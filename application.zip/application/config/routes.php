<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Admin';
$route['(:any)'] = 'Admins/login';
$route['dashboard'] = 'Admin/dashboard';
$route['profile'] = 'Admin/profile';
$route['Stats'] = 'Chats';
$route['changepassword'] = '/Admin/changepassword';
$route['Movie/(:any)'] = 'Movie/index/$1';
$route['News/(:any)'] = 'News/index/$1';
$route['Wishes/(:any)'] = 'Wishes/index/$1';
$route['Awards/(:any)'] = 'Awards/index/$1';
$route['Speeches/(:any)'] = 'Speeches/index/$1';
$route['Foundations/(:any)'] = 'Foundations/index/$1';
$route['Events/(:any)'] = 'Events/index/$1';
$route['SocialService/(:any)'] = 'SocialService/index/$1';
$route['Video/(:any)'] = 'Video/index/$1';
$route['Adds/(:any)'] = 'Adds/index/$1';
$route['Openion/(:any)'] = 'Openion/index/$1';
$route['Admins'] = 'Admins/index';
$route['users'] = 'users/index';
$route['Celebrity'] = 'Celebrity/index';
$route['Celebrity/(:any)'] = 'Celebrity/index/$1';
$route['Timeline'] = 'Timeline/index';
$route['Timeline/(:any)'] = 'Timeline/index/$1';
$route['Timeline/addTimeline'] = 'Timeline/addTimeline';
$route['Timeline/deleteTimelineImages'] = 'Timeline/deleteTimelineImages';
$route['Celebrity/addCelebrity'] = 'Celebrity/addCelebrity';

$route['Movie/deleteMovie'] = 'Movie/deleteMovie';
$route['Movie/addMovie'] = 'Movie/addMovie';

$route['Awards/deleteAwards'] = 'Awards/deleteAwards';
$route['News/deleteNews'] = 'News/deleteNews';
$route['Wishes/deleteWishes'] = 'Wishes/deleteWishes';
$route['Speeches/deleteSpeech'] = 'Speeches/deleteSpeech';
$route['Foundations/deleteFoundation'] = 'Foundations/deleteFoundation';
$route['Events/deleteEvent'] = 'Events/deleteEvent';
$route['SocialService/deleteSocialService'] = 'SocialService/deleteSocialService';
$route['Timeline/deleteTimeline'] = 'Timeline/deleteTimeline';
$route['Video/deleteVideo'] = 'Video/deleteVideo';
$route['Adds/deleteAdd'] = 'Adds/deleteAdd';
$route['Openion/deleteOpenion'] = 'Openion/deleteOpenion';
$route['Gallery/deleteGallery'] = 'Gallery/deleteGallery';
$route['PromotionBanners/deletePromotionBanner'] = 'PromotionBanners/deletePromotionBanner';
$route['Video/deletevideo'] = 'Video/deletevideo';
$route['Movie/deleteImage'] = 'Movie/deleteImage';
$route['Movie/deleteGalleryImages'] = 'Movie/deleteGalleryImages';
$route['Movie/deleteTrailer'] = 'Movie/deleteTrailer';
$route['Movie/deleteSong'] = 'Movie/deleteSong';
$route['Movie/addGalleryImages'] = 'Movie/addGalleryImages';
$route['Movie/addGalleryImages/(:any)'] = 'Movie/addGalleryImages/$1';

$route['News/editNews'] = 'News/editNews';

$route['translate_uri_dashes'] = FALSE;

//new
$route['Celebrity/deleteCelebrity'] = 'Celebrity/deleteCelebrity';
$route['News/deleteImage'] = 'News/deleteImage';
$route['Movie/editGalleryImages'] = 'Movie/editGalleryImages';
//End
