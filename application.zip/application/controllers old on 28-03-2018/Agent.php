<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Agent extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
		$this->load->model('Agent_model'); 

	}
	
	/*************
	**************
	This method will useful to login as a super admin.
	@param : Email_OR_phone
	@param : password
	return boolen
	**************
	*************/
	function index()
	{
		        if($this->session->userdata('agent_id')){
					redirect(AGENT_DASHBOARD_URL,'refresh'); 
				}
				$urlName=$this->uri->segment(1);
				$where=array('agent_name'=>$urlName);
				$check=$this->getSingleRecord(TBL_BLOOD_BANK_AGENTS,$where,$select="*");
				if($check && count($check)>0){
		      try{
				  $this->load->helper('url');
				  $data=array();
				if (!empty($_POST)) 
				{
					 $this->session->unset_userdata('Role_Id');
                    $this->load->library('form_validation');
					$this->form_validation->set_rules('Email_OR_phone','Email or Phone Number','trim|required');
					$this->form_validation->set_rules('password','Password','trim|required');
					if($this->form_validation->run()!=false)
					{
						$remember = trim($this->input->post('remember'));
						$this->session->set_userdata('remember',$remember);
						
						$Email_OR_phone = trim($this->input->post('Email_OR_phone'));
						$password       = trim($this->input->post('password'));
						$result = $this->Agent_model->login($Email_OR_phone, $password);
						// echo "<pre>";print_r($result);die();
						if($result) 
						{
							$session_remember=$this->session->userdata('remember');
							if(!empty( $session_remember) && $session_remember==1){
								
							  $cookie1= array('name'   => 'agent_Name', 'value'  => $Email_OR_phone, 'expire' => '630720000','path'=>'/'  );
							  $cookie2= array('name'   => 'cookie_agent_password', 'value'  => $password, 'expire' => '630720000', 'path'=>'/' );
							  $cookie3= array('name'   => 'agent_remember', 'value'  => $session_remember, 'expire' => '630720000', 'path'=>'/' );
							    $this->input->set_cookie($cookie1);
							    $this->input->set_cookie($cookie2);
							    $this->input->set_cookie($cookie3);
						     }else {   
							  $cookie1= array('name'   => 'agent_Name', 'value'  => '','expire' => time()-3600, );
							  $cookie2= array('name'   => 'cookie_agent_password','value'  => '','expire' => time()-3600, );
							  $cookie3= array('name'   => 'agent_remember','value'  => '','expire' => time()-3600,);
								$this->input->set_cookie($cookie1);
								$this->input->set_cookie($cookie2);
								$this->input->set_cookie($cookie3);
						    }
							
							$this->setuser_sessiondata($result); 
							$data['successMessage'] = LOGIN_SUCCESS;
							redirect(AGENT_DASHBOARD_URL,'refresh'); 
						} 
						else 
						{
							 $this->session->set_flashdata('Fmessage', EMAIL_OR_PHONE_AND_PASSWORD_NOT_MATCH); 
                             $data['errorMessage'] = EMAIL_OR_PHONE_AND_PASSWORD_NOT_MATCH;
						}
					}
					else {
						$this->session->set_flashdata('Fmessage', validation_errors()); 
						$data['errorMessage']=validation_errors();
					}
					
				}
				
				
				
		 }catch (Exception $exception)
		 {
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		 } 	
		
		
	//	$this->load->view('header');
		$this->load->view('index',$data);
		$this->load->view('footer');
          }else{
			   $this->load->view('pageNotFound');
		   }
	}
	
	function dashboard(){
		try{
			$agentId=$this->session->userdata('agent_id');
			if( empty($agentId))
			{
				redirect(AGENT_LOGOUT_URL,'refresh');
			}
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		$where = array('isActive'=>1,'isDeleted'=>0,'agentId'=>$agentId);
        $usersCount = $this->getAllRecords(TBL_USERS,$where,'count(*) as users_count');
		$data['usersCount'] = $usersCount[0];
        $bloodGroupsCount = $this->getAllRecords(TBL_AVAILABLE_BLDGRUPS,$where,'count(*) as bloodGroupsCount');
		$data['bloodGroupsCount'] = $bloodGroupsCount[0];
        $bloodBanksCount = $this->getAllRecords(TBL_BLOOD_BANKS,$where,'count(*) as bloodBanksCount');
		$data['bloodBanksCount'] = $bloodBanksCount[0];
		$Evenets = $this->getAllRecords(TBL_EVENTS,$where,'count(*) as Evenets');
		$data['Evenets'] = $Evenets[0];
		//echo "<pre>";print_r($data);die();
        $this->load->view('header');
		$this->load->view('dashboard',$data);
		$this->load->view('footer');
	}
	
	
	/*******************
	********************
	This method is useful to 
	logout the user.
	********************
	********************/
	function logout(){
		    $Role_Id=$this->session->userdata('Role_Id');
		    $this->session->unset_userdata('agent_email');
		    $this->session->unset_userdata('agent_phone');
		    $this->session->unset_userdata('agent_address');
		    $this->session->unset_userdata('agent_bld_bank_id');
		    $this->session->unset_userdata('agent_id');
			$isAgentIn=$this->session->userdata('isAgentIn');
			$agent_name=$this->session->userdata('agent_name');
			if(empty($Role_Id) && $isAgentIn){
				redirect(SITEURL.'/'.$agent_name);
			}else{
				redirect(SITEURL);
			}
            
		}
	
	/*******************
	********************
	This method is useful to set the login user details into session
	********************
	********************/
	function setuser_sessiondata($result){ 
		if($result)
		   {
		        $agent_id = $result->agent_id;
			   	$agent_name = $result->agent_name;
			   	$agent_email = $result->agent_email;
				$agent_phone=$result->agent_phone;
				$agent_address=$result->agent_address;
				$agent_bld_bank_id=$result->agent_bld_bank_id;
			   	$newdata = array('agent_id'  => $agent_id,
			   	                 'agent_name'  => $agent_name,
			   	                 'agent_email' => $agent_email,
								 'agent_phone' => $agent_phone,
			   	                 'loggedIn' => TRUE,
								 'agent_address' => $agent_address,
								 'agent_bld_bank_id' => $agent_bld_bank_id,
								 'isAgentIn' => 1
			   			   );
						   
			   	$this->session->set_userdata($newdata);
			}
	}
	
	
	function profile(){
       
		   $agent_id=$this->session->userdata('agent_id');
		 if(empty($agent_id))
		{
			redirect(AGENT_LOGOUT_URL,'refresh');
		}
		
		 
		
		$where = array('agent_id' => $agent_id);
		$details=$this->getSingleRecord(TBL_BLOOD_BANK_AGENTS,$where);
		$data['details']=$details;
            $where = array('isDeleted'=>0);
            $bloodBanks = $this->getAllRecords(TBL_BLOOD_BANKS,$where,'*');
		    $data['bloodBanks']= $bloodBanks ; 
        $this->load->view('header');
		$this->load->view('Agent/profile',$data);
		$this->load->view('scripts');
		$this->load->view('footer');
		
		}
		
	function updateProfile()
	 {
		//debug($_POST);
		 $userId = trim($this->input->post('id'));
		 $name = trim($this->input->post('name'));
		 $emailAddress = trim($this->input->post('emailAddress'));
		 $phoneNumber = trim($this->input->post('phoneNumber'));
		 $agent_address = trim($this->input->post('agent_address'));
		
		 if(!empty($name))        { $data['agent_name']= $name;                      }
		 if(!empty($emailAddress)){ $data['agent_email']= $emailAddress;          }
		 if(!empty($phoneNumber)) { $data['agent_phone']= $phoneNumber;            }
		 if(!empty($agent_address)) { $data['agent_address']= $agent_address;            }
		
         $data['updatedTime'] = date("Y-m-d H:i:s");//debug($data);
		 $where = array('agent_id'=>$userId);
		 $result=$this->insertOrUpdate(TBL_BLOOD_BANK_AGENTS,$where,$data);
		 if($result>0){
               $this->session->set_flashdata('Smessage', 'Your Profile Updated successfully'); 
               redirect(AGENT_PROFILE_URL);
			  // $message = SUCCESSFULLY_UPDATED;
			    }else{
			   $this->session->set_flashdata('Fmessage', 'Error occured'); 
               redirect(AGENT_PROFILE_URL);
				   
			    }
				//echo json_encode($message); die();
	 }
	 
	 function changepassword()
	 {
		  $userId=$this->session->userdata('agent_id');
		  $where = array('agent_id' => $userId);
		  $details=$this->getSingleRecord(TBL_BLOOD_BANK_AGENTS,$where);
		  $data['details']=$details;
		  
		  $where = array('isDeleted' => 0,'isActive'=>1);
		  $this->load->view('header');
		  $this->load->view('Agent/changepassword',$data);
		  $this->load->view('footer');

	}
	 function updatePassword()

	{
		
		 $this->load->library('form_validation');
		 $this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[20]');
		 $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]');
	     if($this->form_validation->run()!=false)
		 {
			 if($this->session->userdata('agent_id')){
		 $userId=$this->session->userdata('agent_id');
			 }else{
				  $userId=$this->input->post('agentId');
				  $token=$this->input->post('token');
			 }
		 $update_password=trim($this->input->post('password'));
		 $where = array('agent_id' => $userId);
	//debug($where);
				 $new_password = trim($this->input->post('password'));
				 $confirm_password = trim($this->input->post('cpassword'));
				 if(!empty($new_password)){ $superadmin_data['agent_password']=md5($new_password);    }
				 $superadmin_data['updatedTime'] = date("Y-m-d H:i:s");
				 $where = array('agent_id'=>$userId);
				 $result=$this->insertOrUpdate(TBL_BLOOD_BANK_AGENTS,$where,$superadmin_data);
				
				 if($result>0){
                  $this->session->set_flashdata('Smessage', PASSWORD_UPDATE_SUCCESS); 
                  redirect(AGENT_CHANGEPASSWORD_URL);
						}else{
					 $this->session->set_flashdata('Fmessage', 'Error occured'); 
                     redirect(AGENT_CHANGEPASSWORD_URL);
						}
			 }
			
		else
		{
            $this->session->set_flashdata('Fmessage', validation_errors()); 
                     redirect(AGENT_CHANGEPASSWORD_URL);
			
		}
		//echo json_encode($message); die();
		 
	}
	function forgotPassword()
	{  
		    $this->load->helpers('common.php');
		    $token=generateRandNumber(6);
			$purpose="Recover Password";
			
            $email_id=trim($this->input->post('emailId'));
			$result = $this->Agent_model->user_exists($email_id);
			   if($result){
                    $user_id=$result->agent_id; 
					$this->Agent_model->saveRecoveryEmailData($user_id,$token,$purpose);
			        $message = PLEASE_CHECK_YOUR_MOBILE_FOR_OTP;
				    //$this->response(array($message), 200);
					$subject="OTP";
					$url=RESET_PASSWORD_URL.'/'.$token;debug($url);
					$message.="<p>Please <a type='button' href='$url'  class='btn register_btn blue_btn mt5'>Click here</a> to reset your passwordt.</p>";
					//$message="Click here to reset your password:".$url;
					$subject = 'Account Details';
				    $smtpEmailSettings = $this->config->item('smtpEmailSettings');
					$isEmailSent = sendSmtpEmail($smtpEmailSettings['smtp_user'],$email_id,$subject,$message);
					$this->session->set_flashdata('Smessage','Check your email to reset password'); 
					redirect(SITEURL.'/'.$result->agent_name);
                }else{
					$this->session->set_flashdata('Fmessage',NO_RECORDS_EXISTS); 
			       //$message = array('status' => 0,'message' =>NO_RECORDS_EXISTS,'result' =>'');
				   redirect(SITEURL);
               }
			
	}
	function resetPassword(){
		$token=$this->uri->segment(3);
		$where=array('token'=>$token,'isActive'=>1);
		$details=  $this->getSingleRecord(TBL_RECOVERY_PASSWORDS,$where,$select="agentId");
		if($details){
				$userId=$details->agentId;
				/*$updateToken['isActive']=0;
				$where=array('userID'=>$userId,'token'=>$token);
				$this->insertOrUpdate(RECOVERY_EMAILS,$where,$updateToken);*/
				$data['agentId']=$userId;
				$data['token']=$token;
				$this->load->view('header');
				$this->load->view('Agent/resetPassword',$data);
				$this->load->view('footer');
				 }
			   else{
				    $this->session->set_flashdata('Fmessage','Your Token has been expired'); 
                    redirect(FORGOT_PASSWORD_URL);
				} 
	}
	 function changeForgotPassword()

	{ //debug($_POST);
		
		 $this->load->library('form_validation');
		 $this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[20]');
		 $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]');
	     if($this->form_validation->run()!=false)
		 {
			
				  $userId=$this->input->post('agentId');
				  $token=$this->input->post('token');
			     
		          $update_password=trim($this->input->post('password'));
		          $where = array('agent_id' => $userId);
				 $new_password = trim($this->input->post('password'));
				 $confirm_password = trim($this->input->post('cpassword'));
				 if(!empty($new_password)){ $superadmin_data['agent_password']=md5($new_password);    }
				 $superadmin_data['updatedTime'] = date("Y-m-d H:i:s");
				 $where = array('agent_id'=>$userId);
				 $result=$this->insertOrUpdate(TBL_BLOOD_BANK_AGENTS,$where,$superadmin_data);
				
				 if($result>0){
					 //$token=$this->uri->segment(3);
		              $where=array('token'=>$token,'agentId'=>$userId);
					  $tokenData['isactive']=0;
		              $details=  $this->insertOrUpdate(TBL_RECOVERY_PASSWORDS,$where,$tokenData);//debug($this->db->last_query());
					  $userDetails=$this->getSingleRecord(TBL_BLOOD_BANK_AGENTS,$where=array('agent_id'=>$userId),"*");
					  $name=$userDetails->agent_name;
                      $this->session->set_flashdata('Smessage', PASSWORD_UPDATE_SUCCESS); 
                      redirect(SITEURL.'/'.$name);
				}else{
					 $this->session->set_flashdata('Fmessage', 'Error occured'); 
                     redirect(AGENT_CHANGEPASSWORD_URL);
						}
			 }
			
		else
		{
            $this->session->set_flashdata('Fmessage', validation_errors()); 
                     redirect(RESET_PASSWORD_URL.'/'.$token);
			
		}
		 
	}
	
	
	
	
}