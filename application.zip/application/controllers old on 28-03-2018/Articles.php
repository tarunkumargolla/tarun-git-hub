<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Articles extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
		$this->load->model('Commonmodel','Commonmodel');
       date_default_timezone_set('Asia/Kolkata');
	}
	
  /*********************************
	 **********************************
	 * This service will useful to get blood banks.
	 * @param address
	 * @serviceType GET
	 * @responseType JSON
	 ************************************
	 ************************************/
	 function index(){
		 try{
			 //neww
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
			
			$where = array('isDeleted'=>0);
            $articles = $this->getAllRecords(TBL_ARTICLES_REF,$where,'*');
		    $data['articles']= $articles ;
		    $this->load->view('header');
		    $this->load->view('Articles/articles',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 
	 function addArticle(){
		 try{
			 $data=array();
			 //neww
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id))
			{
			redirect(LOGOUT_URL,'refresh');
			}
			
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_ARTICLES_REF,$where=array('articleTypeID'=>$id),'*');
				$data['details']=$details;
				
			}
				if( $this->input->post( 'AddArticle' ) ){
					$this->load->library('form_validation');
					$this->form_validation->set_rules('name','Name','trim|required|min_length[3]');
				   if($this->form_validation->run()!=false)
					{ 
				    $name=$this->input->post('name');
				        if(empty($id)){
						  $where=array('articleType'=>$name,'isDeleted'=>0); 
				          $checkExists=$this->getSingleRecord(TBL_ARTICLES_REF,$where,'*');
						  }
						  else{
						  $where=array('articleType'=>$name,'isDeleted'=>0);
						  $checkExists=$this->Commonmodel->checkArticleExists(TBL_ARTICLES_REF,$where,$id);
						  }
				         if(count($checkExists)>0){
						     $this->session->set_flashdata('Fmessage',"Article already existed with this name." ); 
					          if($id)
							   redirect(ADD_ARTICLES_URL.'/'.$id);
							  else
								redirect(ADD_ARTICLES_URL);
					    }
					    $inputdata['articleType'] = $this->input->post('name');
				        $inputdata['isActive'] = 1;
				        $inputdata['isDeleted'] = 0;
						if($id){
							$inputdata['updatedAt'] = date('y-m-d h:i:s');
                            $where=array('articleTypeID'=>$id);
						}else{
							 $inputdata['createdAt'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_ARTICLES_REF,$where,$inputdata);	
                        if($result){
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(ARTICLES_URL);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_ARTICLES_URL.'/'.$id);
							  else
								redirect(ADD_ARTICLES_URL);
						}					
					 
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_ARTICLES_URL);
					  }else{redirect(ADD_ARTICLES_URL);}
						
						  
					}
				}
		    $this->load->view('header');
		    $this->load->view('Articles/addArticle',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 
	function deleteArticle()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('articleTypeID'=>$id);
			$data['isDeleted'] = 1;
			$data['updatedAt']= date('y-m-d h:i:s');
			$success = $this->insertOrUpdate(TBL_ARTICLES_REF,$where,$data);
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	 
	 

	
}