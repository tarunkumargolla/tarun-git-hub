<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Categories extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
		$this->load->model('Commonmodel','Commonmodel');
        date_default_timezone_set('Asia/Kolkata');
	}
	
  /*********************************
	 **********************************
	 * This service will useful to get blood banks.
	 * @param address
	 * @serviceType GET
	 * @responseType JSON
	 ************************************
	 ************************************/
	 function index(){
		 try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) )
			{
			 redirect(LOGOUT_URL,'refresh');
			}
			$where = array('isDeleted'=>0);
            $catrgories = $this->getAllRecords(TBL_CATEGORIES,$where,'*');
		    $data['catrgories']= $catrgories ;
			$this->load->view('header');
		    $this->load->view('Categories/categories',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function addCategory(){
		 try{
			 $data=array();
				 //neww
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
			
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_CATEGORIES,$where=array('cat_id'=>$id),'*');
				$data['details']=$details;
				
			}
			
				if( $this->input->post( 'addCategory' ) ){ 
					//debug($_FILES);
					$this->load->library('form_validation');
					$this->form_validation->set_rules('cat_name',' Category Name','trim|required');
					$this->form_validation->set_rules('colour_code','Colour code','trim|required');
				   if($this->form_validation->run()!=false)
					{ 
				    $cat_name=$this->input->post('cat_name');
					 if(empty($id)){
						   $where=array('cat_name'=>$cat_name,'isDeleted'=>0); 
						   $checkExists=$this->getSingleRecord(TBL_CATEGORIES,$where,'*');
						  }
						  else{
						    $where=array('cat_name'=>$cat_name,'isDeleted'=>0); 
						    $checkExists=$this->Commonmodel->checkCategoryExists(TBL_CATEGORIES,$where,$id);
						  }
				         if(count($checkExists)>0){
							  $this->session->set_flashdata('Fmessage',"Category already existed with this Name." ); 
							 if($id)
									redirect(ADD_CATEGORIES_URL.'/'.$id);
								else
									redirect(ADD_CATEGORIES_URL);
							  }
					
						  $cat_name = trim($this->input->post('cat_name'));
						   $colour_code=trim($this->input->post('colour_code'));
						   
						   $updata['cat_name'] = $cat_name;
						   $updata['cat_colour_code'] = $colour_code;
						   
						 
						   
	       if($_FILES){
		   $target_path ='../uploads/categories/'; 
	       $fileTypes = array('jpeg', 'png', 'jpg','gif');
			if(!empty($_FILES['cat_image']['name'])){
			  $response['file_name'] = basename($_FILES['cat_image']['name']);
			  $filename=basename($_FILES['cat_image']['name']);
			  $rand=rand();
			  $file_extension=pathinfo($_FILES['cat_image']['name']);
			   $picname=$rand.time().'.'.strtolower($file_extension['extension']); 
			   $target_path = $target_path . $picname; 
			    if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
					$movefile=move_uploaded_file($_FILES['cat_image']['tmp_name'], $target_path);
				    if($movefile){
						$updata['cat_image']=$picname;
			         }
				    }else{
					    $this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
						redirect(ADD_CATEGORIES_URL);
					 }
			}
		
	      }		  	   
					if($id){
							$updata['updatedTime'] = date('y-m-d h:i:s');
                            $where=array('cat_id'=>$id);
						}else{
							 $updata['createdTime'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_CATEGORIES,$where,$updata);  //debug($this->db->last_query());
                        if($result){
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(CATEGORIES_URL);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_CATEGORIES_URL.'/'.$id);
							  else
								redirect(ADD_CATEGORIES_URL);
						}					
					 
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_CATEGORIES_URL.'/'.$id);
					  }else{redirect(ADD_CATEGORIES_URL);}
						
						  
					}
				}
		    $this->load->view('header');
		    $this->load->view('Categories/addCategory',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function deleteCategory()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('cat_id'=>$id);
			$data['isDeleted'] = 1;
			
			$success = $this->insertOrUpdate(TBL_CATEGORIES,$where,$data);
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	 
	 
	
	
}