<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Chats extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
		$this->load->model('Chatmodel','Chatmodel');
        date_default_timezone_set('Asia/Kolkata');
	}
	
  /*********************************
	 **********************************
	 * This service will useful to get blood banks.
	 * @param address
	 * @serviceType GET
	 * @responseType JSON
	 ************************************
	 ************************************/
	 function index(){
		 try{  
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) )
			{ 
			 redirect(LOGOUT_URL,'refresh');
			}
			$where = array('isActive'=>1,'isDeleted'=>0);
            $chatMembers = $this->getAllRecords(TBL_CHAT_MEMBERS,$where,'*','ID');
		    $data['chatMembers']= $chatMembers ;
			$where=array('is_active'=>1);
			$chatTypes=$this->getAllRecords(TBL_CHAT_TYPES,$where,'*');
			$data['chatTypes']=$chatTypes;
			$where=array('isDeleted'=>0,'news_article_type'=>8);
			$news=$this->getAllRecords(TBL_NEWS,$where,'*');
			$data['news']=$news;
			$this->load->view('header');
		    $this->load->view('Chats/chats',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function newsBySearch(){
          
		    $id= trim($this->input->post('id'));
		    $where = array('isDeleted'=>0,'isActive'=>1,'newsID'=>$id);
			$chatMembers = $this->getAllRecords(TBL_CHAT_MEMBERS,$where,'*','ID');		    
			$data['chatMembers']= $chatMembers ;
            $where=array('is_active'=>1);
			$chatTypes=$this->getAllRecords(TBL_CHAT_TYPES,$where,'*');
			$data['chatTypes']=$chatTypes;
			$where=array('isDeleted'=>0,'news_article_type'=>8);
			$news=$this->getAllRecords(TBL_NEWS,$where,'*');
			$data['news']=$news; 
			$this->load->view('Chats/chat_members_ajax',$data);
	}
	 function addMember(){
		 try{
			$data=array();
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
			$where=array('is_active'=>1);
			$chatTypes=$this->getAllRecords(TBL_CHAT_TYPES,$where,'*');
			$data['chatTypes']=$chatTypes;
			$where=array('isDeleted'=>0,'news_article_type'=>8);
			$news=$this->getAllRecords(TBL_NEWS,$where,'*');
			$data['news']=$news;
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_CHAT_MEMBERS,$where=array('ID'=>$id),'*');
				$data['details']=$details;
				
			}
			
				if( $this->input->post( 'addMember' ) ){ 
					$this->load->library('form_validation');
					$this->form_validation->set_rules('name',' Name','trim|required');
					$this->form_validation->set_rules('news','News','trim|required');
					if(empty($id)){
					$this->form_validation->set_rules('chart','chart','trim|required');
					}
				   if($this->form_validation->run()!=false)
					{ 
					 
						  $name=$this->input->post('name');
						  
						  if(empty($id)){
						  $where=array('name'=>$name,'newsID'=>$this->input->post('news'));
						  $checkExists=$this->getAllRecords(TBL_CHAT_MEMBERS,$where,"*");
						  }
						  else{
							   $where=array('name'=>$name,'newsID'=>$id);
						  $checkExists=$this->Chatmodel->checkmemberExists(TBL_CHAT_MEMBERS,$where,$id);
						  }
						  if(count($checkExists) > 0){
								  $this->session->set_flashdata('Fmessage',"Member already existed with this Name." ); 
								  if($id)
								   redirect(ADD_CHAT_MEMBERS_URL.'/'.$id);
								  else
									redirect(ADD_CHAT_MEMBERS_URL);
						  }
					    //}		 
						   $name = trim($this->input->post('name'));
						   $news=trim($this->input->post('news'));
						   $chart=trim($this->input->post('chart'));
						   
						   $Indata['name'] = $name;
						   $Indata['newsID'] = $news;
						   $Indata['chatTypeRefID'] = $chart;
						   
						 
						   
	       if($_FILES){
		   $target_path ='../uploads/chatMembers/'; 
	       $fileTypes = array('jpeg', 'png', 'jpg','gif');
			if(!empty($_FILES['image']['name'])){
			  $response['file_name'] = basename($_FILES['image']['name']);
			  $filename=basename($_FILES['image']['name']);
			  $rand=rand();
			  $file_extension=pathinfo($_FILES['image']['name']);
			   $picname=$rand.time().'.'.strtolower($file_extension['extension']); 
			   $target_path = $target_path . $picname; 
			    if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
					$movefile=move_uploaded_file($_FILES['image']['tmp_name'], $target_path);
				    if($movefile){
						$Indata['image']=$picname;
			         }
				    }else{
					    $this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
						redirect(ADD_CHAT_MEMBERS_URL);
					 }
			}
		
	      }		  	   
					if($id){
                            $where=array('ID'=>$id);
						}else{
							 $Indata['createdAt'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_CHAT_MEMBERS,$where,$Indata);  //debug($this->db->last_query());
                        if($result){
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(CHAT_MEMBERS);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_CHAT_MEMBERS_URL.'/'.$id);
							  else
								redirect(ADD_CHAT_MEMBERS_URL);
						}					
					 
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_CHAT_MEMBERS_URL.'/'.$id);
					  }else{redirect(ADD_CHAT_MEMBERS_URL);}
						
						  
					}
				}
		    $this->load->view('header');
		    $this->load->view('Chats/addChats',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function addValues(){
		  $Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
		    $id=$this->uri->segment('3'); 
			$where=array('ID'=>$id);
			$details=$this->getSingleRecord(TBL_CHAT_MEMBERS,$where,'*');
			$data['details']=$details; 
			$where=array('isActive'=>1,'isDeleted'=>0);
			$news=$this->getAllRecords(TBL_NEWS,$where,'*');
			$data['news']=$news;
			$this->load->view('header');
			if($details->chatTypeRefID ==1 ){
			if($details){
				    $where=array('refMemberID'=>$id,'newsID'=>$details->newsID,'isActive'=>1);
				    $values=$this->getAllRecords(TBL_PIE_GRAPH_VALUES,$where,'*'); 
					$details->values=$values;
			    }
				$this->load->view('Chats/addPieChartValues',$data);
			}else if($details->chatTypeRefID ==2){
				if($details){
				    $where=array('refMemberID'=>$id,'newsID'=>$details->newsID,'isActive'=>1);
				    $values=$this->getAllRecords(TBL_LINE_GRAPH_VALUES,$where,'*');
					$details->values=$values;
			    }
				$this->load->view('Chats/addLineChartValues',$data);
			}else{
				if($details){
				    $where=array('refMemberID'=>$id,'newsID'=>$details->newsID,'isActive'=>1);
				    $values=$this->getAllRecords(TBL_BAR_GRAPH_VALUES,$where,'*');
					$details->values=$values;
			    }
				$this->load->view('Chats/addBarChartVlues',$data);
			}
		    $this->load->view('scripts');
			$this->load->view('footer');
	 }
	 //for pie graph values
	 function savePieGraphValues(){
		 
		$data=$_POST;
		$updata['newsID']=$data['newsId'];
		$updata['refMemberID']=$data['memberId'];
		$percentage=$data['Percentage']; 
		if($percentage){$sum=0;
			foreach($percentage as $per){
				$sum=$sum+$per;
			}
			if($sum < 100 || $sum > 100){
				$this->session->set_flashdata('Fmessage',"Percentage must be equal to 100% " );
                 redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);
			}
		}
		$where=array('newsID'=>$data['newsId'],'refMemberID'=>$data['memberId']);
		$this->Chatmodel->deleteValues(TBL_PIE_GRAPH_VALUES,$where);
		$values=$data['value'];
		$texts=$data['text']; 
		$percentage=$data['Percentage']; 
		if($texts){$i=0;
			foreach($texts as $text){
				//$updata['value']=$value;
				$updata['text']=$texts[$i];
                $updata['percentage']=$percentage[$i];				
				$where=array();
		        $RES=$this->insertOrUpdate(TBL_PIE_GRAPH_VALUES,$where,$updata);  
				$i++;
			}
			
		}
		 

		    if($RES){
				$d['isActive']=1;
				$where=array('news_id'=>$data['newsId']);
				$this->insertOrUpdate(TBL_NEWS,$where,$d); 

					$this->session->set_flashdata('Smessage',SUCCESS ); 
					 redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);
					}else{
						$this->session->set_flashdata('Fmessage',FAILED );
                        redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);						
					}
	 } 
	 //for bar graph values
	 function saveBarGraphValues(){
		$data=$_POST;
		$updata['newsID']=$data['newsId'];
		$updata['refMemberID']=$data['memberId'];
		$where=array('newsID'=>$data['newsId'],'refMemberID'=>$data['memberId']);
		$this->Chatmodel->deleteValues(TBL_BAR_GRAPH_VALUES,$where);
		$values=$data['value'];
		$texts=$data['text']; 
		if($values){$i=0;
			foreach($values as $value){
				$updata['value']=$value;
				$updata['text']=$texts[$i]; 
				$where=array();
		        $RES=$this->insertOrUpdate(TBL_BAR_GRAPH_VALUES,$where,$updata); 
				$i++;
			}
			
		}
		
		if($RES){
			
			$d['isActive']=1;
				$where=array('news_id'=>$data['newsId']);
				$this->insertOrUpdate(TBL_NEWS,$where,$d); 
						$this->session->set_flashdata('Smessage',SUCCESS ); 
					   redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);
					}else{
						$this->session->set_flashdata('Fmessage',FAILED );
                        redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);						
					}
	 }
	 //for line graph values
	 function saveLineGraphValues(){
		 
		$data=$_POST; 
		$updata['newsID']=$data['newsId'];
		$updata['refMemberID']=$data['memberId'];
		$where=array('newsID'=>$data['newsId'],'refMemberID'=>$data['memberId']);
		$this->Chatmodel->deleteValues(TBL_LINE_GRAPH_VALUES,$where);
		$values=$data['x'];
		$texts= $data['y']; 
		if($values){$i=0;
			foreach($values as $value){
				$updata['x']=$value;
				$updata['y']=$texts[$i]; 
				$where=array(); 
		        $RES=$this->insertOrUpdate(TBL_LINE_GRAPH_VALUES,$where,$updata); 
				$i++;
			}
			
		}
		if($RES){
			
			    $d['isActive']=1;
				$where=array('news_id'=>$data['newsId']);
				$this->insertOrUpdate(TBL_NEWS,$where,$d); 
				
						$this->session->set_flashdata('Smessage',SUCCESS ); 
					    redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);
					}else{
						$this->session->set_flashdata('Fmessage',FAILED );
                        redirect(ADD_CHAT_VALUES_URL.'/'.$data['memberId']);						
					}
	 }
	 function deleteMember()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('ID'=>$id);
			$data['isDeleted'] = 1;
			$success = $this->insertOrUpdate(TBL_CHAT_MEMBERS,$where,$data);
			if($success)
			{
				$where = array('ID'=>$id);
				$ress=$this->getSingleRecord(TBL_CHAT_MEMBERS,$where,'*');
				$newsId=$ress->newsID;
				$d['isActive']=0;
				$where=array('news_id'=>$newsId);
				$res=$this->insertOrUpdate(TBL_NEWS,$where,$d);
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	function deleteBarGraphValue()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$chartType = $this->input->post('chart');
			$where = array('ID'=>$id);
			$data['isDeleted'] = 1;
			if($chartType ==1){
				$where=array('id'=>$id);
				$table=TBL_PIE_GRAPH_VALUES;
			}else if($chartType == 2){
				$where=array('lgID'=>$id);
				$table=TBL_LINE_GRAPH_VALUES;
			}else{
				$where=array('bgID'=>$id);
				$table=TBL_BAR_GRAPH_VALUES;
			}
			$success=$this->Chatmodel->deleteValues($table,$where);
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	 
	 
	 
	
	
}