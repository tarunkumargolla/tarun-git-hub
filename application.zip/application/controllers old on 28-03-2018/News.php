<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class News extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
		$this->load->model('Newsmodel');
		$this->load->model('Commonmodel','Commonmodel');

		date_default_timezone_set('Asia/Kolkata');
	}
	
  /*********************************
	 **********************************
	 * This service will useful to get blood banks.
	 * @param address
	 * @serviceType GET
	 * @responseType JSON
	 ************************************
	 ************************************/
	 function index(){
		 try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) )
			{
			 redirect(LOGOUT_URL,'refresh');
			}
			$where = array('isDeleted'=>0);
            $news = $this->getAllRecords(TBL_NEWS,$where,'*','news_id');
		    $data['news']= $news ;
			
            $categories = $this->getAllRecords(TBL_CATEGORIES,$where,'*');
		    $data['categories']= $categories ;$where = array('isDeleted'=>0);
			
            $articles = $this->getAllRecords(TBL_ARTICLES_REF,$where,'*');
		    $data['articles']= $articles ;
			
			$this->load->view('header');
		    $this->load->view('News/news',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function addNews(){
		 try{
			 $data=array();
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
			
			
			$where = array('isDeleted'=>0);
            $categories = $this->getAllRecords(TBL_CATEGORIES,$where,'*');
		    $data['categories']= $categories ;$where = array('isDeleted'=>0);
			
            $articles = $this->getAllRecords(TBL_ARTICLES_REF,$where,'*');
		    $data['articles']= $articles ;
			
				if( $this->input->post( 'addNews' ) ){  
				   
					$this->load->library('form_validation');
					$this->form_validation->set_rules('news_title','News Title','trim|required');
					//$this->form_validation->set_rules('news_content','News Content','trim|required');
					$this->form_validation->set_rules('news_cat','News Category','trim|required');
					$this->form_validation->set_rules('news_article','News Article','trim|required');
					$this->form_validation->set_rules('source_link','News Source','trim|required');
					$this->form_validation->set_rules('source_name','News Source Name','trim|required');
				   if($this->form_validation->run()!=false)
					{ 
					
				           $news_title = trim($this->input->post('news_title'));
						   $where=array('news_title'=>$news_title);
						  /*  $Exists=$this->getAllRecords(TBL_NEWS,$where,"*");
						    if($Exists && count($Exists)>0){
							  $this->session->set_flashdata('Fmessage',"News already existed with this title." ); 
                              redirect(ADD_NEWS_URL);
						   }   */
						    
						   $news_content=trim($this->input->post('news_content'));
						   $news_cat=trim($this->input->post('news_cat'));
						   $news_article=trim($this->input->post('news_article'));
						   $source_name=trim($this->input->post('source_name'));
						   $source_link=trim($this->input->post('source_link'));
						   $is_trending_news=trim($this->input->post('is_trending_news'));
						   
						   $Idata['news_title'] = $news_title;
						   $Idata['news_content'] = $news_content;
						   $Idata['news_category_id'] = $news_cat;
						   $Idata['news_article_type'] = $news_article;
						   $Idata['isTrendingNews'] = $is_trending_news;
						   if($news_article == 5 || $news_article == 6 || $news_article == 7 || $news_article == 8 || $news_article == 13 ){
							   $isPremiun=1;
								   }else{
							  $isPremiun=0;
							 }
							 if($news_article == 8){
								   $Idata['isActive'] =0;
							 }
						   $Idata['createdTime'] = date('y-m-d h:i:s');
						   $where=array();
						   $result=$this->insertOrUpdate(TBL_NEWS,$where,$Idata); 
                           $last_id=$this->db->insert_id();

                           if($result){
								if($_FILES){ 
                                    //adding source details
									  if(!empty($_FILES['source_file']['name'])){
                                      $target_path ='../uploads/sourceimages/'; 
									  $fileTypes = array('jpeg', 'png', 'jpg','gif');
									  $response['file_name'] = basename($_FILES['source_file']['name']);
									  $filename=basename($_FILES['source_file']['name']);
									  $rand=rand();
									  $file_extension=pathinfo($_FILES['source_file']['name']); 
									   $picname=$rand.time().'.'.strtolower($file_extension['extension']); 
									   $target_path = $target_path . $picname; 
									   if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
											$movefile=move_uploaded_file($_FILES['source_file']['tmp_name'], $target_path);
											if($movefile){
												$sourceData['sourceImage']=$picname;
											 }
											}else{
												$this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
												redirect($url);
											 }
                                    $sourceData['sourceLink'] = $source_link;
                                    $sourceData['sourceName'] = $source_name;
									$sourceData['newsID'] = $last_id;
									$where=array();
									$sourceUp=$this->insertOrUpdate(TBL_NEWS_SOURCES,$where,$sourceData); 
									} 
                                   //end add source
                                   //for images 
								   $imageName="";
                                      $imageName=@$_FILES['news_image']['name']; 
			                          if($news_article == "2" || $news_article == "5" ){
										  $thumb2="";$video_url="";
										  if($_FILES['thumb_image']['name']){
											  
											  if(!empty($_FILES['thumb_image']['name'])){
												  $target_path ='../uploads/news/'; 
												  $fileTypes = array('jpeg', 'png', 'jpg','gif');
												  $response['file_name'] = basename($_FILES['thumb_image']['name']);
												  $filename=basename($_FILES['thumb_image']['name']);
												  $rand=rand();
												  $file_extension=pathinfo($_FILES['thumb_image']['name']); 
												   $picname2=$rand.time().'.'.strtolower($file_extension['extension']); 
												   $target_path = $target_path . $picname2; 
												   if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile=move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
														if($movefile){
															$thumb2=$picname2;
														 }
														}else{
															$this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
															redirect($url);
														 }
												} 
										  }
											
											 $video_url= trim($this->input->post('video_url')); 
											 if($news_article == "2"){
												  $imageName="";
											 }
											 $this->saveVideo($imageName,$isPremiun,$last_id,$thumb2,$video_url);
                                         
										  
                                      }
                                      else{
										   if($news_article == "4" || $news_article == "7" ){
											    $fileTypes = array('gif');
												 $this->saveImages($imageName,$isPremiun,$last_id,$fileTypes);
											}else if($news_article == "12" || $news_article == "13" ){ 
											    $fileTypes = array('jpeg', 'png', 'jpg','gif');
												$web_url=$this->input->post('web_url');
											    $this->saveCoverPages($imageName,$isPremiun,$last_id,$fileTypes,$web_url);
										   }else if($news_article == "11"){
											    $poleData['npNewsId']=$last_id;
											    $poleData['npOption1']=$this->input->post('option1');
											    $poleData['npOption2']=$this->input->post('option2');
												$poleId=$this->insertOrUpdate(TBL_NEWS_POLLS,$where=array(),$poleData);
												
												
											    $fileTypes = array('jpeg', 'png', 'jpg','gif');
												if($poleId){
											    $this->savePollsImages($imageName,$isPremiun,$last_id,$fileTypes,$poleId);
												}
												if($_FILES['back_image']['name']){ 
													$backGroundImage=$_FILES['back_image']['name']; 
													$this->savePollBackgroundImages($backGroundImage,$isPremiun,$last_id,$fileTypes);
												}
										   }
										   else{
											    $fileTypes = array('jpeg', 'png', 'jpg','gif');
											    $this->saveImages($imageName,$isPremiun,$last_id,$fileTypes);
										   }
										  
										   
									  }
									  
                  
							   }
							   if($news_article == "14"){ 
							                      if(!empty($_FILES['thumb_image']['name'])){
												  $target_path ='../uploads/news/'; 
												  $fileTypes = array('jpeg', 'png', 'jpg','gif');
												  $response['file_name'] = basename($_FILES['thumb_image']['name']);
												  $filename=basename($_FILES['thumb_image']['name']);
												  $rand=rand();
												  $file_extension=pathinfo($_FILES['thumb_image']['name']); 
												   $picname2=$rand.time().'.'.strtolower($file_extension['extension']); 
												   $target_path = $target_path . $picname2; 
												   if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile=move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
														if($movefile){
															$thumb=$picname2;
														 }
														}else{
															$this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
															redirect($url);
														 }
												} 
							        $embedData['newsid']=$last_id;
							        $embedData['code']=$_POST['embedcode'];
							        $embedData['thumb']=$thumb;
								    $this->saveEmbedPages($embedData);
							   }
                            
							$this->session->set_flashdata('Smessage',SUCCESS ); 
							$sendNoti=$this->sendNoti($last_id);
							//$url=SEND_PUSH_NOTI_URL.'?newsid='.$last_id;
							//$RES=file_get_contents($url); print_r($RES);die();
					        redirect(NEWS_URL);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          redirect(ADD_NEWS_URL);
						}					
					 
					}
					else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  redirect(ADD_NEWS_URL);
					} 
				}
		    $this->load->view('header');
		    $this->load->view('News/addNews',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');

		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 } 
	 
	 
	 	function sendNoti($newsId){
		 $where=array('news_id'=>$newsId);
		 $NewsDetails=$this->getSingleRecord(TBL_NEWS,$where); 
		 $news['news_id']= $NewsDetails->news_id;
		 $article=$NewsDetails->news_article_type;
		 $array=array(1,3,4,6,7,8,9,10);
		 if(in_array($article,$array)){
			  $where=array('niNewsID'=>$newsId);
			  $newsImages=$this->getSingleRecord(TBL_NEWS_IMAGES,$where,'niNewsImage');
			  $image=$newsImages->niNewsImage;
		 }else if($article == 2 || $article == 5){
			  $where=array('nvNewsID'=>$newsId);
			  $newsImages=$this->getSingleRecord(TBL_NEWS_VIDEOS,$where,'nvVideoThumbnail');
			   $image=$newsImages->nvVideoThumbnail;
		 }else if($article == 12 || $article == 13){
			  $where=array('ncNewsId'=>$newsId);
			  $newsImages=$this->getSingleRecord(TBL_NEWS_COVER_PAGES,$where,'backgroundImage');
			    $image=$newsImages->backgroundImage;
		 }else if($article == 14){
		     $where=array('neNewsId'=>$newsId);
			 $newsImages=$this->getSingleRecord(TBL_NEWS_EMBED_PAGES,$where,'neThumbNail');
			 $image=$newsImages->neThumbNail;
		 }
		
		 $news['image']=$image;
		 $news['title']=$NewsDetails->news_title;
		 $news['article']=$article;
		 $notifyString=json_encode($news);  
		$where=array('isActive'=>1,'isDeleted'=>0);
		$fcmTokens=$this->getAllRecords(TBL_FCM_TOKENS,$where,'fcm_token');
		 if($fcmTokens){
					$notiMessage['title'] = "New News from FlcikNews";
					$notiMessage['text'] = $notifyString;
						foreach($fcmTokens as  $fcm){ 
								$token=$fcm->fcm_token;
							if($token){
								$fields = array(
									'data' => $notiMessage,
									'to' => $token
									);	
								$json = json_encode($fields);
								$send = sendFCMNoti($json);
								//print_r($send);die();
								}
			          }
			//$message = array('status' => 1,'message' => SUCCESS);
		   // $this->response($message, 200);	  
		 } 
	}
	 function saveEmbedPages($data){
		// debug($data);
		 $insertData['neEmbedCode']=$data['code'];
		 $insertData['neNewsId']=$data['newsid'];
		 $insertData['neThumbNail']=$data['thumb'];
		 $insertData['neCreatedAt']=date("y-m-d h:i:s");
		 $result=$this->insertOrUpdate(TBL_NEWS_EMBED_PAGES,$where=array(),$insertData);
		 if($result){
			 $wepdata['neEmbedwebpageUrl']=FSITEURL.'/Webpage?id='.$result;
			 $this->insertOrUpdate(TBL_NEWS_EMBED_PAGES,$where=array('neEmbedId'=>$result),$wepdata);
		 }
	 }
 function savevideo($imageName,$isPremiun,$id,$thumb,$video_url){
        if($imageName){  
					 $i=0;$imageData=array();
					 $fileTypes = array("gif", "mp3", "mp4", "wma");
					 foreach($imageName as $name)
					 { 
						$target_path ='../uploads/news/'; 
						if(!empty($name)){
							$response['file_name'] = basename($name);
							$filename=basename($name);
							$rand=rand();
							$file_extension=pathinfo($name);
							$picname1=$rand.time().'.'.strtolower($file_extension['extension']); 
							$target_path = $target_path . $picname1; 
						 if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
							$movefile=move_uploaded_file($_FILES['news_image']['tmp_name'][$i], $target_path);   
							if($movefile){
								$imageData[$i]=$picname1;
							 }
							 }
						}
							$i++;
					 }
					 if($imageData){ 
							foreach($imageData as $imgD){
								 $upimgData['nvVideo']=$imgD;
								 $upimgData['nvNewsID']=$id;
								 $upimgData['nvIsPremium']=$isPremiun;
								 $upimgData['nvVideoThumbnail']=$thumb;
								 $upimgData['nvVideoUrl']=""; 
								 $where1=array();
								 $rees=$this->insertOrUpdate(TBL_NEWS_VIDEOS,$where1,$upimgData);
								}
				   }
			}else{ 
				$upimgData['nvNewsID']=$id;
				$upimgData['nvVideo']="";
				$upimgData['nvIsPremium']=$isPremiun;
				$upimgData['nvVideoUrl']=$video_url;
				$upimgData['nvVideoThumbnail']=$thumb;
				$where1=array(); 
				$rees=$this->insertOrUpdate(TBL_NEWS_VIDEOS,$where1,$upimgData);
			} 

}


function saveImages($imageName,$isPremiun,$id,$fileTypes){ 
  if($imageName){ 
                 $i=0;$imageData=array();
                 $fileTypes = $fileTypes;
                          foreach($imageName as $name)
									  {
                                         $target_path ='../uploads/news/'; 
										 if(!empty($name)){
											  $response['file_name'] = basename($name);
											  $filename=basename($name);
											  $rand=rand();
											  $file_extension=pathinfo($name);
											   $picname1=$rand.time().'.'.strtolower($file_extension['extension']); 
											   $target_path = $target_path . $picname1; 
												if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
													$movefile=move_uploaded_file($_FILES['news_image']['tmp_name'][$i], $target_path);
													if($movefile){
														$imageData[$i]=$picname1;
													 }
												 }
											}
											$i++;
									      }
										if($imageData){
										foreach($imageData as $imgD){

											$upimgData['niNewsImage']=$imgD;
											$upimgData['niNewsID']=$id;
											$upimgData['niIsPremium']=$isPremiun;
											
											$where1=array();
											$rees=$this->insertOrUpdate(TBL_NEWS_IMAGES,$where1,$upimgData);
											
										}
                      }
			 }
}
function savePollBackgroundImages($imageName,$isPremiun,$id,$fileTypes){ 
  if($imageName){ 
                 $i=0;$imageData=array();
                 $fileTypes = $fileTypes;
                          foreach($imageName as $name)
									  {
                                         $target_path ='../uploads/news/'; 
										 if(!empty($name)){
											  $response['file_name'] = basename($name);
											  $filename=basename($name);
											  $rand=rand();
											  $file_extension=pathinfo($name);
											   $picname1=$rand.time().'.'.strtolower($file_extension['extension']); 
											   $target_path = $target_path . $picname1; 
												if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
													$movefile=move_uploaded_file($_FILES['back_image']['tmp_name'][$i], $target_path);
													if($movefile){
														$imageData[$i]=$picname1;
													 }
												 }
											}
											$i++;
									      }
										if($imageData){
										foreach($imageData as $imgD){

											$upimgData['niNewsImage']=$imgD;
											$upimgData['niNewsID']=$id;
											$upimgData['niIsPremium']=$isPremiun;
											
											$where1=array();
											$rees=$this->insertOrUpdate(TBL_NEWS_IMAGES,$where1,$upimgData);
											
										}
                      }
			 }
}
function savePollsImages($imageName,$isPremiun,$id,$fileTypes,$poleId){
  if($imageName){ 
                 $i=0;$imageData=array();
                 $fileTypes = $fileTypes;
                          foreach($imageName as $name)
									  {
                                         $target_path ='../uploads/news/'; 
										 if(!empty($name)){
											  $response['file_name'] = basename($name);
											  $filename=basename($name);
											  $rand=rand();
											  $file_extension=pathinfo($name);
											   $picname1=$rand.time().'.'.strtolower($file_extension['extension']); 
											   $target_path = $target_path . $picname1; 
												if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
													$movefile=move_uploaded_file($_FILES['news_image']['tmp_name'][$i], $target_path);
													if($movefile){
														$imageData[$i]=$picname1;
													 }
												 }
											}
											$i++;
									      }
										if($imageData){
										foreach($imageData as $imgD){

											$upimgData['image']=$imgD;
											$upimgData['newsPoleId']=$poleId;
											$upimgData['newsId']=$id;
											
											$where1=array();
											$rees=$this->insertOrUpdate(TBL_NEWS_POLLS_IMAGES,$where1,$upimgData);
										}
                      }
			 }
}

function saveCoverPages($imageName,$isPremiun,$id,$fileTypes,$web_url){ 
  if($imageName){ 
                 $i=0;$imageData=array();
                 $fileTypes = $fileTypes;
                          foreach($imageName as $name)
									  {
                                         $target_path ='../uploads/news/'; 
										 if(!empty($name)){
											  $response['file_name'] = basename($name);
											  $filename=basename($name);
											  $rand=rand();
											  $file_extension=pathinfo($name);
											   $picname1=$rand.time().'.'.strtolower($file_extension['extension']); 
											   $target_path = $target_path . $picname1; 
												if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
													$movefile=move_uploaded_file($_FILES['news_image']['tmp_name'][$i], $target_path);
													if($movefile){
														$imageData[$i]=$picname1;
													 }
												 }
											}
											$i++;
									      }
										if($imageData){
										foreach($imageData as $imgD){

											$upimgData['backgroundImage']=$imgD;
											$upimgData['webUrl']=$web_url;
											$upimgData['isPremium']=$isPremiun;
											$upimgData['ncNewsId']=$id;
											$where1=array();
											$rees=$this->insertOrUpdate(TBL_NEWS_COVER_PAGES,$where1,$upimgData);
										}
                      }
			 }
}


function Edit_polls_back_image($imageName,$id){
	
	if($imageName){ 
		      $target_path ='../uploads/news/'; 
	          $fileTypes = array('jpeg', 'png', 'jpg','gif');
			  if(!empty($imageName)){
			  $response['file_name'] = basename($_FILES['edit_poll_back_Image']['name']);
			  $filename=basename($_FILES['edit_poll_back_Image']['name']);
			  $rand=rand();
			  $file_extension=pathinfo($_FILES['edit_poll_back_Image']['name']); 
			   $picname=$rand.time().'.'.strtolower($file_extension['extension']); 
			   $target_path = $target_path . $picname; 
			  
			    if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
					$movefile=move_uploaded_file($_FILES['edit_poll_back_Image']['tmp_name'], $target_path);
				    if($movefile){
						$sourceData['niNewsImage']=$picname;
						$upimgData['niNewsID']=$id;
			         }
				    }else{
					    $this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
						//redirect(currnet_url());
					 }
			}
			
			
			
			$where=array('niNewsID'=>$id);
		    $sourceUp=$this->insertOrUpdate(TBL_NEWS_IMAGES,$where,$sourceData); 
		}
	
}
	
	 function editNews(){
		$id=$this->uri->segment(3);
		$details=$this->Newsmodel->getNewsDetails($id); 
		$data['details']=$details;
		$url=EDIT_NEWS_URL.'/'.$id;
	
		$where = array('isDeleted'=>0);
        $categories = $this->getAllRecords(TBL_CATEGORIES,$where,'*');
		$data['categories']= $categories ;$where = array('isDeleted'=>0);
			
        $articles = $this->getAllRecords(TBL_ARTICLES_REF,$where,'*');
		$data['articles']= $articles ;
		
		if( $this->input->post( 'editNews' ) ){  	
		  $edit_news_title=$this->input->post('edit_news_title');
		  $where=array('news_title'=>$edit_news_title,'isDeleted'=>0);
		  $Exists=$this->Commonmodel->checkNewsExists(TBL_NEWS,$where,$id);
		  if($Exists){
			 $this->session->set_flashdata('Fmessage',"News already existed with this title." ); 
			 redirect(current_url());
          }
		  $edit_content=$this->input->post('edit_content');
		  $edit_source_link=$this->input->post('edit_source_link');
		  $edit_source_name=$this->input->post('edit_source_name'); 
		  $edit_news_cat=$this->input->post('edit_news_cat');
		  $edit_news_article=$this->input->post('edit_news_article');
          $is_trending_news=trim($this->input->post('is_trending_news'));
		
		if($edit_news_title){ $editData['news_title']=$edit_news_title;}
		if($edit_content){ $editData['news_content']=$edit_content;}
		if($edit_news_article){ $editData['news_article_type']=$edit_news_article;}
		if($edit_news_cat){ $editData['news_category_id']=$edit_news_cat;}
        $editData['isTrendingNews']=$is_trending_news;
		$where=array('news_id'=>$id);
		$newsUP=$this->insertOrUpdate(TBL_NEWS,$where,$editData); 
		if($newsUP){  
			if($_FILES['edit_source_Image']['name']){ 
		      $target_path ='../uploads/sourceimages/'; 
	          $fileTypes = array('jpeg', 'png', 'jpg','gif');
			  if(!empty($_FILES['edit_source_Image']['name'])){
			  $response['file_name'] = basename($_FILES['edit_source_Image']['name']);
			  $filename=basename($_FILES['edit_source_Image']['name']);
			  $rand=rand();
			  $file_extension=pathinfo($_FILES['edit_source_Image']['name']); 
			   $picname=$rand.time().'.'.strtolower($file_extension['extension']); 
			   $target_path = $target_path . $picname; 
			  
			    if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
					$movefile=move_uploaded_file($_FILES['edit_source_Image']['tmp_name'], $target_path);
				    if($movefile){
						$sourceData['sourceImage']=$picname;
			         }
				    }else{
					    $this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
						redirect($currnet_url());
					 }
			}
		}
		    $sourceData['sourceLink']=$edit_source_link;
			$sourceData['sourceName']=$edit_source_name;
			$where=array('newsID'=>$id); 
		    $sourceUp=$this->insertOrUpdate(TBL_NEWS_SOURCES,$where,$sourceData); 
		}
		
		//for images
          $article=$this->input->post('article');
		  
		  if($article == "14"){ 
		    if(!empty($_FILES['edit_thumb']['name'])){
					$target_path ='../uploads/news/'; 
					$fileTypes = array('jpeg', 'png', 'jpg','gif');
					$response['file_name'] = basename($_FILES['edit_thumb']['name']);
					$filename=basename($_FILES['edit_thumb']['name']);
					$rand=rand();
					$file_extension=pathinfo($_FILES['edit_thumb']['name']); 
				    $picname2=$rand.time().'.'.strtolower($file_extension['extension']); 
					$target_path = $target_path . $picname2; 
					if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
						$movefile=move_uploaded_file($_FILES['edit_thumb']['tmp_name'], $target_path);
						if($movefile){
							$thumb=$picname2;
						 }
					}else{
						$this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
						redirect($url);
					 }
					  $embedData['neThumbNail']=$thumb; 
				} 
			  $code=$this->input->post('edit_embed_code');
			  $embedData['neEmbedCode']=$code; 
			  $where=array('neNewsId'=>$id);
			  $this->insertOrUpdate(TBL_NEWS_EMBED_PAGES,$where,$embedData);
		  }
		 if($article == "12" || $article == "13"){ 
		     $coverdata['webUrl']=$this->input->post('edit_cover_web_url'); 
			 $where2=array('ncNewsId'=>$id);
			 $this->insertOrUpdate(TBL_NEWS_COVER_PAGES,$where2,$coverdata);
		  } 
		  if($article == "11"){ 
		    $newsPollData['npOption1']=$this->input->post('edit_option1');
			$newsPollData['npOption2']=$this->input->post('edit_option2');
			$whereP=array('npNewsId'=>$id); 
			$this->insertOrUpdate(TBL_NEWS_POLLS,$whereP,$newsPollData);
			if($_FILES['edit_poll_back_Image']['name']){
				$pollbackgrondImageData=$_FILES['edit_poll_back_Image']['name'];
				$this->Edit_polls_back_image($pollbackgrondImageData,$id);
			}
		  }
		  
		  
		  if($article == "2" || $article == "5" ){ 
                    $thumb="";
										  if(@$_FILES['edit_thumb']['name']){
											  
											  if(!empty($_FILES['edit_thumb']['name'])){
												  $target_path ='../uploads/news/'; 
												  $fileTypes = array('jpeg', 'png', 'jpg','gif');
												  $response['file_name'] = basename($_FILES['edit_thumb']['name']);
												  $filename=basename($_FILES['edit_thumb']['name']);
												  $rand=rand();
												  $file_extension=pathinfo($_FILES['edit_thumb']['name']); 
												   $picname2=$rand.time().'.'.strtolower($file_extension['extension']); 
												   $target_path = $target_path . $picname2; 
												   if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile=move_uploaded_file($_FILES['edit_thumb']['tmp_name'], $target_path);
														if($movefile){
															$thumb=$picname2;
														 }
														}else{
															$this->session->set_flashdata('Fmessage',"File formate is not supported" ); 
															redirect($url);
														 }
												} 
										  }
             		  
		             $imageName=@$_FILES['edit_news_Image']['name'];
                     $i=0;$imageData=array();
			         $fileTypes = array("gif", "mp3", "mp4", "wma");
			 if($imageName){
                 foreach($imageName as $name)
				{ 
                    $target_path ='../uploads/news/'; 
					if(!empty($name)){
						$response['file_name'] = basename($name);
						$filename=basename($name);
						$rand=rand();
						$file_extension=pathinfo($name);
						$picname1=$rand.time().'.'.strtolower($file_extension['extension']); 
						$target_path = $target_path . $picname1; 
                     if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
						$movefile=move_uploaded_file($_FILES['edit_news_Image']['tmp_name'][$i], $target_path);
						if($movefile){
							$imageData[$i]=$picname1;
						 }
						 }
					}
						$i++;
					 }
				if($imageData){
						foreach($imageData as $imgD){
                             $vdata['nvVideo']=$imgD;
							 $vdata['nvNewsID']=$id;
							 if($thumb){
								  $vdata['nvVideoThumbnail']=$thumb;
							 }
							
							 $where1=array('nvNewsID'=>$id);
							 $checkExists=$this->getAllRecords(TBL_NEWS_VIDEOS,$where1,"*");
							 if($checkExists){
								  $where1=array('nvNewsID'=>$id);
							 }else{
								  $where1=array();
							 }
							 $rees=$this->insertOrUpdate(TBL_NEWS_VIDEOS,$where1,$vdata);
								}
			   }else if($thumb){
				             $vdata['nvVideoThumbnail']=$thumb;
							 $where1=array('nvNewsID'=>$id);
							 $vdata['nvNewsID']=$id;
							 $checkExists=$this->getAllRecords(TBL_NEWS_VIDEOS,$where1,"*");
							 if($checkExists){
								  $where1=array('nvNewsID'=>$id);
							 }else{
								  $where1=array();
							 }
							 $rees=$this->insertOrUpdate(TBL_NEWS_VIDEOS,$where1,$vdata);
				   
			   }
		}
		$video_url=$this->input->post('edit_video_url');
		if($video_url){ 
			                 $vdata['nvVideo']="";
							 $vdata['nvNewsID']=$id;
							 $vdata['nvVideoUrl']=$video_url;
							 if($thumb){
								  $vdata['nvVideoThumbnail']=$thumb;
							 }
							$where1=array('nvNewsID'=>$id);
							 $checkExists=$this->getAllRecords(TBL_NEWS_VIDEOS,$where1,"*");
							 if($checkExists){
								  $where1=array('nvNewsID'=>$id);
							 }else{
								  $where1=array();
							 }
							 $rees=$this->insertOrUpdate(TBL_NEWS_VIDEOS,$where1,$vdata);
		}
			 
 
			 
			   //end
         }else{
			 
             if($article == "4" || $article == "7" ){ 
				  $fileTypes = array('gif');
			 }else{
				  $fileTypes = array('jpeg', 'png', 'jpg','gif');
			 }
		  if($_FILES['edit_news_Image']['name']){
		      $imageName=$_FILES['edit_news_Image']['name'];
			  $i=0;$imageData=array(); 
			  
	          $imagesIds=$this->input->post('imagesIds');
			  foreach($imageName as $name)
			  {$img_target_path ='../uploads/news/'; 
				 if(!empty($name)){  
					  $response['file_name'] = basename($name);
					  $filename=basename($name);
					  $rand=rand();
					   $file_extension=pathinfo($name);
					   $img_picname=$rand.time().'.'.strtolower($file_extension['extension']); 
					   $img_target_path = $img_target_path . $img_picname; 
						if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
							$movefile=move_uploaded_file($_FILES['edit_news_Image']['tmp_name'][$i], $img_target_path);
							if($movefile){
								
								 if($article == "12" || $article == "13"){
									$coverdata['backgroundImage']=$img_picname; 
									$where2=array('ncNewsId'=>$id);
									$this->insertOrUpdate(TBL_NEWS_COVER_PAGES,$where2,$coverdata);
									
								 }else if($article == "11"){  
								     
								     $pollImge=$img_picname;
									 $pollimgData['image`']=$pollImge;
									 $pollimageId=$imagesIds[$i];
									 $pollimgData['updatedAt']=date("y-m-d h:i:s");
									 $pollwhere=array('poleImageId'=>$pollimageId); 
									 $this->insertOrUpdate(TBL_NEWS_POLLS_IMAGES,$pollwhere,$pollimgData);
									 //debug($this->db->last_query()); 
								 }else{
								              $imageDat=$img_picname;
							                  $upimgData['niNewsImage']=$imageDat;
                                                $where=array('niNewsID'=>$id,'niImageID'=>$imagesIds[$i]);
                                                $haveRecord = $this->getSingleRecord(TBL_NEWS_IMAGES,$where, '*');
												if($haveRecord){ 
													 $where = array('niImageID'=>$imagesIds[$i]);
													 $this->insertOrUpdate(TBL_NEWS_IMAGES,$where,$upimgData);
												}else{
                                                 $where=array();
                                                $upimgData['niNewsImage']=$imageDat;
                                                $upimgData['niNewsID']=$id;
                                                $this->insertOrUpdate(TBL_NEWS_IMAGES,$where,$upimgData);
                                            }
								 }
							}
						 }
					}
					$i++;
			}
			
	      }
        }
	    redirect(current_url());
      	}
 	     $this->load->view('header');
		 $this->load->view('News/editNews',$data);
		 $this->load->view('scripts');
		 $this->load->view('footer');
	 }
	 function deleteNews()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('news_id'=>$id);
			$data['isDeleted'] = 1;
			
			$success = $this->insertOrUpdate(TBL_NEWS,$where,$data);
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	function deleteImage(){
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$article = $this->input->post('article');
			$newsId = $this->input->post('newsId');
			 if($article==2 || $article==5){
				$where = array('nvVideoID'=>$newsId,'nvVideoID'=>$id);
				$data['nvIsDeleted'] = 1; 
				$success = $this->insertOrUpdate(TBL_NEWS_VIDEOS,$where,$data);
			}else{
				$where = array('niNewsID'=>$newsId,'niImageID'=>$id);
				$data['niIsDeleted'] = 1;
				$success = $this->insertOrUpdate(TBL_NEWS_IMAGES,$where,$data);
			 }
			
			
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	 
	 
	
	
}