<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Settings extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
        date_default_timezone_set('Asia/Kolkata');
	}
	
  /*********************************
	 **********************************
	 * This service will useful to get blood banks.
	 * @param address
	 * @serviceType GET
	 * @responseType JSON
	 ************************************
	 ************************************/
	 function index(){
		 try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) )
			{
			 redirect(LOGOUT_URL,'refresh');
			}
			
			$settings=$this->getAllRecords(TBL_SETTINGS,$where=array(),'*');
            $data['settings']=$settings;
		    $this->load->view('header');
		    $this->load->view('Settings/settings',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	
	 function addSettings(){
		 try{
			$data=array();
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
			$where=array();
			$settings=$this->getAllRecords(TBL_SETTINGS,$where,'*');
			$data['settings']=$settings;
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_SETTINGS,$where=array('id'=>$id),'*');
				$data['details']=$details;
			}
			
				if( $this->input->post( 'addSetting' ) ){ 
					$this->load->library('form_validation');
					$this->form_validation->set_rules('name','Name','trim|required');
					$this->form_validation->set_rules('value','Value','trim|required');
					
				   if($this->form_validation->run()!=false)
					{ 
					 
						  $name=$this->input->post('name');
						  if(empty($id)){
						  $where=array('SettingName'=>$name,'id'=>$this->input->post('id'));
						  $checkExists=$this->getAllRecords(TBL_SETTINGS,$where,"*");
						  }else{
							$where=array('SettingName'=>$name);
							$checkExists=$this->checkNameExistsInEdit(TBL_SETTINGS,"*",$where,'id',$id);
						  }
						  if(count($checkExists) > 0){
								  $this->session->set_flashdata('Fmessage',"Setting already existed with this Name." ); 
								  if($id)
								   redirect(ADD_SETTINGS_URL.'/'.$id);
								  else
									redirect(ADD_SETTINGS_URL);
						  }
						   $name = trim($this->input->post('name'));
						   $value=trim($this->input->post('value'));
						   
						   $Indata['SettingName'] = $name;
						   $Indata['value'] = $value;
						if($id){
                            $where=array('id'=>$id);
							$Indata['updatedTime'] = date('y-m-d h:i:s');

						}else{
							 $Indata['createdTime'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_SETTINGS,$where,$Indata); 
                        if($result){
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(SETTINGS);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_SETTINGS_URL.'/'.$id);
							  else
								redirect(ADD_SETTINGS_URL);
						}					
					 
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_SETTINGS_URL.'/'.$id);
					  }else{redirect(ADD_SETTINGS_URL);}
						
						  
					}
				}
		    $this->load->view('header');
		    $this->load->view('Settings/addSettings',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 
}