<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */

// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Subscriptions extends Healthcontroller 
{
	public function __construct() {
	
		parent::__construct();
		$this->load->model('Commonmodel','Commonmodel');
        date_default_timezone_set('Asia/Kolkata');
	}
	
  /*********************************
	 **********************************
	 * This service will useful to get blood banks.
	 * @param address
	 * @serviceType GET
	 * @responseType JSON
	 ************************************
	 ************************************/
	 function index(){
		 try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) )
			{
			 redirect(LOGOUT_URL,'refresh');
			}
			$where = array('bm_isDeleted'=>0);
            $subscriptions = $this->getAllRecords(TBL_SUBSCRIPTION_REF,$where,'*');
		    $data['subscriptions']= $subscriptions ;
			$this->load->view('header');
		    $this->load->view('Subscriptions/subscriptions',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function addSubscription(){
		 try{
			 $data=array();
			$Role_Id=$this->session->userdata('Role_Id');
			
			if( empty($Role_Id) )
			{
			redirect(LOGOUT_URL,'refresh');
			}
			
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_SUBSCRIPTION_REF,$where=array('bm_type_ref_id'=>$id),'*');
				$data['details']=$details;
				
			}
			
				if( $this->input->post( 'AddSubscription' ) ){ 
					$this->load->library('form_validation');
					$this->form_validation->set_rules('bm_type_ref','Subscription Type','trim|required');
					$this->form_validation->set_rules('bm_amount','Amount','trim|required');
					$this->form_validation->set_rules('bm_discount','Discount','trim|required');
					$this->form_validation->set_rules('bm_access_count','Access count','trim|required');
					$this->form_validation->set_rules('bm_cloud_save','Cloud Acces count','trim|required');
					$this->form_validation->set_rules('accessTime','Access Time','trim|required');
				   if($this->form_validation->run()!=false)
					{ 
				    $bm_type_ref=$this->input->post('bm_type_ref');
					if(empty($id)){
						 $where=array('bm_type_ref'=>$bm_type_ref,'bm_isDeleted'=>0); 
						  $checkExists=$this->getSingleRecord(TBL_SUBSCRIPTION_REF,$where,'*');
						 
					}else{
						  $where=array('bm_type_ref'=>$bm_type_ref,'bm_isDeleted'=>0); 
						  $checkExists=$this->Commonmodel->checkSubscriptionExists(TBL_SUBSCRIPTION_REF,$where,$id);
						
					}
					 if($checkExists){
								 $this->session->set_flashdata('Fmessage',"Subscription already existed with this Name." ); 
								  if($id)
								   redirect(ADD_SUBSCRIPTIONS_URL.'/'.$id);
								  else
									redirect(ADD_SUBSCRIPTIONS_URL);
						  }
						
						   $bm_type_ref = trim($this->input->post('bm_type_ref'));
						   $bm_amount=trim($this->input->post('bm_amount'));
						   $bm_discount=trim($this->input->post('bm_discount'));
						   $bm_access_count=trim($this->input->post('bm_access_count'));
						   $bm_cloud_save=trim($this->input->post('bm_cloud_save'));
						   $bm_monthly_gift_card=trim($this->input->post('bm_monthly_gift_card'));
						   $bm_is_not_free=trim($this->input->post('bm_is_not_free'));
						   $accessTime=trim($this->input->post('accessTime'));
						   
						   $Idata['bm_type_ref'] = $bm_type_ref;
						   $Idata['bm_amount'] = $bm_amount;
						   $Idata['bm_discount'] = $bm_discount;
						   $Idata['bm_access_count'] = $bm_access_count;
						   $Idata['bm_cloud_save'] = $bm_cloud_save;
						   $Idata['bm_monthly_gift_card'] = $bm_monthly_gift_card;
						   $Idata['bm_is_not_free'] = $bm_is_not_free;
						   $Idata['bm_access_time'] = $accessTime;
						if($id){
							$Idata['bm_updatedAt'] = date('y-m-d h:i:s');
                            $where=array('bm_type_ref_id'=>$id);
						}else{
							 $Idata['bm_createdAt'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_SUBSCRIPTION_REF,$where,$Idata); 
                        if($result){
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(SUBSCRIPTIONS_URL);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_SUBSCRIPTIONS_URL.'/'.$id);
							  else
								redirect(ADD_SUBSCRIPTIONS_URL);
						}					
					 
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_SUBSCRIPTIONS_URL.'/'.$id);
					  }else{redirect(ADD_SUBSCRIPTIONS_URL);}
						
						  
					}
				}
		    $this->load->view('header');
		    $this->load->view('Subscriptions/addSubscription',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function deleteSubscription()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('bm_type_ref_id'=>$id);
			$data['bm_isDeleted'] = 1;
			
			$success = $this->insertOrUpdate(TBL_SUBSCRIPTION_REF,$where,$data);
			if($success)
			{
				echo json_encode(array('status'=>1,'message'=>SUCCESS));
			}
			else
			{
				echo json_encode(array('status'=>0));
			}
			die();
		}
	}
	 
	 
	
	
}