<?php 
echo "hii";die();
?>