<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Adds extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){ 
		 try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = (int)$this->uri->segment(2);
			$result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			$where = array('add_is_deleted'=>0,'add_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('add_is_deleted'=>0,'add_celebrity_id'=>$celebrityId);
			}
			if(empty($celebrityId)){
				redirect(DASHBOARD_URL);
			}
            $adds = $this->getAllRecords(TBL_ADVERTISEMENTS,$where,'*','add_id');
			if($Role_Id == 1){
			   $where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
		    $data['adds']= $adds ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			$this->load->view('header');
		    $this->load->view('adds/adds',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		} 
		
	}
	 function addAdd() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
			 if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
             $data['celebrityId'] = $celebrityId;
            if($this->input->post('addADD')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('add_title', 'Title', 'trim|required');
                $this->form_validation->set_rules('add_type', 'Type', 'trim|required');
				$this->form_validation->set_rules('add_coins', 'Coins', 'trim|required');
                if ($this->form_validation->run() != false) {  
                    $type = trim($this->input->post('add_type'));
					$Idata['add_type']=$type;
                    $add_title = trim($this->input->post('add_title'));
                    $add_content = trim($this->input->post('add_content'));
					$add_visible_for_once = trim($this->input->post('add_visible_for_once'));
					$add_location = trim($this->input->post('add_location'));
					if($add_location){
						$address = @get_lat_long($add_location);
						$lat = $address['lat'];
						$long =$address['long'];
						$Idata['add_lat'] = $lat;
						$Idata['add_lon'] = $long;
						$Idata['add_location'] = $add_location;}
						else{
							$Idata['add_lat'] = 0;
						$Idata['add_lon'] = 0;
						$Idata['add_location'] = 0;
						} 
					$add_coins = (int)trim($this->input->post('add_coins'));
					/* if($celebrityId){ */
						$Idata['add_celebrity_id'] = $celebrityId;
					/* }else{
                     $Idata['add_celebrity_id'] =$this->session->userdata('celebrityId');
					 } */
                    $Idata['add_title'] = $add_title;
                    $Idata['add_content'] = $add_content;
					$Idata['add_coins'] = $add_coins;
                    $Idata['add_created_time'] = date('Y-m-d H:i:s');
					$Idata['add_visible_once_per_user'] = ($add_visible_for_once)?$add_visible_for_once:0;
					$Idata['add_image'] = "";
					   if($type == 21){
                                if ($_FILES['add_image']['name']) {
                                     if (!empty($_FILES['add_image']['name'])) {
                                        $target_path = '../uploads/adds/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['add_image']['name']);
                                        $filename = basename($_FILES['add_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['add_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['add_image']['tmp_name'], $target_path); 
											 if ($movefile) {
												  $Idata['add_image'] = $picname2;
											 }else {
													$this->session->set_flashdata('Fmessage', "File not Moved");
													redirect(ADD_ADD_URL.'/'.$celebrityId);
											 }
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_ADD_URL.'/'.$celebrityId);
                                        }
									}
								}
					   }else if($type == 22){
						   
						       if ($_FILES['add_thumb_image']['name']) {
                                     if (!empty($_FILES['add_thumb_image']['name'])) {
                                        $target_path = '../uploads/adds/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['add_thumb_image']['name']);
                                        $filename = basename($_FILES['add_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['add_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['add_thumb_image']['tmp_name'], $target_path);
											 if ($movefile) {
												  $Idata['add_thumb_image'] = $picname2;
											 }
                                        }
									}
								}
                                    if (!empty($_FILES['add_video']['name'])) {
                                        $target_path = '../uploads/adds/';
										if($_FILES['add_video']['name']){
                                            $fileTypes = array('mp4','3gp','flv');}
										else{
									        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
										}
                                        $response['file_name'] = basename($_FILES['add_video']['name']);
                                        $filename = basename($_FILES['add_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['add_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['add_video']['tmp_name'], $target_path);
                                            if ($movefile) {
												$Idata['add_video'] = $picname;
											}
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_ADD_URL.'/'.$celebrityId);
										}
                                         }
										 else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_ADD_URL.'/'.$celebrityId);
                                       }
                                       }
                                    }
									 $where = array();
									$result = $this->insertOrUpdate(TBL_ADVERTISEMENTS, $where, $Idata);
									if($result){
										$this->session->set_flashdata('Smessage', SUCCESS);
                                               redirect(ADDS_URL.'/'.$celebrityId);
									}else {
                                               $this->session->set_flashdata('Fmessage', FAILED);
                                               redirect(ADD_ADD_URL.'/'.$celebrityId);
											}
                                } else{
					$this->session->set_flashdata('Fmessage', validation_errors()); 
					redirect(ADD_ADD_URL.'/'.$celebrityId);
				}
				} 
            $this->load->view('header');
            $this->load->view('adds/addAdd',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
            
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		 function editAdd() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $add_id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
			if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $where = array('add_id'=>$add_id);
			$details = $this->getSingleRecord(TBL_ADVERTISEMENTS, $where, '*');
			$type=@$details->add_type;
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if($this->input->post('editADD')) { 
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_add_title', 'Title', 'trim|required');
                $this->form_validation->set_rules('type', 'Type', 'trim|required');
				$this->form_validation->set_rules('edit_add_coins', 'Coins', 'trim|required');
                if ($this->form_validation->run() != false) { 
                    $type = trim($this->input->post('type'));
					$Idata['add_type']=$type;
                    $add_title = trim($this->input->post('edit_add_title'));
                    $add_content = trim($this->input->post('edit_add_content'));
					$add_visible_for_once = trim($this->input->post('edit_add_visible_for_once'));
					$add_location = trim($this->input->post('edit_add_location'));
					if($add_location){
						$address = get_lat_long($add_location);
						if($address){
						  $lat = $address['lat'];
						  $long =$address['long'];
						  $Idata['add_lat'] = $lat;
						  $Idata['add_lon'] = $long;
						}
						if($add_location && empty($address)){
							$this->session->set_flashdata('Fmessage', "Provide valid address.");
                             redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
						}
						$Idata['add_location'] = $add_location;}
						else{
							$Idata['add_lat'] = 0;
							$Idata['add_lon'] = 0;
							$Idata['add_location'] = 0;
						}
					$add_coins = trim($this->input->post('edit_add_coins'));
					/* if($celebrityId){ */
						$Idata['add_celebrity_id'] = $celebrityId;
					/* }else{
                     $Idata['add_celebrity_id'] =$this->session->userdata('celebrityId');
					 } */
                    $Idata['add_title'] = $add_title;
                    $Idata['add_content'] = $add_content;
					$Idata['add_coins'] = $add_coins;
                    $Idata['add_created_time'] = date('y-m-d h:i:s');
					$Idata['add_visible_once_per_user'] = ($add_visible_for_once)?$add_visible_for_once:0;
					//$Idata['add_image'] = "";
					   if($type == 21){
                                if ($_FILES['edit_add_image']['name']) {
                                     if (!empty($_FILES['edit_add_image']['name'])) {
                                        $target_path = '../uploads/adds/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_add_image']['name']);
                                        $filename = basename($_FILES['edit_add_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_add_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_add_image']['tmp_name'], $target_path); 
											 if ($movefile) {
												  $Idata['add_image'] = $picname2;					

											 }else {
													$this->session->set_flashdata('Fmessage', "File not Moved");
													redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
											 }
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
                                        }
									}
								}
					   }else if($type == 22){
						   
						       if ($_FILES['edit_add_thumb_image']['name']) {
                                     if (!empty($_FILES['edit_add_thumb_image']['name'])) {
                                        $target_path = '../uploads/adds/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_add_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_add_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_add_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_add_thumb_image']['tmp_name'], $target_path);
											 if ($movefile) {
												  $Idata['add_thumb_image'] = $picname2;
											 }
                                        }
									}
								}
                                    if (!empty($_FILES['edit_add_video']['name'])) {
                                        $target_path = '../uploads/adds/';
										if($_FILES['edit_add_video']['name']){
                                            $fileTypes = array('mp4','3gp','flv');}
										else{
									        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
										}
                                        $response['file_name'] = basename($_FILES['edit_add_video']['name']);
                                        $filename = basename($_FILES['edit_add_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_add_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_add_video']['tmp_name'], $target_path);
                                            if ($movefile) {
												$Idata['add_video'] = $picname;
											}
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
										}
                                         }
										 else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
                                       }
                                       }
                                    }
									$where = array('add_id'=>$add_id);
									$result = $this->insertOrUpdate(TBL_ADVERTISEMENTS,$where, $Idata);
									if($result){
										$this->session->set_flashdata('Smessage', SUCCESS);
                                               redirect(ADDS_URL.'/'.$celebrityId);
									}else {
                                               $this->session->set_flashdata('Fmessage', FAILED);
                                               redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
											}
                                } else{
					$this->session->set_flashdata('Fmessage', validation_errors()); 
					redirect(EDIT_ADD_URL.'/'.$celebrityId.'/'.$add_id);
				}
				}
			$this->load->view('header');
            $this->load->view('adds/editAdd',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
			
            
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    } 
	function deleteAdd() { 
        if ($this->input->is_ajax_request()) {
			$add_id = $this->input->post('id');
			$data['add_is_deleted'] = 1;
			$where = array('add_id'=>$add_id);
			$deleteFoundation = $this->insertOrUpdate(TBL_ADVERTISEMENTS,$where,$data);
            if($deleteFoundation){
               $this->session->set_flashdata('Smessage', "Add Delete Successfully");
            } else {
               $this->session->set_flashdata('Fmessage', "Deleting Add failed.");
            }
            die();
        }
    } 
}