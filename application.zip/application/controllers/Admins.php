<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Admins extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
		$this->load->model('Admin_model'); 
        $this->load->model('Commonmodel'); 
	}
	
	/*************
	**************
	This method will useful to login as a super admin.
	@param : Email_OR_phone
	@param : password
	return boolen
	**************
	*************/
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(ADMIN_LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			    $where = array('isDeleted'=>0,'roleId'=>2);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'roleId'=>2,'celebrityId'=>$celebrityId);
			}
            $admins = $this->getAllRecords(TBL_USERS,$where,'*');
			$where = array('c_is_deleted'=>0);
			$celebrity = $this->getAllRecords(TBL_CELEBRITY,$where,'*','userId');
		    $data['admins']= $admins ;
			$data['celebritys']=$celebrity;
			$this->load->view('header');
		    $this->load->view('admins/admins',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addAdmin(){
		 try{
			$data=array();
			$Role_Id=$this->session->userdata('Role_Id');
			if( empty($Role_Id)  )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(ADMIN_LOGOUT_URL,'refresh');
				}
			}
			$id=$this->uri->segment(3);
			if($id){
				$details=$this->getSingleRecord(TBL_USERS,$where=array('userId'=>$id),'*');
				$data['details']=$details;
				
			}
			if( $this->input->post( 'addAdmin' ) ){
					$this->load->library('form_validation');
					$this->form_validation->set_rules('name','Name','trim|required|min_length[3]');
					$this->form_validation->set_rules('phoneNumber','Phone Number','trim|required|min_length[10]|max_length[10]');
					$this->form_validation->set_rules('emailAddress','Email Address','trim|required');
				   if($this->form_validation->run()!=false)
					{ $phoneNumber=$this->input->post('phoneNumber');
				      $celebrityId = $this->input->post('celeb');
					if(empty($id)){
						  $where=array('phoneNumber'=>$phoneNumber,'isDeleted'=>0,'celebrityId'=>$celebrityId); 
						  $checkExists=$this->getSingleRecord(TBL_USERS,$where,'*');
					}else{
						 $where=array('phoneNumber'=>$phoneNumber,'isDeleted'=>0,'celebrityId'=>$celebrityId); 
						  $checkExists=$this->Commonmodel->checkUserExists(TBL_USERS,$where,$id);
					}
						  if($checkExists){
								 $this->session->set_flashdata('Fmessage',"User already existed with this Phone Number." ); 
								  if($id)
								   redirect(ADD_ADMINS_URL.'/'.$id);
								  else
									redirect(ADD_ADMINS_URL);
						  }
					
						
						$inputdata['name'] = $this->input->post('name');
				        $inputdata['phoneNumber'] = $this->input->post('phoneNumber');
				        $inputdata['emailAddress'] = $this->input->post('emailAddress');
						$inputdata['referenceCode'] = $this->generateReferenceCode(6);
						$inputdata['password'] = md5($this->input->post('password'));
						$inputdata['celebrityId'] = $this->input->post('celeb');
						$inputdata['app_id'] = $this->input->post('celeb');
				        $inputdata['isActive'] = 1;
				        $inputdata['isDeleted'] = 0;
						$inputdata['roleId'] = 2;
						if($id){
							$inputdata['updatedTime'] = date('y-m-d h:i:s');
                            $where=array('userId'=>$id);
						}else{
							 $inputdata['createdTime'] = date('y-m-d h:i:s');
							 $where=array();
						}
                        $result=$this->insertOrUpdate(TBL_USERS,$where,$inputdata);	
						$last_id = $this->db->insert_id();
                        if($result){
							$this->saveSignUpRewards($last_id);
							$this->session->set_flashdata('Smessage',SUCCESS ); 
					        redirect(ADMIN_URL);
						}else{
							$this->session->set_flashdata('Fmessage',FAILED ); 
					          if($id)
							   redirect(ADD_ADMINS_URL.'/'.$id);
							  else
								redirect(ADD_ADMINS_URL);
						}					
					}
					  else
					{
					  $this->session->set_flashdata('Fmessage', validation_errors()); 
					  if($id) {redirect(ADD_ADMINS_URL.'/'.$id);
					  }else{redirect(ADD_ADMINS_URL);}
						
						  
					}
				}
				$where = array();
				$data['celebritys'] =$this->getAllRecords(TBL_CELEBRITY,$where,'*');
		    $this->load->view('header');
		    $this->load->view('admins/addAdmin',$data);
		    $this->load->view('scripts');
			$this->load->view('footer');
		 }
			catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
	 }
	 function saveSignUpRewards($userId){
		 $data['userId']=$userId;
		 $data['refererId']=0;
		 $coins = $this->getSingleRecord(TBL_COINS_REFEREMCE, array('id'=>1),'no_of_coins');
		 $coins=$coins->no_of_coins;
		 $data['earnedPoints']=$coins;
	     $save=$this->insertOrUpdate(TBL_USER_SIGNUP_REWARDS,array(),$data);
		if($save){
		    return $coins;
		}else{
			return false;
		}
		
		
	}
	 function generateReferenceCode($length=0){
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		return strtolower($randomString);
	}
	 function login()
	{
		try{
				$this->load->helper('url');
				$data=array();
				 if($this->session->userdata('celebrityId')){
					 $id = $this->session->userdata('celebrityId');
					redirect(CELEBRITY_PAGE_URL.'/'.$id,'refresh'); 
				} 
				$urlName=trim($this->uri->segment(1));
				$urlName = str_ireplace("%20"," ",$urlName);
				$where=array('c_name'=>$urlName);
				$check=$this->getSingleRecord(TBL_CELEBRITY,$where,$select="*");
				$celebrityId = $check->c_id;
				if($check && count($check)>0){
					if($this->session->userdata('userId')){
						redirect(LOGOUT_URL.'/'.$urlName);
					}
				if (!empty($_POST)) 
				{
					$this->session->unset_userdata('Role_Id');
					$this->session->unset_userdata('User_Name');
					$this->load->library('form_validation');
					$this->form_validation->set_rules('Email_OR_phone','Email or Phone Number','trim|required');
					$this->form_validation->set_rules('password','Password','trim|required');
					if($this->form_validation->run()!=false)
					{
						$remember = trim($this->input->post('remember'));
						$this->session->set_userdata('remember',$remember);
						
						$Email_OR_phone = trim($this->input->post('Email_OR_phone'));
						$password       = trim($this->input->post('password'));
						$result = $this->Admin_model->adminlogin($Email_OR_phone, $password,$celebrityId);
						if($result)
						{ 
							$session_remember=$this->session->userdata('remember');
							if(!empty( $session_remember) && $session_remember==1){
								
							  $cookie1= array('name'   => 'superadmin_name', 'value'  => $Email_OR_phone, 'expire' => '630720000','path'=>'/'  );
							  $cookie2= array('name'   => 'superadmin_password', 'value'  => $password, 'expire' => '630720000', 'path'=>'/' );
							  $cookie3= array('name'   => 'superadmin_remember', 'value'  => $session_remember, 'expire' => '630720000', 'path'=>'/' );
							    $this->input->set_cookie($cookie1);
							    $this->input->set_cookie($cookie2);
							    $this->input->set_cookie($cookie3);
						     }else {   
							  $cookie1= array('name'   => 'superadmin_name', 'value'  => '','expire' => time()-3600, );
							  $cookie2= array('name'   => 'superadmin_password','value'  => '','expire' => time()-3600, );
							  $cookie3= array('name'   => 'superadmin_remember','value'  => '','expire' => time()-3600,);
								$this->input->set_cookie($cookie1);
								$this->input->set_cookie($cookie2);
								$this->input->set_cookie($cookie3);
						    }
							
							$this->setadmin_sessiondata($result); 
							$id = $result->celebrityId;
							$data['successMessage'] = LOGIN_SUCCESS;
							redirect(CELEBRITY_PAGE_URL.$id,'refresh'); 
						} 
						else 
						{
								 $this->session->set_flashdata('Fmessage', EMAIL_OR_PHONE_AND_PASSWORD_NOT_MATCH);
								redirect(SUPERADMIN_LOGIN_URL);
						}
					}
					else {
						$data['errorMessage']=validation_errors();
					}
					
				}
				$this->load->view('index',$data);
		}else{
			redirect(DASHBOARD_URL,'refresh');
		}
				
				
		 }catch (Exception $exception)
		 {
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		 } 	
	}
	
	function dashboard(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			$isSessionIn=$this->session->userdata('isSessionIn');
			if($Role_Id == 1 && $isSessionIn == 1){
			  redirect(DASHBOARD_URL,'refresh'); 

			}

			if( empty($Role_Id))
			{
				redirect(ADMIN_LOGOUT_URL,'refresh');
			}
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
		$celebrityId = $this->session->userdata('celebrityId');
		$where = array('isActive'=>1,'isDeleted'=>0,'roleId'=>2,'celebrityId'=>$celebrityId);
        $usersCount = $this->getAllRecords(TBL_USERS,$where,'count(*) as users_count'); 
		$data['usersCount'] = $usersCount[0];

		$where = array('isActive'=>1,'isDeleted'=>0);
        $categories = $this->getAllRecords(TBL_CATEGORIES,$where,'count(*) as categories'); 
		$data['categories'] = $categories[0]; 
		
		$where = array('isActive'=>1,'isDeleted'=>0);
        $articles = $this->getAllRecords(TBL_ARTICLES_REF,$where,'count(*) as articles'); 
		$data['articles'] = $articles[0]; 
		
		$where = array('bm_isActive'=>1,'bm_isDeleted'=>0);
        $subscriptions = $this->getAllRecords(TBL_SUBSCRIPTION_REF,$where,'count(*) as subscriptions'); 
		$data['subscriptions'] = $subscriptions[0]; 
        // debug($data);
        $this->load->view('header');
		$this->load->view('dashboard',$data);
		$this->load->view('footer');
	}
	
	
	/*******************
	********************
	This method is useful to 
	logout the user.
	********************
	********************/
	function logout(){
		    $this->session->unset_userdata('userId');
		    $this->session->unset_userdata('User_Name');
		    $this->session->unset_userdata('emailAddress');
		    $this->session->unset_userdata('Role_Id');
			$this->session->unset_userdata('celebrityId');
		    $this->session->unset_userdata('loggedIn');
		    $this->session->unset_userdata('isSessionIn');
          //  $this->session->sess_destroy();
            redirect(SITEURL);
		}
	
	/*******************
	********************
	This method is useful to set the login user details into session
	********************
	********************/
	function setadmin_sessiondata($result){ 
		if($result)
		   {
		        $userId = $result->userId;
			   	$User_Name = $result->name;
			   	$email_address = $result->emailAddress;
				$Role_Id=$result->roleId;
				$celebrityId = $result->celebrityId;
			   	$newdata = array('userId'  => $userId,
			   	                 'User_Name'  => $User_Name,
			   	                 'emailAddress' => $email_address,
								 'Role_Id' => $Role_Id,
								 'celebrityId'=>$celebrityId,
			   	                 'loggedIn' => TRUE,
								 'isSessionIn' => 1
			   			   );
						   
			   	$this->session->set_userdata($newdata);
			}
	}
	
	

	function profile(){
           $Role_Id=$this->session->userdata('Role_Id');
		   $userId=$this->session->userdata('userId');
		 if(empty($userId))
		{
			redirect(CELEBRITY_ADMIN_LOGOUT_URL,'refresh');
		}
		
		 
		 if( empty($Role_Id))
		{
			redirect(LOGOUT_URL,'refresh');
		}
		
		$where = array('userId' => $userId,'roleId'=>$Role_Id);
		$details=$this->getSingleRecord(TBL_USERS,$where);
		$data['details']=$details;
        $this->load->view('header');
		$this->load->view('adminProfile',$data);
		$this->load->view('scripts');
		$this->load->view('footer');
		
		}
		
	function updateProfile()
	 {
		$celebrityId = $this->session->userdata('celebrityId');
		 $userId = trim($this->input->post('id'));
		 $name = trim($this->input->post('name'));
		 $emailAddress = trim($this->input->post('emailAddress'));
		 $phoneNumber = trim($this->input->post('phoneNumber'));
		
		 if(!empty($name))        { $data['name']= $name;                      }
		 if(!empty($emailAddress)){ $data['emailAddress']= $emailAddress;          }
		 if(!empty($phoneNumber)) { $data['phoneNumber']= $phoneNumber;            }
		
         $data['updatedTime'] = date("Y-m-d H:i:s");
		 $where = array('userId'=>$userId);
		 $result=$this->insertOrUpdate(TBL_USERS,$where,$data);
		 if($result>0){
               $this->session->set_flashdata('Smessage', 'Your Profile Updated successfully'); 
               redirect(CELEBRITY_PAGE_URL.$celebrityId);
			
			    }else{
			   $this->session->set_flashdata('Fmessage', 'Error occured'); 
               redirect(ADMIN_PROFILE_URL);
				   
			    }
				
	 }
	 function changepassword()
	 {
		  $userId=$this->session->userdata('userId');
		  $where = array('userId' => $userId);
		  $details=$this->getSingleRecord(TBL_USERS,$where);
		  $data['details']=$details;
		  
		  $where = array('isDeleted' => 0,'isActive'=>1);
		  $this->load->view('header');
		  $this->load->view('changeAdminPassword',$data);
		  $this->load->view('scripts');
		  $this->load->view('footer');

	}
	 function updatePassword()

	{
		
		 $this->load->library('form_validation');
		 $this->form_validation->set_rules('password','Password','trim|required|min_length[6]|max_length[20]');
		 $this->form_validation->set_rules('cpassword','Confirm Password','trim|required|matches[password]');
	     if($this->form_validation->run()!=false)
		 {
		 $userId=$this->session->userdata('userId');
		 $update_password=trim($this->input->post('password'));
		 $where = array('userId' => $userId);
		 $new_password = trim($this->input->post('password'));
				 $confirm_password = trim($this->input->post('cpassword'));
				 if(!empty($new_password)){ $superadmin_data['password']=md5($new_password);    }
				 $superadmin_data['updatedTime'] = date("Y-m-d H:i:s");
				 $where = array('userId'=>$userId);
				 $result=$this->insertOrUpdate(TBL_USERS,$where,$superadmin_data);
				
				 if($result>0){
                  $this->session->set_flashdata('Smessage', PASSWORD_UPDATE_SUCCESS); 
                  redirect(ADMIN_URL);
						}else{
					 $this->session->set_flashdata('Fmessage', 'Error occured'); 
                     redirect(ADMIN_CHANGEPASSWORD_URL);
						}
			 }
			
		else
		{
            $this->session->set_flashdata('Fmessage', validation_errors()); 
                     redirect(ADMIN_CHANGEPASSWORD_URL);
			
		}
		echo json_encode($message); die();
		 
	}
	
	 	function deleteAdmin()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id');
			$where = array('userId'=>$id);
			$data['isDeleted'] = 1;
			$data['updatedTime']= date('y-m-d h:i:s');
			$success = $this->insertOrUpdate(TBL_USERS,$where,$data);
			if($success)
			{
				 $this->session->set_flashdata('Smessage', "Admin Delete Successfully");
			}
			else
			{
				 $this->session->set_flashdata('Smessage', "Admin Delete Failed");
			}
			die();
		}
	}
}