<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Foundations extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		 try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = $this->uri->segment(3);
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			$where = array('f_is_deleted'=>0,'f_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('f_is_deleted'=>0,'f_celebrity_id'=>$celebrityId);
			}
            $foundations = $this->getAllRecords(TBL_FOUNDATIONS,$where,'*');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
		    $data['foundations']= $foundations ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('foundations/foundation',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		} 
		
	}
	 function addFoundation() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
            $data['celebrityId'] = $celebrityId;
            
            if ($this->input->post('addFoundation')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('foundations_title', 'Foundations Title', 'trim|required');
                $this->form_validation->set_rules('foundations_content', 'Foundations Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $type = trim($this->input->post('type'));
					$Idata['f_article_type']=$type;
                    $foundations_title = trim($this->input->post('foundations_title'));
                    $foundations_content = trim($this->input->post('foundations_content'));
					if($celebrityId){
						$Idata['f_celebrity_id'] = $celebrityId;
					}
					else{
                   $Idata['f_celebrity_id'] =$this->session->userdata('celebrityId');}

                    $Idata['f_title'] = $foundations_title;
                    $Idata['f_content'] = $foundations_content;
                        $isPremiun = 0;
                    $Idata['f_created_time'] = date('y-m-d h:i:s');
					$Idata['f_image'] = "";
                                if ($_FILES['foundation_image_video']['name']) {
                                     if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/foundations/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['f_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
                                        }}
                                    if (!empty($_FILES['foundation_image_video']['name'])) {
                                        $target_path = '../uploads/foundations/';
										if($_FILES['thumb_image']['name']){
                                            $fileTypes = array('mp4','3gp','flv');}
										else{
									        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
										}
                                        $response['file_name'] = basename($_FILES['foundation_image_video']['name']);
                                        $filename = basename($_FILES['foundation_image_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['foundation_image_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['foundation_image_video']['tmp_name'], $target_path);
                                            if ($movefile) {
												if($type == 14){
												  $Tdata['t_post_type'] = '14';
                                                  $Idata['f_image'] = $picname;
												}else{
												    $Tdata['t_post_type'] = '17';
                                                    $Idata['f_video'] = $picname;
												}
												$where = array();
												$result = $this->insertOrUpdate(TBL_FOUNDATIONS, $where, $Idata);
												$last_id = $this->db->insert_id();
												if($result){
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(FOUNDATION_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
											}
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
                                        }
                                    }
                                }
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_FOUNDATION_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('foundations/addFoundation',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editFoundation() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $foundation_id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
            $where = array('f_id'=>$foundation_id);
			$details = $this->getSingleRecord(TBL_FOUNDATIONS, $where, '*');
			$type=@$details->f_article_type;
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editFoundation')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_foundation_title', 'Foundations Title', 'trim|required');
                $this->form_validation->set_rules('edit_foundation_content', 'Foundations Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                   // $type = trim($this->input->post('type'));
                    $foundations_title = trim($this->input->post('edit_foundation_title'));
					$foundation_id = trim($this->input->post('edit_foundation_id'));
                   
                    $foundations_content = trim($this->input->post('edit_foundation_content'));
					if($celebrityId){
						$Idata['f_celebrity_id'] = $celebrityId;
					}
					else{
                    $Idata['f_celebrity_id'] =$this->session->userdata('celebrityId');}
 
                    $Idata['f_title'] = $foundations_title;
                    $Idata['f_content'] = $foundations_content;
					$Idata['f_updated_time'] = date('Y-m-d H:i:s');
                        $isPremiun = 0;
                                    if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/foundations/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['f_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
                                        }}
                                    if (!empty($_FILES['edit_foundation_image_video']['name'])) {
                                        $target_path = '../uploads/foundations/';
										
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif','mp4','3gp','flv');
                                        $response['file_name'] = basename($_FILES['edit_foundation_image_video']['name']);
                                        $filename = basename($_FILES['edit_foundation_image_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_foundation_image_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_foundation_image_video']['tmp_name'], $target_path);
                                            if ($movefile) {
												if($type == 14){
                                                   $Idata['f_image'] = $picname;
												 }else{
                                                   $Idata['f_video'] = $picname;
												 }
											}else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
											}
										} else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
                                        }
									}	
												$where = array('f_id'=>$foundation_id);
												$haveRecord = $this->getSingleRecord(TBL_FOUNDATIONS,$where,'*');
												if($haveRecord){
												$where = array('f_id'=>$foundation_id);
												$result = $this->insertOrUpdate(TBL_FOUNDATIONS, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_FOUNDATIONS, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
                }
            }
			
            $this->load->view('header');
            $this->load->view('foundations/editFoundation',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteFoundation() {
        if ($this->input->is_ajax_request()) {
            $image = $this->input->post('image');
			//$imagePath = '../uploads/foundations/'.$image;
			$foundation_id = $this->input->post('id');
			$data['f_is_deleted'] = 1;
			$where = array('f_id'=>$foundation_id);
			$deleteFoundation = $this->insertOrUpdate(TBL_FOUNDATIONS,$where,$data);
            if($deleteFoundation){
            //unlink($imagePath);
               $this->session->set_flashdata('Smessage', "Foundation Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Foundation Delete Not Successfully");
            }
            die();
        }
    } 
}