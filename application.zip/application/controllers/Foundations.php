<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Foundations extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = (int)$this->uri->segment(2);
			$result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			$where = array('f_is_deleted'=>0,'f_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('f_is_deleted'=>0,'f_celebrity_id'=>$celebrityId);
			}
			if(empty($celebrityId)){
				redirect(DASHBOARD_URL);
			}
            $foundations = $this->getAllRecords(TBL_FOUNDATIONS,$where,'*','f_id');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
		    $data['foundations']= $foundations ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('foundations/foundation',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addFoundation() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
			 if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $data['celebrityId'] = $celebrityId;
            
            if ($this->input->post('addFoundation')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('foundation_title', 'Foundations Title', 'trim|required');
                $this->form_validation->set_rules('foundation_content', 'Foundations Content', 'trim|required');
				$this->form_validation->set_rules('type', 'Article Type', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $foundations_title = trim($this->input->post('foundation_title'));
                    $foundations_content = trim($this->input->post('foundation_content'));
					$type = $this->input->post('type');
					$Idata['f_article_type'] = $type;
					$foundation_video = trim($this->input->post('foundation_video'));
					if($foundation_video){
						$Idata['f_video'] = $foundation_video;
					}
					else{
						$Idata['f_video'] = "";
					}
					/* if($celebrityId){ */
						$Idata['f_celebrity_id'] = $celebrityId;
					/* }
					else{
                   $Idata['f_celebrity_id'] =$this->session->userdata('celebrityId');} */

                    $Idata['f_title'] = $foundations_title;
                    $Idata['f_content'] = $foundations_content;
                        $isPremiun = 0;
                    $Idata['f_created_time'] = date('y-m-d h:i:s');
					$Idata['f_image'] = "";
				if (($_FILES['foundation_image']['name']) || ($_FILES['thumb_image']['name'])) {
                                     if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/foundations/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['f_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
                                        }
									}
										$where = array();
										$res = $this->insertOrUpdate(TBL_FOUNDATIONS,$where,$Idata);
										$last_id = $this->db->insert_id();
										if($res){
										$imageName = @$_FILES['foundation_image']['name'];
					                    if ($imageName) {
											$i = 0;
											$imageData = array();
											$fileTypes = array('jpeg', 'png', 'jpg', 'gif');
											foreach ($imageName as $name) {
												$target_path = '../uploads/foundations/';
												if (!empty($name)) {
													$response['file_name'] = basename($name);
													$filename = basename($name);
													$rand = rand();
													$file_extension = pathinfo($name);
													$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
													$target_path = $target_path . $picname1;
													if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
														$movefile = move_uploaded_file($_FILES['foundation_image']['tmp_name'][$i], $target_path);
														if ($movefile) {
													$upimgData['f_foundation_image'] = $picname1;
													$upimgData['f_foundation_id'] = $last_id;
													$upimgData['f_created_time'] = date('Y-m-d H:i:s');
                                             
													$where = array();
													$result = $this->insertOrUpdate(TBL_FOUNDATION_IMAGES, $where, $upimgData);
														}
													}
												}
												$i++;
										}}
										           /**** to send push noti ***/
													$Tdata['t_post_type'] = $type;
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$Tdata['t_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$foundations_title);
													}
													/**** to send push noti on edit ***/
													$this->session->set_flashdata('Smessage', " Successfully");
												    redirect(FOUNDATION_URL.'/'.$celebrityId);
				                                  }}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_FOUNDATION_URL.'/'.$celebrityId);
                }
            }
            $this->load->view('header');
            $this->load->view('foundations/addFoundation',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editFoundation() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $foundation_id= (int)$this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
			if($Role_Id == 2){
				$celebrityId = $this->session->userdata('celebrityId');
			}
			$result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $where = array('f_id'=>$foundation_id);
			$details = $this->getSingleRecord(TBL_FOUNDATIONS, $where, '*');
			$where = array('f_foundation_id'=>$foundation_id,'f_foundation_is_deleted'=>0);
		    $data['foundationImages'] = $this->getAllRecords(TBL_FOUNDATION_IMAGES,$where,'*','f_img_id');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
            if ($this->input->post('editfoundation')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_foundation_title', 'Foundations Title', 'trim|required');
                $this->form_validation->set_rules('edit_foundation_content', 'Foundations Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $foundations_title = trim($this->input->post('edit_foundation_title'));
					$foundation_id = trim($this->input->post('edit_foundation_id'));
                    $fImage_id = $this->input->post('fImageID');
                    $foundations_content = trim($this->input->post('edit_foundation_content'));
					$foundation_video = trim($this->input->post('edit_foundation_video'));
					if($foundation_video){
						$Idata['f_video'] = $foundation_video;
					}
					else{
						$Idata['f_video'] = "";
					}
					/* if($celebrityId){ */
						$Idata['f_celebrity_id'] = $celebrityId;
					/* }
					else{
                    $Idata['f_celebrity_id'] =$this->session->userdata('celebrityId');} */
                    $Idata['f_title'] = $foundations_title;
                    $Idata['f_content'] = $foundations_content;
					$Idata['f_updated_time'] = date('y-m-d H:i:s');
                                    if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/foundations/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['f_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
                                        }}
												$where = array('f_id'=>$foundation_id);
												$result = $this->insertOrUpdate(TBL_FOUNDATIONS, $where, $Idata);
												if($result){
													  $where = array('f_id'=>$foundation_id);
			                                          $details = $this->getSingleRecord(TBL_FOUNDATIONS, $where, '*');
													$type=@$details->f_article_type;
													/**** to send push noti on edit ***/
													$Tdata['t_post_type'] = $type;
													$Tdata['t_post_id'] = $foundation_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$Tdata['t_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$foundations_title);
													}
													/**** to send push noti on edit ***/
													$imageName = @$_FILES['edit_foundation_image']['name'];
													if ($imageName || !$imageName) {
														$i = 0;
														$imageData = array();
														$fileTypes = array('jpeg', 'png', 'jpg', 'gif');
														foreach ($imageName as $name) {
															$target_path = '../uploads/foundations/';
															if (!empty($name)) {
																$response['file_name'] = basename($name);
																$filename = basename($name);
																$rand = rand();
																$file_extension = pathinfo($name);
																$picname1 = $rand . time() . '.' . strtolower($file_extension['extension']);
																$target_path = $target_path . $picname1;
																if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
																	$movefile = move_uploaded_file($_FILES['edit_foundation_image']['tmp_name'][$i],$target_path);
																if ($movefile) {
																$upimgData['f_foundation_image'] = $picname1;
																$upimgData['f_foundation_id'] = $foundation_id;
																$upimgData['f_updated_time'] = date('Y-m-d H:i:s');
																$where = array('f_foundation_id'=>$foundation_id,'f_img_id'=>$fImage_id[$i]);
																$haveRecord = $this->getAllRecords(TBL_FOUNDATION_IMAGES,$where,'*');
																if($haveRecord){
																$where = array('f_img_id'=>$fImage_id[$i]);
																$res = $this->insertOrUpdate(TBL_FOUNDATION_IMAGES,$where,$upimgData);
																}else{
																$where = array();
																$res = $this->insertOrUpdate(TBL_FOUNDATION_IMAGES,$where,$upimgData);}
																	}
																	else {
														$this->session->set_flashdata('Fmessage', "File not Moved");
														redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$socialService_id);
														}
																}
																else {
														$this->session->set_flashdata('Fmessage', "File formate is not supported");
														redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$socialService_id);
																 }
															}
															$i++;
													}
												}
													  $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(FOUNDATION_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_FOUNDATION_URL.'/'.$celebrityId.'/'.$foundation_id);
                }
            }
			
            $this->load->view('header');
            $this->load->view('foundations/editFoundation',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	
	function deleteFoundation() {
        if ($this->input->is_ajax_request()) {
			$foundation_id = $this->input->post('id');
			$data['f_is_deleted'] = 1;
			$where = array('f_id'=>$foundation_id);
			$deleteFoundation = $this->insertOrUpdate(TBL_FOUNDATIONS,$where,$data);
            if($deleteFoundation){
               $this->session->set_flashdata('Smessage', "Foundation Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Foundation Delete Not Successfully");
            }
            die();
        }
    }
}