<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Galery extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	  function images() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = $this->uri->segment(3);
		if($celebrityId){
			$where = array('isDeleted' => 0,'news_article_type'=> 3,'celebrityId'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'celebrityId'=>$celebrityId,'news_article_type'=>3);
			}
		$newsTitles = $this->getAllRecords(TBL_NEWS,$where,'news_title');
		$data['titles'] =$newsTitles;
		
		$where =array('isDeleted'=>0,'news_article_type'=> 2);
		$newsTitles = $this->getAllRecords(TBL_NEWS,$where,'news_title,news_id');
		$data['videotitles'] =$newsTitles;
		$data['celebrityId'] = $celebrityId;
        $this->load->view('header');
		$this->load->view('galery/image',$data);
		$this->load->view('footer');
		
	}  
	function imagesData(){
		$title =str_ireplace("%20"," ",$this->uri->segment(3));
		$celebrityId = $this->uri->segment(4);
		$newsId = $this->uri->segment(5);
		$where = array('news_title'=>$title,'news_id'=>$newsId);
		$newscontent = $this->getSingleRecord(TBL_NEWS,$where,'news_content');
		$data['content'] =$newscontent;
		$data['newsId'] =$newsId;
		$data['celebrityId'] =$celebrityId;
		$data['title'] = $title;
	    $this->load->view('header');
		$this->load->view('galery/imagedata',$data);
		$this->load->view('footer');
	}
	function videosData(){
		$data['title'] =str_ireplace("%20"," ",$this->uri->segment(3));
		$id = $this->uri->segment(5);
		
		$where = array('nvNewsID'=>$id,'nvIsDeleted'=>0);
		$result = $this->getAllRecords(TBL_NEWS_VIDEOS,$where,'*');
		$data['videoDetails'] = $result;
	    $this->load->view('header');
		$this->load->view('galery/videodata',$data);
		$this->load->view('footer');
	}
	function deleteImage() {
        if ($this->input->is_ajax_request()) {
            $imagePath = $this->input->post('path');
			$newsId = $this->input->post('newsId');
            if(file_exists($imagePath)){
            unlink($imagePath);
               $this->session->set_flashdata('Smessage', "Image Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Image Delete Not Successfully Please Provide Valid Path");
            }
            die();
        }
    }
    function deleteVideo() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
			$data['nvIsDeleted'] = 1;
			$where = array('nvVideoID'=>$id);
			$result = $this->insertOrUpdate(TBL_NEWS_VIDEOS,$where,$data);
			if($result){
               $this->session->set_flashdata('Smessage', "Video Delete Successfully");
			}else {
             $this->session->set_flashdata('Fmessage', "Video Delete Not Successfully Please Provide Valid Path");
            }
            die();
        }
    
}
}