<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Galery extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	//START
	  function images() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = $this->uri->segment(3);
		if($celebrityId){
			$imageTitles = $this->Commonmodel->imageTitles($celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$imageTitles = $this->Commonmodel->imageTitles($celebrityId);
			}
		$data['titles'] =$imageTitles;
		if($celebrityId){
			$videoTitles = $this->Commonmodel->videoTitles($celebrityId);
		}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$videoTitles = $this->Commonmodel->videoTitles($celebrityId);
			}
		$data['videotitles'] =$videoTitles;
		$data['celebrityId'] = $celebrityId;
        $this->load->view('header');
		$this->load->view('galery/image',$data);
		$this->load->view('footer');
		
	}  
	
	function imagesData(){
		$celebrityId = $this->uri->segment(3);
		$newsId = $this->uri->segment(4);
		$where = array('news_id'=>$newsId);
		$news = $this->getSingleRecord(TBL_NEWS,$where,'*');
		$data['newsDetails'] = $news;
		$where = array('niNewsID'=>$newsId,'niIsDeleted'=>0);
		$data['newsImages'] = $this->getAllRecords(TBL_NEWS_IMAGES,$where,'*');
		$data['celebrityId'] =$celebrityId;
	    $this->load->view('header');
		$this->load->view('galery/imagedata',$data);
		$this->load->view('footer');
	}
	function videosData(){
		$id = $this->uri->segment(4);
		$data['celebrityId'] = $this->uri->segment(3);
		$where = array('news_id'=>$id);
		$news = $this->getSingleRecord(TBL_NEWS,$where,'*');
		$data['newsDetails'] = $news;
		$where = array('nvNewsID'=>$id,'nvIsDeleted'=>0);
		$result = $this->getAllRecords(TBL_NEWS_VIDEOS,$where,'*');
		$data['videoDetails'] = $result;
	    $this->load->view('header');
		$this->load->view('galery/videodata',$data);
		$this->load->view('footer');
	}
	// END
	function deleteImage() {
        if ($this->input->is_ajax_request()) {
			$newsId = $this->input->post('newsId');
			$imageId = $this->input->post('imageId');
			$where = array('niNewsID'=>$newsId,'niImageID'=>$imageId);
			$data['niIsDeleted'] = 1;
			$result = $this->insertOrUpdate(TBL_NEWS_IMAGES,$where,$data);
			if($result){
               $this->session->set_flashdata('Smessage', "Image Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Image Delete Not Successfully Please Provide Valid Path");
            }
            die();
        }
    }
    function deleteVideo() {
        if ($this->input->is_ajax_request()) {
            $id = $this->input->post('id');
			$data['nvIsDeleted'] = 1;
			$where = array('nvVideoID'=>$id);
			$result = $this->insertOrUpdate(TBL_NEWS_VIDEOS,$where,$data);
			if($result){
               $this->session->set_flashdata('Smessage', "Video Delete Successfully");
			}else {
             $this->session->set_flashdata('Fmessage', "Video Delete Not Successfully Please Provide Valid Path");
            }
            die();
        }
    
}
}