<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Openion extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	  
	  function index() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = (int)$this->uri->segment(2);
		if($Role_Id==1){
			$where = array('isDeleted' => 0,'celebrityId'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'celebrityId'=>$celebrityId);
			}
			if(empty($celebrityId)){
				redirect(DASHBOARD_URL);
			}
		$openions = $this->getAllRecords(TBL_OPENION_POLLS,$where,'*','poll_id');
	     if($openions){
			 $i=0;
			 foreach($openions as $openion){
		$where = array('isActive'=>1,'isDeleted'=>0,'pollingOption'=>1,'pollId'=>$openion->poll_id);
        $yes = $this->getAllRecords(TBL_USER_POLLING_RESULTS,$where,'count(*) as yes'); 
		$where = array('isActive'=>1,'isDeleted'=>0,'pollingOption'=>2,'pollId'=>$openion->poll_id);
        $no = $this->getAllRecords(TBL_USER_POLLING_RESULTS,$where,'count(*) as n'); 
		$where = array('isActive'=>1,'isDeleted'=>0,'pollingOption'=>3,'pollId'=>$openion->poll_id);
        $mayBe = $this->getAllRecords(TBL_USER_POLLING_RESULTS,$where,'count(*) as maybe'); 
		$openion->yes=$yes;
		$openion->n=$no;
		$openion->maybe=$mayBe;
		$i++;
		 }
		 }
		$data['openions'] =$openions;
		$data['celebrityId'] = $celebrityId;//debug($data);
        $this->load->view('header');
		$this->load->view('openions/openion',$data);
		$this->load->view('footer');
		
	}  
	function addOpenion() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            $celebrityId = $this->uri->segment(3); 
			if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $data['celebrityId'] = $celebrityId;
            if ($this->input->post('addOpenion')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('question', 'question', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $question = trim($this->input->post('question'));
					/* if($celebrityId){ */
						$Idata['celebrityId'] = $celebrityId;
					/* }else{
						$Idata['celebrityId'] =$this->session->userdata('celebrityId');} */
						$Idata['question'] = $question;
						$isPremiun = 0;
						$Idata['createdTime'] = date('y-m-d h:i:s');
						$where = array();
						$result = $this->insertOrUpdate(TBL_OPENION_POLLS,$where,$Idata);
						$last_id = $this->db->insert_id();
						if($result){
							/* save into timeline table */
							$Tdata['t_post_type'] = '23';
							$Tdata['t_post_id'] = $last_id;
							$Tdata['t_celebrity_id'] = $celebrityId;
							$Tdata['t_created_time'] = date('Y-m-d H:i:s');
						    $where = array();
							$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata); 
							$timeline_id = $this->db->insert_id();
							if($timeline_id){
							  $this->sendPushNotification($timeline_id,$celebrityId,'New openion poll added.');
							}
							/**** end send push noti ***/
						$this->session->set_flashdata('Smessage', SUCCESS);
                       redirect(OPENION_POLLS_URL.'/'.$celebrityId);
						}
						else {
                         $this->session->set_flashdata('Fmessage', FAILED);
                         redirect(ADD_OPENION_POLLS_URL.'/'.$celebrityId);
						}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_OPENION_POLLS_URL.'/'.$celebrityId);
                }
            }
            $this->load->view('header');
            $this->load->view('openions/addOpenion',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        }catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function editOpenion() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            $celebrityId = $this->uri->segment(3); 
			if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $data['celebrityId'] = $celebrityId;
			$id = $this->uri->segment(4); 
			$where = array('poll_id'=>$id);
			$data['openion'] = $this->getSingleRecord(TBL_OPENION_POLLS,$where,'*');
            if ($this->input->post('editOpenion')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_question', 'question', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $question = trim($this->input->post('edit_question'));
					/* if($celebrityId){ */
						$Idata['celebrityId'] = $celebrityId;
					/* }else{
						$celebrityId=$this->session->userdata('celebrityId');
						$Idata['celebrityId'] =$this->session->userdata('celebrityId');
				    } */
						$Idata['question'] = $question;
						$isPremiun = 0;
						$Idata['updatedTime'] = date('y-m-d h:i:s');
						$where = array('poll_id'=>$id);
						$result = $this->insertOrUpdate(TBL_OPENION_POLLS,$where,$Idata);
						if($result){
							/* save into timeline table */
							$Tdata['t_post_type'] = '23';
							$Tdata['t_post_id'] = $id;
							$Tdata['t_celebrity_id'] = $celebrityId;
							$Tdata['t_created_time'] = date('Y-m-d H:i:s');
						    $where = array();
							$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata); 
							$timeline_id = $this->db->insert_id();
							if($timeline_id){
							  $this->sendPushNotification($timeline_id,$celebrityId,'Modification in openion poll.');
							}
							/**** end send push noti ***/
						 $this->session->set_flashdata('Smessage', SUCCESS);
                         redirect(OPENION_POLLS_URL.'/'.$celebrityId);
						}
						else {
                         $this->session->set_flashdata('Fmessage', FAILED);
                         redirect(EDIT_OPENION_POLLS_URL.'/'.$celebrityId);
						}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_OPENION_POLLS_URL.'/'.$celebrityId);
                }
            }
            $this->load->view('header');
            $this->load->view('openions/editOpenion',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        }catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteOpenion() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			$data['isDeleted'] = 1;
			$where = array('poll_id'=>$id);
			$deleteopenions = $this->insertOrUpdate(TBL_OPENION_POLLS,$where,$data);
            if($deleteopenions){
               $this->session->set_flashdata('Smessage', SUCCESS);
            } else {
             $this->session->set_flashdata('Fmessage', FAILED);
            }
            die();
        }
    }
}