<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class SocialService extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = $this->uri->segment(3);
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			$where = array('sv_is_deleted'=>0,'sv_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('sv_is_deleted'=>0,'sv_celebrity_id'=>$celebrityId);
			}
            $socialServices = $this->getAllRecords(TBL_SOCIAL_SERVICE,$where,'*');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
		    $data['socialServices']= $socialServices ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('socialService/socialService',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addSocialService() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
            $data['celebrityId'] = $celebrityId;
            
            if ($this->input->post('addSocialService')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('socialService_title', 'SocialService Title', 'trim|required');
                $this->form_validation->set_rules('socialService_content', 'SocialService Content', 'trim|required');
				$this->form_validation->set_rules('social_service_place', 'SocialService Place', 'trim|required');
				$this->form_validation->set_rules('social_service_date', 'SocialService Date', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $type = trim($this->input->post('type'));
					$Idata['sv_article_type'] = $type;
                    $socialService_title = trim($this->input->post('socialService_title'));
                    $socialService_content = trim($this->input->post('socialService_content'));
					$social_service_place = trim($this->input->post('social_service_place'));
					$social_service_date = trim($this->input->post('social_service_date'));
					if($celebrityId){
						$Idata['sv_celebrity_id'] = $celebrityId;
					}
					else{
                    $Idata['sv_celebrity_id'] =$this->session->userdata('celebrityId');}
                    $Idata['sv_title'] = $socialService_title;
                    $Idata['sv_content'] = $socialService_content;
					$Idata['sv_place'] = $social_service_place;
					$Idata['sv_date'] = $social_service_date;
                    $isPremiun = 0;
                    $Idata['sv_created_time'] = date('y-m-d h:i:s');
					$Idata['sv_image'] = "";
                                if (($_FILES['SocialService_image']['name']) || ($_FILES['SocialService_video']['name'])) {
                                     if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/socialServices/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['sv_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
                                        }}
                                    if (!empty($_FILES['SocialService_image']['name'])) {
                                        $target_path = '../uploads/socialServices/';
										$fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['SocialService_image']['name']);
                                        $filename = basename($_FILES['SocialService_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['SocialService_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['SocialService_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['sv_image'] = $picname;
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
                                        }
                                    }
									 if (!empty($_FILES['SocialService_video']['name'])) {
                                        $target_path = '../uploads/socialServices/';
										$fileTypes = array('mp4', 'flv', '3gp');
                                        $response['file_name'] = basename($_FILES['SocialService_video']['name']);
                                        $filename = basename($_FILES['SocialService_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['SocialService_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['SocialService_video']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['sv_video'] = $picname;
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
                                        }
                                    }
									$where = array();
												$result = $this->insertOrUpdate(TBL_SOCIAL_SERVICE, $where, $Idata);
												$last_id = $this->db->insert_id();
												if($result){
													if($type == 15){
													$Tdata['t_post_type'] = '15';
													}else{
													$Tdata['t_post_type'] = '18';

													}
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(SOCIAL_SERVICE_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_SOCIAL_SERVICE_URL.'/'.$celebrityId);
											}
                                }
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_SOCIAL_SERVICE_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('socialService/addSocialService',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editSocialService() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $socialService_id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
            $where = array('sv_id'=>$socialService_id);
			$details = $this->getSingleRecord(TBL_SOCIAL_SERVICE, $where, '*');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editSocialService')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_SocialService_title', 'SocialService Title', 'trim|required');
                $this->form_validation->set_rules('edit_SocialService_content', 'SocialService Content', 'trim|required');
				$this->form_validation->set_rules('edit_social_service_place', 'SocialService Place', 'trim|required');
				$this->form_validation->set_rules('edit_social_service_date', 'SocialService Date', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $socialService_title = trim($this->input->post('edit_SocialService_title'));
					$socialService_id = trim($this->input->post('edit_foundation_id'));
                    $socialService_content = trim($this->input->post('edit_SocialService_content'));
					$social_service_place = trim($this->input->post('edit_social_service_place'));
					$social_service_date = trim($this->input->post('edit_social_service_date'));
					if($celebrityId){
						$Idata['sv_celebrity_id'] = $celebrityId;
					}
					else{
                   $Idata['sv_celebrity_id'] =$this->session->userdata('celebrityId');}

                    $Idata['sv_title'] = $socialService_title;
                    $Idata['sv_content'] = $socialService_content;
					$Idata['sv_updated_time'] = date('y-m-d H:i:s');
                        $isPremiun = 0;
                                     if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/socialServices/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname2 = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname2;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
									 if ($movefile) {
										  $Idata['sv_thumb_image'] = $picname2;
									 }else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
                                        }
										}
                                    if (!empty($_FILES['edit_SocialService_image']['name'])) {
                                        $target_path = '../uploads/socialServices/';
										$fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_SocialService_image']['name']);
                                        $filename = basename($_FILES['edit_SocialService_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_SocialService_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_SocialService_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['sv_image'] = $picname;//print_r($Idata);die();
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
                                        }
                                    }
									 if (!empty($_FILES['edit_SocialService_video']['name'])) {
                                        $target_path = '../uploads/socialServices/';
										$fileTypes = array('mp4', 'flv', '3gp');
                                        $response['file_name'] = basename($_FILES['edit_SocialService_video']['name']);
                                        $filename = basename($_FILES['edit_SocialService_video']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_SocialService_video']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_SocialService_video']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['sv_video'] = $picname;
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
                                        }
									 }
												$where = array('sv_id'=>$socialService_id);
												$haveRecord = $this->getSingleRecord(TBL_SOCIAL_SERVICE,$where,'*');
												if($haveRecord){
												$where = array('sv_id'=>$socialService_id);
												$result = $this->insertOrUpdate(TBL_SOCIAL_SERVICE, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_SOCIAL_SERVICE, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
											}
				}else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_SOCIAL_SERVICE_URL.'/'.$celebrityId.'/'.$socialService_id);
                }
			}
            $this->load->view('header');
            $this->load->view('socialService/editSocialService',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteSocialService() {
        if ($this->input->is_ajax_request()) {
			$socialService_id = $this->input->post('id');
			$data['sv_is_deleted'] = 1;
			$where = array('sv_id'=>$socialService_id);
			$deleteSocialService = $this->insertOrUpdate(TBL_SOCIAL_SERVICE,$where,$data);
            if($deleteSocialService){
               $this->session->set_flashdata('Smessage', "Foundation Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Foundation Delete Not Successfully");
            }
            die();
        }
    }
}