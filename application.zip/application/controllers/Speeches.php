<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header("access-control-allow-origin: *");
class Speeches extends Healthcontroller {

	function __construct()
	{
		parent::__construct();
		
		$this->load->helper('url');
        $this->load->model('Commonmodel'); 
	}
	
	function index(){
		try{
			$Role_Id=$this->session->userdata('Role_Id');
			$celebrityId = (int)$this->uri->segment(2);
			$result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
			if( empty($Role_Id) && empty($agentId) )
			{
				if($this->session->userdata('isAgentIn')){
					redirect(AGENT_LOGOUT_URL,'refresh');
				}else{
					redirect(LOGOUT_URL,'refresh');
				}
			}
			
			if($Role_Id == 1){
			    $where = array('s_is_deleted'=>0,'s_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('s_is_deleted'=>0,'s_celebrity_id'=>$celebrityId);
			}
			if(empty($celebrityId)){
				redirect(DASHBOARD_URL);
			}
            $speeches = $this->getAllRecords(TBL_SPEECHES,$where,'*','s_id');
			if($Role_Id == 1){
			$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('c_is_deleted'=>0,'c_id'=>$celebrityId);
			}
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY,$where,'*');
		    $data['speeches']= $speeches ;
			$data['cele_Name']=@$celebrity->c_name;
			$data['celebrityId']=@$celebrityId;
			
			$this->load->view('header');
		    $this->load->view('speeches/speech',$data);
			$this->load->view('footer');
		}catch (Exception $exception)
		{
			$data['error']=$exception->getMessage();
			$this->logExceptionMessage($exception);					
		}
		
	}
	function addSpeech() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
             $celebrityId = $this->uri->segment(3);
			 if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $data['celebrityId'] = $celebrityId;
            
            if ($this->input->post('addSpeech')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('speach_title', 'Speech Title', 'trim|required');
                $this->form_validation->set_rules('speach_content', 'Speech Content', 'trim|required');
				$this->form_validation->set_rules('speach_video', 'Speech Video', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $speach_title = trim($this->input->post('speach_title'));
                    $speach_content = trim($this->input->post('speach_content'));
					$speach_video = trim($this->input->post('speach_video'));
					/* if($celebrityId){ */
						$Idata['s_celebrity_id'] = $celebrityId;
					/* }
					elseif($Role_Id == 2){
                   $Idata['s_celebrity_id'] =$this->session->userdata('celebrityId');} */
                    $Idata['s_title'] = $speach_title;
                    $Idata['s_content'] = $speach_content;
					$Idata['s_video'] = $speach_video;
                        $isPremiun = 0;
                    $Idata['s_created_time'] = date('y-m-d h:i:s');
                                if ($_FILES['thumb_image']['name']) {

                                    if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/speeches/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['s_thumbnail'] = $picname;
												$where = array();
												$result = $this->insertOrUpdate(TBL_SPEECHES, $where, $Idata);
												$last_id = $this->db->insert_id();
												if($result){
													/**** to send push noti ***/
													$Tdata['t_post_type'] = '13';
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$Tdata['t_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$speach_title);
													}
													/**** end send push noti ***/
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(SPEECHES_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_SPEECHES_URL.'/'.$celebrityId);
											}
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_SPEECHES_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_SPEECHES_URL.'/'.$celebrityId);
                                        }
                                    }
                                }
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_SPEECHES_URL.'/'.$celebrityId);
                }
            }
            $this->load->view('header');
            $this->load->view('speeches/addSpeech',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editSpeech() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
			if($Role_Id == 2){
				$celebrityId = $this->session->userdata('celebrityId');
			}
			$result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $where = array('s_id'=>$id);
			$details = $this->getSingleRecord(TBL_SPEECHES, $where, '*');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editSpeech')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_speach_title', 'Speech Title', 'trim|required');
                $this->form_validation->set_rules('edit_speach_content', 'Speech Content', 'trim|required');
				$this->form_validation->set_rules('edit_speach_video', 'Speech Video', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $speach_title = trim($this->input->post('edit_speach_title'));
					$speech_id = trim($this->input->post('edit_speech_id'));
                    $speach_video = trim($this->input->post('edit_speach_video'));
                    $speach_content = trim($this->input->post('edit_speach_content'));
					/* if($celebrityId){ */
						$Idata['s_celebrity_id'] = $celebrityId;
					/* }
					else{
                   $Idata['s_celebrity_id'] =$this->session->userdata('celebrityId');}*/
                    $Idata['s_title'] = $speach_title;
                    $Idata['s_content'] = $speach_content;
					$Idata['s_video'] = $speach_video;
					$Idata['s_updated_time'] = date('y-m-d H:i:s');
                        $isPremiun = 0;

                                    if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/speeches/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif','mp4','3gp','flv');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['s_thumbnail'] = $picname;
												 }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_SPEECHES_URL.'/'.$celebrityId.'/'.$speech_id);
											}
										} else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_SPEECHES_URL.'/'.$celebrityId.'/'.$speech_id);
                                        }
									}	
												$where = array('s_id'=>$speech_id);
												$haveRecord = $this->getSingleRecord(TBL_SPEECHES,$where,'*');
												if($haveRecord){
												$where = array('s_id'=>$speech_id);
												$result = $this->insertOrUpdate(TBL_SPEECHES, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_SPEECHES, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													/**** to send push noti ***/
													$Tdata['t_post_type'] = 13;
													$Tdata['t_post_id'] = $speech_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$Tdata['t_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$speach_title);
													}
													/**** end send push noti ***/
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(SPEECHES_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_SPEECHES_URL.'/'.$celebrityId.'/'.$speech_id);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_SPEECHES_URL.'/'.$celebrityId.'/'.$speech_id);
                }
            }
			
            $this->load->view('header');
            $this->load->view('speeches/editSpeech',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteSpeech() {
        if ($this->input->is_ajax_request()) {
            $image = $this->input->post('image');
			$imagePath = '../uploads/speeches/'.$image;
			$id = $this->input->post('id');
			$data['s_is_deleted'] = 1;
			$where = array('s_id'=>$id);
			$deleteSpeech = $this->insertOrUpdate(TBL_SPEECHES,$where,$data);
            if(file_exists($imagePath) && $deleteSpeech){
            unlink($imagePath);
               $this->session->set_flashdata('Smessage', "Speech Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Failed.");
            }
            die();
        }
    }
}