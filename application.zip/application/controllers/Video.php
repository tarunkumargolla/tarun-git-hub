<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Video extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	  
	  function index() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = (int)$this->uri->segment(2);
		if($Role_Id==1){
			$where = array('isDeleted' => 0,'video_celebrity_id'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'video_celebrity_id'=>$celebrityId);
			}
			if(empty($celebrityId)){
				redirect(DASHBOARD_URL);
			}
		$videos = $this->getAllRecords(TBL_VIDEOS,$where,'*','video_id');
		$data['videos'] =$videos;
		$data['celebrityId'] = $celebrityId;
        $this->load->view('header');
		$this->load->view('video/video',$data);
		$this->load->view('footer');
		
	}  
	function addVideo() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            $celebrityId = (int)$this->uri->segment(3); 
			if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY, array('c_is_deleted' => 0,'c_id'=>$celebrityId), '*');
            $data['celebritys'] = $celebrity;
            if ($this->input->post('addVideo')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('video_title', 'Video Title', 'trim|required');
                $this->form_validation->set_rules('video_url', 'Video code', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $video_title = trim($this->input->post('video_title'));
                    $video_url = trim($this->input->post('video_url'));
					/* if($celebrityId){ */
						$Idata['video_celebrity_id'] = $celebrityId;
					/* }else{
						$Idata['video_celebrity_id'] =$this->session->userdata('celebrityId');} */
						$Idata['video_title'] = $video_title;
						$Idata['video'] = $video_url;
						$isPremiun = 0;
						$Idata['createdTime'] = date('y-m-d h:i:s');
                                if ($_FILES['thumb_image']['name']) {

                                    if (!empty($_FILES['thumb_image']['name'])) {
                                        $target_path = '../uploads/videos/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['thumb_image']['name']);
                                        $filename = basename($_FILES['thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['thumb_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['thumb_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['video_thumbnail'] = $picname;
												$where = array();
												$result = $this->insertOrUpdate(TBL_VIDEOS, $where, $Idata);
												$last_id = $this->db->insert_id();
												if($result){
													/**** to send push noti ***/
                                                    $Tdata['t_post_type'] = '6';
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
											        $Tdata['t_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$video_title);
													}
													/**** end send push noti ***/
													$this->session->set_flashdata('Smessage', SUCCESS);
                                                    redirect(VIDEOS_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_VIDEO_URL.'/'.$celebrityId);
											}
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_VIDEO_URL.'/'.$celebrityId);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_VIDEO_URL.'/'.$celebrityId);
                                        }
                                    }
                                }
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_VIDEO_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('video/addvideo',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        }catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editVideo() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
			if($Role_Id == 2){
				 $celebrityId = $this->session->userdata('celebrityId');
			 }
			 $result = $this->celebrity(TBL_CELEBRITY,array('c_id'=>$celebrityId),'*');
            $where = array('video_id'=>$id);
			$details = $this->getSingleRecord(TBL_VIDEOS, $where, '*');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editVideo')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_video_title', 'Video Title', 'trim|required');
                $this->form_validation->set_rules('edit_video_url', 'Video Url', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $video_title = trim($this->input->post('edit_video_title'));
					$video_id = trim($this->input->post('edit_video_id'));
                   
                    $video_url = trim($this->input->post('edit_video_url'));
					/* if($celebrityId){ */
						$Idata['video_celebrity_id'] = $celebrityId;
					/* }
					else{
                   $Idata['video_celebrity_id'] =$this->session->userdata('edit_celebrityId');} */
                    $Idata['video_title'] = $video_title;
                    $Idata['video'] = $video_url;
                        $isPremiun = 0;

                                    if (!empty($_FILES['edit_thumb_image']['name'])) {
                                        $target_path = '../uploads/videos/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_thumb_image']['name']);
                                        $filename = basename($_FILES['edit_thumb_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_thumb_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_thumb_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['video_thumbnail'] = $picname;
												 }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_VIDEO_URL.'/'.$celebrityId.'/'.$video_id);
											}
										} else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_VIDEO_URL.'/'.$celebrityId.'/'.$video_id);
                                        }
									}	
												$where = array('video_id'=>$video_id);
												$haveRecord = $this->getSingleRecord(TBL_VIDEOS,$where,'*');
												if($haveRecord){
												$where = array('video_id'=>$video_id);
												$result = $this->insertOrUpdate(TBL_VIDEOS, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_VIDEOS, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
													/**** to send push noti ***/
                                                    $Tdata['t_post_type'] = '6';
													$Tdata['t_post_id'] = $video_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
											        $Tdata['t_created_time'] = date('Y-m-d H:i:s');
													$where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$video_title);
													}
													/**** end send push noti ***/
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(VIDEOS_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_VIDEO_URL.'/'.$celebrityId.'/'.$video_id);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(EDIT_VIDEO_URL.'/'.$celebrityId.'/'.$video_id);
                }
            }
			
            $this->load->view('header');
            $this->load->view('video/editvideo',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deletevideo() {
        if ($this->input->is_ajax_request()) {
			$id = $this->input->post('id');
			$data['isDeleted'] = 1;
			$where = array('video_id'=>$id);
			$deletevideo = $this->insertOrUpdate(TBL_VIDEOS,$where,$data);
            if($deletevideo){
               $this->session->set_flashdata('Smessage', "video Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Failed");
            }
            die();
        }
    }
}