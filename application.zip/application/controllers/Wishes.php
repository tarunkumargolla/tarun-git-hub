<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This resource contains the services for the Application services.
 * 
 * @category	Restful WebService
 * @controller  Service Controller
 */
// This can be removed if you use __autoload() in config.php OR use Modular Extensions

class Wishes extends Healthcontroller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Newsmodel');
        $this->load->model('Commonmodel', 'Commonmodel');

        date_default_timezone_set('Asia/Kolkata');
    }
	  
	  function index() {
		  $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
			$celebrityId = (int)$this->uri->segment(2);
		  if($Role_Id==1){
			$where = array('isDeleted' => 0,'celebrityId'=>$celebrityId);}
			else{
				$celebrityId = $this->session->userdata('celebrityId');
				$where = array('isDeleted'=>0,'celebrityId'=>$celebrityId);
			}
			if(empty($celebrityId)){
				redirect(CELEBRITY_URL);
			}
		$wishesimages = $this->getAllRecords(TBL_WISHES,$where,'wishes_id,wishes_image');
		$data['wishes'] =$wishesimages;
		$data['celebrityId'] = $celebrityId;
        $this->load->view('header');
		$this->load->view('Wishes/wishes',$data);
		$this->load->view('footer');
		
	}  
	function addWishes() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');
            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }
            $celebrityId = $this->uri->segment(3); 
			$celebrity = $this->getSingleRecord(TBL_CELEBRITY, array('c_is_deleted' => 0,'c_id'=>$celebrityId), '*');
            $data['celebritys'] = $celebrity;
            if ($this->input->post('addWishes')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('wishes_title', 'Wishes Title', 'trim|required');
                $this->form_validation->set_rules('wishes_content', 'Wishes Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $wishes_title = trim($this->input->post('wishes_title'));
                    $wishes_content = trim($this->input->post('wishes_content'));
					if($celebrityId){
						$Idata['celebrityId'] = $celebrityId;
					}else{
						$Idata['celebrityId'] =$this->session->userdata('celebrityId');}
						$Idata['wishes_name'] = $wishes_title;
						$Idata['wishes_content'] = $wishes_content;
						$isPremiun = 0;
						$Idata['createdTime'] = date('y-m-d h:i:s');
                                if ($_FILES['wishes_image']['name']) {

                                    if (!empty($_FILES['wishes_image']['name'])) {
                                        $target_path = '../uploads/wishes/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['wishes_image']['name']);
                                        $filename = basename($_FILES['wishes_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['wishes_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['wishes_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['wishes_image'] = $picname;
												$where = array();
												$result = $this->insertOrUpdate(TBL_WISHES, $where, $Idata);
												$last_id = $this->db->insert_id();
												if($result){
													/**** to send push noti on edit ***/
                                                    $Tdata['t_post_type'] = '16';
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$Tdata['t_created_time'] = date('Y-m-d H:i:s');
                                                    $where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$wishes_title);
													}
													/**** to send push noti on edit ***/
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(WISHES_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(ADD_WISHES_URL);
											}
                                            }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(ADD_WISHES_URL);
											}
                                        } else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(ADD_WISHES_URL);
                                        }
                                    }
                                }
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_WISHES_URL);
                }
            }
            $this->load->view('header');
            $this->load->view('Wishes/addWishes',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        }catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
		function editWishes() {
        try {
            $data = array();
            $Role_Id = $this->session->userdata('Role_Id');

            if (empty($Role_Id)) {
                redirect(LOGOUT_URL, 'refresh');
            }

            $id= $this->uri->segment(4);
			$celebrityId = $this->uri->segment(3);
            $where = array('wishes_id'=>$id);
			$details = $this->getSingleRecord(TBL_WISHES, $where, '*');
			$data['details'] = $details;
            $data['celebrityId'] = $celebrityId;
			
            if ($this->input->post('editWishes')) {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('edit_wishes_title', 'Wishes Title', 'trim|required');
                $this->form_validation->set_rules('edit_wishes_content', 'Wishes Content', 'trim|required');
                if ($this->form_validation->run() != false) {

                    $wishes_title = trim($this->input->post('edit_wishes_title'));
					$wishes_id = trim($this->input->post('edit_wishes_id'));
                   
                    $wishes_content = trim($this->input->post('edit_wishes_content'));
					if($celebrityId){
						$Idata['celebrityId'] = $celebrityId;
					}else{
                       $Idata['celebrityId'] =$this->session->userdata('edit_celebrityId');
					   $celebrityId=$this->session->userdata('edit_celebrityId');
				     }

                    $Idata['wishes_name'] = $wishes_title;
                    $Idata['wishes_content'] = $wishes_content;
                        $isPremiun = 0;

                                    if (!empty($_FILES['edit_wishes_image']['name'])) {
                                        $target_path = '../uploads/wishes/';
                                        $fileTypes = array('jpeg', 'png', 'jpg', 'gif');
                                        $response['file_name'] = basename($_FILES['edit_wishes_image']['name']);
                                        $filename = basename($_FILES['edit_wishes_image']['name']);
                                        $rand = rand();
                                        $file_extension = pathinfo($_FILES['edit_wishes_image']['name']);
                                        $picname = $rand . time() . '.' . strtolower($file_extension['extension']);
                                        $target_path = $target_path . $picname;
                                        if (in_array(strtolower($file_extension['extension']), $fileTypes)) {
                                            $movefile = move_uploaded_file($_FILES['edit_wishes_image']['tmp_name'], $target_path);
                                            if ($movefile) {
                                                $Idata['wishes_image'] = $picname;
												 }
											else {
                                            $this->session->set_flashdata('Fmessage', "File not Moved");
                                            redirect(EDIT_WISHES_URL);
											}
										} else {
                                            $this->session->set_flashdata('Fmessage', "File formate is not supported");
                                            redirect(EDIT_WISHES_URL);
                                        }
									}	
												$where = array('wishes_id'=>$wishes_id);
												$haveRecord = $this->getSingleRecord(TBL_WISHES,$where,'*');
												if($haveRecord){
												$where = array('wishes_id'=>$wishes_id);
												$result = $this->insertOrUpdate(TBL_WISHES, $where, $Idata);}
												else{
												$where = array();
												$result = $this->insertOrUpdate(TBL_WISHES, $where, $Idata);
												}
												$last_id = $this->db->insert_id();
												if($result){
												   /**** to send push noti on edit ***/
                                                    $Tdata['t_post_type'] = '16';
													$Tdata['t_post_id'] = $last_id;
													$Tdata['t_celebrity_id'] = $celebrityId;
													$Tdata['t_created_time'] = date('Y-m-d H:i:s');
                                                    $where = array();
													$Tresult = $this->insertOrUpdate(TBL_TIMELINE,$where,$Tdata);
													$timeline_id = $this->db->insert_id();
													if($timeline_id){
													  $this->sendPushNotification($timeline_id,$celebrityId,$wishes_title);
													}
													/**** to send push noti on edit ***/
													 $this->session->set_flashdata('Smessage', SUCCESS);
                                                      redirect(WISHES_URL.'/'.$celebrityId);
												}
												else {
                                            $this->session->set_flashdata('Fmessage', FAILED);
                                            redirect(EDIT_WISHES_URL);
											}
								 } else {
                    $this->session->set_flashdata('Fmessage', validation_errors());
                    redirect(ADD_WISHES_URL);
                }
            }
			
            $this->load->view('header');
            $this->load->view('Wishes/editWishes',$data);
            $this->load->view('scripts');
            $this->load->view('footer');
        } catch (Exception $exception) {
            $data['error'] = $exception->getMessage();
            $this->logExceptionMessage($exception);
        }
    }
	function deleteWishes() {
        if ($this->input->is_ajax_request()) {
            
			$id = $this->input->post('id');
			$data['isDeleted'] = 1;
			$where = array('wishes_id'=>$id);
			$deleteWishes = $this->insertOrUpdate(TBL_WISHES,$where,$data);
            if($deleteWishes){
               $this->session->set_flashdata('Smessage', "Wishes Delete Successfully");
            } else {
             $this->session->set_flashdata('Fmessage', "Wishes Delete Not Successfully Please Provide Valid Path");
            }
            die();
        }
    }
}