<?php
/*  
Parameter Example
	$data = array('post_id'=>'12345','post_title'=>'A Blog post');
	$target = 'single tocken id or topic name';
	or
	$target = array('token1','token2','...'); // up to 1000 in one request
*/

class Fcm {
public function sendMessage($data,$target){

$ch = curl_init("https://fcm.googleapis.com/fcm/send");
$header=array('Content-Type: application/json',
"Authorization: key=AIzaSyDumD9-tAVk_jiGCmFxAwh07NuU7k8PToc");
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{ \"notification\": {    \"title\": \"Test desde curl\",    \"text\": \"Hello \"  },    \"to\" : \"eA8VE2E7Lzc:APA91bEa4pLQlvQ38GlMlu0bW5cmkVtHMDeLKsX9e-kv_1LWcjbpts3DuXblu2PO7ohM9wpIxUaCZZD8immgZL5-z85HpL9Udn7iw50iDMNrPXE7mthViYdMv2nIr-YGg199UCJFhMFa\"}");

 $result =  curl_exec($ch);
 
curl_close($ch);
}
}