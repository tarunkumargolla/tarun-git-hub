<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-10 07:39:22 --> Config Class Initialized
INFO - 2017-02-10 07:39:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:22 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:22 --> URI Class Initialized
INFO - 2017-02-10 07:39:22 --> Router Class Initialized
INFO - 2017-02-10 07:39:22 --> Output Class Initialized
INFO - 2017-02-10 07:39:22 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:22 --> Input Class Initialized
INFO - 2017-02-10 07:39:22 --> Language Class Initialized
INFO - 2017-02-10 07:39:22 --> Loader Class Initialized
INFO - 2017-02-10 07:39:22 --> Helper loaded: common_helper
INFO - 2017-02-10 07:39:22 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 07:39:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 07:39:22 --> Unable to connect to the database
INFO - 2017-02-10 07:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:22 --> Controller Class Initialized
DEBUG - 2017-02-10 07:39:22 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:39:22 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:39:22 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 07:39:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 07:39:22 --> Unable to connect to the database
INFO - 2017-02-10 07:39:22 --> Model Class Initialized
INFO - 2017-02-10 07:39:22 --> Model Class Initialized
INFO - 2017-02-10 07:39:22 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 07:39:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 07:39:22 --> Unable to connect to the database
INFO - 2017-02-10 07:39:22 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:22 --> Model Class Initialized
INFO - 2017-02-10 07:39:22 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 07:39:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 07:39:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 07:39:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 07:39:22 --> Unable to connect to the database
ERROR - 2017-02-10 12:09:22 --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-02-10 12:09:22 --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-02-10 12:09:22 --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-02-10 12:09:22 --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-02-10 12:09:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 12:09:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 12:09:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 12:09:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 12:09:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 12:09:22 --> Unable to connect to the database
ERROR - 2017-02-10 12:09:22 --> mysql_query() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 245
ERROR - 2017-02-10 12:09:22 --> mysql_insert_id() expects parameter 1 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_insert_id() expects parameter 1 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 370
ERROR - 2017-02-10 12:09:22 --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 346
ERROR - 2017-02-10 12:09:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 12:09:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 12:09:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 12:09:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 12:09:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 12:09:22 --> Unable to connect to the database
ERROR - 2017-02-10 12:09:22 --> mysql_query() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 245
ERROR - 2017-02-10 12:09:22 --> mysql_num_rows() expects parameter 1 to be resource, null given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_result.php 63
ERROR - 2017-02-10 12:09:22 --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\blooddonation\system\core\Exceptions.php:275)
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\blooddonation\system\core\Exceptions.php:275) C:\xampp\htdocs\blooddonation\application\libraries\REST_Controller.php 486
ERROR - 2017-02-10 12:09:22 --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\blooddonation\system\core\Exceptions.php:275)
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\blooddonation\system\core\Exceptions.php:275) C:\xampp\htdocs\blooddonation\system\core\Common.php 569
ERROR - 2017-02-10 12:09:22 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 12:09:22 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 12:09:22 --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES)
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_pconnect(): Access denied for user 'vikram'@'localhost' (using password: YES) C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2017-02-10 12:09:22 --> mysql_select_db() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 191
ERROR - 2017-02-10 12:09:22 --> Unable to select database: blooddonation
ERROR - 2017-02-10 12:09:22 --> Unable to connect to the database
ERROR - 2017-02-10 12:09:22 --> mysql_query() expects parameter 2 to be resource, boolean given
ERROR - 2017-02-10 12:09:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 245
INFO - 2017-02-10 07:39:46 --> Config Class Initialized
INFO - 2017-02-10 07:39:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:46 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:46 --> URI Class Initialized
INFO - 2017-02-10 07:39:46 --> Router Class Initialized
INFO - 2017-02-10 07:39:46 --> Output Class Initialized
INFO - 2017-02-10 07:39:46 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:46 --> Input Class Initialized
INFO - 2017-02-10 07:39:46 --> Language Class Initialized
INFO - 2017-02-10 07:39:46 --> Loader Class Initialized
INFO - 2017-02-10 07:39:46 --> Helper loaded: common_helper
INFO - 2017-02-10 07:39:46 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:46 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:46 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-02-10 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:46 --> Controller Class Initialized
DEBUG - 2017-02-10 07:39:46 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:39:46 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:39:46 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:46 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:46 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-02-10 07:39:46 --> Model Class Initialized
INFO - 2017-02-10 07:39:46 --> Model Class Initialized
INFO - 2017-02-10 07:39:46 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:46 --> Model Class Initialized
ERROR - 2017-02-10 12:09:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notifications', 'get', NULL, '', '::1', 1486708786, 1)
ERROR - 2017-02-10 12:09:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.12453103065491
WHERE `id` =0
INFO - 2017-02-10 07:39:46 --> Config Class Initialized
INFO - 2017-02-10 07:39:46 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:46 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:46 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:46 --> URI Class Initialized
INFO - 2017-02-10 07:39:46 --> Router Class Initialized
INFO - 2017-02-10 07:39:46 --> Output Class Initialized
INFO - 2017-02-10 07:39:46 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:46 --> Input Class Initialized
INFO - 2017-02-10 07:39:46 --> Language Class Initialized
INFO - 2017-02-10 07:39:46 --> Loader Class Initialized
INFO - 2017-02-10 07:39:46 --> Helper loaded: common_helper
INFO - 2017-02-10 07:39:46 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:46 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:46 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-02-10 07:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:46 --> Controller Class Initialized
DEBUG - 2017-02-10 07:39:46 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:39:46 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:39:46 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:46 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:46 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-02-10 07:39:46 --> Model Class Initialized
INFO - 2017-02-10 07:39:46 --> Model Class Initialized
INFO - 2017-02-10 07:39:46 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:46 --> Model Class Initialized
ERROR - 2017-02-10 12:09:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notifications', 'get', NULL, '', '::1', 1486708786, 1)
ERROR - 2017-02-10 12:09:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.017248868942261
WHERE `id` =0
INFO - 2017-02-10 07:39:51 --> Config Class Initialized
INFO - 2017-02-10 07:39:51 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:39:51 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:39:51 --> Utf8 Class Initialized
INFO - 2017-02-10 07:39:51 --> URI Class Initialized
INFO - 2017-02-10 07:39:51 --> Router Class Initialized
INFO - 2017-02-10 07:39:51 --> Output Class Initialized
INFO - 2017-02-10 07:39:51 --> Security Class Initialized
DEBUG - 2017-02-10 07:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:39:51 --> Input Class Initialized
INFO - 2017-02-10 07:39:51 --> Language Class Initialized
INFO - 2017-02-10 07:39:51 --> Loader Class Initialized
INFO - 2017-02-10 07:39:51 --> Helper loaded: common_helper
INFO - 2017-02-10 07:39:51 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:51 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:51 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-02-10 07:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:39:51 --> Controller Class Initialized
DEBUG - 2017-02-10 07:39:51 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:39:51 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:39:51 --> Database Driver Class Initialized
ERROR - 2017-02-10 07:39:51 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-02-10 07:39:51 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\blooddonation\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-02-10 07:39:51 --> Model Class Initialized
INFO - 2017-02-10 07:39:51 --> Model Class Initialized
INFO - 2017-02-10 07:39:51 --> Helper loaded: url_helper
INFO - 2017-02-10 07:39:51 --> Model Class Initialized
ERROR - 2017-02-10 12:09:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notifications', 'get', NULL, '', '::1', 1486708791, 1)
ERROR - 2017-02-10 12:09:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.018028020858765
WHERE `id` =0
INFO - 2017-02-10 07:40:04 --> Config Class Initialized
INFO - 2017-02-10 07:40:04 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:40:04 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:40:04 --> Utf8 Class Initialized
INFO - 2017-02-10 07:40:04 --> URI Class Initialized
INFO - 2017-02-10 07:40:04 --> Router Class Initialized
INFO - 2017-02-10 07:40:04 --> Output Class Initialized
INFO - 2017-02-10 07:40:04 --> Security Class Initialized
DEBUG - 2017-02-10 07:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:40:04 --> Input Class Initialized
INFO - 2017-02-10 07:40:04 --> Language Class Initialized
INFO - 2017-02-10 07:40:04 --> Loader Class Initialized
INFO - 2017-02-10 07:40:04 --> Helper loaded: common_helper
INFO - 2017-02-10 07:40:04 --> Database Driver Class Initialized
INFO - 2017-02-10 07:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:40:04 --> Controller Class Initialized
DEBUG - 2017-02-10 07:40:04 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:40:04 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:40:04 --> Database Driver Class Initialized
INFO - 2017-02-10 07:40:04 --> Model Class Initialized
INFO - 2017-02-10 07:40:04 --> Model Class Initialized
INFO - 2017-02-10 07:40:04 --> Helper loaded: url_helper
INFO - 2017-02-10 07:40:04 --> Model Class Initialized
ERROR - 2017-02-10 12:10:04 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notifications', 'get', NULL, '', '::1', 1486708804, 1)
ERROR - 2017-02-10 12:10:04 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.017375946044922
WHERE `id` =0
INFO - 2017-02-10 07:41:36 --> Config Class Initialized
INFO - 2017-02-10 07:41:36 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:41:37 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:41:37 --> Utf8 Class Initialized
INFO - 2017-02-10 07:41:37 --> URI Class Initialized
INFO - 2017-02-10 07:41:37 --> Router Class Initialized
INFO - 2017-02-10 07:41:37 --> Output Class Initialized
INFO - 2017-02-10 07:41:37 --> Security Class Initialized
DEBUG - 2017-02-10 07:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:41:37 --> Input Class Initialized
INFO - 2017-02-10 07:41:37 --> Language Class Initialized
INFO - 2017-02-10 07:41:37 --> Loader Class Initialized
INFO - 2017-02-10 07:41:37 --> Helper loaded: common_helper
INFO - 2017-02-10 07:41:37 --> Database Driver Class Initialized
INFO - 2017-02-10 07:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:41:37 --> Controller Class Initialized
DEBUG - 2017-02-10 07:41:37 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:41:37 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:41:37 --> Database Driver Class Initialized
INFO - 2017-02-10 07:41:37 --> Model Class Initialized
INFO - 2017-02-10 07:41:37 --> Model Class Initialized
INFO - 2017-02-10 07:41:37 --> Helper loaded: url_helper
INFO - 2017-02-10 07:41:37 --> Model Class Initialized
ERROR - 2017-02-10 12:11:37 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486708897, 1)
INFO - 2017-02-10 12:11:37 --> Helper loaded: form_helper
INFO - 2017-02-10 12:11:37 --> Form Validation Class Initialized
INFO - 2017-02-10 12:11:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:11:37 --> Query error: Unknown column 'noti_enable' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '3'
 LIMIT 1
ERROR - 2017-02-10 12:11:37 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-02-10 12:11:37 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-02-10 07:45:56 --> Config Class Initialized
INFO - 2017-02-10 07:45:56 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:45:56 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:45:56 --> Utf8 Class Initialized
INFO - 2017-02-10 07:45:56 --> URI Class Initialized
INFO - 2017-02-10 07:45:56 --> Router Class Initialized
INFO - 2017-02-10 07:45:56 --> Output Class Initialized
INFO - 2017-02-10 07:45:56 --> Security Class Initialized
DEBUG - 2017-02-10 07:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:45:56 --> Input Class Initialized
INFO - 2017-02-10 07:45:56 --> Language Class Initialized
INFO - 2017-02-10 07:45:56 --> Loader Class Initialized
INFO - 2017-02-10 07:45:56 --> Helper loaded: common_helper
INFO - 2017-02-10 07:45:56 --> Database Driver Class Initialized
INFO - 2017-02-10 07:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:45:56 --> Controller Class Initialized
DEBUG - 2017-02-10 07:45:56 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:45:56 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:45:56 --> Database Driver Class Initialized
INFO - 2017-02-10 07:45:56 --> Model Class Initialized
INFO - 2017-02-10 07:45:56 --> Model Class Initialized
INFO - 2017-02-10 07:45:56 --> Helper loaded: url_helper
INFO - 2017-02-10 07:45:56 --> Model Class Initialized
ERROR - 2017-02-10 12:15:56 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709156, 1)
INFO - 2017-02-10 12:15:56 --> Helper loaded: form_helper
INFO - 2017-02-10 12:15:56 --> Form Validation Class Initialized
INFO - 2017-02-10 12:15:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:15:56 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.015233039855957
WHERE `id` =0
INFO - 2017-02-10 07:46:22 --> Config Class Initialized
INFO - 2017-02-10 07:46:22 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:46:22 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:46:22 --> Utf8 Class Initialized
INFO - 2017-02-10 07:46:22 --> URI Class Initialized
INFO - 2017-02-10 07:46:22 --> Router Class Initialized
INFO - 2017-02-10 07:46:22 --> Output Class Initialized
INFO - 2017-02-10 07:46:22 --> Security Class Initialized
DEBUG - 2017-02-10 07:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:46:22 --> Input Class Initialized
INFO - 2017-02-10 07:46:22 --> Language Class Initialized
INFO - 2017-02-10 07:46:22 --> Loader Class Initialized
INFO - 2017-02-10 07:46:22 --> Helper loaded: common_helper
INFO - 2017-02-10 07:46:22 --> Database Driver Class Initialized
INFO - 2017-02-10 07:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:46:22 --> Controller Class Initialized
DEBUG - 2017-02-10 07:46:22 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:46:22 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:46:22 --> Database Driver Class Initialized
INFO - 2017-02-10 07:46:22 --> Model Class Initialized
INFO - 2017-02-10 07:46:22 --> Model Class Initialized
INFO - 2017-02-10 07:46:22 --> Helper loaded: url_helper
INFO - 2017-02-10 07:46:22 --> Model Class Initialized
ERROR - 2017-02-10 12:16:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709182, 1)
INFO - 2017-02-10 12:16:22 --> Helper loaded: form_helper
INFO - 2017-02-10 12:16:22 --> Form Validation Class Initialized
INFO - 2017-02-10 12:16:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:16:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.021043062210083
WHERE `id` =0
INFO - 2017-02-10 07:46:42 --> Config Class Initialized
INFO - 2017-02-10 07:46:42 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:46:42 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:46:42 --> Utf8 Class Initialized
INFO - 2017-02-10 07:46:42 --> URI Class Initialized
INFO - 2017-02-10 07:46:42 --> Router Class Initialized
INFO - 2017-02-10 07:46:42 --> Output Class Initialized
INFO - 2017-02-10 07:46:42 --> Security Class Initialized
DEBUG - 2017-02-10 07:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:46:42 --> Input Class Initialized
INFO - 2017-02-10 07:46:42 --> Language Class Initialized
INFO - 2017-02-10 07:46:42 --> Loader Class Initialized
INFO - 2017-02-10 07:46:42 --> Helper loaded: common_helper
INFO - 2017-02-10 07:46:42 --> Database Driver Class Initialized
INFO - 2017-02-10 07:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:46:42 --> Controller Class Initialized
DEBUG - 2017-02-10 07:46:42 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:46:42 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:46:42 --> Database Driver Class Initialized
INFO - 2017-02-10 07:46:42 --> Model Class Initialized
INFO - 2017-02-10 07:46:42 --> Model Class Initialized
INFO - 2017-02-10 07:46:42 --> Helper loaded: url_helper
INFO - 2017-02-10 07:46:42 --> Model Class Initialized
ERROR - 2017-02-10 12:16:42 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709202, 1)
INFO - 2017-02-10 12:16:42 --> Helper loaded: form_helper
INFO - 2017-02-10 12:16:42 --> Form Validation Class Initialized
INFO - 2017-02-10 12:16:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:16:42 --> Query error: Unknown column 'noti_enable' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '3'
 LIMIT 1
ERROR - 2017-02-10 12:16:42 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-02-10 12:16:42 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-02-10 07:47:16 --> Config Class Initialized
INFO - 2017-02-10 07:47:16 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:16 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:16 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:16 --> URI Class Initialized
INFO - 2017-02-10 07:47:16 --> Router Class Initialized
INFO - 2017-02-10 07:47:16 --> Output Class Initialized
INFO - 2017-02-10 07:47:16 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:16 --> Input Class Initialized
INFO - 2017-02-10 07:47:16 --> Language Class Initialized
INFO - 2017-02-10 07:47:16 --> Loader Class Initialized
INFO - 2017-02-10 07:47:16 --> Helper loaded: common_helper
INFO - 2017-02-10 07:47:16 --> Database Driver Class Initialized
INFO - 2017-02-10 07:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:47:16 --> Controller Class Initialized
DEBUG - 2017-02-10 07:47:16 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:47:16 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:47:16 --> Database Driver Class Initialized
INFO - 2017-02-10 07:47:16 --> Model Class Initialized
INFO - 2017-02-10 07:47:16 --> Model Class Initialized
INFO - 2017-02-10 07:47:16 --> Helper loaded: url_helper
INFO - 2017-02-10 07:47:16 --> Model Class Initialized
ERROR - 2017-02-10 12:17:16 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709236, 1)
INFO - 2017-02-10 12:17:16 --> Helper loaded: form_helper
INFO - 2017-02-10 12:17:16 --> Form Validation Class Initialized
INFO - 2017-02-10 12:17:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:17:16 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.019969940185547
WHERE `id` =0
INFO - 2017-02-10 07:47:36 --> Config Class Initialized
INFO - 2017-02-10 07:47:36 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:47:36 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:47:36 --> Utf8 Class Initialized
INFO - 2017-02-10 07:47:36 --> URI Class Initialized
INFO - 2017-02-10 07:47:36 --> Router Class Initialized
INFO - 2017-02-10 07:47:36 --> Output Class Initialized
INFO - 2017-02-10 07:47:36 --> Security Class Initialized
DEBUG - 2017-02-10 07:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:47:36 --> Input Class Initialized
INFO - 2017-02-10 07:47:36 --> Language Class Initialized
INFO - 2017-02-10 07:47:36 --> Loader Class Initialized
INFO - 2017-02-10 07:47:36 --> Helper loaded: common_helper
INFO - 2017-02-10 07:47:36 --> Database Driver Class Initialized
INFO - 2017-02-10 07:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:47:36 --> Controller Class Initialized
DEBUG - 2017-02-10 07:47:36 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:47:36 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:47:36 --> Database Driver Class Initialized
INFO - 2017-02-10 07:47:36 --> Model Class Initialized
INFO - 2017-02-10 07:47:36 --> Model Class Initialized
INFO - 2017-02-10 07:47:36 --> Helper loaded: url_helper
INFO - 2017-02-10 07:47:36 --> Model Class Initialized
ERROR - 2017-02-10 12:17:36 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709256, 1)
INFO - 2017-02-10 12:17:36 --> Helper loaded: form_helper
INFO - 2017-02-10 12:17:36 --> Form Validation Class Initialized
INFO - 2017-02-10 12:17:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:17:36 --> Query error: Unknown column 'noti_enable' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '3'
 LIMIT 1
ERROR - 2017-02-10 12:17:36 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.021606922149658
WHERE `id` =0
INFO - 2017-02-10 07:48:33 --> Config Class Initialized
INFO - 2017-02-10 07:48:33 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:33 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:33 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:33 --> URI Class Initialized
INFO - 2017-02-10 07:48:33 --> Router Class Initialized
INFO - 2017-02-10 07:48:33 --> Output Class Initialized
INFO - 2017-02-10 07:48:33 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:33 --> Input Class Initialized
INFO - 2017-02-10 07:48:33 --> Language Class Initialized
INFO - 2017-02-10 07:48:33 --> Loader Class Initialized
INFO - 2017-02-10 07:48:33 --> Helper loaded: common_helper
INFO - 2017-02-10 07:48:33 --> Database Driver Class Initialized
INFO - 2017-02-10 07:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:48:33 --> Controller Class Initialized
DEBUG - 2017-02-10 07:48:33 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:48:33 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:48:33 --> Database Driver Class Initialized
INFO - 2017-02-10 07:48:33 --> Model Class Initialized
INFO - 2017-02-10 07:48:33 --> Model Class Initialized
INFO - 2017-02-10 07:48:33 --> Helper loaded: url_helper
INFO - 2017-02-10 07:48:33 --> Model Class Initialized
ERROR - 2017-02-10 12:18:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709313, 1)
INFO - 2017-02-10 12:18:33 --> Helper loaded: form_helper
INFO - 2017-02-10 12:18:33 --> Form Validation Class Initialized
INFO - 2017-02-10 12:18:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:18:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.01795220375061
WHERE `id` =0
INFO - 2017-02-10 07:48:39 --> Config Class Initialized
INFO - 2017-02-10 07:48:39 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:48:39 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:48:39 --> Utf8 Class Initialized
INFO - 2017-02-10 07:48:39 --> URI Class Initialized
INFO - 2017-02-10 07:48:39 --> Router Class Initialized
INFO - 2017-02-10 07:48:39 --> Output Class Initialized
INFO - 2017-02-10 07:48:39 --> Security Class Initialized
DEBUG - 2017-02-10 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:48:39 --> Input Class Initialized
INFO - 2017-02-10 07:48:39 --> Language Class Initialized
INFO - 2017-02-10 07:48:39 --> Loader Class Initialized
INFO - 2017-02-10 07:48:39 --> Helper loaded: common_helper
INFO - 2017-02-10 07:48:39 --> Database Driver Class Initialized
INFO - 2017-02-10 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:48:39 --> Controller Class Initialized
DEBUG - 2017-02-10 07:48:39 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:48:39 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:48:39 --> Database Driver Class Initialized
INFO - 2017-02-10 07:48:39 --> Model Class Initialized
INFO - 2017-02-10 07:48:39 --> Model Class Initialized
INFO - 2017-02-10 07:48:39 --> Helper loaded: url_helper
INFO - 2017-02-10 07:48:39 --> Model Class Initialized
ERROR - 2017-02-10 12:18:39 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709319, 1)
INFO - 2017-02-10 12:18:39 --> Helper loaded: form_helper
INFO - 2017-02-10 12:18:39 --> Form Validation Class Initialized
INFO - 2017-02-10 12:18:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:18:39 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.019489049911499
WHERE `id` =0
INFO - 2017-02-10 07:49:01 --> Config Class Initialized
INFO - 2017-02-10 07:49:01 --> Hooks Class Initialized
DEBUG - 2017-02-10 07:49:01 --> UTF-8 Support Enabled
INFO - 2017-02-10 07:49:01 --> Utf8 Class Initialized
INFO - 2017-02-10 07:49:01 --> URI Class Initialized
INFO - 2017-02-10 07:49:01 --> Router Class Initialized
INFO - 2017-02-10 07:49:01 --> Output Class Initialized
INFO - 2017-02-10 07:49:01 --> Security Class Initialized
DEBUG - 2017-02-10 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 07:49:01 --> Input Class Initialized
INFO - 2017-02-10 07:49:01 --> Language Class Initialized
INFO - 2017-02-10 07:49:01 --> Loader Class Initialized
INFO - 2017-02-10 07:49:01 --> Helper loaded: common_helper
INFO - 2017-02-10 07:49:01 --> Database Driver Class Initialized
INFO - 2017-02-10 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 07:49:01 --> Controller Class Initialized
DEBUG - 2017-02-10 07:49:01 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 07:49:01 --> Helper loaded: inflector_helper
INFO - 2017-02-10 07:49:01 --> Database Driver Class Initialized
INFO - 2017-02-10 07:49:01 --> Model Class Initialized
INFO - 2017-02-10 07:49:01 --> Model Class Initialized
INFO - 2017-02-10 07:49:01 --> Helper loaded: url_helper
INFO - 2017-02-10 07:49:01 --> Model Class Initialized
ERROR - 2017-02-10 12:19:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486709341, 1)
INFO - 2017-02-10 12:19:01 --> Helper loaded: form_helper
INFO - 2017-02-10 12:19:01 --> Form Validation Class Initialized
INFO - 2017-02-10 12:19:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:19:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.90456891059875
WHERE `id` =0
INFO - 2017-02-10 08:01:23 --> Config Class Initialized
INFO - 2017-02-10 08:01:23 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:01:23 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:01:23 --> Utf8 Class Initialized
INFO - 2017-02-10 08:01:23 --> URI Class Initialized
INFO - 2017-02-10 08:01:23 --> Router Class Initialized
INFO - 2017-02-10 08:01:23 --> Output Class Initialized
INFO - 2017-02-10 08:01:23 --> Security Class Initialized
DEBUG - 2017-02-10 08:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:01:23 --> Input Class Initialized
INFO - 2017-02-10 08:01:23 --> Language Class Initialized
INFO - 2017-02-10 08:01:23 --> Loader Class Initialized
INFO - 2017-02-10 08:01:23 --> Helper loaded: common_helper
INFO - 2017-02-10 08:01:23 --> Database Driver Class Initialized
INFO - 2017-02-10 08:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:01:23 --> Controller Class Initialized
DEBUG - 2017-02-10 08:01:23 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 08:01:23 --> Helper loaded: inflector_helper
INFO - 2017-02-10 08:01:23 --> Database Driver Class Initialized
INFO - 2017-02-10 08:01:23 --> Model Class Initialized
INFO - 2017-02-10 08:01:23 --> Model Class Initialized
INFO - 2017-02-10 08:01:23 --> Helper loaded: url_helper
INFO - 2017-02-10 08:01:23 --> Model Class Initialized
ERROR - 2017-02-10 12:31:23 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486710083, 1)
INFO - 2017-02-10 12:31:23 --> Helper loaded: form_helper
INFO - 2017-02-10 12:31:23 --> Form Validation Class Initialized
INFO - 2017-02-10 12:31:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:31:23 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.28904509544373
WHERE `id` =0
INFO - 2017-02-10 08:01:45 --> Config Class Initialized
INFO - 2017-02-10 08:01:45 --> Hooks Class Initialized
DEBUG - 2017-02-10 08:01:45 --> UTF-8 Support Enabled
INFO - 2017-02-10 08:01:45 --> Utf8 Class Initialized
INFO - 2017-02-10 08:01:45 --> URI Class Initialized
INFO - 2017-02-10 08:01:45 --> Router Class Initialized
INFO - 2017-02-10 08:01:45 --> Output Class Initialized
INFO - 2017-02-10 08:01:45 --> Security Class Initialized
DEBUG - 2017-02-10 08:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-10 08:01:45 --> Input Class Initialized
INFO - 2017-02-10 08:01:45 --> Language Class Initialized
INFO - 2017-02-10 08:01:45 --> Loader Class Initialized
INFO - 2017-02-10 08:01:45 --> Helper loaded: common_helper
INFO - 2017-02-10 08:01:45 --> Database Driver Class Initialized
INFO - 2017-02-10 08:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-10 08:01:45 --> Controller Class Initialized
DEBUG - 2017-02-10 08:01:45 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-10 08:01:45 --> Helper loaded: inflector_helper
INFO - 2017-02-10 08:01:45 --> Database Driver Class Initialized
INFO - 2017-02-10 08:01:45 --> Model Class Initialized
INFO - 2017-02-10 08:01:45 --> Model Class Initialized
INFO - 2017-02-10 08:01:45 --> Helper loaded: url_helper
INFO - 2017-02-10 08:01:45 --> Model Class Initialized
ERROR - 2017-02-10 12:31:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"3\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\"}', '', '::1', 1486710105, 1)
INFO - 2017-02-10 12:31:45 --> Helper loaded: form_helper
INFO - 2017-02-10 12:31:45 --> Form Validation Class Initialized
INFO - 2017-02-10 12:31:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-10 12:31:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.3562159538269
WHERE `id` =0
