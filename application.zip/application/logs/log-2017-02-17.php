<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-02-17 06:57:21 --> Config Class Initialized
INFO - 2017-02-17 06:57:21 --> Hooks Class Initialized
DEBUG - 2017-02-17 06:57:21 --> UTF-8 Support Enabled
INFO - 2017-02-17 06:57:21 --> Utf8 Class Initialized
INFO - 2017-02-17 06:57:21 --> URI Class Initialized
INFO - 2017-02-17 06:57:21 --> Router Class Initialized
INFO - 2017-02-17 06:57:21 --> Output Class Initialized
INFO - 2017-02-17 06:57:21 --> Security Class Initialized
DEBUG - 2017-02-17 06:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 06:57:21 --> Input Class Initialized
INFO - 2017-02-17 06:57:21 --> Language Class Initialized
INFO - 2017-02-17 06:57:21 --> Loader Class Initialized
INFO - 2017-02-17 06:57:21 --> Helper loaded: common_helper
INFO - 2017-02-17 06:57:21 --> Database Driver Class Initialized
INFO - 2017-02-17 06:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 06:57:21 --> Controller Class Initialized
DEBUG - 2017-02-17 06:57:21 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-17 06:57:21 --> Helper loaded: inflector_helper
INFO - 2017-02-17 06:57:21 --> Database Driver Class Initialized
INFO - 2017-02-17 06:57:22 --> Model Class Initialized
INFO - 2017-02-17 06:57:22 --> Model Class Initialized
INFO - 2017-02-17 06:57:22 --> Helper loaded: url_helper
ERROR - 2017-02-17 11:27:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/signup', 'post', '{\"name\":\"asasass\",\"phoneNumber\":\"8985716639\",\"countryCode\":\"+91\"}', '', '::1', 1487311042, 1)
INFO - 2017-02-17 11:27:22 --> Helper loaded: form_helper
INFO - 2017-02-17 11:27:22 --> Form Validation Class Initialized
INFO - 2017-02-17 11:27:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 11:27:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.91251397132874
WHERE `id` =0
INFO - 2017-02-17 07:16:09 --> Config Class Initialized
INFO - 2017-02-17 07:16:09 --> Hooks Class Initialized
DEBUG - 2017-02-17 07:16:09 --> UTF-8 Support Enabled
INFO - 2017-02-17 07:16:09 --> Utf8 Class Initialized
INFO - 2017-02-17 07:16:09 --> URI Class Initialized
INFO - 2017-02-17 07:16:09 --> Router Class Initialized
INFO - 2017-02-17 07:16:09 --> Output Class Initialized
INFO - 2017-02-17 07:16:09 --> Security Class Initialized
DEBUG - 2017-02-17 07:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-02-17 07:16:09 --> Input Class Initialized
INFO - 2017-02-17 07:16:09 --> Language Class Initialized
INFO - 2017-02-17 07:16:09 --> Loader Class Initialized
INFO - 2017-02-17 07:16:09 --> Helper loaded: common_helper
INFO - 2017-02-17 07:16:09 --> Database Driver Class Initialized
INFO - 2017-02-17 07:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-02-17 07:16:09 --> Controller Class Initialized
DEBUG - 2017-02-17 07:16:09 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-02-17 07:16:09 --> Helper loaded: inflector_helper
INFO - 2017-02-17 07:16:09 --> Database Driver Class Initialized
INFO - 2017-02-17 07:16:09 --> Model Class Initialized
INFO - 2017-02-17 07:16:09 --> Model Class Initialized
INFO - 2017-02-17 07:16:09 --> Helper loaded: url_helper
ERROR - 2017-02-17 11:46:09 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/signup', 'post', '{\"name\":\"asasass\",\"phoneNumber\":\"8985716639\",\"countryCode\":\"+91\"}', '', '::1', 1487312169, 1)
INFO - 2017-02-17 11:46:09 --> Helper loaded: form_helper
INFO - 2017-02-17 11:46:09 --> Form Validation Class Initialized
INFO - 2017-02-17 11:46:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-02-17 11:46:09 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.47544312477112
WHERE `id` =0
