<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-01 08:25:41 --> Config Class Initialized
INFO - 2017-03-01 08:25:41 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:25:41 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:25:41 --> Utf8 Class Initialized
INFO - 2017-03-01 08:25:41 --> URI Class Initialized
INFO - 2017-03-01 08:25:41 --> Router Class Initialized
INFO - 2017-03-01 08:25:41 --> Output Class Initialized
INFO - 2017-03-01 08:25:41 --> Security Class Initialized
DEBUG - 2017-03-01 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:25:41 --> Input Class Initialized
INFO - 2017-03-01 08:25:41 --> Language Class Initialized
INFO - 2017-03-01 08:25:41 --> Loader Class Initialized
INFO - 2017-03-01 08:25:41 --> Helper loaded: common_helper
INFO - 2017-03-01 08:25:41 --> Database Driver Class Initialized
INFO - 2017-03-01 08:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:25:41 --> Controller Class Initialized
DEBUG - 2017-03-01 08:25:41 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:25:41 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:25:41 --> Database Driver Class Initialized
INFO - 2017-03-01 08:25:41 --> Model Class Initialized
INFO - 2017-03-01 08:25:41 --> Model Class Initialized
INFO - 2017-03-01 08:25:41 --> Helper loaded: url_helper
INFO - 2017-03-01 08:25:41 --> Model Class Initialized
ERROR - 2017-03-01 12:55:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/singleRequest', 'post', '{\"userId\":\"1\",\"donarId\":\"33\"}', '', '::1', 1488353141, 1)
ERROR - 2017-03-01 12:55:41 --> Undefined variable: send
ERROR - 2017-03-01 12:55:41 --> Severity: Notice --> Undefined variable: send C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 718
ERROR - 2017-03-01 12:55:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.43647694587708
WHERE `id` =0
INFO - 2017-03-01 08:26:08 --> Config Class Initialized
INFO - 2017-03-01 08:26:08 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:26:08 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:26:08 --> Utf8 Class Initialized
INFO - 2017-03-01 08:26:08 --> URI Class Initialized
INFO - 2017-03-01 08:26:08 --> Router Class Initialized
INFO - 2017-03-01 08:26:08 --> Output Class Initialized
INFO - 2017-03-01 08:26:08 --> Security Class Initialized
DEBUG - 2017-03-01 08:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:26:08 --> Input Class Initialized
INFO - 2017-03-01 08:26:08 --> Language Class Initialized
INFO - 2017-03-01 08:26:08 --> Loader Class Initialized
INFO - 2017-03-01 08:26:08 --> Helper loaded: common_helper
INFO - 2017-03-01 08:26:08 --> Database Driver Class Initialized
INFO - 2017-03-01 08:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:26:08 --> Controller Class Initialized
DEBUG - 2017-03-01 08:26:08 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:26:08 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:26:08 --> Database Driver Class Initialized
INFO - 2017-03-01 08:26:08 --> Model Class Initialized
INFO - 2017-03-01 08:26:08 --> Model Class Initialized
INFO - 2017-03-01 08:26:08 --> Helper loaded: url_helper
INFO - 2017-03-01 08:26:08 --> Model Class Initialized
ERROR - 2017-03-01 12:56:08 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/singleRequest', 'post', '{\"userId\":\"1\",\"donarId\":\"33\"}', '', '::1', 1488353168, 1)
ERROR - 2017-03-01 12:56:08 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.23446607589722
WHERE `id` =0
INFO - 2017-03-01 08:27:20 --> Config Class Initialized
INFO - 2017-03-01 08:27:20 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:27:20 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:27:20 --> Utf8 Class Initialized
INFO - 2017-03-01 08:27:20 --> URI Class Initialized
INFO - 2017-03-01 08:27:20 --> Router Class Initialized
INFO - 2017-03-01 08:27:20 --> Output Class Initialized
INFO - 2017-03-01 08:27:20 --> Security Class Initialized
DEBUG - 2017-03-01 08:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:27:20 --> Input Class Initialized
INFO - 2017-03-01 08:27:20 --> Language Class Initialized
INFO - 2017-03-01 08:27:20 --> Loader Class Initialized
INFO - 2017-03-01 08:27:20 --> Helper loaded: common_helper
INFO - 2017-03-01 08:27:20 --> Database Driver Class Initialized
INFO - 2017-03-01 08:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:27:20 --> Controller Class Initialized
DEBUG - 2017-03-01 08:27:20 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:27:20 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:27:20 --> Database Driver Class Initialized
INFO - 2017-03-01 08:27:20 --> Model Class Initialized
INFO - 2017-03-01 08:27:20 --> Model Class Initialized
INFO - 2017-03-01 08:27:20 --> Helper loaded: url_helper
INFO - 2017-03-01 08:27:20 --> Model Class Initialized
ERROR - 2017-03-01 12:57:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.011261940002441
WHERE `id` = ''
INFO - 2017-03-01 08:27:48 --> Config Class Initialized
INFO - 2017-03-01 08:27:48 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:27:48 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:27:48 --> Utf8 Class Initialized
INFO - 2017-03-01 08:27:48 --> URI Class Initialized
INFO - 2017-03-01 08:27:48 --> Router Class Initialized
INFO - 2017-03-01 08:27:48 --> Output Class Initialized
INFO - 2017-03-01 08:27:48 --> Security Class Initialized
DEBUG - 2017-03-01 08:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:27:48 --> Input Class Initialized
INFO - 2017-03-01 08:27:48 --> Language Class Initialized
INFO - 2017-03-01 08:27:48 --> Loader Class Initialized
INFO - 2017-03-01 08:27:48 --> Helper loaded: common_helper
INFO - 2017-03-01 08:27:48 --> Database Driver Class Initialized
INFO - 2017-03-01 08:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:27:48 --> Controller Class Initialized
DEBUG - 2017-03-01 08:27:48 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:27:48 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:27:48 --> Database Driver Class Initialized
INFO - 2017-03-01 08:27:48 --> Model Class Initialized
INFO - 2017-03-01 08:27:48 --> Model Class Initialized
INFO - 2017-03-01 08:27:48 --> Helper loaded: url_helper
INFO - 2017-03-01 08:27:48 --> Model Class Initialized
ERROR - 2017-03-01 12:57:48 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/bloodRequests', 'get', '{\"userId\":\"1\"}', '', '::1', 1488353268, 1)
ERROR - 2017-03-01 12:57:48 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.20374703407288
WHERE `id` =0
INFO - 2017-03-01 08:28:06 --> Config Class Initialized
INFO - 2017-03-01 08:28:06 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:28:06 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:28:06 --> Utf8 Class Initialized
INFO - 2017-03-01 08:28:06 --> URI Class Initialized
INFO - 2017-03-01 08:28:06 --> Router Class Initialized
INFO - 2017-03-01 08:28:06 --> Output Class Initialized
INFO - 2017-03-01 08:28:06 --> Security Class Initialized
DEBUG - 2017-03-01 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:28:06 --> Input Class Initialized
INFO - 2017-03-01 08:28:06 --> Language Class Initialized
INFO - 2017-03-01 08:28:06 --> Loader Class Initialized
INFO - 2017-03-01 08:28:06 --> Helper loaded: common_helper
INFO - 2017-03-01 08:28:06 --> Database Driver Class Initialized
INFO - 2017-03-01 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:28:06 --> Controller Class Initialized
DEBUG - 2017-03-01 08:28:06 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:28:06 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:28:06 --> Database Driver Class Initialized
INFO - 2017-03-01 08:28:06 --> Model Class Initialized
INFO - 2017-03-01 08:28:06 --> Model Class Initialized
INFO - 2017-03-01 08:28:06 --> Helper loaded: url_helper
INFO - 2017-03-01 08:28:06 --> Model Class Initialized
ERROR - 2017-03-01 12:58:06 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/singleRequest', 'post', '{\"userId\":\"1\",\"donarId\":\"33\"}', '', '::1', 1488353286, 1)
ERROR - 2017-03-01 12:58:06 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.14683294296265
WHERE `id` =0
INFO - 2017-03-01 08:28:10 --> Config Class Initialized
INFO - 2017-03-01 08:28:10 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:28:10 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:28:11 --> Utf8 Class Initialized
INFO - 2017-03-01 08:28:11 --> URI Class Initialized
INFO - 2017-03-01 08:28:11 --> Router Class Initialized
INFO - 2017-03-01 08:28:11 --> Output Class Initialized
INFO - 2017-03-01 08:28:11 --> Security Class Initialized
DEBUG - 2017-03-01 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:28:11 --> Input Class Initialized
INFO - 2017-03-01 08:28:11 --> Language Class Initialized
INFO - 2017-03-01 08:28:11 --> Loader Class Initialized
INFO - 2017-03-01 08:28:11 --> Helper loaded: common_helper
INFO - 2017-03-01 08:28:11 --> Database Driver Class Initialized
INFO - 2017-03-01 08:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:28:11 --> Controller Class Initialized
DEBUG - 2017-03-01 08:28:11 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:28:11 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:28:11 --> Database Driver Class Initialized
INFO - 2017-03-01 08:28:11 --> Model Class Initialized
INFO - 2017-03-01 08:28:11 --> Model Class Initialized
INFO - 2017-03-01 08:28:11 --> Helper loaded: url_helper
INFO - 2017-03-01 08:28:11 --> Model Class Initialized
ERROR - 2017-03-01 12:58:11 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/bloodRequests', 'get', '{\"userId\":\"1\"}', '', '::1', 1488353291, 1)
ERROR - 2017-03-01 12:58:11 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.19571399688721
WHERE `id` =0
INFO - 2017-03-01 08:29:07 --> Config Class Initialized
INFO - 2017-03-01 08:29:07 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:29:07 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:29:07 --> Utf8 Class Initialized
INFO - 2017-03-01 08:29:07 --> URI Class Initialized
INFO - 2017-03-01 08:29:07 --> Router Class Initialized
INFO - 2017-03-01 08:29:07 --> Output Class Initialized
INFO - 2017-03-01 08:29:07 --> Security Class Initialized
DEBUG - 2017-03-01 08:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:29:07 --> Input Class Initialized
INFO - 2017-03-01 08:29:07 --> Language Class Initialized
INFO - 2017-03-01 08:29:07 --> Loader Class Initialized
INFO - 2017-03-01 08:29:07 --> Helper loaded: common_helper
INFO - 2017-03-01 08:29:07 --> Database Driver Class Initialized
INFO - 2017-03-01 08:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:29:07 --> Controller Class Initialized
DEBUG - 2017-03-01 08:29:07 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:29:07 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:29:07 --> Database Driver Class Initialized
INFO - 2017-03-01 08:29:07 --> Model Class Initialized
INFO - 2017-03-01 08:29:07 --> Model Class Initialized
INFO - 2017-03-01 08:29:07 --> Helper loaded: url_helper
INFO - 2017-03-01 08:29:07 --> Model Class Initialized
ERROR - 2017-03-01 12:59:07 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/singleRequest', 'post', '{\"userId\":\"1\",\"donarId\":\"33\"}', '', '::1', 1488353347, 1)
ERROR - 2017-03-01 12:59:07 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.062513113021851
WHERE `id` =0
INFO - 2017-03-01 08:32:29 --> Config Class Initialized
INFO - 2017-03-01 08:32:29 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:32:29 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:32:29 --> Utf8 Class Initialized
INFO - 2017-03-01 08:32:29 --> URI Class Initialized
INFO - 2017-03-01 08:32:29 --> Router Class Initialized
INFO - 2017-03-01 08:32:29 --> Output Class Initialized
INFO - 2017-03-01 08:32:29 --> Security Class Initialized
DEBUG - 2017-03-01 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:32:29 --> Input Class Initialized
INFO - 2017-03-01 08:32:29 --> Language Class Initialized
ERROR - 2017-03-01 08:32:29 --> syntax error, unexpected '{'
ERROR - 2017-03-01 08:32:29 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 719
INFO - 2017-03-01 08:32:54 --> Config Class Initialized
INFO - 2017-03-01 08:32:54 --> Hooks Class Initialized
DEBUG - 2017-03-01 08:32:54 --> UTF-8 Support Enabled
INFO - 2017-03-01 08:32:54 --> Utf8 Class Initialized
INFO - 2017-03-01 08:32:54 --> URI Class Initialized
INFO - 2017-03-01 08:32:54 --> Router Class Initialized
INFO - 2017-03-01 08:32:54 --> Output Class Initialized
INFO - 2017-03-01 08:32:54 --> Security Class Initialized
DEBUG - 2017-03-01 08:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-01 08:32:54 --> Input Class Initialized
INFO - 2017-03-01 08:32:54 --> Language Class Initialized
INFO - 2017-03-01 08:32:54 --> Loader Class Initialized
INFO - 2017-03-01 08:32:54 --> Helper loaded: common_helper
INFO - 2017-03-01 08:32:54 --> Database Driver Class Initialized
INFO - 2017-03-01 08:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-01 08:32:54 --> Controller Class Initialized
DEBUG - 2017-03-01 08:32:54 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-01 08:32:54 --> Helper loaded: inflector_helper
INFO - 2017-03-01 08:32:54 --> Database Driver Class Initialized
INFO - 2017-03-01 08:32:54 --> Model Class Initialized
INFO - 2017-03-01 08:32:54 --> Model Class Initialized
INFO - 2017-03-01 08:32:54 --> Helper loaded: url_helper
INFO - 2017-03-01 08:32:54 --> Model Class Initialized
ERROR - 2017-03-01 13:02:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/singleRequest', 'post', '{\"userId\":\"1\",\"donarId\":\"33\"}', '', '::1', 1488353574, 1)
ERROR - 2017-03-01 13:02:55 --> Undefined variable: send
ERROR - 2017-03-01 13:02:55 --> Severity: Notice --> Undefined variable: send C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 718
ERROR - 2017-03-01 13:02:55 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.20423817634583
WHERE `id` =0
