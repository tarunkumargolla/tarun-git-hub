<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-17 14:54:34 --> Config Class Initialized
INFO - 2017-03-17 14:54:34 --> Hooks Class Initialized
DEBUG - 2017-03-17 14:54:34 --> UTF-8 Support Enabled
INFO - 2017-03-17 14:54:34 --> Utf8 Class Initialized
INFO - 2017-03-17 14:54:34 --> URI Class Initialized
INFO - 2017-03-17 14:54:34 --> Router Class Initialized
INFO - 2017-03-17 14:54:34 --> Output Class Initialized
INFO - 2017-03-17 14:54:34 --> Security Class Initialized
DEBUG - 2017-03-17 14:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 14:54:34 --> Input Class Initialized
INFO - 2017-03-17 14:54:34 --> Language Class Initialized
INFO - 2017-03-17 14:54:34 --> Loader Class Initialized
INFO - 2017-03-17 14:54:34 --> Helper loaded: common_helper
INFO - 2017-03-17 14:54:34 --> Database Driver Class Initialized
INFO - 2017-03-17 14:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 14:54:34 --> Controller Class Initialized
DEBUG - 2017-03-17 14:54:34 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-17 14:54:34 --> Helper loaded: inflector_helper
INFO - 2017-03-17 14:54:34 --> Database Driver Class Initialized
INFO - 2017-03-17 14:54:34 --> Model Class Initialized
INFO - 2017-03-17 14:54:34 --> Model Class Initialized
INFO - 2017-03-17 14:54:34 --> Helper loaded: url_helper
INFO - 2017-03-17 14:54:34 --> Model Class Initialized
ERROR - 2017-03-17 19:24:34 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', NULL, '', '::1', 1489758874, 1)
ERROR - 2017-03-17 19:24:34 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.013633966445923
WHERE `id` =0
INFO - 2017-03-17 14:54:41 --> Config Class Initialized
INFO - 2017-03-17 14:54:41 --> Hooks Class Initialized
DEBUG - 2017-03-17 14:54:41 --> UTF-8 Support Enabled
INFO - 2017-03-17 14:54:41 --> Utf8 Class Initialized
INFO - 2017-03-17 14:54:41 --> URI Class Initialized
INFO - 2017-03-17 14:54:41 --> Router Class Initialized
INFO - 2017-03-17 14:54:41 --> Output Class Initialized
INFO - 2017-03-17 14:54:41 --> Security Class Initialized
DEBUG - 2017-03-17 14:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 14:54:41 --> Input Class Initialized
INFO - 2017-03-17 14:54:41 --> Language Class Initialized
INFO - 2017-03-17 14:54:41 --> Loader Class Initialized
INFO - 2017-03-17 14:54:41 --> Helper loaded: common_helper
INFO - 2017-03-17 14:54:41 --> Database Driver Class Initialized
INFO - 2017-03-17 14:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 14:54:41 --> Controller Class Initialized
DEBUG - 2017-03-17 14:54:41 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-17 14:54:41 --> Helper loaded: inflector_helper
INFO - 2017-03-17 14:54:41 --> Database Driver Class Initialized
INFO - 2017-03-17 14:54:41 --> Model Class Initialized
INFO - 2017-03-17 14:54:41 --> Model Class Initialized
INFO - 2017-03-17 14:54:41 --> Helper loaded: url_helper
INFO - 2017-03-17 14:54:41 --> Model Class Initialized
ERROR - 2017-03-17 19:24:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"2\"}', '', '::1', 1489758881, 1)
ERROR - 2017-03-17 19:24:41 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '2'
 LIMIT 1
ERROR - 2017-03-17 19:24:41 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-03-17 19:24:41 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-03-17 14:54:51 --> Config Class Initialized
INFO - 2017-03-17 14:54:51 --> Hooks Class Initialized
DEBUG - 2017-03-17 14:54:51 --> UTF-8 Support Enabled
INFO - 2017-03-17 14:54:51 --> Utf8 Class Initialized
INFO - 2017-03-17 14:54:51 --> URI Class Initialized
INFO - 2017-03-17 14:54:51 --> Router Class Initialized
INFO - 2017-03-17 14:54:51 --> Output Class Initialized
INFO - 2017-03-17 14:54:51 --> Security Class Initialized
DEBUG - 2017-03-17 14:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 14:54:51 --> Input Class Initialized
INFO - 2017-03-17 14:54:51 --> Language Class Initialized
INFO - 2017-03-17 14:54:51 --> Loader Class Initialized
INFO - 2017-03-17 14:54:51 --> Helper loaded: common_helper
INFO - 2017-03-17 14:54:51 --> Database Driver Class Initialized
INFO - 2017-03-17 14:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 14:54:51 --> Controller Class Initialized
DEBUG - 2017-03-17 14:54:51 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-17 14:54:51 --> Helper loaded: inflector_helper
INFO - 2017-03-17 14:54:51 --> Database Driver Class Initialized
INFO - 2017-03-17 14:54:51 --> Model Class Initialized
INFO - 2017-03-17 14:54:51 --> Model Class Initialized
INFO - 2017-03-17 14:54:51 --> Helper loaded: url_helper
ERROR - 2017-03-17 19:24:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0086629390716553
WHERE `id` = ''
INFO - 2017-03-17 14:55:05 --> Config Class Initialized
INFO - 2017-03-17 14:55:05 --> Hooks Class Initialized
DEBUG - 2017-03-17 14:55:05 --> UTF-8 Support Enabled
INFO - 2017-03-17 14:55:05 --> Utf8 Class Initialized
INFO - 2017-03-17 14:55:05 --> URI Class Initialized
INFO - 2017-03-17 14:55:05 --> Router Class Initialized
INFO - 2017-03-17 14:55:05 --> Output Class Initialized
INFO - 2017-03-17 14:55:05 --> Security Class Initialized
DEBUG - 2017-03-17 14:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 14:55:05 --> Input Class Initialized
INFO - 2017-03-17 14:55:05 --> Language Class Initialized
INFO - 2017-03-17 14:55:05 --> Loader Class Initialized
INFO - 2017-03-17 14:55:05 --> Helper loaded: common_helper
INFO - 2017-03-17 14:55:05 --> Database Driver Class Initialized
INFO - 2017-03-17 14:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 14:55:05 --> Controller Class Initialized
DEBUG - 2017-03-17 14:55:05 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-17 14:55:05 --> Helper loaded: inflector_helper
INFO - 2017-03-17 14:55:05 --> Database Driver Class Initialized
INFO - 2017-03-17 14:55:05 --> Model Class Initialized
INFO - 2017-03-17 14:55:05 --> Model Class Initialized
INFO - 2017-03-17 14:55:05 --> Helper loaded: url_helper
INFO - 2017-03-17 14:55:05 --> Model Class Initialized
ERROR - 2017-03-17 19:25:05 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"2\"}', '', '::1', 1489758905, 1)
ERROR - 2017-03-17 19:25:05 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '2'
 LIMIT 1
ERROR - 2017-03-17 19:25:05 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-03-17 19:25:05 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-03-17 14:55:07 --> Config Class Initialized
INFO - 2017-03-17 14:55:07 --> Hooks Class Initialized
DEBUG - 2017-03-17 14:55:07 --> UTF-8 Support Enabled
INFO - 2017-03-17 14:55:07 --> Utf8 Class Initialized
INFO - 2017-03-17 14:55:07 --> URI Class Initialized
INFO - 2017-03-17 14:55:07 --> Router Class Initialized
INFO - 2017-03-17 14:55:07 --> Output Class Initialized
INFO - 2017-03-17 14:55:07 --> Security Class Initialized
DEBUG - 2017-03-17 14:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-17 14:55:07 --> Input Class Initialized
INFO - 2017-03-17 14:55:07 --> Language Class Initialized
INFO - 2017-03-17 14:55:07 --> Loader Class Initialized
INFO - 2017-03-17 14:55:07 --> Helper loaded: common_helper
INFO - 2017-03-17 14:55:07 --> Database Driver Class Initialized
INFO - 2017-03-17 14:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-17 14:55:07 --> Controller Class Initialized
DEBUG - 2017-03-17 14:55:07 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-17 14:55:07 --> Helper loaded: inflector_helper
INFO - 2017-03-17 14:55:07 --> Database Driver Class Initialized
INFO - 2017-03-17 14:55:07 --> Model Class Initialized
INFO - 2017-03-17 14:55:07 --> Model Class Initialized
INFO - 2017-03-17 14:55:07 --> Helper loaded: url_helper
INFO - 2017-03-17 14:55:07 --> Model Class Initialized
ERROR - 2017-03-17 19:25:07 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', NULL, '', '::1', 1489758907, 1)
ERROR - 2017-03-17 19:25:07 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.01085901260376
WHERE `id` =0
