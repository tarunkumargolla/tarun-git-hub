<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-20 06:52:25 --> Config Class Initialized
INFO - 2017-03-20 06:52:25 --> Hooks Class Initialized
DEBUG - 2017-03-20 06:52:25 --> UTF-8 Support Enabled
INFO - 2017-03-20 06:52:25 --> Utf8 Class Initialized
INFO - 2017-03-20 06:52:25 --> URI Class Initialized
INFO - 2017-03-20 06:52:25 --> Router Class Initialized
INFO - 2017-03-20 06:52:25 --> Output Class Initialized
INFO - 2017-03-20 06:52:25 --> Security Class Initialized
DEBUG - 2017-03-20 06:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 06:52:25 --> Input Class Initialized
INFO - 2017-03-20 06:52:25 --> Language Class Initialized
INFO - 2017-03-20 06:52:25 --> Loader Class Initialized
INFO - 2017-03-20 06:52:25 --> Helper loaded: common_helper
INFO - 2017-03-20 06:52:25 --> Database Driver Class Initialized
INFO - 2017-03-20 06:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 06:52:25 --> Controller Class Initialized
DEBUG - 2017-03-20 06:52:25 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 06:52:25 --> Helper loaded: inflector_helper
INFO - 2017-03-20 06:52:25 --> Database Driver Class Initialized
INFO - 2017-03-20 06:52:25 --> Model Class Initialized
INFO - 2017-03-20 06:52:25 --> Model Class Initialized
INFO - 2017-03-20 06:52:25 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:22:25 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/signup', 'post', '{\"name\":\"ashiya\",\"phoneNumber\":\"8985716639\",\"countryCode\":\"+91\"}', '', '::1', 1489989145, 1)
INFO - 2017-03-20 11:22:25 --> Helper loaded: form_helper
INFO - 2017-03-20 11:22:25 --> Form Validation Class Initialized
INFO - 2017-03-20 11:22:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:22:26 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.63789391517639
WHERE `id` =0
INFO - 2017-03-20 06:54:01 --> Config Class Initialized
INFO - 2017-03-20 06:54:01 --> Hooks Class Initialized
DEBUG - 2017-03-20 06:54:01 --> UTF-8 Support Enabled
INFO - 2017-03-20 06:54:01 --> Utf8 Class Initialized
INFO - 2017-03-20 06:54:01 --> URI Class Initialized
INFO - 2017-03-20 06:54:01 --> Router Class Initialized
INFO - 2017-03-20 06:54:01 --> Output Class Initialized
INFO - 2017-03-20 06:54:01 --> Security Class Initialized
DEBUG - 2017-03-20 06:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 06:54:01 --> Input Class Initialized
INFO - 2017-03-20 06:54:01 --> Language Class Initialized
INFO - 2017-03-20 06:54:01 --> Loader Class Initialized
INFO - 2017-03-20 06:54:01 --> Helper loaded: common_helper
INFO - 2017-03-20 06:54:01 --> Database Driver Class Initialized
INFO - 2017-03-20 06:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 06:54:01 --> Controller Class Initialized
DEBUG - 2017-03-20 06:54:01 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 06:54:01 --> Helper loaded: inflector_helper
INFO - 2017-03-20 06:54:01 --> Database Driver Class Initialized
INFO - 2017-03-20 06:54:01 --> Model Class Initialized
INFO - 2017-03-20 06:54:01 --> Model Class Initialized
INFO - 2017-03-20 06:54:01 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:24:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/signup', 'post', '{\"name\":\"ashiya\",\"phoneNumber\":\"8985716639\",\"countryCode\":\"+91\"}', '', '::1', 1489989241, 1)
INFO - 2017-03-20 11:24:01 --> Helper loaded: form_helper
INFO - 2017-03-20 11:24:01 --> Form Validation Class Initialized
INFO - 2017-03-20 11:24:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:24:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.39262008666992
WHERE `id` =0
INFO - 2017-03-20 06:54:58 --> Config Class Initialized
INFO - 2017-03-20 06:54:58 --> Hooks Class Initialized
DEBUG - 2017-03-20 06:54:58 --> UTF-8 Support Enabled
INFO - 2017-03-20 06:54:58 --> Utf8 Class Initialized
INFO - 2017-03-20 06:54:58 --> URI Class Initialized
INFO - 2017-03-20 06:54:58 --> Router Class Initialized
INFO - 2017-03-20 06:54:58 --> Output Class Initialized
INFO - 2017-03-20 06:54:58 --> Security Class Initialized
DEBUG - 2017-03-20 06:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 06:54:58 --> Input Class Initialized
INFO - 2017-03-20 06:54:58 --> Language Class Initialized
INFO - 2017-03-20 06:54:58 --> Loader Class Initialized
INFO - 2017-03-20 06:54:58 --> Helper loaded: common_helper
INFO - 2017-03-20 06:54:58 --> Database Driver Class Initialized
INFO - 2017-03-20 06:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 06:54:58 --> Controller Class Initialized
DEBUG - 2017-03-20 06:54:58 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 06:54:58 --> Helper loaded: inflector_helper
INFO - 2017-03-20 06:54:58 --> Database Driver Class Initialized
INFO - 2017-03-20 06:54:58 --> Model Class Initialized
INFO - 2017-03-20 06:54:58 --> Model Class Initialized
INFO - 2017-03-20 06:54:58 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:24:58 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"12\"}', '', '::1', 1489989298, 1)
INFO - 2017-03-20 11:24:58 --> Helper loaded: form_helper
INFO - 2017-03-20 11:24:58 --> Form Validation Class Initialized
INFO - 2017-03-20 11:24:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:24:58 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.10441589355469
WHERE `id` =0
INFO - 2017-03-20 06:59:44 --> Config Class Initialized
INFO - 2017-03-20 06:59:44 --> Hooks Class Initialized
DEBUG - 2017-03-20 06:59:44 --> UTF-8 Support Enabled
INFO - 2017-03-20 06:59:44 --> Utf8 Class Initialized
INFO - 2017-03-20 06:59:44 --> URI Class Initialized
INFO - 2017-03-20 06:59:44 --> Router Class Initialized
INFO - 2017-03-20 06:59:44 --> Output Class Initialized
INFO - 2017-03-20 06:59:44 --> Security Class Initialized
DEBUG - 2017-03-20 06:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 06:59:44 --> Input Class Initialized
INFO - 2017-03-20 06:59:44 --> Language Class Initialized
INFO - 2017-03-20 06:59:44 --> Loader Class Initialized
INFO - 2017-03-20 06:59:44 --> Helper loaded: common_helper
INFO - 2017-03-20 06:59:44 --> Database Driver Class Initialized
INFO - 2017-03-20 06:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 06:59:44 --> Controller Class Initialized
DEBUG - 2017-03-20 06:59:44 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 06:59:44 --> Helper loaded: inflector_helper
INFO - 2017-03-20 06:59:44 --> Database Driver Class Initialized
INFO - 2017-03-20 06:59:44 --> Model Class Initialized
INFO - 2017-03-20 06:59:44 --> Model Class Initialized
INFO - 2017-03-20 06:59:44 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:29:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"12\"}', '', '::1', 1489989584, 1)
INFO - 2017-03-20 11:29:44 --> Helper loaded: form_helper
INFO - 2017-03-20 11:29:44 --> Form Validation Class Initialized
INFO - 2017-03-20 11:29:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:29:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.019778966903687
WHERE `id` =0
INFO - 2017-03-20 06:59:54 --> Config Class Initialized
INFO - 2017-03-20 06:59:54 --> Hooks Class Initialized
DEBUG - 2017-03-20 06:59:54 --> UTF-8 Support Enabled
INFO - 2017-03-20 06:59:54 --> Utf8 Class Initialized
INFO - 2017-03-20 06:59:54 --> URI Class Initialized
INFO - 2017-03-20 06:59:54 --> Router Class Initialized
INFO - 2017-03-20 06:59:54 --> Output Class Initialized
INFO - 2017-03-20 06:59:54 --> Security Class Initialized
DEBUG - 2017-03-20 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 06:59:54 --> Input Class Initialized
INFO - 2017-03-20 06:59:54 --> Language Class Initialized
INFO - 2017-03-20 06:59:54 --> Loader Class Initialized
INFO - 2017-03-20 06:59:54 --> Helper loaded: common_helper
INFO - 2017-03-20 06:59:54 --> Database Driver Class Initialized
INFO - 2017-03-20 06:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 06:59:54 --> Controller Class Initialized
DEBUG - 2017-03-20 06:59:54 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 06:59:54 --> Helper loaded: inflector_helper
INFO - 2017-03-20 06:59:54 --> Database Driver Class Initialized
INFO - 2017-03-20 06:59:54 --> Model Class Initialized
INFO - 2017-03-20 06:59:54 --> Model Class Initialized
INFO - 2017-03-20 06:59:54 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:29:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"12\"}', '', '::1', 1489989594, 1)
INFO - 2017-03-20 11:29:54 --> Helper loaded: form_helper
INFO - 2017-03-20 11:29:54 --> Form Validation Class Initialized
INFO - 2017-03-20 11:29:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:29:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.013720989227295
WHERE `id` =0
INFO - 2017-03-20 07:00:56 --> Config Class Initialized
INFO - 2017-03-20 07:00:56 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:00:56 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:00:56 --> Utf8 Class Initialized
INFO - 2017-03-20 07:00:56 --> URI Class Initialized
INFO - 2017-03-20 07:00:56 --> Router Class Initialized
INFO - 2017-03-20 07:00:56 --> Output Class Initialized
INFO - 2017-03-20 07:00:56 --> Security Class Initialized
DEBUG - 2017-03-20 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:00:56 --> Input Class Initialized
INFO - 2017-03-20 07:00:56 --> Language Class Initialized
INFO - 2017-03-20 07:00:56 --> Loader Class Initialized
INFO - 2017-03-20 07:00:56 --> Helper loaded: common_helper
INFO - 2017-03-20 07:00:56 --> Database Driver Class Initialized
INFO - 2017-03-20 07:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:00:56 --> Controller Class Initialized
DEBUG - 2017-03-20 07:00:56 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:00:56 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:00:56 --> Database Driver Class Initialized
INFO - 2017-03-20 07:00:56 --> Model Class Initialized
INFO - 2017-03-20 07:00:56 --> Model Class Initialized
INFO - 2017-03-20 07:00:56 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:30:56 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"12\"}', '', '::1', 1489989656, 1)
INFO - 2017-03-20 11:30:56 --> Helper loaded: form_helper
INFO - 2017-03-20 11:30:56 --> Form Validation Class Initialized
INFO - 2017-03-20 11:30:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:30:56 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.01692008972168
WHERE `id` =0
INFO - 2017-03-20 07:01:21 --> Config Class Initialized
INFO - 2017-03-20 07:01:21 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:01:21 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:01:21 --> Utf8 Class Initialized
INFO - 2017-03-20 07:01:21 --> URI Class Initialized
INFO - 2017-03-20 07:01:21 --> Router Class Initialized
INFO - 2017-03-20 07:01:21 --> Output Class Initialized
INFO - 2017-03-20 07:01:21 --> Security Class Initialized
DEBUG - 2017-03-20 07:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:01:21 --> Input Class Initialized
INFO - 2017-03-20 07:01:21 --> Language Class Initialized
INFO - 2017-03-20 07:01:21 --> Loader Class Initialized
INFO - 2017-03-20 07:01:21 --> Helper loaded: common_helper
INFO - 2017-03-20 07:01:21 --> Database Driver Class Initialized
INFO - 2017-03-20 07:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:01:21 --> Controller Class Initialized
DEBUG - 2017-03-20 07:01:21 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:01:22 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:01:22 --> Database Driver Class Initialized
INFO - 2017-03-20 07:01:22 --> Model Class Initialized
INFO - 2017-03-20 07:01:22 --> Model Class Initialized
INFO - 2017-03-20 07:01:22 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:31:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"13\"}', '', '::1', 1489989682, 1)
INFO - 2017-03-20 11:31:22 --> Helper loaded: form_helper
INFO - 2017-03-20 11:31:22 --> Form Validation Class Initialized
INFO - 2017-03-20 11:31:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:31:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.016027927398682
WHERE `id` =0
INFO - 2017-03-20 07:01:38 --> Config Class Initialized
INFO - 2017-03-20 07:01:38 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:01:38 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:01:38 --> Utf8 Class Initialized
INFO - 2017-03-20 07:01:38 --> URI Class Initialized
INFO - 2017-03-20 07:01:38 --> Router Class Initialized
INFO - 2017-03-20 07:01:38 --> Output Class Initialized
INFO - 2017-03-20 07:01:38 --> Security Class Initialized
DEBUG - 2017-03-20 07:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:01:38 --> Input Class Initialized
INFO - 2017-03-20 07:01:38 --> Language Class Initialized
INFO - 2017-03-20 07:01:38 --> Loader Class Initialized
INFO - 2017-03-20 07:01:38 --> Helper loaded: common_helper
INFO - 2017-03-20 07:01:38 --> Database Driver Class Initialized
INFO - 2017-03-20 07:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:01:38 --> Controller Class Initialized
DEBUG - 2017-03-20 07:01:38 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:01:38 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:01:38 --> Database Driver Class Initialized
INFO - 2017-03-20 07:01:38 --> Model Class Initialized
INFO - 2017-03-20 07:01:38 --> Model Class Initialized
INFO - 2017-03-20 07:01:38 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:31:38 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"13\"}', '', '::1', 1489989698, 1)
INFO - 2017-03-20 11:31:38 --> Helper loaded: form_helper
INFO - 2017-03-20 11:31:38 --> Form Validation Class Initialized
INFO - 2017-03-20 11:31:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:31:38 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.018354177474976
WHERE `id` =0
INFO - 2017-03-20 07:01:50 --> Config Class Initialized
INFO - 2017-03-20 07:01:50 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:01:50 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:01:50 --> Utf8 Class Initialized
INFO - 2017-03-20 07:01:50 --> URI Class Initialized
INFO - 2017-03-20 07:01:50 --> Router Class Initialized
INFO - 2017-03-20 07:01:50 --> Output Class Initialized
INFO - 2017-03-20 07:01:50 --> Security Class Initialized
DEBUG - 2017-03-20 07:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:01:50 --> Input Class Initialized
INFO - 2017-03-20 07:01:50 --> Language Class Initialized
INFO - 2017-03-20 07:01:50 --> Loader Class Initialized
INFO - 2017-03-20 07:01:50 --> Helper loaded: common_helper
INFO - 2017-03-20 07:01:50 --> Database Driver Class Initialized
INFO - 2017-03-20 07:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:01:50 --> Controller Class Initialized
DEBUG - 2017-03-20 07:01:50 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:01:50 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:01:50 --> Database Driver Class Initialized
INFO - 2017-03-20 07:01:50 --> Model Class Initialized
INFO - 2017-03-20 07:01:50 --> Model Class Initialized
INFO - 2017-03-20 07:01:50 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:31:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"13\"}', '', '::1', 1489989710, 1)
INFO - 2017-03-20 11:31:50 --> Helper loaded: form_helper
INFO - 2017-03-20 11:31:50 --> Form Validation Class Initialized
INFO - 2017-03-20 11:31:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:31:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.017168998718262
WHERE `id` =0
INFO - 2017-03-20 07:04:51 --> Config Class Initialized
INFO - 2017-03-20 07:04:51 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:04:51 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:04:51 --> Utf8 Class Initialized
INFO - 2017-03-20 07:04:51 --> URI Class Initialized
INFO - 2017-03-20 07:04:51 --> Router Class Initialized
INFO - 2017-03-20 07:04:51 --> Output Class Initialized
INFO - 2017-03-20 07:04:51 --> Security Class Initialized
DEBUG - 2017-03-20 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:04:51 --> Input Class Initialized
INFO - 2017-03-20 07:04:51 --> Language Class Initialized
INFO - 2017-03-20 07:04:51 --> Loader Class Initialized
INFO - 2017-03-20 07:04:51 --> Helper loaded: common_helper
INFO - 2017-03-20 07:04:51 --> Database Driver Class Initialized
INFO - 2017-03-20 07:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:04:51 --> Controller Class Initialized
DEBUG - 2017-03-20 07:04:51 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:04:51 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:04:51 --> Database Driver Class Initialized
INFO - 2017-03-20 07:04:51 --> Model Class Initialized
INFO - 2017-03-20 07:04:51 --> Model Class Initialized
INFO - 2017-03-20 07:04:51 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:34:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/signup', 'post', '{\"name\":\"ashiya\",\"phoneNumber\":\"8985716639\",\"countryCode\":\"+91\"}', '', '::1', 1489989891, 1)
INFO - 2017-03-20 11:34:51 --> Helper loaded: form_helper
INFO - 2017-03-20 11:34:51 --> Form Validation Class Initialized
INFO - 2017-03-20 11:34:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:34:52 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.36609506607056
WHERE `id` =0
INFO - 2017-03-20 07:05:15 --> Config Class Initialized
INFO - 2017-03-20 07:05:15 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:05:15 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:05:15 --> Utf8 Class Initialized
INFO - 2017-03-20 07:05:15 --> URI Class Initialized
INFO - 2017-03-20 07:05:15 --> Router Class Initialized
INFO - 2017-03-20 07:05:15 --> Output Class Initialized
INFO - 2017-03-20 07:05:15 --> Security Class Initialized
DEBUG - 2017-03-20 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:05:15 --> Input Class Initialized
INFO - 2017-03-20 07:05:15 --> Language Class Initialized
INFO - 2017-03-20 07:05:15 --> Loader Class Initialized
INFO - 2017-03-20 07:05:15 --> Helper loaded: common_helper
INFO - 2017-03-20 07:05:15 --> Database Driver Class Initialized
INFO - 2017-03-20 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:05:15 --> Controller Class Initialized
DEBUG - 2017-03-20 07:05:15 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:05:15 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:05:15 --> Database Driver Class Initialized
INFO - 2017-03-20 07:05:15 --> Model Class Initialized
INFO - 2017-03-20 07:05:15 --> Model Class Initialized
INFO - 2017-03-20 07:05:15 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:35:15 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"323510\",\"userId\":\"13\"}', '', '::1', 1489989915, 1)
INFO - 2017-03-20 11:35:15 --> Helper loaded: form_helper
INFO - 2017-03-20 11:35:15 --> Form Validation Class Initialized
INFO - 2017-03-20 11:35:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:35:15 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.018371105194092
WHERE `id` =0
INFO - 2017-03-20 07:05:20 --> Config Class Initialized
INFO - 2017-03-20 07:05:20 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:05:20 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:05:20 --> Utf8 Class Initialized
INFO - 2017-03-20 07:05:20 --> URI Class Initialized
INFO - 2017-03-20 07:05:20 --> Router Class Initialized
INFO - 2017-03-20 07:05:20 --> Output Class Initialized
INFO - 2017-03-20 07:05:20 --> Security Class Initialized
DEBUG - 2017-03-20 07:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:05:20 --> Input Class Initialized
INFO - 2017-03-20 07:05:20 --> Language Class Initialized
INFO - 2017-03-20 07:05:20 --> Loader Class Initialized
INFO - 2017-03-20 07:05:20 --> Helper loaded: common_helper
INFO - 2017-03-20 07:05:20 --> Database Driver Class Initialized
INFO - 2017-03-20 07:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:05:20 --> Controller Class Initialized
DEBUG - 2017-03-20 07:05:20 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:05:20 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:05:20 --> Database Driver Class Initialized
INFO - 2017-03-20 07:05:20 --> Model Class Initialized
INFO - 2017-03-20 07:05:20 --> Model Class Initialized
INFO - 2017-03-20 07:05:20 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:35:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/authenticationByOtp', 'post', '{\"otp\":\"123456\",\"userId\":\"13\"}', '', '::1', 1489989920, 1)
INFO - 2017-03-20 11:35:20 --> Helper loaded: form_helper
INFO - 2017-03-20 11:35:20 --> Form Validation Class Initialized
INFO - 2017-03-20 11:35:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:35:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.12461805343628
WHERE `id` =0
INFO - 2017-03-20 07:06:05 --> Config Class Initialized
INFO - 2017-03-20 07:06:05 --> Hooks Class Initialized
DEBUG - 2017-03-20 07:06:05 --> UTF-8 Support Enabled
INFO - 2017-03-20 07:06:05 --> Utf8 Class Initialized
INFO - 2017-03-20 07:06:05 --> URI Class Initialized
INFO - 2017-03-20 07:06:05 --> Router Class Initialized
INFO - 2017-03-20 07:06:05 --> Output Class Initialized
INFO - 2017-03-20 07:06:05 --> Security Class Initialized
DEBUG - 2017-03-20 07:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 07:06:05 --> Input Class Initialized
INFO - 2017-03-20 07:06:05 --> Language Class Initialized
INFO - 2017-03-20 07:06:05 --> Loader Class Initialized
INFO - 2017-03-20 07:06:05 --> Helper loaded: common_helper
INFO - 2017-03-20 07:06:05 --> Database Driver Class Initialized
INFO - 2017-03-20 07:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 07:06:05 --> Controller Class Initialized
DEBUG - 2017-03-20 07:06:05 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 07:06:05 --> Helper loaded: inflector_helper
INFO - 2017-03-20 07:06:05 --> Database Driver Class Initialized
INFO - 2017-03-20 07:06:05 --> Model Class Initialized
INFO - 2017-03-20 07:06:05 --> Model Class Initialized
INFO - 2017-03-20 07:06:05 --> Helper loaded: url_helper
ERROR - 2017-03-20 11:36:05 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/signup', 'post', '{\"name\":\"ashiya\",\"phoneNumber\":\"7729048729\",\"countryCode\":\"+91\"}', '', '::1', 1489989965, 1)
INFO - 2017-03-20 11:36:05 --> Helper loaded: form_helper
INFO - 2017-03-20 11:36:05 --> Form Validation Class Initialized
INFO - 2017-03-20 11:36:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 11:36:06 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.45003700256348
WHERE `id` =0
INFO - 2017-03-20 10:17:50 --> Config Class Initialized
INFO - 2017-03-20 10:17:50 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:17:50 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:17:50 --> Utf8 Class Initialized
INFO - 2017-03-20 10:17:50 --> URI Class Initialized
INFO - 2017-03-20 10:17:50 --> Router Class Initialized
INFO - 2017-03-20 10:17:50 --> Output Class Initialized
INFO - 2017-03-20 10:17:50 --> Security Class Initialized
DEBUG - 2017-03-20 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:17:50 --> Input Class Initialized
INFO - 2017-03-20 10:17:50 --> Language Class Initialized
INFO - 2017-03-20 10:17:50 --> Loader Class Initialized
INFO - 2017-03-20 10:17:50 --> Helper loaded: common_helper
INFO - 2017-03-20 10:17:50 --> Database Driver Class Initialized
INFO - 2017-03-20 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:17:50 --> Controller Class Initialized
DEBUG - 2017-03-20 10:17:50 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:17:50 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:17:50 --> Database Driver Class Initialized
INFO - 2017-03-20 10:17:50 --> Model Class Initialized
INFO - 2017-03-20 10:17:50 --> Model Class Initialized
INFO - 2017-03-20 10:17:50 --> Helper loaded: url_helper
INFO - 2017-03-20 10:17:50 --> Model Class Initialized
ERROR - 2017-03-20 14:47:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001470, 1)
INFO - 2017-03-20 14:47:50 --> Helper loaded: form_helper
INFO - 2017-03-20 14:47:50 --> Form Validation Class Initialized
INFO - 2017-03-20 14:47:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:47:50 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '11'
 LIMIT 1
ERROR - 2017-03-20 14:47:50 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-03-20 14:47:50 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-03-20 10:19:10 --> Config Class Initialized
INFO - 2017-03-20 10:19:10 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:19:10 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:19:10 --> Utf8 Class Initialized
INFO - 2017-03-20 10:19:10 --> URI Class Initialized
INFO - 2017-03-20 10:19:10 --> Router Class Initialized
INFO - 2017-03-20 10:19:10 --> Output Class Initialized
INFO - 2017-03-20 10:19:10 --> Security Class Initialized
DEBUG - 2017-03-20 10:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:19:10 --> Input Class Initialized
INFO - 2017-03-20 10:19:10 --> Language Class Initialized
INFO - 2017-03-20 10:19:10 --> Loader Class Initialized
INFO - 2017-03-20 10:19:10 --> Helper loaded: common_helper
INFO - 2017-03-20 10:19:10 --> Database Driver Class Initialized
INFO - 2017-03-20 10:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:19:10 --> Controller Class Initialized
DEBUG - 2017-03-20 10:19:10 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:19:10 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:19:10 --> Database Driver Class Initialized
INFO - 2017-03-20 10:19:10 --> Model Class Initialized
INFO - 2017-03-20 10:19:10 --> Model Class Initialized
INFO - 2017-03-20 10:19:10 --> Helper loaded: url_helper
INFO - 2017-03-20 10:19:10 --> Model Class Initialized
ERROR - 2017-03-20 14:49:10 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001550, 1)
INFO - 2017-03-20 14:49:10 --> Helper loaded: form_helper
INFO - 2017-03-20 14:49:10 --> Form Validation Class Initialized
INFO - 2017-03-20 14:49:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:49:10 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.020753145217896
WHERE `id` =0
INFO - 2017-03-20 10:19:26 --> Config Class Initialized
INFO - 2017-03-20 10:19:26 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:19:26 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:19:26 --> Utf8 Class Initialized
INFO - 2017-03-20 10:19:26 --> URI Class Initialized
INFO - 2017-03-20 10:19:26 --> Router Class Initialized
INFO - 2017-03-20 10:19:26 --> Output Class Initialized
INFO - 2017-03-20 10:19:26 --> Security Class Initialized
DEBUG - 2017-03-20 10:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:19:26 --> Input Class Initialized
INFO - 2017-03-20 10:19:26 --> Language Class Initialized
INFO - 2017-03-20 10:19:26 --> Loader Class Initialized
INFO - 2017-03-20 10:19:26 --> Helper loaded: common_helper
INFO - 2017-03-20 10:19:26 --> Database Driver Class Initialized
INFO - 2017-03-20 10:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:19:26 --> Controller Class Initialized
DEBUG - 2017-03-20 10:19:26 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:19:26 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:19:26 --> Database Driver Class Initialized
INFO - 2017-03-20 10:19:26 --> Model Class Initialized
INFO - 2017-03-20 10:19:26 --> Model Class Initialized
INFO - 2017-03-20 10:19:26 --> Helper loaded: url_helper
INFO - 2017-03-20 10:19:26 --> Model Class Initialized
ERROR - 2017-03-20 14:49:26 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001566, 1)
INFO - 2017-03-20 14:49:26 --> Helper loaded: form_helper
INFO - 2017-03-20 14:49:26 --> Form Validation Class Initialized
INFO - 2017-03-20 14:49:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:49:26 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.018980979919434
WHERE `id` =0
INFO - 2017-03-20 10:19:40 --> Config Class Initialized
INFO - 2017-03-20 10:19:40 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:19:40 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:19:40 --> Utf8 Class Initialized
INFO - 2017-03-20 10:19:40 --> URI Class Initialized
INFO - 2017-03-20 10:19:40 --> Router Class Initialized
INFO - 2017-03-20 10:19:40 --> Output Class Initialized
INFO - 2017-03-20 10:19:40 --> Security Class Initialized
DEBUG - 2017-03-20 10:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:19:40 --> Input Class Initialized
INFO - 2017-03-20 10:19:40 --> Language Class Initialized
INFO - 2017-03-20 10:19:40 --> Loader Class Initialized
INFO - 2017-03-20 10:19:40 --> Helper loaded: common_helper
INFO - 2017-03-20 10:19:40 --> Database Driver Class Initialized
INFO - 2017-03-20 10:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:19:40 --> Controller Class Initialized
DEBUG - 2017-03-20 10:19:40 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:19:40 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:19:40 --> Database Driver Class Initialized
INFO - 2017-03-20 10:19:40 --> Model Class Initialized
INFO - 2017-03-20 10:19:40 --> Model Class Initialized
INFO - 2017-03-20 10:19:40 --> Helper loaded: url_helper
INFO - 2017-03-20 10:19:40 --> Model Class Initialized
ERROR - 2017-03-20 14:49:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001580, 1)
INFO - 2017-03-20 14:49:40 --> Helper loaded: form_helper
INFO - 2017-03-20 14:49:40 --> Form Validation Class Initialized
INFO - 2017-03-20 14:49:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:49:40 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '11'
 LIMIT 1
ERROR - 2017-03-20 14:49:40 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-03-20 14:49:40 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-03-20 10:20:14 --> Config Class Initialized
INFO - 2017-03-20 10:20:14 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:20:14 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:20:14 --> Utf8 Class Initialized
INFO - 2017-03-20 10:20:14 --> URI Class Initialized
INFO - 2017-03-20 10:20:14 --> Router Class Initialized
INFO - 2017-03-20 10:20:14 --> Output Class Initialized
INFO - 2017-03-20 10:20:14 --> Security Class Initialized
DEBUG - 2017-03-20 10:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:20:14 --> Input Class Initialized
INFO - 2017-03-20 10:20:14 --> Language Class Initialized
INFO - 2017-03-20 10:20:14 --> Loader Class Initialized
INFO - 2017-03-20 10:20:14 --> Helper loaded: common_helper
INFO - 2017-03-20 10:20:14 --> Database Driver Class Initialized
INFO - 2017-03-20 10:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:20:14 --> Controller Class Initialized
DEBUG - 2017-03-20 10:20:14 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:20:14 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:20:14 --> Database Driver Class Initialized
INFO - 2017-03-20 10:20:14 --> Model Class Initialized
INFO - 2017-03-20 10:20:14 --> Model Class Initialized
INFO - 2017-03-20 10:20:14 --> Helper loaded: url_helper
INFO - 2017-03-20 10:20:14 --> Model Class Initialized
ERROR - 2017-03-20 14:50:14 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001614, 1)
INFO - 2017-03-20 14:50:14 --> Helper loaded: form_helper
INFO - 2017-03-20 14:50:14 --> Form Validation Class Initialized
INFO - 2017-03-20 14:50:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:50:14 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '11'
 LIMIT 1
ERROR - 2017-03-20 14:50:14 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-03-20 14:50:14 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-03-20 10:21:02 --> Config Class Initialized
INFO - 2017-03-20 10:21:02 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:21:02 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:21:02 --> Utf8 Class Initialized
INFO - 2017-03-20 10:21:02 --> URI Class Initialized
INFO - 2017-03-20 10:21:02 --> Router Class Initialized
INFO - 2017-03-20 10:21:02 --> Output Class Initialized
INFO - 2017-03-20 10:21:02 --> Security Class Initialized
DEBUG - 2017-03-20 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:21:02 --> Input Class Initialized
INFO - 2017-03-20 10:21:02 --> Language Class Initialized
INFO - 2017-03-20 10:21:02 --> Loader Class Initialized
INFO - 2017-03-20 10:21:02 --> Helper loaded: common_helper
INFO - 2017-03-20 10:21:02 --> Database Driver Class Initialized
INFO - 2017-03-20 10:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:21:02 --> Controller Class Initialized
DEBUG - 2017-03-20 10:21:02 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:21:02 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:21:02 --> Database Driver Class Initialized
INFO - 2017-03-20 10:21:02 --> Model Class Initialized
INFO - 2017-03-20 10:21:02 --> Model Class Initialized
INFO - 2017-03-20 10:21:02 --> Helper loaded: url_helper
INFO - 2017-03-20 10:21:02 --> Model Class Initialized
ERROR - 2017-03-20 14:51:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001662, 1)
INFO - 2017-03-20 14:51:02 --> Helper loaded: form_helper
INFO - 2017-03-20 14:51:02 --> Form Validation Class Initialized
INFO - 2017-03-20 14:51:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:51:02 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '14'
 LIMIT 1
ERROR - 2017-03-20 14:51:02 --> Call to undefined method Usermodel::throwException()
ERROR - 2017-03-20 14:51:02 --> Severity: Error --> Call to undefined method Usermodel::throwException() C:\xampp\htdocs\blooddonation\application\models\Usermodel.php 55
INFO - 2017-03-20 10:21:19 --> Config Class Initialized
INFO - 2017-03-20 10:21:19 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:21:19 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:21:19 --> Utf8 Class Initialized
INFO - 2017-03-20 10:21:19 --> URI Class Initialized
INFO - 2017-03-20 10:21:19 --> Router Class Initialized
INFO - 2017-03-20 10:21:20 --> Output Class Initialized
INFO - 2017-03-20 10:21:20 --> Security Class Initialized
DEBUG - 2017-03-20 10:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:21:20 --> Input Class Initialized
INFO - 2017-03-20 10:21:20 --> Language Class Initialized
INFO - 2017-03-20 10:21:20 --> Loader Class Initialized
INFO - 2017-03-20 10:21:20 --> Helper loaded: common_helper
INFO - 2017-03-20 10:21:20 --> Database Driver Class Initialized
INFO - 2017-03-20 10:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:21:20 --> Controller Class Initialized
DEBUG - 2017-03-20 10:21:20 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:21:20 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:21:20 --> Database Driver Class Initialized
INFO - 2017-03-20 10:21:20 --> Model Class Initialized
INFO - 2017-03-20 10:21:20 --> Model Class Initialized
INFO - 2017-03-20 10:21:20 --> Helper loaded: url_helper
INFO - 2017-03-20 10:21:20 --> Model Class Initialized
ERROR - 2017-03-20 14:51:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001680, 1)
INFO - 2017-03-20 14:51:20 --> Helper loaded: form_helper
INFO - 2017-03-20 14:51:20 --> Form Validation Class Initialized
INFO - 2017-03-20 14:51:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:51:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.017282009124756
WHERE `id` =0
INFO - 2017-03-20 10:21:41 --> Config Class Initialized
INFO - 2017-03-20 10:21:41 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:21:41 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:21:41 --> Utf8 Class Initialized
INFO - 2017-03-20 10:21:41 --> URI Class Initialized
INFO - 2017-03-20 10:21:41 --> Router Class Initialized
INFO - 2017-03-20 10:21:41 --> Output Class Initialized
INFO - 2017-03-20 10:21:41 --> Security Class Initialized
DEBUG - 2017-03-20 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:21:41 --> Input Class Initialized
INFO - 2017-03-20 10:21:41 --> Language Class Initialized
INFO - 2017-03-20 10:21:41 --> Loader Class Initialized
INFO - 2017-03-20 10:21:41 --> Helper loaded: common_helper
INFO - 2017-03-20 10:21:41 --> Database Driver Class Initialized
INFO - 2017-03-20 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:21:41 --> Controller Class Initialized
DEBUG - 2017-03-20 10:21:41 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:21:41 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:21:41 --> Database Driver Class Initialized
INFO - 2017-03-20 10:21:41 --> Model Class Initialized
INFO - 2017-03-20 10:21:41 --> Model Class Initialized
INFO - 2017-03-20 10:21:41 --> Helper loaded: url_helper
INFO - 2017-03-20 10:21:41 --> Model Class Initialized
ERROR - 2017-03-20 14:51:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001701, 1)
INFO - 2017-03-20 14:51:41 --> Helper loaded: form_helper
INFO - 2017-03-20 14:51:41 --> Form Validation Class Initialized
INFO - 2017-03-20 14:51:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:51:41 --> Query error: Unknown column 'age' in 'field list' - Invalid query: SELECT `userId`, `name`, `gender`, `countryCode`, `phoneNumber`, `address`, `profilePicture`, `bloodGroup`, `is_phoneNumber_visible`, `noti_enable`, `age`
FROM `users`
WHERE `isActive` = 1
AND `userId` = '14'
 LIMIT 1
ERROR - 2017-03-20 14:51:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.019036054611206
WHERE `id` =0
INFO - 2017-03-20 10:22:22 --> Config Class Initialized
INFO - 2017-03-20 10:22:22 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:22:22 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:22:22 --> Utf8 Class Initialized
INFO - 2017-03-20 10:22:22 --> URI Class Initialized
INFO - 2017-03-20 10:22:22 --> Router Class Initialized
INFO - 2017-03-20 10:22:22 --> Output Class Initialized
INFO - 2017-03-20 10:22:22 --> Security Class Initialized
DEBUG - 2017-03-20 10:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:22:22 --> Input Class Initialized
INFO - 2017-03-20 10:22:22 --> Language Class Initialized
INFO - 2017-03-20 10:22:22 --> Loader Class Initialized
INFO - 2017-03-20 10:22:22 --> Helper loaded: common_helper
INFO - 2017-03-20 10:22:22 --> Database Driver Class Initialized
INFO - 2017-03-20 10:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:22:22 --> Controller Class Initialized
DEBUG - 2017-03-20 10:22:22 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:22:22 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:22:22 --> Database Driver Class Initialized
INFO - 2017-03-20 10:22:22 --> Model Class Initialized
INFO - 2017-03-20 10:22:22 --> Model Class Initialized
INFO - 2017-03-20 10:22:22 --> Helper loaded: url_helper
INFO - 2017-03-20 10:22:22 --> Model Class Initialized
ERROR - 2017-03-20 14:52:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001742, 1)
INFO - 2017-03-20 14:52:22 --> Helper loaded: form_helper
INFO - 2017-03-20 14:52:22 --> Form Validation Class Initialized
INFO - 2017-03-20 14:52:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:52:22 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.11016511917114
WHERE `id` =0
INFO - 2017-03-20 10:23:33 --> Config Class Initialized
INFO - 2017-03-20 10:23:33 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:23:33 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:23:33 --> Utf8 Class Initialized
INFO - 2017-03-20 10:23:33 --> URI Class Initialized
INFO - 2017-03-20 10:23:33 --> Router Class Initialized
INFO - 2017-03-20 10:23:33 --> Output Class Initialized
INFO - 2017-03-20 10:23:33 --> Security Class Initialized
DEBUG - 2017-03-20 10:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:23:33 --> Input Class Initialized
INFO - 2017-03-20 10:23:33 --> Language Class Initialized
INFO - 2017-03-20 10:23:33 --> Loader Class Initialized
INFO - 2017-03-20 10:23:33 --> Helper loaded: common_helper
INFO - 2017-03-20 10:23:33 --> Database Driver Class Initialized
INFO - 2017-03-20 10:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:23:33 --> Controller Class Initialized
DEBUG - 2017-03-20 10:23:33 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:23:33 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:23:33 --> Database Driver Class Initialized
INFO - 2017-03-20 10:23:33 --> Model Class Initialized
INFO - 2017-03-20 10:23:33 --> Model Class Initialized
INFO - 2017-03-20 10:23:33 --> Helper loaded: url_helper
INFO - 2017-03-20 10:23:33 --> Model Class Initialized
ERROR - 2017-03-20 14:53:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001813, 1)
INFO - 2017-03-20 14:53:33 --> Helper loaded: form_helper
INFO - 2017-03-20 14:53:33 --> Form Validation Class Initialized
INFO - 2017-03-20 14:53:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:53:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.020696878433228
WHERE `id` =0
INFO - 2017-03-20 10:23:59 --> Config Class Initialized
INFO - 2017-03-20 10:23:59 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:23:59 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:23:59 --> Utf8 Class Initialized
INFO - 2017-03-20 10:23:59 --> URI Class Initialized
INFO - 2017-03-20 10:23:59 --> Router Class Initialized
INFO - 2017-03-20 10:23:59 --> Output Class Initialized
INFO - 2017-03-20 10:23:59 --> Security Class Initialized
DEBUG - 2017-03-20 10:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:23:59 --> Input Class Initialized
INFO - 2017-03-20 10:23:59 --> Language Class Initialized
INFO - 2017-03-20 10:23:59 --> Loader Class Initialized
INFO - 2017-03-20 10:23:59 --> Helper loaded: common_helper
INFO - 2017-03-20 10:23:59 --> Database Driver Class Initialized
INFO - 2017-03-20 10:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:23:59 --> Controller Class Initialized
DEBUG - 2017-03-20 10:23:59 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:23:59 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:23:59 --> Database Driver Class Initialized
INFO - 2017-03-20 10:23:59 --> Model Class Initialized
INFO - 2017-03-20 10:23:59 --> Model Class Initialized
INFO - 2017-03-20 10:23:59 --> Helper loaded: url_helper
INFO - 2017-03-20 10:23:59 --> Model Class Initialized
ERROR - 2017-03-20 14:53:59 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001839, 1)
INFO - 2017-03-20 14:53:59 --> Helper loaded: form_helper
INFO - 2017-03-20 14:53:59 --> Form Validation Class Initialized
INFO - 2017-03-20 14:53:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:54:00 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 1.0144999027252
WHERE `id` =0
INFO - 2017-03-20 10:24:54 --> Config Class Initialized
INFO - 2017-03-20 10:24:54 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:24:54 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:24:54 --> Utf8 Class Initialized
INFO - 2017-03-20 10:24:54 --> URI Class Initialized
INFO - 2017-03-20 10:24:54 --> Router Class Initialized
INFO - 2017-03-20 10:24:54 --> Output Class Initialized
INFO - 2017-03-20 10:24:54 --> Security Class Initialized
DEBUG - 2017-03-20 10:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:24:54 --> Input Class Initialized
INFO - 2017-03-20 10:24:54 --> Language Class Initialized
INFO - 2017-03-20 10:24:54 --> Loader Class Initialized
INFO - 2017-03-20 10:24:54 --> Helper loaded: common_helper
INFO - 2017-03-20 10:24:54 --> Database Driver Class Initialized
INFO - 2017-03-20 10:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:24:54 --> Controller Class Initialized
DEBUG - 2017-03-20 10:24:54 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:24:54 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:24:54 --> Database Driver Class Initialized
INFO - 2017-03-20 10:24:54 --> Model Class Initialized
INFO - 2017-03-20 10:24:54 --> Model Class Initialized
INFO - 2017-03-20 10:24:54 --> Helper loaded: url_helper
INFO - 2017-03-20 10:24:54 --> Model Class Initialized
ERROR - 2017-03-20 14:54:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"age\":\"22\",\"gender\":\"1\",\"address\":\"hyderabad\",\"message\":\"i want help\",\"check\":\"0\"}', '', '::1', 1490001894, 1)
INFO - 2017-03-20 14:54:54 --> Helper loaded: form_helper
INFO - 2017-03-20 14:54:54 --> Form Validation Class Initialized
INFO - 2017-03-20 14:54:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 14:54:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.62246823310852
WHERE `id` =0
INFO - 2017-03-20 10:54:42 --> Config Class Initialized
INFO - 2017-03-20 10:54:42 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:54:42 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:54:42 --> Utf8 Class Initialized
INFO - 2017-03-20 10:54:42 --> URI Class Initialized
INFO - 2017-03-20 10:54:42 --> Router Class Initialized
INFO - 2017-03-20 10:54:42 --> Output Class Initialized
INFO - 2017-03-20 10:54:42 --> Security Class Initialized
DEBUG - 2017-03-20 10:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:54:42 --> Input Class Initialized
INFO - 2017-03-20 10:54:42 --> Language Class Initialized
INFO - 2017-03-20 10:54:42 --> Loader Class Initialized
INFO - 2017-03-20 10:54:42 --> Helper loaded: common_helper
INFO - 2017-03-20 10:54:42 --> Database Driver Class Initialized
INFO - 2017-03-20 10:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:54:42 --> Controller Class Initialized
DEBUG - 2017-03-20 10:54:42 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:54:42 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:54:42 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:24:42 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.006248950958252
WHERE `id` = ''
INFO - 2017-03-20 10:54:50 --> Config Class Initialized
INFO - 2017-03-20 10:54:50 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:54:50 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:54:50 --> Utf8 Class Initialized
INFO - 2017-03-20 10:54:50 --> URI Class Initialized
INFO - 2017-03-20 10:54:50 --> Router Class Initialized
INFO - 2017-03-20 10:54:50 --> Output Class Initialized
INFO - 2017-03-20 10:54:50 --> Security Class Initialized
DEBUG - 2017-03-20 10:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:54:50 --> Input Class Initialized
INFO - 2017-03-20 10:54:50 --> Language Class Initialized
INFO - 2017-03-20 10:54:50 --> Loader Class Initialized
INFO - 2017-03-20 10:54:50 --> Helper loaded: common_helper
INFO - 2017-03-20 10:54:50 --> Database Driver Class Initialized
INFO - 2017-03-20 10:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:54:50 --> Controller Class Initialized
DEBUG - 2017-03-20 10:54:50 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:54:50 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:54:50 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:24:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/dataPolicy', 'get', NULL, '', '::1', 1490003690, 1)
INFO - 2017-03-20 15:24:50 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\datapolocy.php
INFO - 2017-03-20 15:24:50 --> Final output sent to browser
DEBUG - 2017-03-20 15:24:50 --> Total execution time: 0.0372
ERROR - 2017-03-20 15:24:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0076858997344971
WHERE `id` =0
INFO - 2017-03-20 10:55:01 --> Config Class Initialized
INFO - 2017-03-20 10:55:01 --> Hooks Class Initialized
DEBUG - 2017-03-20 10:55:01 --> UTF-8 Support Enabled
INFO - 2017-03-20 10:55:01 --> Utf8 Class Initialized
INFO - 2017-03-20 10:55:01 --> URI Class Initialized
INFO - 2017-03-20 10:55:01 --> Router Class Initialized
INFO - 2017-03-20 10:55:01 --> Output Class Initialized
INFO - 2017-03-20 10:55:01 --> Security Class Initialized
DEBUG - 2017-03-20 10:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 10:55:01 --> Input Class Initialized
INFO - 2017-03-20 10:55:01 --> Language Class Initialized
INFO - 2017-03-20 10:55:01 --> Loader Class Initialized
INFO - 2017-03-20 10:55:01 --> Helper loaded: common_helper
INFO - 2017-03-20 10:55:01 --> Database Driver Class Initialized
INFO - 2017-03-20 10:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 10:55:01 --> Controller Class Initialized
DEBUG - 2017-03-20 10:55:01 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 10:55:01 --> Helper loaded: inflector_helper
INFO - 2017-03-20 10:55:01 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:25:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490003701, 1)
INFO - 2017-03-20 15:25:01 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\Privacy.php
INFO - 2017-03-20 15:25:01 --> Final output sent to browser
DEBUG - 2017-03-20 15:25:01 --> Total execution time: 0.0381
ERROR - 2017-03-20 15:25:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0063719749450684
WHERE `id` =0
INFO - 2017-03-20 11:00:49 --> Config Class Initialized
INFO - 2017-03-20 11:00:49 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:00:49 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:00:49 --> Utf8 Class Initialized
INFO - 2017-03-20 11:00:49 --> URI Class Initialized
INFO - 2017-03-20 11:00:49 --> Router Class Initialized
INFO - 2017-03-20 11:00:49 --> Output Class Initialized
INFO - 2017-03-20 11:00:49 --> Security Class Initialized
DEBUG - 2017-03-20 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:00:49 --> Input Class Initialized
INFO - 2017-03-20 11:00:49 --> Language Class Initialized
INFO - 2017-03-20 11:00:49 --> Loader Class Initialized
INFO - 2017-03-20 11:00:49 --> Helper loaded: common_helper
INFO - 2017-03-20 11:00:49 --> Database Driver Class Initialized
INFO - 2017-03-20 11:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:00:49 --> Controller Class Initialized
DEBUG - 2017-03-20 11:00:49 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:00:49 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:00:49 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:30:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004049, 1)
INFO - 2017-03-20 15:30:49 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\Privacy.php
INFO - 2017-03-20 15:30:49 --> Final output sent to browser
DEBUG - 2017-03-20 15:30:49 --> Total execution time: 0.0391
ERROR - 2017-03-20 15:30:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0069990158081055
WHERE `id` =0
INFO - 2017-03-20 11:01:09 --> Config Class Initialized
INFO - 2017-03-20 11:01:09 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:01:09 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:01:09 --> Utf8 Class Initialized
INFO - 2017-03-20 11:01:09 --> URI Class Initialized
INFO - 2017-03-20 11:01:09 --> Router Class Initialized
INFO - 2017-03-20 11:01:09 --> Output Class Initialized
INFO - 2017-03-20 11:01:09 --> Security Class Initialized
DEBUG - 2017-03-20 11:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:01:09 --> Input Class Initialized
INFO - 2017-03-20 11:01:09 --> Language Class Initialized
INFO - 2017-03-20 11:01:09 --> Loader Class Initialized
INFO - 2017-03-20 11:01:09 --> Helper loaded: common_helper
INFO - 2017-03-20 11:01:09 --> Database Driver Class Initialized
INFO - 2017-03-20 11:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:01:09 --> Controller Class Initialized
DEBUG - 2017-03-20 11:01:09 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:01:09 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:01:09 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:31:09 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004069, 1)
INFO - 2017-03-20 15:31:09 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\Privacy.php
INFO - 2017-03-20 15:31:09 --> Final output sent to browser
DEBUG - 2017-03-20 15:31:09 --> Total execution time: 0.0410
ERROR - 2017-03-20 15:31:09 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0075311660766602
WHERE `id` =0
INFO - 2017-03-20 11:02:25 --> Config Class Initialized
INFO - 2017-03-20 11:02:25 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:02:25 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:02:25 --> Utf8 Class Initialized
INFO - 2017-03-20 11:02:25 --> URI Class Initialized
INFO - 2017-03-20 11:02:25 --> Router Class Initialized
INFO - 2017-03-20 11:02:25 --> Output Class Initialized
INFO - 2017-03-20 11:02:25 --> Security Class Initialized
DEBUG - 2017-03-20 11:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:02:25 --> Input Class Initialized
INFO - 2017-03-20 11:02:25 --> Language Class Initialized
INFO - 2017-03-20 11:02:25 --> Loader Class Initialized
INFO - 2017-03-20 11:02:25 --> Helper loaded: common_helper
INFO - 2017-03-20 11:02:25 --> Database Driver Class Initialized
INFO - 2017-03-20 11:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:02:25 --> Controller Class Initialized
DEBUG - 2017-03-20 11:02:25 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:02:25 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:02:25 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:32:25 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004145, 1)
INFO - 2017-03-20 15:32:25 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:32:25 --> Final output sent to browser
DEBUG - 2017-03-20 15:32:25 --> Total execution time: 0.0408
ERROR - 2017-03-20 15:32:25 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0097451210021973
WHERE `id` =0
INFO - 2017-03-20 11:03:19 --> Config Class Initialized
INFO - 2017-03-20 11:03:19 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:03:19 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:03:19 --> Utf8 Class Initialized
INFO - 2017-03-20 11:03:19 --> URI Class Initialized
INFO - 2017-03-20 11:03:19 --> Router Class Initialized
INFO - 2017-03-20 11:03:19 --> Output Class Initialized
INFO - 2017-03-20 11:03:19 --> Security Class Initialized
DEBUG - 2017-03-20 11:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:03:19 --> Input Class Initialized
INFO - 2017-03-20 11:03:19 --> Language Class Initialized
INFO - 2017-03-20 11:03:20 --> Loader Class Initialized
INFO - 2017-03-20 11:03:20 --> Helper loaded: common_helper
INFO - 2017-03-20 11:03:20 --> Database Driver Class Initialized
INFO - 2017-03-20 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:03:20 --> Controller Class Initialized
DEBUG - 2017-03-20 11:03:20 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:03:20 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:03:20 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:33:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004200, 1)
INFO - 2017-03-20 15:33:20 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:33:20 --> Final output sent to browser
DEBUG - 2017-03-20 15:33:20 --> Total execution time: 0.0454
ERROR - 2017-03-20 15:33:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.010272026062012
WHERE `id` =0
INFO - 2017-03-20 11:03:43 --> Config Class Initialized
INFO - 2017-03-20 11:03:43 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:03:43 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:03:43 --> Utf8 Class Initialized
INFO - 2017-03-20 11:03:43 --> URI Class Initialized
INFO - 2017-03-20 11:03:43 --> Router Class Initialized
INFO - 2017-03-20 11:03:43 --> Output Class Initialized
INFO - 2017-03-20 11:03:43 --> Security Class Initialized
DEBUG - 2017-03-20 11:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:03:43 --> Input Class Initialized
INFO - 2017-03-20 11:03:43 --> Language Class Initialized
INFO - 2017-03-20 11:03:43 --> Loader Class Initialized
INFO - 2017-03-20 11:03:43 --> Helper loaded: common_helper
INFO - 2017-03-20 11:03:43 --> Database Driver Class Initialized
INFO - 2017-03-20 11:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:03:43 --> Controller Class Initialized
DEBUG - 2017-03-20 11:03:43 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:03:43 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:03:43 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:33:43 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004223, 1)
INFO - 2017-03-20 15:33:43 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:33:43 --> Final output sent to browser
DEBUG - 2017-03-20 15:33:43 --> Total execution time: 0.0371
ERROR - 2017-03-20 15:33:43 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0061130523681641
WHERE `id` =0
INFO - 2017-03-20 11:04:01 --> Config Class Initialized
INFO - 2017-03-20 11:04:01 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:04:01 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:04:01 --> Utf8 Class Initialized
INFO - 2017-03-20 11:04:01 --> URI Class Initialized
INFO - 2017-03-20 11:04:01 --> Router Class Initialized
INFO - 2017-03-20 11:04:01 --> Output Class Initialized
INFO - 2017-03-20 11:04:01 --> Security Class Initialized
DEBUG - 2017-03-20 11:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:04:01 --> Input Class Initialized
INFO - 2017-03-20 11:04:01 --> Language Class Initialized
INFO - 2017-03-20 11:04:01 --> Loader Class Initialized
INFO - 2017-03-20 11:04:01 --> Helper loaded: common_helper
INFO - 2017-03-20 11:04:01 --> Database Driver Class Initialized
INFO - 2017-03-20 11:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:04:01 --> Controller Class Initialized
DEBUG - 2017-03-20 11:04:01 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:04:01 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:04:01 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:34:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004241, 1)
INFO - 2017-03-20 15:34:01 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacy.php
INFO - 2017-03-20 15:34:01 --> Final output sent to browser
DEBUG - 2017-03-20 15:34:01 --> Total execution time: 0.0396
ERROR - 2017-03-20 15:34:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0068891048431396
WHERE `id` =0
INFO - 2017-03-20 11:10:47 --> Config Class Initialized
INFO - 2017-03-20 11:10:47 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:10:47 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:10:47 --> Utf8 Class Initialized
INFO - 2017-03-20 11:10:47 --> URI Class Initialized
INFO - 2017-03-20 11:10:47 --> Router Class Initialized
INFO - 2017-03-20 11:10:47 --> Output Class Initialized
INFO - 2017-03-20 11:10:47 --> Security Class Initialized
DEBUG - 2017-03-20 11:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:10:47 --> Input Class Initialized
INFO - 2017-03-20 11:10:47 --> Language Class Initialized
INFO - 2017-03-20 11:10:47 --> Loader Class Initialized
INFO - 2017-03-20 11:10:47 --> Helper loaded: common_helper
INFO - 2017-03-20 11:10:47 --> Database Driver Class Initialized
INFO - 2017-03-20 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:10:47 --> Controller Class Initialized
DEBUG - 2017-03-20 11:10:47 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:10:47 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:10:47 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:40:47 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490004647, 1)
INFO - 2017-03-20 15:40:47 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:40:47 --> Final output sent to browser
DEBUG - 2017-03-20 15:40:47 --> Total execution time: 0.0374
ERROR - 2017-03-20 15:40:47 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0067801475524902
WHERE `id` =0
INFO - 2017-03-20 11:14:40 --> Config Class Initialized
INFO - 2017-03-20 11:14:40 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:14:40 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:14:40 --> Utf8 Class Initialized
INFO - 2017-03-20 11:14:40 --> URI Class Initialized
INFO - 2017-03-20 11:14:40 --> Router Class Initialized
INFO - 2017-03-20 11:14:40 --> Output Class Initialized
INFO - 2017-03-20 11:14:40 --> Security Class Initialized
DEBUG - 2017-03-20 11:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:14:40 --> Input Class Initialized
INFO - 2017-03-20 11:14:40 --> Language Class Initialized
INFO - 2017-03-20 11:14:40 --> Loader Class Initialized
INFO - 2017-03-20 11:14:40 --> Helper loaded: common_helper
INFO - 2017-03-20 11:14:40 --> Database Driver Class Initialized
INFO - 2017-03-20 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:14:40 --> Controller Class Initialized
DEBUG - 2017-03-20 11:14:40 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:14:40 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:14:40 --> Database Driver Class Initialized
INFO - 2017-03-20 11:14:40 --> Model Class Initialized
INFO - 2017-03-20 11:14:40 --> Model Class Initialized
INFO - 2017-03-20 11:14:40 --> Helper loaded: url_helper
INFO - 2017-03-20 11:14:40 --> Model Class Initialized
ERROR - 2017-03-20 15:44:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notifications', 'get', NULL, '', '::1', 1490004880, 1)
ERROR - 2017-03-20 15:44:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.084227800369263
WHERE `id` =0
INFO - 2017-03-20 11:14:44 --> Config Class Initialized
INFO - 2017-03-20 11:14:44 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:14:44 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:14:44 --> Utf8 Class Initialized
INFO - 2017-03-20 11:14:44 --> URI Class Initialized
INFO - 2017-03-20 11:14:44 --> Router Class Initialized
INFO - 2017-03-20 11:14:44 --> Output Class Initialized
INFO - 2017-03-20 11:14:44 --> Security Class Initialized
DEBUG - 2017-03-20 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:14:44 --> Input Class Initialized
INFO - 2017-03-20 11:14:44 --> Language Class Initialized
INFO - 2017-03-20 11:14:44 --> Loader Class Initialized
INFO - 2017-03-20 11:14:44 --> Helper loaded: common_helper
INFO - 2017-03-20 11:14:44 --> Database Driver Class Initialized
INFO - 2017-03-20 11:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:14:44 --> Controller Class Initialized
DEBUG - 2017-03-20 11:14:44 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:14:44 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:14:44 --> Database Driver Class Initialized
INFO - 2017-03-20 11:14:44 --> Model Class Initialized
INFO - 2017-03-20 11:14:44 --> Model Class Initialized
INFO - 2017-03-20 11:14:44 --> Helper loaded: url_helper
INFO - 2017-03-20 11:14:44 --> Model Class Initialized
ERROR - 2017-03-20 15:44:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0087409019470215
WHERE `id` = ''
INFO - 2017-03-20 11:14:47 --> Config Class Initialized
INFO - 2017-03-20 11:14:47 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:14:47 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:14:47 --> Utf8 Class Initialized
INFO - 2017-03-20 11:14:47 --> URI Class Initialized
INFO - 2017-03-20 11:14:47 --> Router Class Initialized
INFO - 2017-03-20 11:14:47 --> Output Class Initialized
INFO - 2017-03-20 11:14:47 --> Security Class Initialized
DEBUG - 2017-03-20 11:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:14:47 --> Input Class Initialized
INFO - 2017-03-20 11:14:47 --> Language Class Initialized
INFO - 2017-03-20 11:14:47 --> Loader Class Initialized
INFO - 2017-03-20 11:14:47 --> Helper loaded: common_helper
INFO - 2017-03-20 11:14:47 --> Database Driver Class Initialized
INFO - 2017-03-20 11:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:14:47 --> Controller Class Initialized
DEBUG - 2017-03-20 11:14:47 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:14:47 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:14:47 --> Database Driver Class Initialized
INFO - 2017-03-20 11:14:47 --> Model Class Initialized
INFO - 2017-03-20 11:14:47 --> Model Class Initialized
INFO - 2017-03-20 11:14:47 --> Helper loaded: url_helper
INFO - 2017-03-20 11:14:47 --> Model Class Initialized
ERROR - 2017-03-20 15:44:47 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0088388919830322
WHERE `id` = ''
INFO - 2017-03-20 11:15:05 --> Config Class Initialized
INFO - 2017-03-20 11:15:05 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:15:05 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:15:05 --> Utf8 Class Initialized
INFO - 2017-03-20 11:15:05 --> URI Class Initialized
INFO - 2017-03-20 11:15:05 --> Router Class Initialized
INFO - 2017-03-20 11:15:05 --> Output Class Initialized
INFO - 2017-03-20 11:15:05 --> Security Class Initialized
DEBUG - 2017-03-20 11:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:15:05 --> Input Class Initialized
INFO - 2017-03-20 11:15:05 --> Language Class Initialized
INFO - 2017-03-20 11:15:05 --> Loader Class Initialized
INFO - 2017-03-20 11:15:05 --> Helper loaded: common_helper
INFO - 2017-03-20 11:15:05 --> Database Driver Class Initialized
INFO - 2017-03-20 11:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:15:05 --> Controller Class Initialized
DEBUG - 2017-03-20 11:15:05 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:15:05 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:15:05 --> Database Driver Class Initialized
INFO - 2017-03-20 11:15:05 --> Model Class Initialized
INFO - 2017-03-20 11:15:05 --> Model Class Initialized
INFO - 2017-03-20 11:15:05 --> Helper loaded: url_helper
INFO - 2017-03-20 11:15:05 --> Model Class Initialized
ERROR - 2017-03-20 15:45:05 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.008821964263916
WHERE `id` = ''
INFO - 2017-03-20 11:15:08 --> Config Class Initialized
INFO - 2017-03-20 11:15:08 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:15:08 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:15:08 --> Utf8 Class Initialized
INFO - 2017-03-20 11:15:08 --> URI Class Initialized
INFO - 2017-03-20 11:15:08 --> Router Class Initialized
INFO - 2017-03-20 11:15:08 --> Output Class Initialized
INFO - 2017-03-20 11:15:08 --> Security Class Initialized
DEBUG - 2017-03-20 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:15:08 --> Input Class Initialized
INFO - 2017-03-20 11:15:08 --> Language Class Initialized
INFO - 2017-03-20 11:15:08 --> Loader Class Initialized
INFO - 2017-03-20 11:15:08 --> Helper loaded: common_helper
INFO - 2017-03-20 11:15:08 --> Database Driver Class Initialized
INFO - 2017-03-20 11:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:15:08 --> Controller Class Initialized
DEBUG - 2017-03-20 11:15:08 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:15:08 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:15:08 --> Database Driver Class Initialized
INFO - 2017-03-20 11:15:08 --> Model Class Initialized
INFO - 2017-03-20 11:15:08 --> Model Class Initialized
INFO - 2017-03-20 11:15:08 --> Helper loaded: url_helper
INFO - 2017-03-20 11:15:08 --> Model Class Initialized
ERROR - 2017-03-20 15:45:08 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0084819793701172
WHERE `id` = ''
INFO - 2017-03-20 11:15:18 --> Config Class Initialized
INFO - 2017-03-20 11:15:18 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:15:18 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:15:18 --> Utf8 Class Initialized
INFO - 2017-03-20 11:15:18 --> URI Class Initialized
INFO - 2017-03-20 11:15:18 --> Router Class Initialized
INFO - 2017-03-20 11:15:18 --> Output Class Initialized
INFO - 2017-03-20 11:15:18 --> Security Class Initialized
DEBUG - 2017-03-20 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:15:18 --> Input Class Initialized
INFO - 2017-03-20 11:15:18 --> Language Class Initialized
INFO - 2017-03-20 11:15:18 --> Loader Class Initialized
INFO - 2017-03-20 11:15:18 --> Helper loaded: common_helper
INFO - 2017-03-20 11:15:18 --> Database Driver Class Initialized
INFO - 2017-03-20 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:15:18 --> Controller Class Initialized
DEBUG - 2017-03-20 11:15:18 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:15:18 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:15:18 --> Database Driver Class Initialized
INFO - 2017-03-20 11:15:18 --> Model Class Initialized
INFO - 2017-03-20 11:15:18 --> Model Class Initialized
INFO - 2017-03-20 11:15:18 --> Helper loaded: url_helper
INFO - 2017-03-20 11:15:18 --> Model Class Initialized
ERROR - 2017-03-20 15:45:18 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/dataPolicy', 'get', NULL, '', '::1', 1490004918, 1)
INFO - 2017-03-20 15:45:18 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\datapolocy.php
INFO - 2017-03-20 15:45:18 --> Final output sent to browser
DEBUG - 2017-03-20 15:45:18 --> Total execution time: 0.0431
ERROR - 2017-03-20 15:45:18 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.010589122772217
WHERE `id` =0
INFO - 2017-03-20 11:28:53 --> Config Class Initialized
INFO - 2017-03-20 11:28:53 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:28:53 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:28:53 --> Utf8 Class Initialized
INFO - 2017-03-20 11:28:53 --> URI Class Initialized
INFO - 2017-03-20 11:28:53 --> Router Class Initialized
INFO - 2017-03-20 11:28:53 --> Output Class Initialized
INFO - 2017-03-20 11:28:53 --> Security Class Initialized
DEBUG - 2017-03-20 11:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:28:53 --> Input Class Initialized
INFO - 2017-03-20 11:28:53 --> Language Class Initialized
INFO - 2017-03-20 11:28:53 --> Loader Class Initialized
INFO - 2017-03-20 11:28:53 --> Helper loaded: common_helper
INFO - 2017-03-20 11:28:53 --> Database Driver Class Initialized
INFO - 2017-03-20 11:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:28:53 --> Controller Class Initialized
DEBUG - 2017-03-20 11:28:53 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:28:53 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:28:53 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:58:53 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005733, 1)
INFO - 2017-03-20 15:58:53 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:58:53 --> Final output sent to browser
DEBUG - 2017-03-20 15:58:53 --> Total execution time: 0.0384
ERROR - 2017-03-20 15:58:53 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0068819522857666
WHERE `id` =0
INFO - 2017-03-20 11:29:34 --> Config Class Initialized
INFO - 2017-03-20 11:29:34 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:29:34 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:29:34 --> Utf8 Class Initialized
INFO - 2017-03-20 11:29:34 --> URI Class Initialized
INFO - 2017-03-20 11:29:34 --> Router Class Initialized
INFO - 2017-03-20 11:29:34 --> Output Class Initialized
INFO - 2017-03-20 11:29:34 --> Security Class Initialized
DEBUG - 2017-03-20 11:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:29:34 --> Input Class Initialized
INFO - 2017-03-20 11:29:34 --> Language Class Initialized
INFO - 2017-03-20 11:29:34 --> Loader Class Initialized
INFO - 2017-03-20 11:29:34 --> Helper loaded: common_helper
INFO - 2017-03-20 11:29:34 --> Database Driver Class Initialized
INFO - 2017-03-20 11:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:29:34 --> Controller Class Initialized
DEBUG - 2017-03-20 11:29:34 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:29:34 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:29:34 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:59:34 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005774, 1)
INFO - 2017-03-20 15:59:34 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:59:34 --> Final output sent to browser
DEBUG - 2017-03-20 15:59:34 --> Total execution time: 0.0514
ERROR - 2017-03-20 15:59:34 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0062770843505859
WHERE `id` =0
INFO - 2017-03-20 11:29:46 --> Config Class Initialized
INFO - 2017-03-20 11:29:46 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:29:46 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:29:46 --> Utf8 Class Initialized
INFO - 2017-03-20 11:29:46 --> URI Class Initialized
INFO - 2017-03-20 11:29:46 --> Router Class Initialized
INFO - 2017-03-20 11:29:46 --> Output Class Initialized
INFO - 2017-03-20 11:29:46 --> Security Class Initialized
DEBUG - 2017-03-20 11:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:29:46 --> Input Class Initialized
INFO - 2017-03-20 11:29:46 --> Language Class Initialized
INFO - 2017-03-20 11:29:46 --> Loader Class Initialized
INFO - 2017-03-20 11:29:46 --> Helper loaded: common_helper
INFO - 2017-03-20 11:29:46 --> Database Driver Class Initialized
INFO - 2017-03-20 11:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:29:46 --> Controller Class Initialized
DEBUG - 2017-03-20 11:29:46 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:29:46 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:29:46 --> Database Driver Class Initialized
ERROR - 2017-03-20 15:59:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005786, 1)
INFO - 2017-03-20 15:59:46 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 15:59:46 --> Final output sent to browser
DEBUG - 2017-03-20 15:59:46 --> Total execution time: 0.0420
ERROR - 2017-03-20 15:59:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0081260204315186
WHERE `id` =0
INFO - 2017-03-20 11:31:02 --> Config Class Initialized
INFO - 2017-03-20 11:31:02 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:02 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:02 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:02 --> URI Class Initialized
INFO - 2017-03-20 11:31:02 --> Router Class Initialized
INFO - 2017-03-20 11:31:02 --> Output Class Initialized
INFO - 2017-03-20 11:31:02 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:02 --> Input Class Initialized
INFO - 2017-03-20 11:31:02 --> Language Class Initialized
INFO - 2017-03-20 11:31:02 --> Loader Class Initialized
INFO - 2017-03-20 11:31:02 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:02 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:02 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:02 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:02 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:02 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005862, 1)
INFO - 2017-03-20 16:01:02 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:02 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:02 --> Total execution time: 0.0423
ERROR - 2017-03-20 16:01:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0076539516448975
WHERE `id` =0
INFO - 2017-03-20 11:31:03 --> Config Class Initialized
INFO - 2017-03-20 11:31:03 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:03 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:03 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:03 --> URI Class Initialized
INFO - 2017-03-20 11:31:03 --> Router Class Initialized
INFO - 2017-03-20 11:31:03 --> Output Class Initialized
INFO - 2017-03-20 11:31:03 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:03 --> Input Class Initialized
INFO - 2017-03-20 11:31:03 --> Language Class Initialized
INFO - 2017-03-20 11:31:03 --> Loader Class Initialized
INFO - 2017-03-20 11:31:03 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:03 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:03 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:03 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:03 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:03 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:03 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005863, 1)
INFO - 2017-03-20 16:01:03 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:03 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:03 --> Total execution time: 0.0365
ERROR - 2017-03-20 16:01:03 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0059750080108643
WHERE `id` =0
INFO - 2017-03-20 11:31:03 --> Config Class Initialized
INFO - 2017-03-20 11:31:03 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:03 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:03 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:03 --> URI Class Initialized
INFO - 2017-03-20 11:31:03 --> Router Class Initialized
INFO - 2017-03-20 11:31:03 --> Output Class Initialized
INFO - 2017-03-20 11:31:03 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:03 --> Input Class Initialized
INFO - 2017-03-20 11:31:03 --> Language Class Initialized
INFO - 2017-03-20 11:31:03 --> Loader Class Initialized
INFO - 2017-03-20 11:31:03 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:03 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:03 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:03 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:03 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:03 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:03 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005863, 1)
INFO - 2017-03-20 16:01:03 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:03 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:03 --> Total execution time: 0.0403
ERROR - 2017-03-20 16:01:03 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0074169635772705
WHERE `id` =0
INFO - 2017-03-20 11:31:03 --> Config Class Initialized
INFO - 2017-03-20 11:31:03 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:03 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:03 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:03 --> URI Class Initialized
INFO - 2017-03-20 11:31:03 --> Router Class Initialized
INFO - 2017-03-20 11:31:03 --> Output Class Initialized
INFO - 2017-03-20 11:31:03 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:03 --> Input Class Initialized
INFO - 2017-03-20 11:31:03 --> Language Class Initialized
INFO - 2017-03-20 11:31:03 --> Loader Class Initialized
INFO - 2017-03-20 11:31:03 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:03 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:03 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:03 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:03 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:03 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:03 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005863, 1)
INFO - 2017-03-20 16:01:03 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:03 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:03 --> Total execution time: 0.0391
ERROR - 2017-03-20 16:01:03 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0088579654693604
WHERE `id` =0
INFO - 2017-03-20 11:31:13 --> Config Class Initialized
INFO - 2017-03-20 11:31:13 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:13 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:13 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:13 --> URI Class Initialized
INFO - 2017-03-20 11:31:13 --> Router Class Initialized
INFO - 2017-03-20 11:31:13 --> Output Class Initialized
INFO - 2017-03-20 11:31:13 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:13 --> Input Class Initialized
INFO - 2017-03-20 11:31:13 --> Language Class Initialized
INFO - 2017-03-20 11:31:13 --> Loader Class Initialized
INFO - 2017-03-20 11:31:13 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:13 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:13 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:13 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:13 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:13 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005873, 1)
INFO - 2017-03-20 16:01:13 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:13 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:13 --> Total execution time: 0.0451
ERROR - 2017-03-20 16:01:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0080530643463135
WHERE `id` =0
INFO - 2017-03-20 11:31:23 --> Config Class Initialized
INFO - 2017-03-20 11:31:23 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:23 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:23 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:23 --> URI Class Initialized
INFO - 2017-03-20 11:31:23 --> Router Class Initialized
INFO - 2017-03-20 11:31:23 --> Output Class Initialized
INFO - 2017-03-20 11:31:23 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:23 --> Input Class Initialized
INFO - 2017-03-20 11:31:23 --> Language Class Initialized
INFO - 2017-03-20 11:31:23 --> Loader Class Initialized
INFO - 2017-03-20 11:31:23 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:23 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:23 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:23 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:23 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:23 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:23 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005883, 1)
INFO - 2017-03-20 16:01:23 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:23 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:23 --> Total execution time: 0.0405
ERROR - 2017-03-20 16:01:23 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0073950290679932
WHERE `id` =0
INFO - 2017-03-20 11:31:24 --> Config Class Initialized
INFO - 2017-03-20 11:31:24 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:24 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:24 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:24 --> URI Class Initialized
INFO - 2017-03-20 11:31:24 --> Router Class Initialized
INFO - 2017-03-20 11:31:24 --> Output Class Initialized
INFO - 2017-03-20 11:31:24 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:24 --> Input Class Initialized
INFO - 2017-03-20 11:31:24 --> Language Class Initialized
INFO - 2017-03-20 11:31:24 --> Loader Class Initialized
INFO - 2017-03-20 11:31:24 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:24 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:24 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:24 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:24 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:24 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:24 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005884, 1)
INFO - 2017-03-20 16:01:24 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:24 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:24 --> Total execution time: 0.0400
ERROR - 2017-03-20 16:01:24 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0086791515350342
WHERE `id` =0
INFO - 2017-03-20 11:31:24 --> Config Class Initialized
INFO - 2017-03-20 11:31:24 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:24 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:24 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:24 --> URI Class Initialized
INFO - 2017-03-20 11:31:24 --> Router Class Initialized
INFO - 2017-03-20 11:31:24 --> Output Class Initialized
INFO - 2017-03-20 11:31:24 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:24 --> Input Class Initialized
INFO - 2017-03-20 11:31:24 --> Language Class Initialized
INFO - 2017-03-20 11:31:24 --> Loader Class Initialized
INFO - 2017-03-20 11:31:24 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:24 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:24 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:24 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:24 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:24 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:24 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005884, 1)
INFO - 2017-03-20 16:01:24 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:24 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:24 --> Total execution time: 0.0375
ERROR - 2017-03-20 16:01:24 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0061290264129639
WHERE `id` =0
INFO - 2017-03-20 11:31:51 --> Config Class Initialized
INFO - 2017-03-20 11:31:51 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:31:51 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:31:51 --> Utf8 Class Initialized
INFO - 2017-03-20 11:31:51 --> URI Class Initialized
INFO - 2017-03-20 11:31:51 --> Router Class Initialized
INFO - 2017-03-20 11:31:51 --> Output Class Initialized
INFO - 2017-03-20 11:31:51 --> Security Class Initialized
DEBUG - 2017-03-20 11:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:31:51 --> Input Class Initialized
INFO - 2017-03-20 11:31:51 --> Language Class Initialized
INFO - 2017-03-20 11:31:51 --> Loader Class Initialized
INFO - 2017-03-20 11:31:51 --> Helper loaded: common_helper
INFO - 2017-03-20 11:31:51 --> Database Driver Class Initialized
INFO - 2017-03-20 11:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:31:51 --> Controller Class Initialized
DEBUG - 2017-03-20 11:31:51 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:31:51 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:31:51 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:01:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490005911, 1)
INFO - 2017-03-20 16:01:51 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:01:51 --> Final output sent to browser
DEBUG - 2017-03-20 16:01:51 --> Total execution time: 0.0407
ERROR - 2017-03-20 16:01:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0063478946685791
WHERE `id` =0
INFO - 2017-03-20 11:33:27 --> Config Class Initialized
INFO - 2017-03-20 11:33:27 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:27 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:27 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:27 --> URI Class Initialized
INFO - 2017-03-20 11:33:27 --> Router Class Initialized
INFO - 2017-03-20 11:33:27 --> Output Class Initialized
INFO - 2017-03-20 11:33:27 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:27 --> Input Class Initialized
INFO - 2017-03-20 11:33:27 --> Language Class Initialized
INFO - 2017-03-20 11:33:27 --> Loader Class Initialized
INFO - 2017-03-20 11:33:27 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:27 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:27 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:27 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:27 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:27 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:27 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006007, 1)
INFO - 2017-03-20 16:03:27 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:27 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:27 --> Total execution time: 0.0585
ERROR - 2017-03-20 16:03:27 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0089948177337646
WHERE `id` =0
INFO - 2017-03-20 11:33:28 --> Config Class Initialized
INFO - 2017-03-20 11:33:28 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:28 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:28 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:28 --> URI Class Initialized
INFO - 2017-03-20 11:33:28 --> Router Class Initialized
INFO - 2017-03-20 11:33:28 --> Output Class Initialized
INFO - 2017-03-20 11:33:28 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:28 --> Input Class Initialized
INFO - 2017-03-20 11:33:28 --> Language Class Initialized
INFO - 2017-03-20 11:33:28 --> Loader Class Initialized
INFO - 2017-03-20 11:33:28 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:28 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:28 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:28 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:28 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:28 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:28 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006008, 1)
INFO - 2017-03-20 16:03:28 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:28 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:28 --> Total execution time: 0.0482
ERROR - 2017-03-20 16:03:28 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0071418285369873
WHERE `id` =0
INFO - 2017-03-20 11:33:31 --> Config Class Initialized
INFO - 2017-03-20 11:33:31 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:31 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:31 --> URI Class Initialized
INFO - 2017-03-20 11:33:31 --> Router Class Initialized
INFO - 2017-03-20 11:33:31 --> Output Class Initialized
INFO - 2017-03-20 11:33:31 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:31 --> Input Class Initialized
INFO - 2017-03-20 11:33:31 --> Language Class Initialized
INFO - 2017-03-20 11:33:31 --> Loader Class Initialized
INFO - 2017-03-20 11:33:31 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:31 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:31 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:31 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:31 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:31 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006011, 1)
INFO - 2017-03-20 16:03:31 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:31 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:31 --> Total execution time: 0.0518
ERROR - 2017-03-20 16:03:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0067470073699951
WHERE `id` =0
INFO - 2017-03-20 11:33:31 --> Config Class Initialized
INFO - 2017-03-20 11:33:31 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:31 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:31 --> URI Class Initialized
INFO - 2017-03-20 11:33:31 --> Router Class Initialized
INFO - 2017-03-20 11:33:31 --> Output Class Initialized
INFO - 2017-03-20 11:33:31 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:31 --> Input Class Initialized
INFO - 2017-03-20 11:33:31 --> Language Class Initialized
INFO - 2017-03-20 11:33:31 --> Loader Class Initialized
INFO - 2017-03-20 11:33:31 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:31 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:31 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:31 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:31 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:31 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006011, 1)
INFO - 2017-03-20 16:03:31 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:31 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:31 --> Total execution time: 0.0365
ERROR - 2017-03-20 16:03:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0059680938720703
WHERE `id` =0
INFO - 2017-03-20 11:33:31 --> Config Class Initialized
INFO - 2017-03-20 11:33:31 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:31 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:31 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:31 --> URI Class Initialized
INFO - 2017-03-20 11:33:31 --> Router Class Initialized
INFO - 2017-03-20 11:33:31 --> Output Class Initialized
INFO - 2017-03-20 11:33:31 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:31 --> Input Class Initialized
INFO - 2017-03-20 11:33:31 --> Language Class Initialized
INFO - 2017-03-20 11:33:31 --> Loader Class Initialized
INFO - 2017-03-20 11:33:31 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:31 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:31 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:31 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:31 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:31 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006011, 1)
INFO - 2017-03-20 16:03:31 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:31 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:31 --> Total execution time: 0.0602
ERROR - 2017-03-20 16:03:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0073001384735107
WHERE `id` =0
INFO - 2017-03-20 11:33:32 --> Config Class Initialized
INFO - 2017-03-20 11:33:32 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:32 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:32 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:32 --> URI Class Initialized
INFO - 2017-03-20 11:33:32 --> Router Class Initialized
INFO - 2017-03-20 11:33:32 --> Output Class Initialized
INFO - 2017-03-20 11:33:32 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:32 --> Input Class Initialized
INFO - 2017-03-20 11:33:32 --> Language Class Initialized
INFO - 2017-03-20 11:33:32 --> Loader Class Initialized
INFO - 2017-03-20 11:33:32 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:32 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:32 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006012, 1)
INFO - 2017-03-20 16:03:32 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:32 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:32 --> Total execution time: 0.0490
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0061461925506592
WHERE `id` =0
INFO - 2017-03-20 11:33:32 --> Config Class Initialized
INFO - 2017-03-20 11:33:32 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:32 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:32 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:32 --> URI Class Initialized
INFO - 2017-03-20 11:33:32 --> Router Class Initialized
INFO - 2017-03-20 11:33:32 --> Output Class Initialized
INFO - 2017-03-20 11:33:32 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:32 --> Input Class Initialized
INFO - 2017-03-20 11:33:32 --> Language Class Initialized
INFO - 2017-03-20 11:33:32 --> Loader Class Initialized
INFO - 2017-03-20 11:33:32 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:32 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:32 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006012, 1)
INFO - 2017-03-20 16:03:32 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:32 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:32 --> Total execution time: 0.0592
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0064010620117188
WHERE `id` =0
INFO - 2017-03-20 11:33:32 --> Config Class Initialized
INFO - 2017-03-20 11:33:32 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:32 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:32 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:32 --> URI Class Initialized
INFO - 2017-03-20 11:33:32 --> Router Class Initialized
INFO - 2017-03-20 11:33:32 --> Output Class Initialized
INFO - 2017-03-20 11:33:32 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:32 --> Input Class Initialized
INFO - 2017-03-20 11:33:32 --> Language Class Initialized
INFO - 2017-03-20 11:33:32 --> Loader Class Initialized
INFO - 2017-03-20 11:33:32 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:32 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:32 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006012, 1)
INFO - 2017-03-20 16:03:32 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:32 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:32 --> Total execution time: 0.0379
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0069570541381836
WHERE `id` =0
INFO - 2017-03-20 11:33:32 --> Config Class Initialized
INFO - 2017-03-20 11:33:32 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:32 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:32 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:32 --> URI Class Initialized
INFO - 2017-03-20 11:33:32 --> Router Class Initialized
INFO - 2017-03-20 11:33:32 --> Output Class Initialized
INFO - 2017-03-20 11:33:32 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:32 --> Input Class Initialized
INFO - 2017-03-20 11:33:32 --> Language Class Initialized
INFO - 2017-03-20 11:33:32 --> Loader Class Initialized
INFO - 2017-03-20 11:33:32 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:32 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:32 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006012, 1)
INFO - 2017-03-20 16:03:32 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:32 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:32 --> Total execution time: 0.0551
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.006295919418335
WHERE `id` =0
INFO - 2017-03-20 11:33:32 --> Config Class Initialized
INFO - 2017-03-20 11:33:32 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:32 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:32 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:32 --> URI Class Initialized
INFO - 2017-03-20 11:33:32 --> Router Class Initialized
INFO - 2017-03-20 11:33:32 --> Output Class Initialized
INFO - 2017-03-20 11:33:32 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:32 --> Input Class Initialized
INFO - 2017-03-20 11:33:32 --> Language Class Initialized
INFO - 2017-03-20 11:33:32 --> Loader Class Initialized
INFO - 2017-03-20 11:33:32 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:32 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:32 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:32 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:32 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006012, 1)
INFO - 2017-03-20 16:03:32 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:32 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:32 --> Total execution time: 0.0403
ERROR - 2017-03-20 16:03:32 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0059158802032471
WHERE `id` =0
INFO - 2017-03-20 11:33:33 --> Config Class Initialized
INFO - 2017-03-20 11:33:33 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:33 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:33 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:33 --> URI Class Initialized
INFO - 2017-03-20 11:33:33 --> Router Class Initialized
INFO - 2017-03-20 11:33:33 --> Output Class Initialized
INFO - 2017-03-20 11:33:33 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:33 --> Input Class Initialized
INFO - 2017-03-20 11:33:33 --> Language Class Initialized
INFO - 2017-03-20 11:33:33 --> Loader Class Initialized
INFO - 2017-03-20 11:33:33 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:33 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:33 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:33 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:33 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:33 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006013, 1)
INFO - 2017-03-20 16:03:33 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:33 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:33 --> Total execution time: 0.0512
ERROR - 2017-03-20 16:03:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0069289207458496
WHERE `id` =0
INFO - 2017-03-20 11:33:33 --> Config Class Initialized
INFO - 2017-03-20 11:33:33 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:33 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:33 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:33 --> URI Class Initialized
INFO - 2017-03-20 11:33:33 --> Router Class Initialized
INFO - 2017-03-20 11:33:33 --> Output Class Initialized
INFO - 2017-03-20 11:33:33 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:33 --> Input Class Initialized
INFO - 2017-03-20 11:33:33 --> Language Class Initialized
INFO - 2017-03-20 11:33:33 --> Loader Class Initialized
INFO - 2017-03-20 11:33:33 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:33 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:33 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:33 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:33 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:33 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006013, 1)
INFO - 2017-03-20 16:03:33 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:33 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:33 --> Total execution time: 0.0428
ERROR - 2017-03-20 16:03:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0072450637817383
WHERE `id` =0
INFO - 2017-03-20 11:33:49 --> Config Class Initialized
INFO - 2017-03-20 11:33:49 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:33:49 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:33:49 --> Utf8 Class Initialized
INFO - 2017-03-20 11:33:49 --> URI Class Initialized
INFO - 2017-03-20 11:33:49 --> Router Class Initialized
INFO - 2017-03-20 11:33:49 --> Output Class Initialized
INFO - 2017-03-20 11:33:49 --> Security Class Initialized
DEBUG - 2017-03-20 11:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:33:49 --> Input Class Initialized
INFO - 2017-03-20 11:33:49 --> Language Class Initialized
INFO - 2017-03-20 11:33:49 --> Loader Class Initialized
INFO - 2017-03-20 11:33:49 --> Helper loaded: common_helper
INFO - 2017-03-20 11:33:49 --> Database Driver Class Initialized
INFO - 2017-03-20 11:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:33:49 --> Controller Class Initialized
DEBUG - 2017-03-20 11:33:49 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:33:49 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:33:49 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:03:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006029, 1)
INFO - 2017-03-20 16:03:49 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:03:49 --> Final output sent to browser
DEBUG - 2017-03-20 16:03:49 --> Total execution time: 0.0375
ERROR - 2017-03-20 16:03:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0063519477844238
WHERE `id` =0
INFO - 2017-03-20 11:34:16 --> Config Class Initialized
INFO - 2017-03-20 11:34:16 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:34:16 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:34:16 --> Utf8 Class Initialized
INFO - 2017-03-20 11:34:16 --> URI Class Initialized
INFO - 2017-03-20 11:34:16 --> Router Class Initialized
INFO - 2017-03-20 11:34:16 --> Output Class Initialized
INFO - 2017-03-20 11:34:16 --> Security Class Initialized
DEBUG - 2017-03-20 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:34:16 --> Input Class Initialized
INFO - 2017-03-20 11:34:16 --> Language Class Initialized
INFO - 2017-03-20 11:34:16 --> Loader Class Initialized
INFO - 2017-03-20 11:34:16 --> Helper loaded: common_helper
INFO - 2017-03-20 11:34:16 --> Database Driver Class Initialized
INFO - 2017-03-20 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:34:16 --> Controller Class Initialized
DEBUG - 2017-03-20 11:34:16 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:34:16 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:34:16 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:04:16 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006056, 1)
INFO - 2017-03-20 16:04:16 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:04:16 --> Final output sent to browser
DEBUG - 2017-03-20 16:04:16 --> Total execution time: 0.0398
ERROR - 2017-03-20 16:04:16 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0064761638641357
WHERE `id` =0
INFO - 2017-03-20 11:34:33 --> Config Class Initialized
INFO - 2017-03-20 11:34:33 --> Hooks Class Initialized
DEBUG - 2017-03-20 11:34:33 --> UTF-8 Support Enabled
INFO - 2017-03-20 11:34:33 --> Utf8 Class Initialized
INFO - 2017-03-20 11:34:33 --> URI Class Initialized
INFO - 2017-03-20 11:34:33 --> Router Class Initialized
INFO - 2017-03-20 11:34:33 --> Output Class Initialized
INFO - 2017-03-20 11:34:33 --> Security Class Initialized
DEBUG - 2017-03-20 11:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 11:34:33 --> Input Class Initialized
INFO - 2017-03-20 11:34:33 --> Language Class Initialized
INFO - 2017-03-20 11:34:33 --> Loader Class Initialized
INFO - 2017-03-20 11:34:33 --> Helper loaded: common_helper
INFO - 2017-03-20 11:34:33 --> Database Driver Class Initialized
INFO - 2017-03-20 11:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 11:34:33 --> Controller Class Initialized
DEBUG - 2017-03-20 11:34:33 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 11:34:33 --> Helper loaded: inflector_helper
INFO - 2017-03-20 11:34:33 --> Database Driver Class Initialized
ERROR - 2017-03-20 16:04:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1490006073, 1)
INFO - 2017-03-20 16:04:33 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-03-20 16:04:33 --> Final output sent to browser
DEBUG - 2017-03-20 16:04:33 --> Total execution time: 0.0375
ERROR - 2017-03-20 16:04:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0076899528503418
WHERE `id` =0
INFO - 2017-03-20 12:58:28 --> Config Class Initialized
INFO - 2017-03-20 12:58:28 --> Hooks Class Initialized
DEBUG - 2017-03-20 12:58:28 --> UTF-8 Support Enabled
INFO - 2017-03-20 12:58:28 --> Utf8 Class Initialized
INFO - 2017-03-20 12:58:28 --> URI Class Initialized
INFO - 2017-03-20 12:58:28 --> Router Class Initialized
INFO - 2017-03-20 12:58:28 --> Output Class Initialized
INFO - 2017-03-20 12:58:28 --> Security Class Initialized
DEBUG - 2017-03-20 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 12:58:28 --> Input Class Initialized
INFO - 2017-03-20 12:58:28 --> Language Class Initialized
INFO - 2017-03-20 12:58:28 --> Loader Class Initialized
INFO - 2017-03-20 12:58:28 --> Helper loaded: common_helper
INFO - 2017-03-20 12:58:28 --> Database Driver Class Initialized
INFO - 2017-03-20 12:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 12:58:28 --> Controller Class Initialized
DEBUG - 2017-03-20 12:58:28 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 12:58:28 --> Helper loaded: inflector_helper
INFO - 2017-03-20 12:58:28 --> Database Driver Class Initialized
INFO - 2017-03-20 12:58:28 --> Model Class Initialized
INFO - 2017-03-20 12:58:28 --> Model Class Initialized
INFO - 2017-03-20 12:58:28 --> Helper loaded: url_helper
INFO - 2017-03-20 12:58:28 --> Model Class Initialized
ERROR - 2017-03-20 17:28:28 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/suggestDonar', 'post', '{\"SuggestingUserId\":\"1\",\"phoneNumber\":\"8985716639\",\"emailAddress\":\"ashiya.syed@mizpahsoft.com\"}', '', '::1', 1490011108, 1)
INFO - 2017-03-20 17:28:28 --> Helper loaded: form_helper
INFO - 2017-03-20 17:28:28 --> Form Validation Class Initialized
INFO - 2017-03-20 17:28:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-03-20 17:28:29 --> Email Class Initialized
INFO - 2017-03-20 17:28:30 --> Language file loaded: language/english/email_lang.php
ERROR - 2017-03-20 17:28:31 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 2.607498884201
WHERE `id` =0
INFO - 2017-03-20 12:58:53 --> Config Class Initialized
INFO - 2017-03-20 12:58:53 --> Hooks Class Initialized
DEBUG - 2017-03-20 12:58:53 --> UTF-8 Support Enabled
INFO - 2017-03-20 12:58:53 --> Utf8 Class Initialized
INFO - 2017-03-20 12:58:53 --> URI Class Initialized
INFO - 2017-03-20 12:58:53 --> Router Class Initialized
INFO - 2017-03-20 12:58:53 --> Output Class Initialized
INFO - 2017-03-20 12:58:53 --> Security Class Initialized
DEBUG - 2017-03-20 12:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 12:58:53 --> Input Class Initialized
INFO - 2017-03-20 12:58:53 --> Language Class Initialized
INFO - 2017-03-20 12:58:53 --> Loader Class Initialized
INFO - 2017-03-20 12:58:53 --> Helper loaded: common_helper
INFO - 2017-03-20 12:58:53 --> Database Driver Class Initialized
INFO - 2017-03-20 12:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 12:58:53 --> Controller Class Initialized
DEBUG - 2017-03-20 12:58:53 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 12:58:53 --> Helper loaded: inflector_helper
INFO - 2017-03-20 12:58:53 --> Database Driver Class Initialized
INFO - 2017-03-20 12:58:53 --> Model Class Initialized
INFO - 2017-03-20 12:58:53 --> Model Class Initialized
INFO - 2017-03-20 12:58:53 --> Helper loaded: url_helper
INFO - 2017-03-20 12:58:53 --> Model Class Initialized
ERROR - 2017-03-20 17:28:53 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/suggestDonar', 'post', '{\"SuggestingUserId\":\"1\",\"phoneNumber\":\"8985716639\",\"emailAddress\":\"ashiya.syed@mizpahsoft.com\"}', '', '::1', 1490011133, 1)
INFO - 2017-03-20 17:28:53 --> Helper loaded: form_helper
INFO - 2017-03-20 17:28:53 --> Form Validation Class Initialized
INFO - 2017-03-20 17:28:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:28:53 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.31462693214417
WHERE `id` =0
INFO - 2017-03-20 13:05:12 --> Config Class Initialized
INFO - 2017-03-20 13:05:12 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:05:12 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:05:12 --> Utf8 Class Initialized
INFO - 2017-03-20 13:05:12 --> URI Class Initialized
INFO - 2017-03-20 13:05:12 --> Router Class Initialized
INFO - 2017-03-20 13:05:12 --> Output Class Initialized
INFO - 2017-03-20 13:05:12 --> Security Class Initialized
DEBUG - 2017-03-20 13:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:05:12 --> Input Class Initialized
INFO - 2017-03-20 13:05:12 --> Language Class Initialized
INFO - 2017-03-20 13:05:12 --> Loader Class Initialized
INFO - 2017-03-20 13:05:12 --> Helper loaded: common_helper
INFO - 2017-03-20 13:05:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:05:12 --> Controller Class Initialized
DEBUG - 2017-03-20 13:05:12 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:05:12 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:05:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:05:12 --> Model Class Initialized
INFO - 2017-03-20 13:05:12 --> Model Class Initialized
INFO - 2017-03-20 13:05:12 --> Helper loaded: url_helper
INFO - 2017-03-20 13:05:12 --> Model Class Initialized
ERROR - 2017-03-20 17:35:12 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/suggestDonar', 'post', '{\"SuggestingUserId\":\"1\",\"phoneNumber\":\"8985716639\",\"emailAddress\":\"ashiya.syed@mizpahsoft.com\"}', '', '::1', 1490011512, 1)
INFO - 2017-03-20 17:35:12 --> Helper loaded: form_helper
INFO - 2017-03-20 17:35:12 --> Form Validation Class Initialized
INFO - 2017-03-20 17:35:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:35:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.38980102539062
WHERE `id` =0
INFO - 2017-03-20 13:18:24 --> Config Class Initialized
INFO - 2017-03-20 13:18:24 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:18:24 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:18:24 --> Utf8 Class Initialized
INFO - 2017-03-20 13:18:24 --> URI Class Initialized
INFO - 2017-03-20 13:18:24 --> Router Class Initialized
INFO - 2017-03-20 13:18:24 --> Output Class Initialized
INFO - 2017-03-20 13:18:24 --> Security Class Initialized
DEBUG - 2017-03-20 13:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:18:24 --> Input Class Initialized
INFO - 2017-03-20 13:18:24 --> Language Class Initialized
INFO - 2017-03-20 13:18:24 --> Loader Class Initialized
INFO - 2017-03-20 13:18:24 --> Helper loaded: common_helper
INFO - 2017-03-20 13:18:24 --> Database Driver Class Initialized
INFO - 2017-03-20 13:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:18:24 --> Controller Class Initialized
DEBUG - 2017-03-20 13:18:24 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:18:24 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:18:24 --> Database Driver Class Initialized
INFO - 2017-03-20 13:18:24 --> Model Class Initialized
INFO - 2017-03-20 13:18:24 --> Model Class Initialized
INFO - 2017-03-20 13:18:24 --> Helper loaded: url_helper
INFO - 2017-03-20 13:18:24 --> Model Class Initialized
ERROR - 2017-03-20 17:48:24 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012304, 1)
INFO - 2017-03-20 17:48:24 --> Helper loaded: form_helper
INFO - 2017-03-20 17:48:24 --> Form Validation Class Initialized
INFO - 2017-03-20 17:48:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:48:25 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.38979291915894
WHERE `id` =0
INFO - 2017-03-20 13:21:45 --> Config Class Initialized
INFO - 2017-03-20 13:21:45 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:21:45 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:21:45 --> Utf8 Class Initialized
INFO - 2017-03-20 13:21:45 --> URI Class Initialized
INFO - 2017-03-20 13:21:45 --> Router Class Initialized
INFO - 2017-03-20 13:21:45 --> Output Class Initialized
INFO - 2017-03-20 13:21:45 --> Security Class Initialized
DEBUG - 2017-03-20 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:21:45 --> Input Class Initialized
INFO - 2017-03-20 13:21:45 --> Language Class Initialized
INFO - 2017-03-20 13:21:45 --> Loader Class Initialized
INFO - 2017-03-20 13:21:45 --> Helper loaded: common_helper
INFO - 2017-03-20 13:21:45 --> Database Driver Class Initialized
INFO - 2017-03-20 13:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:21:45 --> Controller Class Initialized
DEBUG - 2017-03-20 13:21:45 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:21:45 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:21:45 --> Database Driver Class Initialized
INFO - 2017-03-20 13:21:45 --> Model Class Initialized
INFO - 2017-03-20 13:21:45 --> Model Class Initialized
INFO - 2017-03-20 13:21:45 --> Helper loaded: url_helper
INFO - 2017-03-20 13:21:45 --> Model Class Initialized
ERROR - 2017-03-20 17:51:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012505, 1)
INFO - 2017-03-20 17:51:45 --> Helper loaded: form_helper
INFO - 2017-03-20 17:51:45 --> Form Validation Class Initialized
INFO - 2017-03-20 17:51:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:51:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.3674738407135
WHERE `id` =0
INFO - 2017-03-20 13:22:02 --> Config Class Initialized
INFO - 2017-03-20 13:22:02 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:22:02 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:22:02 --> Utf8 Class Initialized
INFO - 2017-03-20 13:22:02 --> URI Class Initialized
INFO - 2017-03-20 13:22:02 --> Router Class Initialized
INFO - 2017-03-20 13:22:02 --> Output Class Initialized
INFO - 2017-03-20 13:22:02 --> Security Class Initialized
DEBUG - 2017-03-20 13:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:22:02 --> Input Class Initialized
INFO - 2017-03-20 13:22:02 --> Language Class Initialized
INFO - 2017-03-20 13:22:02 --> Loader Class Initialized
INFO - 2017-03-20 13:22:02 --> Helper loaded: common_helper
INFO - 2017-03-20 13:22:02 --> Database Driver Class Initialized
INFO - 2017-03-20 13:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:22:02 --> Controller Class Initialized
DEBUG - 2017-03-20 13:22:02 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:22:02 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:22:02 --> Database Driver Class Initialized
INFO - 2017-03-20 13:22:02 --> Model Class Initialized
INFO - 2017-03-20 13:22:02 --> Model Class Initialized
INFO - 2017-03-20 13:22:02 --> Helper loaded: url_helper
INFO - 2017-03-20 13:22:02 --> Model Class Initialized
ERROR - 2017-03-20 17:52:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012522, 1)
INFO - 2017-03-20 17:52:02 --> Helper loaded: form_helper
INFO - 2017-03-20 17:52:02 --> Form Validation Class Initialized
INFO - 2017-03-20 17:52:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:52:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.30623602867126
WHERE `id` =0
INFO - 2017-03-20 13:22:48 --> Config Class Initialized
INFO - 2017-03-20 13:22:48 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:22:48 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:22:48 --> Utf8 Class Initialized
INFO - 2017-03-20 13:22:48 --> URI Class Initialized
INFO - 2017-03-20 13:22:48 --> Router Class Initialized
INFO - 2017-03-20 13:22:48 --> Output Class Initialized
INFO - 2017-03-20 13:22:48 --> Security Class Initialized
DEBUG - 2017-03-20 13:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:22:48 --> Input Class Initialized
INFO - 2017-03-20 13:22:48 --> Language Class Initialized
INFO - 2017-03-20 13:22:48 --> Loader Class Initialized
INFO - 2017-03-20 13:22:48 --> Helper loaded: common_helper
INFO - 2017-03-20 13:22:48 --> Database Driver Class Initialized
INFO - 2017-03-20 13:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:22:48 --> Controller Class Initialized
DEBUG - 2017-03-20 13:22:48 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:22:48 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:22:48 --> Database Driver Class Initialized
INFO - 2017-03-20 13:22:48 --> Model Class Initialized
INFO - 2017-03-20 13:22:48 --> Model Class Initialized
INFO - 2017-03-20 13:22:48 --> Helper loaded: url_helper
INFO - 2017-03-20 13:22:48 --> Model Class Initialized
ERROR - 2017-03-20 17:52:48 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012568, 1)
INFO - 2017-03-20 17:52:48 --> Helper loaded: form_helper
INFO - 2017-03-20 17:52:48 --> Form Validation Class Initialized
INFO - 2017-03-20 17:52:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:52:48 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.33418297767639
WHERE `id` =0
INFO - 2017-03-20 13:23:43 --> Config Class Initialized
INFO - 2017-03-20 13:23:43 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:23:43 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:23:43 --> Utf8 Class Initialized
INFO - 2017-03-20 13:23:43 --> URI Class Initialized
INFO - 2017-03-20 13:23:43 --> Router Class Initialized
INFO - 2017-03-20 13:23:43 --> Output Class Initialized
INFO - 2017-03-20 13:23:43 --> Security Class Initialized
DEBUG - 2017-03-20 13:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:23:43 --> Input Class Initialized
INFO - 2017-03-20 13:23:43 --> Language Class Initialized
INFO - 2017-03-20 13:23:43 --> Loader Class Initialized
INFO - 2017-03-20 13:23:43 --> Helper loaded: common_helper
INFO - 2017-03-20 13:23:43 --> Database Driver Class Initialized
INFO - 2017-03-20 13:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:23:43 --> Controller Class Initialized
DEBUG - 2017-03-20 13:23:43 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:23:43 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:23:43 --> Database Driver Class Initialized
INFO - 2017-03-20 13:23:43 --> Model Class Initialized
INFO - 2017-03-20 13:23:43 --> Model Class Initialized
INFO - 2017-03-20 13:23:43 --> Helper loaded: url_helper
INFO - 2017-03-20 13:23:43 --> Model Class Initialized
ERROR - 2017-03-20 17:53:43 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012623, 1)
INFO - 2017-03-20 17:53:43 --> Helper loaded: form_helper
INFO - 2017-03-20 17:53:43 --> Form Validation Class Initialized
INFO - 2017-03-20 17:53:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:53:52 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 9.3267500400543
WHERE `id` =0
INFO - 2017-03-20 13:24:58 --> Config Class Initialized
INFO - 2017-03-20 13:24:58 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:24:58 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:24:58 --> Utf8 Class Initialized
INFO - 2017-03-20 13:24:58 --> URI Class Initialized
INFO - 2017-03-20 13:24:58 --> Router Class Initialized
INFO - 2017-03-20 13:24:58 --> Output Class Initialized
INFO - 2017-03-20 13:24:58 --> Security Class Initialized
DEBUG - 2017-03-20 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:24:58 --> Input Class Initialized
INFO - 2017-03-20 13:24:58 --> Language Class Initialized
INFO - 2017-03-20 13:24:58 --> Loader Class Initialized
INFO - 2017-03-20 13:24:58 --> Helper loaded: common_helper
INFO - 2017-03-20 13:24:58 --> Database Driver Class Initialized
INFO - 2017-03-20 13:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:24:58 --> Controller Class Initialized
DEBUG - 2017-03-20 13:24:58 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:24:58 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:24:58 --> Database Driver Class Initialized
INFO - 2017-03-20 13:24:58 --> Model Class Initialized
INFO - 2017-03-20 13:24:58 --> Model Class Initialized
INFO - 2017-03-20 13:24:58 --> Helper loaded: url_helper
INFO - 2017-03-20 13:24:58 --> Model Class Initialized
ERROR - 2017-03-20 17:54:58 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012698, 1)
INFO - 2017-03-20 17:54:58 --> Helper loaded: form_helper
INFO - 2017-03-20 17:54:58 --> Form Validation Class Initialized
INFO - 2017-03-20 17:54:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:54:59 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.32870197296143
WHERE `id` =0
INFO - 2017-03-20 13:25:12 --> Config Class Initialized
INFO - 2017-03-20 13:25:12 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:25:12 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:25:12 --> Utf8 Class Initialized
INFO - 2017-03-20 13:25:12 --> URI Class Initialized
INFO - 2017-03-20 13:25:12 --> Router Class Initialized
INFO - 2017-03-20 13:25:12 --> Output Class Initialized
INFO - 2017-03-20 13:25:12 --> Security Class Initialized
DEBUG - 2017-03-20 13:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:25:12 --> Input Class Initialized
INFO - 2017-03-20 13:25:12 --> Language Class Initialized
INFO - 2017-03-20 13:25:12 --> Loader Class Initialized
INFO - 2017-03-20 13:25:12 --> Helper loaded: common_helper
INFO - 2017-03-20 13:25:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:25:12 --> Controller Class Initialized
DEBUG - 2017-03-20 13:25:12 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:25:12 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:25:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:25:12 --> Model Class Initialized
INFO - 2017-03-20 13:25:12 --> Model Class Initialized
INFO - 2017-03-20 13:25:12 --> Helper loaded: url_helper
INFO - 2017-03-20 13:25:12 --> Model Class Initialized
ERROR - 2017-03-20 17:55:12 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"11\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012712, 1)
INFO - 2017-03-20 17:55:12 --> Helper loaded: form_helper
INFO - 2017-03-20 17:55:12 --> Form Validation Class Initialized
INFO - 2017-03-20 17:55:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:55:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 1.0221500396729
WHERE `id` =0
INFO - 2017-03-20 13:26:41 --> Config Class Initialized
INFO - 2017-03-20 13:26:41 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:26:41 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:26:41 --> Utf8 Class Initialized
INFO - 2017-03-20 13:26:41 --> URI Class Initialized
INFO - 2017-03-20 13:26:41 --> Router Class Initialized
INFO - 2017-03-20 13:26:41 --> Output Class Initialized
INFO - 2017-03-20 13:26:41 --> Security Class Initialized
DEBUG - 2017-03-20 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:26:41 --> Input Class Initialized
INFO - 2017-03-20 13:26:41 --> Language Class Initialized
INFO - 2017-03-20 13:26:41 --> Loader Class Initialized
INFO - 2017-03-20 13:26:41 --> Helper loaded: common_helper
INFO - 2017-03-20 13:26:41 --> Database Driver Class Initialized
INFO - 2017-03-20 13:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:26:41 --> Controller Class Initialized
DEBUG - 2017-03-20 13:26:41 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:26:41 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:26:41 --> Database Driver Class Initialized
INFO - 2017-03-20 13:26:41 --> Model Class Initialized
INFO - 2017-03-20 13:26:41 --> Model Class Initialized
INFO - 2017-03-20 13:26:41 --> Helper loaded: url_helper
INFO - 2017-03-20 13:26:41 --> Model Class Initialized
ERROR - 2017-03-20 17:56:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"2\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012801, 1)
INFO - 2017-03-20 17:56:41 --> Helper loaded: form_helper
INFO - 2017-03-20 17:56:41 --> Form Validation Class Initialized
INFO - 2017-03-20 17:56:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:56:42 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.78146910667419
WHERE `id` =0
INFO - 2017-03-20 13:28:39 --> Config Class Initialized
INFO - 2017-03-20 13:28:39 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:28:39 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:28:39 --> Utf8 Class Initialized
INFO - 2017-03-20 13:28:39 --> URI Class Initialized
INFO - 2017-03-20 13:28:39 --> Router Class Initialized
INFO - 2017-03-20 13:28:39 --> Output Class Initialized
INFO - 2017-03-20 13:28:39 --> Security Class Initialized
DEBUG - 2017-03-20 13:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:28:39 --> Input Class Initialized
INFO - 2017-03-20 13:28:39 --> Language Class Initialized
INFO - 2017-03-20 13:28:39 --> Loader Class Initialized
INFO - 2017-03-20 13:28:39 --> Helper loaded: common_helper
INFO - 2017-03-20 13:28:39 --> Database Driver Class Initialized
INFO - 2017-03-20 13:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:28:39 --> Controller Class Initialized
DEBUG - 2017-03-20 13:28:39 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:28:39 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:28:39 --> Database Driver Class Initialized
INFO - 2017-03-20 13:28:39 --> Model Class Initialized
INFO - 2017-03-20 13:28:39 --> Model Class Initialized
INFO - 2017-03-20 13:28:39 --> Helper loaded: url_helper
INFO - 2017-03-20 13:28:39 --> Model Class Initialized
ERROR - 2017-03-20 17:58:39 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"2\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490012919, 1)
INFO - 2017-03-20 17:58:39 --> Helper loaded: form_helper
INFO - 2017-03-20 17:58:39 --> Form Validation Class Initialized
INFO - 2017-03-20 17:58:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 17:58:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.47100400924683
WHERE `id` =0
INFO - 2017-03-20 13:30:00 --> Config Class Initialized
INFO - 2017-03-20 13:30:00 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:30:00 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:30:00 --> Utf8 Class Initialized
INFO - 2017-03-20 13:30:00 --> URI Class Initialized
INFO - 2017-03-20 13:30:00 --> Router Class Initialized
INFO - 2017-03-20 13:30:00 --> Output Class Initialized
INFO - 2017-03-20 13:30:00 --> Security Class Initialized
DEBUG - 2017-03-20 13:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:30:00 --> Input Class Initialized
INFO - 2017-03-20 13:30:00 --> Language Class Initialized
INFO - 2017-03-20 13:30:00 --> Loader Class Initialized
INFO - 2017-03-20 13:30:00 --> Helper loaded: common_helper
INFO - 2017-03-20 13:30:00 --> Database Driver Class Initialized
INFO - 2017-03-20 13:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:30:00 --> Controller Class Initialized
DEBUG - 2017-03-20 13:30:00 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:30:00 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:30:00 --> Database Driver Class Initialized
INFO - 2017-03-20 13:30:00 --> Model Class Initialized
INFO - 2017-03-20 13:30:00 --> Model Class Initialized
INFO - 2017-03-20 13:30:00 --> Helper loaded: url_helper
INFO - 2017-03-20 13:30:00 --> Model Class Initialized
ERROR - 2017-03-20 18:00:00 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"2\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490013000, 1)
INFO - 2017-03-20 18:00:00 --> Helper loaded: form_helper
INFO - 2017-03-20 18:00:00 --> Form Validation Class Initialized
INFO - 2017-03-20 18:00:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:00:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.89936113357544
WHERE `id` =0
INFO - 2017-03-20 13:30:52 --> Config Class Initialized
INFO - 2017-03-20 13:30:52 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:30:52 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:30:52 --> Utf8 Class Initialized
INFO - 2017-03-20 13:30:52 --> URI Class Initialized
INFO - 2017-03-20 13:30:52 --> Router Class Initialized
INFO - 2017-03-20 13:30:52 --> Output Class Initialized
INFO - 2017-03-20 13:30:52 --> Security Class Initialized
DEBUG - 2017-03-20 13:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:30:52 --> Input Class Initialized
INFO - 2017-03-20 13:30:52 --> Language Class Initialized
INFO - 2017-03-20 13:30:52 --> Loader Class Initialized
INFO - 2017-03-20 13:30:52 --> Helper loaded: common_helper
INFO - 2017-03-20 13:30:52 --> Database Driver Class Initialized
INFO - 2017-03-20 13:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:30:52 --> Controller Class Initialized
DEBUG - 2017-03-20 13:30:52 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:30:52 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:30:52 --> Database Driver Class Initialized
INFO - 2017-03-20 13:30:52 --> Model Class Initialized
INFO - 2017-03-20 13:30:52 --> Model Class Initialized
INFO - 2017-03-20 13:30:52 --> Helper loaded: url_helper
INFO - 2017-03-20 13:30:52 --> Model Class Initialized
ERROR - 2017-03-20 18:00:52 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"2\"}', '', '::1', 1490013052, 1)
ERROR - 2017-03-20 18:00:52 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.016331911087036
WHERE `id` =0
INFO - 2017-03-20 13:31:00 --> Config Class Initialized
INFO - 2017-03-20 13:31:00 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:31:00 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:31:00 --> Utf8 Class Initialized
INFO - 2017-03-20 13:31:00 --> URI Class Initialized
INFO - 2017-03-20 13:31:00 --> Router Class Initialized
INFO - 2017-03-20 13:31:00 --> Output Class Initialized
INFO - 2017-03-20 13:31:00 --> Security Class Initialized
DEBUG - 2017-03-20 13:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:31:00 --> Input Class Initialized
INFO - 2017-03-20 13:31:00 --> Language Class Initialized
INFO - 2017-03-20 13:31:00 --> Loader Class Initialized
INFO - 2017-03-20 13:31:00 --> Helper loaded: common_helper
INFO - 2017-03-20 13:31:00 --> Database Driver Class Initialized
INFO - 2017-03-20 13:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:31:00 --> Controller Class Initialized
DEBUG - 2017-03-20 13:31:00 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:31:00 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:31:00 --> Database Driver Class Initialized
INFO - 2017-03-20 13:31:00 --> Model Class Initialized
INFO - 2017-03-20 13:31:00 --> Model Class Initialized
INFO - 2017-03-20 13:31:00 --> Helper loaded: url_helper
INFO - 2017-03-20 13:31:00 --> Model Class Initialized
ERROR - 2017-03-20 18:01:00 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013060, 1)
ERROR - 2017-03-20 18:01:00 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.02060604095459
WHERE `id` =0
INFO - 2017-03-20 13:33:29 --> Config Class Initialized
INFO - 2017-03-20 13:33:29 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:33:29 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:33:29 --> Utf8 Class Initialized
INFO - 2017-03-20 13:33:29 --> URI Class Initialized
INFO - 2017-03-20 13:33:29 --> Router Class Initialized
INFO - 2017-03-20 13:33:29 --> Output Class Initialized
INFO - 2017-03-20 13:33:29 --> Security Class Initialized
DEBUG - 2017-03-20 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:33:29 --> Input Class Initialized
INFO - 2017-03-20 13:33:29 --> Language Class Initialized
INFO - 2017-03-20 13:33:29 --> Loader Class Initialized
INFO - 2017-03-20 13:33:29 --> Helper loaded: common_helper
INFO - 2017-03-20 13:33:29 --> Database Driver Class Initialized
INFO - 2017-03-20 13:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:33:29 --> Controller Class Initialized
DEBUG - 2017-03-20 13:33:29 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:33:29 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:33:29 --> Database Driver Class Initialized
INFO - 2017-03-20 13:33:29 --> Model Class Initialized
INFO - 2017-03-20 13:33:29 --> Model Class Initialized
INFO - 2017-03-20 13:33:29 --> Helper loaded: url_helper
INFO - 2017-03-20 13:33:29 --> Model Class Initialized
ERROR - 2017-03-20 18:03:29 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013209, 1)
ERROR - 2017-03-20 18:03:29 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.024368047714233
WHERE `id` =0
INFO - 2017-03-20 13:33:40 --> Config Class Initialized
INFO - 2017-03-20 13:33:40 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:33:40 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:33:40 --> Utf8 Class Initialized
INFO - 2017-03-20 13:33:40 --> URI Class Initialized
INFO - 2017-03-20 13:33:40 --> Router Class Initialized
INFO - 2017-03-20 13:33:40 --> Output Class Initialized
INFO - 2017-03-20 13:33:40 --> Security Class Initialized
DEBUG - 2017-03-20 13:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:33:40 --> Input Class Initialized
INFO - 2017-03-20 13:33:40 --> Language Class Initialized
INFO - 2017-03-20 13:33:40 --> Loader Class Initialized
INFO - 2017-03-20 13:33:40 --> Helper loaded: common_helper
INFO - 2017-03-20 13:33:40 --> Database Driver Class Initialized
INFO - 2017-03-20 13:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:33:40 --> Controller Class Initialized
DEBUG - 2017-03-20 13:33:40 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:33:40 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:33:40 --> Database Driver Class Initialized
INFO - 2017-03-20 13:33:40 --> Model Class Initialized
INFO - 2017-03-20 13:33:40 --> Model Class Initialized
INFO - 2017-03-20 13:33:40 --> Helper loaded: url_helper
INFO - 2017-03-20 13:33:40 --> Model Class Initialized
ERROR - 2017-03-20 18:03:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"2\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490013220, 1)
INFO - 2017-03-20 18:03:40 --> Helper loaded: form_helper
INFO - 2017-03-20 18:03:40 --> Form Validation Class Initialized
INFO - 2017-03-20 18:03:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:03:41 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.7792181968689
WHERE `id` =0
INFO - 2017-03-20 13:33:45 --> Config Class Initialized
INFO - 2017-03-20 13:33:45 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:33:45 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:33:45 --> Utf8 Class Initialized
INFO - 2017-03-20 13:33:45 --> URI Class Initialized
INFO - 2017-03-20 13:33:45 --> Router Class Initialized
INFO - 2017-03-20 13:33:45 --> Output Class Initialized
INFO - 2017-03-20 13:33:45 --> Security Class Initialized
DEBUG - 2017-03-20 13:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:33:45 --> Input Class Initialized
INFO - 2017-03-20 13:33:45 --> Language Class Initialized
INFO - 2017-03-20 13:33:45 --> Loader Class Initialized
INFO - 2017-03-20 13:33:45 --> Helper loaded: common_helper
INFO - 2017-03-20 13:33:45 --> Database Driver Class Initialized
INFO - 2017-03-20 13:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:33:45 --> Controller Class Initialized
DEBUG - 2017-03-20 13:33:45 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:33:45 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:33:45 --> Database Driver Class Initialized
INFO - 2017-03-20 13:33:45 --> Model Class Initialized
INFO - 2017-03-20 13:33:45 --> Model Class Initialized
INFO - 2017-03-20 13:33:45 --> Helper loaded: url_helper
INFO - 2017-03-20 13:33:45 --> Model Class Initialized
ERROR - 2017-03-20 18:03:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013225, 1)
ERROR - 2017-03-20 18:03:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.014157056808472
WHERE `id` =0
INFO - 2017-03-20 13:34:09 --> Config Class Initialized
INFO - 2017-03-20 13:34:09 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:34:09 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:34:09 --> Utf8 Class Initialized
INFO - 2017-03-20 13:34:09 --> URI Class Initialized
INFO - 2017-03-20 13:34:09 --> Router Class Initialized
INFO - 2017-03-20 13:34:09 --> Output Class Initialized
INFO - 2017-03-20 13:34:09 --> Security Class Initialized
DEBUG - 2017-03-20 13:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:34:09 --> Input Class Initialized
INFO - 2017-03-20 13:34:09 --> Language Class Initialized
INFO - 2017-03-20 13:34:09 --> Loader Class Initialized
INFO - 2017-03-20 13:34:09 --> Helper loaded: common_helper
INFO - 2017-03-20 13:34:09 --> Database Driver Class Initialized
INFO - 2017-03-20 13:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:34:09 --> Controller Class Initialized
DEBUG - 2017-03-20 13:34:09 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:34:09 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:34:09 --> Database Driver Class Initialized
INFO - 2017-03-20 13:34:09 --> Model Class Initialized
INFO - 2017-03-20 13:34:09 --> Model Class Initialized
INFO - 2017-03-20 13:34:09 --> Helper loaded: url_helper
INFO - 2017-03-20 13:34:09 --> Model Class Initialized
ERROR - 2017-03-20 18:04:09 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013249, 1)
ERROR - 2017-03-20 18:04:09 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.013782978057861
WHERE `id` =0
INFO - 2017-03-20 13:42:50 --> Config Class Initialized
INFO - 2017-03-20 13:42:50 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:42:50 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:42:50 --> Utf8 Class Initialized
INFO - 2017-03-20 13:42:50 --> URI Class Initialized
INFO - 2017-03-20 13:42:50 --> Router Class Initialized
INFO - 2017-03-20 13:42:50 --> Output Class Initialized
INFO - 2017-03-20 13:42:50 --> Security Class Initialized
DEBUG - 2017-03-20 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:42:50 --> Input Class Initialized
INFO - 2017-03-20 13:42:50 --> Language Class Initialized
INFO - 2017-03-20 13:42:50 --> Loader Class Initialized
INFO - 2017-03-20 13:42:50 --> Helper loaded: common_helper
INFO - 2017-03-20 13:42:50 --> Database Driver Class Initialized
INFO - 2017-03-20 13:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:42:50 --> Controller Class Initialized
DEBUG - 2017-03-20 13:42:50 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:42:50 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:42:50 --> Database Driver Class Initialized
INFO - 2017-03-20 13:42:50 --> Model Class Initialized
INFO - 2017-03-20 13:42:50 --> Model Class Initialized
INFO - 2017-03-20 13:42:50 --> Helper loaded: url_helper
INFO - 2017-03-20 13:42:50 --> Model Class Initialized
ERROR - 2017-03-20 18:12:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/suggestDonar', 'post', '{\"SuggestingUserId\":\"1\",\"phoneNumber\":\"8985716639\",\"emailAddress\":\"ashiya.syed@mizpahsoft.com\"}', '', '::1', 1490013770, 1)
INFO - 2017-03-20 18:12:50 --> Helper loaded: form_helper
INFO - 2017-03-20 18:12:50 --> Form Validation Class Initialized
INFO - 2017-03-20 18:12:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:12:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.34900999069214
WHERE `id` =0
INFO - 2017-03-20 13:43:50 --> Config Class Initialized
INFO - 2017-03-20 13:43:50 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:43:50 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:43:50 --> Utf8 Class Initialized
INFO - 2017-03-20 13:43:50 --> URI Class Initialized
INFO - 2017-03-20 13:43:50 --> Router Class Initialized
INFO - 2017-03-20 13:43:50 --> Output Class Initialized
INFO - 2017-03-20 13:43:50 --> Security Class Initialized
DEBUG - 2017-03-20 13:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:43:50 --> Input Class Initialized
INFO - 2017-03-20 13:43:50 --> Language Class Initialized
INFO - 2017-03-20 13:43:50 --> Loader Class Initialized
INFO - 2017-03-20 13:43:50 --> Helper loaded: common_helper
INFO - 2017-03-20 13:43:50 --> Database Driver Class Initialized
INFO - 2017-03-20 13:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:43:50 --> Controller Class Initialized
DEBUG - 2017-03-20 13:43:50 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:43:50 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:43:50 --> Database Driver Class Initialized
INFO - 2017-03-20 13:43:50 --> Model Class Initialized
INFO - 2017-03-20 13:43:50 --> Model Class Initialized
INFO - 2017-03-20 13:43:50 --> Helper loaded: url_helper
INFO - 2017-03-20 13:43:50 --> Model Class Initialized
ERROR - 2017-03-20 18:13:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013830, 1)
ERROR - 2017-03-20 18:13:50 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.015321016311646
WHERE `id` =0
INFO - 2017-03-20 13:44:12 --> Config Class Initialized
INFO - 2017-03-20 13:44:12 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:44:12 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:44:12 --> Utf8 Class Initialized
INFO - 2017-03-20 13:44:12 --> URI Class Initialized
INFO - 2017-03-20 13:44:12 --> Router Class Initialized
INFO - 2017-03-20 13:44:12 --> Output Class Initialized
INFO - 2017-03-20 13:44:12 --> Security Class Initialized
DEBUG - 2017-03-20 13:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:44:12 --> Input Class Initialized
INFO - 2017-03-20 13:44:12 --> Language Class Initialized
INFO - 2017-03-20 13:44:12 --> Loader Class Initialized
INFO - 2017-03-20 13:44:12 --> Helper loaded: common_helper
INFO - 2017-03-20 13:44:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:44:12 --> Controller Class Initialized
DEBUG - 2017-03-20 13:44:12 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:44:12 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:44:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:44:12 --> Model Class Initialized
INFO - 2017-03-20 13:44:12 --> Model Class Initialized
INFO - 2017-03-20 13:44:12 --> Helper loaded: url_helper
INFO - 2017-03-20 13:44:12 --> Model Class Initialized
ERROR - 2017-03-20 18:14:12 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490013852, 1)
INFO - 2017-03-20 18:14:12 --> Helper loaded: form_helper
INFO - 2017-03-20 18:14:12 --> Form Validation Class Initialized
INFO - 2017-03-20 18:14:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:14:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.73242092132568
WHERE `id` =0
INFO - 2017-03-20 13:44:15 --> Config Class Initialized
INFO - 2017-03-20 13:44:15 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:44:15 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:44:15 --> Utf8 Class Initialized
INFO - 2017-03-20 13:44:15 --> URI Class Initialized
INFO - 2017-03-20 13:44:15 --> Router Class Initialized
INFO - 2017-03-20 13:44:15 --> Output Class Initialized
INFO - 2017-03-20 13:44:15 --> Security Class Initialized
DEBUG - 2017-03-20 13:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:44:15 --> Input Class Initialized
INFO - 2017-03-20 13:44:15 --> Language Class Initialized
INFO - 2017-03-20 13:44:15 --> Loader Class Initialized
INFO - 2017-03-20 13:44:15 --> Helper loaded: common_helper
INFO - 2017-03-20 13:44:15 --> Database Driver Class Initialized
INFO - 2017-03-20 13:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:44:15 --> Controller Class Initialized
DEBUG - 2017-03-20 13:44:15 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:44:15 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:44:15 --> Database Driver Class Initialized
INFO - 2017-03-20 13:44:15 --> Model Class Initialized
INFO - 2017-03-20 13:44:15 --> Model Class Initialized
INFO - 2017-03-20 13:44:15 --> Helper loaded: url_helper
INFO - 2017-03-20 13:44:15 --> Model Class Initialized
ERROR - 2017-03-20 18:14:15 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013855, 1)
ERROR - 2017-03-20 18:14:15 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.017242193222046
WHERE `id` =0
INFO - 2017-03-20 13:46:12 --> Config Class Initialized
INFO - 2017-03-20 13:46:12 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:46:12 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:46:12 --> Utf8 Class Initialized
INFO - 2017-03-20 13:46:12 --> URI Class Initialized
INFO - 2017-03-20 13:46:12 --> Router Class Initialized
INFO - 2017-03-20 13:46:12 --> Output Class Initialized
INFO - 2017-03-20 13:46:12 --> Security Class Initialized
DEBUG - 2017-03-20 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:46:12 --> Input Class Initialized
INFO - 2017-03-20 13:46:12 --> Language Class Initialized
INFO - 2017-03-20 13:46:12 --> Loader Class Initialized
INFO - 2017-03-20 13:46:12 --> Helper loaded: common_helper
INFO - 2017-03-20 13:46:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:46:12 --> Controller Class Initialized
DEBUG - 2017-03-20 13:46:12 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:46:12 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:46:12 --> Database Driver Class Initialized
INFO - 2017-03-20 13:46:12 --> Model Class Initialized
INFO - 2017-03-20 13:46:12 --> Model Class Initialized
INFO - 2017-03-20 13:46:12 --> Helper loaded: url_helper
INFO - 2017-03-20 13:46:12 --> Model Class Initialized
ERROR - 2017-03-20 18:16:12 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notificationsCount', 'get', '{\"userId\":\"1\"}', '', '::1', 1490013972, 1)
ERROR - 2017-03-20 18:16:12 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.01682710647583
WHERE `id` =0
INFO - 2017-03-20 13:58:46 --> Config Class Initialized
INFO - 2017-03-20 13:58:46 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:58:46 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:58:46 --> Utf8 Class Initialized
INFO - 2017-03-20 13:58:46 --> URI Class Initialized
INFO - 2017-03-20 13:58:46 --> Router Class Initialized
INFO - 2017-03-20 13:58:46 --> Output Class Initialized
INFO - 2017-03-20 13:58:46 --> Security Class Initialized
DEBUG - 2017-03-20 13:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:58:46 --> Input Class Initialized
INFO - 2017-03-20 13:58:46 --> Language Class Initialized
INFO - 2017-03-20 13:58:46 --> Loader Class Initialized
INFO - 2017-03-20 13:58:46 --> Helper loaded: common_helper
INFO - 2017-03-20 13:58:46 --> Database Driver Class Initialized
INFO - 2017-03-20 13:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:58:46 --> Controller Class Initialized
DEBUG - 2017-03-20 13:58:46 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:58:46 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:58:46 --> Database Driver Class Initialized
INFO - 2017-03-20 13:58:46 --> Model Class Initialized
INFO - 2017-03-20 13:58:46 --> Model Class Initialized
INFO - 2017-03-20 13:58:46 --> Helper loaded: url_helper
INFO - 2017-03-20 13:58:46 --> Model Class Initialized
ERROR - 2017-03-20 18:28:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490014726, 1)
INFO - 2017-03-20 18:28:46 --> Helper loaded: form_helper
INFO - 2017-03-20 18:28:46 --> Form Validation Class Initialized
INFO - 2017-03-20 18:28:46 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:28:46 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.3294939994812
WHERE `id` =0
INFO - 2017-03-20 13:59:02 --> Config Class Initialized
INFO - 2017-03-20 13:59:02 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:59:02 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:59:02 --> Utf8 Class Initialized
INFO - 2017-03-20 13:59:02 --> URI Class Initialized
INFO - 2017-03-20 13:59:02 --> Router Class Initialized
INFO - 2017-03-20 13:59:02 --> Output Class Initialized
INFO - 2017-03-20 13:59:02 --> Security Class Initialized
DEBUG - 2017-03-20 13:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:59:02 --> Input Class Initialized
INFO - 2017-03-20 13:59:02 --> Language Class Initialized
INFO - 2017-03-20 13:59:02 --> Loader Class Initialized
INFO - 2017-03-20 13:59:02 --> Helper loaded: common_helper
INFO - 2017-03-20 13:59:02 --> Database Driver Class Initialized
INFO - 2017-03-20 13:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:59:02 --> Controller Class Initialized
DEBUG - 2017-03-20 13:59:02 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:59:02 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:59:02 --> Database Driver Class Initialized
INFO - 2017-03-20 13:59:02 --> Model Class Initialized
INFO - 2017-03-20 13:59:02 --> Model Class Initialized
INFO - 2017-03-20 13:59:02 --> Helper loaded: url_helper
INFO - 2017-03-20 13:59:02 --> Model Class Initialized
ERROR - 2017-03-20 18:29:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490014742, 1)
INFO - 2017-03-20 18:29:02 --> Helper loaded: form_helper
INFO - 2017-03-20 18:29:02 --> Form Validation Class Initialized
INFO - 2017-03-20 18:29:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:29:02 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.44292593002319
WHERE `id` =0
INFO - 2017-03-20 13:59:40 --> Config Class Initialized
INFO - 2017-03-20 13:59:40 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:59:40 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:59:40 --> Utf8 Class Initialized
INFO - 2017-03-20 13:59:40 --> URI Class Initialized
INFO - 2017-03-20 13:59:40 --> Router Class Initialized
INFO - 2017-03-20 13:59:40 --> Output Class Initialized
INFO - 2017-03-20 13:59:40 --> Security Class Initialized
DEBUG - 2017-03-20 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:59:40 --> Input Class Initialized
INFO - 2017-03-20 13:59:40 --> Language Class Initialized
INFO - 2017-03-20 13:59:40 --> Loader Class Initialized
INFO - 2017-03-20 13:59:40 --> Helper loaded: common_helper
INFO - 2017-03-20 13:59:40 --> Database Driver Class Initialized
INFO - 2017-03-20 13:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:59:40 --> Controller Class Initialized
DEBUG - 2017-03-20 13:59:40 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:59:40 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:59:40 --> Database Driver Class Initialized
INFO - 2017-03-20 13:59:40 --> Model Class Initialized
INFO - 2017-03-20 13:59:40 --> Model Class Initialized
INFO - 2017-03-20 13:59:40 --> Helper loaded: url_helper
INFO - 2017-03-20 13:59:40 --> Model Class Initialized
ERROR - 2017-03-20 18:29:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490014780, 1)
INFO - 2017-03-20 18:29:40 --> Helper loaded: form_helper
INFO - 2017-03-20 18:29:40 --> Form Validation Class Initialized
INFO - 2017-03-20 18:29:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:29:40 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.51247096061707
WHERE `id` =0
INFO - 2017-03-20 13:59:58 --> Config Class Initialized
INFO - 2017-03-20 13:59:58 --> Hooks Class Initialized
DEBUG - 2017-03-20 13:59:58 --> UTF-8 Support Enabled
INFO - 2017-03-20 13:59:58 --> Utf8 Class Initialized
INFO - 2017-03-20 13:59:58 --> URI Class Initialized
INFO - 2017-03-20 13:59:58 --> Router Class Initialized
INFO - 2017-03-20 13:59:58 --> Output Class Initialized
INFO - 2017-03-20 13:59:58 --> Security Class Initialized
DEBUG - 2017-03-20 13:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-20 13:59:58 --> Input Class Initialized
INFO - 2017-03-20 13:59:58 --> Language Class Initialized
INFO - 2017-03-20 13:59:58 --> Loader Class Initialized
INFO - 2017-03-20 13:59:58 --> Helper loaded: common_helper
INFO - 2017-03-20 13:59:58 --> Database Driver Class Initialized
INFO - 2017-03-20 13:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-20 13:59:58 --> Controller Class Initialized
DEBUG - 2017-03-20 13:59:58 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-20 13:59:58 --> Helper loaded: inflector_helper
INFO - 2017-03-20 13:59:58 --> Database Driver Class Initialized
INFO - 2017-03-20 13:59:58 --> Model Class Initialized
INFO - 2017-03-20 13:59:58 --> Model Class Initialized
INFO - 2017-03-20 13:59:58 --> Helper loaded: url_helper
INFO - 2017-03-20 13:59:58 --> Model Class Initialized
ERROR - 2017-03-20 18:29:58 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/addBloodRequest', 'post', '{\"userId\":\"14\",\"bloodGroup\":\"1\",\"address\":\"hyderabad\"}', '', '::1', 1490014798, 1)
INFO - 2017-03-20 18:29:58 --> Helper loaded: form_helper
INFO - 2017-03-20 18:29:58 --> Form Validation Class Initialized
INFO - 2017-03-20 18:29:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-20 18:29:59 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.84223294258118
WHERE `id` =0
