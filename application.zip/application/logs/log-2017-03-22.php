<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-22 12:42:33 --> Config Class Initialized
INFO - 2017-03-22 12:42:33 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:42:33 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:42:33 --> Utf8 Class Initialized
INFO - 2017-03-22 12:42:33 --> URI Class Initialized
INFO - 2017-03-22 12:42:33 --> Router Class Initialized
INFO - 2017-03-22 12:42:33 --> Output Class Initialized
INFO - 2017-03-22 12:42:33 --> Security Class Initialized
DEBUG - 2017-03-22 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:42:33 --> Input Class Initialized
INFO - 2017-03-22 12:42:33 --> Language Class Initialized
INFO - 2017-03-22 12:42:33 --> Loader Class Initialized
INFO - 2017-03-22 12:42:33 --> Helper loaded: common_helper
INFO - 2017-03-22 12:42:33 --> Database Driver Class Initialized
INFO - 2017-03-22 12:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:42:33 --> Email Class Initialized
INFO - 2017-03-22 12:42:33 --> Controller Class Initialized
DEBUG - 2017-03-22 12:42:33 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:42:33 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:42:33 --> Database Driver Class Initialized
INFO - 2017-03-22 12:42:33 --> Model Class Initialized
INFO - 2017-03-22 12:42:33 --> Model Class Initialized
INFO - 2017-03-22 12:42:33 --> Helper loaded: url_helper
INFO - 2017-03-22 12:42:33 --> Model Class Initialized
ERROR - 2017-03-22 17:12:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490182953, 1)
INFO - 2017-03-22 17:12:33 --> Helper loaded: form_helper
INFO - 2017-03-22 17:12:33 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:12:33 --> Undefined variable: bld
ERROR - 2017-03-22 17:12:33 --> Severity: Notice --> Undefined variable: bld C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
INFO - 2017-03-22 17:12:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-22 17:12:33 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.17397212982178
WHERE `id` =0
INFO - 2017-03-22 12:43:06 --> Config Class Initialized
INFO - 2017-03-22 12:43:06 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:43:06 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:43:06 --> Utf8 Class Initialized
INFO - 2017-03-22 12:43:06 --> URI Class Initialized
INFO - 2017-03-22 12:43:06 --> Router Class Initialized
INFO - 2017-03-22 12:43:06 --> Output Class Initialized
INFO - 2017-03-22 12:43:06 --> Security Class Initialized
DEBUG - 2017-03-22 12:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:43:06 --> Input Class Initialized
INFO - 2017-03-22 12:43:06 --> Language Class Initialized
INFO - 2017-03-22 12:43:06 --> Loader Class Initialized
INFO - 2017-03-22 12:43:06 --> Helper loaded: common_helper
INFO - 2017-03-22 12:43:06 --> Database Driver Class Initialized
INFO - 2017-03-22 12:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:43:06 --> Email Class Initialized
INFO - 2017-03-22 12:43:06 --> Controller Class Initialized
DEBUG - 2017-03-22 12:43:06 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:43:06 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:43:06 --> Database Driver Class Initialized
INFO - 2017-03-22 12:43:06 --> Model Class Initialized
INFO - 2017-03-22 12:43:06 --> Model Class Initialized
INFO - 2017-03-22 12:43:06 --> Helper loaded: url_helper
INFO - 2017-03-22 12:43:07 --> Model Class Initialized
ERROR - 2017-03-22 17:13:07 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490182987, 1)
INFO - 2017-03-22 17:13:07 --> Helper loaded: form_helper
INFO - 2017-03-22 17:13:07 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:13:07 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.017471075057983
WHERE `id` =0
INFO - 2017-03-22 12:43:45 --> Config Class Initialized
INFO - 2017-03-22 12:43:45 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:43:45 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:43:45 --> Utf8 Class Initialized
INFO - 2017-03-22 12:43:45 --> URI Class Initialized
INFO - 2017-03-22 12:43:45 --> Router Class Initialized
INFO - 2017-03-22 12:43:45 --> Output Class Initialized
INFO - 2017-03-22 12:43:45 --> Security Class Initialized
DEBUG - 2017-03-22 12:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:43:45 --> Input Class Initialized
INFO - 2017-03-22 12:43:45 --> Language Class Initialized
INFO - 2017-03-22 12:43:45 --> Loader Class Initialized
INFO - 2017-03-22 12:43:45 --> Helper loaded: common_helper
INFO - 2017-03-22 12:43:45 --> Database Driver Class Initialized
INFO - 2017-03-22 12:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:43:45 --> Email Class Initialized
INFO - 2017-03-22 12:43:45 --> Controller Class Initialized
DEBUG - 2017-03-22 12:43:45 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:43:45 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:43:45 --> Database Driver Class Initialized
INFO - 2017-03-22 12:43:45 --> Model Class Initialized
INFO - 2017-03-22 12:43:45 --> Model Class Initialized
INFO - 2017-03-22 12:43:45 --> Helper loaded: url_helper
INFO - 2017-03-22 12:43:45 --> Model Class Initialized
ERROR - 2017-03-22 17:13:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183025, 1)
INFO - 2017-03-22 17:13:45 --> Helper loaded: form_helper
INFO - 2017-03-22 17:13:45 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:13:45 --> Trying to get property of non-object
ERROR - 2017-03-22 17:13:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
INFO - 2017-03-22 17:13:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-22 17:13:45 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.021773099899292
WHERE `id` =0
INFO - 2017-03-22 12:44:20 --> Config Class Initialized
INFO - 2017-03-22 12:44:20 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:44:20 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:44:20 --> Utf8 Class Initialized
INFO - 2017-03-22 12:44:20 --> URI Class Initialized
INFO - 2017-03-22 12:44:20 --> Router Class Initialized
INFO - 2017-03-22 12:44:20 --> Output Class Initialized
INFO - 2017-03-22 12:44:20 --> Security Class Initialized
DEBUG - 2017-03-22 12:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:44:20 --> Input Class Initialized
INFO - 2017-03-22 12:44:20 --> Language Class Initialized
INFO - 2017-03-22 12:44:20 --> Loader Class Initialized
INFO - 2017-03-22 12:44:20 --> Helper loaded: common_helper
INFO - 2017-03-22 12:44:20 --> Database Driver Class Initialized
INFO - 2017-03-22 12:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:44:20 --> Email Class Initialized
INFO - 2017-03-22 12:44:20 --> Controller Class Initialized
DEBUG - 2017-03-22 12:44:20 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:44:20 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:44:20 --> Database Driver Class Initialized
INFO - 2017-03-22 12:44:20 --> Model Class Initialized
INFO - 2017-03-22 12:44:20 --> Model Class Initialized
INFO - 2017-03-22 12:44:20 --> Helper loaded: url_helper
INFO - 2017-03-22 12:44:20 --> Model Class Initialized
ERROR - 2017-03-22 17:14:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183060, 1)
INFO - 2017-03-22 17:14:20 --> Helper loaded: form_helper
INFO - 2017-03-22 17:14:20 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:14:20 --> Trying to get property of non-object
ERROR - 2017-03-22 17:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
ERROR - 2017-03-22 17:14:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.020697832107544
WHERE `id` =0
INFO - 2017-03-22 12:45:01 --> Config Class Initialized
INFO - 2017-03-22 12:45:01 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:45:01 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:45:01 --> Utf8 Class Initialized
INFO - 2017-03-22 12:45:01 --> URI Class Initialized
INFO - 2017-03-22 12:45:01 --> Router Class Initialized
INFO - 2017-03-22 12:45:01 --> Output Class Initialized
INFO - 2017-03-22 12:45:01 --> Security Class Initialized
DEBUG - 2017-03-22 12:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:45:01 --> Input Class Initialized
INFO - 2017-03-22 12:45:01 --> Language Class Initialized
INFO - 2017-03-22 12:45:01 --> Loader Class Initialized
INFO - 2017-03-22 12:45:01 --> Helper loaded: common_helper
INFO - 2017-03-22 12:45:01 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:45:01 --> Email Class Initialized
INFO - 2017-03-22 12:45:01 --> Controller Class Initialized
DEBUG - 2017-03-22 12:45:01 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:45:01 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:45:01 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:01 --> Model Class Initialized
INFO - 2017-03-22 12:45:01 --> Model Class Initialized
INFO - 2017-03-22 12:45:01 --> Helper loaded: url_helper
INFO - 2017-03-22 12:45:01 --> Model Class Initialized
ERROR - 2017-03-22 17:15:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183101, 1)
INFO - 2017-03-22 17:15:01 --> Helper loaded: form_helper
INFO - 2017-03-22 17:15:01 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:15:01 --> Trying to get property of non-object
ERROR - 2017-03-22 17:15:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
ERROR - 2017-03-22 17:15:01 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.021655082702637
WHERE `id` =0
INFO - 2017-03-22 12:45:23 --> Config Class Initialized
INFO - 2017-03-22 12:45:23 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:45:23 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:45:23 --> Utf8 Class Initialized
INFO - 2017-03-22 12:45:23 --> URI Class Initialized
INFO - 2017-03-22 12:45:23 --> Router Class Initialized
INFO - 2017-03-22 12:45:23 --> Output Class Initialized
INFO - 2017-03-22 12:45:23 --> Security Class Initialized
DEBUG - 2017-03-22 12:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:45:23 --> Input Class Initialized
INFO - 2017-03-22 12:45:23 --> Language Class Initialized
INFO - 2017-03-22 12:45:23 --> Loader Class Initialized
INFO - 2017-03-22 12:45:23 --> Helper loaded: common_helper
INFO - 2017-03-22 12:45:23 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:45:23 --> Email Class Initialized
INFO - 2017-03-22 12:45:23 --> Controller Class Initialized
DEBUG - 2017-03-22 12:45:23 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:45:23 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:45:23 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:23 --> Model Class Initialized
INFO - 2017-03-22 12:45:23 --> Model Class Initialized
INFO - 2017-03-22 12:45:23 --> Helper loaded: url_helper
INFO - 2017-03-22 12:45:23 --> Model Class Initialized
ERROR - 2017-03-22 17:15:23 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183123, 1)
INFO - 2017-03-22 17:15:23 --> Helper loaded: form_helper
INFO - 2017-03-22 17:15:23 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:15:23 --> Trying to get property of non-object
ERROR - 2017-03-22 17:15:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
ERROR - 2017-03-22 17:15:23 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.019354104995728
WHERE `id` =0
INFO - 2017-03-22 12:45:35 --> Config Class Initialized
INFO - 2017-03-22 12:45:35 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:45:35 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:45:35 --> Utf8 Class Initialized
INFO - 2017-03-22 12:45:35 --> URI Class Initialized
INFO - 2017-03-22 12:45:35 --> Router Class Initialized
INFO - 2017-03-22 12:45:35 --> Output Class Initialized
INFO - 2017-03-22 12:45:35 --> Security Class Initialized
DEBUG - 2017-03-22 12:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:45:35 --> Input Class Initialized
INFO - 2017-03-22 12:45:35 --> Language Class Initialized
INFO - 2017-03-22 12:45:35 --> Loader Class Initialized
INFO - 2017-03-22 12:45:35 --> Helper loaded: common_helper
INFO - 2017-03-22 12:45:35 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:45:35 --> Email Class Initialized
INFO - 2017-03-22 12:45:35 --> Controller Class Initialized
DEBUG - 2017-03-22 12:45:35 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:45:35 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:45:35 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:35 --> Model Class Initialized
INFO - 2017-03-22 12:45:35 --> Model Class Initialized
INFO - 2017-03-22 12:45:35 --> Helper loaded: url_helper
INFO - 2017-03-22 12:45:35 --> Model Class Initialized
ERROR - 2017-03-22 17:15:35 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183135, 1)
INFO - 2017-03-22 17:15:35 --> Helper loaded: form_helper
INFO - 2017-03-22 17:15:35 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:15:35 --> Trying to get property of non-object
ERROR - 2017-03-22 17:15:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
ERROR - 2017-03-22 17:15:35 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.019345998764038
WHERE `id` =0
INFO - 2017-03-22 12:45:47 --> Config Class Initialized
INFO - 2017-03-22 12:45:47 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:45:47 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:45:47 --> Utf8 Class Initialized
INFO - 2017-03-22 12:45:47 --> URI Class Initialized
INFO - 2017-03-22 12:45:47 --> Router Class Initialized
INFO - 2017-03-22 12:45:47 --> Output Class Initialized
INFO - 2017-03-22 12:45:47 --> Security Class Initialized
DEBUG - 2017-03-22 12:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:45:47 --> Input Class Initialized
INFO - 2017-03-22 12:45:47 --> Language Class Initialized
INFO - 2017-03-22 12:45:47 --> Loader Class Initialized
INFO - 2017-03-22 12:45:47 --> Helper loaded: common_helper
INFO - 2017-03-22 12:45:47 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:45:47 --> Email Class Initialized
INFO - 2017-03-22 12:45:47 --> Controller Class Initialized
DEBUG - 2017-03-22 12:45:47 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:45:47 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:45:47 --> Database Driver Class Initialized
INFO - 2017-03-22 12:45:47 --> Model Class Initialized
INFO - 2017-03-22 12:45:47 --> Model Class Initialized
INFO - 2017-03-22 12:45:47 --> Helper loaded: url_helper
INFO - 2017-03-22 12:45:47 --> Model Class Initialized
ERROR - 2017-03-22 17:15:47 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183147, 1)
INFO - 2017-03-22 17:15:47 --> Helper loaded: form_helper
INFO - 2017-03-22 17:15:47 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:15:47 --> Trying to get property of non-object
ERROR - 2017-03-22 17:15:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
ERROR - 2017-03-22 17:15:47 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.02032995223999
WHERE `id` =0
INFO - 2017-03-22 12:46:54 --> Config Class Initialized
INFO - 2017-03-22 12:46:54 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:46:54 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:46:54 --> Utf8 Class Initialized
INFO - 2017-03-22 12:46:54 --> URI Class Initialized
INFO - 2017-03-22 12:46:54 --> Router Class Initialized
INFO - 2017-03-22 12:46:54 --> Output Class Initialized
INFO - 2017-03-22 12:46:54 --> Security Class Initialized
DEBUG - 2017-03-22 12:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:46:54 --> Input Class Initialized
INFO - 2017-03-22 12:46:54 --> Language Class Initialized
INFO - 2017-03-22 12:46:54 --> Loader Class Initialized
INFO - 2017-03-22 12:46:54 --> Helper loaded: common_helper
INFO - 2017-03-22 12:46:54 --> Database Driver Class Initialized
INFO - 2017-03-22 12:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:46:54 --> Email Class Initialized
INFO - 2017-03-22 12:46:54 --> Controller Class Initialized
DEBUG - 2017-03-22 12:46:54 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:46:54 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:46:54 --> Database Driver Class Initialized
INFO - 2017-03-22 12:46:54 --> Model Class Initialized
INFO - 2017-03-22 12:46:54 --> Model Class Initialized
INFO - 2017-03-22 12:46:54 --> Helper loaded: url_helper
INFO - 2017-03-22 12:46:54 --> Model Class Initialized
ERROR - 2017-03-22 17:16:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183214, 1)
INFO - 2017-03-22 17:16:54 --> Helper loaded: form_helper
INFO - 2017-03-22 17:16:54 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:16:54 --> Trying to get property of non-object
ERROR - 2017-03-22 17:16:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
INFO - 2017-03-22 17:16:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-22 17:16:54 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.022979021072388
WHERE `id` =0
INFO - 2017-03-22 12:47:05 --> Config Class Initialized
INFO - 2017-03-22 12:47:05 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:47:05 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:47:05 --> Utf8 Class Initialized
INFO - 2017-03-22 12:47:05 --> URI Class Initialized
INFO - 2017-03-22 12:47:05 --> Router Class Initialized
INFO - 2017-03-22 12:47:05 --> Output Class Initialized
INFO - 2017-03-22 12:47:05 --> Security Class Initialized
DEBUG - 2017-03-22 12:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:47:05 --> Input Class Initialized
INFO - 2017-03-22 12:47:05 --> Language Class Initialized
INFO - 2017-03-22 12:47:05 --> Loader Class Initialized
INFO - 2017-03-22 12:47:05 --> Helper loaded: common_helper
INFO - 2017-03-22 12:47:05 --> Database Driver Class Initialized
INFO - 2017-03-22 12:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:47:05 --> Email Class Initialized
INFO - 2017-03-22 12:47:05 --> Controller Class Initialized
DEBUG - 2017-03-22 12:47:05 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:47:05 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:47:05 --> Database Driver Class Initialized
INFO - 2017-03-22 12:47:05 --> Model Class Initialized
INFO - 2017-03-22 12:47:05 --> Model Class Initialized
INFO - 2017-03-22 12:47:05 --> Helper loaded: url_helper
INFO - 2017-03-22 12:47:05 --> Model Class Initialized
ERROR - 2017-03-22 17:17:05 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183225, 1)
INFO - 2017-03-22 17:17:05 --> Helper loaded: form_helper
INFO - 2017-03-22 17:17:05 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:17:05 --> Trying to get property of non-object
ERROR - 2017-03-22 17:17:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
INFO - 2017-03-22 17:17:05 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-22 17:17:05 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.02577805519104
WHERE `id` =0
INFO - 2017-03-22 12:47:06 --> Config Class Initialized
INFO - 2017-03-22 12:47:06 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:47:06 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:47:06 --> Utf8 Class Initialized
INFO - 2017-03-22 12:47:06 --> URI Class Initialized
INFO - 2017-03-22 12:47:06 --> Router Class Initialized
INFO - 2017-03-22 12:47:06 --> Output Class Initialized
INFO - 2017-03-22 12:47:06 --> Security Class Initialized
DEBUG - 2017-03-22 12:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:47:06 --> Input Class Initialized
INFO - 2017-03-22 12:47:06 --> Language Class Initialized
INFO - 2017-03-22 12:47:06 --> Loader Class Initialized
INFO - 2017-03-22 12:47:06 --> Helper loaded: common_helper
INFO - 2017-03-22 12:47:06 --> Database Driver Class Initialized
INFO - 2017-03-22 12:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:47:06 --> Email Class Initialized
INFO - 2017-03-22 12:47:06 --> Controller Class Initialized
DEBUG - 2017-03-22 12:47:06 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:47:06 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:47:06 --> Database Driver Class Initialized
INFO - 2017-03-22 12:47:06 --> Model Class Initialized
INFO - 2017-03-22 12:47:06 --> Model Class Initialized
INFO - 2017-03-22 12:47:06 --> Helper loaded: url_helper
INFO - 2017-03-22 12:47:06 --> Model Class Initialized
ERROR - 2017-03-22 17:17:06 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183226, 1)
INFO - 2017-03-22 17:17:06 --> Helper loaded: form_helper
INFO - 2017-03-22 17:17:06 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:17:06 --> Trying to get property of non-object
ERROR - 2017-03-22 17:17:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 544
INFO - 2017-03-22 17:17:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-22 17:17:06 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.021596193313599
WHERE `id` =0
INFO - 2017-03-22 12:48:43 --> Config Class Initialized
INFO - 2017-03-22 12:48:43 --> Hooks Class Initialized
DEBUG - 2017-03-22 12:48:43 --> UTF-8 Support Enabled
INFO - 2017-03-22 12:48:43 --> Utf8 Class Initialized
INFO - 2017-03-22 12:48:43 --> URI Class Initialized
INFO - 2017-03-22 12:48:43 --> Router Class Initialized
INFO - 2017-03-22 12:48:43 --> Output Class Initialized
INFO - 2017-03-22 12:48:43 --> Security Class Initialized
DEBUG - 2017-03-22 12:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-22 12:48:43 --> Input Class Initialized
INFO - 2017-03-22 12:48:43 --> Language Class Initialized
INFO - 2017-03-22 12:48:43 --> Loader Class Initialized
INFO - 2017-03-22 12:48:43 --> Helper loaded: common_helper
INFO - 2017-03-22 12:48:43 --> Database Driver Class Initialized
INFO - 2017-03-22 12:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-22 12:48:43 --> Email Class Initialized
INFO - 2017-03-22 12:48:43 --> Controller Class Initialized
DEBUG - 2017-03-22 12:48:43 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-22 12:48:43 --> Helper loaded: inflector_helper
INFO - 2017-03-22 12:48:43 --> Database Driver Class Initialized
INFO - 2017-03-22 12:48:43 --> Model Class Initialized
INFO - 2017-03-22 12:48:43 --> Model Class Initialized
INFO - 2017-03-22 12:48:43 --> Helper loaded: url_helper
INFO - 2017-03-22 12:48:43 --> Model Class Initialized
ERROR - 2017-03-22 17:18:43 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/bloodRequests/acceptRequest', 'post', '{\"userId\":\"1\",\"requestId\":\"1\"}', '', '::1', 1490183323, 1)
INFO - 2017-03-22 17:18:43 --> Helper loaded: form_helper
INFO - 2017-03-22 17:18:43 --> Form Validation Class Initialized
ERROR - 2017-03-22 17:18:43 --> Undefined variable: requestDetails
ERROR - 2017-03-22 17:18:43 --> Severity: Notice --> Undefined variable: requestDetails C:\xampp\htdocs\blooddonation\application\controllers\Webservices\BloodRequests.php 543
INFO - 2017-03-22 17:18:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-03-22 17:18:43 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.021960020065308
WHERE `id` =0
