<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-03-23 06:27:44 --> Config Class Initialized
INFO - 2017-03-23 06:27:44 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:27:44 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:27:44 --> Utf8 Class Initialized
INFO - 2017-03-23 06:27:44 --> URI Class Initialized
INFO - 2017-03-23 06:27:44 --> Router Class Initialized
INFO - 2017-03-23 06:27:44 --> Output Class Initialized
INFO - 2017-03-23 06:27:44 --> Security Class Initialized
DEBUG - 2017-03-23 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:27:44 --> Input Class Initialized
INFO - 2017-03-23 06:27:44 --> Language Class Initialized
INFO - 2017-03-23 06:27:44 --> Loader Class Initialized
INFO - 2017-03-23 06:27:44 --> Helper loaded: common_helper
INFO - 2017-03-23 06:27:44 --> Database Driver Class Initialized
INFO - 2017-03-23 06:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:27:44 --> Email Class Initialized
INFO - 2017-03-23 06:27:44 --> Controller Class Initialized
DEBUG - 2017-03-23 06:27:44 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:27:44 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:27:44 --> Database Driver Class Initialized
INFO - 2017-03-23 06:27:44 --> Model Class Initialized
INFO - 2017-03-23 06:27:44 --> Model Class Initialized
INFO - 2017-03-23 06:27:44 --> Helper loaded: url_helper
ERROR - 2017-03-23 10:57:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/profile', 'get', '{\"userId\":\"5\"}', '', '::1', 1490246864, 1)
ERROR - 2017-03-23 10:57:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.039700984954834
WHERE `id` =0
INFO - 2017-03-23 06:28:36 --> Config Class Initialized
INFO - 2017-03-23 06:28:36 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:28:36 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:28:36 --> Utf8 Class Initialized
INFO - 2017-03-23 06:28:36 --> URI Class Initialized
INFO - 2017-03-23 06:28:36 --> Router Class Initialized
INFO - 2017-03-23 06:28:36 --> Output Class Initialized
INFO - 2017-03-23 06:28:36 --> Security Class Initialized
DEBUG - 2017-03-23 06:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:28:36 --> Input Class Initialized
INFO - 2017-03-23 06:28:36 --> Language Class Initialized
INFO - 2017-03-23 06:28:36 --> Loader Class Initialized
INFO - 2017-03-23 06:28:36 --> Helper loaded: common_helper
INFO - 2017-03-23 06:28:36 --> Database Driver Class Initialized
INFO - 2017-03-23 06:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:28:36 --> Email Class Initialized
INFO - 2017-03-23 06:28:36 --> Controller Class Initialized
DEBUG - 2017-03-23 06:28:36 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:28:36 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:28:36 --> Database Driver Class Initialized
INFO - 2017-03-23 06:28:36 --> Model Class Initialized
INFO - 2017-03-23 06:28:36 --> Model Class Initialized
INFO - 2017-03-23 06:28:36 --> Helper loaded: url_helper
ERROR - 2017-03-23 10:58:36 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/profile', 'get', '{\"userId\":\"1\"}', '', '::1', 1490246916, 1)
ERROR - 2017-03-23 10:58:36 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.061087131500244
WHERE `id` =0
INFO - 2017-03-23 06:28:48 --> Config Class Initialized
INFO - 2017-03-23 06:28:48 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:28:48 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:28:48 --> Utf8 Class Initialized
INFO - 2017-03-23 06:28:48 --> URI Class Initialized
INFO - 2017-03-23 06:28:48 --> Router Class Initialized
INFO - 2017-03-23 06:28:48 --> Output Class Initialized
INFO - 2017-03-23 06:28:48 --> Security Class Initialized
DEBUG - 2017-03-23 06:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:28:48 --> Input Class Initialized
INFO - 2017-03-23 06:28:48 --> Language Class Initialized
INFO - 2017-03-23 06:28:48 --> Loader Class Initialized
INFO - 2017-03-23 06:28:48 --> Helper loaded: common_helper
INFO - 2017-03-23 06:28:49 --> Database Driver Class Initialized
INFO - 2017-03-23 06:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:28:49 --> Email Class Initialized
INFO - 2017-03-23 06:28:49 --> Controller Class Initialized
DEBUG - 2017-03-23 06:28:49 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:28:49 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:28:49 --> Database Driver Class Initialized
INFO - 2017-03-23 06:28:49 --> Model Class Initialized
INFO - 2017-03-23 06:28:49 --> Model Class Initialized
INFO - 2017-03-23 06:28:49 --> Helper loaded: url_helper
ERROR - 2017-03-23 10:58:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/profile', 'get', '{\"userId\":\"5\"}', '', '::1', 1490246929, 1)
ERROR - 2017-03-23 10:58:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.010365962982178
WHERE `id` =0
INFO - 2017-03-23 06:30:36 --> Config Class Initialized
INFO - 2017-03-23 06:30:36 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:30:36 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:30:36 --> Utf8 Class Initialized
INFO - 2017-03-23 06:30:36 --> URI Class Initialized
INFO - 2017-03-23 06:30:36 --> Router Class Initialized
INFO - 2017-03-23 06:30:36 --> Output Class Initialized
INFO - 2017-03-23 06:30:36 --> Security Class Initialized
DEBUG - 2017-03-23 06:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:30:36 --> Input Class Initialized
INFO - 2017-03-23 06:30:36 --> Language Class Initialized
INFO - 2017-03-23 06:30:36 --> Loader Class Initialized
INFO - 2017-03-23 06:30:36 --> Helper loaded: common_helper
INFO - 2017-03-23 06:30:36 --> Database Driver Class Initialized
INFO - 2017-03-23 06:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:30:36 --> Email Class Initialized
INFO - 2017-03-23 06:30:36 --> Controller Class Initialized
DEBUG - 2017-03-23 06:30:36 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:30:36 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:30:36 --> Database Driver Class Initialized
INFO - 2017-03-23 06:30:36 --> Model Class Initialized
INFO - 2017-03-23 06:30:36 --> Model Class Initialized
INFO - 2017-03-23 06:30:36 --> Helper loaded: url_helper
INFO - 2017-03-23 06:30:36 --> Model Class Initialized
ERROR - 2017-03-23 11:00:36 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/BloodRequests/notifications', 'get', NULL, '', '::1', 1490247036, 1)
ERROR - 2017-03-23 11:00:36 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.15562987327576
WHERE `id` =0
INFO - 2017-03-23 06:30:44 --> Config Class Initialized
INFO - 2017-03-23 06:30:44 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:30:44 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:30:44 --> Utf8 Class Initialized
INFO - 2017-03-23 06:30:44 --> URI Class Initialized
INFO - 2017-03-23 06:30:44 --> Router Class Initialized
INFO - 2017-03-23 06:30:44 --> Output Class Initialized
INFO - 2017-03-23 06:30:44 --> Security Class Initialized
DEBUG - 2017-03-23 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:30:44 --> Input Class Initialized
INFO - 2017-03-23 06:30:44 --> Language Class Initialized
INFO - 2017-03-23 06:30:44 --> Loader Class Initialized
INFO - 2017-03-23 06:30:44 --> Helper loaded: common_helper
INFO - 2017-03-23 06:30:44 --> Database Driver Class Initialized
INFO - 2017-03-23 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:30:44 --> Email Class Initialized
INFO - 2017-03-23 06:30:44 --> Controller Class Initialized
DEBUG - 2017-03-23 06:30:44 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:30:44 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:30:44 --> Database Driver Class Initialized
INFO - 2017-03-23 06:30:44 --> Model Class Initialized
INFO - 2017-03-23 06:30:44 --> Model Class Initialized
INFO - 2017-03-23 06:30:44 --> Helper loaded: url_helper
ERROR - 2017-03-23 11:00:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/profile', 'get', '{\"userId\":\"1\"}', '', '::1', 1490247044, 1)
ERROR - 2017-03-23 11:00:44 --> Call to undefined function debug()
ERROR - 2017-03-23 11:00:44 --> Severity: Error --> Call to undefined function debug() C:\xampp\htdocs\blooddonation\application\controllers\Webservices\Users.php 280
INFO - 2017-03-23 06:30:59 --> Config Class Initialized
INFO - 2017-03-23 06:30:59 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:30:59 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:30:59 --> Utf8 Class Initialized
INFO - 2017-03-23 06:30:59 --> URI Class Initialized
INFO - 2017-03-23 06:30:59 --> Router Class Initialized
INFO - 2017-03-23 06:30:59 --> Output Class Initialized
INFO - 2017-03-23 06:30:59 --> Security Class Initialized
DEBUG - 2017-03-23 06:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:30:59 --> Input Class Initialized
INFO - 2017-03-23 06:30:59 --> Language Class Initialized
INFO - 2017-03-23 06:30:59 --> Loader Class Initialized
INFO - 2017-03-23 06:30:59 --> Helper loaded: common_helper
INFO - 2017-03-23 06:30:59 --> Database Driver Class Initialized
INFO - 2017-03-23 06:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:30:59 --> Email Class Initialized
INFO - 2017-03-23 06:30:59 --> Controller Class Initialized
DEBUG - 2017-03-23 06:30:59 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:30:59 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:30:59 --> Database Driver Class Initialized
INFO - 2017-03-23 06:30:59 --> Model Class Initialized
INFO - 2017-03-23 06:30:59 --> Model Class Initialized
INFO - 2017-03-23 06:30:59 --> Helper loaded: url_helper
ERROR - 2017-03-23 11:00:59 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/profile', 'get', '{\"userId\":\"1\"}', '', '::1', 1490247059, 1)
ERROR - 2017-03-23 11:00:59 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.013864040374756
WHERE `id` =0
INFO - 2017-03-23 06:31:20 --> Config Class Initialized
INFO - 2017-03-23 06:31:20 --> Hooks Class Initialized
DEBUG - 2017-03-23 06:31:20 --> UTF-8 Support Enabled
INFO - 2017-03-23 06:31:20 --> Utf8 Class Initialized
INFO - 2017-03-23 06:31:20 --> URI Class Initialized
INFO - 2017-03-23 06:31:20 --> Router Class Initialized
INFO - 2017-03-23 06:31:20 --> Output Class Initialized
INFO - 2017-03-23 06:31:20 --> Security Class Initialized
DEBUG - 2017-03-23 06:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-03-23 06:31:20 --> Input Class Initialized
INFO - 2017-03-23 06:31:20 --> Language Class Initialized
INFO - 2017-03-23 06:31:20 --> Loader Class Initialized
INFO - 2017-03-23 06:31:20 --> Helper loaded: common_helper
INFO - 2017-03-23 06:31:20 --> Database Driver Class Initialized
INFO - 2017-03-23 06:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-03-23 06:31:20 --> Email Class Initialized
INFO - 2017-03-23 06:31:20 --> Controller Class Initialized
DEBUG - 2017-03-23 06:31:20 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-03-23 06:31:20 --> Helper loaded: inflector_helper
INFO - 2017-03-23 06:31:20 --> Database Driver Class Initialized
INFO - 2017-03-23 06:31:20 --> Model Class Initialized
INFO - 2017-03-23 06:31:20 --> Model Class Initialized
INFO - 2017-03-23 06:31:20 --> Helper loaded: url_helper
ERROR - 2017-03-23 11:01:20 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Users/profile', 'get', '{\"userId\":\"1\"}', '', '::1', 1490247080, 1)
ERROR - 2017-03-23 11:01:21 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.015336036682129
WHERE `id` =0
