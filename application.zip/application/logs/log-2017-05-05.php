<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-05-05 16:32:43 --> Config Class Initialized
INFO - 2017-05-05 16:32:43 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:32:43 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:32:43 --> Utf8 Class Initialized
INFO - 2017-05-05 16:32:43 --> URI Class Initialized
INFO - 2017-05-05 16:32:43 --> Router Class Initialized
INFO - 2017-05-05 16:32:43 --> Output Class Initialized
INFO - 2017-05-05 16:32:43 --> Security Class Initialized
DEBUG - 2017-05-05 16:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:32:43 --> Input Class Initialized
INFO - 2017-05-05 16:32:43 --> Language Class Initialized
INFO - 2017-05-05 16:32:43 --> Loader Class Initialized
INFO - 2017-05-05 16:32:43 --> Helper loaded: common_helper
INFO - 2017-05-05 16:32:43 --> Database Driver Class Initialized
INFO - 2017-05-05 16:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:32:44 --> Email Class Initialized
INFO - 2017-05-05 16:32:44 --> Controller Class Initialized
DEBUG - 2017-05-05 16:32:44 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:32:44 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:32:44 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:02:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493994764, 1)
INFO - 2017-05-05 20:02:44 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:02:44 --> Final output sent to browser
DEBUG - 2017-05-05 20:02:44 --> Total execution time: 0.5283
ERROR - 2017-05-05 20:02:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.061380863189697
WHERE `id` =0
INFO - 2017-05-05 16:32:52 --> Config Class Initialized
INFO - 2017-05-05 16:32:52 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:32:52 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:32:52 --> Utf8 Class Initialized
INFO - 2017-05-05 16:32:52 --> URI Class Initialized
INFO - 2017-05-05 16:32:52 --> Router Class Initialized
INFO - 2017-05-05 16:32:52 --> Output Class Initialized
INFO - 2017-05-05 16:32:52 --> Security Class Initialized
DEBUG - 2017-05-05 16:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:32:52 --> Input Class Initialized
INFO - 2017-05-05 16:32:52 --> Language Class Initialized
INFO - 2017-05-05 16:32:52 --> Loader Class Initialized
INFO - 2017-05-05 16:32:52 --> Helper loaded: common_helper
INFO - 2017-05-05 16:32:52 --> Database Driver Class Initialized
INFO - 2017-05-05 16:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:32:53 --> Email Class Initialized
INFO - 2017-05-05 16:32:53 --> Controller Class Initialized
DEBUG - 2017-05-05 16:32:53 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:32:53 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:32:53 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:02:53 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493994773, 1)
INFO - 2017-05-05 20:02:53 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:02:53 --> Final output sent to browser
DEBUG - 2017-05-05 20:02:53 --> Total execution time: 0.0463
ERROR - 2017-05-05 20:02:53 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0076022148132324
WHERE `id` =0
INFO - 2017-05-05 16:33:29 --> Config Class Initialized
INFO - 2017-05-05 16:33:29 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:33:29 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:33:29 --> Utf8 Class Initialized
INFO - 2017-05-05 16:33:29 --> URI Class Initialized
INFO - 2017-05-05 16:33:29 --> Router Class Initialized
INFO - 2017-05-05 16:33:29 --> Output Class Initialized
INFO - 2017-05-05 16:33:29 --> Security Class Initialized
DEBUG - 2017-05-05 16:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:33:29 --> Input Class Initialized
INFO - 2017-05-05 16:33:29 --> Language Class Initialized
INFO - 2017-05-05 16:33:29 --> Loader Class Initialized
INFO - 2017-05-05 16:33:29 --> Helper loaded: common_helper
INFO - 2017-05-05 16:33:29 --> Database Driver Class Initialized
INFO - 2017-05-05 16:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:33:29 --> Email Class Initialized
INFO - 2017-05-05 16:33:29 --> Controller Class Initialized
DEBUG - 2017-05-05 16:33:29 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:33:29 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:33:29 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:03:29 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493994809, 1)
INFO - 2017-05-05 20:03:29 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:03:29 --> Final output sent to browser
DEBUG - 2017-05-05 20:03:29 --> Total execution time: 0.0441
ERROR - 2017-05-05 20:03:29 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0079331398010254
WHERE `id` =0
INFO - 2017-05-05 16:33:49 --> Config Class Initialized
INFO - 2017-05-05 16:33:49 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:33:49 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:33:49 --> Utf8 Class Initialized
INFO - 2017-05-05 16:33:49 --> URI Class Initialized
INFO - 2017-05-05 16:33:49 --> Router Class Initialized
INFO - 2017-05-05 16:33:49 --> Output Class Initialized
INFO - 2017-05-05 16:33:49 --> Security Class Initialized
DEBUG - 2017-05-05 16:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:33:49 --> Input Class Initialized
INFO - 2017-05-05 16:33:49 --> Language Class Initialized
INFO - 2017-05-05 16:33:49 --> Loader Class Initialized
INFO - 2017-05-05 16:33:49 --> Helper loaded: common_helper
INFO - 2017-05-05 16:33:49 --> Database Driver Class Initialized
INFO - 2017-05-05 16:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:33:49 --> Email Class Initialized
INFO - 2017-05-05 16:33:49 --> Controller Class Initialized
DEBUG - 2017-05-05 16:33:49 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:33:49 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:33:49 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:03:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493994829, 1)
INFO - 2017-05-05 20:03:49 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:03:49 --> Final output sent to browser
DEBUG - 2017-05-05 20:03:49 --> Total execution time: 0.0425
ERROR - 2017-05-05 20:03:49 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0076179504394531
WHERE `id` =0
INFO - 2017-05-05 16:33:51 --> Config Class Initialized
INFO - 2017-05-05 16:33:51 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:33:51 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:33:51 --> Utf8 Class Initialized
INFO - 2017-05-05 16:33:51 --> URI Class Initialized
INFO - 2017-05-05 16:33:51 --> Router Class Initialized
INFO - 2017-05-05 16:33:51 --> Output Class Initialized
INFO - 2017-05-05 16:33:51 --> Security Class Initialized
DEBUG - 2017-05-05 16:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:33:51 --> Input Class Initialized
INFO - 2017-05-05 16:33:51 --> Language Class Initialized
INFO - 2017-05-05 16:33:51 --> Loader Class Initialized
INFO - 2017-05-05 16:33:51 --> Helper loaded: common_helper
INFO - 2017-05-05 16:33:51 --> Database Driver Class Initialized
INFO - 2017-05-05 16:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:33:51 --> Email Class Initialized
INFO - 2017-05-05 16:33:51 --> Controller Class Initialized
DEBUG - 2017-05-05 16:33:51 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:33:51 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:33:51 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:03:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493994831, 1)
INFO - 2017-05-05 20:03:51 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:03:51 --> Final output sent to browser
DEBUG - 2017-05-05 20:03:51 --> Total execution time: 0.0412
ERROR - 2017-05-05 20:03:51 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0075628757476807
WHERE `id` =0
INFO - 2017-05-05 16:34:44 --> Config Class Initialized
INFO - 2017-05-05 16:34:44 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:34:44 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:34:44 --> Utf8 Class Initialized
INFO - 2017-05-05 16:34:44 --> URI Class Initialized
INFO - 2017-05-05 16:34:44 --> Router Class Initialized
INFO - 2017-05-05 16:34:44 --> Output Class Initialized
INFO - 2017-05-05 16:34:44 --> Security Class Initialized
DEBUG - 2017-05-05 16:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:34:44 --> Input Class Initialized
INFO - 2017-05-05 16:34:44 --> Language Class Initialized
INFO - 2017-05-05 16:34:44 --> Loader Class Initialized
INFO - 2017-05-05 16:34:44 --> Helper loaded: common_helper
INFO - 2017-05-05 16:34:44 --> Database Driver Class Initialized
INFO - 2017-05-05 16:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:34:44 --> Email Class Initialized
INFO - 2017-05-05 16:34:44 --> Controller Class Initialized
DEBUG - 2017-05-05 16:34:44 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:34:44 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:34:44 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:04:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493994884, 1)
INFO - 2017-05-05 20:04:44 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:04:44 --> Final output sent to browser
DEBUG - 2017-05-05 20:04:44 --> Total execution time: 0.0399
ERROR - 2017-05-05 20:04:44 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0061991214752197
WHERE `id` =0
INFO - 2017-05-05 16:38:13 --> Config Class Initialized
INFO - 2017-05-05 16:38:13 --> Hooks Class Initialized
DEBUG - 2017-05-05 16:38:13 --> UTF-8 Support Enabled
INFO - 2017-05-05 16:38:13 --> Utf8 Class Initialized
INFO - 2017-05-05 16:38:13 --> URI Class Initialized
INFO - 2017-05-05 16:38:13 --> Router Class Initialized
INFO - 2017-05-05 16:38:13 --> Output Class Initialized
INFO - 2017-05-05 16:38:13 --> Security Class Initialized
DEBUG - 2017-05-05 16:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-05-05 16:38:13 --> Input Class Initialized
INFO - 2017-05-05 16:38:13 --> Language Class Initialized
INFO - 2017-05-05 16:38:13 --> Loader Class Initialized
INFO - 2017-05-05 16:38:13 --> Helper loaded: common_helper
INFO - 2017-05-05 16:38:13 --> Database Driver Class Initialized
INFO - 2017-05-05 16:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-05-05 16:38:13 --> Email Class Initialized
INFO - 2017-05-05 16:38:13 --> Controller Class Initialized
DEBUG - 2017-05-05 16:38:13 --> Config file loaded: C:\xampp\htdocs\blooddonation\application\config/rest.php
INFO - 2017-05-05 16:38:13 --> Helper loaded: inflector_helper
INFO - 2017-05-05 16:38:13 --> Database Driver Class Initialized
ERROR - 2017-05-05 20:08:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: INSERT INTO `logs` (`uri`, `method`, `params`, `api_key`, `ip_address`, `time`, `authorized`) VALUES ('Webservices/Privacy/privacy', 'get', NULL, '', '::1', 1493995093, 1)
INFO - 2017-05-05 20:08:13 --> File loaded: C:\xampp\htdocs\blooddonation\application\views\privacyPolicy.php
INFO - 2017-05-05 20:08:13 --> Final output sent to browser
DEBUG - 2017-05-05 20:08:13 --> Total execution time: 0.0404
ERROR - 2017-05-05 20:08:13 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.0078320503234863
WHERE `id` =0
