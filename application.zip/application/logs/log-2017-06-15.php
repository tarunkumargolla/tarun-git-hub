<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-06-15 12:02:31 --> Config Class Initialized
INFO - 2017-06-15 12:02:31 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:02:31 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:02:31 --> Utf8 Class Initialized
INFO - 2017-06-15 12:02:31 --> URI Class Initialized
DEBUG - 2017-06-15 12:02:31 --> No URI present. Default controller set.
INFO - 2017-06-15 12:02:31 --> Router Class Initialized
INFO - 2017-06-15 12:02:31 --> Output Class Initialized
INFO - 2017-06-15 12:02:31 --> Security Class Initialized
DEBUG - 2017-06-15 12:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:02:31 --> Input Class Initialized
INFO - 2017-06-15 12:02:31 --> Language Class Initialized
INFO - 2017-06-15 12:03:27 --> Config Class Initialized
INFO - 2017-06-15 12:03:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:03:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:03:27 --> Utf8 Class Initialized
INFO - 2017-06-15 12:03:27 --> URI Class Initialized
DEBUG - 2017-06-15 12:03:27 --> No URI present. Default controller set.
INFO - 2017-06-15 12:03:27 --> Router Class Initialized
INFO - 2017-06-15 12:03:27 --> Output Class Initialized
INFO - 2017-06-15 12:03:27 --> Security Class Initialized
DEBUG - 2017-06-15 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:03:27 --> Input Class Initialized
INFO - 2017-06-15 12:03:27 --> Language Class Initialized
INFO - 2017-06-15 12:19:05 --> Config Class Initialized
INFO - 2017-06-15 12:19:05 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:19:05 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:19:05 --> Utf8 Class Initialized
INFO - 2017-06-15 12:19:05 --> URI Class Initialized
DEBUG - 2017-06-15 12:19:05 --> No URI present. Default controller set.
INFO - 2017-06-15 12:19:05 --> Router Class Initialized
INFO - 2017-06-15 12:19:05 --> Output Class Initialized
INFO - 2017-06-15 12:19:05 --> Security Class Initialized
DEBUG - 2017-06-15 12:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:19:05 --> Input Class Initialized
INFO - 2017-06-15 12:19:05 --> Language Class Initialized
ERROR - 2017-06-15 12:19:05 --> Using $this when not in object context
ERROR - 2017-06-15 12:19:05 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\bloodApp\application\controllers\Welcome.php 2
INFO - 2017-06-15 12:19:58 --> Config Class Initialized
INFO - 2017-06-15 12:19:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:19:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:19:58 --> Utf8 Class Initialized
INFO - 2017-06-15 12:19:58 --> URI Class Initialized
DEBUG - 2017-06-15 12:19:58 --> No URI present. Default controller set.
INFO - 2017-06-15 12:19:58 --> Router Class Initialized
INFO - 2017-06-15 12:19:58 --> Output Class Initialized
INFO - 2017-06-15 12:19:58 --> Security Class Initialized
DEBUG - 2017-06-15 12:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:19:58 --> Input Class Initialized
INFO - 2017-06-15 12:19:58 --> Language Class Initialized
INFO - 2017-06-15 12:19:58 --> Loader Class Initialized
INFO - 2017-06-15 12:19:58 --> Helper loaded: common_helper
INFO - 2017-06-15 12:19:58 --> Database Driver Class Initialized
INFO - 2017-06-15 12:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:19:58 --> Email Class Initialized
INFO - 2017-06-15 12:19:58 --> Controller Class Initialized
INFO - 2017-06-15 12:19:58 --> Helper loaded: form_helper
INFO - 2017-06-15 12:19:58 --> Form Validation Class Initialized
INFO - 2017-06-15 12:19:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:19:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:19:58 --> Helper loaded: url_helper
INFO - 2017-06-15 12:19:58 --> Model Class Initialized
INFO - 2017-06-15 12:20:07 --> Config Class Initialized
INFO - 2017-06-15 12:20:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:07 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:07 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:07 --> No URI present. Default controller set.
INFO - 2017-06-15 12:20:07 --> Router Class Initialized
INFO - 2017-06-15 12:20:07 --> Output Class Initialized
INFO - 2017-06-15 12:20:07 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:07 --> Input Class Initialized
INFO - 2017-06-15 12:20:07 --> Language Class Initialized
INFO - 2017-06-15 12:20:07 --> Loader Class Initialized
INFO - 2017-06-15 12:20:07 --> Helper loaded: common_helper
INFO - 2017-06-15 12:20:07 --> Database Driver Class Initialized
INFO - 2017-06-15 12:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:20:07 --> Email Class Initialized
INFO - 2017-06-15 12:20:07 --> Controller Class Initialized
INFO - 2017-06-15 12:20:07 --> Helper loaded: form_helper
INFO - 2017-06-15 12:20:07 --> Form Validation Class Initialized
INFO - 2017-06-15 12:20:07 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:20:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:20:07 --> Helper loaded: url_helper
INFO - 2017-06-15 12:20:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:20:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:20:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:20:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:20:07 --> Final output sent to browser
DEBUG - 2017-06-15 12:20:07 --> Total execution time: 0.0435
INFO - 2017-06-15 12:20:07 --> Config Class Initialized
INFO - 2017-06-15 12:20:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:07 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:07 --> URI Class Initialized
INFO - 2017-06-15 12:20:07 --> Config Class Initialized
INFO - 2017-06-15 12:20:07 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:07 --> Router Class Initialized
INFO - 2017-06-15 12:20:07 --> Output Class Initialized
DEBUG - 2017-06-15 12:20:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:07 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:07 --> Security Class Initialized
INFO - 2017-06-15 12:20:07 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:07 --> Input Class Initialized
INFO - 2017-06-15 12:20:07 --> Router Class Initialized
INFO - 2017-06-15 12:20:07 --> Language Class Initialized
INFO - 2017-06-15 12:20:07 --> Output Class Initialized
ERROR - 2017-06-15 12:20:07 --> 404 Page Not Found: Css/main.css
INFO - 2017-06-15 12:20:07 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:07 --> Input Class Initialized
INFO - 2017-06-15 12:20:07 --> Language Class Initialized
ERROR - 2017-06-15 12:20:07 --> 404 Page Not Found: Images/default_profile_img.png
INFO - 2017-06-15 12:20:07 --> Config Class Initialized
INFO - 2017-06-15 12:20:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:07 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:07 --> URI Class Initialized
INFO - 2017-06-15 12:20:07 --> Router Class Initialized
INFO - 2017-06-15 12:20:07 --> Output Class Initialized
INFO - 2017-06-15 12:20:07 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:07 --> Input Class Initialized
INFO - 2017-06-15 12:20:07 --> Language Class Initialized
ERROR - 2017-06-15 12:20:07 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:52 --> No URI present. Default controller set.
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
INFO - 2017-06-15 12:20:52 --> Loader Class Initialized
INFO - 2017-06-15 12:20:52 --> Helper loaded: common_helper
INFO - 2017-06-15 12:20:52 --> Database Driver Class Initialized
INFO - 2017-06-15 12:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:20:52 --> Email Class Initialized
INFO - 2017-06-15 12:20:52 --> Controller Class Initialized
INFO - 2017-06-15 12:20:52 --> Helper loaded: form_helper
INFO - 2017-06-15 12:20:52 --> Form Validation Class Initialized
INFO - 2017-06-15 12:20:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:20:52 --> Helper loaded: url_helper
INFO - 2017-06-15 12:20:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:20:52 --> Final output sent to browser
DEBUG - 2017-06-15 12:20:52 --> Total execution time: 0.0423
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Images/default_profile_img.png
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Js/jquery-2.1.4.min.js
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Css/main.css
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Js/main.js
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Js/plugins
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:20:52 --> Config Class Initialized
INFO - 2017-06-15 12:20:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:52 --> URI Class Initialized
INFO - 2017-06-15 12:20:52 --> Router Class Initialized
INFO - 2017-06-15 12:20:52 --> Output Class Initialized
INFO - 2017-06-15 12:20:52 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:52 --> Input Class Initialized
INFO - 2017-06-15 12:20:52 --> Language Class Initialized
ERROR - 2017-06-15 12:20:52 --> 404 Page Not Found: Js/main.js
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:53 --> No URI present. Default controller set.
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
INFO - 2017-06-15 12:20:53 --> Loader Class Initialized
INFO - 2017-06-15 12:20:53 --> Helper loaded: common_helper
INFO - 2017-06-15 12:20:53 --> Database Driver Class Initialized
INFO - 2017-06-15 12:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:20:53 --> Email Class Initialized
INFO - 2017-06-15 12:20:53 --> Controller Class Initialized
INFO - 2017-06-15 12:20:53 --> Helper loaded: form_helper
INFO - 2017-06-15 12:20:53 --> Form Validation Class Initialized
INFO - 2017-06-15 12:20:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:20:53 --> Helper loaded: url_helper
INFO - 2017-06-15 12:20:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:20:53 --> Final output sent to browser
DEBUG - 2017-06-15 12:20:53 --> Total execution time: 0.0410
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Js/jquery-2.1.4.min.js
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Images/default_profile_img.png
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Css/main.css
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:53 --> Config Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
DEBUG - 2017-06-15 12:20:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
INFO - 2017-06-15 12:20:53 --> URI Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
INFO - 2017-06-15 12:20:53 --> Router Class Initialized
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Js/plugins
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
INFO - 2017-06-15 12:20:53 --> Output Class Initialized
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
INFO - 2017-06-15 12:20:53 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:53 --> Input Class Initialized
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Js/main.js
INFO - 2017-06-15 12:20:53 --> Language Class Initialized
ERROR - 2017-06-15 12:20:53 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:54 --> No URI present. Default controller set.
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
INFO - 2017-06-15 12:20:54 --> Loader Class Initialized
INFO - 2017-06-15 12:20:54 --> Helper loaded: common_helper
INFO - 2017-06-15 12:20:54 --> Database Driver Class Initialized
INFO - 2017-06-15 12:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:20:54 --> Email Class Initialized
INFO - 2017-06-15 12:20:54 --> Controller Class Initialized
INFO - 2017-06-15 12:20:54 --> Helper loaded: form_helper
INFO - 2017-06-15 12:20:54 --> Form Validation Class Initialized
INFO - 2017-06-15 12:20:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:20:54 --> Helper loaded: url_helper
INFO - 2017-06-15 12:20:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:20:54 --> Final output sent to browser
DEBUG - 2017-06-15 12:20:54 --> Total execution time: 0.0440
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Images/default_profile_img.png
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Js/jquery-2.1.4.min.js
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Css/main.css
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
INFO - 2017-06-15 12:20:54 --> Config Class Initialized
INFO - 2017-06-15 12:20:54 --> Hooks Class Initialized
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
INFO - 2017-06-15 12:20:54 --> URI Class Initialized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
INFO - 2017-06-15 12:20:54 --> Router Class Initialized
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Js/plugins
INFO - 2017-06-15 12:20:54 --> Output Class Initialized
INFO - 2017-06-15 12:20:54 --> Security Class Initialized
DEBUG - 2017-06-15 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:20:54 --> Input Class Initialized
INFO - 2017-06-15 12:20:54 --> Language Class Initialized
ERROR - 2017-06-15 12:20:54 --> 404 Page Not Found: Js/main.js
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
DEBUG - 2017-06-15 12:21:34 --> No URI present. Default controller set.
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
INFO - 2017-06-15 12:21:34 --> Loader Class Initialized
INFO - 2017-06-15 12:21:34 --> Helper loaded: common_helper
INFO - 2017-06-15 12:21:34 --> Database Driver Class Initialized
INFO - 2017-06-15 12:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:21:34 --> Email Class Initialized
INFO - 2017-06-15 12:21:34 --> Controller Class Initialized
INFO - 2017-06-15 12:21:34 --> Helper loaded: form_helper
INFO - 2017-06-15 12:21:34 --> Form Validation Class Initialized
INFO - 2017-06-15 12:21:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:21:34 --> Helper loaded: url_helper
INFO - 2017-06-15 12:21:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:21:34 --> Final output sent to browser
DEBUG - 2017-06-15 12:21:34 --> Total execution time: 0.0427
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
ERROR - 2017-06-15 12:21:34 --> 404 Page Not Found: Js/plugins
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
ERROR - 2017-06-15 12:21:34 --> 404 Page Not Found: Images/default_profile_img.png
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
ERROR - 2017-06-15 12:21:34 --> 404 Page Not Found: Js/jquery-2.1.4.min.js
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
ERROR - 2017-06-15 12:21:34 --> 404 Page Not Found: Js/main.js
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
INFO - 2017-06-15 12:21:34 --> Config Class Initialized
INFO - 2017-06-15 12:21:34 --> Hooks Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:34 --> Utf8 Class Initialized
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
INFO - 2017-06-15 12:21:34 --> URI Class Initialized
ERROR - 2017-06-15 12:21:34 --> 404 Page Not Found: Js/bootstrap.min.js
INFO - 2017-06-15 12:21:34 --> Router Class Initialized
INFO - 2017-06-15 12:21:34 --> Output Class Initialized
INFO - 2017-06-15 12:21:34 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:34 --> Input Class Initialized
INFO - 2017-06-15 12:21:34 --> Language Class Initialized
ERROR - 2017-06-15 12:21:34 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:21:35 --> Config Class Initialized
INFO - 2017-06-15 12:21:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:21:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:35 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:35 --> URI Class Initialized
INFO - 2017-06-15 12:21:35 --> Router Class Initialized
INFO - 2017-06-15 12:21:35 --> Output Class Initialized
INFO - 2017-06-15 12:21:35 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:35 --> Input Class Initialized
INFO - 2017-06-15 12:21:35 --> Language Class Initialized
ERROR - 2017-06-15 12:21:35 --> 404 Page Not Found: Js/plugins
INFO - 2017-06-15 12:21:35 --> Config Class Initialized
INFO - 2017-06-15 12:21:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:21:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:21:35 --> Utf8 Class Initialized
INFO - 2017-06-15 12:21:35 --> URI Class Initialized
INFO - 2017-06-15 12:21:35 --> Router Class Initialized
INFO - 2017-06-15 12:21:35 --> Output Class Initialized
INFO - 2017-06-15 12:21:35 --> Security Class Initialized
DEBUG - 2017-06-15 12:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:21:35 --> Input Class Initialized
INFO - 2017-06-15 12:21:35 --> Language Class Initialized
ERROR - 2017-06-15 12:21:35 --> 404 Page Not Found: Js/main.js
INFO - 2017-06-15 12:22:20 --> Config Class Initialized
INFO - 2017-06-15 12:22:20 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:22:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:22:20 --> Utf8 Class Initialized
INFO - 2017-06-15 12:22:20 --> URI Class Initialized
DEBUG - 2017-06-15 12:22:20 --> No URI present. Default controller set.
INFO - 2017-06-15 12:22:20 --> Router Class Initialized
INFO - 2017-06-15 12:22:20 --> Output Class Initialized
INFO - 2017-06-15 12:22:20 --> Security Class Initialized
DEBUG - 2017-06-15 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:22:20 --> Input Class Initialized
INFO - 2017-06-15 12:22:20 --> Language Class Initialized
INFO - 2017-06-15 12:22:20 --> Loader Class Initialized
INFO - 2017-06-15 12:22:20 --> Helper loaded: common_helper
INFO - 2017-06-15 12:22:20 --> Database Driver Class Initialized
INFO - 2017-06-15 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:22:20 --> Email Class Initialized
INFO - 2017-06-15 12:22:20 --> Controller Class Initialized
INFO - 2017-06-15 12:22:20 --> Helper loaded: form_helper
INFO - 2017-06-15 12:22:20 --> Form Validation Class Initialized
INFO - 2017-06-15 12:22:20 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:22:20 --> Helper loaded: url_helper
INFO - 2017-06-15 12:22:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:22:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:22:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:22:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:22:20 --> Final output sent to browser
DEBUG - 2017-06-15 12:22:20 --> Total execution time: 0.0462
INFO - 2017-06-15 12:22:20 --> Config Class Initialized
INFO - 2017-06-15 12:22:20 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:22:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:22:20 --> Utf8 Class Initialized
INFO - 2017-06-15 12:22:20 --> Config Class Initialized
INFO - 2017-06-15 12:22:20 --> Hooks Class Initialized
INFO - 2017-06-15 12:22:20 --> URI Class Initialized
INFO - 2017-06-15 12:22:20 --> Router Class Initialized
DEBUG - 2017-06-15 12:22:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:22:20 --> Utf8 Class Initialized
INFO - 2017-06-15 12:22:20 --> Output Class Initialized
INFO - 2017-06-15 12:22:20 --> URI Class Initialized
INFO - 2017-06-15 12:22:20 --> Security Class Initialized
INFO - 2017-06-15 12:22:20 --> Router Class Initialized
DEBUG - 2017-06-15 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:22:20 --> Input Class Initialized
INFO - 2017-06-15 12:22:20 --> Language Class Initialized
INFO - 2017-06-15 12:22:20 --> Output Class Initialized
INFO - 2017-06-15 12:22:20 --> Security Class Initialized
ERROR - 2017-06-15 12:22:20 --> 404 Page Not Found: Images/default_profile_img.png
DEBUG - 2017-06-15 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:22:20 --> Input Class Initialized
INFO - 2017-06-15 12:22:20 --> Language Class Initialized
ERROR - 2017-06-15 12:22:20 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:22:22 --> Config Class Initialized
INFO - 2017-06-15 12:22:22 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:22:22 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:22:22 --> Utf8 Class Initialized
INFO - 2017-06-15 12:22:22 --> URI Class Initialized
DEBUG - 2017-06-15 12:22:22 --> No URI present. Default controller set.
INFO - 2017-06-15 12:22:22 --> Router Class Initialized
INFO - 2017-06-15 12:22:22 --> Output Class Initialized
INFO - 2017-06-15 12:22:22 --> Security Class Initialized
DEBUG - 2017-06-15 12:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:22:22 --> Input Class Initialized
INFO - 2017-06-15 12:22:22 --> Language Class Initialized
INFO - 2017-06-15 12:22:22 --> Loader Class Initialized
INFO - 2017-06-15 12:22:22 --> Helper loaded: common_helper
INFO - 2017-06-15 12:22:22 --> Database Driver Class Initialized
INFO - 2017-06-15 12:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:22:22 --> Email Class Initialized
INFO - 2017-06-15 12:22:22 --> Controller Class Initialized
INFO - 2017-06-15 12:22:22 --> Helper loaded: form_helper
INFO - 2017-06-15 12:22:22 --> Form Validation Class Initialized
INFO - 2017-06-15 12:22:22 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:22:22 --> Helper loaded: url_helper
INFO - 2017-06-15 12:22:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:22:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:22:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:22:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:22:22 --> Final output sent to browser
DEBUG - 2017-06-15 12:22:22 --> Total execution time: 0.0392
INFO - 2017-06-15 12:22:22 --> Config Class Initialized
INFO - 2017-06-15 12:22:22 --> Hooks Class Initialized
INFO - 2017-06-15 12:22:22 --> Config Class Initialized
INFO - 2017-06-15 12:22:22 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:22:22 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:22:22 --> Utf8 Class Initialized
DEBUG - 2017-06-15 12:22:22 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:22:22 --> Utf8 Class Initialized
INFO - 2017-06-15 12:22:22 --> URI Class Initialized
INFO - 2017-06-15 12:22:22 --> URI Class Initialized
INFO - 2017-06-15 12:22:22 --> Router Class Initialized
INFO - 2017-06-15 12:22:22 --> Router Class Initialized
INFO - 2017-06-15 12:22:22 --> Output Class Initialized
INFO - 2017-06-15 12:22:22 --> Output Class Initialized
INFO - 2017-06-15 12:22:22 --> Security Class Initialized
INFO - 2017-06-15 12:22:22 --> Security Class Initialized
DEBUG - 2017-06-15 12:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 12:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:22:22 --> Input Class Initialized
INFO - 2017-06-15 12:22:22 --> Input Class Initialized
INFO - 2017-06-15 12:22:22 --> Language Class Initialized
INFO - 2017-06-15 12:22:22 --> Language Class Initialized
ERROR - 2017-06-15 12:22:22 --> 404 Page Not Found: Images/default_profile_img.png
ERROR - 2017-06-15 12:22:22 --> 404 Page Not Found: Images/toplist_icon1.png
INFO - 2017-06-15 12:23:14 --> Config Class Initialized
INFO - 2017-06-15 12:23:14 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:23:14 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:23:14 --> Utf8 Class Initialized
INFO - 2017-06-15 12:23:14 --> URI Class Initialized
DEBUG - 2017-06-15 12:23:14 --> No URI present. Default controller set.
INFO - 2017-06-15 12:23:14 --> Router Class Initialized
INFO - 2017-06-15 12:23:14 --> Output Class Initialized
INFO - 2017-06-15 12:23:14 --> Security Class Initialized
DEBUG - 2017-06-15 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:23:14 --> Input Class Initialized
INFO - 2017-06-15 12:23:14 --> Language Class Initialized
INFO - 2017-06-15 12:23:14 --> Loader Class Initialized
INFO - 2017-06-15 12:23:14 --> Helper loaded: common_helper
INFO - 2017-06-15 12:23:14 --> Database Driver Class Initialized
INFO - 2017-06-15 12:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:23:14 --> Email Class Initialized
INFO - 2017-06-15 12:23:14 --> Controller Class Initialized
INFO - 2017-06-15 12:23:14 --> Helper loaded: form_helper
INFO - 2017-06-15 12:23:14 --> Form Validation Class Initialized
INFO - 2017-06-15 12:23:14 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:23:14 --> Helper loaded: url_helper
INFO - 2017-06-15 12:23:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:23:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:23:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:23:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:23:14 --> Final output sent to browser
DEBUG - 2017-06-15 12:23:14 --> Total execution time: 0.0480
INFO - 2017-06-15 12:23:14 --> Config Class Initialized
INFO - 2017-06-15 12:23:14 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:23:14 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:23:14 --> Utf8 Class Initialized
INFO - 2017-06-15 12:23:14 --> URI Class Initialized
INFO - 2017-06-15 12:23:14 --> Router Class Initialized
INFO - 2017-06-15 12:23:14 --> Output Class Initialized
INFO - 2017-06-15 12:23:14 --> Security Class Initialized
DEBUG - 2017-06-15 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:23:14 --> Input Class Initialized
INFO - 2017-06-15 12:23:14 --> Language Class Initialized
ERROR - 2017-06-15 12:23:14 --> 404 Page Not Found: Images/default_profile_img.png
INFO - 2017-06-15 12:23:40 --> Config Class Initialized
INFO - 2017-06-15 12:23:40 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:23:40 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:23:40 --> Utf8 Class Initialized
INFO - 2017-06-15 12:23:40 --> URI Class Initialized
DEBUG - 2017-06-15 12:23:41 --> No URI present. Default controller set.
INFO - 2017-06-15 12:23:41 --> Router Class Initialized
INFO - 2017-06-15 12:23:41 --> Output Class Initialized
INFO - 2017-06-15 12:23:41 --> Security Class Initialized
DEBUG - 2017-06-15 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:23:41 --> Input Class Initialized
INFO - 2017-06-15 12:23:41 --> Language Class Initialized
INFO - 2017-06-15 12:23:41 --> Loader Class Initialized
INFO - 2017-06-15 12:23:41 --> Helper loaded: common_helper
INFO - 2017-06-15 12:23:41 --> Database Driver Class Initialized
INFO - 2017-06-15 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:23:41 --> Email Class Initialized
INFO - 2017-06-15 12:23:41 --> Controller Class Initialized
INFO - 2017-06-15 12:23:41 --> Helper loaded: form_helper
INFO - 2017-06-15 12:23:41 --> Form Validation Class Initialized
INFO - 2017-06-15 12:23:41 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:23:41 --> Helper loaded: url_helper
INFO - 2017-06-15 12:23:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:23:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:23:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:23:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:23:41 --> Final output sent to browser
DEBUG - 2017-06-15 12:23:41 --> Total execution time: 0.0467
INFO - 2017-06-15 12:24:19 --> Config Class Initialized
INFO - 2017-06-15 12:24:19 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:24:19 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:24:19 --> Utf8 Class Initialized
INFO - 2017-06-15 12:24:19 --> URI Class Initialized
DEBUG - 2017-06-15 12:24:19 --> No URI present. Default controller set.
INFO - 2017-06-15 12:24:19 --> Router Class Initialized
INFO - 2017-06-15 12:24:19 --> Output Class Initialized
INFO - 2017-06-15 12:24:19 --> Security Class Initialized
DEBUG - 2017-06-15 12:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:24:19 --> Input Class Initialized
INFO - 2017-06-15 12:24:19 --> Language Class Initialized
INFO - 2017-06-15 12:24:19 --> Loader Class Initialized
INFO - 2017-06-15 12:24:19 --> Helper loaded: common_helper
INFO - 2017-06-15 12:24:19 --> Database Driver Class Initialized
INFO - 2017-06-15 12:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:24:19 --> Email Class Initialized
INFO - 2017-06-15 12:24:19 --> Controller Class Initialized
INFO - 2017-06-15 12:24:19 --> Helper loaded: form_helper
INFO - 2017-06-15 12:24:19 --> Form Validation Class Initialized
INFO - 2017-06-15 12:24:19 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:24:19 --> Helper loaded: url_helper
INFO - 2017-06-15 12:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:24:19 --> Final output sent to browser
DEBUG - 2017-06-15 12:24:19 --> Total execution time: 0.0610
INFO - 2017-06-15 12:27:02 --> Config Class Initialized
INFO - 2017-06-15 12:27:02 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:27:02 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:27:02 --> Utf8 Class Initialized
INFO - 2017-06-15 12:27:02 --> URI Class Initialized
DEBUG - 2017-06-15 12:27:02 --> No URI present. Default controller set.
INFO - 2017-06-15 12:27:02 --> Router Class Initialized
INFO - 2017-06-15 12:27:02 --> Output Class Initialized
INFO - 2017-06-15 12:27:02 --> Security Class Initialized
DEBUG - 2017-06-15 12:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:27:02 --> Input Class Initialized
INFO - 2017-06-15 12:27:02 --> Language Class Initialized
INFO - 2017-06-15 12:27:02 --> Loader Class Initialized
INFO - 2017-06-15 12:27:02 --> Helper loaded: common_helper
INFO - 2017-06-15 12:27:02 --> Database Driver Class Initialized
INFO - 2017-06-15 12:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:27:02 --> Email Class Initialized
INFO - 2017-06-15 12:27:02 --> Controller Class Initialized
INFO - 2017-06-15 12:27:02 --> Helper loaded: form_helper
INFO - 2017-06-15 12:27:02 --> Form Validation Class Initialized
INFO - 2017-06-15 12:27:02 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:27:02 --> Helper loaded: url_helper
INFO - 2017-06-15 12:27:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:27:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:27:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:27:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:27:02 --> Final output sent to browser
DEBUG - 2017-06-15 12:27:02 --> Total execution time: 0.0634
INFO - 2017-06-15 12:27:59 --> Config Class Initialized
INFO - 2017-06-15 12:27:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:27:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:27:59 --> Utf8 Class Initialized
INFO - 2017-06-15 12:27:59 --> URI Class Initialized
DEBUG - 2017-06-15 12:27:59 --> No URI present. Default controller set.
INFO - 2017-06-15 12:27:59 --> Router Class Initialized
INFO - 2017-06-15 12:27:59 --> Output Class Initialized
INFO - 2017-06-15 12:27:59 --> Security Class Initialized
DEBUG - 2017-06-15 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:27:59 --> Input Class Initialized
INFO - 2017-06-15 12:27:59 --> Language Class Initialized
INFO - 2017-06-15 12:27:59 --> Loader Class Initialized
INFO - 2017-06-15 12:27:59 --> Helper loaded: common_helper
INFO - 2017-06-15 12:27:59 --> Database Driver Class Initialized
INFO - 2017-06-15 12:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:27:59 --> Email Class Initialized
INFO - 2017-06-15 12:27:59 --> Controller Class Initialized
INFO - 2017-06-15 12:27:59 --> Helper loaded: form_helper
INFO - 2017-06-15 12:27:59 --> Form Validation Class Initialized
INFO - 2017-06-15 12:27:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:27:59 --> Helper loaded: url_helper
INFO - 2017-06-15 12:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:27:59 --> Final output sent to browser
DEBUG - 2017-06-15 12:27:59 --> Total execution time: 0.0520
INFO - 2017-06-15 12:28:57 --> Config Class Initialized
INFO - 2017-06-15 12:28:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:28:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:28:57 --> Utf8 Class Initialized
INFO - 2017-06-15 12:28:57 --> URI Class Initialized
INFO - 2017-06-15 12:28:57 --> Router Class Initialized
INFO - 2017-06-15 12:28:57 --> Output Class Initialized
INFO - 2017-06-15 12:28:57 --> Security Class Initialized
DEBUG - 2017-06-15 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:28:57 --> Input Class Initialized
INFO - 2017-06-15 12:28:57 --> Language Class Initialized
ERROR - 2017-06-15 12:28:57 --> 404 Page Not Found: Indexhtml/index
INFO - 2017-06-15 12:28:58 --> Config Class Initialized
INFO - 2017-06-15 12:28:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:28:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:28:58 --> Utf8 Class Initialized
INFO - 2017-06-15 12:28:58 --> URI Class Initialized
DEBUG - 2017-06-15 12:28:58 --> No URI present. Default controller set.
INFO - 2017-06-15 12:28:58 --> Router Class Initialized
INFO - 2017-06-15 12:28:58 --> Output Class Initialized
INFO - 2017-06-15 12:28:58 --> Security Class Initialized
DEBUG - 2017-06-15 12:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:28:58 --> Input Class Initialized
INFO - 2017-06-15 12:28:58 --> Language Class Initialized
INFO - 2017-06-15 12:28:58 --> Loader Class Initialized
INFO - 2017-06-15 12:28:58 --> Helper loaded: common_helper
INFO - 2017-06-15 12:28:58 --> Database Driver Class Initialized
INFO - 2017-06-15 12:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:28:58 --> Email Class Initialized
INFO - 2017-06-15 12:28:58 --> Controller Class Initialized
INFO - 2017-06-15 12:28:58 --> Helper loaded: form_helper
INFO - 2017-06-15 12:28:58 --> Form Validation Class Initialized
INFO - 2017-06-15 12:28:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:28:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:28:58 --> Helper loaded: url_helper
INFO - 2017-06-15 12:28:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:28:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:28:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:28:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:28:58 --> Final output sent to browser
DEBUG - 2017-06-15 12:28:58 --> Total execution time: 0.0438
INFO - 2017-06-15 12:29:03 --> Config Class Initialized
INFO - 2017-06-15 12:29:03 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:29:03 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:29:03 --> Utf8 Class Initialized
INFO - 2017-06-15 12:29:03 --> URI Class Initialized
DEBUG - 2017-06-15 12:29:03 --> No URI present. Default controller set.
INFO - 2017-06-15 12:29:03 --> Router Class Initialized
INFO - 2017-06-15 12:29:03 --> Output Class Initialized
INFO - 2017-06-15 12:29:03 --> Security Class Initialized
DEBUG - 2017-06-15 12:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:29:03 --> Input Class Initialized
INFO - 2017-06-15 12:29:03 --> Language Class Initialized
INFO - 2017-06-15 12:29:03 --> Loader Class Initialized
INFO - 2017-06-15 12:29:03 --> Helper loaded: common_helper
INFO - 2017-06-15 12:29:03 --> Database Driver Class Initialized
INFO - 2017-06-15 12:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:29:03 --> Email Class Initialized
INFO - 2017-06-15 12:29:03 --> Controller Class Initialized
INFO - 2017-06-15 12:29:03 --> Helper loaded: form_helper
INFO - 2017-06-15 12:29:03 --> Form Validation Class Initialized
INFO - 2017-06-15 12:29:03 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:29:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:29:03 --> Helper loaded: url_helper
INFO - 2017-06-15 12:29:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:29:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:29:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:29:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:29:03 --> Final output sent to browser
DEBUG - 2017-06-15 12:29:03 --> Total execution time: 0.0441
INFO - 2017-06-15 12:31:30 --> Config Class Initialized
INFO - 2017-06-15 12:31:30 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:31:30 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:31:30 --> Utf8 Class Initialized
INFO - 2017-06-15 12:31:30 --> URI Class Initialized
DEBUG - 2017-06-15 12:31:30 --> No URI present. Default controller set.
INFO - 2017-06-15 12:31:30 --> Router Class Initialized
INFO - 2017-06-15 12:31:30 --> Output Class Initialized
INFO - 2017-06-15 12:31:30 --> Security Class Initialized
DEBUG - 2017-06-15 12:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:31:30 --> Input Class Initialized
INFO - 2017-06-15 12:31:30 --> Language Class Initialized
INFO - 2017-06-15 12:31:30 --> Loader Class Initialized
INFO - 2017-06-15 12:31:30 --> Helper loaded: common_helper
INFO - 2017-06-15 12:31:30 --> Database Driver Class Initialized
INFO - 2017-06-15 12:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:31:30 --> Email Class Initialized
INFO - 2017-06-15 12:31:30 --> Controller Class Initialized
INFO - 2017-06-15 12:31:30 --> Helper loaded: form_helper
INFO - 2017-06-15 12:31:30 --> Form Validation Class Initialized
INFO - 2017-06-15 12:31:30 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:31:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:31:30 --> Helper loaded: url_helper
ERROR - 2017-06-15 12:31:30 --> Use of undefined constant SUPERADMIN_ROLE_ID - assumed 'SUPERADMIN_ROLE_ID'
ERROR - 2017-06-15 12:31:30 --> Severity: Notice --> Use of undefined constant SUPERADMIN_ROLE_ID - assumed 'SUPERADMIN_ROLE_ID' C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 93
ERROR - 2017-06-15 12:31:30 --> Use of undefined constant TBL_TESTS - assumed 'TBL_TESTS'
ERROR - 2017-06-15 12:31:30 --> Severity: Notice --> Use of undefined constant TBL_TESTS - assumed 'TBL_TESTS' C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 105
ERROR - 2017-06-15 12:31:30 --> Query error: Table 'blooddonation.tbl_tests' doesn't exist - Invalid query: SELECT count(*) as tests_count
FROM `TBL_TESTS`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-06-15 12:31:30 --> Call to a member function result() on a non-object
ERROR - 2017-06-15 12:31:30 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\bloodApp\application\core\Healthcontroller.php 72
INFO - 2017-06-15 12:32:15 --> Config Class Initialized
INFO - 2017-06-15 12:32:15 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:32:15 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:32:15 --> Utf8 Class Initialized
INFO - 2017-06-15 12:32:15 --> URI Class Initialized
DEBUG - 2017-06-15 12:32:15 --> No URI present. Default controller set.
INFO - 2017-06-15 12:32:15 --> Router Class Initialized
INFO - 2017-06-15 12:32:15 --> Output Class Initialized
INFO - 2017-06-15 12:32:15 --> Security Class Initialized
DEBUG - 2017-06-15 12:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:32:15 --> Input Class Initialized
INFO - 2017-06-15 12:32:15 --> Language Class Initialized
INFO - 2017-06-15 12:32:15 --> Loader Class Initialized
INFO - 2017-06-15 12:32:15 --> Helper loaded: common_helper
INFO - 2017-06-15 12:32:15 --> Database Driver Class Initialized
INFO - 2017-06-15 12:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:32:15 --> Email Class Initialized
INFO - 2017-06-15 12:32:15 --> Controller Class Initialized
INFO - 2017-06-15 12:32:15 --> Helper loaded: form_helper
INFO - 2017-06-15 12:32:15 --> Form Validation Class Initialized
INFO - 2017-06-15 12:32:15 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:32:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:32:15 --> Helper loaded: url_helper
ERROR - 2017-06-15 12:32:15 --> Use of undefined constant TBL_TESTS - assumed 'TBL_TESTS'
ERROR - 2017-06-15 12:32:15 --> Severity: Notice --> Use of undefined constant TBL_TESTS - assumed 'TBL_TESTS' C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 105
ERROR - 2017-06-15 12:32:15 --> Query error: Table 'blooddonation.tbl_tests' doesn't exist - Invalid query: SELECT count(*) as tests_count
FROM `TBL_TESTS`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-06-15 12:32:15 --> Call to a member function result() on a non-object
ERROR - 2017-06-15 12:32:15 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\bloodApp\application\core\Healthcontroller.php 72
INFO - 2017-06-15 12:32:43 --> Config Class Initialized
INFO - 2017-06-15 12:32:43 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:32:43 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:32:43 --> Utf8 Class Initialized
INFO - 2017-06-15 12:32:43 --> URI Class Initialized
DEBUG - 2017-06-15 12:32:43 --> No URI present. Default controller set.
INFO - 2017-06-15 12:32:43 --> Router Class Initialized
INFO - 2017-06-15 12:32:43 --> Output Class Initialized
INFO - 2017-06-15 12:32:43 --> Security Class Initialized
DEBUG - 2017-06-15 12:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:32:43 --> Input Class Initialized
INFO - 2017-06-15 12:32:43 --> Language Class Initialized
INFO - 2017-06-15 12:32:43 --> Loader Class Initialized
INFO - 2017-06-15 12:32:43 --> Helper loaded: common_helper
INFO - 2017-06-15 12:32:43 --> Database Driver Class Initialized
INFO - 2017-06-15 12:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:32:43 --> Email Class Initialized
INFO - 2017-06-15 12:32:43 --> Controller Class Initialized
INFO - 2017-06-15 12:32:43 --> Helper loaded: form_helper
INFO - 2017-06-15 12:32:43 --> Form Validation Class Initialized
INFO - 2017-06-15 12:32:43 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:32:43 --> Helper loaded: url_helper
INFO - 2017-06-15 12:32:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:32:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:32:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:32:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:32:43 --> Final output sent to browser
DEBUG - 2017-06-15 12:32:43 --> Total execution time: 0.0467
INFO - 2017-06-15 12:38:56 --> Config Class Initialized
INFO - 2017-06-15 12:38:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:38:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:38:56 --> Utf8 Class Initialized
INFO - 2017-06-15 12:38:56 --> URI Class Initialized
DEBUG - 2017-06-15 12:38:56 --> No URI present. Default controller set.
INFO - 2017-06-15 12:38:56 --> Router Class Initialized
INFO - 2017-06-15 12:38:56 --> Output Class Initialized
INFO - 2017-06-15 12:38:56 --> Security Class Initialized
DEBUG - 2017-06-15 12:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:38:56 --> Input Class Initialized
INFO - 2017-06-15 12:38:56 --> Language Class Initialized
INFO - 2017-06-15 12:38:56 --> Loader Class Initialized
INFO - 2017-06-15 12:38:56 --> Helper loaded: common_helper
INFO - 2017-06-15 12:38:56 --> Database Driver Class Initialized
INFO - 2017-06-15 12:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:38:56 --> Email Class Initialized
INFO - 2017-06-15 12:38:56 --> Controller Class Initialized
INFO - 2017-06-15 12:38:56 --> Helper loaded: form_helper
INFO - 2017-06-15 12:38:56 --> Form Validation Class Initialized
INFO - 2017-06-15 12:38:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:38:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:38:56 --> Helper loaded: url_helper
INFO - 2017-06-15 12:38:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:38:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
ERROR - 2017-06-15 12:38:56 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 12:38:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\application\views\index.php 27
ERROR - 2017-06-15 12:38:56 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 12:38:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\application\views\index.php 39
ERROR - 2017-06-15 12:38:56 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 12:38:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\application\views\index.php 51
ERROR - 2017-06-15 12:38:56 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 12:38:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\application\views\index.php 63
INFO - 2017-06-15 12:38:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:38:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:38:56 --> Final output sent to browser
DEBUG - 2017-06-15 12:38:56 --> Total execution time: 0.0517
INFO - 2017-06-15 12:39:25 --> Config Class Initialized
INFO - 2017-06-15 12:39:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:39:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:39:25 --> Utf8 Class Initialized
INFO - 2017-06-15 12:39:25 --> URI Class Initialized
DEBUG - 2017-06-15 12:39:25 --> No URI present. Default controller set.
INFO - 2017-06-15 12:39:25 --> Router Class Initialized
INFO - 2017-06-15 12:39:25 --> Output Class Initialized
INFO - 2017-06-15 12:39:25 --> Security Class Initialized
DEBUG - 2017-06-15 12:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:39:25 --> Input Class Initialized
INFO - 2017-06-15 12:39:25 --> Language Class Initialized
INFO - 2017-06-15 12:39:25 --> Loader Class Initialized
INFO - 2017-06-15 12:39:25 --> Helper loaded: common_helper
INFO - 2017-06-15 12:39:25 --> Database Driver Class Initialized
INFO - 2017-06-15 12:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:39:25 --> Email Class Initialized
INFO - 2017-06-15 12:39:25 --> Controller Class Initialized
INFO - 2017-06-15 12:39:25 --> Helper loaded: form_helper
INFO - 2017-06-15 12:39:25 --> Form Validation Class Initialized
INFO - 2017-06-15 12:39:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:39:25 --> Helper loaded: url_helper
ERROR - 2017-06-15 12:39:25 --> Call to undefined function neatPrintAndDie()
ERROR - 2017-06-15 12:39:25 --> Severity: Error --> Call to undefined function neatPrintAndDie() C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 111
INFO - 2017-06-15 12:39:41 --> Config Class Initialized
INFO - 2017-06-15 12:39:41 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:39:41 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:39:41 --> Utf8 Class Initialized
INFO - 2017-06-15 12:39:41 --> URI Class Initialized
DEBUG - 2017-06-15 12:39:41 --> No URI present. Default controller set.
INFO - 2017-06-15 12:39:41 --> Router Class Initialized
INFO - 2017-06-15 12:39:41 --> Output Class Initialized
INFO - 2017-06-15 12:39:41 --> Security Class Initialized
DEBUG - 2017-06-15 12:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:39:41 --> Input Class Initialized
INFO - 2017-06-15 12:39:41 --> Language Class Initialized
INFO - 2017-06-15 12:39:41 --> Loader Class Initialized
INFO - 2017-06-15 12:39:41 --> Helper loaded: common_helper
INFO - 2017-06-15 12:39:41 --> Database Driver Class Initialized
INFO - 2017-06-15 12:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:39:41 --> Email Class Initialized
INFO - 2017-06-15 12:39:41 --> Controller Class Initialized
INFO - 2017-06-15 12:39:41 --> Helper loaded: form_helper
INFO - 2017-06-15 12:39:41 --> Form Validation Class Initialized
INFO - 2017-06-15 12:39:41 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:39:41 --> Helper loaded: url_helper
INFO - 2017-06-15 12:40:25 --> Config Class Initialized
INFO - 2017-06-15 12:40:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:40:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:40:25 --> Utf8 Class Initialized
INFO - 2017-06-15 12:40:25 --> URI Class Initialized
DEBUG - 2017-06-15 12:40:25 --> No URI present. Default controller set.
INFO - 2017-06-15 12:40:25 --> Router Class Initialized
INFO - 2017-06-15 12:40:25 --> Output Class Initialized
INFO - 2017-06-15 12:40:25 --> Security Class Initialized
DEBUG - 2017-06-15 12:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:40:25 --> Input Class Initialized
INFO - 2017-06-15 12:40:25 --> Language Class Initialized
INFO - 2017-06-15 12:40:25 --> Loader Class Initialized
INFO - 2017-06-15 12:40:25 --> Helper loaded: common_helper
INFO - 2017-06-15 12:40:25 --> Database Driver Class Initialized
INFO - 2017-06-15 12:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:40:25 --> Email Class Initialized
INFO - 2017-06-15 12:40:25 --> Controller Class Initialized
INFO - 2017-06-15 12:40:25 --> Helper loaded: form_helper
INFO - 2017-06-15 12:40:25 --> Form Validation Class Initialized
INFO - 2017-06-15 12:40:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:40:25 --> Helper loaded: url_helper
INFO - 2017-06-15 12:42:18 --> Config Class Initialized
INFO - 2017-06-15 12:42:18 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:42:18 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:42:18 --> Utf8 Class Initialized
INFO - 2017-06-15 12:42:18 --> URI Class Initialized
DEBUG - 2017-06-15 12:42:18 --> No URI present. Default controller set.
INFO - 2017-06-15 12:42:18 --> Router Class Initialized
INFO - 2017-06-15 12:42:18 --> Output Class Initialized
INFO - 2017-06-15 12:42:18 --> Security Class Initialized
DEBUG - 2017-06-15 12:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:42:18 --> Input Class Initialized
INFO - 2017-06-15 12:42:18 --> Language Class Initialized
INFO - 2017-06-15 12:42:18 --> Loader Class Initialized
INFO - 2017-06-15 12:42:18 --> Helper loaded: common_helper
INFO - 2017-06-15 12:42:18 --> Database Driver Class Initialized
INFO - 2017-06-15 12:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:42:18 --> Email Class Initialized
INFO - 2017-06-15 12:42:18 --> Controller Class Initialized
INFO - 2017-06-15 12:42:18 --> Helper loaded: form_helper
INFO - 2017-06-15 12:42:18 --> Form Validation Class Initialized
INFO - 2017-06-15 12:42:18 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:42:18 --> Helper loaded: url_helper
INFO - 2017-06-15 12:42:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:42:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:42:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:42:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:42:18 --> Final output sent to browser
DEBUG - 2017-06-15 12:42:18 --> Total execution time: 0.0484
INFO - 2017-06-15 12:42:31 --> Config Class Initialized
INFO - 2017-06-15 12:42:31 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:42:31 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:42:31 --> Utf8 Class Initialized
INFO - 2017-06-15 12:42:31 --> URI Class Initialized
DEBUG - 2017-06-15 12:42:31 --> No URI present. Default controller set.
INFO - 2017-06-15 12:42:31 --> Router Class Initialized
INFO - 2017-06-15 12:42:31 --> Output Class Initialized
INFO - 2017-06-15 12:42:31 --> Security Class Initialized
DEBUG - 2017-06-15 12:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:42:31 --> Input Class Initialized
INFO - 2017-06-15 12:42:31 --> Language Class Initialized
INFO - 2017-06-15 12:42:31 --> Loader Class Initialized
INFO - 2017-06-15 12:42:31 --> Helper loaded: common_helper
INFO - 2017-06-15 12:42:31 --> Database Driver Class Initialized
INFO - 2017-06-15 12:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:42:31 --> Email Class Initialized
INFO - 2017-06-15 12:42:31 --> Controller Class Initialized
INFO - 2017-06-15 12:42:31 --> Helper loaded: form_helper
INFO - 2017-06-15 12:42:31 --> Form Validation Class Initialized
INFO - 2017-06-15 12:42:31 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:42:31 --> Helper loaded: url_helper
INFO - 2017-06-15 12:42:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:42:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:42:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:42:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:42:31 --> Final output sent to browser
DEBUG - 2017-06-15 12:42:31 --> Total execution time: 0.0486
INFO - 2017-06-15 12:42:50 --> Config Class Initialized
INFO - 2017-06-15 12:42:50 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:42:50 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:42:50 --> Utf8 Class Initialized
INFO - 2017-06-15 12:42:50 --> URI Class Initialized
DEBUG - 2017-06-15 12:42:50 --> No URI present. Default controller set.
INFO - 2017-06-15 12:42:50 --> Router Class Initialized
INFO - 2017-06-15 12:42:50 --> Output Class Initialized
INFO - 2017-06-15 12:42:50 --> Security Class Initialized
DEBUG - 2017-06-15 12:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:42:50 --> Input Class Initialized
INFO - 2017-06-15 12:42:50 --> Language Class Initialized
INFO - 2017-06-15 12:42:50 --> Loader Class Initialized
INFO - 2017-06-15 12:42:50 --> Helper loaded: common_helper
INFO - 2017-06-15 12:42:50 --> Database Driver Class Initialized
INFO - 2017-06-15 12:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:42:50 --> Email Class Initialized
INFO - 2017-06-15 12:42:50 --> Controller Class Initialized
INFO - 2017-06-15 12:42:50 --> Helper loaded: form_helper
INFO - 2017-06-15 12:42:50 --> Form Validation Class Initialized
INFO - 2017-06-15 12:42:50 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:42:50 --> Helper loaded: url_helper
INFO - 2017-06-15 12:42:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:42:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:42:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:42:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:42:50 --> Final output sent to browser
DEBUG - 2017-06-15 12:42:50 --> Total execution time: 0.0445
INFO - 2017-06-15 12:42:53 --> Config Class Initialized
INFO - 2017-06-15 12:42:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:42:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:42:53 --> Utf8 Class Initialized
INFO - 2017-06-15 12:42:53 --> URI Class Initialized
INFO - 2017-06-15 12:42:53 --> Router Class Initialized
INFO - 2017-06-15 12:42:53 --> Output Class Initialized
INFO - 2017-06-15 12:42:53 --> Security Class Initialized
DEBUG - 2017-06-15 12:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:42:53 --> Input Class Initialized
INFO - 2017-06-15 12:42:53 --> Language Class Initialized
ERROR - 2017-06-15 12:42:53 --> 404 Page Not Found: Indexhtml/index
INFO - 2017-06-15 12:42:54 --> Config Class Initialized
INFO - 2017-06-15 12:42:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:42:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:42:55 --> Utf8 Class Initialized
INFO - 2017-06-15 12:42:55 --> URI Class Initialized
DEBUG - 2017-06-15 12:42:55 --> No URI present. Default controller set.
INFO - 2017-06-15 12:42:55 --> Router Class Initialized
INFO - 2017-06-15 12:42:55 --> Output Class Initialized
INFO - 2017-06-15 12:42:55 --> Security Class Initialized
DEBUG - 2017-06-15 12:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:42:55 --> Input Class Initialized
INFO - 2017-06-15 12:42:55 --> Language Class Initialized
INFO - 2017-06-15 12:42:55 --> Loader Class Initialized
INFO - 2017-06-15 12:42:55 --> Helper loaded: common_helper
INFO - 2017-06-15 12:42:55 --> Database Driver Class Initialized
INFO - 2017-06-15 12:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:42:55 --> Email Class Initialized
INFO - 2017-06-15 12:42:55 --> Controller Class Initialized
INFO - 2017-06-15 12:42:55 --> Helper loaded: form_helper
INFO - 2017-06-15 12:42:55 --> Form Validation Class Initialized
INFO - 2017-06-15 12:42:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:42:55 --> Helper loaded: url_helper
INFO - 2017-06-15 12:42:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:42:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:42:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:42:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:42:55 --> Final output sent to browser
DEBUG - 2017-06-15 12:42:55 --> Total execution time: 0.0494
INFO - 2017-06-15 12:43:47 --> Config Class Initialized
INFO - 2017-06-15 12:43:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:43:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:43:47 --> Utf8 Class Initialized
INFO - 2017-06-15 12:43:47 --> URI Class Initialized
DEBUG - 2017-06-15 12:43:47 --> No URI present. Default controller set.
INFO - 2017-06-15 12:43:47 --> Router Class Initialized
INFO - 2017-06-15 12:43:47 --> Output Class Initialized
INFO - 2017-06-15 12:43:47 --> Security Class Initialized
DEBUG - 2017-06-15 12:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:43:47 --> Input Class Initialized
INFO - 2017-06-15 12:43:47 --> Language Class Initialized
INFO - 2017-06-15 12:43:47 --> Loader Class Initialized
INFO - 2017-06-15 12:43:47 --> Helper loaded: common_helper
INFO - 2017-06-15 12:43:47 --> Database Driver Class Initialized
INFO - 2017-06-15 12:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:43:47 --> Email Class Initialized
INFO - 2017-06-15 12:43:47 --> Controller Class Initialized
INFO - 2017-06-15 12:43:47 --> Helper loaded: form_helper
INFO - 2017-06-15 12:43:47 --> Form Validation Class Initialized
INFO - 2017-06-15 12:43:47 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:43:47 --> Helper loaded: url_helper
INFO - 2017-06-15 12:43:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:43:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:43:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:43:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:43:47 --> Final output sent to browser
DEBUG - 2017-06-15 12:43:47 --> Total execution time: 0.0462
INFO - 2017-06-15 12:43:49 --> Config Class Initialized
INFO - 2017-06-15 12:43:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:43:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:43:49 --> Utf8 Class Initialized
INFO - 2017-06-15 12:43:49 --> URI Class Initialized
DEBUG - 2017-06-15 12:43:49 --> No URI present. Default controller set.
INFO - 2017-06-15 12:43:49 --> Router Class Initialized
INFO - 2017-06-15 12:43:49 --> Output Class Initialized
INFO - 2017-06-15 12:43:49 --> Security Class Initialized
DEBUG - 2017-06-15 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:43:49 --> Input Class Initialized
INFO - 2017-06-15 12:43:49 --> Language Class Initialized
INFO - 2017-06-15 12:43:49 --> Loader Class Initialized
INFO - 2017-06-15 12:43:49 --> Helper loaded: common_helper
INFO - 2017-06-15 12:43:49 --> Database Driver Class Initialized
INFO - 2017-06-15 12:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:43:49 --> Email Class Initialized
INFO - 2017-06-15 12:43:49 --> Controller Class Initialized
INFO - 2017-06-15 12:43:49 --> Helper loaded: form_helper
INFO - 2017-06-15 12:43:49 --> Form Validation Class Initialized
INFO - 2017-06-15 12:43:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:43:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:43:49 --> Helper loaded: url_helper
INFO - 2017-06-15 12:43:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:43:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:43:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:43:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:43:49 --> Final output sent to browser
DEBUG - 2017-06-15 12:43:49 --> Total execution time: 0.0424
INFO - 2017-06-15 12:50:47 --> Config Class Initialized
INFO - 2017-06-15 12:50:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:50:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:50:47 --> Utf8 Class Initialized
INFO - 2017-06-15 12:50:47 --> URI Class Initialized
DEBUG - 2017-06-15 12:50:47 --> No URI present. Default controller set.
INFO - 2017-06-15 12:50:47 --> Router Class Initialized
INFO - 2017-06-15 12:50:47 --> Output Class Initialized
INFO - 2017-06-15 12:50:47 --> Security Class Initialized
DEBUG - 2017-06-15 12:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:50:47 --> Input Class Initialized
INFO - 2017-06-15 12:50:47 --> Language Class Initialized
INFO - 2017-06-15 12:50:47 --> Loader Class Initialized
INFO - 2017-06-15 12:50:47 --> Helper loaded: common_helper
INFO - 2017-06-15 12:50:47 --> Database Driver Class Initialized
INFO - 2017-06-15 12:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:50:47 --> Email Class Initialized
INFO - 2017-06-15 12:50:47 --> Controller Class Initialized
INFO - 2017-06-15 12:50:47 --> Helper loaded: form_helper
INFO - 2017-06-15 12:50:47 --> Form Validation Class Initialized
INFO - 2017-06-15 12:50:47 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:50:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:50:47 --> Helper loaded: url_helper
INFO - 2017-06-15 12:50:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:50:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:50:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:50:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:50:47 --> Final output sent to browser
DEBUG - 2017-06-15 12:50:47 --> Total execution time: 0.0476
INFO - 2017-06-15 12:51:07 --> Config Class Initialized
INFO - 2017-06-15 12:51:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:51:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:51:07 --> Utf8 Class Initialized
INFO - 2017-06-15 12:51:07 --> URI Class Initialized
DEBUG - 2017-06-15 12:51:07 --> No URI present. Default controller set.
INFO - 2017-06-15 12:51:07 --> Router Class Initialized
INFO - 2017-06-15 12:51:07 --> Output Class Initialized
INFO - 2017-06-15 12:51:07 --> Security Class Initialized
DEBUG - 2017-06-15 12:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:51:07 --> Input Class Initialized
INFO - 2017-06-15 12:51:07 --> Language Class Initialized
INFO - 2017-06-15 12:51:07 --> Loader Class Initialized
INFO - 2017-06-15 12:51:07 --> Helper loaded: common_helper
INFO - 2017-06-15 12:51:07 --> Database Driver Class Initialized
INFO - 2017-06-15 12:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:51:07 --> Email Class Initialized
INFO - 2017-06-15 12:51:07 --> Controller Class Initialized
INFO - 2017-06-15 12:51:07 --> Helper loaded: form_helper
INFO - 2017-06-15 12:51:07 --> Form Validation Class Initialized
INFO - 2017-06-15 12:51:07 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:51:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:51:07 --> Helper loaded: url_helper
INFO - 2017-06-15 12:51:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:51:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:51:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:51:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:51:07 --> Final output sent to browser
DEBUG - 2017-06-15 12:51:07 --> Total execution time: 0.0514
INFO - 2017-06-15 12:51:54 --> Config Class Initialized
INFO - 2017-06-15 12:51:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:51:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:51:54 --> Utf8 Class Initialized
INFO - 2017-06-15 12:51:54 --> URI Class Initialized
DEBUG - 2017-06-15 12:51:54 --> No URI present. Default controller set.
INFO - 2017-06-15 12:51:54 --> Router Class Initialized
INFO - 2017-06-15 12:51:54 --> Output Class Initialized
INFO - 2017-06-15 12:51:54 --> Security Class Initialized
DEBUG - 2017-06-15 12:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:51:54 --> Input Class Initialized
INFO - 2017-06-15 12:51:54 --> Language Class Initialized
INFO - 2017-06-15 12:51:54 --> Loader Class Initialized
INFO - 2017-06-15 12:51:54 --> Helper loaded: common_helper
INFO - 2017-06-15 12:51:54 --> Database Driver Class Initialized
INFO - 2017-06-15 12:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:51:54 --> Email Class Initialized
INFO - 2017-06-15 12:51:54 --> Controller Class Initialized
INFO - 2017-06-15 12:51:54 --> Helper loaded: form_helper
INFO - 2017-06-15 12:51:54 --> Form Validation Class Initialized
INFO - 2017-06-15 12:51:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:51:54 --> Helper loaded: url_helper
INFO - 2017-06-15 12:51:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:51:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:51:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:51:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:51:54 --> Final output sent to browser
DEBUG - 2017-06-15 12:51:54 --> Total execution time: 0.0581
INFO - 2017-06-15 12:53:56 --> Config Class Initialized
INFO - 2017-06-15 12:53:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:53:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:53:56 --> Utf8 Class Initialized
INFO - 2017-06-15 12:53:56 --> URI Class Initialized
DEBUG - 2017-06-15 12:53:56 --> No URI present. Default controller set.
INFO - 2017-06-15 12:53:56 --> Router Class Initialized
INFO - 2017-06-15 12:53:56 --> Output Class Initialized
INFO - 2017-06-15 12:53:56 --> Security Class Initialized
DEBUG - 2017-06-15 12:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:53:56 --> Input Class Initialized
INFO - 2017-06-15 12:53:56 --> Language Class Initialized
INFO - 2017-06-15 12:53:56 --> Loader Class Initialized
INFO - 2017-06-15 12:53:56 --> Helper loaded: common_helper
INFO - 2017-06-15 12:53:56 --> Database Driver Class Initialized
INFO - 2017-06-15 12:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:53:56 --> Email Class Initialized
INFO - 2017-06-15 12:53:56 --> Controller Class Initialized
INFO - 2017-06-15 12:53:56 --> Helper loaded: form_helper
INFO - 2017-06-15 12:53:56 --> Form Validation Class Initialized
INFO - 2017-06-15 12:53:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:53:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:53:56 --> Helper loaded: url_helper
INFO - 2017-06-15 12:53:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:53:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:53:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:53:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:53:56 --> Final output sent to browser
DEBUG - 2017-06-15 12:53:56 --> Total execution time: 0.0481
INFO - 2017-06-15 12:53:58 --> Config Class Initialized
INFO - 2017-06-15 12:53:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:53:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:53:58 --> Utf8 Class Initialized
INFO - 2017-06-15 12:53:58 --> URI Class Initialized
DEBUG - 2017-06-15 12:53:58 --> No URI present. Default controller set.
INFO - 2017-06-15 12:53:58 --> Router Class Initialized
INFO - 2017-06-15 12:53:58 --> Output Class Initialized
INFO - 2017-06-15 12:53:58 --> Security Class Initialized
DEBUG - 2017-06-15 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:53:58 --> Input Class Initialized
INFO - 2017-06-15 12:53:58 --> Language Class Initialized
INFO - 2017-06-15 12:53:58 --> Loader Class Initialized
INFO - 2017-06-15 12:53:58 --> Helper loaded: common_helper
INFO - 2017-06-15 12:53:58 --> Database Driver Class Initialized
INFO - 2017-06-15 12:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:53:58 --> Email Class Initialized
INFO - 2017-06-15 12:53:58 --> Controller Class Initialized
INFO - 2017-06-15 12:53:58 --> Helper loaded: form_helper
INFO - 2017-06-15 12:53:58 --> Form Validation Class Initialized
INFO - 2017-06-15 12:53:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:53:58 --> Helper loaded: url_helper
INFO - 2017-06-15 12:53:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:53:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:53:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:53:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:53:58 --> Final output sent to browser
DEBUG - 2017-06-15 12:53:58 --> Total execution time: 0.0595
INFO - 2017-06-15 12:53:59 --> Config Class Initialized
INFO - 2017-06-15 12:53:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:53:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:53:59 --> Utf8 Class Initialized
INFO - 2017-06-15 12:53:59 --> URI Class Initialized
DEBUG - 2017-06-15 12:53:59 --> No URI present. Default controller set.
INFO - 2017-06-15 12:53:59 --> Router Class Initialized
INFO - 2017-06-15 12:53:59 --> Output Class Initialized
INFO - 2017-06-15 12:53:59 --> Security Class Initialized
DEBUG - 2017-06-15 12:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:53:59 --> Input Class Initialized
INFO - 2017-06-15 12:53:59 --> Language Class Initialized
INFO - 2017-06-15 12:53:59 --> Loader Class Initialized
INFO - 2017-06-15 12:53:59 --> Helper loaded: common_helper
INFO - 2017-06-15 12:53:59 --> Database Driver Class Initialized
INFO - 2017-06-15 12:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:53:59 --> Email Class Initialized
INFO - 2017-06-15 12:53:59 --> Controller Class Initialized
INFO - 2017-06-15 12:53:59 --> Helper loaded: form_helper
INFO - 2017-06-15 12:53:59 --> Form Validation Class Initialized
INFO - 2017-06-15 12:53:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:53:59 --> Helper loaded: url_helper
INFO - 2017-06-15 12:53:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:53:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:53:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:53:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:53:59 --> Final output sent to browser
DEBUG - 2017-06-15 12:53:59 --> Total execution time: 0.0478
INFO - 2017-06-15 12:54:02 --> Config Class Initialized
INFO - 2017-06-15 12:54:02 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:54:02 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:54:02 --> Utf8 Class Initialized
INFO - 2017-06-15 12:54:02 --> URI Class Initialized
DEBUG - 2017-06-15 12:54:02 --> No URI present. Default controller set.
INFO - 2017-06-15 12:54:02 --> Router Class Initialized
INFO - 2017-06-15 12:54:02 --> Output Class Initialized
INFO - 2017-06-15 12:54:02 --> Security Class Initialized
DEBUG - 2017-06-15 12:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:54:02 --> Input Class Initialized
INFO - 2017-06-15 12:54:02 --> Language Class Initialized
INFO - 2017-06-15 12:54:02 --> Loader Class Initialized
INFO - 2017-06-15 12:54:02 --> Helper loaded: common_helper
INFO - 2017-06-15 12:54:02 --> Database Driver Class Initialized
INFO - 2017-06-15 12:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:54:02 --> Email Class Initialized
INFO - 2017-06-15 12:54:02 --> Controller Class Initialized
INFO - 2017-06-15 12:54:02 --> Helper loaded: form_helper
INFO - 2017-06-15 12:54:02 --> Form Validation Class Initialized
INFO - 2017-06-15 12:54:02 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:54:02 --> Helper loaded: url_helper
INFO - 2017-06-15 12:54:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:54:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:54:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:54:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:54:02 --> Final output sent to browser
DEBUG - 2017-06-15 12:54:02 --> Total execution time: 0.0470
INFO - 2017-06-15 12:54:14 --> Config Class Initialized
INFO - 2017-06-15 12:54:14 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:54:14 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:54:14 --> Utf8 Class Initialized
INFO - 2017-06-15 12:54:14 --> URI Class Initialized
DEBUG - 2017-06-15 12:54:14 --> No URI present. Default controller set.
INFO - 2017-06-15 12:54:14 --> Router Class Initialized
INFO - 2017-06-15 12:54:14 --> Output Class Initialized
INFO - 2017-06-15 12:54:14 --> Security Class Initialized
DEBUG - 2017-06-15 12:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:54:14 --> Input Class Initialized
INFO - 2017-06-15 12:54:14 --> Language Class Initialized
INFO - 2017-06-15 12:54:14 --> Loader Class Initialized
INFO - 2017-06-15 12:54:14 --> Helper loaded: common_helper
INFO - 2017-06-15 12:54:14 --> Database Driver Class Initialized
INFO - 2017-06-15 12:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:54:14 --> Email Class Initialized
INFO - 2017-06-15 12:54:14 --> Controller Class Initialized
INFO - 2017-06-15 12:54:14 --> Helper loaded: form_helper
INFO - 2017-06-15 12:54:14 --> Form Validation Class Initialized
INFO - 2017-06-15 12:54:14 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:54:14 --> Helper loaded: url_helper
INFO - 2017-06-15 12:54:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:54:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:54:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:54:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:54:14 --> Final output sent to browser
DEBUG - 2017-06-15 12:54:14 --> Total execution time: 0.0481
INFO - 2017-06-15 12:54:19 --> Config Class Initialized
INFO - 2017-06-15 12:54:19 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:54:19 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:54:19 --> Utf8 Class Initialized
INFO - 2017-06-15 12:54:19 --> URI Class Initialized
DEBUG - 2017-06-15 12:54:19 --> No URI present. Default controller set.
INFO - 2017-06-15 12:54:19 --> Router Class Initialized
INFO - 2017-06-15 12:54:19 --> Output Class Initialized
INFO - 2017-06-15 12:54:19 --> Security Class Initialized
DEBUG - 2017-06-15 12:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:54:19 --> Input Class Initialized
INFO - 2017-06-15 12:54:19 --> Language Class Initialized
INFO - 2017-06-15 12:54:19 --> Loader Class Initialized
INFO - 2017-06-15 12:54:19 --> Helper loaded: common_helper
INFO - 2017-06-15 12:54:19 --> Database Driver Class Initialized
INFO - 2017-06-15 12:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:54:19 --> Email Class Initialized
INFO - 2017-06-15 12:54:19 --> Controller Class Initialized
INFO - 2017-06-15 12:54:19 --> Helper loaded: form_helper
INFO - 2017-06-15 12:54:19 --> Form Validation Class Initialized
INFO - 2017-06-15 12:54:19 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:54:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:54:19 --> Helper loaded: url_helper
INFO - 2017-06-15 12:54:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:54:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:54:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:54:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:54:19 --> Final output sent to browser
DEBUG - 2017-06-15 12:54:19 --> Total execution time: 0.0430
INFO - 2017-06-15 12:58:55 --> Config Class Initialized
INFO - 2017-06-15 12:58:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:58:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:58:55 --> Utf8 Class Initialized
INFO - 2017-06-15 12:58:55 --> URI Class Initialized
DEBUG - 2017-06-15 12:58:55 --> No URI present. Default controller set.
INFO - 2017-06-15 12:58:55 --> Router Class Initialized
INFO - 2017-06-15 12:58:55 --> Output Class Initialized
INFO - 2017-06-15 12:58:55 --> Security Class Initialized
DEBUG - 2017-06-15 12:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:58:55 --> Input Class Initialized
INFO - 2017-06-15 12:58:55 --> Language Class Initialized
INFO - 2017-06-15 12:58:55 --> Loader Class Initialized
INFO - 2017-06-15 12:58:55 --> Helper loaded: common_helper
INFO - 2017-06-15 12:58:55 --> Database Driver Class Initialized
INFO - 2017-06-15 12:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:58:55 --> Email Class Initialized
INFO - 2017-06-15 12:58:55 --> Controller Class Initialized
INFO - 2017-06-15 12:58:55 --> Helper loaded: form_helper
INFO - 2017-06-15 12:58:55 --> Form Validation Class Initialized
INFO - 2017-06-15 12:58:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:58:55 --> Helper loaded: url_helper
INFO - 2017-06-15 12:58:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:58:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:58:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:58:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:58:55 --> Final output sent to browser
DEBUG - 2017-06-15 12:58:55 --> Total execution time: 0.0496
INFO - 2017-06-15 12:59:13 --> Config Class Initialized
INFO - 2017-06-15 12:59:13 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:59:13 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:59:13 --> Utf8 Class Initialized
INFO - 2017-06-15 12:59:13 --> URI Class Initialized
DEBUG - 2017-06-15 12:59:13 --> No URI present. Default controller set.
INFO - 2017-06-15 12:59:13 --> Router Class Initialized
INFO - 2017-06-15 12:59:13 --> Output Class Initialized
INFO - 2017-06-15 12:59:13 --> Security Class Initialized
DEBUG - 2017-06-15 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:59:13 --> Input Class Initialized
INFO - 2017-06-15 12:59:13 --> Language Class Initialized
INFO - 2017-06-15 12:59:13 --> Loader Class Initialized
INFO - 2017-06-15 12:59:13 --> Helper loaded: common_helper
INFO - 2017-06-15 12:59:13 --> Database Driver Class Initialized
INFO - 2017-06-15 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:59:13 --> Email Class Initialized
INFO - 2017-06-15 12:59:13 --> Controller Class Initialized
INFO - 2017-06-15 12:59:13 --> Helper loaded: form_helper
INFO - 2017-06-15 12:59:13 --> Form Validation Class Initialized
INFO - 2017-06-15 12:59:13 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:59:13 --> Helper loaded: url_helper
INFO - 2017-06-15 12:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:59:13 --> Final output sent to browser
DEBUG - 2017-06-15 12:59:13 --> Total execution time: 0.0508
INFO - 2017-06-15 12:59:48 --> Config Class Initialized
INFO - 2017-06-15 12:59:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 12:59:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 12:59:48 --> Utf8 Class Initialized
INFO - 2017-06-15 12:59:48 --> URI Class Initialized
DEBUG - 2017-06-15 12:59:48 --> No URI present. Default controller set.
INFO - 2017-06-15 12:59:48 --> Router Class Initialized
INFO - 2017-06-15 12:59:48 --> Output Class Initialized
INFO - 2017-06-15 12:59:48 --> Security Class Initialized
DEBUG - 2017-06-15 12:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 12:59:48 --> Input Class Initialized
INFO - 2017-06-15 12:59:48 --> Language Class Initialized
INFO - 2017-06-15 12:59:48 --> Loader Class Initialized
INFO - 2017-06-15 12:59:48 --> Helper loaded: common_helper
INFO - 2017-06-15 12:59:48 --> Database Driver Class Initialized
INFO - 2017-06-15 12:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 12:59:48 --> Email Class Initialized
INFO - 2017-06-15 12:59:48 --> Controller Class Initialized
INFO - 2017-06-15 12:59:48 --> Helper loaded: form_helper
INFO - 2017-06-15 12:59:48 --> Form Validation Class Initialized
INFO - 2017-06-15 12:59:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 12:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 12:59:48 --> Helper loaded: url_helper
INFO - 2017-06-15 12:59:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 12:59:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 12:59:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 12:59:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 12:59:48 --> Final output sent to browser
DEBUG - 2017-06-15 12:59:48 --> Total execution time: 0.0484
INFO - 2017-06-15 13:00:00 --> Config Class Initialized
INFO - 2017-06-15 13:00:00 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:00:00 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:00:00 --> Utf8 Class Initialized
INFO - 2017-06-15 13:00:00 --> URI Class Initialized
DEBUG - 2017-06-15 13:00:00 --> No URI present. Default controller set.
INFO - 2017-06-15 13:00:00 --> Router Class Initialized
INFO - 2017-06-15 13:00:00 --> Output Class Initialized
INFO - 2017-06-15 13:00:00 --> Security Class Initialized
DEBUG - 2017-06-15 13:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:00:00 --> Input Class Initialized
INFO - 2017-06-15 13:00:00 --> Language Class Initialized
INFO - 2017-06-15 13:00:00 --> Loader Class Initialized
INFO - 2017-06-15 13:00:00 --> Helper loaded: common_helper
INFO - 2017-06-15 13:00:00 --> Database Driver Class Initialized
INFO - 2017-06-15 13:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:00:00 --> Email Class Initialized
INFO - 2017-06-15 13:00:00 --> Controller Class Initialized
INFO - 2017-06-15 13:00:00 --> Helper loaded: form_helper
INFO - 2017-06-15 13:00:00 --> Form Validation Class Initialized
INFO - 2017-06-15 13:00:00 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:00:00 --> Helper loaded: url_helper
INFO - 2017-06-15 13:00:00 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:00:00 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:00:00 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:00:00 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:00:00 --> Final output sent to browser
DEBUG - 2017-06-15 13:00:00 --> Total execution time: 0.0459
INFO - 2017-06-15 13:00:03 --> Config Class Initialized
INFO - 2017-06-15 13:00:03 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:00:03 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:00:03 --> Utf8 Class Initialized
INFO - 2017-06-15 13:00:03 --> URI Class Initialized
DEBUG - 2017-06-15 13:00:03 --> No URI present. Default controller set.
INFO - 2017-06-15 13:00:03 --> Router Class Initialized
INFO - 2017-06-15 13:00:03 --> Output Class Initialized
INFO - 2017-06-15 13:00:03 --> Security Class Initialized
DEBUG - 2017-06-15 13:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:00:03 --> Input Class Initialized
INFO - 2017-06-15 13:00:03 --> Language Class Initialized
INFO - 2017-06-15 13:00:03 --> Loader Class Initialized
INFO - 2017-06-15 13:00:03 --> Helper loaded: common_helper
INFO - 2017-06-15 13:00:03 --> Database Driver Class Initialized
INFO - 2017-06-15 13:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:00:03 --> Email Class Initialized
INFO - 2017-06-15 13:00:03 --> Controller Class Initialized
INFO - 2017-06-15 13:00:03 --> Helper loaded: form_helper
INFO - 2017-06-15 13:00:03 --> Form Validation Class Initialized
INFO - 2017-06-15 13:00:03 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:00:03 --> Helper loaded: url_helper
INFO - 2017-06-15 13:00:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:00:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:00:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:00:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:00:03 --> Final output sent to browser
DEBUG - 2017-06-15 13:00:03 --> Total execution time: 0.0520
INFO - 2017-06-15 13:00:07 --> Config Class Initialized
INFO - 2017-06-15 13:00:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:00:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:00:07 --> Utf8 Class Initialized
INFO - 2017-06-15 13:00:07 --> URI Class Initialized
DEBUG - 2017-06-15 13:00:07 --> No URI present. Default controller set.
INFO - 2017-06-15 13:00:07 --> Router Class Initialized
INFO - 2017-06-15 13:00:07 --> Output Class Initialized
INFO - 2017-06-15 13:00:07 --> Security Class Initialized
DEBUG - 2017-06-15 13:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:00:07 --> Input Class Initialized
INFO - 2017-06-15 13:00:07 --> Language Class Initialized
INFO - 2017-06-15 13:00:07 --> Loader Class Initialized
INFO - 2017-06-15 13:00:07 --> Helper loaded: common_helper
INFO - 2017-06-15 13:00:07 --> Database Driver Class Initialized
INFO - 2017-06-15 13:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:00:07 --> Email Class Initialized
INFO - 2017-06-15 13:00:07 --> Controller Class Initialized
INFO - 2017-06-15 13:00:07 --> Helper loaded: form_helper
INFO - 2017-06-15 13:00:07 --> Form Validation Class Initialized
INFO - 2017-06-15 13:00:07 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:00:07 --> Helper loaded: url_helper
INFO - 2017-06-15 13:00:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:00:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:00:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:00:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:00:07 --> Final output sent to browser
DEBUG - 2017-06-15 13:00:07 --> Total execution time: 0.0441
INFO - 2017-06-15 13:00:12 --> Config Class Initialized
INFO - 2017-06-15 13:00:12 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:00:12 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:00:12 --> Utf8 Class Initialized
INFO - 2017-06-15 13:00:12 --> URI Class Initialized
DEBUG - 2017-06-15 13:00:12 --> No URI present. Default controller set.
INFO - 2017-06-15 13:00:12 --> Router Class Initialized
INFO - 2017-06-15 13:00:12 --> Output Class Initialized
INFO - 2017-06-15 13:00:12 --> Security Class Initialized
DEBUG - 2017-06-15 13:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:00:12 --> Input Class Initialized
INFO - 2017-06-15 13:00:12 --> Language Class Initialized
INFO - 2017-06-15 13:00:12 --> Loader Class Initialized
INFO - 2017-06-15 13:00:12 --> Helper loaded: common_helper
INFO - 2017-06-15 13:00:12 --> Database Driver Class Initialized
INFO - 2017-06-15 13:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:00:12 --> Email Class Initialized
INFO - 2017-06-15 13:00:12 --> Controller Class Initialized
INFO - 2017-06-15 13:00:12 --> Helper loaded: form_helper
INFO - 2017-06-15 13:00:12 --> Form Validation Class Initialized
INFO - 2017-06-15 13:00:12 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:00:12 --> Helper loaded: url_helper
INFO - 2017-06-15 13:00:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:00:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:00:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:00:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:00:12 --> Final output sent to browser
DEBUG - 2017-06-15 13:00:12 --> Total execution time: 0.0445
INFO - 2017-06-15 13:01:46 --> Config Class Initialized
INFO - 2017-06-15 13:01:46 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:01:46 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:01:46 --> Utf8 Class Initialized
INFO - 2017-06-15 13:01:46 --> URI Class Initialized
DEBUG - 2017-06-15 13:01:46 --> No URI present. Default controller set.
INFO - 2017-06-15 13:01:46 --> Router Class Initialized
INFO - 2017-06-15 13:01:47 --> Output Class Initialized
INFO - 2017-06-15 13:01:47 --> Security Class Initialized
DEBUG - 2017-06-15 13:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:01:47 --> Input Class Initialized
INFO - 2017-06-15 13:01:47 --> Language Class Initialized
INFO - 2017-06-15 13:01:47 --> Loader Class Initialized
INFO - 2017-06-15 13:01:47 --> Helper loaded: common_helper
INFO - 2017-06-15 13:01:47 --> Database Driver Class Initialized
INFO - 2017-06-15 13:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:01:47 --> Email Class Initialized
INFO - 2017-06-15 13:01:47 --> Controller Class Initialized
INFO - 2017-06-15 13:01:47 --> Helper loaded: form_helper
INFO - 2017-06-15 13:01:47 --> Form Validation Class Initialized
INFO - 2017-06-15 13:01:47 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:01:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:01:47 --> Helper loaded: url_helper
INFO - 2017-06-15 13:01:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:01:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:01:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:01:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:01:47 --> Final output sent to browser
DEBUG - 2017-06-15 13:01:47 --> Total execution time: 0.0476
INFO - 2017-06-15 13:13:11 --> Config Class Initialized
INFO - 2017-06-15 13:13:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:13:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:13:11 --> Utf8 Class Initialized
INFO - 2017-06-15 13:13:11 --> URI Class Initialized
DEBUG - 2017-06-15 13:13:11 --> No URI present. Default controller set.
INFO - 2017-06-15 13:13:11 --> Router Class Initialized
INFO - 2017-06-15 13:13:11 --> Output Class Initialized
INFO - 2017-06-15 13:13:11 --> Security Class Initialized
DEBUG - 2017-06-15 13:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:13:11 --> Input Class Initialized
INFO - 2017-06-15 13:13:11 --> Language Class Initialized
INFO - 2017-06-15 13:13:11 --> Loader Class Initialized
INFO - 2017-06-15 13:13:11 --> Helper loaded: common_helper
INFO - 2017-06-15 13:13:11 --> Database Driver Class Initialized
INFO - 2017-06-15 13:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:13:11 --> Email Class Initialized
INFO - 2017-06-15 13:13:11 --> Controller Class Initialized
INFO - 2017-06-15 13:13:11 --> Helper loaded: form_helper
INFO - 2017-06-15 13:13:11 --> Form Validation Class Initialized
INFO - 2017-06-15 13:13:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:13:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:13:11 --> Helper loaded: url_helper
INFO - 2017-06-15 13:13:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:13:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:13:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:13:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:13:11 --> Final output sent to browser
DEBUG - 2017-06-15 13:13:11 --> Total execution time: 0.1751
INFO - 2017-06-15 13:28:52 --> Config Class Initialized
INFO - 2017-06-15 13:28:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:28:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:28:52 --> Utf8 Class Initialized
INFO - 2017-06-15 13:28:52 --> URI Class Initialized
DEBUG - 2017-06-15 13:28:52 --> No URI present. Default controller set.
INFO - 2017-06-15 13:28:52 --> Router Class Initialized
INFO - 2017-06-15 13:28:52 --> Output Class Initialized
INFO - 2017-06-15 13:28:52 --> Security Class Initialized
DEBUG - 2017-06-15 13:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:28:52 --> Input Class Initialized
INFO - 2017-06-15 13:28:52 --> Language Class Initialized
INFO - 2017-06-15 13:28:52 --> Loader Class Initialized
INFO - 2017-06-15 13:28:52 --> Helper loaded: common_helper
INFO - 2017-06-15 13:28:52 --> Database Driver Class Initialized
INFO - 2017-06-15 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:28:52 --> Email Class Initialized
INFO - 2017-06-15 13:28:52 --> Controller Class Initialized
INFO - 2017-06-15 13:28:52 --> Helper loaded: form_helper
INFO - 2017-06-15 13:28:52 --> Form Validation Class Initialized
INFO - 2017-06-15 13:28:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:28:52 --> Helper loaded: url_helper
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:28:52 --> Final output sent to browser
DEBUG - 2017-06-15 13:28:52 --> Total execution time: 0.0523
INFO - 2017-06-15 13:28:52 --> Config Class Initialized
INFO - 2017-06-15 13:28:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:28:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:28:52 --> Utf8 Class Initialized
INFO - 2017-06-15 13:28:52 --> URI Class Initialized
DEBUG - 2017-06-15 13:28:52 --> No URI present. Default controller set.
INFO - 2017-06-15 13:28:52 --> Router Class Initialized
INFO - 2017-06-15 13:28:52 --> Output Class Initialized
INFO - 2017-06-15 13:28:52 --> Security Class Initialized
DEBUG - 2017-06-15 13:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:28:52 --> Input Class Initialized
INFO - 2017-06-15 13:28:52 --> Language Class Initialized
INFO - 2017-06-15 13:28:52 --> Loader Class Initialized
INFO - 2017-06-15 13:28:52 --> Helper loaded: common_helper
INFO - 2017-06-15 13:28:52 --> Database Driver Class Initialized
INFO - 2017-06-15 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:28:52 --> Email Class Initialized
INFO - 2017-06-15 13:28:52 --> Controller Class Initialized
INFO - 2017-06-15 13:28:52 --> Helper loaded: form_helper
INFO - 2017-06-15 13:28:52 --> Form Validation Class Initialized
INFO - 2017-06-15 13:28:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:28:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:28:52 --> Helper loaded: url_helper
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:28:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:28:52 --> Final output sent to browser
DEBUG - 2017-06-15 13:28:52 --> Total execution time: 0.0503
INFO - 2017-06-15 13:28:57 --> Config Class Initialized
INFO - 2017-06-15 13:28:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:28:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:28:57 --> Utf8 Class Initialized
INFO - 2017-06-15 13:28:57 --> URI Class Initialized
DEBUG - 2017-06-15 13:28:57 --> No URI present. Default controller set.
INFO - 2017-06-15 13:28:57 --> Router Class Initialized
INFO - 2017-06-15 13:28:57 --> Output Class Initialized
INFO - 2017-06-15 13:28:57 --> Security Class Initialized
DEBUG - 2017-06-15 13:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:28:57 --> Input Class Initialized
INFO - 2017-06-15 13:28:57 --> Language Class Initialized
INFO - 2017-06-15 13:28:57 --> Loader Class Initialized
INFO - 2017-06-15 13:28:57 --> Helper loaded: common_helper
INFO - 2017-06-15 13:28:57 --> Database Driver Class Initialized
INFO - 2017-06-15 13:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:28:57 --> Email Class Initialized
INFO - 2017-06-15 13:28:57 --> Controller Class Initialized
INFO - 2017-06-15 13:28:57 --> Helper loaded: form_helper
INFO - 2017-06-15 13:28:57 --> Form Validation Class Initialized
INFO - 2017-06-15 13:28:57 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:28:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:28:57 --> Helper loaded: url_helper
INFO - 2017-06-15 13:28:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:28:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:28:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:28:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:28:57 --> Final output sent to browser
DEBUG - 2017-06-15 13:28:57 --> Total execution time: 0.0569
INFO - 2017-06-15 13:29:19 --> Config Class Initialized
INFO - 2017-06-15 13:29:19 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:29:19 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:29:19 --> Utf8 Class Initialized
INFO - 2017-06-15 13:29:19 --> URI Class Initialized
DEBUG - 2017-06-15 13:29:19 --> No URI present. Default controller set.
INFO - 2017-06-15 13:29:19 --> Router Class Initialized
INFO - 2017-06-15 13:29:19 --> Output Class Initialized
INFO - 2017-06-15 13:29:19 --> Security Class Initialized
DEBUG - 2017-06-15 13:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:29:19 --> Input Class Initialized
INFO - 2017-06-15 13:29:19 --> Language Class Initialized
INFO - 2017-06-15 13:29:19 --> Loader Class Initialized
INFO - 2017-06-15 13:29:19 --> Helper loaded: common_helper
INFO - 2017-06-15 13:29:19 --> Database Driver Class Initialized
INFO - 2017-06-15 13:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:29:19 --> Email Class Initialized
INFO - 2017-06-15 13:29:19 --> Controller Class Initialized
INFO - 2017-06-15 13:29:19 --> Helper loaded: form_helper
INFO - 2017-06-15 13:29:19 --> Form Validation Class Initialized
INFO - 2017-06-15 13:29:19 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:29:19 --> Helper loaded: url_helper
INFO - 2017-06-15 13:29:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
ERROR - 2017-06-15 13:29:19 --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL'
ERROR - 2017-06-15 13:29:19 --> Severity: Notice --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL' C:\xampp\htdocs\bloodApp\application\views\sideMenu.php 6
INFO - 2017-06-15 13:29:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:29:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:29:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:29:19 --> Final output sent to browser
DEBUG - 2017-06-15 13:29:19 --> Total execution time: 0.0486
INFO - 2017-06-15 13:29:20 --> Config Class Initialized
INFO - 2017-06-15 13:29:20 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:29:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:29:20 --> Utf8 Class Initialized
INFO - 2017-06-15 13:29:20 --> URI Class Initialized
DEBUG - 2017-06-15 13:29:20 --> No URI present. Default controller set.
INFO - 2017-06-15 13:29:20 --> Router Class Initialized
INFO - 2017-06-15 13:29:20 --> Output Class Initialized
INFO - 2017-06-15 13:29:20 --> Security Class Initialized
DEBUG - 2017-06-15 13:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:29:20 --> Input Class Initialized
INFO - 2017-06-15 13:29:20 --> Language Class Initialized
INFO - 2017-06-15 13:29:20 --> Loader Class Initialized
INFO - 2017-06-15 13:29:20 --> Helper loaded: common_helper
INFO - 2017-06-15 13:29:20 --> Database Driver Class Initialized
INFO - 2017-06-15 13:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:29:20 --> Email Class Initialized
INFO - 2017-06-15 13:29:20 --> Controller Class Initialized
INFO - 2017-06-15 13:29:20 --> Helper loaded: form_helper
INFO - 2017-06-15 13:29:20 --> Form Validation Class Initialized
INFO - 2017-06-15 13:29:20 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:29:20 --> Helper loaded: url_helper
INFO - 2017-06-15 13:29:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
ERROR - 2017-06-15 13:29:20 --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL'
ERROR - 2017-06-15 13:29:20 --> Severity: Notice --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL' C:\xampp\htdocs\bloodApp\application\views\sideMenu.php 6
INFO - 2017-06-15 13:29:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:29:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:29:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:29:20 --> Final output sent to browser
DEBUG - 2017-06-15 13:29:20 --> Total execution time: 0.0480
INFO - 2017-06-15 13:29:36 --> Config Class Initialized
INFO - 2017-06-15 13:29:36 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:29:36 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:29:36 --> Utf8 Class Initialized
INFO - 2017-06-15 13:29:36 --> URI Class Initialized
DEBUG - 2017-06-15 13:29:36 --> No URI present. Default controller set.
INFO - 2017-06-15 13:29:36 --> Router Class Initialized
INFO - 2017-06-15 13:29:36 --> Output Class Initialized
INFO - 2017-06-15 13:29:36 --> Security Class Initialized
DEBUG - 2017-06-15 13:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:29:36 --> Input Class Initialized
INFO - 2017-06-15 13:29:36 --> Language Class Initialized
INFO - 2017-06-15 13:29:36 --> Loader Class Initialized
INFO - 2017-06-15 13:29:36 --> Helper loaded: common_helper
INFO - 2017-06-15 13:29:36 --> Database Driver Class Initialized
INFO - 2017-06-15 13:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:29:36 --> Email Class Initialized
INFO - 2017-06-15 13:29:36 --> Controller Class Initialized
INFO - 2017-06-15 13:29:36 --> Helper loaded: form_helper
INFO - 2017-06-15 13:29:36 --> Form Validation Class Initialized
INFO - 2017-06-15 13:29:36 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:29:36 --> Helper loaded: url_helper
INFO - 2017-06-15 13:29:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
ERROR - 2017-06-15 13:29:36 --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL'
ERROR - 2017-06-15 13:29:36 --> Severity: Notice --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL' C:\xampp\htdocs\bloodApp\application\views\sideMenu.php 6
INFO - 2017-06-15 13:29:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:29:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:29:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:29:36 --> Final output sent to browser
DEBUG - 2017-06-15 13:29:36 --> Total execution time: 0.0501
INFO - 2017-06-15 13:29:37 --> Config Class Initialized
INFO - 2017-06-15 13:29:37 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:29:37 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:29:37 --> Utf8 Class Initialized
INFO - 2017-06-15 13:29:37 --> URI Class Initialized
DEBUG - 2017-06-15 13:29:37 --> No URI present. Default controller set.
INFO - 2017-06-15 13:29:37 --> Router Class Initialized
INFO - 2017-06-15 13:29:37 --> Output Class Initialized
INFO - 2017-06-15 13:29:37 --> Security Class Initialized
DEBUG - 2017-06-15 13:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:29:37 --> Input Class Initialized
INFO - 2017-06-15 13:29:37 --> Language Class Initialized
INFO - 2017-06-15 13:29:37 --> Loader Class Initialized
INFO - 2017-06-15 13:29:37 --> Helper loaded: common_helper
INFO - 2017-06-15 13:29:37 --> Database Driver Class Initialized
INFO - 2017-06-15 13:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:29:37 --> Email Class Initialized
INFO - 2017-06-15 13:29:37 --> Controller Class Initialized
INFO - 2017-06-15 13:29:37 --> Helper loaded: form_helper
INFO - 2017-06-15 13:29:37 --> Form Validation Class Initialized
INFO - 2017-06-15 13:29:37 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:29:37 --> Helper loaded: url_helper
INFO - 2017-06-15 13:29:37 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
ERROR - 2017-06-15 13:29:37 --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL'
ERROR - 2017-06-15 13:29:37 --> Severity: Notice --> Use of undefined constant USER_MANAGEMENT_URL - assumed 'USER_MANAGEMENT_URL' C:\xampp\htdocs\bloodApp\application\views\sideMenu.php 6
INFO - 2017-06-15 13:29:37 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:29:37 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:29:37 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:29:37 --> Final output sent to browser
DEBUG - 2017-06-15 13:29:37 --> Total execution time: 0.0491
INFO - 2017-06-15 13:29:47 --> Config Class Initialized
INFO - 2017-06-15 13:29:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:29:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:29:47 --> Utf8 Class Initialized
INFO - 2017-06-15 13:29:47 --> URI Class Initialized
DEBUG - 2017-06-15 13:29:47 --> No URI present. Default controller set.
INFO - 2017-06-15 13:29:47 --> Router Class Initialized
INFO - 2017-06-15 13:29:47 --> Output Class Initialized
INFO - 2017-06-15 13:29:47 --> Security Class Initialized
DEBUG - 2017-06-15 13:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:29:47 --> Input Class Initialized
INFO - 2017-06-15 13:29:47 --> Language Class Initialized
INFO - 2017-06-15 13:29:47 --> Loader Class Initialized
INFO - 2017-06-15 13:29:47 --> Helper loaded: common_helper
INFO - 2017-06-15 13:29:47 --> Database Driver Class Initialized
INFO - 2017-06-15 13:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:29:47 --> Email Class Initialized
INFO - 2017-06-15 13:29:47 --> Controller Class Initialized
INFO - 2017-06-15 13:29:47 --> Helper loaded: form_helper
INFO - 2017-06-15 13:29:47 --> Form Validation Class Initialized
INFO - 2017-06-15 13:29:47 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:29:47 --> Helper loaded: url_helper
INFO - 2017-06-15 13:30:07 --> Config Class Initialized
INFO - 2017-06-15 13:30:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:30:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:30:07 --> Utf8 Class Initialized
INFO - 2017-06-15 13:30:07 --> URI Class Initialized
DEBUG - 2017-06-15 13:30:07 --> No URI present. Default controller set.
INFO - 2017-06-15 13:30:07 --> Router Class Initialized
INFO - 2017-06-15 13:30:07 --> Output Class Initialized
INFO - 2017-06-15 13:30:07 --> Security Class Initialized
DEBUG - 2017-06-15 13:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:30:07 --> Input Class Initialized
INFO - 2017-06-15 13:30:07 --> Language Class Initialized
INFO - 2017-06-15 13:30:07 --> Loader Class Initialized
INFO - 2017-06-15 13:30:07 --> Helper loaded: common_helper
INFO - 2017-06-15 13:30:07 --> Database Driver Class Initialized
INFO - 2017-06-15 13:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:30:07 --> Email Class Initialized
INFO - 2017-06-15 13:30:07 --> Controller Class Initialized
INFO - 2017-06-15 13:30:07 --> Helper loaded: form_helper
INFO - 2017-06-15 13:30:07 --> Form Validation Class Initialized
INFO - 2017-06-15 13:30:07 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:30:07 --> Helper loaded: url_helper
INFO - 2017-06-15 13:30:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:30:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:30:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:30:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:30:07 --> Final output sent to browser
DEBUG - 2017-06-15 13:30:07 --> Total execution time: 0.0461
INFO - 2017-06-15 13:30:10 --> Config Class Initialized
INFO - 2017-06-15 13:30:10 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:30:10 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:30:10 --> Utf8 Class Initialized
INFO - 2017-06-15 13:30:10 --> URI Class Initialized
INFO - 2017-06-15 13:30:10 --> Router Class Initialized
INFO - 2017-06-15 13:30:10 --> Output Class Initialized
INFO - 2017-06-15 13:30:10 --> Security Class Initialized
DEBUG - 2017-06-15 13:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:30:10 --> Input Class Initialized
INFO - 2017-06-15 13:30:10 --> Language Class Initialized
ERROR - 2017-06-15 13:30:10 --> syntax error, unexpected '{', expecting function (T_FUNCTION)
ERROR - 2017-06-15 13:30:10 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting function (T_FUNCTION) C:\xampp\htdocs\bloodApp\application\controllers\Users.php 10
INFO - 2017-06-15 13:30:24 --> Config Class Initialized
INFO - 2017-06-15 13:30:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:30:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:30:24 --> Utf8 Class Initialized
INFO - 2017-06-15 13:30:24 --> URI Class Initialized
INFO - 2017-06-15 13:30:24 --> Router Class Initialized
INFO - 2017-06-15 13:30:24 --> Output Class Initialized
INFO - 2017-06-15 13:30:24 --> Security Class Initialized
DEBUG - 2017-06-15 13:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:30:24 --> Input Class Initialized
INFO - 2017-06-15 13:30:24 --> Language Class Initialized
INFO - 2017-06-15 13:30:24 --> Loader Class Initialized
INFO - 2017-06-15 13:30:24 --> Helper loaded: common_helper
INFO - 2017-06-15 13:30:24 --> Database Driver Class Initialized
INFO - 2017-06-15 13:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:30:24 --> Email Class Initialized
INFO - 2017-06-15 13:30:24 --> Controller Class Initialized
INFO - 2017-06-15 13:30:24 --> Helper loaded: form_helper
INFO - 2017-06-15 13:30:24 --> Form Validation Class Initialized
INFO - 2017-06-15 13:30:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:30:24 --> Helper loaded: url_helper
INFO - 2017-06-15 13:30:24 --> Model Class Initialized
INFO - 2017-06-15 13:30:24 --> Model Class Initialized
INFO - 2017-06-15 17:00:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:00:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:00:24 --> Final output sent to browser
DEBUG - 2017-06-15 17:00:24 --> Total execution time: 0.0705
INFO - 2017-06-15 13:30:36 --> Config Class Initialized
INFO - 2017-06-15 13:30:36 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:30:36 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:30:36 --> Utf8 Class Initialized
INFO - 2017-06-15 13:30:36 --> URI Class Initialized
INFO - 2017-06-15 13:30:36 --> Router Class Initialized
INFO - 2017-06-15 13:30:36 --> Output Class Initialized
INFO - 2017-06-15 13:30:36 --> Security Class Initialized
DEBUG - 2017-06-15 13:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:30:36 --> Input Class Initialized
INFO - 2017-06-15 13:30:36 --> Language Class Initialized
INFO - 2017-06-15 13:30:36 --> Loader Class Initialized
INFO - 2017-06-15 13:30:36 --> Helper loaded: common_helper
INFO - 2017-06-15 13:30:36 --> Database Driver Class Initialized
INFO - 2017-06-15 13:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:30:36 --> Email Class Initialized
INFO - 2017-06-15 13:30:36 --> Controller Class Initialized
INFO - 2017-06-15 13:30:36 --> Helper loaded: form_helper
INFO - 2017-06-15 13:30:36 --> Form Validation Class Initialized
INFO - 2017-06-15 13:30:36 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:30:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:30:36 --> Helper loaded: url_helper
INFO - 2017-06-15 13:30:36 --> Model Class Initialized
INFO - 2017-06-15 13:30:36 --> Model Class Initialized
INFO - 2017-06-15 17:00:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:00:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:00:36 --> Final output sent to browser
DEBUG - 2017-06-15 17:00:36 --> Total execution time: 0.0502
INFO - 2017-06-15 13:34:51 --> Config Class Initialized
INFO - 2017-06-15 13:34:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:34:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:34:51 --> Utf8 Class Initialized
INFO - 2017-06-15 13:34:51 --> URI Class Initialized
INFO - 2017-06-15 13:34:51 --> Router Class Initialized
INFO - 2017-06-15 13:34:51 --> Output Class Initialized
INFO - 2017-06-15 13:34:51 --> Security Class Initialized
DEBUG - 2017-06-15 13:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:34:51 --> Input Class Initialized
INFO - 2017-06-15 13:34:51 --> Language Class Initialized
INFO - 2017-06-15 13:34:51 --> Loader Class Initialized
INFO - 2017-06-15 13:34:51 --> Helper loaded: common_helper
INFO - 2017-06-15 13:34:51 --> Database Driver Class Initialized
INFO - 2017-06-15 13:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:34:51 --> Email Class Initialized
INFO - 2017-06-15 13:34:51 --> Controller Class Initialized
INFO - 2017-06-15 13:34:51 --> Helper loaded: form_helper
INFO - 2017-06-15 13:34:51 --> Form Validation Class Initialized
INFO - 2017-06-15 13:34:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:34:51 --> Helper loaded: url_helper
INFO - 2017-06-15 13:34:51 --> Model Class Initialized
INFO - 2017-06-15 13:34:51 --> Model Class Initialized
INFO - 2017-06-15 17:04:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:04:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:04:51 --> Final output sent to browser
DEBUG - 2017-06-15 17:04:51 --> Total execution time: 0.0536
INFO - 2017-06-15 13:35:09 --> Config Class Initialized
INFO - 2017-06-15 13:35:09 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:35:09 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:35:09 --> Utf8 Class Initialized
INFO - 2017-06-15 13:35:09 --> URI Class Initialized
INFO - 2017-06-15 13:35:09 --> Router Class Initialized
INFO - 2017-06-15 13:35:09 --> Output Class Initialized
INFO - 2017-06-15 13:35:09 --> Security Class Initialized
DEBUG - 2017-06-15 13:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:35:09 --> Input Class Initialized
INFO - 2017-06-15 13:35:09 --> Language Class Initialized
INFO - 2017-06-15 13:35:09 --> Loader Class Initialized
INFO - 2017-06-15 13:35:09 --> Helper loaded: common_helper
INFO - 2017-06-15 13:35:09 --> Database Driver Class Initialized
INFO - 2017-06-15 13:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:35:09 --> Email Class Initialized
INFO - 2017-06-15 13:35:09 --> Controller Class Initialized
INFO - 2017-06-15 13:35:09 --> Helper loaded: form_helper
INFO - 2017-06-15 13:35:09 --> Form Validation Class Initialized
INFO - 2017-06-15 13:35:09 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:35:09 --> Helper loaded: url_helper
INFO - 2017-06-15 13:35:09 --> Model Class Initialized
INFO - 2017-06-15 13:35:09 --> Model Class Initialized
INFO - 2017-06-15 17:05:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:05:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:05:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:05:09 --> Final output sent to browser
DEBUG - 2017-06-15 17:05:09 --> Total execution time: 0.0505
INFO - 2017-06-15 13:35:24 --> Config Class Initialized
INFO - 2017-06-15 13:35:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:35:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:35:24 --> Utf8 Class Initialized
INFO - 2017-06-15 13:35:24 --> URI Class Initialized
INFO - 2017-06-15 13:35:24 --> Router Class Initialized
INFO - 2017-06-15 13:35:24 --> Output Class Initialized
INFO - 2017-06-15 13:35:24 --> Security Class Initialized
DEBUG - 2017-06-15 13:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:35:24 --> Input Class Initialized
INFO - 2017-06-15 13:35:24 --> Language Class Initialized
INFO - 2017-06-15 13:35:24 --> Loader Class Initialized
INFO - 2017-06-15 13:35:24 --> Helper loaded: common_helper
INFO - 2017-06-15 13:35:24 --> Database Driver Class Initialized
INFO - 2017-06-15 13:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:35:24 --> Email Class Initialized
INFO - 2017-06-15 13:35:24 --> Controller Class Initialized
INFO - 2017-06-15 13:35:24 --> Helper loaded: form_helper
INFO - 2017-06-15 13:35:24 --> Form Validation Class Initialized
INFO - 2017-06-15 13:35:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:35:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:35:24 --> Helper loaded: url_helper
INFO - 2017-06-15 13:35:24 --> Model Class Initialized
INFO - 2017-06-15 13:35:24 --> Model Class Initialized
INFO - 2017-06-15 17:05:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:05:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:05:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:05:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:05:24 --> Final output sent to browser
DEBUG - 2017-06-15 17:05:24 --> Total execution time: 0.0554
INFO - 2017-06-15 13:35:26 --> Config Class Initialized
INFO - 2017-06-15 13:35:26 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:35:26 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:35:26 --> Utf8 Class Initialized
INFO - 2017-06-15 13:35:26 --> URI Class Initialized
INFO - 2017-06-15 13:35:26 --> Router Class Initialized
INFO - 2017-06-15 13:35:26 --> Output Class Initialized
INFO - 2017-06-15 13:35:26 --> Security Class Initialized
DEBUG - 2017-06-15 13:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:35:26 --> Input Class Initialized
INFO - 2017-06-15 13:35:26 --> Language Class Initialized
INFO - 2017-06-15 13:35:26 --> Loader Class Initialized
INFO - 2017-06-15 13:35:26 --> Helper loaded: common_helper
INFO - 2017-06-15 13:35:26 --> Database Driver Class Initialized
INFO - 2017-06-15 13:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:35:26 --> Email Class Initialized
INFO - 2017-06-15 13:35:26 --> Controller Class Initialized
INFO - 2017-06-15 13:35:26 --> Helper loaded: form_helper
INFO - 2017-06-15 13:35:26 --> Form Validation Class Initialized
INFO - 2017-06-15 13:35:26 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:35:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:35:26 --> Helper loaded: url_helper
INFO - 2017-06-15 13:35:26 --> Model Class Initialized
INFO - 2017-06-15 13:35:26 --> Model Class Initialized
INFO - 2017-06-15 17:05:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:05:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:05:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:05:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:05:26 --> Final output sent to browser
DEBUG - 2017-06-15 17:05:26 --> Total execution time: 0.0478
INFO - 2017-06-15 13:35:33 --> Config Class Initialized
INFO - 2017-06-15 13:35:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:35:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:35:33 --> Utf8 Class Initialized
INFO - 2017-06-15 13:35:33 --> URI Class Initialized
DEBUG - 2017-06-15 13:35:33 --> No URI present. Default controller set.
INFO - 2017-06-15 13:35:33 --> Router Class Initialized
INFO - 2017-06-15 13:35:33 --> Output Class Initialized
INFO - 2017-06-15 13:35:33 --> Security Class Initialized
DEBUG - 2017-06-15 13:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:35:33 --> Input Class Initialized
INFO - 2017-06-15 13:35:33 --> Language Class Initialized
INFO - 2017-06-15 13:35:33 --> Loader Class Initialized
INFO - 2017-06-15 13:35:33 --> Helper loaded: common_helper
INFO - 2017-06-15 13:35:33 --> Database Driver Class Initialized
INFO - 2017-06-15 13:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:35:33 --> Email Class Initialized
INFO - 2017-06-15 13:35:33 --> Controller Class Initialized
INFO - 2017-06-15 13:35:33 --> Helper loaded: form_helper
INFO - 2017-06-15 13:35:33 --> Form Validation Class Initialized
INFO - 2017-06-15 13:35:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:35:33 --> Helper loaded: url_helper
INFO - 2017-06-15 13:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 13:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 13:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 13:35:33 --> Final output sent to browser
DEBUG - 2017-06-15 13:35:33 --> Total execution time: 0.0451
INFO - 2017-06-15 13:35:44 --> Config Class Initialized
INFO - 2017-06-15 13:35:44 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:35:44 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:35:44 --> Utf8 Class Initialized
INFO - 2017-06-15 13:35:44 --> URI Class Initialized
INFO - 2017-06-15 13:35:44 --> Router Class Initialized
INFO - 2017-06-15 13:35:44 --> Output Class Initialized
INFO - 2017-06-15 13:35:44 --> Security Class Initialized
DEBUG - 2017-06-15 13:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:35:44 --> Input Class Initialized
INFO - 2017-06-15 13:35:44 --> Language Class Initialized
INFO - 2017-06-15 13:35:44 --> Loader Class Initialized
INFO - 2017-06-15 13:35:44 --> Helper loaded: common_helper
INFO - 2017-06-15 13:35:44 --> Database Driver Class Initialized
INFO - 2017-06-15 13:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:35:44 --> Email Class Initialized
INFO - 2017-06-15 13:35:44 --> Controller Class Initialized
INFO - 2017-06-15 13:35:44 --> Helper loaded: form_helper
INFO - 2017-06-15 13:35:44 --> Form Validation Class Initialized
INFO - 2017-06-15 13:35:44 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:35:44 --> Helper loaded: url_helper
INFO - 2017-06-15 13:35:44 --> Model Class Initialized
INFO - 2017-06-15 13:35:44 --> Model Class Initialized
INFO - 2017-06-15 17:05:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:05:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:05:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:05:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:05:44 --> Final output sent to browser
DEBUG - 2017-06-15 17:05:44 --> Total execution time: 0.0492
INFO - 2017-06-15 13:39:13 --> Config Class Initialized
INFO - 2017-06-15 13:39:13 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:39:13 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:39:13 --> Utf8 Class Initialized
INFO - 2017-06-15 13:39:13 --> URI Class Initialized
INFO - 2017-06-15 13:39:13 --> Router Class Initialized
INFO - 2017-06-15 13:39:13 --> Output Class Initialized
INFO - 2017-06-15 13:39:13 --> Security Class Initialized
DEBUG - 2017-06-15 13:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:39:13 --> Input Class Initialized
INFO - 2017-06-15 13:39:13 --> Language Class Initialized
INFO - 2017-06-15 13:39:13 --> Loader Class Initialized
INFO - 2017-06-15 13:39:13 --> Helper loaded: common_helper
INFO - 2017-06-15 13:39:13 --> Database Driver Class Initialized
INFO - 2017-06-15 13:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:39:13 --> Email Class Initialized
INFO - 2017-06-15 13:39:13 --> Controller Class Initialized
INFO - 2017-06-15 13:39:13 --> Helper loaded: form_helper
INFO - 2017-06-15 13:39:13 --> Form Validation Class Initialized
INFO - 2017-06-15 13:39:13 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:39:13 --> Helper loaded: url_helper
INFO - 2017-06-15 13:39:13 --> Model Class Initialized
INFO - 2017-06-15 13:39:13 --> Model Class Initialized
INFO - 2017-06-15 17:09:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:09:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
ERROR - 2017-06-15 17:09:13 --> Undefined variable: users
ERROR - 2017-06-15 17:09:13 --> Severity: Notice --> Undefined variable: users C:\xampp\htdocs\bloodApp\application\views\users\users.php 37
INFO - 2017-06-15 17:09:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:09:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:09:13 --> Final output sent to browser
DEBUG - 2017-06-15 17:09:13 --> Total execution time: 0.0568
INFO - 2017-06-15 13:39:29 --> Config Class Initialized
INFO - 2017-06-15 13:39:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:39:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:39:29 --> Utf8 Class Initialized
INFO - 2017-06-15 13:39:29 --> URI Class Initialized
INFO - 2017-06-15 13:39:29 --> Router Class Initialized
INFO - 2017-06-15 13:39:29 --> Output Class Initialized
INFO - 2017-06-15 13:39:29 --> Security Class Initialized
DEBUG - 2017-06-15 13:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:39:29 --> Input Class Initialized
INFO - 2017-06-15 13:39:29 --> Language Class Initialized
INFO - 2017-06-15 13:39:29 --> Loader Class Initialized
INFO - 2017-06-15 13:39:29 --> Helper loaded: common_helper
INFO - 2017-06-15 13:39:29 --> Database Driver Class Initialized
INFO - 2017-06-15 13:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:39:29 --> Email Class Initialized
INFO - 2017-06-15 13:39:29 --> Controller Class Initialized
INFO - 2017-06-15 13:39:29 --> Helper loaded: form_helper
INFO - 2017-06-15 13:39:29 --> Form Validation Class Initialized
INFO - 2017-06-15 13:39:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:39:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:39:29 --> Helper loaded: url_helper
INFO - 2017-06-15 13:39:29 --> Model Class Initialized
INFO - 2017-06-15 13:39:29 --> Model Class Initialized
INFO - 2017-06-15 17:09:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:09:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:42:11 --> Config Class Initialized
INFO - 2017-06-15 13:42:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:42:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:42:11 --> Utf8 Class Initialized
INFO - 2017-06-15 13:42:11 --> URI Class Initialized
INFO - 2017-06-15 13:42:11 --> Router Class Initialized
INFO - 2017-06-15 13:42:11 --> Output Class Initialized
INFO - 2017-06-15 13:42:11 --> Security Class Initialized
DEBUG - 2017-06-15 13:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:42:11 --> Input Class Initialized
INFO - 2017-06-15 13:42:11 --> Language Class Initialized
INFO - 2017-06-15 13:42:11 --> Loader Class Initialized
INFO - 2017-06-15 13:42:11 --> Helper loaded: common_helper
INFO - 2017-06-15 13:42:11 --> Database Driver Class Initialized
INFO - 2017-06-15 13:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:42:11 --> Email Class Initialized
INFO - 2017-06-15 13:42:11 --> Controller Class Initialized
INFO - 2017-06-15 13:42:11 --> Helper loaded: form_helper
INFO - 2017-06-15 13:42:11 --> Form Validation Class Initialized
INFO - 2017-06-15 13:42:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:42:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:42:11 --> Helper loaded: url_helper
INFO - 2017-06-15 13:42:11 --> Model Class Initialized
INFO - 2017-06-15 13:42:11 --> Model Class Initialized
INFO - 2017-06-15 17:12:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:12:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 13:42:22 --> Config Class Initialized
INFO - 2017-06-15 13:42:22 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:42:22 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:42:22 --> Utf8 Class Initialized
INFO - 2017-06-15 13:42:22 --> URI Class Initialized
INFO - 2017-06-15 13:42:22 --> Router Class Initialized
INFO - 2017-06-15 13:42:22 --> Output Class Initialized
INFO - 2017-06-15 13:42:22 --> Security Class Initialized
DEBUG - 2017-06-15 13:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:42:22 --> Input Class Initialized
INFO - 2017-06-15 13:42:22 --> Language Class Initialized
INFO - 2017-06-15 13:42:22 --> Loader Class Initialized
INFO - 2017-06-15 13:42:22 --> Helper loaded: common_helper
INFO - 2017-06-15 13:42:22 --> Database Driver Class Initialized
INFO - 2017-06-15 13:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:42:22 --> Email Class Initialized
INFO - 2017-06-15 13:42:22 --> Controller Class Initialized
INFO - 2017-06-15 13:42:22 --> Helper loaded: form_helper
INFO - 2017-06-15 13:42:22 --> Form Validation Class Initialized
INFO - 2017-06-15 13:42:22 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:42:22 --> Helper loaded: url_helper
INFO - 2017-06-15 13:42:22 --> Model Class Initialized
INFO - 2017-06-15 13:42:22 --> Model Class Initialized
INFO - 2017-06-15 17:12:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:12:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:12:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:12:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:12:22 --> Final output sent to browser
DEBUG - 2017-06-15 17:12:22 --> Total execution time: 0.0519
INFO - 2017-06-15 13:42:38 --> Config Class Initialized
INFO - 2017-06-15 13:42:38 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:42:38 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:42:38 --> Utf8 Class Initialized
INFO - 2017-06-15 13:42:38 --> URI Class Initialized
INFO - 2017-06-15 13:42:38 --> Router Class Initialized
INFO - 2017-06-15 13:42:38 --> Output Class Initialized
INFO - 2017-06-15 13:42:38 --> Security Class Initialized
DEBUG - 2017-06-15 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:42:38 --> Input Class Initialized
INFO - 2017-06-15 13:42:38 --> Language Class Initialized
INFO - 2017-06-15 13:42:38 --> Loader Class Initialized
INFO - 2017-06-15 13:42:38 --> Helper loaded: common_helper
INFO - 2017-06-15 13:42:38 --> Database Driver Class Initialized
INFO - 2017-06-15 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:42:38 --> Email Class Initialized
INFO - 2017-06-15 13:42:38 --> Controller Class Initialized
INFO - 2017-06-15 13:42:38 --> Helper loaded: form_helper
INFO - 2017-06-15 13:42:38 --> Form Validation Class Initialized
INFO - 2017-06-15 13:42:38 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:42:38 --> Helper loaded: url_helper
INFO - 2017-06-15 13:42:38 --> Model Class Initialized
INFO - 2017-06-15 13:42:38 --> Model Class Initialized
INFO - 2017-06-15 17:12:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:12:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:12:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:12:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:12:38 --> Final output sent to browser
DEBUG - 2017-06-15 17:12:38 --> Total execution time: 0.0506
INFO - 2017-06-15 13:42:58 --> Config Class Initialized
INFO - 2017-06-15 13:42:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:42:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:42:58 --> Utf8 Class Initialized
INFO - 2017-06-15 13:42:58 --> URI Class Initialized
INFO - 2017-06-15 13:42:58 --> Router Class Initialized
INFO - 2017-06-15 13:42:58 --> Output Class Initialized
INFO - 2017-06-15 13:42:58 --> Security Class Initialized
DEBUG - 2017-06-15 13:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:42:58 --> Input Class Initialized
INFO - 2017-06-15 13:42:58 --> Language Class Initialized
INFO - 2017-06-15 13:42:58 --> Loader Class Initialized
INFO - 2017-06-15 13:42:58 --> Helper loaded: common_helper
INFO - 2017-06-15 13:42:58 --> Database Driver Class Initialized
INFO - 2017-06-15 13:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:42:58 --> Email Class Initialized
INFO - 2017-06-15 13:42:58 --> Controller Class Initialized
INFO - 2017-06-15 13:42:58 --> Helper loaded: form_helper
INFO - 2017-06-15 13:42:58 --> Form Validation Class Initialized
INFO - 2017-06-15 13:42:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:42:58 --> Helper loaded: url_helper
INFO - 2017-06-15 13:42:58 --> Model Class Initialized
INFO - 2017-06-15 13:42:58 --> Model Class Initialized
INFO - 2017-06-15 17:12:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:12:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:12:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:12:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:12:58 --> Final output sent to browser
DEBUG - 2017-06-15 17:12:58 --> Total execution time: 0.0482
INFO - 2017-06-15 13:43:13 --> Config Class Initialized
INFO - 2017-06-15 13:43:13 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:43:13 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:43:13 --> Utf8 Class Initialized
INFO - 2017-06-15 13:43:13 --> URI Class Initialized
INFO - 2017-06-15 13:43:13 --> Router Class Initialized
INFO - 2017-06-15 13:43:13 --> Output Class Initialized
INFO - 2017-06-15 13:43:13 --> Security Class Initialized
DEBUG - 2017-06-15 13:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:43:13 --> Input Class Initialized
INFO - 2017-06-15 13:43:13 --> Language Class Initialized
INFO - 2017-06-15 13:43:13 --> Loader Class Initialized
INFO - 2017-06-15 13:43:13 --> Helper loaded: common_helper
INFO - 2017-06-15 13:43:13 --> Database Driver Class Initialized
INFO - 2017-06-15 13:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:43:13 --> Email Class Initialized
INFO - 2017-06-15 13:43:13 --> Controller Class Initialized
INFO - 2017-06-15 13:43:13 --> Helper loaded: form_helper
INFO - 2017-06-15 13:43:13 --> Form Validation Class Initialized
INFO - 2017-06-15 13:43:13 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:43:13 --> Helper loaded: url_helper
INFO - 2017-06-15 13:43:13 --> Model Class Initialized
INFO - 2017-06-15 13:43:13 --> Model Class Initialized
INFO - 2017-06-15 17:13:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:13:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:13:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:13:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:13:13 --> Final output sent to browser
DEBUG - 2017-06-15 17:13:13 --> Total execution time: 0.0506
INFO - 2017-06-15 13:43:47 --> Config Class Initialized
INFO - 2017-06-15 13:43:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:43:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:43:47 --> Utf8 Class Initialized
INFO - 2017-06-15 13:43:47 --> URI Class Initialized
INFO - 2017-06-15 13:43:47 --> Router Class Initialized
INFO - 2017-06-15 13:43:47 --> Output Class Initialized
INFO - 2017-06-15 13:43:47 --> Security Class Initialized
DEBUG - 2017-06-15 13:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:43:47 --> Input Class Initialized
INFO - 2017-06-15 13:43:47 --> Language Class Initialized
INFO - 2017-06-15 13:43:47 --> Loader Class Initialized
INFO - 2017-06-15 13:43:47 --> Helper loaded: common_helper
INFO - 2017-06-15 13:43:47 --> Database Driver Class Initialized
INFO - 2017-06-15 13:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:43:47 --> Email Class Initialized
INFO - 2017-06-15 13:43:47 --> Controller Class Initialized
INFO - 2017-06-15 13:43:47 --> Helper loaded: form_helper
INFO - 2017-06-15 13:43:47 --> Form Validation Class Initialized
INFO - 2017-06-15 13:43:47 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:43:47 --> Helper loaded: url_helper
INFO - 2017-06-15 13:43:47 --> Model Class Initialized
INFO - 2017-06-15 13:43:47 --> Model Class Initialized
INFO - 2017-06-15 17:13:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:13:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:13:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:13:47 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:13:47 --> Final output sent to browser
DEBUG - 2017-06-15 17:13:47 --> Total execution time: 0.0532
INFO - 2017-06-15 13:44:04 --> Config Class Initialized
INFO - 2017-06-15 13:44:04 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:44:04 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:44:04 --> Utf8 Class Initialized
INFO - 2017-06-15 13:44:04 --> URI Class Initialized
INFO - 2017-06-15 13:44:04 --> Router Class Initialized
INFO - 2017-06-15 13:44:04 --> Output Class Initialized
INFO - 2017-06-15 13:44:04 --> Security Class Initialized
DEBUG - 2017-06-15 13:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:44:04 --> Input Class Initialized
INFO - 2017-06-15 13:44:04 --> Language Class Initialized
INFO - 2017-06-15 13:44:04 --> Loader Class Initialized
INFO - 2017-06-15 13:44:04 --> Helper loaded: common_helper
INFO - 2017-06-15 13:44:04 --> Database Driver Class Initialized
INFO - 2017-06-15 13:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:44:04 --> Email Class Initialized
INFO - 2017-06-15 13:44:04 --> Controller Class Initialized
INFO - 2017-06-15 13:44:04 --> Helper loaded: form_helper
INFO - 2017-06-15 13:44:04 --> Form Validation Class Initialized
INFO - 2017-06-15 13:44:04 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:44:04 --> Helper loaded: url_helper
INFO - 2017-06-15 13:44:04 --> Model Class Initialized
INFO - 2017-06-15 13:44:04 --> Model Class Initialized
INFO - 2017-06-15 17:14:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:14:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:14:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:14:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:14:04 --> Final output sent to browser
DEBUG - 2017-06-15 17:14:04 --> Total execution time: 0.0514
INFO - 2017-06-15 13:44:29 --> Config Class Initialized
INFO - 2017-06-15 13:44:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:44:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:44:29 --> Utf8 Class Initialized
INFO - 2017-06-15 13:44:29 --> URI Class Initialized
INFO - 2017-06-15 13:44:29 --> Router Class Initialized
INFO - 2017-06-15 13:44:29 --> Output Class Initialized
INFO - 2017-06-15 13:44:29 --> Security Class Initialized
DEBUG - 2017-06-15 13:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:44:29 --> Input Class Initialized
INFO - 2017-06-15 13:44:29 --> Language Class Initialized
INFO - 2017-06-15 13:44:29 --> Loader Class Initialized
INFO - 2017-06-15 13:44:29 --> Helper loaded: common_helper
INFO - 2017-06-15 13:44:29 --> Database Driver Class Initialized
INFO - 2017-06-15 13:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:44:29 --> Email Class Initialized
INFO - 2017-06-15 13:44:29 --> Controller Class Initialized
INFO - 2017-06-15 13:44:29 --> Helper loaded: form_helper
INFO - 2017-06-15 13:44:29 --> Form Validation Class Initialized
INFO - 2017-06-15 13:44:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:44:29 --> Helper loaded: url_helper
INFO - 2017-06-15 13:44:29 --> Model Class Initialized
INFO - 2017-06-15 13:44:29 --> Model Class Initialized
INFO - 2017-06-15 17:14:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:14:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:14:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:14:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:14:29 --> Final output sent to browser
DEBUG - 2017-06-15 17:14:29 --> Total execution time: 0.0494
INFO - 2017-06-15 13:44:49 --> Config Class Initialized
INFO - 2017-06-15 13:44:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:44:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:44:49 --> Utf8 Class Initialized
INFO - 2017-06-15 13:44:49 --> URI Class Initialized
INFO - 2017-06-15 13:44:49 --> Router Class Initialized
INFO - 2017-06-15 13:44:49 --> Output Class Initialized
INFO - 2017-06-15 13:44:49 --> Security Class Initialized
DEBUG - 2017-06-15 13:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:44:49 --> Input Class Initialized
INFO - 2017-06-15 13:44:49 --> Language Class Initialized
INFO - 2017-06-15 13:44:49 --> Loader Class Initialized
INFO - 2017-06-15 13:44:49 --> Helper loaded: common_helper
INFO - 2017-06-15 13:44:49 --> Database Driver Class Initialized
INFO - 2017-06-15 13:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:44:49 --> Email Class Initialized
INFO - 2017-06-15 13:44:49 --> Controller Class Initialized
INFO - 2017-06-15 13:44:49 --> Helper loaded: form_helper
INFO - 2017-06-15 13:44:49 --> Form Validation Class Initialized
INFO - 2017-06-15 13:44:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:44:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:44:49 --> Helper loaded: url_helper
INFO - 2017-06-15 13:44:49 --> Model Class Initialized
INFO - 2017-06-15 13:44:49 --> Model Class Initialized
INFO - 2017-06-15 17:14:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:14:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:14:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:14:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:14:49 --> Final output sent to browser
DEBUG - 2017-06-15 17:14:49 --> Total execution time: 0.0470
INFO - 2017-06-15 13:45:34 --> Config Class Initialized
INFO - 2017-06-15 13:45:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:45:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:45:34 --> Utf8 Class Initialized
INFO - 2017-06-15 13:45:34 --> URI Class Initialized
INFO - 2017-06-15 13:45:34 --> Router Class Initialized
INFO - 2017-06-15 13:45:34 --> Output Class Initialized
INFO - 2017-06-15 13:45:34 --> Security Class Initialized
DEBUG - 2017-06-15 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:45:34 --> Input Class Initialized
INFO - 2017-06-15 13:45:34 --> Language Class Initialized
INFO - 2017-06-15 13:45:34 --> Loader Class Initialized
INFO - 2017-06-15 13:45:34 --> Helper loaded: common_helper
INFO - 2017-06-15 13:45:34 --> Database Driver Class Initialized
INFO - 2017-06-15 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:45:34 --> Email Class Initialized
INFO - 2017-06-15 13:45:34 --> Controller Class Initialized
INFO - 2017-06-15 13:45:34 --> Helper loaded: form_helper
INFO - 2017-06-15 13:45:34 --> Form Validation Class Initialized
INFO - 2017-06-15 13:45:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:45:34 --> Helper loaded: url_helper
INFO - 2017-06-15 13:45:34 --> Model Class Initialized
INFO - 2017-06-15 13:45:34 --> Model Class Initialized
INFO - 2017-06-15 17:15:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:15:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:15:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:15:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:15:34 --> Final output sent to browser
DEBUG - 2017-06-15 17:15:34 --> Total execution time: 0.0564
INFO - 2017-06-15 13:48:34 --> Config Class Initialized
INFO - 2017-06-15 13:48:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:48:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:48:34 --> Utf8 Class Initialized
INFO - 2017-06-15 13:48:34 --> URI Class Initialized
INFO - 2017-06-15 13:48:34 --> Router Class Initialized
INFO - 2017-06-15 13:48:34 --> Output Class Initialized
INFO - 2017-06-15 13:48:34 --> Security Class Initialized
DEBUG - 2017-06-15 13:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:48:34 --> Input Class Initialized
INFO - 2017-06-15 13:48:34 --> Language Class Initialized
INFO - 2017-06-15 13:48:34 --> Loader Class Initialized
INFO - 2017-06-15 13:48:34 --> Helper loaded: common_helper
INFO - 2017-06-15 13:48:34 --> Database Driver Class Initialized
INFO - 2017-06-15 13:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:48:34 --> Email Class Initialized
INFO - 2017-06-15 13:48:34 --> Controller Class Initialized
INFO - 2017-06-15 13:48:34 --> Helper loaded: form_helper
INFO - 2017-06-15 13:48:34 --> Form Validation Class Initialized
INFO - 2017-06-15 13:48:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:48:34 --> Helper loaded: url_helper
INFO - 2017-06-15 13:48:34 --> Model Class Initialized
INFO - 2017-06-15 13:48:34 --> Model Class Initialized
INFO - 2017-06-15 17:18:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:18:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:18:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:18:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:18:34 --> Final output sent to browser
DEBUG - 2017-06-15 17:18:34 --> Total execution time: 0.0516
INFO - 2017-06-15 13:48:39 --> Config Class Initialized
INFO - 2017-06-15 13:48:39 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:48:39 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:48:39 --> Utf8 Class Initialized
INFO - 2017-06-15 13:48:39 --> URI Class Initialized
INFO - 2017-06-15 13:48:39 --> Router Class Initialized
INFO - 2017-06-15 13:48:39 --> Output Class Initialized
INFO - 2017-06-15 13:48:39 --> Security Class Initialized
DEBUG - 2017-06-15 13:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:48:39 --> Input Class Initialized
INFO - 2017-06-15 13:48:39 --> Language Class Initialized
INFO - 2017-06-15 13:48:39 --> Loader Class Initialized
INFO - 2017-06-15 13:48:39 --> Helper loaded: common_helper
INFO - 2017-06-15 13:48:39 --> Database Driver Class Initialized
INFO - 2017-06-15 13:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:48:39 --> Email Class Initialized
INFO - 2017-06-15 13:48:39 --> Controller Class Initialized
INFO - 2017-06-15 13:48:39 --> Helper loaded: form_helper
INFO - 2017-06-15 13:48:39 --> Form Validation Class Initialized
INFO - 2017-06-15 13:48:39 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:48:39 --> Helper loaded: url_helper
INFO - 2017-06-15 13:48:39 --> Model Class Initialized
INFO - 2017-06-15 13:48:39 --> Model Class Initialized
INFO - 2017-06-15 17:18:39 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:18:39 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:18:39 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:18:39 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:18:39 --> Final output sent to browser
DEBUG - 2017-06-15 17:18:39 --> Total execution time: 0.0566
INFO - 2017-06-15 13:49:01 --> Config Class Initialized
INFO - 2017-06-15 13:49:01 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:49:01 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:49:01 --> Utf8 Class Initialized
INFO - 2017-06-15 13:49:01 --> URI Class Initialized
INFO - 2017-06-15 13:49:01 --> Router Class Initialized
INFO - 2017-06-15 13:49:01 --> Output Class Initialized
INFO - 2017-06-15 13:49:01 --> Security Class Initialized
DEBUG - 2017-06-15 13:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:49:01 --> Input Class Initialized
INFO - 2017-06-15 13:49:01 --> Language Class Initialized
INFO - 2017-06-15 13:49:01 --> Loader Class Initialized
INFO - 2017-06-15 13:49:01 --> Helper loaded: common_helper
INFO - 2017-06-15 13:49:01 --> Database Driver Class Initialized
INFO - 2017-06-15 13:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:49:01 --> Email Class Initialized
INFO - 2017-06-15 13:49:01 --> Controller Class Initialized
INFO - 2017-06-15 13:49:01 --> Helper loaded: form_helper
INFO - 2017-06-15 13:49:01 --> Form Validation Class Initialized
INFO - 2017-06-15 13:49:01 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:49:01 --> Helper loaded: url_helper
INFO - 2017-06-15 13:49:01 --> Model Class Initialized
INFO - 2017-06-15 13:49:01 --> Model Class Initialized
INFO - 2017-06-15 17:19:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:19:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:19:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:19:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:19:01 --> Final output sent to browser
DEBUG - 2017-06-15 17:19:01 --> Total execution time: 0.0529
INFO - 2017-06-15 13:53:11 --> Config Class Initialized
INFO - 2017-06-15 13:53:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:53:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:53:11 --> Utf8 Class Initialized
INFO - 2017-06-15 13:53:11 --> URI Class Initialized
INFO - 2017-06-15 13:53:11 --> Router Class Initialized
INFO - 2017-06-15 13:53:11 --> Output Class Initialized
INFO - 2017-06-15 13:53:11 --> Security Class Initialized
DEBUG - 2017-06-15 13:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:53:11 --> Input Class Initialized
INFO - 2017-06-15 13:53:11 --> Language Class Initialized
INFO - 2017-06-15 13:53:11 --> Loader Class Initialized
INFO - 2017-06-15 13:53:11 --> Helper loaded: common_helper
INFO - 2017-06-15 13:53:11 --> Database Driver Class Initialized
INFO - 2017-06-15 13:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:53:11 --> Email Class Initialized
INFO - 2017-06-15 13:53:11 --> Controller Class Initialized
INFO - 2017-06-15 13:53:11 --> Helper loaded: form_helper
INFO - 2017-06-15 13:53:11 --> Form Validation Class Initialized
INFO - 2017-06-15 13:53:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:53:11 --> Helper loaded: url_helper
INFO - 2017-06-15 13:53:11 --> Model Class Initialized
INFO - 2017-06-15 13:53:11 --> Model Class Initialized
INFO - 2017-06-15 17:23:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:23:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:23:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:23:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:23:11 --> Final output sent to browser
DEBUG - 2017-06-15 17:23:11 --> Total execution time: 0.0518
INFO - 2017-06-15 13:53:31 --> Config Class Initialized
INFO - 2017-06-15 13:53:31 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:53:31 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:53:31 --> Utf8 Class Initialized
INFO - 2017-06-15 13:53:31 --> URI Class Initialized
INFO - 2017-06-15 13:53:31 --> Router Class Initialized
INFO - 2017-06-15 13:53:31 --> Output Class Initialized
INFO - 2017-06-15 13:53:31 --> Security Class Initialized
DEBUG - 2017-06-15 13:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:53:31 --> Input Class Initialized
INFO - 2017-06-15 13:53:31 --> Language Class Initialized
INFO - 2017-06-15 13:53:31 --> Loader Class Initialized
INFO - 2017-06-15 13:53:31 --> Helper loaded: common_helper
INFO - 2017-06-15 13:53:31 --> Database Driver Class Initialized
INFO - 2017-06-15 13:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:53:31 --> Email Class Initialized
INFO - 2017-06-15 13:53:31 --> Controller Class Initialized
INFO - 2017-06-15 13:53:31 --> Helper loaded: form_helper
INFO - 2017-06-15 13:53:31 --> Form Validation Class Initialized
INFO - 2017-06-15 13:53:31 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:53:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:53:31 --> Helper loaded: url_helper
INFO - 2017-06-15 13:53:31 --> Model Class Initialized
INFO - 2017-06-15 13:53:31 --> Model Class Initialized
INFO - 2017-06-15 17:23:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:23:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:23:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:23:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:23:31 --> Final output sent to browser
DEBUG - 2017-06-15 17:23:31 --> Total execution time: 0.0489
INFO - 2017-06-15 13:53:34 --> Config Class Initialized
INFO - 2017-06-15 13:53:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:53:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:53:34 --> Utf8 Class Initialized
INFO - 2017-06-15 13:53:34 --> URI Class Initialized
INFO - 2017-06-15 13:53:34 --> Router Class Initialized
INFO - 2017-06-15 13:53:34 --> Output Class Initialized
INFO - 2017-06-15 13:53:34 --> Security Class Initialized
DEBUG - 2017-06-15 13:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:53:34 --> Input Class Initialized
INFO - 2017-06-15 13:53:34 --> Language Class Initialized
INFO - 2017-06-15 13:53:34 --> Loader Class Initialized
INFO - 2017-06-15 13:53:34 --> Helper loaded: common_helper
INFO - 2017-06-15 13:53:34 --> Database Driver Class Initialized
INFO - 2017-06-15 13:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:53:34 --> Email Class Initialized
INFO - 2017-06-15 13:53:34 --> Controller Class Initialized
INFO - 2017-06-15 13:53:34 --> Helper loaded: form_helper
INFO - 2017-06-15 13:53:34 --> Form Validation Class Initialized
INFO - 2017-06-15 13:53:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:53:34 --> Helper loaded: url_helper
INFO - 2017-06-15 13:53:34 --> Model Class Initialized
INFO - 2017-06-15 13:53:34 --> Model Class Initialized
INFO - 2017-06-15 13:54:50 --> Config Class Initialized
INFO - 2017-06-15 13:54:50 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:54:50 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:54:50 --> Utf8 Class Initialized
INFO - 2017-06-15 13:54:50 --> URI Class Initialized
INFO - 2017-06-15 13:54:50 --> Router Class Initialized
INFO - 2017-06-15 13:54:50 --> Output Class Initialized
INFO - 2017-06-15 13:54:50 --> Security Class Initialized
DEBUG - 2017-06-15 13:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:54:50 --> Input Class Initialized
INFO - 2017-06-15 13:54:50 --> Language Class Initialized
INFO - 2017-06-15 13:54:50 --> Loader Class Initialized
INFO - 2017-06-15 13:54:50 --> Helper loaded: common_helper
INFO - 2017-06-15 13:54:50 --> Database Driver Class Initialized
INFO - 2017-06-15 13:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:54:50 --> Email Class Initialized
INFO - 2017-06-15 13:54:50 --> Controller Class Initialized
INFO - 2017-06-15 13:54:50 --> Helper loaded: form_helper
INFO - 2017-06-15 13:54:50 --> Form Validation Class Initialized
INFO - 2017-06-15 13:54:50 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:54:50 --> Helper loaded: url_helper
INFO - 2017-06-15 13:54:50 --> Model Class Initialized
INFO - 2017-06-15 13:54:50 --> Model Class Initialized
INFO - 2017-06-15 13:54:51 --> Config Class Initialized
INFO - 2017-06-15 13:54:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:54:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:54:51 --> Utf8 Class Initialized
INFO - 2017-06-15 13:54:51 --> URI Class Initialized
INFO - 2017-06-15 13:54:51 --> Router Class Initialized
INFO - 2017-06-15 13:54:51 --> Output Class Initialized
INFO - 2017-06-15 13:54:51 --> Security Class Initialized
DEBUG - 2017-06-15 13:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:54:51 --> Input Class Initialized
INFO - 2017-06-15 13:54:51 --> Language Class Initialized
INFO - 2017-06-15 13:54:51 --> Loader Class Initialized
INFO - 2017-06-15 13:54:51 --> Helper loaded: common_helper
INFO - 2017-06-15 13:54:51 --> Database Driver Class Initialized
INFO - 2017-06-15 13:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:54:51 --> Email Class Initialized
INFO - 2017-06-15 13:54:51 --> Controller Class Initialized
INFO - 2017-06-15 13:54:51 --> Helper loaded: form_helper
INFO - 2017-06-15 13:54:51 --> Form Validation Class Initialized
INFO - 2017-06-15 13:54:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:54:51 --> Helper loaded: url_helper
INFO - 2017-06-15 13:54:51 --> Model Class Initialized
INFO - 2017-06-15 13:54:51 --> Model Class Initialized
INFO - 2017-06-15 17:24:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
ERROR - 2017-06-15 17:24:51 --> Use of undefined constant BLOOD_GROUPS_MANAGEMENT_URL - assumed 'BLOOD_GROUPS_MANAGEMENT_URL'
ERROR - 2017-06-15 17:24:51 --> Severity: Notice --> Use of undefined constant BLOOD_GROUPS_MANAGEMENT_URL - assumed 'BLOOD_GROUPS_MANAGEMENT_URL' C:\xampp\htdocs\bloodApp\application\views\sideMenu.php 8
INFO - 2017-06-15 17:24:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:24:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:24:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:24:51 --> Final output sent to browser
DEBUG - 2017-06-15 17:24:51 --> Total execution time: 0.0504
INFO - 2017-06-15 13:54:54 --> Config Class Initialized
INFO - 2017-06-15 13:54:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:54:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:54:54 --> Utf8 Class Initialized
INFO - 2017-06-15 13:54:54 --> URI Class Initialized
INFO - 2017-06-15 13:54:54 --> Router Class Initialized
INFO - 2017-06-15 13:54:54 --> Output Class Initialized
INFO - 2017-06-15 13:54:54 --> Security Class Initialized
DEBUG - 2017-06-15 13:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:54:54 --> Input Class Initialized
INFO - 2017-06-15 13:54:54 --> Language Class Initialized
INFO - 2017-06-15 13:54:54 --> Loader Class Initialized
INFO - 2017-06-15 13:54:54 --> Helper loaded: common_helper
INFO - 2017-06-15 13:54:54 --> Database Driver Class Initialized
INFO - 2017-06-15 13:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:54:54 --> Email Class Initialized
INFO - 2017-06-15 13:54:54 --> Controller Class Initialized
INFO - 2017-06-15 13:54:54 --> Helper loaded: form_helper
INFO - 2017-06-15 13:54:54 --> Form Validation Class Initialized
INFO - 2017-06-15 13:54:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:54:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:54:54 --> Helper loaded: url_helper
INFO - 2017-06-15 13:54:54 --> Model Class Initialized
INFO - 2017-06-15 13:54:54 --> Model Class Initialized
INFO - 2017-06-15 17:24:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
ERROR - 2017-06-15 17:24:54 --> Use of undefined constant BLOOD_GROUPS_MANAGEMENT_URL - assumed 'BLOOD_GROUPS_MANAGEMENT_URL'
ERROR - 2017-06-15 17:24:54 --> Severity: Notice --> Use of undefined constant BLOOD_GROUPS_MANAGEMENT_URL - assumed 'BLOOD_GROUPS_MANAGEMENT_URL' C:\xampp\htdocs\bloodApp\application\views\sideMenu.php 8
INFO - 2017-06-15 17:24:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:24:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:24:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:24:54 --> Final output sent to browser
DEBUG - 2017-06-15 17:24:54 --> Total execution time: 0.0485
INFO - 2017-06-15 13:55:11 --> Config Class Initialized
INFO - 2017-06-15 13:55:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:55:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:55:11 --> Utf8 Class Initialized
INFO - 2017-06-15 13:55:11 --> URI Class Initialized
INFO - 2017-06-15 13:55:11 --> Router Class Initialized
INFO - 2017-06-15 13:55:11 --> Output Class Initialized
INFO - 2017-06-15 13:55:12 --> Security Class Initialized
DEBUG - 2017-06-15 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:55:12 --> Input Class Initialized
INFO - 2017-06-15 13:55:12 --> Language Class Initialized
INFO - 2017-06-15 13:55:12 --> Loader Class Initialized
INFO - 2017-06-15 13:55:12 --> Helper loaded: common_helper
INFO - 2017-06-15 13:55:12 --> Database Driver Class Initialized
INFO - 2017-06-15 13:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:55:12 --> Email Class Initialized
INFO - 2017-06-15 13:55:12 --> Controller Class Initialized
INFO - 2017-06-15 13:55:12 --> Helper loaded: form_helper
INFO - 2017-06-15 13:55:12 --> Form Validation Class Initialized
INFO - 2017-06-15 13:55:12 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:55:12 --> Helper loaded: url_helper
INFO - 2017-06-15 13:55:12 --> Model Class Initialized
INFO - 2017-06-15 13:55:12 --> Model Class Initialized
INFO - 2017-06-15 17:25:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:25:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:25:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:25:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:25:12 --> Final output sent to browser
DEBUG - 2017-06-15 17:25:12 --> Total execution time: 0.0488
INFO - 2017-06-15 13:57:53 --> Config Class Initialized
INFO - 2017-06-15 13:57:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:57:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:57:53 --> Utf8 Class Initialized
INFO - 2017-06-15 13:57:53 --> URI Class Initialized
INFO - 2017-06-15 13:57:53 --> Router Class Initialized
INFO - 2017-06-15 13:57:53 --> Output Class Initialized
INFO - 2017-06-15 13:57:53 --> Security Class Initialized
DEBUG - 2017-06-15 13:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:57:53 --> Input Class Initialized
INFO - 2017-06-15 13:57:53 --> Language Class Initialized
INFO - 2017-06-15 13:57:53 --> Loader Class Initialized
INFO - 2017-06-15 13:57:53 --> Helper loaded: common_helper
INFO - 2017-06-15 13:57:53 --> Database Driver Class Initialized
INFO - 2017-06-15 13:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:57:53 --> Email Class Initialized
INFO - 2017-06-15 13:57:53 --> Controller Class Initialized
INFO - 2017-06-15 13:57:53 --> Helper loaded: form_helper
INFO - 2017-06-15 13:57:53 --> Form Validation Class Initialized
INFO - 2017-06-15 13:57:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:57:53 --> Helper loaded: url_helper
INFO - 2017-06-15 13:57:53 --> Model Class Initialized
INFO - 2017-06-15 13:57:53 --> Model Class Initialized
INFO - 2017-06-15 17:27:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:27:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:27:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:27:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:27:53 --> Final output sent to browser
DEBUG - 2017-06-15 17:27:53 --> Total execution time: 0.0511
INFO - 2017-06-15 13:57:54 --> Config Class Initialized
INFO - 2017-06-15 13:57:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:57:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:57:54 --> Utf8 Class Initialized
INFO - 2017-06-15 13:57:54 --> URI Class Initialized
INFO - 2017-06-15 13:57:54 --> Router Class Initialized
INFO - 2017-06-15 13:57:54 --> Output Class Initialized
INFO - 2017-06-15 13:57:54 --> Security Class Initialized
DEBUG - 2017-06-15 13:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:57:54 --> Input Class Initialized
INFO - 2017-06-15 13:57:54 --> Language Class Initialized
INFO - 2017-06-15 13:57:54 --> Loader Class Initialized
INFO - 2017-06-15 13:57:54 --> Helper loaded: common_helper
INFO - 2017-06-15 13:57:54 --> Database Driver Class Initialized
INFO - 2017-06-15 13:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:57:54 --> Email Class Initialized
INFO - 2017-06-15 13:57:54 --> Controller Class Initialized
INFO - 2017-06-15 13:57:54 --> Helper loaded: form_helper
INFO - 2017-06-15 13:57:54 --> Form Validation Class Initialized
INFO - 2017-06-15 13:57:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:57:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:57:54 --> Helper loaded: url_helper
INFO - 2017-06-15 13:57:54 --> Model Class Initialized
INFO - 2017-06-15 13:57:54 --> Model Class Initialized
INFO - 2017-06-15 13:57:59 --> Config Class Initialized
INFO - 2017-06-15 13:57:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:57:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:57:59 --> Utf8 Class Initialized
INFO - 2017-06-15 13:57:59 --> URI Class Initialized
INFO - 2017-06-15 13:57:59 --> Router Class Initialized
INFO - 2017-06-15 13:57:59 --> Output Class Initialized
INFO - 2017-06-15 13:57:59 --> Security Class Initialized
DEBUG - 2017-06-15 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:57:59 --> Input Class Initialized
INFO - 2017-06-15 13:57:59 --> Language Class Initialized
INFO - 2017-06-15 13:57:59 --> Loader Class Initialized
INFO - 2017-06-15 13:57:59 --> Helper loaded: common_helper
INFO - 2017-06-15 13:57:59 --> Database Driver Class Initialized
INFO - 2017-06-15 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:57:59 --> Email Class Initialized
INFO - 2017-06-15 13:57:59 --> Controller Class Initialized
INFO - 2017-06-15 13:57:59 --> Helper loaded: form_helper
INFO - 2017-06-15 13:57:59 --> Form Validation Class Initialized
INFO - 2017-06-15 13:57:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:57:59 --> Helper loaded: url_helper
INFO - 2017-06-15 13:57:59 --> Model Class Initialized
INFO - 2017-06-15 13:57:59 --> Model Class Initialized
INFO - 2017-06-15 17:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:27:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:27:59 --> Final output sent to browser
DEBUG - 2017-06-15 17:27:59 --> Total execution time: 0.0498
INFO - 2017-06-15 13:58:00 --> Config Class Initialized
INFO - 2017-06-15 13:58:00 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:58:00 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:58:00 --> Utf8 Class Initialized
INFO - 2017-06-15 13:58:00 --> URI Class Initialized
INFO - 2017-06-15 13:58:00 --> Router Class Initialized
INFO - 2017-06-15 13:58:00 --> Output Class Initialized
INFO - 2017-06-15 13:58:00 --> Security Class Initialized
DEBUG - 2017-06-15 13:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:58:00 --> Input Class Initialized
INFO - 2017-06-15 13:58:00 --> Language Class Initialized
INFO - 2017-06-15 13:58:00 --> Loader Class Initialized
INFO - 2017-06-15 13:58:00 --> Helper loaded: common_helper
INFO - 2017-06-15 13:58:00 --> Database Driver Class Initialized
INFO - 2017-06-15 13:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:58:00 --> Email Class Initialized
INFO - 2017-06-15 13:58:00 --> Controller Class Initialized
INFO - 2017-06-15 13:58:00 --> Helper loaded: form_helper
INFO - 2017-06-15 13:58:00 --> Form Validation Class Initialized
INFO - 2017-06-15 13:58:00 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:58:00 --> Helper loaded: url_helper
INFO - 2017-06-15 13:58:00 --> Model Class Initialized
INFO - 2017-06-15 13:58:00 --> Model Class Initialized
INFO - 2017-06-15 13:58:32 --> Config Class Initialized
INFO - 2017-06-15 13:58:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:58:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:58:32 --> Utf8 Class Initialized
INFO - 2017-06-15 13:58:32 --> URI Class Initialized
INFO - 2017-06-15 13:58:32 --> Router Class Initialized
INFO - 2017-06-15 13:58:32 --> Output Class Initialized
INFO - 2017-06-15 13:58:32 --> Security Class Initialized
DEBUG - 2017-06-15 13:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:58:32 --> Input Class Initialized
INFO - 2017-06-15 13:58:32 --> Language Class Initialized
INFO - 2017-06-15 13:58:32 --> Loader Class Initialized
INFO - 2017-06-15 13:58:32 --> Helper loaded: common_helper
INFO - 2017-06-15 13:58:32 --> Database Driver Class Initialized
INFO - 2017-06-15 13:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:58:32 --> Email Class Initialized
INFO - 2017-06-15 13:58:32 --> Controller Class Initialized
INFO - 2017-06-15 13:58:32 --> Helper loaded: form_helper
INFO - 2017-06-15 13:58:32 --> Form Validation Class Initialized
INFO - 2017-06-15 13:58:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:58:32 --> Helper loaded: url_helper
INFO - 2017-06-15 13:58:32 --> Model Class Initialized
INFO - 2017-06-15 13:58:32 --> Model Class Initialized
INFO - 2017-06-15 13:58:33 --> Config Class Initialized
INFO - 2017-06-15 13:58:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:58:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:58:33 --> Utf8 Class Initialized
INFO - 2017-06-15 13:58:33 --> URI Class Initialized
INFO - 2017-06-15 13:58:33 --> Router Class Initialized
INFO - 2017-06-15 13:58:33 --> Output Class Initialized
INFO - 2017-06-15 13:58:33 --> Security Class Initialized
DEBUG - 2017-06-15 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:58:33 --> Input Class Initialized
INFO - 2017-06-15 13:58:33 --> Language Class Initialized
INFO - 2017-06-15 13:58:33 --> Loader Class Initialized
INFO - 2017-06-15 13:58:33 --> Helper loaded: common_helper
INFO - 2017-06-15 13:58:33 --> Database Driver Class Initialized
INFO - 2017-06-15 13:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:58:33 --> Email Class Initialized
INFO - 2017-06-15 13:58:33 --> Controller Class Initialized
INFO - 2017-06-15 13:58:33 --> Helper loaded: form_helper
INFO - 2017-06-15 13:58:33 --> Form Validation Class Initialized
INFO - 2017-06-15 13:58:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:58:33 --> Helper loaded: url_helper
INFO - 2017-06-15 13:58:33 --> Model Class Initialized
INFO - 2017-06-15 13:58:33 --> Model Class Initialized
INFO - 2017-06-15 17:28:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:28:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:28:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:28:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:28:33 --> Final output sent to browser
DEBUG - 2017-06-15 17:28:33 --> Total execution time: 0.0497
INFO - 2017-06-15 13:58:35 --> Config Class Initialized
INFO - 2017-06-15 13:58:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:58:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:58:35 --> Utf8 Class Initialized
INFO - 2017-06-15 13:58:35 --> URI Class Initialized
INFO - 2017-06-15 13:58:35 --> Router Class Initialized
INFO - 2017-06-15 13:58:35 --> Output Class Initialized
INFO - 2017-06-15 13:58:35 --> Security Class Initialized
DEBUG - 2017-06-15 13:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:58:35 --> Input Class Initialized
INFO - 2017-06-15 13:58:35 --> Language Class Initialized
INFO - 2017-06-15 13:58:35 --> Loader Class Initialized
INFO - 2017-06-15 13:58:35 --> Helper loaded: common_helper
INFO - 2017-06-15 13:58:35 --> Database Driver Class Initialized
INFO - 2017-06-15 13:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:58:35 --> Email Class Initialized
INFO - 2017-06-15 13:58:35 --> Controller Class Initialized
INFO - 2017-06-15 13:58:35 --> Helper loaded: form_helper
INFO - 2017-06-15 13:58:35 --> Form Validation Class Initialized
INFO - 2017-06-15 13:58:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:58:35 --> Helper loaded: url_helper
INFO - 2017-06-15 13:58:35 --> Model Class Initialized
INFO - 2017-06-15 13:58:35 --> Model Class Initialized
INFO - 2017-06-15 13:59:20 --> Config Class Initialized
INFO - 2017-06-15 13:59:20 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:59:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:59:20 --> Utf8 Class Initialized
INFO - 2017-06-15 13:59:20 --> URI Class Initialized
INFO - 2017-06-15 13:59:20 --> Router Class Initialized
INFO - 2017-06-15 13:59:20 --> Output Class Initialized
INFO - 2017-06-15 13:59:20 --> Security Class Initialized
DEBUG - 2017-06-15 13:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:59:20 --> Input Class Initialized
INFO - 2017-06-15 13:59:20 --> Language Class Initialized
INFO - 2017-06-15 13:59:20 --> Loader Class Initialized
INFO - 2017-06-15 13:59:20 --> Helper loaded: common_helper
INFO - 2017-06-15 13:59:20 --> Database Driver Class Initialized
INFO - 2017-06-15 13:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:59:20 --> Email Class Initialized
INFO - 2017-06-15 13:59:20 --> Controller Class Initialized
INFO - 2017-06-15 13:59:20 --> Helper loaded: form_helper
INFO - 2017-06-15 13:59:20 --> Form Validation Class Initialized
INFO - 2017-06-15 13:59:20 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:59:20 --> Helper loaded: url_helper
INFO - 2017-06-15 13:59:20 --> Model Class Initialized
INFO - 2017-06-15 13:59:20 --> Model Class Initialized
INFO - 2017-06-15 13:59:31 --> Config Class Initialized
INFO - 2017-06-15 13:59:31 --> Hooks Class Initialized
DEBUG - 2017-06-15 13:59:31 --> UTF-8 Support Enabled
INFO - 2017-06-15 13:59:31 --> Utf8 Class Initialized
INFO - 2017-06-15 13:59:31 --> URI Class Initialized
INFO - 2017-06-15 13:59:31 --> Router Class Initialized
INFO - 2017-06-15 13:59:31 --> Output Class Initialized
INFO - 2017-06-15 13:59:31 --> Security Class Initialized
DEBUG - 2017-06-15 13:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 13:59:31 --> Input Class Initialized
INFO - 2017-06-15 13:59:31 --> Language Class Initialized
INFO - 2017-06-15 13:59:31 --> Loader Class Initialized
INFO - 2017-06-15 13:59:31 --> Helper loaded: common_helper
INFO - 2017-06-15 13:59:31 --> Database Driver Class Initialized
INFO - 2017-06-15 13:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 13:59:31 --> Email Class Initialized
INFO - 2017-06-15 13:59:31 --> Controller Class Initialized
INFO - 2017-06-15 13:59:31 --> Helper loaded: form_helper
INFO - 2017-06-15 13:59:31 --> Form Validation Class Initialized
INFO - 2017-06-15 13:59:31 --> Helper loaded: email_helper
DEBUG - 2017-06-15 13:59:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 13:59:31 --> Helper loaded: url_helper
INFO - 2017-06-15 13:59:31 --> Model Class Initialized
INFO - 2017-06-15 13:59:31 --> Model Class Initialized
INFO - 2017-06-15 17:29:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:29:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:29:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:29:31 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:29:31 --> Final output sent to browser
DEBUG - 2017-06-15 17:29:31 --> Total execution time: 0.0487
INFO - 2017-06-15 14:01:25 --> Config Class Initialized
INFO - 2017-06-15 14:01:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:01:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:01:25 --> Utf8 Class Initialized
INFO - 2017-06-15 14:01:25 --> URI Class Initialized
INFO - 2017-06-15 14:01:25 --> Router Class Initialized
INFO - 2017-06-15 14:01:25 --> Output Class Initialized
INFO - 2017-06-15 14:01:25 --> Security Class Initialized
DEBUG - 2017-06-15 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:01:25 --> Input Class Initialized
INFO - 2017-06-15 14:01:25 --> Language Class Initialized
INFO - 2017-06-15 14:01:25 --> Loader Class Initialized
INFO - 2017-06-15 14:01:25 --> Helper loaded: common_helper
INFO - 2017-06-15 14:01:25 --> Database Driver Class Initialized
INFO - 2017-06-15 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:01:25 --> Email Class Initialized
INFO - 2017-06-15 14:01:25 --> Controller Class Initialized
INFO - 2017-06-15 14:01:25 --> Helper loaded: form_helper
INFO - 2017-06-15 14:01:25 --> Form Validation Class Initialized
INFO - 2017-06-15 14:01:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:01:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:01:25 --> Helper loaded: url_helper
INFO - 2017-06-15 14:01:25 --> Model Class Initialized
INFO - 2017-06-15 14:01:25 --> Model Class Initialized
INFO - 2017-06-15 17:31:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:31:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:31:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:31:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:31:25 --> Final output sent to browser
DEBUG - 2017-06-15 17:31:25 --> Total execution time: 0.0582
INFO - 2017-06-15 14:01:27 --> Config Class Initialized
INFO - 2017-06-15 14:01:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:01:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:01:27 --> Utf8 Class Initialized
INFO - 2017-06-15 14:01:27 --> URI Class Initialized
INFO - 2017-06-15 14:01:27 --> Router Class Initialized
INFO - 2017-06-15 14:01:27 --> Output Class Initialized
INFO - 2017-06-15 14:01:27 --> Security Class Initialized
DEBUG - 2017-06-15 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:01:27 --> Input Class Initialized
INFO - 2017-06-15 14:01:27 --> Language Class Initialized
INFO - 2017-06-15 14:01:27 --> Loader Class Initialized
INFO - 2017-06-15 14:01:27 --> Helper loaded: common_helper
INFO - 2017-06-15 14:01:27 --> Database Driver Class Initialized
INFO - 2017-06-15 14:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:01:27 --> Email Class Initialized
INFO - 2017-06-15 14:01:27 --> Controller Class Initialized
DEBUG - 2017-06-15 14:01:27 --> Config file loaded: C:\xampp\htdocs\bloodApp\application\config/rest.php
INFO - 2017-06-15 14:01:27 --> Helper loaded: inflector_helper
INFO - 2017-06-15 14:01:27 --> Database Driver Class Initialized
INFO - 2017-06-15 14:01:27 --> Model Class Initialized
INFO - 2017-06-15 14:01:27 --> Model Class Initialized
INFO - 2017-06-15 14:01:27 --> Helper loaded: url_helper
ERROR - 2017-06-15 17:31:27 --> Query error: Table 'blooddonation.logs' doesn't exist - Invalid query: UPDATE `logs` SET `rtime` = 0.079994916915894
WHERE `id` = ''
INFO - 2017-06-15 14:01:55 --> Config Class Initialized
INFO - 2017-06-15 14:01:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:01:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:01:55 --> Utf8 Class Initialized
INFO - 2017-06-15 14:01:55 --> URI Class Initialized
INFO - 2017-06-15 14:01:55 --> Router Class Initialized
INFO - 2017-06-15 14:01:55 --> Output Class Initialized
INFO - 2017-06-15 14:01:55 --> Security Class Initialized
DEBUG - 2017-06-15 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:01:55 --> Input Class Initialized
INFO - 2017-06-15 14:01:55 --> Language Class Initialized
INFO - 2017-06-15 14:01:55 --> Loader Class Initialized
INFO - 2017-06-15 14:01:55 --> Helper loaded: common_helper
INFO - 2017-06-15 14:01:55 --> Database Driver Class Initialized
INFO - 2017-06-15 14:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:01:55 --> Email Class Initialized
INFO - 2017-06-15 14:01:55 --> Controller Class Initialized
INFO - 2017-06-15 14:01:55 --> Helper loaded: form_helper
INFO - 2017-06-15 14:01:55 --> Form Validation Class Initialized
INFO - 2017-06-15 14:01:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:01:55 --> Helper loaded: url_helper
INFO - 2017-06-15 14:01:55 --> Model Class Initialized
INFO - 2017-06-15 14:01:55 --> Model Class Initialized
INFO - 2017-06-15 14:02:02 --> Config Class Initialized
INFO - 2017-06-15 14:02:02 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:02:02 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:02:02 --> Utf8 Class Initialized
INFO - 2017-06-15 14:02:02 --> URI Class Initialized
INFO - 2017-06-15 14:02:02 --> Router Class Initialized
INFO - 2017-06-15 14:02:02 --> Output Class Initialized
INFO - 2017-06-15 14:02:02 --> Security Class Initialized
DEBUG - 2017-06-15 14:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:02:02 --> Input Class Initialized
INFO - 2017-06-15 14:02:02 --> Language Class Initialized
INFO - 2017-06-15 14:02:02 --> Loader Class Initialized
INFO - 2017-06-15 14:02:02 --> Helper loaded: common_helper
INFO - 2017-06-15 14:02:02 --> Database Driver Class Initialized
INFO - 2017-06-15 14:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:02:02 --> Email Class Initialized
INFO - 2017-06-15 14:02:02 --> Controller Class Initialized
INFO - 2017-06-15 14:02:02 --> Helper loaded: form_helper
INFO - 2017-06-15 14:02:02 --> Form Validation Class Initialized
INFO - 2017-06-15 14:02:02 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:02:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:02:02 --> Helper loaded: url_helper
INFO - 2017-06-15 14:02:02 --> Model Class Initialized
INFO - 2017-06-15 14:02:02 --> Model Class Initialized
INFO - 2017-06-15 17:32:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 17:32:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 17:32:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 17:32:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 17:32:02 --> Final output sent to browser
DEBUG - 2017-06-15 17:32:02 --> Total execution time: 0.0491
INFO - 2017-06-15 14:02:04 --> Config Class Initialized
INFO - 2017-06-15 14:02:04 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:02:04 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:02:04 --> Utf8 Class Initialized
INFO - 2017-06-15 14:02:04 --> URI Class Initialized
DEBUG - 2017-06-15 14:02:04 --> No URI present. Default controller set.
INFO - 2017-06-15 14:02:04 --> Router Class Initialized
INFO - 2017-06-15 14:02:04 --> Output Class Initialized
INFO - 2017-06-15 14:02:04 --> Security Class Initialized
DEBUG - 2017-06-15 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:02:04 --> Input Class Initialized
INFO - 2017-06-15 14:02:04 --> Language Class Initialized
INFO - 2017-06-15 14:02:04 --> Loader Class Initialized
INFO - 2017-06-15 14:02:04 --> Helper loaded: common_helper
INFO - 2017-06-15 14:02:04 --> Database Driver Class Initialized
INFO - 2017-06-15 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:02:04 --> Email Class Initialized
INFO - 2017-06-15 14:02:04 --> Controller Class Initialized
INFO - 2017-06-15 14:02:04 --> Helper loaded: form_helper
INFO - 2017-06-15 14:02:04 --> Form Validation Class Initialized
INFO - 2017-06-15 14:02:04 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:02:04 --> Helper loaded: url_helper
INFO - 2017-06-15 14:02:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:02:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:02:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:02:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:02:04 --> Final output sent to browser
DEBUG - 2017-06-15 14:02:04 --> Total execution time: 0.0426
INFO - 2017-06-15 14:02:07 --> Config Class Initialized
INFO - 2017-06-15 14:02:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:02:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:02:07 --> Utf8 Class Initialized
INFO - 2017-06-15 14:02:07 --> URI Class Initialized
INFO - 2017-06-15 14:02:07 --> Router Class Initialized
INFO - 2017-06-15 14:02:07 --> Output Class Initialized
INFO - 2017-06-15 14:02:07 --> Security Class Initialized
DEBUG - 2017-06-15 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:02:07 --> Input Class Initialized
INFO - 2017-06-15 14:02:07 --> Language Class Initialized
INFO - 2017-06-15 14:02:07 --> Loader Class Initialized
INFO - 2017-06-15 14:02:07 --> Helper loaded: common_helper
INFO - 2017-06-15 14:02:07 --> Database Driver Class Initialized
INFO - 2017-06-15 14:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:02:07 --> Email Class Initialized
INFO - 2017-06-15 14:02:07 --> Controller Class Initialized
INFO - 2017-06-15 14:02:07 --> Helper loaded: form_helper
INFO - 2017-06-15 14:02:07 --> Form Validation Class Initialized
INFO - 2017-06-15 14:02:07 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:02:07 --> Helper loaded: url_helper
INFO - 2017-06-15 14:02:07 --> Model Class Initialized
INFO - 2017-06-15 14:02:07 --> Model Class Initialized
INFO - 2017-06-15 14:02:09 --> Config Class Initialized
INFO - 2017-06-15 14:02:09 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:02:09 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:02:09 --> Utf8 Class Initialized
INFO - 2017-06-15 14:02:09 --> URI Class Initialized
DEBUG - 2017-06-15 14:02:09 --> No URI present. Default controller set.
INFO - 2017-06-15 14:02:09 --> Router Class Initialized
INFO - 2017-06-15 14:02:09 --> Output Class Initialized
INFO - 2017-06-15 14:02:09 --> Security Class Initialized
DEBUG - 2017-06-15 14:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:02:09 --> Input Class Initialized
INFO - 2017-06-15 14:02:09 --> Language Class Initialized
INFO - 2017-06-15 14:02:09 --> Loader Class Initialized
INFO - 2017-06-15 14:02:09 --> Helper loaded: common_helper
INFO - 2017-06-15 14:02:09 --> Database Driver Class Initialized
INFO - 2017-06-15 14:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:02:09 --> Email Class Initialized
INFO - 2017-06-15 14:02:09 --> Controller Class Initialized
INFO - 2017-06-15 14:02:09 --> Helper loaded: form_helper
INFO - 2017-06-15 14:02:09 --> Form Validation Class Initialized
INFO - 2017-06-15 14:02:09 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:02:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:02:09 --> Helper loaded: url_helper
INFO - 2017-06-15 14:02:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:02:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:02:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:02:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:02:09 --> Final output sent to browser
DEBUG - 2017-06-15 14:02:09 --> Total execution time: 0.0487
INFO - 2017-06-15 14:06:54 --> Config Class Initialized
INFO - 2017-06-15 14:06:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:06:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:06:54 --> Utf8 Class Initialized
INFO - 2017-06-15 14:06:54 --> URI Class Initialized
DEBUG - 2017-06-15 14:06:54 --> No URI present. Default controller set.
INFO - 2017-06-15 14:06:54 --> Router Class Initialized
INFO - 2017-06-15 14:06:54 --> Output Class Initialized
INFO - 2017-06-15 14:06:54 --> Security Class Initialized
DEBUG - 2017-06-15 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:06:54 --> Input Class Initialized
INFO - 2017-06-15 14:06:54 --> Language Class Initialized
INFO - 2017-06-15 14:06:54 --> Loader Class Initialized
INFO - 2017-06-15 14:06:54 --> Helper loaded: common_helper
INFO - 2017-06-15 14:06:54 --> Database Driver Class Initialized
INFO - 2017-06-15 14:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:06:54 --> Email Class Initialized
INFO - 2017-06-15 14:06:54 --> Controller Class Initialized
INFO - 2017-06-15 14:06:54 --> Helper loaded: form_helper
INFO - 2017-06-15 14:06:54 --> Form Validation Class Initialized
INFO - 2017-06-15 14:06:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:06:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:06:54 --> Helper loaded: url_helper
INFO - 2017-06-15 14:06:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:06:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:06:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:06:54 --> Final output sent to browser
DEBUG - 2017-06-15 14:06:54 --> Total execution time: 0.0446
INFO - 2017-06-15 14:06:54 --> Config Class Initialized
INFO - 2017-06-15 14:06:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:06:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:06:54 --> Utf8 Class Initialized
INFO - 2017-06-15 14:06:54 --> URI Class Initialized
INFO - 2017-06-15 14:06:54 --> Router Class Initialized
INFO - 2017-06-15 14:06:54 --> Output Class Initialized
INFO - 2017-06-15 14:06:54 --> Security Class Initialized
DEBUG - 2017-06-15 14:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:06:54 --> Input Class Initialized
INFO - 2017-06-15 14:06:54 --> Language Class Initialized
ERROR - 2017-06-15 14:06:54 --> 404 Page Not Found: Images/login_logo.png
INFO - 2017-06-15 14:07:33 --> Config Class Initialized
INFO - 2017-06-15 14:07:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:07:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:07:33 --> Utf8 Class Initialized
INFO - 2017-06-15 14:07:33 --> URI Class Initialized
DEBUG - 2017-06-15 14:07:33 --> No URI present. Default controller set.
INFO - 2017-06-15 14:07:33 --> Router Class Initialized
INFO - 2017-06-15 14:07:33 --> Output Class Initialized
INFO - 2017-06-15 14:07:33 --> Security Class Initialized
DEBUG - 2017-06-15 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:07:33 --> Input Class Initialized
INFO - 2017-06-15 14:07:33 --> Language Class Initialized
INFO - 2017-06-15 14:07:33 --> Loader Class Initialized
INFO - 2017-06-15 14:07:33 --> Helper loaded: common_helper
INFO - 2017-06-15 14:07:33 --> Database Driver Class Initialized
INFO - 2017-06-15 14:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:07:33 --> Email Class Initialized
INFO - 2017-06-15 14:07:33 --> Controller Class Initialized
INFO - 2017-06-15 14:07:33 --> Helper loaded: form_helper
INFO - 2017-06-15 14:07:33 --> Form Validation Class Initialized
INFO - 2017-06-15 14:07:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:07:33 --> Helper loaded: url_helper
INFO - 2017-06-15 14:07:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:07:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:07:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:07:33 --> Final output sent to browser
DEBUG - 2017-06-15 14:07:33 --> Total execution time: 0.0438
INFO - 2017-06-15 14:07:33 --> Config Class Initialized
INFO - 2017-06-15 14:07:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:07:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:07:33 --> Utf8 Class Initialized
INFO - 2017-06-15 14:07:33 --> URI Class Initialized
INFO - 2017-06-15 14:07:33 --> Router Class Initialized
INFO - 2017-06-15 14:07:33 --> Output Class Initialized
INFO - 2017-06-15 14:07:33 --> Security Class Initialized
DEBUG - 2017-06-15 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:07:33 --> Input Class Initialized
INFO - 2017-06-15 14:07:33 --> Language Class Initialized
ERROR - 2017-06-15 14:07:33 --> 404 Page Not Found: Images/login_logo.png
INFO - 2017-06-15 14:07:41 --> Config Class Initialized
INFO - 2017-06-15 14:07:41 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:07:41 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:07:41 --> Utf8 Class Initialized
INFO - 2017-06-15 14:07:41 --> URI Class Initialized
DEBUG - 2017-06-15 14:07:41 --> No URI present. Default controller set.
INFO - 2017-06-15 14:07:41 --> Router Class Initialized
INFO - 2017-06-15 14:07:41 --> Output Class Initialized
INFO - 2017-06-15 14:07:41 --> Security Class Initialized
DEBUG - 2017-06-15 14:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:07:41 --> Input Class Initialized
INFO - 2017-06-15 14:07:41 --> Language Class Initialized
INFO - 2017-06-15 14:07:41 --> Loader Class Initialized
INFO - 2017-06-15 14:07:41 --> Helper loaded: common_helper
INFO - 2017-06-15 14:07:41 --> Database Driver Class Initialized
INFO - 2017-06-15 14:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:07:41 --> Email Class Initialized
INFO - 2017-06-15 14:07:41 --> Controller Class Initialized
INFO - 2017-06-15 14:07:41 --> Helper loaded: form_helper
INFO - 2017-06-15 14:07:41 --> Form Validation Class Initialized
INFO - 2017-06-15 14:07:41 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:07:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:07:41 --> Helper loaded: url_helper
INFO - 2017-06-15 14:07:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:07:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:07:41 --> Final output sent to browser
DEBUG - 2017-06-15 14:07:41 --> Total execution time: 0.0408
INFO - 2017-06-15 14:07:41 --> Config Class Initialized
INFO - 2017-06-15 14:07:41 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:07:41 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:07:41 --> Utf8 Class Initialized
INFO - 2017-06-15 14:07:41 --> URI Class Initialized
INFO - 2017-06-15 14:07:41 --> Router Class Initialized
INFO - 2017-06-15 14:07:41 --> Output Class Initialized
INFO - 2017-06-15 14:07:41 --> Security Class Initialized
DEBUG - 2017-06-15 14:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:07:41 --> Input Class Initialized
INFO - 2017-06-15 14:07:41 --> Language Class Initialized
ERROR - 2017-06-15 14:07:41 --> 404 Page Not Found: Images/login_logo.png
INFO - 2017-06-15 14:08:15 --> Config Class Initialized
INFO - 2017-06-15 14:08:15 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:08:15 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:08:15 --> Utf8 Class Initialized
INFO - 2017-06-15 14:08:15 --> URI Class Initialized
DEBUG - 2017-06-15 14:08:15 --> No URI present. Default controller set.
INFO - 2017-06-15 14:08:15 --> Router Class Initialized
INFO - 2017-06-15 14:08:15 --> Output Class Initialized
INFO - 2017-06-15 14:08:15 --> Security Class Initialized
DEBUG - 2017-06-15 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:08:15 --> Input Class Initialized
INFO - 2017-06-15 14:08:15 --> Language Class Initialized
INFO - 2017-06-15 14:08:15 --> Loader Class Initialized
INFO - 2017-06-15 14:08:15 --> Helper loaded: common_helper
INFO - 2017-06-15 14:08:15 --> Database Driver Class Initialized
INFO - 2017-06-15 14:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:08:15 --> Email Class Initialized
INFO - 2017-06-15 14:08:15 --> Controller Class Initialized
INFO - 2017-06-15 14:08:15 --> Helper loaded: form_helper
INFO - 2017-06-15 14:08:15 --> Form Validation Class Initialized
INFO - 2017-06-15 14:08:15 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:08:15 --> Helper loaded: url_helper
INFO - 2017-06-15 14:08:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:08:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:08:15 --> Final output sent to browser
DEBUG - 2017-06-15 14:08:15 --> Total execution time: 0.0498
INFO - 2017-06-15 14:08:47 --> Config Class Initialized
INFO - 2017-06-15 14:08:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:08:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:08:47 --> Utf8 Class Initialized
INFO - 2017-06-15 14:08:47 --> URI Class Initialized
INFO - 2017-06-15 14:08:47 --> Router Class Initialized
INFO - 2017-06-15 14:08:47 --> Output Class Initialized
INFO - 2017-06-15 14:08:47 --> Security Class Initialized
DEBUG - 2017-06-15 14:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:08:47 --> Input Class Initialized
INFO - 2017-06-15 14:08:47 --> Language Class Initialized
ERROR - 2017-06-15 14:08:47 --> 404 Page Not Found: Indexhtml/index
INFO - 2017-06-15 14:08:49 --> Config Class Initialized
INFO - 2017-06-15 14:08:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:08:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:08:49 --> Utf8 Class Initialized
INFO - 2017-06-15 14:08:49 --> URI Class Initialized
DEBUG - 2017-06-15 14:08:49 --> No URI present. Default controller set.
INFO - 2017-06-15 14:08:49 --> Router Class Initialized
INFO - 2017-06-15 14:08:49 --> Output Class Initialized
INFO - 2017-06-15 14:08:49 --> Security Class Initialized
DEBUG - 2017-06-15 14:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:08:49 --> Input Class Initialized
INFO - 2017-06-15 14:08:49 --> Language Class Initialized
INFO - 2017-06-15 14:08:49 --> Loader Class Initialized
INFO - 2017-06-15 14:08:49 --> Helper loaded: common_helper
INFO - 2017-06-15 14:08:49 --> Database Driver Class Initialized
INFO - 2017-06-15 14:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:08:49 --> Email Class Initialized
INFO - 2017-06-15 14:08:49 --> Controller Class Initialized
INFO - 2017-06-15 14:08:49 --> Helper loaded: form_helper
INFO - 2017-06-15 14:08:49 --> Form Validation Class Initialized
INFO - 2017-06-15 14:08:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:08:49 --> Helper loaded: url_helper
INFO - 2017-06-15 14:08:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:08:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:08:49 --> Final output sent to browser
DEBUG - 2017-06-15 14:08:49 --> Total execution time: 0.0397
INFO - 2017-06-15 14:11:48 --> Config Class Initialized
INFO - 2017-06-15 14:11:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:11:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:11:48 --> Utf8 Class Initialized
INFO - 2017-06-15 14:11:48 --> URI Class Initialized
DEBUG - 2017-06-15 14:11:48 --> No URI present. Default controller set.
INFO - 2017-06-15 14:11:48 --> Router Class Initialized
INFO - 2017-06-15 14:11:48 --> Output Class Initialized
INFO - 2017-06-15 14:11:48 --> Security Class Initialized
DEBUG - 2017-06-15 14:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:11:48 --> Input Class Initialized
INFO - 2017-06-15 14:11:48 --> Language Class Initialized
INFO - 2017-06-15 14:11:48 --> Loader Class Initialized
INFO - 2017-06-15 14:11:48 --> Helper loaded: common_helper
INFO - 2017-06-15 14:11:48 --> Database Driver Class Initialized
INFO - 2017-06-15 14:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:11:48 --> Email Class Initialized
INFO - 2017-06-15 14:11:48 --> Controller Class Initialized
INFO - 2017-06-15 14:11:48 --> Helper loaded: form_helper
INFO - 2017-06-15 14:11:48 --> Form Validation Class Initialized
INFO - 2017-06-15 14:11:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:11:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:11:48 --> Helper loaded: url_helper
INFO - 2017-06-15 14:11:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:11:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:11:48 --> Final output sent to browser
DEBUG - 2017-06-15 14:11:48 --> Total execution time: 0.0435
INFO - 2017-06-15 14:16:34 --> Config Class Initialized
INFO - 2017-06-15 14:16:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:16:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:16:34 --> Utf8 Class Initialized
INFO - 2017-06-15 14:16:34 --> URI Class Initialized
DEBUG - 2017-06-15 14:16:34 --> No URI present. Default controller set.
INFO - 2017-06-15 14:16:34 --> Router Class Initialized
INFO - 2017-06-15 14:16:34 --> Output Class Initialized
INFO - 2017-06-15 14:16:34 --> Security Class Initialized
DEBUG - 2017-06-15 14:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:16:34 --> Input Class Initialized
INFO - 2017-06-15 14:16:34 --> Language Class Initialized
INFO - 2017-06-15 14:16:34 --> Loader Class Initialized
INFO - 2017-06-15 14:16:34 --> Helper loaded: common_helper
INFO - 2017-06-15 14:16:34 --> Database Driver Class Initialized
INFO - 2017-06-15 14:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:16:34 --> Email Class Initialized
INFO - 2017-06-15 14:16:34 --> Controller Class Initialized
INFO - 2017-06-15 14:16:34 --> Helper loaded: form_helper
INFO - 2017-06-15 14:16:34 --> Form Validation Class Initialized
INFO - 2017-06-15 14:16:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:16:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:16:34 --> Helper loaded: url_helper
INFO - 2017-06-15 14:16:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:16:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:16:34 --> Final output sent to browser
DEBUG - 2017-06-15 14:16:34 --> Total execution time: 0.0480
INFO - 2017-06-15 14:19:37 --> Config Class Initialized
INFO - 2017-06-15 14:19:37 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:19:37 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:19:37 --> Utf8 Class Initialized
INFO - 2017-06-15 14:19:37 --> URI Class Initialized
DEBUG - 2017-06-15 14:19:37 --> No URI present. Default controller set.
INFO - 2017-06-15 14:19:37 --> Router Class Initialized
INFO - 2017-06-15 14:19:37 --> Output Class Initialized
INFO - 2017-06-15 14:19:37 --> Security Class Initialized
DEBUG - 2017-06-15 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:19:37 --> Input Class Initialized
INFO - 2017-06-15 14:19:37 --> Language Class Initialized
INFO - 2017-06-15 14:19:37 --> Loader Class Initialized
INFO - 2017-06-15 14:19:37 --> Helper loaded: common_helper
INFO - 2017-06-15 14:19:37 --> Database Driver Class Initialized
INFO - 2017-06-15 14:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:19:37 --> Email Class Initialized
INFO - 2017-06-15 14:19:37 --> Controller Class Initialized
INFO - 2017-06-15 14:19:37 --> Helper loaded: form_helper
INFO - 2017-06-15 14:19:37 --> Form Validation Class Initialized
INFO - 2017-06-15 14:19:37 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:19:37 --> Helper loaded: url_helper
INFO - 2017-06-15 14:19:37 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:19:37 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:19:37 --> Final output sent to browser
DEBUG - 2017-06-15 14:19:37 --> Total execution time: 0.0430
INFO - 2017-06-15 14:19:49 --> Config Class Initialized
INFO - 2017-06-15 14:19:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:19:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:19:49 --> Utf8 Class Initialized
INFO - 2017-06-15 14:19:49 --> URI Class Initialized
DEBUG - 2017-06-15 14:19:49 --> No URI present. Default controller set.
INFO - 2017-06-15 14:19:49 --> Router Class Initialized
INFO - 2017-06-15 14:19:49 --> Output Class Initialized
INFO - 2017-06-15 14:19:49 --> Security Class Initialized
DEBUG - 2017-06-15 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:19:49 --> Input Class Initialized
INFO - 2017-06-15 14:19:49 --> Language Class Initialized
INFO - 2017-06-15 14:19:49 --> Loader Class Initialized
INFO - 2017-06-15 14:19:49 --> Helper loaded: common_helper
INFO - 2017-06-15 14:19:49 --> Database Driver Class Initialized
INFO - 2017-06-15 14:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:19:49 --> Email Class Initialized
INFO - 2017-06-15 14:19:49 --> Controller Class Initialized
INFO - 2017-06-15 14:19:49 --> Helper loaded: form_helper
INFO - 2017-06-15 14:19:49 --> Form Validation Class Initialized
INFO - 2017-06-15 14:19:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:19:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:19:49 --> Helper loaded: url_helper
INFO - 2017-06-15 14:19:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:19:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:19:49 --> Final output sent to browser
DEBUG - 2017-06-15 14:19:49 --> Total execution time: 0.0459
INFO - 2017-06-15 14:20:00 --> Config Class Initialized
INFO - 2017-06-15 14:20:00 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:00 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:00 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:00 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:00 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:00 --> Router Class Initialized
INFO - 2017-06-15 14:20:00 --> Output Class Initialized
INFO - 2017-06-15 14:20:00 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:00 --> Input Class Initialized
INFO - 2017-06-15 14:20:00 --> Language Class Initialized
INFO - 2017-06-15 14:20:00 --> Loader Class Initialized
INFO - 2017-06-15 14:20:00 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:00 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:00 --> Email Class Initialized
INFO - 2017-06-15 14:20:00 --> Controller Class Initialized
INFO - 2017-06-15 14:20:00 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:00 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:00 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:00 --> Helper loaded: url_helper
INFO - 2017-06-15 14:20:00 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:20:00 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:20:00 --> Final output sent to browser
DEBUG - 2017-06-15 14:20:00 --> Total execution time: 0.0461
INFO - 2017-06-15 14:20:01 --> Config Class Initialized
INFO - 2017-06-15 14:20:01 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:01 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:01 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:01 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:01 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:01 --> Router Class Initialized
INFO - 2017-06-15 14:20:01 --> Output Class Initialized
INFO - 2017-06-15 14:20:01 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:01 --> Input Class Initialized
INFO - 2017-06-15 14:20:01 --> Language Class Initialized
INFO - 2017-06-15 14:20:01 --> Loader Class Initialized
INFO - 2017-06-15 14:20:01 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:01 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:01 --> Email Class Initialized
INFO - 2017-06-15 14:20:01 --> Controller Class Initialized
INFO - 2017-06-15 14:20:01 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:01 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:01 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:01 --> Helper loaded: url_helper
DEBUG - 2017-06-15 14:20:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 14:20:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:20:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:20:01 --> Final output sent to browser
DEBUG - 2017-06-15 14:20:01 --> Total execution time: 0.0617
INFO - 2017-06-15 14:20:38 --> Config Class Initialized
INFO - 2017-06-15 14:20:38 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:38 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:38 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:38 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:38 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:38 --> Router Class Initialized
INFO - 2017-06-15 14:20:38 --> Output Class Initialized
INFO - 2017-06-15 14:20:38 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:38 --> Input Class Initialized
INFO - 2017-06-15 14:20:38 --> Language Class Initialized
INFO - 2017-06-15 14:20:38 --> Loader Class Initialized
INFO - 2017-06-15 14:20:38 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:38 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:38 --> Email Class Initialized
INFO - 2017-06-15 14:20:38 --> Controller Class Initialized
INFO - 2017-06-15 14:20:38 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:38 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:38 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:38 --> Helper loaded: url_helper
INFO - 2017-06-15 14:20:40 --> Config Class Initialized
INFO - 2017-06-15 14:20:40 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:40 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:40 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:40 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:40 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:40 --> Router Class Initialized
INFO - 2017-06-15 14:20:40 --> Output Class Initialized
INFO - 2017-06-15 14:20:40 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:40 --> Input Class Initialized
INFO - 2017-06-15 14:20:40 --> Language Class Initialized
INFO - 2017-06-15 14:20:40 --> Loader Class Initialized
INFO - 2017-06-15 14:20:40 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:40 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:40 --> Email Class Initialized
INFO - 2017-06-15 14:20:40 --> Controller Class Initialized
INFO - 2017-06-15 14:20:40 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:40 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:40 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:40 --> Helper loaded: url_helper
INFO - 2017-06-15 14:20:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:20:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:20:40 --> Final output sent to browser
DEBUG - 2017-06-15 14:20:40 --> Total execution time: 0.0382
INFO - 2017-06-15 14:20:47 --> Config Class Initialized
INFO - 2017-06-15 14:20:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:47 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:47 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:47 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:47 --> Router Class Initialized
INFO - 2017-06-15 14:20:47 --> Output Class Initialized
INFO - 2017-06-15 14:20:47 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:47 --> Input Class Initialized
INFO - 2017-06-15 14:20:47 --> Language Class Initialized
INFO - 2017-06-15 14:20:47 --> Loader Class Initialized
INFO - 2017-06-15 14:20:47 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:47 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:47 --> Email Class Initialized
INFO - 2017-06-15 14:20:47 --> Controller Class Initialized
INFO - 2017-06-15 14:20:47 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:47 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:47 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:47 --> Helper loaded: url_helper
INFO - 2017-06-15 14:20:52 --> Config Class Initialized
INFO - 2017-06-15 14:20:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:52 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:52 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:52 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:52 --> Router Class Initialized
INFO - 2017-06-15 14:20:52 --> Output Class Initialized
INFO - 2017-06-15 14:20:52 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:52 --> Input Class Initialized
INFO - 2017-06-15 14:20:52 --> Language Class Initialized
INFO - 2017-06-15 14:20:52 --> Loader Class Initialized
INFO - 2017-06-15 14:20:52 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:52 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:52 --> Email Class Initialized
INFO - 2017-06-15 14:20:52 --> Controller Class Initialized
INFO - 2017-06-15 14:20:52 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:52 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:52 --> Helper loaded: url_helper
INFO - 2017-06-15 14:20:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:20:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:20:52 --> Final output sent to browser
DEBUG - 2017-06-15 14:20:52 --> Total execution time: 0.0420
INFO - 2017-06-15 14:20:56 --> Config Class Initialized
INFO - 2017-06-15 14:20:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:20:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:20:56 --> Utf8 Class Initialized
INFO - 2017-06-15 14:20:56 --> URI Class Initialized
DEBUG - 2017-06-15 14:20:56 --> No URI present. Default controller set.
INFO - 2017-06-15 14:20:56 --> Router Class Initialized
INFO - 2017-06-15 14:20:56 --> Output Class Initialized
INFO - 2017-06-15 14:20:56 --> Security Class Initialized
DEBUG - 2017-06-15 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:20:56 --> Input Class Initialized
INFO - 2017-06-15 14:20:56 --> Language Class Initialized
INFO - 2017-06-15 14:20:56 --> Loader Class Initialized
INFO - 2017-06-15 14:20:56 --> Helper loaded: common_helper
INFO - 2017-06-15 14:20:56 --> Database Driver Class Initialized
INFO - 2017-06-15 14:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:20:56 --> Email Class Initialized
INFO - 2017-06-15 14:20:56 --> Controller Class Initialized
INFO - 2017-06-15 14:20:57 --> Helper loaded: form_helper
INFO - 2017-06-15 14:20:57 --> Form Validation Class Initialized
INFO - 2017-06-15 14:20:57 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:20:57 --> Helper loaded: url_helper
INFO - 2017-06-15 14:22:05 --> Config Class Initialized
INFO - 2017-06-15 14:22:05 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:22:05 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:22:05 --> Utf8 Class Initialized
INFO - 2017-06-15 14:22:05 --> URI Class Initialized
DEBUG - 2017-06-15 14:22:05 --> No URI present. Default controller set.
INFO - 2017-06-15 14:22:05 --> Router Class Initialized
INFO - 2017-06-15 14:22:05 --> Output Class Initialized
INFO - 2017-06-15 14:22:05 --> Security Class Initialized
DEBUG - 2017-06-15 14:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:22:05 --> Input Class Initialized
INFO - 2017-06-15 14:22:05 --> Language Class Initialized
INFO - 2017-06-15 14:22:05 --> Loader Class Initialized
INFO - 2017-06-15 14:22:05 --> Helper loaded: common_helper
INFO - 2017-06-15 14:22:05 --> Database Driver Class Initialized
INFO - 2017-06-15 14:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:22:05 --> Email Class Initialized
INFO - 2017-06-15 14:22:05 --> Controller Class Initialized
INFO - 2017-06-15 14:22:05 --> Helper loaded: form_helper
INFO - 2017-06-15 14:22:05 --> Form Validation Class Initialized
INFO - 2017-06-15 14:22:05 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:22:05 --> Helper loaded: url_helper
INFO - 2017-06-15 14:26:40 --> Config Class Initialized
INFO - 2017-06-15 14:26:40 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:26:40 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:26:40 --> Utf8 Class Initialized
INFO - 2017-06-15 14:26:40 --> URI Class Initialized
DEBUG - 2017-06-15 14:26:40 --> No URI present. Default controller set.
INFO - 2017-06-15 14:26:40 --> Router Class Initialized
INFO - 2017-06-15 14:26:40 --> Output Class Initialized
INFO - 2017-06-15 14:26:40 --> Security Class Initialized
DEBUG - 2017-06-15 14:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:26:40 --> Input Class Initialized
INFO - 2017-06-15 14:26:40 --> Language Class Initialized
INFO - 2017-06-15 14:26:40 --> Loader Class Initialized
INFO - 2017-06-15 14:26:40 --> Helper loaded: common_helper
INFO - 2017-06-15 14:26:40 --> Database Driver Class Initialized
INFO - 2017-06-15 14:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:26:40 --> Email Class Initialized
INFO - 2017-06-15 14:26:40 --> Controller Class Initialized
INFO - 2017-06-15 14:26:40 --> Helper loaded: form_helper
INFO - 2017-06-15 14:26:40 --> Form Validation Class Initialized
INFO - 2017-06-15 14:26:40 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:26:40 --> Helper loaded: url_helper
INFO - 2017-06-15 14:26:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:26:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:26:40 --> Final output sent to browser
DEBUG - 2017-06-15 14:26:40 --> Total execution time: 0.0447
INFO - 2017-06-15 14:28:32 --> Config Class Initialized
INFO - 2017-06-15 14:28:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:28:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:28:32 --> Utf8 Class Initialized
INFO - 2017-06-15 14:28:32 --> URI Class Initialized
DEBUG - 2017-06-15 14:28:32 --> No URI present. Default controller set.
INFO - 2017-06-15 14:28:32 --> Router Class Initialized
INFO - 2017-06-15 14:28:32 --> Output Class Initialized
INFO - 2017-06-15 14:28:32 --> Security Class Initialized
DEBUG - 2017-06-15 14:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:28:32 --> Input Class Initialized
INFO - 2017-06-15 14:28:32 --> Language Class Initialized
INFO - 2017-06-15 14:28:32 --> Loader Class Initialized
INFO - 2017-06-15 14:28:32 --> Helper loaded: common_helper
INFO - 2017-06-15 14:28:32 --> Database Driver Class Initialized
INFO - 2017-06-15 14:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:28:32 --> Email Class Initialized
INFO - 2017-06-15 14:28:32 --> Controller Class Initialized
INFO - 2017-06-15 14:28:32 --> Helper loaded: form_helper
INFO - 2017-06-15 14:28:32 --> Form Validation Class Initialized
INFO - 2017-06-15 14:28:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:28:32 --> Helper loaded: url_helper
INFO - 2017-06-15 14:28:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:28:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:28:32 --> Final output sent to browser
DEBUG - 2017-06-15 14:28:32 --> Total execution time: 0.0427
INFO - 2017-06-15 14:28:51 --> Config Class Initialized
INFO - 2017-06-15 14:28:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:28:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:28:51 --> Utf8 Class Initialized
INFO - 2017-06-15 14:28:51 --> URI Class Initialized
DEBUG - 2017-06-15 14:28:51 --> No URI present. Default controller set.
INFO - 2017-06-15 14:28:51 --> Router Class Initialized
INFO - 2017-06-15 14:28:51 --> Output Class Initialized
INFO - 2017-06-15 14:28:51 --> Security Class Initialized
DEBUG - 2017-06-15 14:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:28:51 --> Input Class Initialized
INFO - 2017-06-15 14:28:51 --> Language Class Initialized
INFO - 2017-06-15 14:28:51 --> Loader Class Initialized
INFO - 2017-06-15 14:28:51 --> Helper loaded: common_helper
INFO - 2017-06-15 14:28:51 --> Database Driver Class Initialized
INFO - 2017-06-15 14:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:28:51 --> Email Class Initialized
INFO - 2017-06-15 14:28:51 --> Controller Class Initialized
INFO - 2017-06-15 14:28:51 --> Helper loaded: form_helper
INFO - 2017-06-15 14:28:51 --> Form Validation Class Initialized
INFO - 2017-06-15 14:28:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:28:51 --> Helper loaded: url_helper
INFO - 2017-06-15 14:29:15 --> Config Class Initialized
INFO - 2017-06-15 14:29:15 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:29:15 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:29:15 --> Utf8 Class Initialized
INFO - 2017-06-15 14:29:15 --> URI Class Initialized
DEBUG - 2017-06-15 14:29:15 --> No URI present. Default controller set.
INFO - 2017-06-15 14:29:15 --> Router Class Initialized
INFO - 2017-06-15 14:29:15 --> Output Class Initialized
INFO - 2017-06-15 14:29:15 --> Security Class Initialized
DEBUG - 2017-06-15 14:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:29:15 --> Input Class Initialized
INFO - 2017-06-15 14:29:15 --> Language Class Initialized
INFO - 2017-06-15 14:29:15 --> Loader Class Initialized
INFO - 2017-06-15 14:29:15 --> Helper loaded: common_helper
INFO - 2017-06-15 14:29:15 --> Database Driver Class Initialized
INFO - 2017-06-15 14:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:29:15 --> Email Class Initialized
INFO - 2017-06-15 14:29:15 --> Controller Class Initialized
INFO - 2017-06-15 14:29:15 --> Helper loaded: form_helper
INFO - 2017-06-15 14:29:15 --> Form Validation Class Initialized
INFO - 2017-06-15 14:29:15 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:29:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:15 --> Helper loaded: url_helper
DEBUG - 2017-06-15 14:29:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-06-15 14:29:15 --> Undefined property: Admin::$Admin_model
ERROR - 2017-06-15 14:29:15 --> Severity: Notice --> Undefined property: Admin::$Admin_model C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 42
ERROR - 2017-06-15 14:29:15 --> Call to a member function login() on a non-object
ERROR - 2017-06-15 14:29:15 --> Severity: Error --> Call to a member function login() on a non-object C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 42
INFO - 2017-06-15 14:29:24 --> Config Class Initialized
INFO - 2017-06-15 14:29:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:29:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:29:24 --> Utf8 Class Initialized
INFO - 2017-06-15 14:29:24 --> URI Class Initialized
DEBUG - 2017-06-15 14:29:24 --> No URI present. Default controller set.
INFO - 2017-06-15 14:29:24 --> Router Class Initialized
INFO - 2017-06-15 14:29:24 --> Output Class Initialized
INFO - 2017-06-15 14:29:24 --> Security Class Initialized
DEBUG - 2017-06-15 14:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:29:24 --> Input Class Initialized
INFO - 2017-06-15 14:29:24 --> Language Class Initialized
INFO - 2017-06-15 14:29:24 --> Loader Class Initialized
INFO - 2017-06-15 14:29:24 --> Helper loaded: common_helper
INFO - 2017-06-15 14:29:24 --> Database Driver Class Initialized
INFO - 2017-06-15 14:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:29:24 --> Email Class Initialized
INFO - 2017-06-15 14:29:24 --> Controller Class Initialized
INFO - 2017-06-15 14:29:24 --> Helper loaded: form_helper
INFO - 2017-06-15 14:29:24 --> Form Validation Class Initialized
INFO - 2017-06-15 14:29:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:24 --> Helper loaded: url_helper
INFO - 2017-06-15 14:29:24 --> Model Class Initialized
INFO - 2017-06-15 14:29:24 --> Model Class Initialized
DEBUG - 2017-06-15 14:29:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 14:29:43 --> Config Class Initialized
INFO - 2017-06-15 14:29:43 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:29:43 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:29:43 --> Utf8 Class Initialized
INFO - 2017-06-15 14:29:43 --> URI Class Initialized
DEBUG - 2017-06-15 14:29:43 --> No URI present. Default controller set.
INFO - 2017-06-15 14:29:43 --> Router Class Initialized
INFO - 2017-06-15 14:29:43 --> Output Class Initialized
INFO - 2017-06-15 14:29:43 --> Security Class Initialized
DEBUG - 2017-06-15 14:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:29:43 --> Input Class Initialized
INFO - 2017-06-15 14:29:43 --> Language Class Initialized
INFO - 2017-06-15 14:29:43 --> Loader Class Initialized
INFO - 2017-06-15 14:29:43 --> Helper loaded: common_helper
INFO - 2017-06-15 14:29:43 --> Database Driver Class Initialized
INFO - 2017-06-15 14:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:29:43 --> Email Class Initialized
INFO - 2017-06-15 14:29:43 --> Controller Class Initialized
INFO - 2017-06-15 14:29:43 --> Helper loaded: form_helper
INFO - 2017-06-15 14:29:43 --> Form Validation Class Initialized
INFO - 2017-06-15 14:29:43 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:43 --> Helper loaded: url_helper
INFO - 2017-06-15 14:29:43 --> Model Class Initialized
INFO - 2017-06-15 14:29:43 --> Model Class Initialized
DEBUG - 2017-06-15 14:29:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-06-15 14:29:43 --> Undefined property: stdClass::$userName
ERROR - 2017-06-15 14:29:43 --> Severity: Notice --> Undefined property: stdClass::$userName C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 141
ERROR - 2017-06-15 14:29:43 --> Undefined property: stdClass::$roleID
ERROR - 2017-06-15 14:29:43 --> Severity: Notice --> Undefined property: stdClass::$roleID C:\xampp\htdocs\bloodApp\application\controllers\Admin.php 143
INFO - 2017-06-15 14:29:43 --> Config Class Initialized
INFO - 2017-06-15 14:29:43 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:29:44 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:29:44 --> Utf8 Class Initialized
INFO - 2017-06-15 14:29:44 --> URI Class Initialized
INFO - 2017-06-15 14:29:44 --> Router Class Initialized
INFO - 2017-06-15 14:29:44 --> Output Class Initialized
INFO - 2017-06-15 14:29:44 --> Security Class Initialized
DEBUG - 2017-06-15 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:29:44 --> Input Class Initialized
INFO - 2017-06-15 14:29:44 --> Language Class Initialized
INFO - 2017-06-15 14:29:44 --> Loader Class Initialized
INFO - 2017-06-15 14:29:44 --> Helper loaded: common_helper
INFO - 2017-06-15 14:29:44 --> Database Driver Class Initialized
INFO - 2017-06-15 14:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:29:44 --> Email Class Initialized
INFO - 2017-06-15 14:29:44 --> Controller Class Initialized
INFO - 2017-06-15 14:29:44 --> Helper loaded: form_helper
INFO - 2017-06-15 14:29:44 --> Form Validation Class Initialized
INFO - 2017-06-15 14:29:44 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:29:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:29:44 --> Helper loaded: url_helper
INFO - 2017-06-15 14:29:44 --> Model Class Initialized
INFO - 2017-06-15 14:29:44 --> Model Class Initialized
INFO - 2017-06-15 14:29:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:29:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:29:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:29:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:29:44 --> Final output sent to browser
DEBUG - 2017-06-15 14:29:44 --> Total execution time: 0.0591
INFO - 2017-06-15 14:32:36 --> Config Class Initialized
INFO - 2017-06-15 14:32:36 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:32:36 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:32:36 --> Utf8 Class Initialized
INFO - 2017-06-15 14:32:36 --> URI Class Initialized
INFO - 2017-06-15 14:32:36 --> Router Class Initialized
INFO - 2017-06-15 14:32:36 --> Output Class Initialized
INFO - 2017-06-15 14:32:36 --> Security Class Initialized
DEBUG - 2017-06-15 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:32:36 --> Input Class Initialized
INFO - 2017-06-15 14:32:36 --> Language Class Initialized
INFO - 2017-06-15 14:32:36 --> Loader Class Initialized
INFO - 2017-06-15 14:32:36 --> Helper loaded: common_helper
INFO - 2017-06-15 14:32:36 --> Database Driver Class Initialized
INFO - 2017-06-15 14:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:32:36 --> Email Class Initialized
INFO - 2017-06-15 14:32:36 --> Controller Class Initialized
INFO - 2017-06-15 14:32:36 --> Helper loaded: form_helper
INFO - 2017-06-15 14:32:36 --> Form Validation Class Initialized
INFO - 2017-06-15 14:32:36 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:32:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:32:36 --> Helper loaded: url_helper
INFO - 2017-06-15 14:32:36 --> Model Class Initialized
INFO - 2017-06-15 14:32:36 --> Model Class Initialized
INFO - 2017-06-15 14:32:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:32:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:32:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:32:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:32:36 --> Final output sent to browser
DEBUG - 2017-06-15 14:32:36 --> Total execution time: 0.0480
INFO - 2017-06-15 14:32:38 --> Config Class Initialized
INFO - 2017-06-15 14:32:38 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:32:38 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:32:38 --> Utf8 Class Initialized
INFO - 2017-06-15 14:32:38 --> URI Class Initialized
INFO - 2017-06-15 14:32:38 --> Router Class Initialized
INFO - 2017-06-15 14:32:38 --> Output Class Initialized
INFO - 2017-06-15 14:32:38 --> Security Class Initialized
DEBUG - 2017-06-15 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:32:38 --> Input Class Initialized
INFO - 2017-06-15 14:32:38 --> Language Class Initialized
INFO - 2017-06-15 14:32:38 --> Loader Class Initialized
INFO - 2017-06-15 14:32:38 --> Helper loaded: common_helper
INFO - 2017-06-15 14:32:38 --> Database Driver Class Initialized
INFO - 2017-06-15 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:32:38 --> Email Class Initialized
INFO - 2017-06-15 14:32:38 --> Controller Class Initialized
INFO - 2017-06-15 14:32:38 --> Helper loaded: form_helper
INFO - 2017-06-15 14:32:38 --> Form Validation Class Initialized
INFO - 2017-06-15 14:32:38 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:32:38 --> Helper loaded: url_helper
INFO - 2017-06-15 14:32:38 --> Model Class Initialized
INFO - 2017-06-15 14:32:38 --> Model Class Initialized
INFO - 2017-06-15 14:32:38 --> Config Class Initialized
INFO - 2017-06-15 14:32:38 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:32:38 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:32:38 --> Utf8 Class Initialized
INFO - 2017-06-15 14:32:38 --> URI Class Initialized
DEBUG - 2017-06-15 14:32:38 --> No URI present. Default controller set.
INFO - 2017-06-15 14:32:38 --> Router Class Initialized
INFO - 2017-06-15 14:32:38 --> Output Class Initialized
INFO - 2017-06-15 14:32:38 --> Security Class Initialized
DEBUG - 2017-06-15 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:32:38 --> Input Class Initialized
INFO - 2017-06-15 14:32:38 --> Language Class Initialized
INFO - 2017-06-15 14:32:38 --> Loader Class Initialized
INFO - 2017-06-15 14:32:38 --> Helper loaded: common_helper
INFO - 2017-06-15 14:32:38 --> Database Driver Class Initialized
INFO - 2017-06-15 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:32:38 --> Email Class Initialized
INFO - 2017-06-15 14:32:38 --> Controller Class Initialized
INFO - 2017-06-15 14:32:38 --> Helper loaded: form_helper
INFO - 2017-06-15 14:32:38 --> Form Validation Class Initialized
INFO - 2017-06-15 14:32:38 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:32:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:32:38 --> Helper loaded: url_helper
INFO - 2017-06-15 14:32:38 --> Model Class Initialized
INFO - 2017-06-15 14:32:38 --> Model Class Initialized
INFO - 2017-06-15 14:32:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:32:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:32:38 --> Final output sent to browser
DEBUG - 2017-06-15 14:32:38 --> Total execution time: 0.0429
INFO - 2017-06-15 14:32:56 --> Config Class Initialized
INFO - 2017-06-15 14:32:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:32:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:32:56 --> Utf8 Class Initialized
INFO - 2017-06-15 14:32:56 --> URI Class Initialized
DEBUG - 2017-06-15 14:32:56 --> No URI present. Default controller set.
INFO - 2017-06-15 14:32:56 --> Router Class Initialized
INFO - 2017-06-15 14:32:56 --> Output Class Initialized
INFO - 2017-06-15 14:32:56 --> Security Class Initialized
DEBUG - 2017-06-15 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:32:56 --> Input Class Initialized
INFO - 2017-06-15 14:32:56 --> Language Class Initialized
INFO - 2017-06-15 14:32:56 --> Loader Class Initialized
INFO - 2017-06-15 14:32:56 --> Helper loaded: common_helper
INFO - 2017-06-15 14:32:56 --> Database Driver Class Initialized
INFO - 2017-06-15 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:32:56 --> Email Class Initialized
INFO - 2017-06-15 14:32:56 --> Controller Class Initialized
INFO - 2017-06-15 14:32:56 --> Helper loaded: form_helper
INFO - 2017-06-15 14:32:56 --> Form Validation Class Initialized
INFO - 2017-06-15 14:32:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:32:56 --> Helper loaded: url_helper
INFO - 2017-06-15 14:32:56 --> Model Class Initialized
INFO - 2017-06-15 14:32:56 --> Model Class Initialized
DEBUG - 2017-06-15 14:32:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:32:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 14:32:57 --> Config Class Initialized
INFO - 2017-06-15 14:32:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:32:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:32:57 --> Utf8 Class Initialized
INFO - 2017-06-15 14:32:57 --> URI Class Initialized
INFO - 2017-06-15 14:32:57 --> Router Class Initialized
INFO - 2017-06-15 14:32:57 --> Output Class Initialized
INFO - 2017-06-15 14:32:57 --> Security Class Initialized
DEBUG - 2017-06-15 14:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:32:57 --> Input Class Initialized
INFO - 2017-06-15 14:32:57 --> Language Class Initialized
INFO - 2017-06-15 14:32:57 --> Loader Class Initialized
INFO - 2017-06-15 14:32:57 --> Helper loaded: common_helper
INFO - 2017-06-15 14:32:57 --> Database Driver Class Initialized
INFO - 2017-06-15 14:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:32:57 --> Email Class Initialized
INFO - 2017-06-15 14:32:57 --> Controller Class Initialized
INFO - 2017-06-15 14:32:57 --> Helper loaded: form_helper
INFO - 2017-06-15 14:32:57 --> Form Validation Class Initialized
INFO - 2017-06-15 14:32:57 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:32:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:32:57 --> Helper loaded: url_helper
INFO - 2017-06-15 14:32:57 --> Model Class Initialized
INFO - 2017-06-15 14:32:57 --> Model Class Initialized
INFO - 2017-06-15 14:32:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:32:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:32:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:32:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:32:57 --> Final output sent to browser
DEBUG - 2017-06-15 14:32:57 --> Total execution time: 0.0559
INFO - 2017-06-15 14:33:01 --> Config Class Initialized
INFO - 2017-06-15 14:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:01 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:01 --> URI Class Initialized
INFO - 2017-06-15 14:33:01 --> Router Class Initialized
INFO - 2017-06-15 14:33:01 --> Output Class Initialized
INFO - 2017-06-15 14:33:01 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:01 --> Input Class Initialized
INFO - 2017-06-15 14:33:01 --> Language Class Initialized
INFO - 2017-06-15 14:33:01 --> Loader Class Initialized
INFO - 2017-06-15 14:33:01 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:01 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:01 --> Email Class Initialized
INFO - 2017-06-15 14:33:01 --> Controller Class Initialized
INFO - 2017-06-15 14:33:01 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:01 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:01 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:01 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:01 --> Model Class Initialized
INFO - 2017-06-15 14:33:01 --> Model Class Initialized
INFO - 2017-06-15 14:33:01 --> Config Class Initialized
INFO - 2017-06-15 14:33:01 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:01 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:01 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:01 --> URI Class Initialized
DEBUG - 2017-06-15 14:33:01 --> No URI present. Default controller set.
INFO - 2017-06-15 14:33:01 --> Router Class Initialized
INFO - 2017-06-15 14:33:01 --> Output Class Initialized
INFO - 2017-06-15 14:33:01 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:01 --> Input Class Initialized
INFO - 2017-06-15 14:33:01 --> Language Class Initialized
INFO - 2017-06-15 14:33:01 --> Loader Class Initialized
INFO - 2017-06-15 14:33:01 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:01 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:01 --> Email Class Initialized
INFO - 2017-06-15 14:33:01 --> Controller Class Initialized
INFO - 2017-06-15 14:33:01 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:01 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:01 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:01 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:01 --> Model Class Initialized
INFO - 2017-06-15 14:33:01 --> Model Class Initialized
INFO - 2017-06-15 14:33:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:33:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:33:01 --> Final output sent to browser
DEBUG - 2017-06-15 14:33:01 --> Total execution time: 0.0428
INFO - 2017-06-15 14:33:03 --> Config Class Initialized
INFO - 2017-06-15 14:33:03 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:03 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:03 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:03 --> URI Class Initialized
DEBUG - 2017-06-15 14:33:03 --> No URI present. Default controller set.
INFO - 2017-06-15 14:33:03 --> Router Class Initialized
INFO - 2017-06-15 14:33:03 --> Output Class Initialized
INFO - 2017-06-15 14:33:03 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:03 --> Input Class Initialized
INFO - 2017-06-15 14:33:03 --> Language Class Initialized
INFO - 2017-06-15 14:33:03 --> Loader Class Initialized
INFO - 2017-06-15 14:33:03 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:03 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:03 --> Email Class Initialized
INFO - 2017-06-15 14:33:03 --> Controller Class Initialized
INFO - 2017-06-15 14:33:03 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:03 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:03 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:03 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:03 --> Model Class Initialized
INFO - 2017-06-15 14:33:03 --> Model Class Initialized
DEBUG - 2017-06-15 14:33:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 14:33:03 --> Config Class Initialized
INFO - 2017-06-15 14:33:03 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:03 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:03 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:03 --> URI Class Initialized
INFO - 2017-06-15 14:33:03 --> Router Class Initialized
INFO - 2017-06-15 14:33:03 --> Output Class Initialized
INFO - 2017-06-15 14:33:03 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:03 --> Input Class Initialized
INFO - 2017-06-15 14:33:03 --> Language Class Initialized
INFO - 2017-06-15 14:33:03 --> Loader Class Initialized
INFO - 2017-06-15 14:33:03 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:03 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:03 --> Email Class Initialized
INFO - 2017-06-15 14:33:03 --> Controller Class Initialized
INFO - 2017-06-15 14:33:03 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:03 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:03 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:03 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:03 --> Model Class Initialized
INFO - 2017-06-15 14:33:03 --> Model Class Initialized
INFO - 2017-06-15 14:33:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:33:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:33:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:33:03 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:33:03 --> Final output sent to browser
DEBUG - 2017-06-15 14:33:03 --> Total execution time: 0.0706
INFO - 2017-06-15 14:33:22 --> Config Class Initialized
INFO - 2017-06-15 14:33:22 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:22 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:22 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:22 --> URI Class Initialized
INFO - 2017-06-15 14:33:22 --> Router Class Initialized
INFO - 2017-06-15 14:33:22 --> Output Class Initialized
INFO - 2017-06-15 14:33:22 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:22 --> Input Class Initialized
INFO - 2017-06-15 14:33:22 --> Language Class Initialized
INFO - 2017-06-15 14:33:22 --> Loader Class Initialized
INFO - 2017-06-15 14:33:22 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:22 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:22 --> Email Class Initialized
INFO - 2017-06-15 14:33:22 --> Controller Class Initialized
INFO - 2017-06-15 14:33:22 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:22 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:22 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:22 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:22 --> Model Class Initialized
INFO - 2017-06-15 14:33:22 --> Model Class Initialized
INFO - 2017-06-15 18:03:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 18:03:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 18:03:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 18:03:22 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 18:03:22 --> Final output sent to browser
DEBUG - 2017-06-15 18:03:22 --> Total execution time: 0.0473
INFO - 2017-06-15 14:33:23 --> Config Class Initialized
INFO - 2017-06-15 14:33:23 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:23 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:23 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:23 --> URI Class Initialized
INFO - 2017-06-15 14:33:23 --> Router Class Initialized
INFO - 2017-06-15 14:33:23 --> Output Class Initialized
INFO - 2017-06-15 14:33:23 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:23 --> Input Class Initialized
INFO - 2017-06-15 14:33:23 --> Language Class Initialized
INFO - 2017-06-15 14:33:23 --> Loader Class Initialized
INFO - 2017-06-15 14:33:23 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:23 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:23 --> Email Class Initialized
INFO - 2017-06-15 14:33:23 --> Controller Class Initialized
INFO - 2017-06-15 14:33:23 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:23 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:23 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:23 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:23 --> Model Class Initialized
INFO - 2017-06-15 14:33:23 --> Model Class Initialized
INFO - 2017-06-15 14:33:24 --> Config Class Initialized
INFO - 2017-06-15 14:33:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:24 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:24 --> URI Class Initialized
INFO - 2017-06-15 14:33:24 --> Router Class Initialized
INFO - 2017-06-15 14:33:24 --> Output Class Initialized
INFO - 2017-06-15 14:33:24 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:24 --> Input Class Initialized
INFO - 2017-06-15 14:33:24 --> Language Class Initialized
INFO - 2017-06-15 14:33:24 --> Loader Class Initialized
INFO - 2017-06-15 14:33:24 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:24 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:24 --> Email Class Initialized
INFO - 2017-06-15 14:33:24 --> Controller Class Initialized
INFO - 2017-06-15 14:33:24 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:24 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:24 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:24 --> Model Class Initialized
INFO - 2017-06-15 14:33:24 --> Model Class Initialized
INFO - 2017-06-15 18:03:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 18:03:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 18:03:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 18:03:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 18:03:24 --> Final output sent to browser
DEBUG - 2017-06-15 18:03:24 --> Total execution time: 0.0582
INFO - 2017-06-15 14:33:29 --> Config Class Initialized
INFO - 2017-06-15 14:33:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:29 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:29 --> URI Class Initialized
DEBUG - 2017-06-15 14:33:29 --> No URI present. Default controller set.
INFO - 2017-06-15 14:33:29 --> Router Class Initialized
INFO - 2017-06-15 14:33:29 --> Output Class Initialized
INFO - 2017-06-15 14:33:29 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:29 --> Input Class Initialized
INFO - 2017-06-15 14:33:29 --> Language Class Initialized
INFO - 2017-06-15 14:33:29 --> Loader Class Initialized
INFO - 2017-06-15 14:33:29 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:29 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:29 --> Email Class Initialized
INFO - 2017-06-15 14:33:29 --> Controller Class Initialized
INFO - 2017-06-15 14:33:29 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:29 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:29 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:29 --> Model Class Initialized
INFO - 2017-06-15 14:33:29 --> Model Class Initialized
INFO - 2017-06-15 14:33:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:33:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:33:29 --> Final output sent to browser
DEBUG - 2017-06-15 14:33:29 --> Total execution time: 0.0414
INFO - 2017-06-15 14:33:42 --> Config Class Initialized
INFO - 2017-06-15 14:33:42 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:42 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:42 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:42 --> URI Class Initialized
DEBUG - 2017-06-15 14:33:42 --> No URI present. Default controller set.
INFO - 2017-06-15 14:33:42 --> Router Class Initialized
INFO - 2017-06-15 14:33:42 --> Output Class Initialized
INFO - 2017-06-15 14:33:42 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:42 --> Input Class Initialized
INFO - 2017-06-15 14:33:42 --> Language Class Initialized
INFO - 2017-06-15 14:33:42 --> Loader Class Initialized
INFO - 2017-06-15 14:33:42 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:42 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:42 --> Email Class Initialized
INFO - 2017-06-15 14:33:42 --> Controller Class Initialized
INFO - 2017-06-15 14:33:42 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:42 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:42 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:42 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:42 --> Model Class Initialized
INFO - 2017-06-15 14:33:42 --> Model Class Initialized
DEBUG - 2017-06-15 14:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 14:33:43 --> Config Class Initialized
INFO - 2017-06-15 14:33:43 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:43 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:43 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:43 --> URI Class Initialized
INFO - 2017-06-15 14:33:43 --> Router Class Initialized
INFO - 2017-06-15 14:33:43 --> Output Class Initialized
INFO - 2017-06-15 14:33:43 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:43 --> Input Class Initialized
INFO - 2017-06-15 14:33:43 --> Language Class Initialized
INFO - 2017-06-15 14:33:43 --> Loader Class Initialized
INFO - 2017-06-15 14:33:43 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:43 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:43 --> Email Class Initialized
INFO - 2017-06-15 14:33:43 --> Controller Class Initialized
INFO - 2017-06-15 14:33:43 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:43 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:43 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:43 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:43 --> Model Class Initialized
INFO - 2017-06-15 14:33:43 --> Model Class Initialized
INFO - 2017-06-15 14:33:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:33:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:33:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:33:43 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:33:43 --> Final output sent to browser
DEBUG - 2017-06-15 14:33:43 --> Total execution time: 0.0568
INFO - 2017-06-15 14:33:44 --> Config Class Initialized
INFO - 2017-06-15 14:33:44 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:33:44 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:33:44 --> Utf8 Class Initialized
INFO - 2017-06-15 14:33:44 --> URI Class Initialized
DEBUG - 2017-06-15 14:33:44 --> No URI present. Default controller set.
INFO - 2017-06-15 14:33:44 --> Router Class Initialized
INFO - 2017-06-15 14:33:44 --> Output Class Initialized
INFO - 2017-06-15 14:33:44 --> Security Class Initialized
DEBUG - 2017-06-15 14:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:33:44 --> Input Class Initialized
INFO - 2017-06-15 14:33:44 --> Language Class Initialized
INFO - 2017-06-15 14:33:44 --> Loader Class Initialized
INFO - 2017-06-15 14:33:44 --> Helper loaded: common_helper
INFO - 2017-06-15 14:33:44 --> Database Driver Class Initialized
INFO - 2017-06-15 14:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:33:44 --> Email Class Initialized
INFO - 2017-06-15 14:33:44 --> Controller Class Initialized
INFO - 2017-06-15 14:33:44 --> Helper loaded: form_helper
INFO - 2017-06-15 14:33:44 --> Form Validation Class Initialized
INFO - 2017-06-15 14:33:44 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:33:44 --> Helper loaded: url_helper
INFO - 2017-06-15 14:33:44 --> Model Class Initialized
INFO - 2017-06-15 14:33:44 --> Model Class Initialized
INFO - 2017-06-15 14:33:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:33:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:33:44 --> Final output sent to browser
DEBUG - 2017-06-15 14:33:44 --> Total execution time: 0.0403
INFO - 2017-06-15 14:34:25 --> Config Class Initialized
INFO - 2017-06-15 14:34:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:25 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:25 --> URI Class Initialized
DEBUG - 2017-06-15 14:34:25 --> No URI present. Default controller set.
INFO - 2017-06-15 14:34:25 --> Router Class Initialized
INFO - 2017-06-15 14:34:25 --> Output Class Initialized
INFO - 2017-06-15 14:34:25 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:25 --> Input Class Initialized
INFO - 2017-06-15 14:34:25 --> Language Class Initialized
INFO - 2017-06-15 14:34:25 --> Loader Class Initialized
INFO - 2017-06-15 14:34:26 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:26 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:26 --> Email Class Initialized
INFO - 2017-06-15 14:34:26 --> Controller Class Initialized
INFO - 2017-06-15 14:34:26 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:26 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:26 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:26 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:26 --> Model Class Initialized
INFO - 2017-06-15 14:34:26 --> Model Class Initialized
DEBUG - 2017-06-15 14:34:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 14:34:26 --> Config Class Initialized
INFO - 2017-06-15 14:34:26 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:26 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:26 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:26 --> URI Class Initialized
INFO - 2017-06-15 14:34:26 --> Router Class Initialized
INFO - 2017-06-15 14:34:26 --> Output Class Initialized
INFO - 2017-06-15 14:34:26 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:26 --> Input Class Initialized
INFO - 2017-06-15 14:34:26 --> Language Class Initialized
INFO - 2017-06-15 14:34:26 --> Loader Class Initialized
INFO - 2017-06-15 14:34:26 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:26 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:26 --> Email Class Initialized
INFO - 2017-06-15 14:34:26 --> Controller Class Initialized
INFO - 2017-06-15 14:34:26 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:26 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:26 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:26 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:26 --> Model Class Initialized
INFO - 2017-06-15 14:34:26 --> Model Class Initialized
INFO - 2017-06-15 14:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:34:26 --> Final output sent to browser
DEBUG - 2017-06-15 14:34:26 --> Total execution time: 0.0641
INFO - 2017-06-15 14:34:27 --> Config Class Initialized
INFO - 2017-06-15 14:34:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:27 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:27 --> URI Class Initialized
INFO - 2017-06-15 14:34:27 --> Router Class Initialized
INFO - 2017-06-15 14:34:27 --> Output Class Initialized
INFO - 2017-06-15 14:34:27 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:27 --> Input Class Initialized
INFO - 2017-06-15 14:34:27 --> Language Class Initialized
INFO - 2017-06-15 14:34:27 --> Loader Class Initialized
INFO - 2017-06-15 14:34:27 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:27 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:27 --> Email Class Initialized
INFO - 2017-06-15 14:34:27 --> Controller Class Initialized
INFO - 2017-06-15 14:34:27 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:27 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:27 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:27 --> Model Class Initialized
INFO - 2017-06-15 14:34:27 --> Model Class Initialized
INFO - 2017-06-15 14:34:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:34:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:34:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:34:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:34:27 --> Final output sent to browser
DEBUG - 2017-06-15 14:34:27 --> Total execution time: 0.0448
INFO - 2017-06-15 14:34:45 --> Config Class Initialized
INFO - 2017-06-15 14:34:45 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:45 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:45 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:45 --> URI Class Initialized
INFO - 2017-06-15 14:34:45 --> Router Class Initialized
INFO - 2017-06-15 14:34:45 --> Output Class Initialized
INFO - 2017-06-15 14:34:45 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:45 --> Input Class Initialized
INFO - 2017-06-15 14:34:45 --> Language Class Initialized
INFO - 2017-06-15 14:34:45 --> Loader Class Initialized
INFO - 2017-06-15 14:34:45 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:45 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:45 --> Email Class Initialized
INFO - 2017-06-15 14:34:45 --> Controller Class Initialized
INFO - 2017-06-15 14:34:45 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:45 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:45 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:45 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:45 --> Model Class Initialized
INFO - 2017-06-15 14:34:45 --> Model Class Initialized
INFO - 2017-06-15 14:34:45 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:34:45 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:34:45 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:34:45 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:34:45 --> Final output sent to browser
DEBUG - 2017-06-15 14:34:45 --> Total execution time: 0.0478
INFO - 2017-06-15 14:34:46 --> Config Class Initialized
INFO - 2017-06-15 14:34:46 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:46 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:46 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:46 --> URI Class Initialized
INFO - 2017-06-15 14:34:46 --> Router Class Initialized
INFO - 2017-06-15 14:34:46 --> Output Class Initialized
INFO - 2017-06-15 14:34:46 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:46 --> Input Class Initialized
INFO - 2017-06-15 14:34:46 --> Language Class Initialized
INFO - 2017-06-15 14:34:46 --> Loader Class Initialized
INFO - 2017-06-15 14:34:46 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:46 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:46 --> Email Class Initialized
INFO - 2017-06-15 14:34:46 --> Controller Class Initialized
INFO - 2017-06-15 14:34:46 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:46 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:46 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:46 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:46 --> Model Class Initialized
INFO - 2017-06-15 14:34:46 --> Model Class Initialized
INFO - 2017-06-15 14:34:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:34:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:34:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:34:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:34:46 --> Final output sent to browser
DEBUG - 2017-06-15 14:34:46 --> Total execution time: 0.0484
INFO - 2017-06-15 14:34:51 --> Config Class Initialized
INFO - 2017-06-15 14:34:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:51 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:51 --> URI Class Initialized
DEBUG - 2017-06-15 14:34:51 --> No URI present. Default controller set.
INFO - 2017-06-15 14:34:51 --> Router Class Initialized
INFO - 2017-06-15 14:34:51 --> Output Class Initialized
INFO - 2017-06-15 14:34:51 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:51 --> Input Class Initialized
INFO - 2017-06-15 14:34:51 --> Language Class Initialized
INFO - 2017-06-15 14:34:51 --> Loader Class Initialized
INFO - 2017-06-15 14:34:51 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:51 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:51 --> Email Class Initialized
INFO - 2017-06-15 14:34:51 --> Controller Class Initialized
INFO - 2017-06-15 14:34:51 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:51 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:51 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:51 --> Model Class Initialized
INFO - 2017-06-15 14:34:51 --> Model Class Initialized
INFO - 2017-06-15 14:34:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 14:34:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:34:51 --> Final output sent to browser
DEBUG - 2017-06-15 14:34:51 --> Total execution time: 0.0407
INFO - 2017-06-15 14:34:52 --> Config Class Initialized
INFO - 2017-06-15 14:34:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:34:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:34:52 --> Utf8 Class Initialized
INFO - 2017-06-15 14:34:52 --> URI Class Initialized
INFO - 2017-06-15 14:34:52 --> Router Class Initialized
INFO - 2017-06-15 14:34:52 --> Output Class Initialized
INFO - 2017-06-15 14:34:52 --> Security Class Initialized
DEBUG - 2017-06-15 14:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:34:52 --> Input Class Initialized
INFO - 2017-06-15 14:34:52 --> Language Class Initialized
INFO - 2017-06-15 14:34:52 --> Loader Class Initialized
INFO - 2017-06-15 14:34:52 --> Helper loaded: common_helper
INFO - 2017-06-15 14:34:52 --> Database Driver Class Initialized
INFO - 2017-06-15 14:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:34:52 --> Email Class Initialized
INFO - 2017-06-15 14:34:52 --> Controller Class Initialized
INFO - 2017-06-15 14:34:52 --> Helper loaded: form_helper
INFO - 2017-06-15 14:34:52 --> Form Validation Class Initialized
INFO - 2017-06-15 14:34:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:34:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:34:52 --> Helper loaded: url_helper
INFO - 2017-06-15 14:34:52 --> Model Class Initialized
INFO - 2017-06-15 14:34:52 --> Model Class Initialized
INFO - 2017-06-15 14:34:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:34:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:34:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:34:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:34:52 --> Final output sent to browser
DEBUG - 2017-06-15 14:34:52 --> Total execution time: 0.0475
INFO - 2017-06-15 14:35:42 --> Config Class Initialized
INFO - 2017-06-15 14:35:42 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:35:42 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:35:42 --> Utf8 Class Initialized
INFO - 2017-06-15 14:35:42 --> URI Class Initialized
INFO - 2017-06-15 14:35:42 --> Router Class Initialized
INFO - 2017-06-15 14:35:42 --> Output Class Initialized
INFO - 2017-06-15 14:35:42 --> Security Class Initialized
DEBUG - 2017-06-15 14:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:35:42 --> Input Class Initialized
INFO - 2017-06-15 14:35:42 --> Language Class Initialized
INFO - 2017-06-15 14:35:42 --> Loader Class Initialized
INFO - 2017-06-15 14:35:42 --> Helper loaded: common_helper
INFO - 2017-06-15 14:35:42 --> Database Driver Class Initialized
INFO - 2017-06-15 14:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:35:42 --> Email Class Initialized
INFO - 2017-06-15 14:35:42 --> Controller Class Initialized
INFO - 2017-06-15 14:35:42 --> Helper loaded: form_helper
INFO - 2017-06-15 14:35:42 --> Form Validation Class Initialized
INFO - 2017-06-15 14:35:42 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:35:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:35:42 --> Helper loaded: url_helper
INFO - 2017-06-15 14:35:42 --> Model Class Initialized
INFO - 2017-06-15 14:35:42 --> Model Class Initialized
INFO - 2017-06-15 14:35:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:35:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:35:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:35:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:35:42 --> Final output sent to browser
DEBUG - 2017-06-15 14:35:42 --> Total execution time: 0.0492
INFO - 2017-06-15 14:35:53 --> Config Class Initialized
INFO - 2017-06-15 14:35:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:35:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:35:53 --> Utf8 Class Initialized
INFO - 2017-06-15 14:35:53 --> URI Class Initialized
INFO - 2017-06-15 14:35:53 --> Router Class Initialized
INFO - 2017-06-15 14:35:53 --> Output Class Initialized
INFO - 2017-06-15 14:35:53 --> Security Class Initialized
DEBUG - 2017-06-15 14:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:35:53 --> Input Class Initialized
INFO - 2017-06-15 14:35:53 --> Language Class Initialized
INFO - 2017-06-15 14:35:53 --> Loader Class Initialized
INFO - 2017-06-15 14:35:53 --> Helper loaded: common_helper
INFO - 2017-06-15 14:35:53 --> Database Driver Class Initialized
INFO - 2017-06-15 14:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:35:53 --> Email Class Initialized
INFO - 2017-06-15 14:35:53 --> Controller Class Initialized
INFO - 2017-06-15 14:35:53 --> Helper loaded: form_helper
INFO - 2017-06-15 14:35:53 --> Form Validation Class Initialized
INFO - 2017-06-15 14:35:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:35:53 --> Helper loaded: url_helper
INFO - 2017-06-15 14:35:53 --> Model Class Initialized
INFO - 2017-06-15 14:35:53 --> Model Class Initialized
INFO - 2017-06-15 14:35:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:35:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:35:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:35:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:35:53 --> Final output sent to browser
DEBUG - 2017-06-15 14:35:53 --> Total execution time: 0.0506
INFO - 2017-06-15 14:35:54 --> Config Class Initialized
INFO - 2017-06-15 14:35:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:35:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:35:54 --> Utf8 Class Initialized
INFO - 2017-06-15 14:35:54 --> URI Class Initialized
INFO - 2017-06-15 14:35:54 --> Router Class Initialized
INFO - 2017-06-15 14:35:54 --> Output Class Initialized
INFO - 2017-06-15 14:35:54 --> Security Class Initialized
DEBUG - 2017-06-15 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:35:54 --> Input Class Initialized
INFO - 2017-06-15 14:35:54 --> Language Class Initialized
INFO - 2017-06-15 14:35:54 --> Loader Class Initialized
INFO - 2017-06-15 14:35:54 --> Helper loaded: common_helper
INFO - 2017-06-15 14:35:54 --> Database Driver Class Initialized
INFO - 2017-06-15 14:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:35:54 --> Email Class Initialized
INFO - 2017-06-15 14:35:54 --> Controller Class Initialized
INFO - 2017-06-15 14:35:54 --> Helper loaded: form_helper
INFO - 2017-06-15 14:35:54 --> Form Validation Class Initialized
INFO - 2017-06-15 14:35:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:35:54 --> Helper loaded: url_helper
INFO - 2017-06-15 14:35:54 --> Model Class Initialized
INFO - 2017-06-15 14:35:54 --> Model Class Initialized
INFO - 2017-06-15 18:05:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 18:05:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 18:05:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 18:05:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 18:05:54 --> Final output sent to browser
DEBUG - 2017-06-15 18:05:54 --> Total execution time: 0.0504
INFO - 2017-06-15 14:35:55 --> Config Class Initialized
INFO - 2017-06-15 14:35:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:35:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:35:55 --> Utf8 Class Initialized
INFO - 2017-06-15 14:35:55 --> URI Class Initialized
INFO - 2017-06-15 14:35:55 --> Router Class Initialized
INFO - 2017-06-15 14:35:55 --> Output Class Initialized
INFO - 2017-06-15 14:35:55 --> Security Class Initialized
DEBUG - 2017-06-15 14:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:35:55 --> Input Class Initialized
INFO - 2017-06-15 14:35:55 --> Language Class Initialized
INFO - 2017-06-15 14:35:55 --> Loader Class Initialized
INFO - 2017-06-15 14:35:55 --> Helper loaded: common_helper
INFO - 2017-06-15 14:35:55 --> Database Driver Class Initialized
INFO - 2017-06-15 14:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:35:55 --> Email Class Initialized
INFO - 2017-06-15 14:35:55 --> Controller Class Initialized
INFO - 2017-06-15 14:35:55 --> Helper loaded: form_helper
INFO - 2017-06-15 14:35:55 --> Form Validation Class Initialized
INFO - 2017-06-15 14:35:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:35:55 --> Helper loaded: url_helper
INFO - 2017-06-15 14:35:55 --> Model Class Initialized
INFO - 2017-06-15 14:35:55 --> Model Class Initialized
INFO - 2017-06-15 14:35:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:35:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:35:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:35:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:35:55 --> Final output sent to browser
DEBUG - 2017-06-15 14:35:55 --> Total execution time: 0.0454
INFO - 2017-06-15 14:36:01 --> Config Class Initialized
INFO - 2017-06-15 14:36:01 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:36:01 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:36:01 --> Utf8 Class Initialized
INFO - 2017-06-15 14:36:01 --> URI Class Initialized
INFO - 2017-06-15 14:36:01 --> Router Class Initialized
INFO - 2017-06-15 14:36:01 --> Output Class Initialized
INFO - 2017-06-15 14:36:01 --> Security Class Initialized
DEBUG - 2017-06-15 14:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:36:01 --> Input Class Initialized
INFO - 2017-06-15 14:36:01 --> Language Class Initialized
ERROR - 2017-06-15 14:36:01 --> 404 Page Not Found: Admin/page-user.html
INFO - 2017-06-15 14:36:02 --> Config Class Initialized
INFO - 2017-06-15 14:36:02 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:36:02 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:36:02 --> Utf8 Class Initialized
INFO - 2017-06-15 14:36:02 --> URI Class Initialized
INFO - 2017-06-15 14:36:02 --> Router Class Initialized
INFO - 2017-06-15 14:36:02 --> Output Class Initialized
INFO - 2017-06-15 14:36:02 --> Security Class Initialized
DEBUG - 2017-06-15 14:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:36:02 --> Input Class Initialized
INFO - 2017-06-15 14:36:02 --> Language Class Initialized
INFO - 2017-06-15 14:36:02 --> Loader Class Initialized
INFO - 2017-06-15 14:36:02 --> Helper loaded: common_helper
INFO - 2017-06-15 14:36:02 --> Database Driver Class Initialized
INFO - 2017-06-15 14:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:36:02 --> Email Class Initialized
INFO - 2017-06-15 14:36:02 --> Controller Class Initialized
INFO - 2017-06-15 14:36:02 --> Helper loaded: form_helper
INFO - 2017-06-15 14:36:02 --> Form Validation Class Initialized
INFO - 2017-06-15 14:36:02 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:36:02 --> Helper loaded: url_helper
INFO - 2017-06-15 14:36:02 --> Model Class Initialized
INFO - 2017-06-15 14:36:02 --> Model Class Initialized
INFO - 2017-06-15 14:36:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:36:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:36:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:36:02 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:36:02 --> Final output sent to browser
DEBUG - 2017-06-15 14:36:02 --> Total execution time: 0.0477
INFO - 2017-06-15 14:36:34 --> Config Class Initialized
INFO - 2017-06-15 14:36:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:36:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:36:34 --> Utf8 Class Initialized
INFO - 2017-06-15 14:36:34 --> URI Class Initialized
INFO - 2017-06-15 14:36:34 --> Router Class Initialized
INFO - 2017-06-15 14:36:34 --> Output Class Initialized
INFO - 2017-06-15 14:36:34 --> Security Class Initialized
DEBUG - 2017-06-15 14:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:36:34 --> Input Class Initialized
INFO - 2017-06-15 14:36:34 --> Language Class Initialized
INFO - 2017-06-15 14:36:34 --> Loader Class Initialized
INFO - 2017-06-15 14:36:34 --> Helper loaded: common_helper
INFO - 2017-06-15 14:36:34 --> Database Driver Class Initialized
INFO - 2017-06-15 14:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:36:34 --> Email Class Initialized
INFO - 2017-06-15 14:36:34 --> Controller Class Initialized
INFO - 2017-06-15 14:36:34 --> Helper loaded: form_helper
INFO - 2017-06-15 14:36:34 --> Form Validation Class Initialized
INFO - 2017-06-15 14:36:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:36:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:36:34 --> Helper loaded: url_helper
INFO - 2017-06-15 14:36:34 --> Model Class Initialized
INFO - 2017-06-15 14:36:34 --> Model Class Initialized
INFO - 2017-06-15 14:36:35 --> Config Class Initialized
INFO - 2017-06-15 14:36:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:36:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:36:35 --> Utf8 Class Initialized
INFO - 2017-06-15 14:36:35 --> URI Class Initialized
INFO - 2017-06-15 14:36:35 --> Router Class Initialized
INFO - 2017-06-15 14:36:35 --> Output Class Initialized
INFO - 2017-06-15 14:36:35 --> Security Class Initialized
DEBUG - 2017-06-15 14:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:36:35 --> Input Class Initialized
INFO - 2017-06-15 14:36:35 --> Language Class Initialized
INFO - 2017-06-15 14:36:35 --> Loader Class Initialized
INFO - 2017-06-15 14:36:35 --> Helper loaded: common_helper
INFO - 2017-06-15 14:36:35 --> Database Driver Class Initialized
INFO - 2017-06-15 14:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:36:35 --> Email Class Initialized
INFO - 2017-06-15 14:36:35 --> Controller Class Initialized
INFO - 2017-06-15 14:36:35 --> Helper loaded: form_helper
INFO - 2017-06-15 14:36:35 --> Form Validation Class Initialized
INFO - 2017-06-15 14:36:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:36:35 --> Helper loaded: url_helper
INFO - 2017-06-15 14:36:35 --> Model Class Initialized
INFO - 2017-06-15 14:36:35 --> Model Class Initialized
INFO - 2017-06-15 14:36:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:36:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:36:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:36:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:36:35 --> Final output sent to browser
DEBUG - 2017-06-15 14:36:35 --> Total execution time: 0.0470
INFO - 2017-06-15 14:44:50 --> Config Class Initialized
INFO - 2017-06-15 14:44:50 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:44:50 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:44:50 --> Utf8 Class Initialized
INFO - 2017-06-15 14:44:50 --> URI Class Initialized
INFO - 2017-06-15 14:44:50 --> Router Class Initialized
INFO - 2017-06-15 14:44:50 --> Output Class Initialized
INFO - 2017-06-15 14:44:50 --> Security Class Initialized
DEBUG - 2017-06-15 14:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:44:50 --> Input Class Initialized
INFO - 2017-06-15 14:44:50 --> Language Class Initialized
INFO - 2017-06-15 14:44:50 --> Loader Class Initialized
INFO - 2017-06-15 14:44:50 --> Helper loaded: common_helper
INFO - 2017-06-15 14:44:50 --> Database Driver Class Initialized
INFO - 2017-06-15 14:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:44:50 --> Email Class Initialized
INFO - 2017-06-15 14:44:50 --> Controller Class Initialized
INFO - 2017-06-15 14:44:50 --> Helper loaded: form_helper
INFO - 2017-06-15 14:44:50 --> Form Validation Class Initialized
INFO - 2017-06-15 14:44:50 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:44:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:44:50 --> Helper loaded: url_helper
INFO - 2017-06-15 14:44:50 --> Model Class Initialized
INFO - 2017-06-15 14:44:50 --> Model Class Initialized
INFO - 2017-06-15 18:14:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 18:14:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 18:14:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 18:14:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 18:14:50 --> Final output sent to browser
DEBUG - 2017-06-15 18:14:50 --> Total execution time: 0.0499
INFO - 2017-06-15 14:44:55 --> Config Class Initialized
INFO - 2017-06-15 14:44:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:44:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:44:55 --> Utf8 Class Initialized
INFO - 2017-06-15 14:44:55 --> URI Class Initialized
INFO - 2017-06-15 14:44:55 --> Router Class Initialized
INFO - 2017-06-15 14:44:55 --> Output Class Initialized
INFO - 2017-06-15 14:44:55 --> Security Class Initialized
DEBUG - 2017-06-15 14:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:44:55 --> Input Class Initialized
INFO - 2017-06-15 14:44:55 --> Language Class Initialized
INFO - 2017-06-15 14:44:55 --> Loader Class Initialized
INFO - 2017-06-15 14:44:55 --> Helper loaded: common_helper
INFO - 2017-06-15 14:44:55 --> Database Driver Class Initialized
INFO - 2017-06-15 14:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:44:55 --> Email Class Initialized
INFO - 2017-06-15 14:44:55 --> Controller Class Initialized
INFO - 2017-06-15 14:44:55 --> Helper loaded: form_helper
INFO - 2017-06-15 14:44:55 --> Form Validation Class Initialized
INFO - 2017-06-15 14:44:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:44:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:44:55 --> Helper loaded: url_helper
INFO - 2017-06-15 14:44:55 --> Model Class Initialized
INFO - 2017-06-15 14:44:55 --> Model Class Initialized
INFO - 2017-06-15 14:44:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:44:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:44:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:44:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:44:55 --> Final output sent to browser
DEBUG - 2017-06-15 14:44:55 --> Total execution time: 0.0459
INFO - 2017-06-15 14:49:46 --> Config Class Initialized
INFO - 2017-06-15 14:49:46 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:49:46 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:49:46 --> Utf8 Class Initialized
INFO - 2017-06-15 14:49:46 --> URI Class Initialized
INFO - 2017-06-15 14:49:46 --> Router Class Initialized
INFO - 2017-06-15 14:49:46 --> Output Class Initialized
INFO - 2017-06-15 14:49:46 --> Security Class Initialized
DEBUG - 2017-06-15 14:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:49:46 --> Input Class Initialized
INFO - 2017-06-15 14:49:46 --> Language Class Initialized
INFO - 2017-06-15 14:49:46 --> Loader Class Initialized
INFO - 2017-06-15 14:49:46 --> Helper loaded: common_helper
INFO - 2017-06-15 14:49:46 --> Database Driver Class Initialized
INFO - 2017-06-15 14:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:49:46 --> Email Class Initialized
INFO - 2017-06-15 14:49:46 --> Controller Class Initialized
INFO - 2017-06-15 14:49:46 --> Helper loaded: form_helper
INFO - 2017-06-15 14:49:46 --> Form Validation Class Initialized
INFO - 2017-06-15 14:49:46 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:49:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:49:46 --> Helper loaded: url_helper
INFO - 2017-06-15 14:49:46 --> Model Class Initialized
INFO - 2017-06-15 14:49:46 --> Model Class Initialized
INFO - 2017-06-15 14:49:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:49:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 14:49:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 14:49:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:49:46 --> Final output sent to browser
DEBUG - 2017-06-15 14:49:46 --> Total execution time: 0.0492
INFO - 2017-06-15 14:49:48 --> Config Class Initialized
INFO - 2017-06-15 14:49:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:49:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:49:48 --> Utf8 Class Initialized
INFO - 2017-06-15 14:49:48 --> URI Class Initialized
INFO - 2017-06-15 14:49:48 --> Router Class Initialized
INFO - 2017-06-15 14:49:48 --> Output Class Initialized
INFO - 2017-06-15 14:49:48 --> Security Class Initialized
DEBUG - 2017-06-15 14:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:49:48 --> Input Class Initialized
INFO - 2017-06-15 14:49:48 --> Language Class Initialized
INFO - 2017-06-15 14:49:48 --> Loader Class Initialized
INFO - 2017-06-15 14:49:48 --> Helper loaded: common_helper
INFO - 2017-06-15 14:49:48 --> Database Driver Class Initialized
INFO - 2017-06-15 14:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:49:48 --> Email Class Initialized
INFO - 2017-06-15 14:49:48 --> Controller Class Initialized
INFO - 2017-06-15 14:49:48 --> Helper loaded: form_helper
INFO - 2017-06-15 14:49:48 --> Form Validation Class Initialized
INFO - 2017-06-15 14:49:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:49:48 --> Helper loaded: url_helper
INFO - 2017-06-15 14:49:48 --> Model Class Initialized
INFO - 2017-06-15 14:49:48 --> Model Class Initialized
INFO - 2017-06-15 14:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 14:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:49:48 --> Final output sent to browser
DEBUG - 2017-06-15 14:49:48 --> Total execution time: 0.0437
INFO - 2017-06-15 14:53:14 --> Config Class Initialized
INFO - 2017-06-15 14:53:14 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:53:14 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:53:14 --> Utf8 Class Initialized
INFO - 2017-06-15 14:53:14 --> URI Class Initialized
INFO - 2017-06-15 14:53:14 --> Router Class Initialized
INFO - 2017-06-15 14:53:14 --> Output Class Initialized
INFO - 2017-06-15 14:53:14 --> Security Class Initialized
DEBUG - 2017-06-15 14:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:53:14 --> Input Class Initialized
INFO - 2017-06-15 14:53:14 --> Language Class Initialized
INFO - 2017-06-15 14:53:14 --> Loader Class Initialized
INFO - 2017-06-15 14:53:14 --> Helper loaded: common_helper
INFO - 2017-06-15 14:53:14 --> Database Driver Class Initialized
INFO - 2017-06-15 14:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:53:14 --> Email Class Initialized
INFO - 2017-06-15 14:53:14 --> Controller Class Initialized
INFO - 2017-06-15 14:53:14 --> Helper loaded: form_helper
INFO - 2017-06-15 14:53:14 --> Form Validation Class Initialized
INFO - 2017-06-15 14:53:14 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:53:14 --> Helper loaded: url_helper
INFO - 2017-06-15 14:53:14 --> Model Class Initialized
INFO - 2017-06-15 14:53:14 --> Model Class Initialized
INFO - 2017-06-15 14:53:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:53:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:53:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 14:53:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:53:14 --> Final output sent to browser
DEBUG - 2017-06-15 14:53:14 --> Total execution time: 0.0459
INFO - 2017-06-15 14:53:27 --> Config Class Initialized
INFO - 2017-06-15 14:53:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:53:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:53:27 --> Utf8 Class Initialized
INFO - 2017-06-15 14:53:27 --> URI Class Initialized
INFO - 2017-06-15 14:53:27 --> Router Class Initialized
INFO - 2017-06-15 14:53:27 --> Output Class Initialized
INFO - 2017-06-15 14:53:27 --> Security Class Initialized
DEBUG - 2017-06-15 14:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:53:27 --> Input Class Initialized
INFO - 2017-06-15 14:53:27 --> Language Class Initialized
INFO - 2017-06-15 14:53:27 --> Loader Class Initialized
INFO - 2017-06-15 14:53:27 --> Helper loaded: common_helper
INFO - 2017-06-15 14:53:27 --> Database Driver Class Initialized
INFO - 2017-06-15 14:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:53:27 --> Email Class Initialized
INFO - 2017-06-15 14:53:27 --> Controller Class Initialized
INFO - 2017-06-15 14:53:27 --> Helper loaded: form_helper
INFO - 2017-06-15 14:53:27 --> Form Validation Class Initialized
INFO - 2017-06-15 14:53:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:53:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:53:27 --> Helper loaded: url_helper
INFO - 2017-06-15 14:53:27 --> Model Class Initialized
INFO - 2017-06-15 14:53:27 --> Model Class Initialized
INFO - 2017-06-15 14:53:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:53:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:54:35 --> Config Class Initialized
INFO - 2017-06-15 14:54:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:54:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:54:35 --> Utf8 Class Initialized
INFO - 2017-06-15 14:54:35 --> URI Class Initialized
INFO - 2017-06-15 14:54:35 --> Router Class Initialized
INFO - 2017-06-15 14:54:35 --> Output Class Initialized
INFO - 2017-06-15 14:54:35 --> Security Class Initialized
DEBUG - 2017-06-15 14:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:54:35 --> Input Class Initialized
INFO - 2017-06-15 14:54:35 --> Language Class Initialized
INFO - 2017-06-15 14:54:35 --> Loader Class Initialized
INFO - 2017-06-15 14:54:35 --> Helper loaded: common_helper
INFO - 2017-06-15 14:54:35 --> Database Driver Class Initialized
INFO - 2017-06-15 14:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:54:35 --> Email Class Initialized
INFO - 2017-06-15 14:54:35 --> Controller Class Initialized
INFO - 2017-06-15 14:54:35 --> Helper loaded: form_helper
INFO - 2017-06-15 14:54:35 --> Form Validation Class Initialized
INFO - 2017-06-15 14:54:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:54:35 --> Helper loaded: url_helper
INFO - 2017-06-15 14:54:35 --> Model Class Initialized
INFO - 2017-06-15 14:54:35 --> Model Class Initialized
INFO - 2017-06-15 14:54:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:54:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:54:48 --> Config Class Initialized
INFO - 2017-06-15 14:54:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:54:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:54:48 --> Utf8 Class Initialized
INFO - 2017-06-15 14:54:48 --> URI Class Initialized
INFO - 2017-06-15 14:54:48 --> Router Class Initialized
INFO - 2017-06-15 14:54:48 --> Output Class Initialized
INFO - 2017-06-15 14:54:48 --> Security Class Initialized
DEBUG - 2017-06-15 14:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:54:48 --> Input Class Initialized
INFO - 2017-06-15 14:54:48 --> Language Class Initialized
INFO - 2017-06-15 14:54:48 --> Loader Class Initialized
INFO - 2017-06-15 14:54:48 --> Helper loaded: common_helper
INFO - 2017-06-15 14:54:48 --> Database Driver Class Initialized
INFO - 2017-06-15 14:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:54:48 --> Email Class Initialized
INFO - 2017-06-15 14:54:48 --> Controller Class Initialized
INFO - 2017-06-15 14:54:48 --> Helper loaded: form_helper
INFO - 2017-06-15 14:54:48 --> Form Validation Class Initialized
INFO - 2017-06-15 14:54:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:54:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:54:48 --> Helper loaded: url_helper
INFO - 2017-06-15 14:54:48 --> Model Class Initialized
INFO - 2017-06-15 14:54:48 --> Model Class Initialized
INFO - 2017-06-15 14:54:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:54:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:54:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 14:54:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:54:48 --> Final output sent to browser
DEBUG - 2017-06-15 14:54:48 --> Total execution time: 0.0473
INFO - 2017-06-15 14:55:12 --> Config Class Initialized
INFO - 2017-06-15 14:55:12 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:55:12 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:55:12 --> Utf8 Class Initialized
INFO - 2017-06-15 14:55:12 --> URI Class Initialized
INFO - 2017-06-15 14:55:12 --> Router Class Initialized
INFO - 2017-06-15 14:55:12 --> Output Class Initialized
INFO - 2017-06-15 14:55:12 --> Security Class Initialized
DEBUG - 2017-06-15 14:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:55:12 --> Input Class Initialized
INFO - 2017-06-15 14:55:12 --> Language Class Initialized
INFO - 2017-06-15 14:55:12 --> Loader Class Initialized
INFO - 2017-06-15 14:55:12 --> Helper loaded: common_helper
INFO - 2017-06-15 14:55:12 --> Database Driver Class Initialized
INFO - 2017-06-15 14:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:55:12 --> Email Class Initialized
INFO - 2017-06-15 14:55:12 --> Controller Class Initialized
INFO - 2017-06-15 14:55:12 --> Helper loaded: form_helper
INFO - 2017-06-15 14:55:12 --> Form Validation Class Initialized
INFO - 2017-06-15 14:55:12 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:55:12 --> Helper loaded: url_helper
INFO - 2017-06-15 14:55:12 --> Model Class Initialized
INFO - 2017-06-15 14:55:12 --> Model Class Initialized
INFO - 2017-06-15 14:55:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:55:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:55:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 14:55:12 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:55:12 --> Final output sent to browser
DEBUG - 2017-06-15 14:55:12 --> Total execution time: 0.0487
INFO - 2017-06-15 14:56:40 --> Config Class Initialized
INFO - 2017-06-15 14:56:40 --> Hooks Class Initialized
DEBUG - 2017-06-15 14:56:40 --> UTF-8 Support Enabled
INFO - 2017-06-15 14:56:40 --> Utf8 Class Initialized
INFO - 2017-06-15 14:56:40 --> URI Class Initialized
INFO - 2017-06-15 14:56:40 --> Router Class Initialized
INFO - 2017-06-15 14:56:40 --> Output Class Initialized
INFO - 2017-06-15 14:56:40 --> Security Class Initialized
DEBUG - 2017-06-15 14:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 14:56:40 --> Input Class Initialized
INFO - 2017-06-15 14:56:40 --> Language Class Initialized
INFO - 2017-06-15 14:56:40 --> Loader Class Initialized
INFO - 2017-06-15 14:56:40 --> Helper loaded: common_helper
INFO - 2017-06-15 14:56:40 --> Database Driver Class Initialized
INFO - 2017-06-15 14:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 14:56:40 --> Email Class Initialized
INFO - 2017-06-15 14:56:40 --> Controller Class Initialized
INFO - 2017-06-15 14:56:40 --> Helper loaded: form_helper
INFO - 2017-06-15 14:56:40 --> Form Validation Class Initialized
INFO - 2017-06-15 14:56:40 --> Helper loaded: email_helper
DEBUG - 2017-06-15 14:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 14:56:40 --> Helper loaded: url_helper
INFO - 2017-06-15 14:56:40 --> Model Class Initialized
INFO - 2017-06-15 14:56:40 --> Model Class Initialized
INFO - 2017-06-15 14:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 14:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 14:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 14:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 14:56:40 --> Final output sent to browser
DEBUG - 2017-06-15 14:56:40 --> Total execution time: 0.0543
INFO - 2017-06-15 15:00:35 --> Config Class Initialized
INFO - 2017-06-15 15:00:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:00:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:00:35 --> Utf8 Class Initialized
INFO - 2017-06-15 15:00:35 --> URI Class Initialized
INFO - 2017-06-15 15:00:35 --> Router Class Initialized
INFO - 2017-06-15 15:00:35 --> Output Class Initialized
INFO - 2017-06-15 15:00:35 --> Security Class Initialized
DEBUG - 2017-06-15 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:00:35 --> Input Class Initialized
INFO - 2017-06-15 15:00:35 --> Language Class Initialized
INFO - 2017-06-15 15:00:35 --> Loader Class Initialized
INFO - 2017-06-15 15:00:35 --> Helper loaded: common_helper
INFO - 2017-06-15 15:00:35 --> Database Driver Class Initialized
INFO - 2017-06-15 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:00:35 --> Email Class Initialized
INFO - 2017-06-15 15:00:35 --> Controller Class Initialized
INFO - 2017-06-15 15:00:35 --> Helper loaded: form_helper
INFO - 2017-06-15 15:00:35 --> Form Validation Class Initialized
INFO - 2017-06-15 15:00:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:00:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:00:35 --> Helper loaded: url_helper
INFO - 2017-06-15 15:00:35 --> Model Class Initialized
INFO - 2017-06-15 15:00:35 --> Model Class Initialized
ERROR - 2017-06-15 15:00:35 --> Query error: Unknown column 'agentId' in 'where clause' - Invalid query: SELECT *
FROM `bloodgroups`
WHERE `isDeleted` =0
AND `agentId` =0
ERROR - 2017-06-15 15:00:35 --> Call to a member function result() on a non-object
ERROR - 2017-06-15 15:00:35 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\bloodApp\application\core\Healthcontroller.php 72
INFO - 2017-06-15 15:00:54 --> Config Class Initialized
INFO - 2017-06-15 15:00:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:00:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:00:54 --> Utf8 Class Initialized
INFO - 2017-06-15 15:00:54 --> URI Class Initialized
INFO - 2017-06-15 15:00:54 --> Router Class Initialized
INFO - 2017-06-15 15:00:54 --> Output Class Initialized
INFO - 2017-06-15 15:00:54 --> Security Class Initialized
DEBUG - 2017-06-15 15:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:00:54 --> Input Class Initialized
INFO - 2017-06-15 15:00:54 --> Language Class Initialized
INFO - 2017-06-15 15:00:54 --> Loader Class Initialized
INFO - 2017-06-15 15:00:54 --> Helper loaded: common_helper
INFO - 2017-06-15 15:00:54 --> Database Driver Class Initialized
INFO - 2017-06-15 15:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:00:54 --> Email Class Initialized
INFO - 2017-06-15 15:00:54 --> Controller Class Initialized
INFO - 2017-06-15 15:00:54 --> Helper loaded: form_helper
INFO - 2017-06-15 15:00:54 --> Form Validation Class Initialized
INFO - 2017-06-15 15:00:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:00:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:00:54 --> Helper loaded: url_helper
INFO - 2017-06-15 15:00:54 --> Model Class Initialized
INFO - 2017-06-15 15:00:54 --> Model Class Initialized
INFO - 2017-06-15 15:00:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:00:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:00:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:00:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:00:54 --> Final output sent to browser
DEBUG - 2017-06-15 15:00:54 --> Total execution time: 0.0488
INFO - 2017-06-15 15:02:11 --> Config Class Initialized
INFO - 2017-06-15 15:02:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:02:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:02:11 --> Utf8 Class Initialized
INFO - 2017-06-15 15:02:11 --> URI Class Initialized
INFO - 2017-06-15 15:02:11 --> Router Class Initialized
INFO - 2017-06-15 15:02:11 --> Output Class Initialized
INFO - 2017-06-15 15:02:11 --> Security Class Initialized
DEBUG - 2017-06-15 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:02:11 --> Input Class Initialized
INFO - 2017-06-15 15:02:11 --> Language Class Initialized
INFO - 2017-06-15 15:02:11 --> Loader Class Initialized
INFO - 2017-06-15 15:02:11 --> Helper loaded: common_helper
INFO - 2017-06-15 15:02:11 --> Database Driver Class Initialized
INFO - 2017-06-15 15:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:02:11 --> Email Class Initialized
INFO - 2017-06-15 15:02:11 --> Controller Class Initialized
INFO - 2017-06-15 15:02:11 --> Helper loaded: form_helper
INFO - 2017-06-15 15:02:11 --> Form Validation Class Initialized
INFO - 2017-06-15 15:02:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:02:11 --> Helper loaded: url_helper
INFO - 2017-06-15 15:02:11 --> Model Class Initialized
INFO - 2017-06-15 15:02:11 --> Model Class Initialized
INFO - 2017-06-15 15:02:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:02:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:02:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:02:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:02:11 --> Final output sent to browser
DEBUG - 2017-06-15 15:02:11 --> Total execution time: 0.0483
INFO - 2017-06-15 15:02:18 --> Config Class Initialized
INFO - 2017-06-15 15:02:18 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:02:18 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:02:18 --> Utf8 Class Initialized
INFO - 2017-06-15 15:02:18 --> URI Class Initialized
INFO - 2017-06-15 15:02:18 --> Router Class Initialized
INFO - 2017-06-15 15:02:18 --> Output Class Initialized
INFO - 2017-06-15 15:02:18 --> Security Class Initialized
DEBUG - 2017-06-15 15:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:02:18 --> Input Class Initialized
INFO - 2017-06-15 15:02:18 --> Language Class Initialized
INFO - 2017-06-15 15:02:18 --> Loader Class Initialized
INFO - 2017-06-15 15:02:18 --> Helper loaded: common_helper
INFO - 2017-06-15 15:02:18 --> Database Driver Class Initialized
INFO - 2017-06-15 15:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:02:18 --> Email Class Initialized
INFO - 2017-06-15 15:02:18 --> Controller Class Initialized
INFO - 2017-06-15 15:02:18 --> Helper loaded: form_helper
INFO - 2017-06-15 15:02:18 --> Form Validation Class Initialized
INFO - 2017-06-15 15:02:18 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:02:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:02:18 --> Helper loaded: url_helper
INFO - 2017-06-15 15:02:18 --> Model Class Initialized
INFO - 2017-06-15 15:02:18 --> Model Class Initialized
INFO - 2017-06-15 15:02:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:02:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:02:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:02:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:02:18 --> Final output sent to browser
DEBUG - 2017-06-15 15:02:18 --> Total execution time: 0.0587
INFO - 2017-06-15 15:08:33 --> Config Class Initialized
INFO - 2017-06-15 15:08:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:08:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:08:33 --> Utf8 Class Initialized
INFO - 2017-06-15 15:08:33 --> URI Class Initialized
INFO - 2017-06-15 15:08:33 --> Router Class Initialized
INFO - 2017-06-15 15:08:33 --> Output Class Initialized
INFO - 2017-06-15 15:08:33 --> Security Class Initialized
DEBUG - 2017-06-15 15:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:08:33 --> Input Class Initialized
INFO - 2017-06-15 15:08:33 --> Language Class Initialized
INFO - 2017-06-15 15:08:33 --> Loader Class Initialized
INFO - 2017-06-15 15:08:33 --> Helper loaded: common_helper
INFO - 2017-06-15 15:08:33 --> Database Driver Class Initialized
INFO - 2017-06-15 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:08:33 --> Email Class Initialized
INFO - 2017-06-15 15:08:33 --> Controller Class Initialized
INFO - 2017-06-15 15:08:33 --> Helper loaded: form_helper
INFO - 2017-06-15 15:08:33 --> Form Validation Class Initialized
INFO - 2017-06-15 15:08:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:08:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:08:34 --> Helper loaded: url_helper
INFO - 2017-06-15 15:08:34 --> Model Class Initialized
INFO - 2017-06-15 15:08:34 --> Model Class Initialized
INFO - 2017-06-15 15:08:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:08:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:08:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:08:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:08:34 --> Final output sent to browser
DEBUG - 2017-06-15 15:08:34 --> Total execution time: 0.0569
INFO - 2017-06-15 15:08:36 --> Config Class Initialized
INFO - 2017-06-15 15:08:36 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:08:36 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:08:36 --> Utf8 Class Initialized
INFO - 2017-06-15 15:08:36 --> URI Class Initialized
INFO - 2017-06-15 15:08:36 --> Router Class Initialized
INFO - 2017-06-15 15:08:36 --> Output Class Initialized
INFO - 2017-06-15 15:08:36 --> Security Class Initialized
DEBUG - 2017-06-15 15:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:08:36 --> Input Class Initialized
INFO - 2017-06-15 15:08:36 --> Language Class Initialized
INFO - 2017-06-15 15:08:36 --> Loader Class Initialized
INFO - 2017-06-15 15:08:36 --> Helper loaded: common_helper
INFO - 2017-06-15 15:08:36 --> Database Driver Class Initialized
INFO - 2017-06-15 15:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:08:36 --> Email Class Initialized
INFO - 2017-06-15 15:08:36 --> Controller Class Initialized
INFO - 2017-06-15 15:08:36 --> Helper loaded: form_helper
INFO - 2017-06-15 15:08:36 --> Form Validation Class Initialized
INFO - 2017-06-15 15:08:36 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:08:36 --> Helper loaded: url_helper
INFO - 2017-06-15 15:08:36 --> Model Class Initialized
INFO - 2017-06-15 15:08:36 --> Model Class Initialized
INFO - 2017-06-15 15:08:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:08:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:08:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:08:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:08:36 --> Final output sent to browser
DEBUG - 2017-06-15 15:08:36 --> Total execution time: 0.0526
INFO - 2017-06-15 15:09:11 --> Config Class Initialized
INFO - 2017-06-15 15:09:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:09:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:09:11 --> Utf8 Class Initialized
INFO - 2017-06-15 15:09:11 --> URI Class Initialized
INFO - 2017-06-15 15:09:11 --> Router Class Initialized
INFO - 2017-06-15 15:09:11 --> Output Class Initialized
INFO - 2017-06-15 15:09:11 --> Security Class Initialized
DEBUG - 2017-06-15 15:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:09:11 --> Input Class Initialized
INFO - 2017-06-15 15:09:11 --> Language Class Initialized
INFO - 2017-06-15 15:09:11 --> Loader Class Initialized
INFO - 2017-06-15 15:09:11 --> Helper loaded: common_helper
INFO - 2017-06-15 15:09:11 --> Database Driver Class Initialized
INFO - 2017-06-15 15:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:09:11 --> Email Class Initialized
INFO - 2017-06-15 15:09:11 --> Controller Class Initialized
INFO - 2017-06-15 15:09:11 --> Helper loaded: form_helper
INFO - 2017-06-15 15:09:11 --> Form Validation Class Initialized
INFO - 2017-06-15 15:09:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:09:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:09:11 --> Helper loaded: url_helper
INFO - 2017-06-15 15:09:11 --> Model Class Initialized
INFO - 2017-06-15 15:09:11 --> Model Class Initialized
INFO - 2017-06-15 15:09:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:09:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:09:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:09:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:09:11 --> Final output sent to browser
DEBUG - 2017-06-15 15:09:11 --> Total execution time: 0.0559
INFO - 2017-06-15 15:09:12 --> Config Class Initialized
INFO - 2017-06-15 15:09:12 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:09:12 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:09:12 --> Utf8 Class Initialized
INFO - 2017-06-15 15:09:12 --> URI Class Initialized
INFO - 2017-06-15 15:09:12 --> Router Class Initialized
INFO - 2017-06-15 15:09:12 --> Output Class Initialized
INFO - 2017-06-15 15:09:12 --> Security Class Initialized
DEBUG - 2017-06-15 15:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:09:12 --> Input Class Initialized
INFO - 2017-06-15 15:09:12 --> Language Class Initialized
INFO - 2017-06-15 15:09:12 --> Loader Class Initialized
INFO - 2017-06-15 15:09:12 --> Helper loaded: common_helper
INFO - 2017-06-15 15:09:12 --> Database Driver Class Initialized
INFO - 2017-06-15 15:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:09:12 --> Email Class Initialized
INFO - 2017-06-15 15:09:12 --> Controller Class Initialized
INFO - 2017-06-15 15:09:12 --> Helper loaded: form_helper
INFO - 2017-06-15 15:09:12 --> Form Validation Class Initialized
INFO - 2017-06-15 15:09:12 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:09:12 --> Helper loaded: url_helper
INFO - 2017-06-15 15:09:12 --> Model Class Initialized
INFO - 2017-06-15 15:09:12 --> Model Class Initialized
INFO - 2017-06-15 15:10:14 --> Config Class Initialized
INFO - 2017-06-15 15:10:14 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:14 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:14 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:14 --> URI Class Initialized
INFO - 2017-06-15 15:10:14 --> Router Class Initialized
INFO - 2017-06-15 15:10:14 --> Output Class Initialized
INFO - 2017-06-15 15:10:14 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:14 --> Input Class Initialized
INFO - 2017-06-15 15:10:14 --> Language Class Initialized
INFO - 2017-06-15 15:10:14 --> Loader Class Initialized
INFO - 2017-06-15 15:10:14 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:14 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:14 --> Email Class Initialized
INFO - 2017-06-15 15:10:14 --> Controller Class Initialized
INFO - 2017-06-15 15:10:14 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:14 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:14 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:14 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:14 --> Model Class Initialized
INFO - 2017-06-15 15:10:14 --> Model Class Initialized
INFO - 2017-06-15 15:10:15 --> Config Class Initialized
INFO - 2017-06-15 15:10:15 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:15 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:15 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:15 --> URI Class Initialized
INFO - 2017-06-15 15:10:15 --> Router Class Initialized
INFO - 2017-06-15 15:10:15 --> Output Class Initialized
INFO - 2017-06-15 15:10:15 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:15 --> Input Class Initialized
INFO - 2017-06-15 15:10:15 --> Language Class Initialized
INFO - 2017-06-15 15:10:15 --> Loader Class Initialized
INFO - 2017-06-15 15:10:15 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:15 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:15 --> Email Class Initialized
INFO - 2017-06-15 15:10:15 --> Controller Class Initialized
INFO - 2017-06-15 15:10:15 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:15 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:15 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:15 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:15 --> Model Class Initialized
INFO - 2017-06-15 15:10:15 --> Model Class Initialized
INFO - 2017-06-15 15:10:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:10:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:10:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:10:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:10:15 --> Final output sent to browser
DEBUG - 2017-06-15 15:10:15 --> Total execution time: 0.0470
INFO - 2017-06-15 15:10:18 --> Config Class Initialized
INFO - 2017-06-15 15:10:18 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:18 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:18 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:18 --> URI Class Initialized
INFO - 2017-06-15 15:10:18 --> Router Class Initialized
INFO - 2017-06-15 15:10:18 --> Output Class Initialized
INFO - 2017-06-15 15:10:18 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:18 --> Input Class Initialized
INFO - 2017-06-15 15:10:18 --> Language Class Initialized
INFO - 2017-06-15 15:10:18 --> Loader Class Initialized
INFO - 2017-06-15 15:10:18 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:18 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:18 --> Email Class Initialized
INFO - 2017-06-15 15:10:18 --> Controller Class Initialized
INFO - 2017-06-15 15:10:18 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:18 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:18 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:18 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:18 --> Model Class Initialized
INFO - 2017-06-15 15:10:18 --> Model Class Initialized
INFO - 2017-06-15 15:10:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:10:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:10:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:10:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:10:18 --> Final output sent to browser
DEBUG - 2017-06-15 15:10:18 --> Total execution time: 0.0481
INFO - 2017-06-15 15:10:25 --> Config Class Initialized
INFO - 2017-06-15 15:10:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:25 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:25 --> URI Class Initialized
INFO - 2017-06-15 15:10:25 --> Router Class Initialized
INFO - 2017-06-15 15:10:25 --> Output Class Initialized
INFO - 2017-06-15 15:10:25 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:25 --> Input Class Initialized
INFO - 2017-06-15 15:10:25 --> Language Class Initialized
INFO - 2017-06-15 15:10:25 --> Loader Class Initialized
INFO - 2017-06-15 15:10:25 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:25 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:25 --> Email Class Initialized
INFO - 2017-06-15 15:10:25 --> Controller Class Initialized
INFO - 2017-06-15 15:10:25 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:25 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:25 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:25 --> Model Class Initialized
INFO - 2017-06-15 15:10:25 --> Model Class Initialized
INFO - 2017-06-15 15:10:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:10:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:10:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:10:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:10:25 --> Final output sent to browser
DEBUG - 2017-06-15 15:10:25 --> Total execution time: 0.0471
INFO - 2017-06-15 15:10:27 --> Config Class Initialized
INFO - 2017-06-15 15:10:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:27 --> URI Class Initialized
INFO - 2017-06-15 15:10:27 --> Router Class Initialized
INFO - 2017-06-15 15:10:27 --> Output Class Initialized
INFO - 2017-06-15 15:10:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:27 --> Input Class Initialized
INFO - 2017-06-15 15:10:27 --> Language Class Initialized
INFO - 2017-06-15 15:10:27 --> Loader Class Initialized
INFO - 2017-06-15 15:10:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:27 --> Email Class Initialized
INFO - 2017-06-15 15:10:27 --> Controller Class Initialized
INFO - 2017-06-15 15:10:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:27 --> Model Class Initialized
INFO - 2017-06-15 15:10:27 --> Model Class Initialized
INFO - 2017-06-15 15:10:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:10:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:10:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:10:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:10:27 --> Final output sent to browser
DEBUG - 2017-06-15 15:10:27 --> Total execution time: 0.0479
INFO - 2017-06-15 15:10:54 --> Config Class Initialized
INFO - 2017-06-15 15:10:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:54 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:54 --> URI Class Initialized
INFO - 2017-06-15 15:10:54 --> Router Class Initialized
INFO - 2017-06-15 15:10:54 --> Output Class Initialized
INFO - 2017-06-15 15:10:54 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:54 --> Input Class Initialized
INFO - 2017-06-15 15:10:54 --> Language Class Initialized
INFO - 2017-06-15 15:10:54 --> Loader Class Initialized
INFO - 2017-06-15 15:10:54 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:54 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:54 --> Email Class Initialized
INFO - 2017-06-15 15:10:54 --> Controller Class Initialized
INFO - 2017-06-15 15:10:54 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:54 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:54 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:54 --> Model Class Initialized
INFO - 2017-06-15 15:10:54 --> Model Class Initialized
INFO - 2017-06-15 15:10:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:10:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:10:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:10:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:10:54 --> Final output sent to browser
DEBUG - 2017-06-15 15:10:54 --> Total execution time: 0.0471
INFO - 2017-06-15 15:10:55 --> Config Class Initialized
INFO - 2017-06-15 15:10:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:10:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:10:55 --> Utf8 Class Initialized
INFO - 2017-06-15 15:10:55 --> URI Class Initialized
INFO - 2017-06-15 15:10:55 --> Router Class Initialized
INFO - 2017-06-15 15:10:55 --> Output Class Initialized
INFO - 2017-06-15 15:10:55 --> Security Class Initialized
DEBUG - 2017-06-15 15:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:10:55 --> Input Class Initialized
INFO - 2017-06-15 15:10:55 --> Language Class Initialized
INFO - 2017-06-15 15:10:55 --> Loader Class Initialized
INFO - 2017-06-15 15:10:55 --> Helper loaded: common_helper
INFO - 2017-06-15 15:10:55 --> Database Driver Class Initialized
INFO - 2017-06-15 15:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:10:55 --> Email Class Initialized
INFO - 2017-06-15 15:10:55 --> Controller Class Initialized
INFO - 2017-06-15 15:10:55 --> Helper loaded: form_helper
INFO - 2017-06-15 15:10:55 --> Form Validation Class Initialized
INFO - 2017-06-15 15:10:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:10:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:10:55 --> Helper loaded: url_helper
INFO - 2017-06-15 15:10:55 --> Model Class Initialized
INFO - 2017-06-15 15:10:55 --> Model Class Initialized
INFO - 2017-06-15 15:14:32 --> Config Class Initialized
INFO - 2017-06-15 15:14:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:14:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:14:32 --> Utf8 Class Initialized
INFO - 2017-06-15 15:14:32 --> URI Class Initialized
INFO - 2017-06-15 15:14:32 --> Router Class Initialized
INFO - 2017-06-15 15:14:32 --> Output Class Initialized
INFO - 2017-06-15 15:14:32 --> Security Class Initialized
DEBUG - 2017-06-15 15:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:14:32 --> Input Class Initialized
INFO - 2017-06-15 15:14:32 --> Language Class Initialized
INFO - 2017-06-15 15:14:32 --> Loader Class Initialized
INFO - 2017-06-15 15:14:32 --> Helper loaded: common_helper
INFO - 2017-06-15 15:14:32 --> Database Driver Class Initialized
INFO - 2017-06-15 15:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:14:32 --> Email Class Initialized
INFO - 2017-06-15 15:14:32 --> Controller Class Initialized
INFO - 2017-06-15 15:14:32 --> Helper loaded: form_helper
INFO - 2017-06-15 15:14:32 --> Form Validation Class Initialized
INFO - 2017-06-15 15:14:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:14:32 --> Helper loaded: url_helper
INFO - 2017-06-15 15:14:32 --> Model Class Initialized
INFO - 2017-06-15 15:14:32 --> Model Class Initialized
INFO - 2017-06-15 15:14:32 --> Config Class Initialized
INFO - 2017-06-15 15:14:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:14:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:14:32 --> Utf8 Class Initialized
INFO - 2017-06-15 15:14:32 --> URI Class Initialized
INFO - 2017-06-15 15:14:32 --> Router Class Initialized
INFO - 2017-06-15 15:14:32 --> Output Class Initialized
INFO - 2017-06-15 15:14:32 --> Security Class Initialized
DEBUG - 2017-06-15 15:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:14:32 --> Input Class Initialized
INFO - 2017-06-15 15:14:32 --> Language Class Initialized
INFO - 2017-06-15 15:14:32 --> Loader Class Initialized
INFO - 2017-06-15 15:14:32 --> Helper loaded: common_helper
INFO - 2017-06-15 15:14:32 --> Database Driver Class Initialized
INFO - 2017-06-15 15:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:14:32 --> Email Class Initialized
INFO - 2017-06-15 15:14:32 --> Controller Class Initialized
INFO - 2017-06-15 15:14:32 --> Helper loaded: form_helper
INFO - 2017-06-15 15:14:32 --> Form Validation Class Initialized
INFO - 2017-06-15 15:14:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:14:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:14:32 --> Helper loaded: url_helper
INFO - 2017-06-15 15:14:32 --> Model Class Initialized
INFO - 2017-06-15 15:14:32 --> Model Class Initialized
INFO - 2017-06-15 15:14:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:14:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
ERROR - 2017-06-15 15:14:32 --> Undefined variable: message
ERROR - 2017-06-15 15:14:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\bloodApp\application\views\profile.php 24
INFO - 2017-06-15 15:14:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:14:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:14:32 --> Final output sent to browser
DEBUG - 2017-06-15 15:14:32 --> Total execution time: 0.0765
INFO - 2017-06-15 15:15:59 --> Config Class Initialized
INFO - 2017-06-15 15:15:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:15:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:15:59 --> Utf8 Class Initialized
INFO - 2017-06-15 15:15:59 --> URI Class Initialized
INFO - 2017-06-15 15:15:59 --> Router Class Initialized
INFO - 2017-06-15 15:15:59 --> Output Class Initialized
INFO - 2017-06-15 15:15:59 --> Security Class Initialized
DEBUG - 2017-06-15 15:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:15:59 --> Input Class Initialized
INFO - 2017-06-15 15:15:59 --> Language Class Initialized
INFO - 2017-06-15 15:15:59 --> Loader Class Initialized
INFO - 2017-06-15 15:15:59 --> Helper loaded: common_helper
INFO - 2017-06-15 15:15:59 --> Database Driver Class Initialized
INFO - 2017-06-15 15:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:15:59 --> Email Class Initialized
INFO - 2017-06-15 15:15:59 --> Controller Class Initialized
INFO - 2017-06-15 15:15:59 --> Helper loaded: form_helper
INFO - 2017-06-15 15:15:59 --> Form Validation Class Initialized
INFO - 2017-06-15 15:15:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:15:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:15:59 --> Helper loaded: url_helper
INFO - 2017-06-15 15:15:59 --> Model Class Initialized
INFO - 2017-06-15 15:15:59 --> Model Class Initialized
INFO - 2017-06-15 15:15:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:15:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:15:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:15:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:15:59 --> Final output sent to browser
DEBUG - 2017-06-15 15:15:59 --> Total execution time: 0.0500
INFO - 2017-06-15 15:16:00 --> Config Class Initialized
INFO - 2017-06-15 15:16:00 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:00 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:00 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:00 --> URI Class Initialized
INFO - 2017-06-15 15:16:00 --> Router Class Initialized
INFO - 2017-06-15 15:16:00 --> Output Class Initialized
INFO - 2017-06-15 15:16:00 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:00 --> Input Class Initialized
INFO - 2017-06-15 15:16:00 --> Language Class Initialized
INFO - 2017-06-15 15:16:00 --> Loader Class Initialized
INFO - 2017-06-15 15:16:00 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:00 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:00 --> Email Class Initialized
INFO - 2017-06-15 15:16:00 --> Controller Class Initialized
INFO - 2017-06-15 15:16:00 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:00 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:00 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:00 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:00 --> Model Class Initialized
INFO - 2017-06-15 15:16:00 --> Model Class Initialized
INFO - 2017-06-15 15:16:00 --> Config Class Initialized
INFO - 2017-06-15 15:16:00 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:00 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:00 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:00 --> URI Class Initialized
INFO - 2017-06-15 15:16:00 --> Router Class Initialized
INFO - 2017-06-15 15:16:00 --> Output Class Initialized
INFO - 2017-06-15 15:16:00 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:00 --> Input Class Initialized
INFO - 2017-06-15 15:16:00 --> Language Class Initialized
INFO - 2017-06-15 15:16:00 --> Loader Class Initialized
INFO - 2017-06-15 15:16:00 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:01 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:01 --> Email Class Initialized
INFO - 2017-06-15 15:16:01 --> Controller Class Initialized
INFO - 2017-06-15 15:16:01 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:01 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:01 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:01 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:01 --> Model Class Initialized
INFO - 2017-06-15 15:16:01 --> Model Class Initialized
INFO - 2017-06-15 15:16:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:01 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:01 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:01 --> Total execution time: 0.0541
INFO - 2017-06-15 15:16:05 --> Config Class Initialized
INFO - 2017-06-15 15:16:05 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:05 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:05 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:05 --> URI Class Initialized
INFO - 2017-06-15 15:16:05 --> Router Class Initialized
INFO - 2017-06-15 15:16:05 --> Output Class Initialized
INFO - 2017-06-15 15:16:05 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:05 --> Input Class Initialized
INFO - 2017-06-15 15:16:05 --> Language Class Initialized
INFO - 2017-06-15 15:16:05 --> Loader Class Initialized
INFO - 2017-06-15 15:16:05 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:05 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:05 --> Email Class Initialized
INFO - 2017-06-15 15:16:05 --> Controller Class Initialized
INFO - 2017-06-15 15:16:05 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:05 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:05 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:05 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:05 --> Model Class Initialized
INFO - 2017-06-15 15:16:05 --> Model Class Initialized
INFO - 2017-06-15 15:16:05 --> Config Class Initialized
INFO - 2017-06-15 15:16:05 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:05 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:05 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:05 --> URI Class Initialized
INFO - 2017-06-15 15:16:05 --> Router Class Initialized
INFO - 2017-06-15 15:16:05 --> Output Class Initialized
INFO - 2017-06-15 15:16:05 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:05 --> Input Class Initialized
INFO - 2017-06-15 15:16:05 --> Language Class Initialized
INFO - 2017-06-15 15:16:05 --> Loader Class Initialized
INFO - 2017-06-15 15:16:05 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:05 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:05 --> Email Class Initialized
INFO - 2017-06-15 15:16:05 --> Controller Class Initialized
INFO - 2017-06-15 15:16:05 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:05 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:05 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:05 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:05 --> Model Class Initialized
INFO - 2017-06-15 15:16:05 --> Model Class Initialized
INFO - 2017-06-15 15:16:05 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:05 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:05 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:05 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:05 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:05 --> Total execution time: 0.0800
INFO - 2017-06-15 15:16:21 --> Config Class Initialized
INFO - 2017-06-15 15:16:21 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:21 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:21 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:21 --> URI Class Initialized
INFO - 2017-06-15 15:16:21 --> Router Class Initialized
INFO - 2017-06-15 15:16:21 --> Output Class Initialized
INFO - 2017-06-15 15:16:21 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:21 --> Input Class Initialized
INFO - 2017-06-15 15:16:21 --> Language Class Initialized
INFO - 2017-06-15 15:16:21 --> Loader Class Initialized
INFO - 2017-06-15 15:16:21 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:21 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:21 --> Email Class Initialized
INFO - 2017-06-15 15:16:21 --> Controller Class Initialized
INFO - 2017-06-15 15:16:21 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:21 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:21 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:21 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:21 --> Model Class Initialized
INFO - 2017-06-15 15:16:21 --> Model Class Initialized
INFO - 2017-06-15 15:16:21 --> Config Class Initialized
INFO - 2017-06-15 15:16:21 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:21 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:21 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:21 --> URI Class Initialized
INFO - 2017-06-15 15:16:21 --> Router Class Initialized
INFO - 2017-06-15 15:16:21 --> Output Class Initialized
INFO - 2017-06-15 15:16:21 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:21 --> Input Class Initialized
INFO - 2017-06-15 15:16:21 --> Language Class Initialized
INFO - 2017-06-15 15:16:21 --> Loader Class Initialized
INFO - 2017-06-15 15:16:21 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:21 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:21 --> Email Class Initialized
INFO - 2017-06-15 15:16:21 --> Controller Class Initialized
INFO - 2017-06-15 15:16:21 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:21 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:21 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:21 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:21 --> Model Class Initialized
INFO - 2017-06-15 15:16:21 --> Model Class Initialized
INFO - 2017-06-15 15:16:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:21 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:21 --> Total execution time: 0.0597
INFO - 2017-06-15 15:16:24 --> Config Class Initialized
INFO - 2017-06-15 15:16:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:24 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:24 --> URI Class Initialized
INFO - 2017-06-15 15:16:24 --> Router Class Initialized
INFO - 2017-06-15 15:16:24 --> Output Class Initialized
INFO - 2017-06-15 15:16:24 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:24 --> Input Class Initialized
INFO - 2017-06-15 15:16:24 --> Language Class Initialized
INFO - 2017-06-15 15:16:24 --> Loader Class Initialized
INFO - 2017-06-15 15:16:24 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:24 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:24 --> Email Class Initialized
INFO - 2017-06-15 15:16:24 --> Controller Class Initialized
INFO - 2017-06-15 15:16:24 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:24 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:24 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:24 --> Model Class Initialized
INFO - 2017-06-15 15:16:24 --> Model Class Initialized
INFO - 2017-06-15 15:16:24 --> Config Class Initialized
INFO - 2017-06-15 15:16:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:24 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:24 --> URI Class Initialized
INFO - 2017-06-15 15:16:24 --> Router Class Initialized
INFO - 2017-06-15 15:16:24 --> Output Class Initialized
INFO - 2017-06-15 15:16:24 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:24 --> Input Class Initialized
INFO - 2017-06-15 15:16:24 --> Language Class Initialized
INFO - 2017-06-15 15:16:24 --> Loader Class Initialized
INFO - 2017-06-15 15:16:24 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:24 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:24 --> Email Class Initialized
INFO - 2017-06-15 15:16:24 --> Controller Class Initialized
INFO - 2017-06-15 15:16:24 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:24 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:24 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:24 --> Model Class Initialized
INFO - 2017-06-15 15:16:24 --> Model Class Initialized
INFO - 2017-06-15 15:16:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:24 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:24 --> Total execution time: 0.0690
INFO - 2017-06-15 15:16:29 --> Config Class Initialized
INFO - 2017-06-15 15:16:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:29 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:29 --> URI Class Initialized
INFO - 2017-06-15 15:16:29 --> Router Class Initialized
INFO - 2017-06-15 15:16:29 --> Output Class Initialized
INFO - 2017-06-15 15:16:29 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:29 --> Input Class Initialized
INFO - 2017-06-15 15:16:29 --> Language Class Initialized
INFO - 2017-06-15 15:16:29 --> Loader Class Initialized
INFO - 2017-06-15 15:16:29 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:29 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:29 --> Email Class Initialized
INFO - 2017-06-15 15:16:29 --> Controller Class Initialized
INFO - 2017-06-15 15:16:29 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:29 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:29 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:29 --> Model Class Initialized
INFO - 2017-06-15 15:16:29 --> Model Class Initialized
INFO - 2017-06-15 15:16:29 --> Config Class Initialized
INFO - 2017-06-15 15:16:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:29 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:29 --> URI Class Initialized
INFO - 2017-06-15 15:16:29 --> Router Class Initialized
INFO - 2017-06-15 15:16:29 --> Output Class Initialized
INFO - 2017-06-15 15:16:29 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:29 --> Input Class Initialized
INFO - 2017-06-15 15:16:29 --> Language Class Initialized
INFO - 2017-06-15 15:16:29 --> Loader Class Initialized
INFO - 2017-06-15 15:16:29 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:29 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:29 --> Email Class Initialized
INFO - 2017-06-15 15:16:29 --> Controller Class Initialized
INFO - 2017-06-15 15:16:29 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:29 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:29 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:29 --> Model Class Initialized
INFO - 2017-06-15 15:16:29 --> Model Class Initialized
INFO - 2017-06-15 15:16:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:29 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:29 --> Total execution time: 0.0673
INFO - 2017-06-15 15:16:32 --> Config Class Initialized
INFO - 2017-06-15 15:16:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:32 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:32 --> URI Class Initialized
INFO - 2017-06-15 15:16:32 --> Router Class Initialized
INFO - 2017-06-15 15:16:32 --> Output Class Initialized
INFO - 2017-06-15 15:16:32 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:32 --> Input Class Initialized
INFO - 2017-06-15 15:16:32 --> Language Class Initialized
INFO - 2017-06-15 15:16:32 --> Loader Class Initialized
INFO - 2017-06-15 15:16:32 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:32 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:32 --> Email Class Initialized
INFO - 2017-06-15 15:16:32 --> Controller Class Initialized
INFO - 2017-06-15 15:16:32 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:32 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:32 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:32 --> Model Class Initialized
INFO - 2017-06-15 15:16:32 --> Model Class Initialized
INFO - 2017-06-15 15:16:32 --> Config Class Initialized
INFO - 2017-06-15 15:16:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:32 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:32 --> URI Class Initialized
INFO - 2017-06-15 15:16:32 --> Router Class Initialized
INFO - 2017-06-15 15:16:32 --> Output Class Initialized
INFO - 2017-06-15 15:16:32 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:32 --> Input Class Initialized
INFO - 2017-06-15 15:16:32 --> Language Class Initialized
INFO - 2017-06-15 15:16:32 --> Loader Class Initialized
INFO - 2017-06-15 15:16:32 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:32 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:32 --> Email Class Initialized
INFO - 2017-06-15 15:16:32 --> Controller Class Initialized
INFO - 2017-06-15 15:16:32 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:32 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:32 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:32 --> Model Class Initialized
INFO - 2017-06-15 15:16:32 --> Model Class Initialized
INFO - 2017-06-15 15:16:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:32 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:32 --> Total execution time: 0.0749
INFO - 2017-06-15 15:16:59 --> Config Class Initialized
INFO - 2017-06-15 15:16:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:16:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:16:59 --> Utf8 Class Initialized
INFO - 2017-06-15 15:16:59 --> URI Class Initialized
INFO - 2017-06-15 15:16:59 --> Router Class Initialized
INFO - 2017-06-15 15:16:59 --> Output Class Initialized
INFO - 2017-06-15 15:16:59 --> Security Class Initialized
DEBUG - 2017-06-15 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:16:59 --> Input Class Initialized
INFO - 2017-06-15 15:16:59 --> Language Class Initialized
INFO - 2017-06-15 15:16:59 --> Loader Class Initialized
INFO - 2017-06-15 15:16:59 --> Helper loaded: common_helper
INFO - 2017-06-15 15:16:59 --> Database Driver Class Initialized
INFO - 2017-06-15 15:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:16:59 --> Email Class Initialized
INFO - 2017-06-15 15:16:59 --> Controller Class Initialized
INFO - 2017-06-15 15:16:59 --> Helper loaded: form_helper
INFO - 2017-06-15 15:16:59 --> Form Validation Class Initialized
INFO - 2017-06-15 15:16:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:16:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:16:59 --> Helper loaded: url_helper
INFO - 2017-06-15 15:16:59 --> Model Class Initialized
INFO - 2017-06-15 15:16:59 --> Model Class Initialized
INFO - 2017-06-15 15:16:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:16:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:16:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:16:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:16:59 --> Final output sent to browser
DEBUG - 2017-06-15 15:16:59 --> Total execution time: 0.0479
INFO - 2017-06-15 15:17:51 --> Config Class Initialized
INFO - 2017-06-15 15:17:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:17:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:17:51 --> Utf8 Class Initialized
INFO - 2017-06-15 15:17:51 --> URI Class Initialized
INFO - 2017-06-15 15:17:51 --> Router Class Initialized
INFO - 2017-06-15 15:17:51 --> Output Class Initialized
INFO - 2017-06-15 15:17:51 --> Security Class Initialized
DEBUG - 2017-06-15 15:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:17:51 --> Input Class Initialized
INFO - 2017-06-15 15:17:51 --> Language Class Initialized
INFO - 2017-06-15 15:17:51 --> Loader Class Initialized
INFO - 2017-06-15 15:17:51 --> Helper loaded: common_helper
INFO - 2017-06-15 15:17:51 --> Database Driver Class Initialized
INFO - 2017-06-15 15:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:17:51 --> Email Class Initialized
INFO - 2017-06-15 15:17:51 --> Controller Class Initialized
INFO - 2017-06-15 15:17:51 --> Helper loaded: form_helper
INFO - 2017-06-15 15:17:51 --> Form Validation Class Initialized
INFO - 2017-06-15 15:17:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:17:51 --> Helper loaded: url_helper
INFO - 2017-06-15 15:17:51 --> Model Class Initialized
INFO - 2017-06-15 15:17:51 --> Model Class Initialized
INFO - 2017-06-15 15:17:51 --> Config Class Initialized
INFO - 2017-06-15 15:17:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:17:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:17:51 --> Utf8 Class Initialized
INFO - 2017-06-15 15:17:51 --> URI Class Initialized
INFO - 2017-06-15 15:17:51 --> Router Class Initialized
INFO - 2017-06-15 15:17:51 --> Output Class Initialized
INFO - 2017-06-15 15:17:51 --> Security Class Initialized
DEBUG - 2017-06-15 15:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:17:51 --> Input Class Initialized
INFO - 2017-06-15 15:17:51 --> Language Class Initialized
INFO - 2017-06-15 15:17:51 --> Loader Class Initialized
INFO - 2017-06-15 15:17:51 --> Helper loaded: common_helper
INFO - 2017-06-15 15:17:51 --> Database Driver Class Initialized
INFO - 2017-06-15 15:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:17:51 --> Email Class Initialized
INFO - 2017-06-15 15:17:51 --> Controller Class Initialized
INFO - 2017-06-15 15:17:51 --> Helper loaded: form_helper
INFO - 2017-06-15 15:17:51 --> Form Validation Class Initialized
INFO - 2017-06-15 15:17:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:17:51 --> Helper loaded: url_helper
INFO - 2017-06-15 15:17:51 --> Model Class Initialized
INFO - 2017-06-15 15:17:51 --> Model Class Initialized
INFO - 2017-06-15 15:17:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:17:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:17:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:17:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:17:51 --> Final output sent to browser
DEBUG - 2017-06-15 15:17:51 --> Total execution time: 0.0577
INFO - 2017-06-15 15:18:09 --> Config Class Initialized
INFO - 2017-06-15 15:18:09 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:18:09 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:18:09 --> Utf8 Class Initialized
INFO - 2017-06-15 15:18:09 --> URI Class Initialized
INFO - 2017-06-15 15:18:09 --> Router Class Initialized
INFO - 2017-06-15 15:18:09 --> Output Class Initialized
INFO - 2017-06-15 15:18:09 --> Security Class Initialized
DEBUG - 2017-06-15 15:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:18:09 --> Input Class Initialized
INFO - 2017-06-15 15:18:09 --> Language Class Initialized
INFO - 2017-06-15 15:18:09 --> Loader Class Initialized
INFO - 2017-06-15 15:18:09 --> Helper loaded: common_helper
INFO - 2017-06-15 15:18:09 --> Database Driver Class Initialized
INFO - 2017-06-15 15:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:18:09 --> Email Class Initialized
INFO - 2017-06-15 15:18:09 --> Controller Class Initialized
INFO - 2017-06-15 15:18:09 --> Helper loaded: form_helper
INFO - 2017-06-15 15:18:09 --> Form Validation Class Initialized
INFO - 2017-06-15 15:18:09 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:18:09 --> Helper loaded: url_helper
INFO - 2017-06-15 15:18:09 --> Model Class Initialized
INFO - 2017-06-15 15:18:09 --> Model Class Initialized
INFO - 2017-06-15 15:18:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:18:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:18:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:18:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:18:09 --> Final output sent to browser
DEBUG - 2017-06-15 15:18:09 --> Total execution time: 0.0495
INFO - 2017-06-15 15:18:11 --> Config Class Initialized
INFO - 2017-06-15 15:18:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:18:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:18:11 --> Utf8 Class Initialized
INFO - 2017-06-15 15:18:11 --> URI Class Initialized
INFO - 2017-06-15 15:18:11 --> Router Class Initialized
INFO - 2017-06-15 15:18:11 --> Output Class Initialized
INFO - 2017-06-15 15:18:11 --> Security Class Initialized
DEBUG - 2017-06-15 15:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:18:11 --> Input Class Initialized
INFO - 2017-06-15 15:18:11 --> Language Class Initialized
INFO - 2017-06-15 15:18:11 --> Loader Class Initialized
INFO - 2017-06-15 15:18:11 --> Helper loaded: common_helper
INFO - 2017-06-15 15:18:11 --> Database Driver Class Initialized
INFO - 2017-06-15 15:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:18:11 --> Email Class Initialized
INFO - 2017-06-15 15:18:11 --> Controller Class Initialized
INFO - 2017-06-15 15:18:11 --> Helper loaded: form_helper
INFO - 2017-06-15 15:18:11 --> Form Validation Class Initialized
INFO - 2017-06-15 15:18:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:18:11 --> Helper loaded: url_helper
INFO - 2017-06-15 15:18:11 --> Model Class Initialized
INFO - 2017-06-15 15:18:11 --> Model Class Initialized
INFO - 2017-06-15 15:18:11 --> Config Class Initialized
INFO - 2017-06-15 15:18:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:18:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:18:11 --> Utf8 Class Initialized
INFO - 2017-06-15 15:18:11 --> URI Class Initialized
INFO - 2017-06-15 15:18:11 --> Router Class Initialized
INFO - 2017-06-15 15:18:11 --> Output Class Initialized
INFO - 2017-06-15 15:18:11 --> Security Class Initialized
DEBUG - 2017-06-15 15:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:18:11 --> Input Class Initialized
INFO - 2017-06-15 15:18:11 --> Language Class Initialized
INFO - 2017-06-15 15:18:11 --> Loader Class Initialized
INFO - 2017-06-15 15:18:11 --> Helper loaded: common_helper
INFO - 2017-06-15 15:18:11 --> Database Driver Class Initialized
INFO - 2017-06-15 15:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:18:11 --> Email Class Initialized
INFO - 2017-06-15 15:18:11 --> Controller Class Initialized
INFO - 2017-06-15 15:18:11 --> Helper loaded: form_helper
INFO - 2017-06-15 15:18:11 --> Form Validation Class Initialized
INFO - 2017-06-15 15:18:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:18:11 --> Helper loaded: url_helper
INFO - 2017-06-15 15:18:11 --> Model Class Initialized
INFO - 2017-06-15 15:18:11 --> Model Class Initialized
INFO - 2017-06-15 15:18:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:18:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:18:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:18:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:18:11 --> Final output sent to browser
DEBUG - 2017-06-15 15:18:11 --> Total execution time: 0.0588
INFO - 2017-06-15 15:18:55 --> Config Class Initialized
INFO - 2017-06-15 15:18:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:18:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:18:55 --> Utf8 Class Initialized
INFO - 2017-06-15 15:18:55 --> URI Class Initialized
INFO - 2017-06-15 15:18:55 --> Router Class Initialized
INFO - 2017-06-15 15:18:55 --> Output Class Initialized
INFO - 2017-06-15 15:18:55 --> Security Class Initialized
DEBUG - 2017-06-15 15:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:18:55 --> Input Class Initialized
INFO - 2017-06-15 15:18:55 --> Language Class Initialized
INFO - 2017-06-15 15:18:55 --> Loader Class Initialized
INFO - 2017-06-15 15:18:55 --> Helper loaded: common_helper
INFO - 2017-06-15 15:18:55 --> Database Driver Class Initialized
INFO - 2017-06-15 15:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:18:55 --> Email Class Initialized
INFO - 2017-06-15 15:18:55 --> Controller Class Initialized
INFO - 2017-06-15 15:18:55 --> Helper loaded: form_helper
INFO - 2017-06-15 15:18:55 --> Form Validation Class Initialized
INFO - 2017-06-15 15:18:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:18:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:18:55 --> Helper loaded: url_helper
INFO - 2017-06-15 15:18:55 --> Model Class Initialized
INFO - 2017-06-15 15:18:55 --> Model Class Initialized
INFO - 2017-06-15 15:18:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:18:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:18:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:18:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:18:55 --> Final output sent to browser
DEBUG - 2017-06-15 15:18:55 --> Total execution time: 0.0490
INFO - 2017-06-15 15:19:25 --> Config Class Initialized
INFO - 2017-06-15 15:19:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:25 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:25 --> URI Class Initialized
INFO - 2017-06-15 15:19:25 --> Router Class Initialized
INFO - 2017-06-15 15:19:25 --> Output Class Initialized
INFO - 2017-06-15 15:19:25 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:25 --> Input Class Initialized
INFO - 2017-06-15 15:19:25 --> Language Class Initialized
INFO - 2017-06-15 15:19:25 --> Loader Class Initialized
INFO - 2017-06-15 15:19:25 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:25 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:25 --> Email Class Initialized
INFO - 2017-06-15 15:19:25 --> Controller Class Initialized
INFO - 2017-06-15 15:19:25 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:25 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:25 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:25 --> Model Class Initialized
INFO - 2017-06-15 15:19:25 --> Model Class Initialized
INFO - 2017-06-15 15:19:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:19:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:19:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:19:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:19:25 --> Final output sent to browser
DEBUG - 2017-06-15 15:19:25 --> Total execution time: 0.0522
INFO - 2017-06-15 15:19:27 --> Config Class Initialized
INFO - 2017-06-15 15:19:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:27 --> URI Class Initialized
INFO - 2017-06-15 15:19:27 --> Router Class Initialized
INFO - 2017-06-15 15:19:27 --> Output Class Initialized
INFO - 2017-06-15 15:19:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:27 --> Input Class Initialized
INFO - 2017-06-15 15:19:27 --> Language Class Initialized
INFO - 2017-06-15 15:19:27 --> Loader Class Initialized
INFO - 2017-06-15 15:19:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:27 --> Email Class Initialized
INFO - 2017-06-15 15:19:27 --> Controller Class Initialized
INFO - 2017-06-15 15:19:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:27 --> Model Class Initialized
INFO - 2017-06-15 15:19:27 --> Model Class Initialized
INFO - 2017-06-15 15:19:27 --> Config Class Initialized
INFO - 2017-06-15 15:19:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:27 --> URI Class Initialized
INFO - 2017-06-15 15:19:27 --> Router Class Initialized
INFO - 2017-06-15 15:19:27 --> Output Class Initialized
INFO - 2017-06-15 15:19:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:27 --> Input Class Initialized
INFO - 2017-06-15 15:19:27 --> Language Class Initialized
INFO - 2017-06-15 15:19:27 --> Loader Class Initialized
INFO - 2017-06-15 15:19:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:27 --> Email Class Initialized
INFO - 2017-06-15 15:19:27 --> Controller Class Initialized
INFO - 2017-06-15 15:19:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:27 --> Model Class Initialized
INFO - 2017-06-15 15:19:27 --> Model Class Initialized
INFO - 2017-06-15 15:19:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:19:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:19:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:19:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:19:27 --> Final output sent to browser
DEBUG - 2017-06-15 15:19:27 --> Total execution time: 0.0633
INFO - 2017-06-15 15:19:44 --> Config Class Initialized
INFO - 2017-06-15 15:19:44 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:44 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:44 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:44 --> URI Class Initialized
INFO - 2017-06-15 15:19:44 --> Router Class Initialized
INFO - 2017-06-15 15:19:44 --> Output Class Initialized
INFO - 2017-06-15 15:19:44 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:44 --> Input Class Initialized
INFO - 2017-06-15 15:19:44 --> Language Class Initialized
INFO - 2017-06-15 15:19:44 --> Loader Class Initialized
INFO - 2017-06-15 15:19:44 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:44 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:44 --> Email Class Initialized
INFO - 2017-06-15 15:19:44 --> Controller Class Initialized
INFO - 2017-06-15 15:19:44 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:44 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:44 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:44 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:44 --> Model Class Initialized
INFO - 2017-06-15 15:19:44 --> Model Class Initialized
INFO - 2017-06-15 15:19:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:19:44 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:19:45 --> Config Class Initialized
INFO - 2017-06-15 15:19:45 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:45 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:45 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:45 --> URI Class Initialized
INFO - 2017-06-15 15:19:45 --> Router Class Initialized
INFO - 2017-06-15 15:19:45 --> Output Class Initialized
INFO - 2017-06-15 15:19:45 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:45 --> Input Class Initialized
INFO - 2017-06-15 15:19:45 --> Language Class Initialized
INFO - 2017-06-15 15:19:45 --> Loader Class Initialized
INFO - 2017-06-15 15:19:45 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:45 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:45 --> Email Class Initialized
INFO - 2017-06-15 15:19:45 --> Controller Class Initialized
INFO - 2017-06-15 15:19:45 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:45 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:45 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:45 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:45 --> Model Class Initialized
INFO - 2017-06-15 15:19:45 --> Model Class Initialized
INFO - 2017-06-15 15:19:45 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:19:45 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:19:50 --> Config Class Initialized
INFO - 2017-06-15 15:19:50 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:50 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:50 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:50 --> URI Class Initialized
INFO - 2017-06-15 15:19:50 --> Router Class Initialized
INFO - 2017-06-15 15:19:50 --> Output Class Initialized
INFO - 2017-06-15 15:19:50 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:50 --> Input Class Initialized
INFO - 2017-06-15 15:19:50 --> Language Class Initialized
INFO - 2017-06-15 15:19:50 --> Loader Class Initialized
INFO - 2017-06-15 15:19:50 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:50 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:50 --> Email Class Initialized
INFO - 2017-06-15 15:19:50 --> Controller Class Initialized
INFO - 2017-06-15 15:19:50 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:50 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:50 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:50 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:50 --> Model Class Initialized
INFO - 2017-06-15 15:19:50 --> Model Class Initialized
INFO - 2017-06-15 15:19:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:19:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:19:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:19:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:19:50 --> Final output sent to browser
DEBUG - 2017-06-15 15:19:50 --> Total execution time: 0.0482
INFO - 2017-06-15 15:19:55 --> Config Class Initialized
INFO - 2017-06-15 15:19:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:55 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:55 --> URI Class Initialized
INFO - 2017-06-15 15:19:55 --> Router Class Initialized
INFO - 2017-06-15 15:19:55 --> Output Class Initialized
INFO - 2017-06-15 15:19:55 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:55 --> Input Class Initialized
INFO - 2017-06-15 15:19:55 --> Language Class Initialized
INFO - 2017-06-15 15:19:55 --> Loader Class Initialized
INFO - 2017-06-15 15:19:55 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:55 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:55 --> Email Class Initialized
INFO - 2017-06-15 15:19:55 --> Controller Class Initialized
INFO - 2017-06-15 15:19:55 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:55 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:55 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:55 --> Model Class Initialized
INFO - 2017-06-15 15:19:55 --> Model Class Initialized
INFO - 2017-06-15 15:19:55 --> Config Class Initialized
INFO - 2017-06-15 15:19:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:19:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:19:55 --> Utf8 Class Initialized
INFO - 2017-06-15 15:19:55 --> URI Class Initialized
INFO - 2017-06-15 15:19:55 --> Router Class Initialized
INFO - 2017-06-15 15:19:55 --> Output Class Initialized
INFO - 2017-06-15 15:19:55 --> Security Class Initialized
DEBUG - 2017-06-15 15:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:19:55 --> Input Class Initialized
INFO - 2017-06-15 15:19:55 --> Language Class Initialized
INFO - 2017-06-15 15:19:55 --> Loader Class Initialized
INFO - 2017-06-15 15:19:55 --> Helper loaded: common_helper
INFO - 2017-06-15 15:19:55 --> Database Driver Class Initialized
INFO - 2017-06-15 15:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:19:55 --> Email Class Initialized
INFO - 2017-06-15 15:19:55 --> Controller Class Initialized
INFO - 2017-06-15 15:19:55 --> Helper loaded: form_helper
INFO - 2017-06-15 15:19:55 --> Form Validation Class Initialized
INFO - 2017-06-15 15:19:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:19:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:19:55 --> Helper loaded: url_helper
INFO - 2017-06-15 15:19:55 --> Model Class Initialized
INFO - 2017-06-15 15:19:55 --> Model Class Initialized
INFO - 2017-06-15 15:19:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:19:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:20:15 --> Config Class Initialized
INFO - 2017-06-15 15:20:15 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:15 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:15 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:15 --> URI Class Initialized
INFO - 2017-06-15 15:20:15 --> Router Class Initialized
INFO - 2017-06-15 15:20:15 --> Output Class Initialized
INFO - 2017-06-15 15:20:15 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:15 --> Input Class Initialized
INFO - 2017-06-15 15:20:15 --> Language Class Initialized
INFO - 2017-06-15 15:20:15 --> Loader Class Initialized
INFO - 2017-06-15 15:20:15 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:15 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:15 --> Email Class Initialized
INFO - 2017-06-15 15:20:15 --> Controller Class Initialized
INFO - 2017-06-15 15:20:15 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:15 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:15 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:15 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:15 --> Model Class Initialized
INFO - 2017-06-15 15:20:15 --> Model Class Initialized
INFO - 2017-06-15 15:20:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:20:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:20:24 --> Config Class Initialized
INFO - 2017-06-15 15:20:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:24 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:24 --> URI Class Initialized
INFO - 2017-06-15 15:20:24 --> Router Class Initialized
INFO - 2017-06-15 15:20:24 --> Output Class Initialized
INFO - 2017-06-15 15:20:24 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:24 --> Input Class Initialized
INFO - 2017-06-15 15:20:24 --> Language Class Initialized
INFO - 2017-06-15 15:20:24 --> Loader Class Initialized
INFO - 2017-06-15 15:20:24 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:24 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:24 --> Email Class Initialized
INFO - 2017-06-15 15:20:24 --> Controller Class Initialized
INFO - 2017-06-15 15:20:24 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:24 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:24 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:24 --> Model Class Initialized
INFO - 2017-06-15 15:20:24 --> Model Class Initialized
INFO - 2017-06-15 15:20:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:20:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:20:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:20:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:20:24 --> Final output sent to browser
DEBUG - 2017-06-15 15:20:24 --> Total execution time: 0.0494
INFO - 2017-06-15 15:20:25 --> Config Class Initialized
INFO - 2017-06-15 15:20:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:25 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:25 --> URI Class Initialized
INFO - 2017-06-15 15:20:25 --> Router Class Initialized
INFO - 2017-06-15 15:20:25 --> Output Class Initialized
INFO - 2017-06-15 15:20:25 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:25 --> Input Class Initialized
INFO - 2017-06-15 15:20:25 --> Language Class Initialized
INFO - 2017-06-15 15:20:25 --> Loader Class Initialized
INFO - 2017-06-15 15:20:25 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:25 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:25 --> Email Class Initialized
INFO - 2017-06-15 15:20:25 --> Controller Class Initialized
INFO - 2017-06-15 15:20:25 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:25 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:25 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:25 --> Model Class Initialized
INFO - 2017-06-15 15:20:25 --> Model Class Initialized
INFO - 2017-06-15 15:20:25 --> Config Class Initialized
INFO - 2017-06-15 15:20:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:25 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:25 --> URI Class Initialized
INFO - 2017-06-15 15:20:25 --> Router Class Initialized
INFO - 2017-06-15 15:20:25 --> Output Class Initialized
INFO - 2017-06-15 15:20:25 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:25 --> Input Class Initialized
INFO - 2017-06-15 15:20:25 --> Language Class Initialized
INFO - 2017-06-15 15:20:25 --> Loader Class Initialized
INFO - 2017-06-15 15:20:25 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:25 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:25 --> Email Class Initialized
INFO - 2017-06-15 15:20:25 --> Controller Class Initialized
INFO - 2017-06-15 15:20:25 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:25 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:25 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:25 --> Model Class Initialized
INFO - 2017-06-15 15:20:25 --> Model Class Initialized
INFO - 2017-06-15 15:20:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:20:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:20:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:20:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:20:25 --> Final output sent to browser
DEBUG - 2017-06-15 15:20:25 --> Total execution time: 0.0699
INFO - 2017-06-15 15:20:26 --> Config Class Initialized
INFO - 2017-06-15 15:20:26 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:26 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:26 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:26 --> URI Class Initialized
INFO - 2017-06-15 15:20:26 --> Router Class Initialized
INFO - 2017-06-15 15:20:26 --> Output Class Initialized
INFO - 2017-06-15 15:20:26 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:26 --> Input Class Initialized
INFO - 2017-06-15 15:20:26 --> Language Class Initialized
INFO - 2017-06-15 15:20:26 --> Loader Class Initialized
INFO - 2017-06-15 15:20:26 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:26 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:26 --> Email Class Initialized
INFO - 2017-06-15 15:20:26 --> Controller Class Initialized
INFO - 2017-06-15 15:20:26 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:26 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:26 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:26 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:26 --> Model Class Initialized
INFO - 2017-06-15 15:20:26 --> Model Class Initialized
INFO - 2017-06-15 15:20:27 --> Config Class Initialized
INFO - 2017-06-15 15:20:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:27 --> URI Class Initialized
INFO - 2017-06-15 15:20:27 --> Router Class Initialized
INFO - 2017-06-15 15:20:27 --> Output Class Initialized
INFO - 2017-06-15 15:20:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:27 --> Input Class Initialized
INFO - 2017-06-15 15:20:27 --> Language Class Initialized
INFO - 2017-06-15 15:20:27 --> Loader Class Initialized
INFO - 2017-06-15 15:20:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:27 --> Email Class Initialized
INFO - 2017-06-15 15:20:27 --> Controller Class Initialized
INFO - 2017-06-15 15:20:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:27 --> Model Class Initialized
INFO - 2017-06-15 15:20:27 --> Model Class Initialized
INFO - 2017-06-15 15:20:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:20:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:20:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:20:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:20:27 --> Final output sent to browser
DEBUG - 2017-06-15 15:20:27 --> Total execution time: 0.0604
INFO - 2017-06-15 15:20:27 --> Config Class Initialized
INFO - 2017-06-15 15:20:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:27 --> URI Class Initialized
INFO - 2017-06-15 15:20:27 --> Router Class Initialized
INFO - 2017-06-15 15:20:27 --> Output Class Initialized
INFO - 2017-06-15 15:20:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:27 --> Input Class Initialized
INFO - 2017-06-15 15:20:27 --> Language Class Initialized
INFO - 2017-06-15 15:20:27 --> Loader Class Initialized
INFO - 2017-06-15 15:20:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:27 --> Email Class Initialized
INFO - 2017-06-15 15:20:27 --> Controller Class Initialized
INFO - 2017-06-15 15:20:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:27 --> Model Class Initialized
INFO - 2017-06-15 15:20:27 --> Model Class Initialized
INFO - 2017-06-15 15:20:28 --> Config Class Initialized
INFO - 2017-06-15 15:20:28 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:20:28 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:20:28 --> Utf8 Class Initialized
INFO - 2017-06-15 15:20:28 --> URI Class Initialized
INFO - 2017-06-15 15:20:28 --> Router Class Initialized
INFO - 2017-06-15 15:20:28 --> Output Class Initialized
INFO - 2017-06-15 15:20:28 --> Security Class Initialized
DEBUG - 2017-06-15 15:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:20:28 --> Input Class Initialized
INFO - 2017-06-15 15:20:28 --> Language Class Initialized
INFO - 2017-06-15 15:20:28 --> Loader Class Initialized
INFO - 2017-06-15 15:20:28 --> Helper loaded: common_helper
INFO - 2017-06-15 15:20:28 --> Database Driver Class Initialized
INFO - 2017-06-15 15:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:20:28 --> Email Class Initialized
INFO - 2017-06-15 15:20:28 --> Controller Class Initialized
INFO - 2017-06-15 15:20:28 --> Helper loaded: form_helper
INFO - 2017-06-15 15:20:28 --> Form Validation Class Initialized
INFO - 2017-06-15 15:20:28 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:20:28 --> Helper loaded: url_helper
INFO - 2017-06-15 15:20:28 --> Model Class Initialized
INFO - 2017-06-15 15:20:28 --> Model Class Initialized
INFO - 2017-06-15 15:20:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:20:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:20:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:20:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:20:28 --> Final output sent to browser
DEBUG - 2017-06-15 15:20:28 --> Total execution time: 0.0598
INFO - 2017-06-15 15:21:10 --> Config Class Initialized
INFO - 2017-06-15 15:21:10 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:21:10 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:21:10 --> Utf8 Class Initialized
INFO - 2017-06-15 15:21:10 --> URI Class Initialized
INFO - 2017-06-15 15:21:10 --> Router Class Initialized
INFO - 2017-06-15 15:21:10 --> Output Class Initialized
INFO - 2017-06-15 15:21:10 --> Security Class Initialized
DEBUG - 2017-06-15 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:21:10 --> Input Class Initialized
INFO - 2017-06-15 15:21:10 --> Language Class Initialized
INFO - 2017-06-15 15:21:10 --> Loader Class Initialized
INFO - 2017-06-15 15:21:10 --> Helper loaded: common_helper
INFO - 2017-06-15 15:21:10 --> Database Driver Class Initialized
INFO - 2017-06-15 15:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:21:10 --> Email Class Initialized
INFO - 2017-06-15 15:21:10 --> Controller Class Initialized
INFO - 2017-06-15 15:21:10 --> Helper loaded: form_helper
INFO - 2017-06-15 15:21:10 --> Form Validation Class Initialized
INFO - 2017-06-15 15:21:10 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:21:10 --> Helper loaded: url_helper
INFO - 2017-06-15 15:21:10 --> Model Class Initialized
INFO - 2017-06-15 15:21:10 --> Model Class Initialized
INFO - 2017-06-15 15:21:10 --> Config Class Initialized
INFO - 2017-06-15 15:21:10 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:21:10 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:21:10 --> Utf8 Class Initialized
INFO - 2017-06-15 15:21:10 --> URI Class Initialized
INFO - 2017-06-15 15:21:10 --> Router Class Initialized
INFO - 2017-06-15 15:21:10 --> Output Class Initialized
INFO - 2017-06-15 15:21:10 --> Security Class Initialized
DEBUG - 2017-06-15 15:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:21:10 --> Input Class Initialized
INFO - 2017-06-15 15:21:10 --> Language Class Initialized
INFO - 2017-06-15 15:21:10 --> Loader Class Initialized
INFO - 2017-06-15 15:21:10 --> Helper loaded: common_helper
INFO - 2017-06-15 15:21:10 --> Database Driver Class Initialized
INFO - 2017-06-15 15:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:21:10 --> Email Class Initialized
INFO - 2017-06-15 15:21:10 --> Controller Class Initialized
INFO - 2017-06-15 15:21:10 --> Helper loaded: form_helper
INFO - 2017-06-15 15:21:10 --> Form Validation Class Initialized
INFO - 2017-06-15 15:21:10 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:21:10 --> Helper loaded: url_helper
INFO - 2017-06-15 15:21:10 --> Model Class Initialized
INFO - 2017-06-15 15:21:10 --> Model Class Initialized
INFO - 2017-06-15 15:21:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:21:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:21:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:21:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:21:10 --> Final output sent to browser
DEBUG - 2017-06-15 15:21:10 --> Total execution time: 0.0576
INFO - 2017-06-15 15:24:19 --> Config Class Initialized
INFO - 2017-06-15 15:24:19 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:24:19 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:24:19 --> Utf8 Class Initialized
INFO - 2017-06-15 15:24:19 --> URI Class Initialized
INFO - 2017-06-15 15:24:19 --> Router Class Initialized
INFO - 2017-06-15 15:24:19 --> Output Class Initialized
INFO - 2017-06-15 15:24:19 --> Security Class Initialized
DEBUG - 2017-06-15 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:24:19 --> Input Class Initialized
INFO - 2017-06-15 15:24:19 --> Language Class Initialized
INFO - 2017-06-15 15:24:19 --> Loader Class Initialized
INFO - 2017-06-15 15:24:19 --> Helper loaded: common_helper
INFO - 2017-06-15 15:24:19 --> Database Driver Class Initialized
INFO - 2017-06-15 15:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:24:19 --> Email Class Initialized
INFO - 2017-06-15 15:24:19 --> Controller Class Initialized
INFO - 2017-06-15 15:24:19 --> Helper loaded: form_helper
INFO - 2017-06-15 15:24:19 --> Form Validation Class Initialized
INFO - 2017-06-15 15:24:19 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:24:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:24:19 --> Helper loaded: url_helper
INFO - 2017-06-15 15:24:19 --> Model Class Initialized
INFO - 2017-06-15 15:24:19 --> Model Class Initialized
INFO - 2017-06-15 15:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:24:19 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:24:19 --> Final output sent to browser
DEBUG - 2017-06-15 15:24:19 --> Total execution time: 0.0480
INFO - 2017-06-15 15:24:20 --> Config Class Initialized
INFO - 2017-06-15 15:24:20 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:24:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:24:20 --> Utf8 Class Initialized
INFO - 2017-06-15 15:24:20 --> URI Class Initialized
INFO - 2017-06-15 15:24:20 --> Router Class Initialized
INFO - 2017-06-15 15:24:20 --> Output Class Initialized
INFO - 2017-06-15 15:24:20 --> Security Class Initialized
DEBUG - 2017-06-15 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:24:20 --> Input Class Initialized
INFO - 2017-06-15 15:24:20 --> Language Class Initialized
INFO - 2017-06-15 15:24:20 --> Loader Class Initialized
INFO - 2017-06-15 15:24:20 --> Helper loaded: common_helper
INFO - 2017-06-15 15:24:20 --> Database Driver Class Initialized
INFO - 2017-06-15 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:24:20 --> Email Class Initialized
INFO - 2017-06-15 15:24:20 --> Controller Class Initialized
INFO - 2017-06-15 15:24:20 --> Helper loaded: form_helper
INFO - 2017-06-15 15:24:20 --> Form Validation Class Initialized
INFO - 2017-06-15 15:24:20 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:24:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:24:20 --> Helper loaded: url_helper
INFO - 2017-06-15 15:24:20 --> Model Class Initialized
INFO - 2017-06-15 15:24:20 --> Model Class Initialized
ERROR - 2017-06-15 15:24:20 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 15:24:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\system\database\DB_driver.php 1440
ERROR - 2017-06-15 15:24:20 --> Array to string conversion
ERROR - 2017-06-15 15:24:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bloodApp\system\database\DB_driver.php 1440
ERROR - 2017-06-15 15:24:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `bloodGroups` = Array, `name` = 'superadmin', `phoneNumber` = '1221121212', `bl' at line 1 - Invalid query: UPDATE `users` SET `details` = , `bloodGroups` = Array, `name` = 'superadmin', `phoneNumber` = '1221121212', `bloodGroup` = '9', `updatedTime` = '2017-06-15 15:24:20'
WHERE `userId` = '145'
INFO - 2017-06-15 15:24:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:24:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:24:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:24:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:24:20 --> Final output sent to browser
DEBUG - 2017-06-15 15:24:20 --> Total execution time: 0.0591
INFO - 2017-06-15 15:24:50 --> Config Class Initialized
INFO - 2017-06-15 15:24:50 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:24:50 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:24:50 --> Utf8 Class Initialized
INFO - 2017-06-15 15:24:50 --> URI Class Initialized
INFO - 2017-06-15 15:24:50 --> Router Class Initialized
INFO - 2017-06-15 15:24:50 --> Output Class Initialized
INFO - 2017-06-15 15:24:50 --> Security Class Initialized
DEBUG - 2017-06-15 15:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:24:50 --> Input Class Initialized
INFO - 2017-06-15 15:24:50 --> Language Class Initialized
INFO - 2017-06-15 15:24:50 --> Loader Class Initialized
INFO - 2017-06-15 15:24:50 --> Helper loaded: common_helper
INFO - 2017-06-15 15:24:50 --> Database Driver Class Initialized
INFO - 2017-06-15 15:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:24:50 --> Email Class Initialized
INFO - 2017-06-15 15:24:50 --> Controller Class Initialized
INFO - 2017-06-15 15:24:50 --> Helper loaded: form_helper
INFO - 2017-06-15 15:24:50 --> Form Validation Class Initialized
INFO - 2017-06-15 15:24:50 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:24:50 --> Helper loaded: url_helper
INFO - 2017-06-15 15:24:50 --> Model Class Initialized
INFO - 2017-06-15 15:24:50 --> Model Class Initialized
INFO - 2017-06-15 15:24:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:24:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:24:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:24:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:24:50 --> Final output sent to browser
DEBUG - 2017-06-15 15:24:50 --> Total execution time: 0.0484
INFO - 2017-06-15 15:24:52 --> Config Class Initialized
INFO - 2017-06-15 15:24:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:24:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:24:52 --> Utf8 Class Initialized
INFO - 2017-06-15 15:24:52 --> URI Class Initialized
INFO - 2017-06-15 15:24:52 --> Router Class Initialized
INFO - 2017-06-15 15:24:52 --> Output Class Initialized
INFO - 2017-06-15 15:24:52 --> Security Class Initialized
DEBUG - 2017-06-15 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:24:52 --> Input Class Initialized
INFO - 2017-06-15 15:24:52 --> Language Class Initialized
INFO - 2017-06-15 15:24:52 --> Loader Class Initialized
INFO - 2017-06-15 15:24:52 --> Helper loaded: common_helper
INFO - 2017-06-15 15:24:52 --> Database Driver Class Initialized
INFO - 2017-06-15 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:24:52 --> Email Class Initialized
INFO - 2017-06-15 15:24:52 --> Controller Class Initialized
INFO - 2017-06-15 15:24:52 --> Helper loaded: form_helper
INFO - 2017-06-15 15:24:52 --> Form Validation Class Initialized
INFO - 2017-06-15 15:24:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:24:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:24:52 --> Helper loaded: url_helper
INFO - 2017-06-15 15:24:52 --> Model Class Initialized
INFO - 2017-06-15 15:24:52 --> Model Class Initialized
INFO - 2017-06-15 15:25:21 --> Config Class Initialized
INFO - 2017-06-15 15:25:21 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:25:21 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:25:21 --> Utf8 Class Initialized
INFO - 2017-06-15 15:25:21 --> URI Class Initialized
INFO - 2017-06-15 15:25:21 --> Router Class Initialized
INFO - 2017-06-15 15:25:21 --> Output Class Initialized
INFO - 2017-06-15 15:25:21 --> Security Class Initialized
DEBUG - 2017-06-15 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:25:21 --> Input Class Initialized
INFO - 2017-06-15 15:25:21 --> Language Class Initialized
INFO - 2017-06-15 15:25:21 --> Loader Class Initialized
INFO - 2017-06-15 15:25:21 --> Helper loaded: common_helper
INFO - 2017-06-15 15:25:21 --> Database Driver Class Initialized
INFO - 2017-06-15 15:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:25:21 --> Email Class Initialized
INFO - 2017-06-15 15:25:21 --> Controller Class Initialized
INFO - 2017-06-15 15:25:21 --> Helper loaded: form_helper
INFO - 2017-06-15 15:25:21 --> Form Validation Class Initialized
INFO - 2017-06-15 15:25:21 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:25:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:25:21 --> Helper loaded: url_helper
INFO - 2017-06-15 15:25:21 --> Model Class Initialized
INFO - 2017-06-15 15:25:21 --> Model Class Initialized
ERROR - 2017-06-15 15:25:21 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 15:25:21 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\system\database\DB_driver.php 1440
ERROR - 2017-06-15 15:25:21 --> Array to string conversion
ERROR - 2017-06-15 15:25:21 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bloodApp\system\database\DB_driver.php 1440
ERROR - 2017-06-15 15:25:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `bloodGroups` = Array, `name` = 'superadmin', `phoneNumber` = '1221121212', `bl' at line 1 - Invalid query: UPDATE `users` SET `details` = , `bloodGroups` = Array, `name` = 'superadmin', `phoneNumber` = '1221121212', `bloodGroup` = '9', `updatedTime` = '2017-06-15 15:25:21'
WHERE `userId` = '145'
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:25:21 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:25:21 --> Final output sent to browser
DEBUG - 2017-06-15 15:25:21 --> Total execution time: 0.0544
INFO - 2017-06-15 15:25:33 --> Config Class Initialized
INFO - 2017-06-15 15:25:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:25:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:25:33 --> Utf8 Class Initialized
INFO - 2017-06-15 15:25:33 --> URI Class Initialized
INFO - 2017-06-15 15:25:33 --> Router Class Initialized
INFO - 2017-06-15 15:25:33 --> Output Class Initialized
INFO - 2017-06-15 15:25:33 --> Security Class Initialized
DEBUG - 2017-06-15 15:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:25:33 --> Input Class Initialized
INFO - 2017-06-15 15:25:33 --> Language Class Initialized
INFO - 2017-06-15 15:25:33 --> Loader Class Initialized
INFO - 2017-06-15 15:25:33 --> Helper loaded: common_helper
INFO - 2017-06-15 15:25:33 --> Database Driver Class Initialized
INFO - 2017-06-15 15:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:25:33 --> Email Class Initialized
INFO - 2017-06-15 15:25:33 --> Controller Class Initialized
INFO - 2017-06-15 15:25:33 --> Helper loaded: form_helper
INFO - 2017-06-15 15:25:33 --> Form Validation Class Initialized
INFO - 2017-06-15 15:25:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:25:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:25:33 --> Helper loaded: url_helper
INFO - 2017-06-15 15:25:33 --> Model Class Initialized
INFO - 2017-06-15 15:25:33 --> Model Class Initialized
ERROR - 2017-06-15 15:25:33 --> Object of class stdClass could not be converted to string
ERROR - 2017-06-15 15:25:33 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bloodApp\system\database\DB_driver.php 1440
ERROR - 2017-06-15 15:25:33 --> Array to string conversion
ERROR - 2017-06-15 15:25:33 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bloodApp\system\database\DB_driver.php 1440
ERROR - 2017-06-15 15:25:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `bloodGroups` = Array, `name` = 'superadmin', `phoneNumber` = '1221121212', `bl' at line 1 - Invalid query: UPDATE `users` SET `details` = , `bloodGroups` = Array, `name` = 'superadmin', `phoneNumber` = '1221121212', `bloodGroup` = '9', `updatedTime` = '2017-06-15 15:25:33'
WHERE `userId` = '145'
INFO - 2017-06-15 15:26:51 --> Config Class Initialized
INFO - 2017-06-15 15:26:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:26:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:26:51 --> Utf8 Class Initialized
INFO - 2017-06-15 15:26:51 --> URI Class Initialized
INFO - 2017-06-15 15:26:51 --> Router Class Initialized
INFO - 2017-06-15 15:26:51 --> Output Class Initialized
INFO - 2017-06-15 15:26:51 --> Security Class Initialized
DEBUG - 2017-06-15 15:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:26:51 --> Input Class Initialized
INFO - 2017-06-15 15:26:51 --> Language Class Initialized
INFO - 2017-06-15 15:26:51 --> Loader Class Initialized
INFO - 2017-06-15 15:26:51 --> Helper loaded: common_helper
INFO - 2017-06-15 15:26:51 --> Database Driver Class Initialized
INFO - 2017-06-15 15:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:26:51 --> Email Class Initialized
INFO - 2017-06-15 15:26:51 --> Controller Class Initialized
INFO - 2017-06-15 15:26:51 --> Helper loaded: form_helper
INFO - 2017-06-15 15:26:51 --> Form Validation Class Initialized
INFO - 2017-06-15 15:26:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:26:51 --> Helper loaded: url_helper
INFO - 2017-06-15 15:26:51 --> Model Class Initialized
INFO - 2017-06-15 15:26:51 --> Model Class Initialized
INFO - 2017-06-15 15:26:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:26:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:26:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:26:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:26:51 --> Final output sent to browser
DEBUG - 2017-06-15 15:26:51 --> Total execution time: 0.0474
INFO - 2017-06-15 15:26:52 --> Config Class Initialized
INFO - 2017-06-15 15:26:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:26:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:26:52 --> Utf8 Class Initialized
INFO - 2017-06-15 15:26:52 --> URI Class Initialized
INFO - 2017-06-15 15:26:52 --> Router Class Initialized
INFO - 2017-06-15 15:26:52 --> Output Class Initialized
INFO - 2017-06-15 15:26:52 --> Security Class Initialized
DEBUG - 2017-06-15 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:26:52 --> Input Class Initialized
INFO - 2017-06-15 15:26:52 --> Language Class Initialized
INFO - 2017-06-15 15:26:52 --> Loader Class Initialized
INFO - 2017-06-15 15:26:52 --> Helper loaded: common_helper
INFO - 2017-06-15 15:26:52 --> Database Driver Class Initialized
INFO - 2017-06-15 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:26:52 --> Email Class Initialized
INFO - 2017-06-15 15:26:52 --> Controller Class Initialized
INFO - 2017-06-15 15:26:52 --> Helper loaded: form_helper
INFO - 2017-06-15 15:26:52 --> Form Validation Class Initialized
INFO - 2017-06-15 15:26:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:26:52 --> Helper loaded: url_helper
INFO - 2017-06-15 15:26:52 --> Model Class Initialized
INFO - 2017-06-15 15:26:52 --> Model Class Initialized
INFO - 2017-06-15 15:26:52 --> Config Class Initialized
INFO - 2017-06-15 15:26:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:26:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:26:52 --> Utf8 Class Initialized
INFO - 2017-06-15 15:26:52 --> URI Class Initialized
INFO - 2017-06-15 15:26:52 --> Router Class Initialized
INFO - 2017-06-15 15:26:52 --> Output Class Initialized
INFO - 2017-06-15 15:26:52 --> Security Class Initialized
DEBUG - 2017-06-15 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:26:52 --> Input Class Initialized
INFO - 2017-06-15 15:26:52 --> Language Class Initialized
INFO - 2017-06-15 15:26:52 --> Loader Class Initialized
INFO - 2017-06-15 15:26:52 --> Helper loaded: common_helper
INFO - 2017-06-15 15:26:52 --> Database Driver Class Initialized
INFO - 2017-06-15 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:26:52 --> Email Class Initialized
INFO - 2017-06-15 15:26:52 --> Controller Class Initialized
INFO - 2017-06-15 15:26:52 --> Helper loaded: form_helper
INFO - 2017-06-15 15:26:52 --> Form Validation Class Initialized
INFO - 2017-06-15 15:26:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:26:52 --> Helper loaded: url_helper
INFO - 2017-06-15 15:26:52 --> Model Class Initialized
INFO - 2017-06-15 15:26:53 --> Model Class Initialized
INFO - 2017-06-15 15:26:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:26:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:26:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:26:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:26:53 --> Final output sent to browser
DEBUG - 2017-06-15 15:26:53 --> Total execution time: 0.0541
INFO - 2017-06-15 15:26:56 --> Config Class Initialized
INFO - 2017-06-15 15:26:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:26:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:26:56 --> Utf8 Class Initialized
INFO - 2017-06-15 15:26:56 --> URI Class Initialized
INFO - 2017-06-15 15:26:56 --> Router Class Initialized
INFO - 2017-06-15 15:26:56 --> Output Class Initialized
INFO - 2017-06-15 15:26:56 --> Security Class Initialized
DEBUG - 2017-06-15 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:26:56 --> Input Class Initialized
INFO - 2017-06-15 15:26:56 --> Language Class Initialized
INFO - 2017-06-15 15:26:56 --> Loader Class Initialized
INFO - 2017-06-15 15:26:56 --> Helper loaded: common_helper
INFO - 2017-06-15 15:26:56 --> Database Driver Class Initialized
INFO - 2017-06-15 15:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:26:56 --> Email Class Initialized
INFO - 2017-06-15 15:26:56 --> Controller Class Initialized
INFO - 2017-06-15 15:26:56 --> Helper loaded: form_helper
INFO - 2017-06-15 15:26:56 --> Form Validation Class Initialized
INFO - 2017-06-15 15:26:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:26:56 --> Helper loaded: url_helper
INFO - 2017-06-15 15:26:56 --> Model Class Initialized
INFO - 2017-06-15 15:26:56 --> Model Class Initialized
INFO - 2017-06-15 15:26:56 --> Config Class Initialized
INFO - 2017-06-15 15:26:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:26:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:26:56 --> Utf8 Class Initialized
INFO - 2017-06-15 15:26:56 --> URI Class Initialized
INFO - 2017-06-15 15:26:56 --> Router Class Initialized
INFO - 2017-06-15 15:26:56 --> Output Class Initialized
INFO - 2017-06-15 15:26:56 --> Security Class Initialized
DEBUG - 2017-06-15 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:26:56 --> Input Class Initialized
INFO - 2017-06-15 15:26:56 --> Language Class Initialized
INFO - 2017-06-15 15:26:56 --> Loader Class Initialized
INFO - 2017-06-15 15:26:56 --> Helper loaded: common_helper
INFO - 2017-06-15 15:26:56 --> Database Driver Class Initialized
INFO - 2017-06-15 15:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:26:56 --> Email Class Initialized
INFO - 2017-06-15 15:26:56 --> Controller Class Initialized
INFO - 2017-06-15 15:26:56 --> Helper loaded: form_helper
INFO - 2017-06-15 15:26:56 --> Form Validation Class Initialized
INFO - 2017-06-15 15:26:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:26:56 --> Helper loaded: url_helper
INFO - 2017-06-15 15:26:56 --> Model Class Initialized
INFO - 2017-06-15 15:26:56 --> Model Class Initialized
INFO - 2017-06-15 15:26:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:26:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:26:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:26:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:26:56 --> Final output sent to browser
DEBUG - 2017-06-15 15:26:56 --> Total execution time: 0.0618
INFO - 2017-06-15 15:26:59 --> Config Class Initialized
INFO - 2017-06-15 15:26:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:26:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:26:59 --> Utf8 Class Initialized
INFO - 2017-06-15 15:26:59 --> URI Class Initialized
INFO - 2017-06-15 15:26:59 --> Router Class Initialized
INFO - 2017-06-15 15:26:59 --> Output Class Initialized
INFO - 2017-06-15 15:26:59 --> Security Class Initialized
DEBUG - 2017-06-15 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:26:59 --> Input Class Initialized
INFO - 2017-06-15 15:26:59 --> Language Class Initialized
INFO - 2017-06-15 15:26:59 --> Loader Class Initialized
INFO - 2017-06-15 15:26:59 --> Helper loaded: common_helper
INFO - 2017-06-15 15:26:59 --> Database Driver Class Initialized
INFO - 2017-06-15 15:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:26:59 --> Email Class Initialized
INFO - 2017-06-15 15:26:59 --> Controller Class Initialized
INFO - 2017-06-15 15:26:59 --> Helper loaded: form_helper
INFO - 2017-06-15 15:26:59 --> Form Validation Class Initialized
INFO - 2017-06-15 15:26:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:26:59 --> Helper loaded: url_helper
INFO - 2017-06-15 15:26:59 --> Model Class Initialized
INFO - 2017-06-15 15:26:59 --> Model Class Initialized
INFO - 2017-06-15 15:26:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:26:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:26:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:26:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:26:59 --> Final output sent to browser
DEBUG - 2017-06-15 15:26:59 --> Total execution time: 0.0440
INFO - 2017-06-15 15:27:26 --> Config Class Initialized
INFO - 2017-06-15 15:27:26 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:27:26 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:27:26 --> Utf8 Class Initialized
INFO - 2017-06-15 15:27:26 --> URI Class Initialized
INFO - 2017-06-15 15:27:26 --> Router Class Initialized
INFO - 2017-06-15 15:27:26 --> Output Class Initialized
INFO - 2017-06-15 15:27:26 --> Security Class Initialized
DEBUG - 2017-06-15 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:27:26 --> Input Class Initialized
INFO - 2017-06-15 15:27:26 --> Language Class Initialized
INFO - 2017-06-15 15:27:26 --> Loader Class Initialized
INFO - 2017-06-15 15:27:26 --> Helper loaded: common_helper
INFO - 2017-06-15 15:27:26 --> Database Driver Class Initialized
INFO - 2017-06-15 15:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:27:26 --> Email Class Initialized
INFO - 2017-06-15 15:27:26 --> Controller Class Initialized
INFO - 2017-06-15 15:27:26 --> Helper loaded: form_helper
INFO - 2017-06-15 15:27:26 --> Form Validation Class Initialized
INFO - 2017-06-15 15:27:26 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:27:26 --> Helper loaded: url_helper
INFO - 2017-06-15 15:27:26 --> Model Class Initialized
INFO - 2017-06-15 15:27:27 --> Model Class Initialized
INFO - 2017-06-15 15:27:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:27:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:27:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:27:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:27:27 --> Final output sent to browser
DEBUG - 2017-06-15 15:27:27 --> Total execution time: 0.0480
INFO - 2017-06-15 15:27:29 --> Config Class Initialized
INFO - 2017-06-15 15:27:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:27:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:27:29 --> Utf8 Class Initialized
INFO - 2017-06-15 15:27:29 --> URI Class Initialized
INFO - 2017-06-15 15:27:29 --> Router Class Initialized
INFO - 2017-06-15 15:27:29 --> Output Class Initialized
INFO - 2017-06-15 15:27:29 --> Security Class Initialized
DEBUG - 2017-06-15 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:27:29 --> Input Class Initialized
INFO - 2017-06-15 15:27:29 --> Language Class Initialized
INFO - 2017-06-15 15:27:29 --> Loader Class Initialized
INFO - 2017-06-15 15:27:29 --> Helper loaded: common_helper
INFO - 2017-06-15 15:27:29 --> Database Driver Class Initialized
INFO - 2017-06-15 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:27:29 --> Email Class Initialized
INFO - 2017-06-15 15:27:29 --> Controller Class Initialized
INFO - 2017-06-15 15:27:29 --> Helper loaded: form_helper
INFO - 2017-06-15 15:27:29 --> Form Validation Class Initialized
INFO - 2017-06-15 15:27:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:27:29 --> Helper loaded: url_helper
INFO - 2017-06-15 15:27:29 --> Model Class Initialized
INFO - 2017-06-15 15:27:29 --> Model Class Initialized
INFO - 2017-06-15 15:27:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:27:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:27:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:27:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:27:29 --> Final output sent to browser
DEBUG - 2017-06-15 15:27:29 --> Total execution time: 0.0469
INFO - 2017-06-15 15:31:52 --> Config Class Initialized
INFO - 2017-06-15 15:31:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:31:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:31:52 --> Utf8 Class Initialized
INFO - 2017-06-15 15:31:52 --> URI Class Initialized
INFO - 2017-06-15 15:31:52 --> Router Class Initialized
INFO - 2017-06-15 15:31:52 --> Output Class Initialized
INFO - 2017-06-15 15:31:52 --> Security Class Initialized
DEBUG - 2017-06-15 15:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:31:52 --> Input Class Initialized
INFO - 2017-06-15 15:31:52 --> Language Class Initialized
INFO - 2017-06-15 15:31:52 --> Loader Class Initialized
INFO - 2017-06-15 15:31:52 --> Helper loaded: common_helper
INFO - 2017-06-15 15:31:52 --> Database Driver Class Initialized
INFO - 2017-06-15 15:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:31:52 --> Email Class Initialized
INFO - 2017-06-15 15:31:52 --> Controller Class Initialized
INFO - 2017-06-15 15:31:52 --> Helper loaded: form_helper
INFO - 2017-06-15 15:31:52 --> Form Validation Class Initialized
INFO - 2017-06-15 15:31:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:31:52 --> Helper loaded: url_helper
INFO - 2017-06-15 15:31:52 --> Model Class Initialized
INFO - 2017-06-15 15:31:52 --> Model Class Initialized
INFO - 2017-06-15 15:31:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:31:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
ERROR - 2017-06-15 15:31:52 --> Undefined variable: Smessage
ERROR - 2017-06-15 15:31:52 --> Severity: Notice --> Undefined variable: Smessage C:\xampp\htdocs\bloodApp\application\views\profile.php 24
ERROR - 2017-06-15 15:31:52 --> Array to string conversion
ERROR - 2017-06-15 15:31:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\bloodApp\application\views\profile.php 24
INFO - 2017-06-15 15:31:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:31:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:31:52 --> Final output sent to browser
DEBUG - 2017-06-15 15:31:52 --> Total execution time: 0.0506
INFO - 2017-06-15 15:32:07 --> Config Class Initialized
INFO - 2017-06-15 15:32:07 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:32:07 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:32:07 --> Utf8 Class Initialized
INFO - 2017-06-15 15:32:07 --> URI Class Initialized
INFO - 2017-06-15 15:32:07 --> Router Class Initialized
INFO - 2017-06-15 15:32:07 --> Output Class Initialized
INFO - 2017-06-15 15:32:07 --> Security Class Initialized
DEBUG - 2017-06-15 15:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:32:07 --> Input Class Initialized
INFO - 2017-06-15 15:32:07 --> Language Class Initialized
INFO - 2017-06-15 15:32:07 --> Loader Class Initialized
INFO - 2017-06-15 15:32:07 --> Helper loaded: common_helper
INFO - 2017-06-15 15:32:07 --> Database Driver Class Initialized
INFO - 2017-06-15 15:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:32:07 --> Email Class Initialized
INFO - 2017-06-15 15:32:07 --> Controller Class Initialized
INFO - 2017-06-15 15:32:07 --> Helper loaded: form_helper
INFO - 2017-06-15 15:32:07 --> Form Validation Class Initialized
INFO - 2017-06-15 15:32:07 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:32:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:32:07 --> Helper loaded: url_helper
INFO - 2017-06-15 15:32:07 --> Model Class Initialized
INFO - 2017-06-15 15:32:07 --> Model Class Initialized
INFO - 2017-06-15 15:32:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:32:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:32:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:32:07 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:32:07 --> Final output sent to browser
DEBUG - 2017-06-15 15:32:07 --> Total execution time: 0.0465
INFO - 2017-06-15 15:32:08 --> Config Class Initialized
INFO - 2017-06-15 15:32:08 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:32:08 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:32:08 --> Utf8 Class Initialized
INFO - 2017-06-15 15:32:08 --> URI Class Initialized
INFO - 2017-06-15 15:32:08 --> Router Class Initialized
INFO - 2017-06-15 15:32:08 --> Output Class Initialized
INFO - 2017-06-15 15:32:08 --> Security Class Initialized
DEBUG - 2017-06-15 15:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:32:09 --> Input Class Initialized
INFO - 2017-06-15 15:32:09 --> Language Class Initialized
INFO - 2017-06-15 15:32:09 --> Loader Class Initialized
INFO - 2017-06-15 15:32:09 --> Helper loaded: common_helper
INFO - 2017-06-15 15:32:09 --> Database Driver Class Initialized
INFO - 2017-06-15 15:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:32:09 --> Email Class Initialized
INFO - 2017-06-15 15:32:09 --> Controller Class Initialized
INFO - 2017-06-15 15:32:09 --> Helper loaded: form_helper
INFO - 2017-06-15 15:32:09 --> Form Validation Class Initialized
INFO - 2017-06-15 15:32:09 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:32:09 --> Helper loaded: url_helper
INFO - 2017-06-15 15:32:09 --> Model Class Initialized
INFO - 2017-06-15 15:32:09 --> Model Class Initialized
INFO - 2017-06-15 15:32:09 --> Config Class Initialized
INFO - 2017-06-15 15:32:09 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:32:09 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:32:09 --> Utf8 Class Initialized
INFO - 2017-06-15 15:32:09 --> URI Class Initialized
INFO - 2017-06-15 15:32:09 --> Router Class Initialized
INFO - 2017-06-15 15:32:09 --> Output Class Initialized
INFO - 2017-06-15 15:32:09 --> Security Class Initialized
DEBUG - 2017-06-15 15:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:32:09 --> Input Class Initialized
INFO - 2017-06-15 15:32:09 --> Language Class Initialized
INFO - 2017-06-15 15:32:09 --> Loader Class Initialized
INFO - 2017-06-15 15:32:09 --> Helper loaded: common_helper
INFO - 2017-06-15 15:32:09 --> Database Driver Class Initialized
INFO - 2017-06-15 15:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:32:09 --> Email Class Initialized
INFO - 2017-06-15 15:32:09 --> Controller Class Initialized
INFO - 2017-06-15 15:32:09 --> Helper loaded: form_helper
INFO - 2017-06-15 15:32:09 --> Form Validation Class Initialized
INFO - 2017-06-15 15:32:09 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:32:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:32:09 --> Helper loaded: url_helper
INFO - 2017-06-15 15:32:09 --> Model Class Initialized
INFO - 2017-06-15 15:32:09 --> Model Class Initialized
INFO - 2017-06-15 15:32:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:32:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:32:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:32:09 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:32:09 --> Final output sent to browser
DEBUG - 2017-06-15 15:32:09 --> Total execution time: 0.0559
INFO - 2017-06-15 15:32:29 --> Config Class Initialized
INFO - 2017-06-15 15:32:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:32:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:32:29 --> Utf8 Class Initialized
INFO - 2017-06-15 15:32:29 --> URI Class Initialized
INFO - 2017-06-15 15:32:29 --> Router Class Initialized
INFO - 2017-06-15 15:32:29 --> Output Class Initialized
INFO - 2017-06-15 15:32:29 --> Security Class Initialized
DEBUG - 2017-06-15 15:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:32:29 --> Input Class Initialized
INFO - 2017-06-15 15:32:29 --> Language Class Initialized
INFO - 2017-06-15 15:32:29 --> Loader Class Initialized
INFO - 2017-06-15 15:32:29 --> Helper loaded: common_helper
INFO - 2017-06-15 15:32:29 --> Database Driver Class Initialized
INFO - 2017-06-15 15:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:32:29 --> Email Class Initialized
INFO - 2017-06-15 15:32:29 --> Controller Class Initialized
INFO - 2017-06-15 15:32:29 --> Helper loaded: form_helper
INFO - 2017-06-15 15:32:29 --> Form Validation Class Initialized
INFO - 2017-06-15 15:32:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:32:29 --> Helper loaded: url_helper
INFO - 2017-06-15 15:32:29 --> Model Class Initialized
INFO - 2017-06-15 15:32:29 --> Model Class Initialized
INFO - 2017-06-15 15:32:29 --> Config Class Initialized
INFO - 2017-06-15 15:32:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:32:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:32:29 --> Utf8 Class Initialized
INFO - 2017-06-15 15:32:29 --> URI Class Initialized
INFO - 2017-06-15 15:32:29 --> Router Class Initialized
INFO - 2017-06-15 15:32:29 --> Output Class Initialized
INFO - 2017-06-15 15:32:29 --> Security Class Initialized
DEBUG - 2017-06-15 15:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:32:29 --> Input Class Initialized
INFO - 2017-06-15 15:32:29 --> Language Class Initialized
INFO - 2017-06-15 15:32:29 --> Loader Class Initialized
INFO - 2017-06-15 15:32:29 --> Helper loaded: common_helper
INFO - 2017-06-15 15:32:29 --> Database Driver Class Initialized
INFO - 2017-06-15 15:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:32:29 --> Email Class Initialized
INFO - 2017-06-15 15:32:29 --> Controller Class Initialized
INFO - 2017-06-15 15:32:29 --> Helper loaded: form_helper
INFO - 2017-06-15 15:32:29 --> Form Validation Class Initialized
INFO - 2017-06-15 15:32:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:32:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:32:29 --> Helper loaded: url_helper
INFO - 2017-06-15 15:32:29 --> Model Class Initialized
INFO - 2017-06-15 15:32:29 --> Model Class Initialized
INFO - 2017-06-15 15:32:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:32:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:32:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:32:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:32:29 --> Final output sent to browser
DEBUG - 2017-06-15 15:32:29 --> Total execution time: 0.0596
INFO - 2017-06-15 15:33:03 --> Config Class Initialized
INFO - 2017-06-15 15:33:03 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:33:03 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:33:03 --> Utf8 Class Initialized
INFO - 2017-06-15 15:33:03 --> URI Class Initialized
INFO - 2017-06-15 15:33:03 --> Router Class Initialized
INFO - 2017-06-15 15:33:03 --> Output Class Initialized
INFO - 2017-06-15 15:33:03 --> Security Class Initialized
DEBUG - 2017-06-15 15:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:33:03 --> Input Class Initialized
INFO - 2017-06-15 15:33:03 --> Language Class Initialized
INFO - 2017-06-15 15:33:03 --> Loader Class Initialized
INFO - 2017-06-15 15:33:03 --> Helper loaded: common_helper
INFO - 2017-06-15 15:33:03 --> Database Driver Class Initialized
INFO - 2017-06-15 15:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:33:03 --> Email Class Initialized
INFO - 2017-06-15 15:33:03 --> Controller Class Initialized
INFO - 2017-06-15 15:33:04 --> Helper loaded: form_helper
INFO - 2017-06-15 15:33:04 --> Form Validation Class Initialized
INFO - 2017-06-15 15:33:04 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:33:04 --> Helper loaded: url_helper
INFO - 2017-06-15 15:33:04 --> Model Class Initialized
INFO - 2017-06-15 15:33:04 --> Model Class Initialized
INFO - 2017-06-15 15:33:04 --> Config Class Initialized
INFO - 2017-06-15 15:33:04 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:33:04 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:33:04 --> Utf8 Class Initialized
INFO - 2017-06-15 15:33:04 --> URI Class Initialized
INFO - 2017-06-15 15:33:04 --> Router Class Initialized
INFO - 2017-06-15 15:33:04 --> Output Class Initialized
INFO - 2017-06-15 15:33:04 --> Security Class Initialized
DEBUG - 2017-06-15 15:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:33:04 --> Input Class Initialized
INFO - 2017-06-15 15:33:04 --> Language Class Initialized
INFO - 2017-06-15 15:33:04 --> Loader Class Initialized
INFO - 2017-06-15 15:33:04 --> Helper loaded: common_helper
INFO - 2017-06-15 15:33:04 --> Database Driver Class Initialized
INFO - 2017-06-15 15:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:33:04 --> Email Class Initialized
INFO - 2017-06-15 15:33:04 --> Controller Class Initialized
INFO - 2017-06-15 15:33:04 --> Helper loaded: form_helper
INFO - 2017-06-15 15:33:04 --> Form Validation Class Initialized
INFO - 2017-06-15 15:33:04 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:33:04 --> Helper loaded: url_helper
INFO - 2017-06-15 15:33:04 --> Model Class Initialized
INFO - 2017-06-15 15:33:04 --> Model Class Initialized
INFO - 2017-06-15 15:33:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:33:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:33:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:33:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:33:04 --> Final output sent to browser
DEBUG - 2017-06-15 15:33:04 --> Total execution time: 0.0557
INFO - 2017-06-15 15:33:24 --> Config Class Initialized
INFO - 2017-06-15 15:33:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:33:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:33:24 --> Utf8 Class Initialized
INFO - 2017-06-15 15:33:24 --> URI Class Initialized
INFO - 2017-06-15 15:33:24 --> Router Class Initialized
INFO - 2017-06-15 15:33:24 --> Output Class Initialized
INFO - 2017-06-15 15:33:24 --> Security Class Initialized
DEBUG - 2017-06-15 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:33:24 --> Input Class Initialized
INFO - 2017-06-15 15:33:24 --> Language Class Initialized
INFO - 2017-06-15 15:33:24 --> Loader Class Initialized
INFO - 2017-06-15 15:33:24 --> Helper loaded: common_helper
INFO - 2017-06-15 15:33:24 --> Database Driver Class Initialized
INFO - 2017-06-15 15:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:33:24 --> Email Class Initialized
INFO - 2017-06-15 15:33:24 --> Controller Class Initialized
INFO - 2017-06-15 15:33:24 --> Helper loaded: form_helper
INFO - 2017-06-15 15:33:24 --> Form Validation Class Initialized
INFO - 2017-06-15 15:33:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:33:24 --> Helper loaded: url_helper
INFO - 2017-06-15 15:33:24 --> Model Class Initialized
INFO - 2017-06-15 15:33:24 --> Model Class Initialized
INFO - 2017-06-15 15:33:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:33:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:33:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:33:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:33:24 --> Final output sent to browser
DEBUG - 2017-06-15 15:33:24 --> Total execution time: 0.0461
INFO - 2017-06-15 15:33:49 --> Config Class Initialized
INFO - 2017-06-15 15:33:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:33:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:33:49 --> Utf8 Class Initialized
INFO - 2017-06-15 15:33:49 --> URI Class Initialized
INFO - 2017-06-15 15:33:49 --> Router Class Initialized
INFO - 2017-06-15 15:33:49 --> Output Class Initialized
INFO - 2017-06-15 15:33:49 --> Security Class Initialized
DEBUG - 2017-06-15 15:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:33:49 --> Input Class Initialized
INFO - 2017-06-15 15:33:49 --> Language Class Initialized
INFO - 2017-06-15 15:33:49 --> Loader Class Initialized
INFO - 2017-06-15 15:33:49 --> Helper loaded: common_helper
INFO - 2017-06-15 15:33:49 --> Database Driver Class Initialized
INFO - 2017-06-15 15:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:33:49 --> Email Class Initialized
INFO - 2017-06-15 15:33:49 --> Controller Class Initialized
INFO - 2017-06-15 15:33:49 --> Helper loaded: form_helper
INFO - 2017-06-15 15:33:49 --> Form Validation Class Initialized
INFO - 2017-06-15 15:33:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:33:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:33:49 --> Helper loaded: url_helper
INFO - 2017-06-15 15:33:49 --> Model Class Initialized
INFO - 2017-06-15 15:33:49 --> Model Class Initialized
INFO - 2017-06-15 15:33:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:33:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:33:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:33:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:33:49 --> Final output sent to browser
DEBUG - 2017-06-15 15:33:49 --> Total execution time: 0.0507
INFO - 2017-06-15 15:34:26 --> Config Class Initialized
INFO - 2017-06-15 15:34:26 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:26 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:26 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:26 --> URI Class Initialized
INFO - 2017-06-15 15:34:26 --> Router Class Initialized
INFO - 2017-06-15 15:34:26 --> Output Class Initialized
INFO - 2017-06-15 15:34:26 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:26 --> Input Class Initialized
INFO - 2017-06-15 15:34:26 --> Language Class Initialized
INFO - 2017-06-15 15:34:26 --> Loader Class Initialized
INFO - 2017-06-15 15:34:26 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:26 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:26 --> Email Class Initialized
INFO - 2017-06-15 15:34:26 --> Controller Class Initialized
INFO - 2017-06-15 15:34:26 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:26 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:26 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:26 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:26 --> Model Class Initialized
INFO - 2017-06-15 15:34:26 --> Model Class Initialized
INFO - 2017-06-15 15:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:34:26 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:34:26 --> Final output sent to browser
DEBUG - 2017-06-15 15:34:26 --> Total execution time: 0.0562
INFO - 2017-06-15 15:34:29 --> Config Class Initialized
INFO - 2017-06-15 15:34:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:29 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:29 --> URI Class Initialized
INFO - 2017-06-15 15:34:29 --> Router Class Initialized
INFO - 2017-06-15 15:34:29 --> Output Class Initialized
INFO - 2017-06-15 15:34:29 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:29 --> Input Class Initialized
INFO - 2017-06-15 15:34:29 --> Language Class Initialized
INFO - 2017-06-15 15:34:29 --> Loader Class Initialized
INFO - 2017-06-15 15:34:29 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:29 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:29 --> Email Class Initialized
INFO - 2017-06-15 15:34:29 --> Controller Class Initialized
INFO - 2017-06-15 15:34:29 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:29 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:29 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:29 --> Model Class Initialized
INFO - 2017-06-15 15:34:29 --> Model Class Initialized
INFO - 2017-06-15 15:34:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:34:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:34:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:34:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:34:29 --> Final output sent to browser
DEBUG - 2017-06-15 15:34:29 --> Total execution time: 0.0452
INFO - 2017-06-15 15:34:50 --> Config Class Initialized
INFO - 2017-06-15 15:34:50 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:50 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:50 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:50 --> URI Class Initialized
INFO - 2017-06-15 15:34:50 --> Router Class Initialized
INFO - 2017-06-15 15:34:50 --> Output Class Initialized
INFO - 2017-06-15 15:34:50 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:50 --> Input Class Initialized
INFO - 2017-06-15 15:34:50 --> Language Class Initialized
INFO - 2017-06-15 15:34:50 --> Loader Class Initialized
INFO - 2017-06-15 15:34:50 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:50 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:50 --> Email Class Initialized
INFO - 2017-06-15 15:34:50 --> Controller Class Initialized
INFO - 2017-06-15 15:34:50 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:50 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:50 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:50 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:50 --> Model Class Initialized
INFO - 2017-06-15 15:34:50 --> Model Class Initialized
INFO - 2017-06-15 15:34:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:34:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:34:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:34:50 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:34:50 --> Final output sent to browser
DEBUG - 2017-06-15 15:34:50 --> Total execution time: 0.0502
INFO - 2017-06-15 15:34:51 --> Config Class Initialized
INFO - 2017-06-15 15:34:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:51 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:51 --> URI Class Initialized
INFO - 2017-06-15 15:34:51 --> Router Class Initialized
INFO - 2017-06-15 15:34:51 --> Output Class Initialized
INFO - 2017-06-15 15:34:51 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:51 --> Input Class Initialized
INFO - 2017-06-15 15:34:51 --> Language Class Initialized
INFO - 2017-06-15 15:34:51 --> Loader Class Initialized
INFO - 2017-06-15 15:34:51 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:51 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:51 --> Email Class Initialized
INFO - 2017-06-15 15:34:51 --> Controller Class Initialized
INFO - 2017-06-15 15:34:51 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:51 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:51 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:51 --> Model Class Initialized
INFO - 2017-06-15 15:34:51 --> Model Class Initialized
INFO - 2017-06-15 15:34:51 --> Config Class Initialized
INFO - 2017-06-15 15:34:51 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:51 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:51 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:51 --> URI Class Initialized
INFO - 2017-06-15 15:34:51 --> Router Class Initialized
INFO - 2017-06-15 15:34:51 --> Output Class Initialized
INFO - 2017-06-15 15:34:51 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:51 --> Input Class Initialized
INFO - 2017-06-15 15:34:51 --> Language Class Initialized
INFO - 2017-06-15 15:34:51 --> Loader Class Initialized
INFO - 2017-06-15 15:34:51 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:51 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:51 --> Email Class Initialized
INFO - 2017-06-15 15:34:51 --> Controller Class Initialized
INFO - 2017-06-15 15:34:51 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:51 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:51 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:51 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:51 --> Model Class Initialized
INFO - 2017-06-15 15:34:51 --> Model Class Initialized
INFO - 2017-06-15 15:34:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:34:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:34:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:34:51 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:34:51 --> Final output sent to browser
DEBUG - 2017-06-15 15:34:51 --> Total execution time: 0.0512
INFO - 2017-06-15 15:34:53 --> Config Class Initialized
INFO - 2017-06-15 15:34:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:53 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:53 --> URI Class Initialized
INFO - 2017-06-15 15:34:53 --> Router Class Initialized
INFO - 2017-06-15 15:34:53 --> Output Class Initialized
INFO - 2017-06-15 15:34:53 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:53 --> Input Class Initialized
INFO - 2017-06-15 15:34:53 --> Language Class Initialized
INFO - 2017-06-15 15:34:53 --> Loader Class Initialized
INFO - 2017-06-15 15:34:53 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:53 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:53 --> Email Class Initialized
INFO - 2017-06-15 15:34:53 --> Controller Class Initialized
INFO - 2017-06-15 15:34:53 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:53 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:53 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:53 --> Model Class Initialized
INFO - 2017-06-15 15:34:53 --> Model Class Initialized
INFO - 2017-06-15 15:34:53 --> Config Class Initialized
INFO - 2017-06-15 15:34:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:53 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:53 --> URI Class Initialized
INFO - 2017-06-15 15:34:53 --> Router Class Initialized
INFO - 2017-06-15 15:34:53 --> Output Class Initialized
INFO - 2017-06-15 15:34:53 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:53 --> Input Class Initialized
INFO - 2017-06-15 15:34:53 --> Language Class Initialized
INFO - 2017-06-15 15:34:53 --> Loader Class Initialized
INFO - 2017-06-15 15:34:53 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:53 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:53 --> Email Class Initialized
INFO - 2017-06-15 15:34:53 --> Controller Class Initialized
INFO - 2017-06-15 15:34:53 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:53 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:53 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:53 --> Model Class Initialized
INFO - 2017-06-15 15:34:53 --> Model Class Initialized
INFO - 2017-06-15 15:34:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:34:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:34:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:34:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:34:53 --> Final output sent to browser
DEBUG - 2017-06-15 15:34:53 --> Total execution time: 0.0529
INFO - 2017-06-15 15:34:54 --> Config Class Initialized
INFO - 2017-06-15 15:34:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:54 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:54 --> URI Class Initialized
INFO - 2017-06-15 15:34:54 --> Router Class Initialized
INFO - 2017-06-15 15:34:54 --> Output Class Initialized
INFO - 2017-06-15 15:34:54 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:54 --> Input Class Initialized
INFO - 2017-06-15 15:34:54 --> Language Class Initialized
INFO - 2017-06-15 15:34:54 --> Loader Class Initialized
INFO - 2017-06-15 15:34:54 --> Helper loaded: common_helper
INFO - 2017-06-15 15:34:54 --> Database Driver Class Initialized
INFO - 2017-06-15 15:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:34:54 --> Email Class Initialized
INFO - 2017-06-15 15:34:54 --> Controller Class Initialized
INFO - 2017-06-15 15:34:54 --> Helper loaded: form_helper
INFO - 2017-06-15 15:34:54 --> Form Validation Class Initialized
INFO - 2017-06-15 15:34:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:34:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:34:54 --> Helper loaded: url_helper
INFO - 2017-06-15 15:34:54 --> Model Class Initialized
INFO - 2017-06-15 15:34:54 --> Model Class Initialized
INFO - 2017-06-15 15:34:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:34:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:34:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:34:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:34:54 --> Final output sent to browser
DEBUG - 2017-06-15 15:34:54 --> Total execution time: 0.0438
INFO - 2017-06-15 15:34:57 --> Config Class Initialized
INFO - 2017-06-15 15:34:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:34:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:34:57 --> Utf8 Class Initialized
INFO - 2017-06-15 15:34:57 --> URI Class Initialized
INFO - 2017-06-15 15:34:57 --> Router Class Initialized
INFO - 2017-06-15 15:34:57 --> Output Class Initialized
INFO - 2017-06-15 15:34:57 --> Security Class Initialized
DEBUG - 2017-06-15 15:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:34:57 --> Input Class Initialized
INFO - 2017-06-15 15:34:57 --> Language Class Initialized
ERROR - 2017-06-15 15:34:57 --> 404 Page Not Found: Admin/changepassword
INFO - 2017-06-15 15:40:13 --> Config Class Initialized
INFO - 2017-06-15 15:40:13 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:40:13 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:40:13 --> Utf8 Class Initialized
INFO - 2017-06-15 15:40:13 --> URI Class Initialized
INFO - 2017-06-15 15:40:13 --> Router Class Initialized
INFO - 2017-06-15 15:40:13 --> Output Class Initialized
INFO - 2017-06-15 15:40:13 --> Security Class Initialized
DEBUG - 2017-06-15 15:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:40:13 --> Input Class Initialized
INFO - 2017-06-15 15:40:13 --> Language Class Initialized
INFO - 2017-06-15 15:40:13 --> Loader Class Initialized
INFO - 2017-06-15 15:40:13 --> Helper loaded: common_helper
INFO - 2017-06-15 15:40:13 --> Database Driver Class Initialized
INFO - 2017-06-15 15:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:40:13 --> Email Class Initialized
INFO - 2017-06-15 15:40:13 --> Controller Class Initialized
INFO - 2017-06-15 15:40:13 --> Helper loaded: form_helper
INFO - 2017-06-15 15:40:13 --> Form Validation Class Initialized
INFO - 2017-06-15 15:40:13 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:40:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:40:13 --> Helper loaded: url_helper
INFO - 2017-06-15 15:40:13 --> Model Class Initialized
INFO - 2017-06-15 15:40:13 --> Model Class Initialized
INFO - 2017-06-15 15:40:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:40:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:40:13 --> Final output sent to browser
DEBUG - 2017-06-15 15:40:13 --> Total execution time: 0.0480
INFO - 2017-06-15 15:45:25 --> Config Class Initialized
INFO - 2017-06-15 15:45:25 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:45:25 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:45:25 --> Utf8 Class Initialized
INFO - 2017-06-15 15:45:25 --> URI Class Initialized
INFO - 2017-06-15 15:45:25 --> Router Class Initialized
INFO - 2017-06-15 15:45:25 --> Output Class Initialized
INFO - 2017-06-15 15:45:25 --> Security Class Initialized
DEBUG - 2017-06-15 15:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:45:25 --> Input Class Initialized
INFO - 2017-06-15 15:45:25 --> Language Class Initialized
INFO - 2017-06-15 15:45:25 --> Loader Class Initialized
INFO - 2017-06-15 15:45:25 --> Helper loaded: common_helper
INFO - 2017-06-15 15:45:25 --> Database Driver Class Initialized
INFO - 2017-06-15 15:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:45:25 --> Email Class Initialized
INFO - 2017-06-15 15:45:25 --> Controller Class Initialized
INFO - 2017-06-15 15:45:25 --> Helper loaded: form_helper
INFO - 2017-06-15 15:45:25 --> Form Validation Class Initialized
INFO - 2017-06-15 15:45:25 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:45:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:45:25 --> Helper loaded: url_helper
INFO - 2017-06-15 15:45:25 --> Model Class Initialized
INFO - 2017-06-15 15:45:25 --> Model Class Initialized
INFO - 2017-06-15 15:45:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:45:25 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:45:25 --> Final output sent to browser
DEBUG - 2017-06-15 15:45:25 --> Total execution time: 0.0452
INFO - 2017-06-15 15:45:47 --> Config Class Initialized
INFO - 2017-06-15 15:45:47 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:45:47 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:45:47 --> Utf8 Class Initialized
INFO - 2017-06-15 15:45:47 --> URI Class Initialized
INFO - 2017-06-15 15:45:47 --> Router Class Initialized
INFO - 2017-06-15 15:45:47 --> Output Class Initialized
INFO - 2017-06-15 15:45:47 --> Security Class Initialized
DEBUG - 2017-06-15 15:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:45:47 --> Input Class Initialized
INFO - 2017-06-15 15:45:47 --> Language Class Initialized
INFO - 2017-06-15 15:45:47 --> Loader Class Initialized
INFO - 2017-06-15 15:45:47 --> Helper loaded: common_helper
INFO - 2017-06-15 15:45:47 --> Database Driver Class Initialized
INFO - 2017-06-15 15:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:45:48 --> Email Class Initialized
INFO - 2017-06-15 15:45:48 --> Controller Class Initialized
INFO - 2017-06-15 15:45:48 --> Helper loaded: form_helper
INFO - 2017-06-15 15:45:48 --> Form Validation Class Initialized
INFO - 2017-06-15 15:45:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:45:48 --> Helper loaded: url_helper
INFO - 2017-06-15 15:45:48 --> Model Class Initialized
INFO - 2017-06-15 15:45:48 --> Model Class Initialized
INFO - 2017-06-15 15:45:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:45:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:45:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:45:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:45:48 --> Final output sent to browser
DEBUG - 2017-06-15 15:45:48 --> Total execution time: 0.0477
INFO - 2017-06-15 15:45:59 --> Config Class Initialized
INFO - 2017-06-15 15:45:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:45:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:45:59 --> Utf8 Class Initialized
INFO - 2017-06-15 15:45:59 --> URI Class Initialized
INFO - 2017-06-15 15:45:59 --> Router Class Initialized
INFO - 2017-06-15 15:45:59 --> Output Class Initialized
INFO - 2017-06-15 15:45:59 --> Security Class Initialized
DEBUG - 2017-06-15 15:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:45:59 --> Input Class Initialized
INFO - 2017-06-15 15:45:59 --> Language Class Initialized
INFO - 2017-06-15 15:45:59 --> Loader Class Initialized
INFO - 2017-06-15 15:45:59 --> Helper loaded: common_helper
INFO - 2017-06-15 15:45:59 --> Database Driver Class Initialized
INFO - 2017-06-15 15:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:45:59 --> Email Class Initialized
INFO - 2017-06-15 15:45:59 --> Controller Class Initialized
INFO - 2017-06-15 15:45:59 --> Helper loaded: form_helper
INFO - 2017-06-15 15:45:59 --> Form Validation Class Initialized
INFO - 2017-06-15 15:45:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:45:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:45:59 --> Helper loaded: url_helper
INFO - 2017-06-15 15:45:59 --> Model Class Initialized
INFO - 2017-06-15 15:45:59 --> Model Class Initialized
INFO - 2017-06-15 15:45:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:45:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:45:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:45:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:45:59 --> Final output sent to browser
DEBUG - 2017-06-15 15:45:59 --> Total execution time: 0.0495
INFO - 2017-06-15 15:46:05 --> Config Class Initialized
INFO - 2017-06-15 15:46:05 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:46:05 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:46:05 --> Utf8 Class Initialized
INFO - 2017-06-15 15:46:05 --> URI Class Initialized
INFO - 2017-06-15 15:46:05 --> Router Class Initialized
INFO - 2017-06-15 15:46:05 --> Output Class Initialized
INFO - 2017-06-15 15:46:05 --> Security Class Initialized
DEBUG - 2017-06-15 15:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:46:05 --> Input Class Initialized
INFO - 2017-06-15 15:46:05 --> Language Class Initialized
INFO - 2017-06-15 15:46:05 --> Loader Class Initialized
INFO - 2017-06-15 15:46:05 --> Helper loaded: common_helper
INFO - 2017-06-15 15:46:05 --> Database Driver Class Initialized
INFO - 2017-06-15 15:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:46:05 --> Email Class Initialized
INFO - 2017-06-15 15:46:05 --> Controller Class Initialized
INFO - 2017-06-15 15:46:05 --> Helper loaded: form_helper
INFO - 2017-06-15 15:46:05 --> Form Validation Class Initialized
INFO - 2017-06-15 15:46:05 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:46:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:46:05 --> Helper loaded: url_helper
INFO - 2017-06-15 15:46:05 --> Model Class Initialized
INFO - 2017-06-15 15:46:05 --> Model Class Initialized
DEBUG - 2017-06-15 15:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:46:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:46:48 --> Config Class Initialized
INFO - 2017-06-15 15:46:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:46:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:46:48 --> Utf8 Class Initialized
INFO - 2017-06-15 15:46:48 --> URI Class Initialized
INFO - 2017-06-15 15:46:48 --> Router Class Initialized
INFO - 2017-06-15 15:46:48 --> Output Class Initialized
INFO - 2017-06-15 15:46:48 --> Security Class Initialized
DEBUG - 2017-06-15 15:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:46:48 --> Input Class Initialized
INFO - 2017-06-15 15:46:48 --> Language Class Initialized
INFO - 2017-06-15 15:46:48 --> Loader Class Initialized
INFO - 2017-06-15 15:46:48 --> Helper loaded: common_helper
INFO - 2017-06-15 15:46:48 --> Database Driver Class Initialized
INFO - 2017-06-15 15:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:46:48 --> Email Class Initialized
INFO - 2017-06-15 15:46:48 --> Controller Class Initialized
INFO - 2017-06-15 15:46:48 --> Helper loaded: form_helper
INFO - 2017-06-15 15:46:48 --> Form Validation Class Initialized
INFO - 2017-06-15 15:46:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:46:48 --> Helper loaded: url_helper
INFO - 2017-06-15 15:46:48 --> Model Class Initialized
INFO - 2017-06-15 15:46:48 --> Model Class Initialized
DEBUG - 2017-06-15 15:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:46:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:46:48 --> Config Class Initialized
INFO - 2017-06-15 15:46:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:46:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:46:48 --> Utf8 Class Initialized
INFO - 2017-06-15 15:46:48 --> URI Class Initialized
INFO - 2017-06-15 15:46:48 --> Router Class Initialized
INFO - 2017-06-15 15:46:48 --> Output Class Initialized
INFO - 2017-06-15 15:46:48 --> Security Class Initialized
DEBUG - 2017-06-15 15:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:46:48 --> Input Class Initialized
INFO - 2017-06-15 15:46:48 --> Language Class Initialized
INFO - 2017-06-15 15:46:48 --> Loader Class Initialized
INFO - 2017-06-15 15:46:48 --> Helper loaded: common_helper
INFO - 2017-06-15 15:46:48 --> Database Driver Class Initialized
INFO - 2017-06-15 15:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:46:48 --> Email Class Initialized
INFO - 2017-06-15 15:46:48 --> Controller Class Initialized
INFO - 2017-06-15 15:46:48 --> Helper loaded: form_helper
INFO - 2017-06-15 15:46:48 --> Form Validation Class Initialized
INFO - 2017-06-15 15:46:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:46:48 --> Helper loaded: url_helper
INFO - 2017-06-15 15:46:48 --> Model Class Initialized
INFO - 2017-06-15 15:46:48 --> Model Class Initialized
INFO - 2017-06-15 15:46:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:46:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:46:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:46:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:46:48 --> Final output sent to browser
DEBUG - 2017-06-15 15:46:48 --> Total execution time: 0.0473
INFO - 2017-06-15 15:47:24 --> Config Class Initialized
INFO - 2017-06-15 15:47:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:24 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:24 --> URI Class Initialized
INFO - 2017-06-15 15:47:24 --> Router Class Initialized
INFO - 2017-06-15 15:47:24 --> Output Class Initialized
INFO - 2017-06-15 15:47:24 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:24 --> Input Class Initialized
INFO - 2017-06-15 15:47:24 --> Language Class Initialized
INFO - 2017-06-15 15:47:24 --> Loader Class Initialized
INFO - 2017-06-15 15:47:24 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:24 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:24 --> Email Class Initialized
INFO - 2017-06-15 15:47:24 --> Controller Class Initialized
INFO - 2017-06-15 15:47:24 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:24 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:24 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:24 --> Model Class Initialized
INFO - 2017-06-15 15:47:24 --> Model Class Initialized
INFO - 2017-06-15 15:47:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:47:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:47:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:47:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:47:24 --> Final output sent to browser
DEBUG - 2017-06-15 15:47:24 --> Total execution time: 0.0472
INFO - 2017-06-15 15:47:28 --> Config Class Initialized
INFO - 2017-06-15 15:47:28 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:28 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:28 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:28 --> URI Class Initialized
INFO - 2017-06-15 15:47:28 --> Router Class Initialized
INFO - 2017-06-15 15:47:28 --> Output Class Initialized
INFO - 2017-06-15 15:47:28 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:28 --> Input Class Initialized
INFO - 2017-06-15 15:47:28 --> Language Class Initialized
INFO - 2017-06-15 15:47:28 --> Loader Class Initialized
INFO - 2017-06-15 15:47:28 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:28 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:28 --> Email Class Initialized
INFO - 2017-06-15 15:47:28 --> Controller Class Initialized
INFO - 2017-06-15 15:47:28 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:28 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:28 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:28 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:28 --> Model Class Initialized
INFO - 2017-06-15 15:47:28 --> Model Class Initialized
DEBUG - 2017-06-15 15:47:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:47:28 --> Config Class Initialized
INFO - 2017-06-15 15:47:28 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:28 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:28 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:28 --> URI Class Initialized
INFO - 2017-06-15 15:47:28 --> Router Class Initialized
INFO - 2017-06-15 15:47:28 --> Output Class Initialized
INFO - 2017-06-15 15:47:28 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:28 --> Input Class Initialized
INFO - 2017-06-15 15:47:28 --> Language Class Initialized
INFO - 2017-06-15 15:47:28 --> Loader Class Initialized
INFO - 2017-06-15 15:47:28 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:28 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:28 --> Email Class Initialized
INFO - 2017-06-15 15:47:28 --> Controller Class Initialized
INFO - 2017-06-15 15:47:28 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:28 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:28 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:28 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:28 --> Model Class Initialized
INFO - 2017-06-15 15:47:28 --> Model Class Initialized
INFO - 2017-06-15 15:47:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:47:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:47:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:47:28 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:47:28 --> Final output sent to browser
DEBUG - 2017-06-15 15:47:28 --> Total execution time: 0.0541
INFO - 2017-06-15 15:47:35 --> Config Class Initialized
INFO - 2017-06-15 15:47:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:35 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:35 --> URI Class Initialized
INFO - 2017-06-15 15:47:35 --> Router Class Initialized
INFO - 2017-06-15 15:47:35 --> Output Class Initialized
INFO - 2017-06-15 15:47:35 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:35 --> Input Class Initialized
INFO - 2017-06-15 15:47:35 --> Language Class Initialized
INFO - 2017-06-15 15:47:35 --> Loader Class Initialized
INFO - 2017-06-15 15:47:35 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:35 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:35 --> Email Class Initialized
INFO - 2017-06-15 15:47:35 --> Controller Class Initialized
INFO - 2017-06-15 15:47:35 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:35 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:35 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:35 --> Model Class Initialized
INFO - 2017-06-15 15:47:35 --> Model Class Initialized
DEBUG - 2017-06-15 15:47:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:47:35 --> Config Class Initialized
INFO - 2017-06-15 15:47:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:35 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:35 --> URI Class Initialized
INFO - 2017-06-15 15:47:35 --> Router Class Initialized
INFO - 2017-06-15 15:47:35 --> Output Class Initialized
INFO - 2017-06-15 15:47:35 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:35 --> Input Class Initialized
INFO - 2017-06-15 15:47:35 --> Language Class Initialized
INFO - 2017-06-15 15:47:35 --> Loader Class Initialized
INFO - 2017-06-15 15:47:35 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:35 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:35 --> Email Class Initialized
INFO - 2017-06-15 15:47:35 --> Controller Class Initialized
INFO - 2017-06-15 15:47:35 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:35 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:35 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:35 --> Model Class Initialized
INFO - 2017-06-15 15:47:35 --> Model Class Initialized
INFO - 2017-06-15 15:47:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:47:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:47:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:47:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:47:35 --> Final output sent to browser
DEBUG - 2017-06-15 15:47:35 --> Total execution time: 0.0538
INFO - 2017-06-15 15:47:49 --> Config Class Initialized
INFO - 2017-06-15 15:47:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:49 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:49 --> URI Class Initialized
INFO - 2017-06-15 15:47:49 --> Router Class Initialized
INFO - 2017-06-15 15:47:49 --> Output Class Initialized
INFO - 2017-06-15 15:47:49 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:49 --> Input Class Initialized
INFO - 2017-06-15 15:47:49 --> Language Class Initialized
INFO - 2017-06-15 15:47:49 --> Loader Class Initialized
INFO - 2017-06-15 15:47:49 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:49 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:49 --> Email Class Initialized
INFO - 2017-06-15 15:47:49 --> Controller Class Initialized
INFO - 2017-06-15 15:47:49 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:49 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:49 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:49 --> Model Class Initialized
INFO - 2017-06-15 15:47:49 --> Model Class Initialized
INFO - 2017-06-15 15:47:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:47:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:47:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:47:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:47:49 --> Final output sent to browser
DEBUG - 2017-06-15 15:47:49 --> Total execution time: 0.0442
INFO - 2017-06-15 15:47:55 --> Config Class Initialized
INFO - 2017-06-15 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:55 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:55 --> URI Class Initialized
INFO - 2017-06-15 15:47:55 --> Router Class Initialized
INFO - 2017-06-15 15:47:55 --> Output Class Initialized
INFO - 2017-06-15 15:47:55 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:55 --> Input Class Initialized
INFO - 2017-06-15 15:47:55 --> Language Class Initialized
INFO - 2017-06-15 15:47:55 --> Loader Class Initialized
INFO - 2017-06-15 15:47:55 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:55 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:55 --> Email Class Initialized
INFO - 2017-06-15 15:47:55 --> Controller Class Initialized
INFO - 2017-06-15 15:47:55 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:55 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:55 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:55 --> Model Class Initialized
INFO - 2017-06-15 15:47:55 --> Model Class Initialized
DEBUG - 2017-06-15 15:47:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:47:55 --> Config Class Initialized
INFO - 2017-06-15 15:47:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:47:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:47:55 --> Utf8 Class Initialized
INFO - 2017-06-15 15:47:55 --> URI Class Initialized
INFO - 2017-06-15 15:47:55 --> Router Class Initialized
INFO - 2017-06-15 15:47:55 --> Output Class Initialized
INFO - 2017-06-15 15:47:55 --> Security Class Initialized
DEBUG - 2017-06-15 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:47:55 --> Input Class Initialized
INFO - 2017-06-15 15:47:55 --> Language Class Initialized
INFO - 2017-06-15 15:47:55 --> Loader Class Initialized
INFO - 2017-06-15 15:47:55 --> Helper loaded: common_helper
INFO - 2017-06-15 15:47:55 --> Database Driver Class Initialized
INFO - 2017-06-15 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:47:55 --> Email Class Initialized
INFO - 2017-06-15 15:47:55 --> Controller Class Initialized
INFO - 2017-06-15 15:47:55 --> Helper loaded: form_helper
INFO - 2017-06-15 15:47:55 --> Form Validation Class Initialized
INFO - 2017-06-15 15:47:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:47:55 --> Helper loaded: url_helper
INFO - 2017-06-15 15:47:55 --> Model Class Initialized
INFO - 2017-06-15 15:47:55 --> Model Class Initialized
INFO - 2017-06-15 15:47:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:47:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:47:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:47:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:47:55 --> Final output sent to browser
DEBUG - 2017-06-15 15:47:55 --> Total execution time: 0.0515
INFO - 2017-06-15 15:48:04 --> Config Class Initialized
INFO - 2017-06-15 15:48:04 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:04 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:04 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:04 --> URI Class Initialized
INFO - 2017-06-15 15:48:04 --> Router Class Initialized
INFO - 2017-06-15 15:48:04 --> Output Class Initialized
INFO - 2017-06-15 15:48:04 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:04 --> Input Class Initialized
INFO - 2017-06-15 15:48:04 --> Language Class Initialized
INFO - 2017-06-15 15:48:04 --> Loader Class Initialized
INFO - 2017-06-15 15:48:04 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:04 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:04 --> Email Class Initialized
INFO - 2017-06-15 15:48:04 --> Controller Class Initialized
INFO - 2017-06-15 15:48:04 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:04 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:04 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:04 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:04 --> Model Class Initialized
INFO - 2017-06-15 15:48:04 --> Model Class Initialized
INFO - 2017-06-15 15:48:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:48:04 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:04 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:04 --> Total execution time: 0.0439
INFO - 2017-06-15 15:48:10 --> Config Class Initialized
INFO - 2017-06-15 15:48:10 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:10 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:10 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:10 --> URI Class Initialized
INFO - 2017-06-15 15:48:10 --> Router Class Initialized
INFO - 2017-06-15 15:48:10 --> Output Class Initialized
INFO - 2017-06-15 15:48:10 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:10 --> Input Class Initialized
INFO - 2017-06-15 15:48:10 --> Language Class Initialized
INFO - 2017-06-15 15:48:10 --> Loader Class Initialized
INFO - 2017-06-15 15:48:10 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:10 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:10 --> Email Class Initialized
INFO - 2017-06-15 15:48:10 --> Controller Class Initialized
INFO - 2017-06-15 15:48:10 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:10 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:10 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:10 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:10 --> Model Class Initialized
INFO - 2017-06-15 15:48:10 --> Model Class Initialized
INFO - 2017-06-15 15:48:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:48:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:48:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:10 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:10 --> Total execution time: 0.0885
INFO - 2017-06-15 15:48:14 --> Config Class Initialized
INFO - 2017-06-15 15:48:14 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:14 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:14 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:14 --> URI Class Initialized
INFO - 2017-06-15 15:48:14 --> Router Class Initialized
INFO - 2017-06-15 15:48:14 --> Output Class Initialized
INFO - 2017-06-15 15:48:14 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:14 --> Input Class Initialized
INFO - 2017-06-15 15:48:14 --> Language Class Initialized
INFO - 2017-06-15 15:48:14 --> Loader Class Initialized
INFO - 2017-06-15 15:48:14 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:14 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:14 --> Email Class Initialized
INFO - 2017-06-15 15:48:14 --> Controller Class Initialized
INFO - 2017-06-15 15:48:14 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:14 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:14 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:14 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:14 --> Model Class Initialized
INFO - 2017-06-15 15:48:14 --> Model Class Initialized
INFO - 2017-06-15 15:48:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:48:14 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:14 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:14 --> Total execution time: 0.0461
INFO - 2017-06-15 15:48:15 --> Config Class Initialized
INFO - 2017-06-15 15:48:15 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:15 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:15 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:15 --> URI Class Initialized
INFO - 2017-06-15 15:48:15 --> Router Class Initialized
INFO - 2017-06-15 15:48:15 --> Output Class Initialized
INFO - 2017-06-15 15:48:15 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:15 --> Input Class Initialized
INFO - 2017-06-15 15:48:15 --> Language Class Initialized
INFO - 2017-06-15 15:48:15 --> Loader Class Initialized
INFO - 2017-06-15 15:48:15 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:15 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:15 --> Email Class Initialized
INFO - 2017-06-15 15:48:15 --> Controller Class Initialized
INFO - 2017-06-15 15:48:15 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:15 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:15 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:15 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:15 --> Model Class Initialized
INFO - 2017-06-15 15:48:15 --> Model Class Initialized
INFO - 2017-06-15 15:48:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:48:15 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:15 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:15 --> Total execution time: 0.0466
INFO - 2017-06-15 15:48:17 --> Config Class Initialized
INFO - 2017-06-15 15:48:17 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:17 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:17 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:17 --> URI Class Initialized
INFO - 2017-06-15 15:48:17 --> Router Class Initialized
INFO - 2017-06-15 15:48:17 --> Output Class Initialized
INFO - 2017-06-15 15:48:17 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:17 --> Input Class Initialized
INFO - 2017-06-15 15:48:17 --> Language Class Initialized
INFO - 2017-06-15 15:48:17 --> Loader Class Initialized
INFO - 2017-06-15 15:48:17 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:17 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:17 --> Email Class Initialized
INFO - 2017-06-15 15:48:17 --> Controller Class Initialized
INFO - 2017-06-15 15:48:17 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:17 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:17 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:17 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:17 --> Model Class Initialized
INFO - 2017-06-15 15:48:17 --> Model Class Initialized
INFO - 2017-06-15 15:48:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:48:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:17 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:17 --> Total execution time: 0.0453
INFO - 2017-06-15 15:48:24 --> Config Class Initialized
INFO - 2017-06-15 15:48:24 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:24 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:24 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:24 --> URI Class Initialized
INFO - 2017-06-15 15:48:24 --> Router Class Initialized
INFO - 2017-06-15 15:48:24 --> Output Class Initialized
INFO - 2017-06-15 15:48:24 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:24 --> Input Class Initialized
INFO - 2017-06-15 15:48:24 --> Language Class Initialized
INFO - 2017-06-15 15:48:24 --> Loader Class Initialized
INFO - 2017-06-15 15:48:24 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:24 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:24 --> Email Class Initialized
INFO - 2017-06-15 15:48:24 --> Controller Class Initialized
INFO - 2017-06-15 15:48:24 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:24 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:24 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:24 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:24 --> Model Class Initialized
INFO - 2017-06-15 15:48:24 --> Model Class Initialized
INFO - 2017-06-15 15:48:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:48:24 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:24 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:24 --> Total execution time: 0.0446
INFO - 2017-06-15 15:48:27 --> Config Class Initialized
INFO - 2017-06-15 15:48:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:27 --> URI Class Initialized
INFO - 2017-06-15 15:48:27 --> Router Class Initialized
INFO - 2017-06-15 15:48:27 --> Output Class Initialized
INFO - 2017-06-15 15:48:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:27 --> Input Class Initialized
INFO - 2017-06-15 15:48:27 --> Language Class Initialized
INFO - 2017-06-15 15:48:27 --> Loader Class Initialized
INFO - 2017-06-15 15:48:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:27 --> Email Class Initialized
INFO - 2017-06-15 15:48:27 --> Controller Class Initialized
INFO - 2017-06-15 15:48:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:27 --> Model Class Initialized
INFO - 2017-06-15 15:48:27 --> Model Class Initialized
INFO - 2017-06-15 15:48:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:48:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:27 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:27 --> Total execution time: 0.0482
INFO - 2017-06-15 15:48:57 --> Config Class Initialized
INFO - 2017-06-15 15:48:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:48:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:48:57 --> Utf8 Class Initialized
INFO - 2017-06-15 15:48:57 --> URI Class Initialized
INFO - 2017-06-15 15:48:57 --> Router Class Initialized
INFO - 2017-06-15 15:48:57 --> Output Class Initialized
INFO - 2017-06-15 15:48:57 --> Security Class Initialized
DEBUG - 2017-06-15 15:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:48:57 --> Input Class Initialized
INFO - 2017-06-15 15:48:57 --> Language Class Initialized
INFO - 2017-06-15 15:48:57 --> Loader Class Initialized
INFO - 2017-06-15 15:48:57 --> Helper loaded: common_helper
INFO - 2017-06-15 15:48:57 --> Database Driver Class Initialized
INFO - 2017-06-15 15:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:48:57 --> Email Class Initialized
INFO - 2017-06-15 15:48:57 --> Controller Class Initialized
INFO - 2017-06-15 15:48:57 --> Helper loaded: form_helper
INFO - 2017-06-15 15:48:57 --> Form Validation Class Initialized
INFO - 2017-06-15 15:48:57 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:48:57 --> Helper loaded: url_helper
INFO - 2017-06-15 15:48:57 --> Model Class Initialized
INFO - 2017-06-15 15:48:57 --> Model Class Initialized
INFO - 2017-06-15 15:48:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:48:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:48:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:48:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:48:57 --> Final output sent to browser
DEBUG - 2017-06-15 15:48:57 --> Total execution time: 0.0469
INFO - 2017-06-15 15:49:10 --> Config Class Initialized
INFO - 2017-06-15 15:49:10 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:49:10 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:49:10 --> Utf8 Class Initialized
INFO - 2017-06-15 15:49:10 --> URI Class Initialized
INFO - 2017-06-15 15:49:10 --> Router Class Initialized
INFO - 2017-06-15 15:49:10 --> Output Class Initialized
INFO - 2017-06-15 15:49:10 --> Security Class Initialized
DEBUG - 2017-06-15 15:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:49:10 --> Input Class Initialized
INFO - 2017-06-15 15:49:10 --> Language Class Initialized
INFO - 2017-06-15 15:49:10 --> Loader Class Initialized
INFO - 2017-06-15 15:49:10 --> Helper loaded: common_helper
INFO - 2017-06-15 15:49:10 --> Database Driver Class Initialized
INFO - 2017-06-15 15:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:49:10 --> Email Class Initialized
INFO - 2017-06-15 15:49:10 --> Controller Class Initialized
INFO - 2017-06-15 15:49:10 --> Helper loaded: form_helper
INFO - 2017-06-15 15:49:10 --> Form Validation Class Initialized
INFO - 2017-06-15 15:49:10 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:49:10 --> Helper loaded: url_helper
INFO - 2017-06-15 15:49:10 --> Model Class Initialized
INFO - 2017-06-15 15:49:10 --> Model Class Initialized
INFO - 2017-06-15 15:49:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:49:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:49:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:49:10 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:49:10 --> Final output sent to browser
DEBUG - 2017-06-15 15:49:10 --> Total execution time: 0.0467
INFO - 2017-06-15 15:49:18 --> Config Class Initialized
INFO - 2017-06-15 15:49:18 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:49:18 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:49:18 --> Utf8 Class Initialized
INFO - 2017-06-15 15:49:18 --> URI Class Initialized
INFO - 2017-06-15 15:49:18 --> Router Class Initialized
INFO - 2017-06-15 15:49:18 --> Output Class Initialized
INFO - 2017-06-15 15:49:18 --> Security Class Initialized
DEBUG - 2017-06-15 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:49:18 --> Input Class Initialized
INFO - 2017-06-15 15:49:18 --> Language Class Initialized
INFO - 2017-06-15 15:49:18 --> Loader Class Initialized
INFO - 2017-06-15 15:49:18 --> Helper loaded: common_helper
INFO - 2017-06-15 15:49:18 --> Database Driver Class Initialized
INFO - 2017-06-15 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:49:18 --> Email Class Initialized
INFO - 2017-06-15 15:49:18 --> Controller Class Initialized
INFO - 2017-06-15 15:49:18 --> Helper loaded: form_helper
INFO - 2017-06-15 15:49:18 --> Form Validation Class Initialized
INFO - 2017-06-15 15:49:18 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:49:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:49:18 --> Helper loaded: url_helper
INFO - 2017-06-15 15:49:18 --> Model Class Initialized
INFO - 2017-06-15 15:49:18 --> Model Class Initialized
INFO - 2017-06-15 15:49:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:49:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:49:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:49:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:49:18 --> Final output sent to browser
DEBUG - 2017-06-15 15:49:18 --> Total execution time: 0.0469
INFO - 2017-06-15 15:49:30 --> Config Class Initialized
INFO - 2017-06-15 15:49:30 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:49:30 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:49:30 --> Utf8 Class Initialized
INFO - 2017-06-15 15:49:30 --> URI Class Initialized
INFO - 2017-06-15 15:49:30 --> Router Class Initialized
INFO - 2017-06-15 15:49:30 --> Output Class Initialized
INFO - 2017-06-15 15:49:30 --> Security Class Initialized
DEBUG - 2017-06-15 15:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:49:30 --> Input Class Initialized
INFO - 2017-06-15 15:49:30 --> Language Class Initialized
INFO - 2017-06-15 15:49:30 --> Loader Class Initialized
INFO - 2017-06-15 15:49:30 --> Helper loaded: common_helper
INFO - 2017-06-15 15:49:30 --> Database Driver Class Initialized
INFO - 2017-06-15 15:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:49:30 --> Email Class Initialized
INFO - 2017-06-15 15:49:30 --> Controller Class Initialized
INFO - 2017-06-15 15:49:30 --> Helper loaded: form_helper
INFO - 2017-06-15 15:49:30 --> Form Validation Class Initialized
INFO - 2017-06-15 15:49:30 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:49:30 --> Helper loaded: url_helper
INFO - 2017-06-15 15:49:30 --> Model Class Initialized
INFO - 2017-06-15 15:49:30 --> Model Class Initialized
INFO - 2017-06-15 15:49:30 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:49:30 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:49:30 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:49:30 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:49:30 --> Final output sent to browser
DEBUG - 2017-06-15 15:49:30 --> Total execution time: 0.0460
INFO - 2017-06-15 15:49:41 --> Config Class Initialized
INFO - 2017-06-15 15:49:41 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:49:41 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:49:41 --> Utf8 Class Initialized
INFO - 2017-06-15 15:49:41 --> URI Class Initialized
INFO - 2017-06-15 15:49:41 --> Router Class Initialized
INFO - 2017-06-15 15:49:41 --> Output Class Initialized
INFO - 2017-06-15 15:49:41 --> Security Class Initialized
DEBUG - 2017-06-15 15:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:49:41 --> Input Class Initialized
INFO - 2017-06-15 15:49:41 --> Language Class Initialized
INFO - 2017-06-15 15:49:41 --> Loader Class Initialized
INFO - 2017-06-15 15:49:41 --> Helper loaded: common_helper
INFO - 2017-06-15 15:49:41 --> Database Driver Class Initialized
INFO - 2017-06-15 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:49:41 --> Email Class Initialized
INFO - 2017-06-15 15:49:41 --> Controller Class Initialized
INFO - 2017-06-15 15:49:41 --> Helper loaded: form_helper
INFO - 2017-06-15 15:49:41 --> Form Validation Class Initialized
INFO - 2017-06-15 15:49:41 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:49:41 --> Helper loaded: url_helper
INFO - 2017-06-15 15:49:41 --> Model Class Initialized
INFO - 2017-06-15 15:49:41 --> Model Class Initialized
INFO - 2017-06-15 15:49:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:49:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:49:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:49:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:49:41 --> Final output sent to browser
DEBUG - 2017-06-15 15:49:41 --> Total execution time: 0.0473
INFO - 2017-06-15 15:49:48 --> Config Class Initialized
INFO - 2017-06-15 15:49:48 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:49:48 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:49:48 --> Utf8 Class Initialized
INFO - 2017-06-15 15:49:48 --> URI Class Initialized
INFO - 2017-06-15 15:49:48 --> Router Class Initialized
INFO - 2017-06-15 15:49:48 --> Output Class Initialized
INFO - 2017-06-15 15:49:48 --> Security Class Initialized
DEBUG - 2017-06-15 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:49:48 --> Input Class Initialized
INFO - 2017-06-15 15:49:48 --> Language Class Initialized
INFO - 2017-06-15 15:49:48 --> Loader Class Initialized
INFO - 2017-06-15 15:49:48 --> Helper loaded: common_helper
INFO - 2017-06-15 15:49:48 --> Database Driver Class Initialized
INFO - 2017-06-15 15:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:49:48 --> Email Class Initialized
INFO - 2017-06-15 15:49:48 --> Controller Class Initialized
INFO - 2017-06-15 15:49:48 --> Helper loaded: form_helper
INFO - 2017-06-15 15:49:48 --> Form Validation Class Initialized
INFO - 2017-06-15 15:49:48 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:49:48 --> Helper loaded: url_helper
INFO - 2017-06-15 15:49:48 --> Model Class Initialized
INFO - 2017-06-15 15:49:48 --> Model Class Initialized
INFO - 2017-06-15 15:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:49:48 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:49:48 --> Final output sent to browser
DEBUG - 2017-06-15 15:49:48 --> Total execution time: 0.0463
INFO - 2017-06-15 15:50:06 --> Config Class Initialized
INFO - 2017-06-15 15:50:06 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:06 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:06 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:06 --> URI Class Initialized
INFO - 2017-06-15 15:50:06 --> Router Class Initialized
INFO - 2017-06-15 15:50:06 --> Output Class Initialized
INFO - 2017-06-15 15:50:06 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:06 --> Input Class Initialized
INFO - 2017-06-15 15:50:06 --> Language Class Initialized
INFO - 2017-06-15 15:50:06 --> Loader Class Initialized
INFO - 2017-06-15 15:50:06 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:06 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:06 --> Email Class Initialized
INFO - 2017-06-15 15:50:06 --> Controller Class Initialized
INFO - 2017-06-15 15:50:06 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:06 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:06 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:06 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:06 --> Model Class Initialized
INFO - 2017-06-15 15:50:06 --> Model Class Initialized
INFO - 2017-06-15 15:50:06 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:06 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:50:06 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:50:06 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:06 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:06 --> Total execution time: 0.0468
INFO - 2017-06-15 15:50:11 --> Config Class Initialized
INFO - 2017-06-15 15:50:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:11 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:11 --> URI Class Initialized
INFO - 2017-06-15 15:50:11 --> Router Class Initialized
INFO - 2017-06-15 15:50:11 --> Output Class Initialized
INFO - 2017-06-15 15:50:11 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:11 --> Input Class Initialized
INFO - 2017-06-15 15:50:11 --> Language Class Initialized
INFO - 2017-06-15 15:50:11 --> Loader Class Initialized
INFO - 2017-06-15 15:50:11 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:11 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:11 --> Email Class Initialized
INFO - 2017-06-15 15:50:11 --> Controller Class Initialized
INFO - 2017-06-15 15:50:11 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:11 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:11 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:11 --> Model Class Initialized
INFO - 2017-06-15 15:50:11 --> Model Class Initialized
INFO - 2017-06-15 15:50:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:50:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:50:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:11 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:11 --> Total execution time: 0.0467
INFO - 2017-06-15 15:50:35 --> Config Class Initialized
INFO - 2017-06-15 15:50:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:35 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:35 --> URI Class Initialized
INFO - 2017-06-15 15:50:35 --> Router Class Initialized
INFO - 2017-06-15 15:50:35 --> Output Class Initialized
INFO - 2017-06-15 15:50:35 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:35 --> Input Class Initialized
INFO - 2017-06-15 15:50:35 --> Language Class Initialized
INFO - 2017-06-15 15:50:35 --> Loader Class Initialized
INFO - 2017-06-15 15:50:35 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:35 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:35 --> Email Class Initialized
INFO - 2017-06-15 15:50:35 --> Controller Class Initialized
INFO - 2017-06-15 15:50:35 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:35 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:35 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:35 --> Model Class Initialized
INFO - 2017-06-15 15:50:35 --> Model Class Initialized
INFO - 2017-06-15 15:50:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:50:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:50:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:35 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:35 --> Total execution time: 0.0448
INFO - 2017-06-15 15:50:46 --> Config Class Initialized
INFO - 2017-06-15 15:50:46 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:46 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:46 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:46 --> URI Class Initialized
INFO - 2017-06-15 15:50:46 --> Router Class Initialized
INFO - 2017-06-15 15:50:46 --> Output Class Initialized
INFO - 2017-06-15 15:50:46 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:46 --> Input Class Initialized
INFO - 2017-06-15 15:50:46 --> Language Class Initialized
INFO - 2017-06-15 15:50:46 --> Loader Class Initialized
INFO - 2017-06-15 15:50:46 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:46 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:46 --> Email Class Initialized
INFO - 2017-06-15 15:50:46 --> Controller Class Initialized
INFO - 2017-06-15 15:50:46 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:46 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:46 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:46 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:46 --> Model Class Initialized
INFO - 2017-06-15 15:50:46 --> Model Class Initialized
INFO - 2017-06-15 15:50:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:50:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:50:46 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:46 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:46 --> Total execution time: 0.0477
INFO - 2017-06-15 15:50:53 --> Config Class Initialized
INFO - 2017-06-15 15:50:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:53 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:53 --> URI Class Initialized
INFO - 2017-06-15 15:50:53 --> Router Class Initialized
INFO - 2017-06-15 15:50:53 --> Output Class Initialized
INFO - 2017-06-15 15:50:53 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:53 --> Input Class Initialized
INFO - 2017-06-15 15:50:53 --> Language Class Initialized
INFO - 2017-06-15 15:50:53 --> Loader Class Initialized
INFO - 2017-06-15 15:50:53 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:53 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:53 --> Email Class Initialized
INFO - 2017-06-15 15:50:53 --> Controller Class Initialized
INFO - 2017-06-15 15:50:53 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:53 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:53 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:53 --> Model Class Initialized
INFO - 2017-06-15 15:50:53 --> Model Class Initialized
INFO - 2017-06-15 15:50:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:50:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:50:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:53 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:53 --> Total execution time: 0.0483
INFO - 2017-06-15 15:50:54 --> Config Class Initialized
INFO - 2017-06-15 15:50:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:54 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:54 --> URI Class Initialized
INFO - 2017-06-15 15:50:54 --> Router Class Initialized
INFO - 2017-06-15 15:50:54 --> Output Class Initialized
INFO - 2017-06-15 15:50:54 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:54 --> Input Class Initialized
INFO - 2017-06-15 15:50:54 --> Language Class Initialized
INFO - 2017-06-15 15:50:54 --> Loader Class Initialized
INFO - 2017-06-15 15:50:54 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:54 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:54 --> Email Class Initialized
INFO - 2017-06-15 15:50:54 --> Controller Class Initialized
INFO - 2017-06-15 15:50:54 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:54 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:54 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:54 --> Model Class Initialized
INFO - 2017-06-15 15:50:54 --> Model Class Initialized
INFO - 2017-06-15 15:50:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:50:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:50:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:54 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:54 --> Total execution time: 0.0436
INFO - 2017-06-15 15:50:56 --> Config Class Initialized
INFO - 2017-06-15 15:50:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:56 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:56 --> URI Class Initialized
INFO - 2017-06-15 15:50:56 --> Router Class Initialized
INFO - 2017-06-15 15:50:56 --> Output Class Initialized
INFO - 2017-06-15 15:50:56 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:56 --> Input Class Initialized
INFO - 2017-06-15 15:50:56 --> Language Class Initialized
INFO - 2017-06-15 15:50:56 --> Loader Class Initialized
INFO - 2017-06-15 15:50:56 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:56 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:56 --> Email Class Initialized
INFO - 2017-06-15 15:50:56 --> Controller Class Initialized
INFO - 2017-06-15 15:50:56 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:56 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:56 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:56 --> Model Class Initialized
INFO - 2017-06-15 15:50:56 --> Model Class Initialized
INFO - 2017-06-15 15:50:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:50:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:50:56 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:56 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:56 --> Total execution time: 0.0468
INFO - 2017-06-15 15:50:57 --> Config Class Initialized
INFO - 2017-06-15 15:50:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:50:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:50:57 --> Utf8 Class Initialized
INFO - 2017-06-15 15:50:57 --> URI Class Initialized
INFO - 2017-06-15 15:50:57 --> Router Class Initialized
INFO - 2017-06-15 15:50:57 --> Output Class Initialized
INFO - 2017-06-15 15:50:57 --> Security Class Initialized
DEBUG - 2017-06-15 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:50:57 --> Input Class Initialized
INFO - 2017-06-15 15:50:57 --> Language Class Initialized
INFO - 2017-06-15 15:50:57 --> Loader Class Initialized
INFO - 2017-06-15 15:50:57 --> Helper loaded: common_helper
INFO - 2017-06-15 15:50:57 --> Database Driver Class Initialized
INFO - 2017-06-15 15:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:50:57 --> Email Class Initialized
INFO - 2017-06-15 15:50:57 --> Controller Class Initialized
INFO - 2017-06-15 15:50:57 --> Helper loaded: form_helper
INFO - 2017-06-15 15:50:57 --> Form Validation Class Initialized
INFO - 2017-06-15 15:50:57 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:50:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:50:57 --> Helper loaded: url_helper
INFO - 2017-06-15 15:50:57 --> Model Class Initialized
INFO - 2017-06-15 15:50:57 --> Model Class Initialized
INFO - 2017-06-15 15:50:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:50:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:50:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:50:57 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:50:57 --> Final output sent to browser
DEBUG - 2017-06-15 15:50:57 --> Total execution time: 0.0463
INFO - 2017-06-15 15:51:49 --> Config Class Initialized
INFO - 2017-06-15 15:51:49 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:51:49 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:51:49 --> Utf8 Class Initialized
INFO - 2017-06-15 15:51:49 --> URI Class Initialized
INFO - 2017-06-15 15:51:49 --> Router Class Initialized
INFO - 2017-06-15 15:51:49 --> Output Class Initialized
INFO - 2017-06-15 15:51:49 --> Security Class Initialized
DEBUG - 2017-06-15 15:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:51:49 --> Input Class Initialized
INFO - 2017-06-15 15:51:49 --> Language Class Initialized
INFO - 2017-06-15 15:51:49 --> Loader Class Initialized
INFO - 2017-06-15 15:51:49 --> Helper loaded: common_helper
INFO - 2017-06-15 15:51:49 --> Database Driver Class Initialized
INFO - 2017-06-15 15:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:51:49 --> Email Class Initialized
INFO - 2017-06-15 15:51:49 --> Controller Class Initialized
INFO - 2017-06-15 15:51:49 --> Helper loaded: form_helper
INFO - 2017-06-15 15:51:49 --> Form Validation Class Initialized
INFO - 2017-06-15 15:51:49 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:51:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:51:49 --> Helper loaded: url_helper
INFO - 2017-06-15 15:51:49 --> Model Class Initialized
INFO - 2017-06-15 15:51:49 --> Model Class Initialized
INFO - 2017-06-15 15:51:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:51:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:51:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:51:49 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:51:49 --> Final output sent to browser
DEBUG - 2017-06-15 15:51:49 --> Total execution time: 0.0493
INFO - 2017-06-15 15:52:58 --> Config Class Initialized
INFO - 2017-06-15 15:52:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:52:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:52:58 --> Utf8 Class Initialized
INFO - 2017-06-15 15:52:58 --> URI Class Initialized
INFO - 2017-06-15 15:52:58 --> Router Class Initialized
INFO - 2017-06-15 15:52:58 --> Output Class Initialized
INFO - 2017-06-15 15:52:58 --> Security Class Initialized
DEBUG - 2017-06-15 15:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:52:58 --> Input Class Initialized
INFO - 2017-06-15 15:52:58 --> Language Class Initialized
INFO - 2017-06-15 15:52:58 --> Loader Class Initialized
INFO - 2017-06-15 15:52:58 --> Helper loaded: common_helper
INFO - 2017-06-15 15:52:58 --> Database Driver Class Initialized
INFO - 2017-06-15 15:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:52:58 --> Email Class Initialized
INFO - 2017-06-15 15:52:58 --> Controller Class Initialized
INFO - 2017-06-15 15:52:58 --> Helper loaded: form_helper
INFO - 2017-06-15 15:52:58 --> Form Validation Class Initialized
INFO - 2017-06-15 15:52:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:52:58 --> Helper loaded: url_helper
INFO - 2017-06-15 15:52:58 --> Model Class Initialized
INFO - 2017-06-15 15:52:58 --> Model Class Initialized
INFO - 2017-06-15 15:52:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:52:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:52:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:52:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:52:58 --> Final output sent to browser
DEBUG - 2017-06-15 15:52:58 --> Total execution time: 0.0480
INFO - 2017-06-15 15:54:27 --> Config Class Initialized
INFO - 2017-06-15 15:54:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:54:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:54:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:54:27 --> URI Class Initialized
INFO - 2017-06-15 15:54:27 --> Router Class Initialized
INFO - 2017-06-15 15:54:27 --> Output Class Initialized
INFO - 2017-06-15 15:54:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:54:27 --> Input Class Initialized
INFO - 2017-06-15 15:54:27 --> Language Class Initialized
INFO - 2017-06-15 15:54:27 --> Loader Class Initialized
INFO - 2017-06-15 15:54:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:54:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:54:27 --> Email Class Initialized
INFO - 2017-06-15 15:54:27 --> Controller Class Initialized
INFO - 2017-06-15 15:54:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:54:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:54:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:54:27 --> Model Class Initialized
INFO - 2017-06-15 15:54:27 --> Model Class Initialized
INFO - 2017-06-15 15:54:27 --> Config Class Initialized
INFO - 2017-06-15 15:54:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:54:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:54:27 --> Utf8 Class Initialized
INFO - 2017-06-15 15:54:27 --> URI Class Initialized
DEBUG - 2017-06-15 15:54:27 --> No URI present. Default controller set.
INFO - 2017-06-15 15:54:27 --> Router Class Initialized
INFO - 2017-06-15 15:54:27 --> Output Class Initialized
INFO - 2017-06-15 15:54:27 --> Security Class Initialized
DEBUG - 2017-06-15 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:54:27 --> Input Class Initialized
INFO - 2017-06-15 15:54:27 --> Language Class Initialized
INFO - 2017-06-15 15:54:27 --> Loader Class Initialized
INFO - 2017-06-15 15:54:27 --> Helper loaded: common_helper
INFO - 2017-06-15 15:54:27 --> Database Driver Class Initialized
INFO - 2017-06-15 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:54:27 --> Email Class Initialized
INFO - 2017-06-15 15:54:27 --> Controller Class Initialized
INFO - 2017-06-15 15:54:27 --> Helper loaded: form_helper
INFO - 2017-06-15 15:54:27 --> Form Validation Class Initialized
INFO - 2017-06-15 15:54:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:27 --> Helper loaded: url_helper
INFO - 2017-06-15 15:54:27 --> Model Class Initialized
INFO - 2017-06-15 15:54:27 --> Model Class Initialized
INFO - 2017-06-15 15:54:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 15:54:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:54:27 --> Final output sent to browser
DEBUG - 2017-06-15 15:54:27 --> Total execution time: 0.0499
INFO - 2017-06-15 15:54:30 --> Config Class Initialized
INFO - 2017-06-15 15:54:30 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:54:30 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:54:30 --> Utf8 Class Initialized
INFO - 2017-06-15 15:54:30 --> URI Class Initialized
DEBUG - 2017-06-15 15:54:30 --> No URI present. Default controller set.
INFO - 2017-06-15 15:54:30 --> Router Class Initialized
INFO - 2017-06-15 15:54:30 --> Output Class Initialized
INFO - 2017-06-15 15:54:30 --> Security Class Initialized
DEBUG - 2017-06-15 15:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:54:30 --> Input Class Initialized
INFO - 2017-06-15 15:54:30 --> Language Class Initialized
INFO - 2017-06-15 15:54:30 --> Loader Class Initialized
INFO - 2017-06-15 15:54:30 --> Helper loaded: common_helper
INFO - 2017-06-15 15:54:30 --> Database Driver Class Initialized
INFO - 2017-06-15 15:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:54:30 --> Email Class Initialized
INFO - 2017-06-15 15:54:30 --> Controller Class Initialized
INFO - 2017-06-15 15:54:30 --> Helper loaded: form_helper
INFO - 2017-06-15 15:54:30 --> Form Validation Class Initialized
INFO - 2017-06-15 15:54:30 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:30 --> Helper loaded: url_helper
INFO - 2017-06-15 15:54:30 --> Model Class Initialized
INFO - 2017-06-15 15:54:30 --> Model Class Initialized
DEBUG - 2017-06-15 15:54:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:54:30 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 15:54:30 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:54:30 --> Final output sent to browser
DEBUG - 2017-06-15 15:54:30 --> Total execution time: 0.0511
INFO - 2017-06-15 15:54:34 --> Config Class Initialized
INFO - 2017-06-15 15:54:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:54:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:54:34 --> Utf8 Class Initialized
INFO - 2017-06-15 15:54:34 --> URI Class Initialized
DEBUG - 2017-06-15 15:54:34 --> No URI present. Default controller set.
INFO - 2017-06-15 15:54:34 --> Router Class Initialized
INFO - 2017-06-15 15:54:34 --> Output Class Initialized
INFO - 2017-06-15 15:54:34 --> Security Class Initialized
DEBUG - 2017-06-15 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:54:34 --> Input Class Initialized
INFO - 2017-06-15 15:54:34 --> Language Class Initialized
INFO - 2017-06-15 15:54:34 --> Loader Class Initialized
INFO - 2017-06-15 15:54:34 --> Helper loaded: common_helper
INFO - 2017-06-15 15:54:34 --> Database Driver Class Initialized
INFO - 2017-06-15 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:54:34 --> Email Class Initialized
INFO - 2017-06-15 15:54:34 --> Controller Class Initialized
INFO - 2017-06-15 15:54:34 --> Helper loaded: form_helper
INFO - 2017-06-15 15:54:34 --> Form Validation Class Initialized
INFO - 2017-06-15 15:54:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:34 --> Helper loaded: url_helper
INFO - 2017-06-15 15:54:34 --> Model Class Initialized
INFO - 2017-06-15 15:54:34 --> Model Class Initialized
DEBUG - 2017-06-15 15:54:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:54:34 --> Config Class Initialized
INFO - 2017-06-15 15:54:34 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:54:34 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:54:34 --> Utf8 Class Initialized
INFO - 2017-06-15 15:54:34 --> URI Class Initialized
INFO - 2017-06-15 15:54:34 --> Router Class Initialized
INFO - 2017-06-15 15:54:34 --> Output Class Initialized
INFO - 2017-06-15 15:54:34 --> Security Class Initialized
DEBUG - 2017-06-15 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:54:34 --> Input Class Initialized
INFO - 2017-06-15 15:54:34 --> Language Class Initialized
INFO - 2017-06-15 15:54:34 --> Loader Class Initialized
INFO - 2017-06-15 15:54:34 --> Helper loaded: common_helper
INFO - 2017-06-15 15:54:34 --> Database Driver Class Initialized
INFO - 2017-06-15 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:54:34 --> Email Class Initialized
INFO - 2017-06-15 15:54:34 --> Controller Class Initialized
INFO - 2017-06-15 15:54:34 --> Helper loaded: form_helper
INFO - 2017-06-15 15:54:34 --> Form Validation Class Initialized
INFO - 2017-06-15 15:54:34 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:54:34 --> Helper loaded: url_helper
INFO - 2017-06-15 15:54:34 --> Model Class Initialized
INFO - 2017-06-15 15:54:34 --> Model Class Initialized
INFO - 2017-06-15 15:54:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:54:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:54:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:54:34 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:54:34 --> Final output sent to browser
DEBUG - 2017-06-15 15:54:34 --> Total execution time: 0.0556
INFO - 2017-06-15 15:56:40 --> Config Class Initialized
INFO - 2017-06-15 15:56:40 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:56:40 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:56:40 --> Utf8 Class Initialized
INFO - 2017-06-15 15:56:40 --> URI Class Initialized
INFO - 2017-06-15 15:56:40 --> Router Class Initialized
INFO - 2017-06-15 15:56:40 --> Output Class Initialized
INFO - 2017-06-15 15:56:40 --> Security Class Initialized
DEBUG - 2017-06-15 15:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:56:40 --> Input Class Initialized
INFO - 2017-06-15 15:56:40 --> Language Class Initialized
INFO - 2017-06-15 15:56:40 --> Loader Class Initialized
INFO - 2017-06-15 15:56:40 --> Helper loaded: common_helper
INFO - 2017-06-15 15:56:40 --> Database Driver Class Initialized
INFO - 2017-06-15 15:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:56:40 --> Email Class Initialized
INFO - 2017-06-15 15:56:40 --> Controller Class Initialized
INFO - 2017-06-15 15:56:40 --> Helper loaded: form_helper
INFO - 2017-06-15 15:56:40 --> Form Validation Class Initialized
INFO - 2017-06-15 15:56:40 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:56:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:40 --> Helper loaded: url_helper
INFO - 2017-06-15 15:56:40 --> Model Class Initialized
INFO - 2017-06-15 15:56:40 --> Model Class Initialized
INFO - 2017-06-15 15:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:56:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:56:40 --> Final output sent to browser
DEBUG - 2017-06-15 15:56:40 --> Total execution time: 0.0500
INFO - 2017-06-15 15:56:42 --> Config Class Initialized
INFO - 2017-06-15 15:56:42 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:56:42 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:56:42 --> Utf8 Class Initialized
INFO - 2017-06-15 15:56:42 --> URI Class Initialized
INFO - 2017-06-15 15:56:42 --> Router Class Initialized
INFO - 2017-06-15 15:56:42 --> Output Class Initialized
INFO - 2017-06-15 15:56:42 --> Security Class Initialized
DEBUG - 2017-06-15 15:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:56:42 --> Input Class Initialized
INFO - 2017-06-15 15:56:42 --> Language Class Initialized
INFO - 2017-06-15 15:56:42 --> Loader Class Initialized
INFO - 2017-06-15 15:56:42 --> Helper loaded: common_helper
INFO - 2017-06-15 15:56:42 --> Database Driver Class Initialized
INFO - 2017-06-15 15:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:56:42 --> Email Class Initialized
INFO - 2017-06-15 15:56:42 --> Controller Class Initialized
INFO - 2017-06-15 15:56:42 --> Helper loaded: form_helper
INFO - 2017-06-15 15:56:42 --> Form Validation Class Initialized
INFO - 2017-06-15 15:56:42 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:42 --> Helper loaded: url_helper
INFO - 2017-06-15 15:56:42 --> Model Class Initialized
INFO - 2017-06-15 15:56:42 --> Model Class Initialized
INFO - 2017-06-15 15:56:42 --> Config Class Initialized
INFO - 2017-06-15 15:56:42 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:56:42 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:56:42 --> Utf8 Class Initialized
INFO - 2017-06-15 15:56:42 --> URI Class Initialized
DEBUG - 2017-06-15 15:56:42 --> No URI present. Default controller set.
INFO - 2017-06-15 15:56:42 --> Router Class Initialized
INFO - 2017-06-15 15:56:42 --> Output Class Initialized
INFO - 2017-06-15 15:56:42 --> Security Class Initialized
DEBUG - 2017-06-15 15:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:56:42 --> Input Class Initialized
INFO - 2017-06-15 15:56:42 --> Language Class Initialized
INFO - 2017-06-15 15:56:42 --> Loader Class Initialized
INFO - 2017-06-15 15:56:42 --> Helper loaded: common_helper
INFO - 2017-06-15 15:56:42 --> Database Driver Class Initialized
INFO - 2017-06-15 15:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:56:42 --> Email Class Initialized
INFO - 2017-06-15 15:56:42 --> Controller Class Initialized
INFO - 2017-06-15 15:56:42 --> Helper loaded: form_helper
INFO - 2017-06-15 15:56:42 --> Form Validation Class Initialized
INFO - 2017-06-15 15:56:42 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:56:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:42 --> Helper loaded: url_helper
INFO - 2017-06-15 15:56:42 --> Model Class Initialized
INFO - 2017-06-15 15:56:42 --> Model Class Initialized
ERROR - 2017-06-15 15:56:42 --> Undefined variable: errorMessage
ERROR - 2017-06-15 15:56:42 --> Severity: Notice --> Undefined variable: errorMessage C:\xampp\htdocs\bloodApp\application\views\index.php 25
INFO - 2017-06-15 15:56:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 15:56:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:56:42 --> Final output sent to browser
DEBUG - 2017-06-15 15:56:42 --> Total execution time: 0.0468
INFO - 2017-06-15 15:56:53 --> Config Class Initialized
INFO - 2017-06-15 15:56:53 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:56:53 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:56:53 --> Utf8 Class Initialized
INFO - 2017-06-15 15:56:53 --> URI Class Initialized
DEBUG - 2017-06-15 15:56:53 --> No URI present. Default controller set.
INFO - 2017-06-15 15:56:53 --> Router Class Initialized
INFO - 2017-06-15 15:56:53 --> Output Class Initialized
INFO - 2017-06-15 15:56:53 --> Security Class Initialized
DEBUG - 2017-06-15 15:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:56:53 --> Input Class Initialized
INFO - 2017-06-15 15:56:53 --> Language Class Initialized
INFO - 2017-06-15 15:56:53 --> Loader Class Initialized
INFO - 2017-06-15 15:56:53 --> Helper loaded: common_helper
INFO - 2017-06-15 15:56:53 --> Database Driver Class Initialized
INFO - 2017-06-15 15:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:56:53 --> Email Class Initialized
INFO - 2017-06-15 15:56:53 --> Controller Class Initialized
INFO - 2017-06-15 15:56:53 --> Helper loaded: form_helper
INFO - 2017-06-15 15:56:53 --> Form Validation Class Initialized
INFO - 2017-06-15 15:56:53 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:56:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:53 --> Helper loaded: url_helper
INFO - 2017-06-15 15:56:53 --> Model Class Initialized
INFO - 2017-06-15 15:56:53 --> Model Class Initialized
INFO - 2017-06-15 15:56:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\index.php
INFO - 2017-06-15 15:56:53 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:56:53 --> Final output sent to browser
DEBUG - 2017-06-15 15:56:53 --> Total execution time: 0.0437
INFO - 2017-06-15 15:56:58 --> Config Class Initialized
INFO - 2017-06-15 15:56:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:56:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:56:58 --> Utf8 Class Initialized
INFO - 2017-06-15 15:56:58 --> URI Class Initialized
DEBUG - 2017-06-15 15:56:58 --> No URI present. Default controller set.
INFO - 2017-06-15 15:56:58 --> Router Class Initialized
INFO - 2017-06-15 15:56:58 --> Output Class Initialized
INFO - 2017-06-15 15:56:58 --> Security Class Initialized
DEBUG - 2017-06-15 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:56:58 --> Input Class Initialized
INFO - 2017-06-15 15:56:58 --> Language Class Initialized
INFO - 2017-06-15 15:56:58 --> Loader Class Initialized
INFO - 2017-06-15 15:56:58 --> Helper loaded: common_helper
INFO - 2017-06-15 15:56:58 --> Database Driver Class Initialized
INFO - 2017-06-15 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:56:58 --> Email Class Initialized
INFO - 2017-06-15 15:56:58 --> Controller Class Initialized
INFO - 2017-06-15 15:56:58 --> Helper loaded: form_helper
INFO - 2017-06-15 15:56:58 --> Form Validation Class Initialized
INFO - 2017-06-15 15:56:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:58 --> Helper loaded: url_helper
INFO - 2017-06-15 15:56:58 --> Model Class Initialized
INFO - 2017-06-15 15:56:58 --> Model Class Initialized
DEBUG - 2017-06-15 15:56:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-06-15 15:56:58 --> Config Class Initialized
INFO - 2017-06-15 15:56:58 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:56:58 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:56:58 --> Utf8 Class Initialized
INFO - 2017-06-15 15:56:58 --> URI Class Initialized
INFO - 2017-06-15 15:56:58 --> Router Class Initialized
INFO - 2017-06-15 15:56:58 --> Output Class Initialized
INFO - 2017-06-15 15:56:58 --> Security Class Initialized
DEBUG - 2017-06-15 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:56:58 --> Input Class Initialized
INFO - 2017-06-15 15:56:58 --> Language Class Initialized
INFO - 2017-06-15 15:56:58 --> Loader Class Initialized
INFO - 2017-06-15 15:56:58 --> Helper loaded: common_helper
INFO - 2017-06-15 15:56:58 --> Database Driver Class Initialized
INFO - 2017-06-15 15:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:56:58 --> Email Class Initialized
INFO - 2017-06-15 15:56:58 --> Controller Class Initialized
INFO - 2017-06-15 15:56:58 --> Helper loaded: form_helper
INFO - 2017-06-15 15:56:58 --> Form Validation Class Initialized
INFO - 2017-06-15 15:56:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:56:58 --> Helper loaded: url_helper
INFO - 2017-06-15 15:56:58 --> Model Class Initialized
INFO - 2017-06-15 15:56:58 --> Model Class Initialized
INFO - 2017-06-15 15:56:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:56:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:56:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:56:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:56:58 --> Final output sent to browser
DEBUG - 2017-06-15 15:56:58 --> Total execution time: 0.0662
INFO - 2017-06-15 15:57:18 --> Config Class Initialized
INFO - 2017-06-15 15:57:18 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:57:18 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:57:18 --> Utf8 Class Initialized
INFO - 2017-06-15 15:57:18 --> URI Class Initialized
INFO - 2017-06-15 15:57:18 --> Router Class Initialized
INFO - 2017-06-15 15:57:18 --> Output Class Initialized
INFO - 2017-06-15 15:57:18 --> Security Class Initialized
DEBUG - 2017-06-15 15:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:57:18 --> Input Class Initialized
INFO - 2017-06-15 15:57:18 --> Language Class Initialized
INFO - 2017-06-15 15:57:18 --> Loader Class Initialized
INFO - 2017-06-15 15:57:18 --> Helper loaded: common_helper
INFO - 2017-06-15 15:57:18 --> Database Driver Class Initialized
INFO - 2017-06-15 15:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:57:18 --> Email Class Initialized
INFO - 2017-06-15 15:57:18 --> Controller Class Initialized
INFO - 2017-06-15 15:57:18 --> Helper loaded: form_helper
INFO - 2017-06-15 15:57:18 --> Form Validation Class Initialized
INFO - 2017-06-15 15:57:18 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:57:18 --> Helper loaded: url_helper
INFO - 2017-06-15 15:57:18 --> Model Class Initialized
INFO - 2017-06-15 15:57:18 --> Model Class Initialized
INFO - 2017-06-15 15:57:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:57:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:57:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:57:18 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:57:18 --> Final output sent to browser
DEBUG - 2017-06-15 15:57:18 --> Total execution time: 0.0497
INFO - 2017-06-15 15:59:13 --> Config Class Initialized
INFO - 2017-06-15 15:59:13 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:59:13 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:59:13 --> Utf8 Class Initialized
INFO - 2017-06-15 15:59:13 --> URI Class Initialized
INFO - 2017-06-15 15:59:13 --> Router Class Initialized
INFO - 2017-06-15 15:59:13 --> Output Class Initialized
INFO - 2017-06-15 15:59:13 --> Security Class Initialized
DEBUG - 2017-06-15 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:59:13 --> Input Class Initialized
INFO - 2017-06-15 15:59:13 --> Language Class Initialized
INFO - 2017-06-15 15:59:13 --> Loader Class Initialized
INFO - 2017-06-15 15:59:13 --> Helper loaded: common_helper
INFO - 2017-06-15 15:59:13 --> Database Driver Class Initialized
INFO - 2017-06-15 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:59:13 --> Email Class Initialized
INFO - 2017-06-15 15:59:13 --> Controller Class Initialized
INFO - 2017-06-15 15:59:13 --> Helper loaded: form_helper
INFO - 2017-06-15 15:59:13 --> Form Validation Class Initialized
INFO - 2017-06-15 15:59:13 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:59:13 --> Helper loaded: url_helper
INFO - 2017-06-15 15:59:13 --> Model Class Initialized
INFO - 2017-06-15 15:59:13 --> Model Class Initialized
INFO - 2017-06-15 15:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 15:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 15:59:13 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:59:13 --> Final output sent to browser
DEBUG - 2017-06-15 15:59:13 --> Total execution time: 0.0517
INFO - 2017-06-15 15:59:17 --> Config Class Initialized
INFO - 2017-06-15 15:59:17 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:59:17 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:59:17 --> Utf8 Class Initialized
INFO - 2017-06-15 15:59:17 --> URI Class Initialized
INFO - 2017-06-15 15:59:17 --> Router Class Initialized
INFO - 2017-06-15 15:59:17 --> Output Class Initialized
INFO - 2017-06-15 15:59:17 --> Security Class Initialized
DEBUG - 2017-06-15 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:59:17 --> Input Class Initialized
INFO - 2017-06-15 15:59:17 --> Language Class Initialized
INFO - 2017-06-15 15:59:17 --> Loader Class Initialized
INFO - 2017-06-15 15:59:17 --> Helper loaded: common_helper
INFO - 2017-06-15 15:59:17 --> Database Driver Class Initialized
INFO - 2017-06-15 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:59:17 --> Email Class Initialized
INFO - 2017-06-15 15:59:17 --> Controller Class Initialized
INFO - 2017-06-15 15:59:17 --> Helper loaded: form_helper
INFO - 2017-06-15 15:59:17 --> Form Validation Class Initialized
INFO - 2017-06-15 15:59:17 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:59:17 --> Helper loaded: url_helper
INFO - 2017-06-15 15:59:17 --> Model Class Initialized
INFO - 2017-06-15 15:59:17 --> Model Class Initialized
INFO - 2017-06-15 15:59:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:59:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:59:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\changePassword.php
INFO - 2017-06-15 15:59:17 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:59:17 --> Final output sent to browser
DEBUG - 2017-06-15 15:59:17 --> Total execution time: 0.0439
INFO - 2017-06-15 15:59:20 --> Config Class Initialized
INFO - 2017-06-15 15:59:20 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:59:20 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:59:20 --> Utf8 Class Initialized
INFO - 2017-06-15 15:59:20 --> URI Class Initialized
INFO - 2017-06-15 15:59:20 --> Router Class Initialized
INFO - 2017-06-15 15:59:20 --> Output Class Initialized
INFO - 2017-06-15 15:59:20 --> Security Class Initialized
DEBUG - 2017-06-15 15:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:59:20 --> Input Class Initialized
INFO - 2017-06-15 15:59:20 --> Language Class Initialized
INFO - 2017-06-15 15:59:20 --> Loader Class Initialized
INFO - 2017-06-15 15:59:20 --> Helper loaded: common_helper
INFO - 2017-06-15 15:59:20 --> Database Driver Class Initialized
INFO - 2017-06-15 15:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:59:20 --> Email Class Initialized
INFO - 2017-06-15 15:59:20 --> Controller Class Initialized
INFO - 2017-06-15 15:59:20 --> Helper loaded: form_helper
INFO - 2017-06-15 15:59:20 --> Form Validation Class Initialized
INFO - 2017-06-15 15:59:20 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:59:20 --> Helper loaded: url_helper
INFO - 2017-06-15 15:59:20 --> Model Class Initialized
INFO - 2017-06-15 15:59:20 --> Model Class Initialized
INFO - 2017-06-15 15:59:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 15:59:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sideMenu.php
INFO - 2017-06-15 15:59:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\profile.php
INFO - 2017-06-15 15:59:20 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 15:59:20 --> Final output sent to browser
DEBUG - 2017-06-15 15:59:20 --> Total execution time: 0.0465
INFO - 2017-06-15 15:59:23 --> Config Class Initialized
INFO - 2017-06-15 15:59:23 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:59:23 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:59:23 --> Utf8 Class Initialized
INFO - 2017-06-15 15:59:23 --> URI Class Initialized
INFO - 2017-06-15 15:59:23 --> Router Class Initialized
INFO - 2017-06-15 15:59:23 --> Output Class Initialized
INFO - 2017-06-15 15:59:23 --> Security Class Initialized
DEBUG - 2017-06-15 15:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:59:23 --> Input Class Initialized
INFO - 2017-06-15 15:59:23 --> Language Class Initialized
INFO - 2017-06-15 15:59:23 --> Loader Class Initialized
INFO - 2017-06-15 15:59:23 --> Helper loaded: common_helper
INFO - 2017-06-15 15:59:23 --> Database Driver Class Initialized
INFO - 2017-06-15 15:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:59:23 --> Email Class Initialized
INFO - 2017-06-15 15:59:23 --> Controller Class Initialized
INFO - 2017-06-15 15:59:23 --> Helper loaded: form_helper
INFO - 2017-06-15 15:59:23 --> Form Validation Class Initialized
INFO - 2017-06-15 15:59:23 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:59:23 --> Helper loaded: url_helper
INFO - 2017-06-15 15:59:23 --> Model Class Initialized
INFO - 2017-06-15 15:59:23 --> Model Class Initialized
INFO - 2017-06-15 19:29:23 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:29:23 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:29:23 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:29:23 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:29:23 --> Final output sent to browser
DEBUG - 2017-06-15 19:29:23 --> Total execution time: 0.0498
INFO - 2017-06-15 15:59:52 --> Config Class Initialized
INFO - 2017-06-15 15:59:52 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:59:52 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:59:52 --> Utf8 Class Initialized
INFO - 2017-06-15 15:59:52 --> URI Class Initialized
INFO - 2017-06-15 15:59:52 --> Router Class Initialized
INFO - 2017-06-15 15:59:52 --> Output Class Initialized
INFO - 2017-06-15 15:59:52 --> Security Class Initialized
DEBUG - 2017-06-15 15:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:59:52 --> Input Class Initialized
INFO - 2017-06-15 15:59:52 --> Language Class Initialized
INFO - 2017-06-15 15:59:52 --> Loader Class Initialized
INFO - 2017-06-15 15:59:52 --> Helper loaded: common_helper
INFO - 2017-06-15 15:59:52 --> Database Driver Class Initialized
INFO - 2017-06-15 15:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:59:52 --> Email Class Initialized
INFO - 2017-06-15 15:59:52 --> Controller Class Initialized
INFO - 2017-06-15 15:59:52 --> Helper loaded: form_helper
INFO - 2017-06-15 15:59:52 --> Form Validation Class Initialized
INFO - 2017-06-15 15:59:52 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:59:52 --> Helper loaded: url_helper
INFO - 2017-06-15 15:59:52 --> Model Class Initialized
INFO - 2017-06-15 15:59:52 --> Model Class Initialized
INFO - 2017-06-15 19:29:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:29:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:29:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:29:52 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:29:52 --> Final output sent to browser
DEBUG - 2017-06-15 19:29:52 --> Total execution time: 0.0493
INFO - 2017-06-15 15:59:59 --> Config Class Initialized
INFO - 2017-06-15 15:59:59 --> Hooks Class Initialized
DEBUG - 2017-06-15 15:59:59 --> UTF-8 Support Enabled
INFO - 2017-06-15 15:59:59 --> Utf8 Class Initialized
INFO - 2017-06-15 15:59:59 --> URI Class Initialized
INFO - 2017-06-15 15:59:59 --> Router Class Initialized
INFO - 2017-06-15 15:59:59 --> Output Class Initialized
INFO - 2017-06-15 15:59:59 --> Security Class Initialized
DEBUG - 2017-06-15 15:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 15:59:59 --> Input Class Initialized
INFO - 2017-06-15 15:59:59 --> Language Class Initialized
INFO - 2017-06-15 15:59:59 --> Loader Class Initialized
INFO - 2017-06-15 15:59:59 --> Helper loaded: common_helper
INFO - 2017-06-15 15:59:59 --> Database Driver Class Initialized
INFO - 2017-06-15 15:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 15:59:59 --> Email Class Initialized
INFO - 2017-06-15 15:59:59 --> Controller Class Initialized
INFO - 2017-06-15 15:59:59 --> Helper loaded: form_helper
INFO - 2017-06-15 15:59:59 --> Form Validation Class Initialized
INFO - 2017-06-15 15:59:59 --> Helper loaded: email_helper
DEBUG - 2017-06-15 15:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 15:59:59 --> Helper loaded: url_helper
INFO - 2017-06-15 15:59:59 --> Model Class Initialized
INFO - 2017-06-15 15:59:59 --> Model Class Initialized
INFO - 2017-06-15 19:29:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:29:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:29:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:29:59 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:29:59 --> Final output sent to browser
DEBUG - 2017-06-15 19:29:59 --> Total execution time: 0.0509
INFO - 2017-06-15 16:05:33 --> Config Class Initialized
INFO - 2017-06-15 16:05:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:33 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:33 --> URI Class Initialized
INFO - 2017-06-15 16:05:33 --> Router Class Initialized
INFO - 2017-06-15 16:05:33 --> Output Class Initialized
INFO - 2017-06-15 16:05:33 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:33 --> Input Class Initialized
INFO - 2017-06-15 16:05:33 --> Language Class Initialized
INFO - 2017-06-15 16:05:33 --> Loader Class Initialized
INFO - 2017-06-15 16:05:33 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:33 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:33 --> Email Class Initialized
INFO - 2017-06-15 16:05:33 --> Controller Class Initialized
INFO - 2017-06-15 16:05:33 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:33 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:33 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:33 --> Model Class Initialized
INFO - 2017-06-15 16:05:33 --> Model Class Initialized
INFO - 2017-06-15 19:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:35:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:35:33 --> Final output sent to browser
DEBUG - 2017-06-15 19:35:33 --> Total execution time: 0.0463
INFO - 2017-06-15 16:05:35 --> Config Class Initialized
INFO - 2017-06-15 16:05:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:35 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:35 --> URI Class Initialized
INFO - 2017-06-15 16:05:35 --> Router Class Initialized
INFO - 2017-06-15 16:05:35 --> Output Class Initialized
INFO - 2017-06-15 16:05:35 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:35 --> Input Class Initialized
INFO - 2017-06-15 16:05:35 --> Language Class Initialized
INFO - 2017-06-15 16:05:35 --> Loader Class Initialized
INFO - 2017-06-15 16:05:35 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:35 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:35 --> Email Class Initialized
INFO - 2017-06-15 16:05:35 --> Controller Class Initialized
INFO - 2017-06-15 16:05:35 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:35 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:35 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:35 --> Model Class Initialized
INFO - 2017-06-15 16:05:35 --> Model Class Initialized
INFO - 2017-06-15 16:05:36 --> Config Class Initialized
INFO - 2017-06-15 16:05:36 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:36 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:36 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:36 --> URI Class Initialized
INFO - 2017-06-15 16:05:36 --> Router Class Initialized
INFO - 2017-06-15 16:05:36 --> Output Class Initialized
INFO - 2017-06-15 16:05:36 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:36 --> Input Class Initialized
INFO - 2017-06-15 16:05:36 --> Language Class Initialized
INFO - 2017-06-15 16:05:36 --> Loader Class Initialized
INFO - 2017-06-15 16:05:36 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:36 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:36 --> Email Class Initialized
INFO - 2017-06-15 16:05:36 --> Controller Class Initialized
INFO - 2017-06-15 16:05:36 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:36 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:36 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:36 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:36 --> Model Class Initialized
INFO - 2017-06-15 16:05:36 --> Model Class Initialized
INFO - 2017-06-15 19:35:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:35:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:35:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:35:36 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:35:36 --> Final output sent to browser
DEBUG - 2017-06-15 19:35:36 --> Total execution time: 0.0539
INFO - 2017-06-15 16:05:37 --> Config Class Initialized
INFO - 2017-06-15 16:05:37 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:37 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:37 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:37 --> URI Class Initialized
INFO - 2017-06-15 16:05:37 --> Router Class Initialized
INFO - 2017-06-15 16:05:37 --> Output Class Initialized
INFO - 2017-06-15 16:05:37 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:37 --> Input Class Initialized
INFO - 2017-06-15 16:05:37 --> Language Class Initialized
INFO - 2017-06-15 16:05:37 --> Loader Class Initialized
INFO - 2017-06-15 16:05:37 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:37 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:37 --> Email Class Initialized
INFO - 2017-06-15 16:05:37 --> Controller Class Initialized
INFO - 2017-06-15 16:05:37 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:37 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:37 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:37 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:37 --> Model Class Initialized
INFO - 2017-06-15 16:05:37 --> Model Class Initialized
INFO - 2017-06-15 16:05:38 --> Config Class Initialized
INFO - 2017-06-15 16:05:38 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:38 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:38 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:38 --> URI Class Initialized
INFO - 2017-06-15 16:05:38 --> Router Class Initialized
INFO - 2017-06-15 16:05:38 --> Output Class Initialized
INFO - 2017-06-15 16:05:38 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:38 --> Input Class Initialized
INFO - 2017-06-15 16:05:38 --> Language Class Initialized
INFO - 2017-06-15 16:05:38 --> Loader Class Initialized
INFO - 2017-06-15 16:05:38 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:38 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:38 --> Email Class Initialized
INFO - 2017-06-15 16:05:38 --> Controller Class Initialized
INFO - 2017-06-15 16:05:38 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:38 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:38 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:38 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:38 --> Model Class Initialized
INFO - 2017-06-15 16:05:38 --> Model Class Initialized
INFO - 2017-06-15 19:35:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:35:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:35:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:35:38 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:35:38 --> Final output sent to browser
DEBUG - 2017-06-15 19:35:38 --> Total execution time: 0.0487
INFO - 2017-06-15 16:05:39 --> Config Class Initialized
INFO - 2017-06-15 16:05:39 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:39 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:39 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:39 --> URI Class Initialized
INFO - 2017-06-15 16:05:39 --> Router Class Initialized
INFO - 2017-06-15 16:05:39 --> Output Class Initialized
INFO - 2017-06-15 16:05:39 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:39 --> Input Class Initialized
INFO - 2017-06-15 16:05:39 --> Language Class Initialized
INFO - 2017-06-15 16:05:39 --> Loader Class Initialized
INFO - 2017-06-15 16:05:39 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:39 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:39 --> Email Class Initialized
INFO - 2017-06-15 16:05:39 --> Controller Class Initialized
INFO - 2017-06-15 16:05:39 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:39 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:39 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:39 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:39 --> Model Class Initialized
INFO - 2017-06-15 16:05:39 --> Model Class Initialized
INFO - 2017-06-15 16:05:40 --> Config Class Initialized
INFO - 2017-06-15 16:05:40 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:05:40 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:05:40 --> Utf8 Class Initialized
INFO - 2017-06-15 16:05:40 --> URI Class Initialized
INFO - 2017-06-15 16:05:40 --> Router Class Initialized
INFO - 2017-06-15 16:05:40 --> Output Class Initialized
INFO - 2017-06-15 16:05:40 --> Security Class Initialized
DEBUG - 2017-06-15 16:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:05:40 --> Input Class Initialized
INFO - 2017-06-15 16:05:40 --> Language Class Initialized
INFO - 2017-06-15 16:05:40 --> Loader Class Initialized
INFO - 2017-06-15 16:05:40 --> Helper loaded: common_helper
INFO - 2017-06-15 16:05:40 --> Database Driver Class Initialized
INFO - 2017-06-15 16:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:05:40 --> Email Class Initialized
INFO - 2017-06-15 16:05:40 --> Controller Class Initialized
INFO - 2017-06-15 16:05:40 --> Helper loaded: form_helper
INFO - 2017-06-15 16:05:40 --> Form Validation Class Initialized
INFO - 2017-06-15 16:05:40 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:05:40 --> Helper loaded: url_helper
INFO - 2017-06-15 16:05:40 --> Model Class Initialized
INFO - 2017-06-15 16:05:40 --> Model Class Initialized
INFO - 2017-06-15 19:35:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:35:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:35:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:35:40 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:35:40 --> Final output sent to browser
DEBUG - 2017-06-15 19:35:40 --> Total execution time: 0.0495
INFO - 2017-06-15 16:06:42 --> Config Class Initialized
INFO - 2017-06-15 16:06:42 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:06:42 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:06:42 --> Utf8 Class Initialized
INFO - 2017-06-15 16:06:42 --> URI Class Initialized
INFO - 2017-06-15 16:06:42 --> Router Class Initialized
INFO - 2017-06-15 16:06:42 --> Output Class Initialized
INFO - 2017-06-15 16:06:42 --> Security Class Initialized
DEBUG - 2017-06-15 16:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:06:42 --> Input Class Initialized
INFO - 2017-06-15 16:06:42 --> Language Class Initialized
INFO - 2017-06-15 16:06:42 --> Loader Class Initialized
INFO - 2017-06-15 16:06:42 --> Helper loaded: common_helper
INFO - 2017-06-15 16:06:42 --> Database Driver Class Initialized
INFO - 2017-06-15 16:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:06:42 --> Email Class Initialized
INFO - 2017-06-15 16:06:42 --> Controller Class Initialized
INFO - 2017-06-15 16:06:42 --> Helper loaded: form_helper
INFO - 2017-06-15 16:06:42 --> Form Validation Class Initialized
INFO - 2017-06-15 16:06:42 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:06:42 --> Helper loaded: url_helper
INFO - 2017-06-15 16:06:42 --> Model Class Initialized
INFO - 2017-06-15 16:06:42 --> Model Class Initialized
INFO - 2017-06-15 19:36:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:36:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:36:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:36:42 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:36:42 --> Final output sent to browser
DEBUG - 2017-06-15 19:36:42 --> Total execution time: 0.0465
INFO - 2017-06-15 16:08:11 --> Config Class Initialized
INFO - 2017-06-15 16:08:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:08:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:08:11 --> Utf8 Class Initialized
INFO - 2017-06-15 16:08:11 --> URI Class Initialized
INFO - 2017-06-15 16:08:11 --> Router Class Initialized
INFO - 2017-06-15 16:08:11 --> Output Class Initialized
INFO - 2017-06-15 16:08:11 --> Security Class Initialized
DEBUG - 2017-06-15 16:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:08:11 --> Input Class Initialized
INFO - 2017-06-15 16:08:11 --> Language Class Initialized
INFO - 2017-06-15 16:08:11 --> Loader Class Initialized
INFO - 2017-06-15 16:08:11 --> Helper loaded: common_helper
INFO - 2017-06-15 16:08:11 --> Database Driver Class Initialized
INFO - 2017-06-15 16:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:08:11 --> Email Class Initialized
INFO - 2017-06-15 16:08:11 --> Controller Class Initialized
INFO - 2017-06-15 16:08:11 --> Helper loaded: form_helper
INFO - 2017-06-15 16:08:11 --> Form Validation Class Initialized
INFO - 2017-06-15 16:08:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:08:11 --> Helper loaded: url_helper
INFO - 2017-06-15 16:08:11 --> Model Class Initialized
INFO - 2017-06-15 16:08:11 --> Model Class Initialized
INFO - 2017-06-15 16:08:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 16:08:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 16:08:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 16:08:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 16:08:11 --> Final output sent to browser
DEBUG - 2017-06-15 16:08:11 --> Total execution time: 0.0447
INFO - 2017-06-15 16:09:29 --> Config Class Initialized
INFO - 2017-06-15 16:09:29 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:29 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:29 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:29 --> URI Class Initialized
INFO - 2017-06-15 16:09:29 --> Router Class Initialized
INFO - 2017-06-15 16:09:29 --> Output Class Initialized
INFO - 2017-06-15 16:09:29 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:29 --> Input Class Initialized
INFO - 2017-06-15 16:09:29 --> Language Class Initialized
INFO - 2017-06-15 16:09:29 --> Loader Class Initialized
INFO - 2017-06-15 16:09:29 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:29 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:29 --> Email Class Initialized
INFO - 2017-06-15 16:09:29 --> Controller Class Initialized
INFO - 2017-06-15 16:09:29 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:29 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:29 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:29 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:29 --> Model Class Initialized
INFO - 2017-06-15 16:09:29 --> Model Class Initialized
INFO - 2017-06-15 19:39:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:39:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:39:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:39:29 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:39:29 --> Final output sent to browser
DEBUG - 2017-06-15 19:39:29 --> Total execution time: 0.0481
INFO - 2017-06-15 16:09:32 --> Config Class Initialized
INFO - 2017-06-15 16:09:32 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:32 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:32 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:32 --> URI Class Initialized
INFO - 2017-06-15 16:09:32 --> Router Class Initialized
INFO - 2017-06-15 16:09:32 --> Output Class Initialized
INFO - 2017-06-15 16:09:32 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:32 --> Input Class Initialized
INFO - 2017-06-15 16:09:32 --> Language Class Initialized
INFO - 2017-06-15 16:09:32 --> Loader Class Initialized
INFO - 2017-06-15 16:09:32 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:32 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:32 --> Email Class Initialized
INFO - 2017-06-15 16:09:32 --> Controller Class Initialized
INFO - 2017-06-15 16:09:32 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:32 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:32 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:32 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:32 --> Model Class Initialized
INFO - 2017-06-15 16:09:32 --> Model Class Initialized
INFO - 2017-06-15 19:39:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:39:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:39:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:39:32 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:39:32 --> Final output sent to browser
DEBUG - 2017-06-15 19:39:32 --> Total execution time: 0.0481
INFO - 2017-06-15 16:09:33 --> Config Class Initialized
INFO - 2017-06-15 16:09:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:33 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:33 --> URI Class Initialized
INFO - 2017-06-15 16:09:33 --> Router Class Initialized
INFO - 2017-06-15 16:09:33 --> Output Class Initialized
INFO - 2017-06-15 16:09:33 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:33 --> Input Class Initialized
INFO - 2017-06-15 16:09:33 --> Language Class Initialized
INFO - 2017-06-15 16:09:33 --> Loader Class Initialized
INFO - 2017-06-15 16:09:33 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:33 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:33 --> Email Class Initialized
INFO - 2017-06-15 16:09:33 --> Controller Class Initialized
INFO - 2017-06-15 16:09:33 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:33 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:33 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:33 --> Model Class Initialized
INFO - 2017-06-15 16:09:33 --> Model Class Initialized
INFO - 2017-06-15 16:09:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 16:09:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 16:09:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\dashboard.php
INFO - 2017-06-15 16:09:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 16:09:33 --> Final output sent to browser
DEBUG - 2017-06-15 16:09:33 --> Total execution time: 0.0475
INFO - 2017-06-15 16:09:35 --> Config Class Initialized
INFO - 2017-06-15 16:09:35 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:35 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:35 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:35 --> URI Class Initialized
INFO - 2017-06-15 16:09:35 --> Router Class Initialized
INFO - 2017-06-15 16:09:35 --> Output Class Initialized
INFO - 2017-06-15 16:09:35 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:35 --> Input Class Initialized
INFO - 2017-06-15 16:09:35 --> Language Class Initialized
INFO - 2017-06-15 16:09:35 --> Loader Class Initialized
INFO - 2017-06-15 16:09:35 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:35 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:35 --> Email Class Initialized
INFO - 2017-06-15 16:09:35 --> Controller Class Initialized
INFO - 2017-06-15 16:09:35 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:35 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:35 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:35 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:35 --> Model Class Initialized
INFO - 2017-06-15 16:09:35 --> Model Class Initialized
INFO - 2017-06-15 19:39:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:39:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:39:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:39:35 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:39:35 --> Final output sent to browser
DEBUG - 2017-06-15 19:39:35 --> Total execution time: 0.0484
INFO - 2017-06-15 16:09:55 --> Config Class Initialized
INFO - 2017-06-15 16:09:55 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:55 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:55 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:55 --> URI Class Initialized
INFO - 2017-06-15 16:09:55 --> Router Class Initialized
INFO - 2017-06-15 16:09:55 --> Output Class Initialized
INFO - 2017-06-15 16:09:55 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:55 --> Input Class Initialized
INFO - 2017-06-15 16:09:55 --> Language Class Initialized
INFO - 2017-06-15 16:09:55 --> Loader Class Initialized
INFO - 2017-06-15 16:09:55 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:55 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:55 --> Email Class Initialized
INFO - 2017-06-15 16:09:55 --> Controller Class Initialized
INFO - 2017-06-15 16:09:55 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:55 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:55 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:55 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:55 --> Model Class Initialized
INFO - 2017-06-15 16:09:55 --> Model Class Initialized
INFO - 2017-06-15 19:39:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:39:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:39:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:39:55 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:39:55 --> Final output sent to browser
DEBUG - 2017-06-15 19:39:55 --> Total execution time: 0.0499
INFO - 2017-06-15 16:09:56 --> Config Class Initialized
INFO - 2017-06-15 16:09:56 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:56 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:56 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:56 --> URI Class Initialized
INFO - 2017-06-15 16:09:56 --> Router Class Initialized
INFO - 2017-06-15 16:09:56 --> Output Class Initialized
INFO - 2017-06-15 16:09:56 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:56 --> Input Class Initialized
INFO - 2017-06-15 16:09:56 --> Language Class Initialized
INFO - 2017-06-15 16:09:56 --> Loader Class Initialized
INFO - 2017-06-15 16:09:56 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:56 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:56 --> Email Class Initialized
INFO - 2017-06-15 16:09:56 --> Controller Class Initialized
INFO - 2017-06-15 16:09:56 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:56 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:56 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:56 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:56 --> Model Class Initialized
INFO - 2017-06-15 16:09:56 --> Model Class Initialized
INFO - 2017-06-15 16:09:57 --> Config Class Initialized
INFO - 2017-06-15 16:09:57 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:09:57 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:09:57 --> Utf8 Class Initialized
INFO - 2017-06-15 16:09:57 --> URI Class Initialized
INFO - 2017-06-15 16:09:57 --> Router Class Initialized
INFO - 2017-06-15 16:09:57 --> Output Class Initialized
INFO - 2017-06-15 16:09:57 --> Security Class Initialized
DEBUG - 2017-06-15 16:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:09:57 --> Input Class Initialized
INFO - 2017-06-15 16:09:57 --> Language Class Initialized
INFO - 2017-06-15 16:09:57 --> Loader Class Initialized
INFO - 2017-06-15 16:09:57 --> Helper loaded: common_helper
INFO - 2017-06-15 16:09:57 --> Database Driver Class Initialized
INFO - 2017-06-15 16:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:09:58 --> Email Class Initialized
INFO - 2017-06-15 16:09:58 --> Controller Class Initialized
INFO - 2017-06-15 16:09:58 --> Helper loaded: form_helper
INFO - 2017-06-15 16:09:58 --> Form Validation Class Initialized
INFO - 2017-06-15 16:09:58 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:09:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:09:58 --> Helper loaded: url_helper
INFO - 2017-06-15 16:09:58 --> Model Class Initialized
INFO - 2017-06-15 16:09:58 --> Model Class Initialized
INFO - 2017-06-15 19:39:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:39:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:39:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:39:58 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:39:58 --> Final output sent to browser
DEBUG - 2017-06-15 19:39:58 --> Total execution time: 0.0518
INFO - 2017-06-15 16:12:27 --> Config Class Initialized
INFO - 2017-06-15 16:12:27 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:12:27 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:12:27 --> Utf8 Class Initialized
INFO - 2017-06-15 16:12:27 --> URI Class Initialized
INFO - 2017-06-15 16:12:27 --> Router Class Initialized
INFO - 2017-06-15 16:12:27 --> Output Class Initialized
INFO - 2017-06-15 16:12:27 --> Security Class Initialized
DEBUG - 2017-06-15 16:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:12:27 --> Input Class Initialized
INFO - 2017-06-15 16:12:27 --> Language Class Initialized
INFO - 2017-06-15 16:12:27 --> Loader Class Initialized
INFO - 2017-06-15 16:12:27 --> Helper loaded: common_helper
INFO - 2017-06-15 16:12:27 --> Database Driver Class Initialized
INFO - 2017-06-15 16:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:12:27 --> Email Class Initialized
INFO - 2017-06-15 16:12:27 --> Controller Class Initialized
INFO - 2017-06-15 16:12:27 --> Helper loaded: form_helper
INFO - 2017-06-15 16:12:27 --> Form Validation Class Initialized
INFO - 2017-06-15 16:12:27 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:12:27 --> Helper loaded: url_helper
INFO - 2017-06-15 16:12:27 --> Model Class Initialized
INFO - 2017-06-15 16:12:27 --> Model Class Initialized
INFO - 2017-06-15 19:42:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:42:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:42:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:42:27 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:42:27 --> Final output sent to browser
DEBUG - 2017-06-15 19:42:27 --> Total execution time: 0.0554
INFO - 2017-06-15 16:13:41 --> Config Class Initialized
INFO - 2017-06-15 16:13:41 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:13:41 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:13:41 --> Utf8 Class Initialized
INFO - 2017-06-15 16:13:41 --> URI Class Initialized
INFO - 2017-06-15 16:13:41 --> Router Class Initialized
INFO - 2017-06-15 16:13:41 --> Output Class Initialized
INFO - 2017-06-15 16:13:41 --> Security Class Initialized
DEBUG - 2017-06-15 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:13:41 --> Input Class Initialized
INFO - 2017-06-15 16:13:41 --> Language Class Initialized
INFO - 2017-06-15 16:13:41 --> Loader Class Initialized
INFO - 2017-06-15 16:13:41 --> Helper loaded: common_helper
INFO - 2017-06-15 16:13:41 --> Database Driver Class Initialized
INFO - 2017-06-15 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:13:41 --> Email Class Initialized
INFO - 2017-06-15 16:13:41 --> Controller Class Initialized
INFO - 2017-06-15 16:13:41 --> Helper loaded: form_helper
INFO - 2017-06-15 16:13:41 --> Form Validation Class Initialized
INFO - 2017-06-15 16:13:41 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:13:41 --> Helper loaded: url_helper
INFO - 2017-06-15 16:13:41 --> Model Class Initialized
INFO - 2017-06-15 16:13:41 --> Model Class Initialized
INFO - 2017-06-15 19:43:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:43:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:43:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:43:41 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:43:41 --> Final output sent to browser
DEBUG - 2017-06-15 19:43:41 --> Total execution time: 0.0502
INFO - 2017-06-15 16:14:33 --> Config Class Initialized
INFO - 2017-06-15 16:14:33 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:14:33 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:14:33 --> Utf8 Class Initialized
INFO - 2017-06-15 16:14:33 --> URI Class Initialized
INFO - 2017-06-15 16:14:33 --> Router Class Initialized
INFO - 2017-06-15 16:14:33 --> Output Class Initialized
INFO - 2017-06-15 16:14:33 --> Security Class Initialized
DEBUG - 2017-06-15 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:14:33 --> Input Class Initialized
INFO - 2017-06-15 16:14:33 --> Language Class Initialized
INFO - 2017-06-15 16:14:33 --> Loader Class Initialized
INFO - 2017-06-15 16:14:33 --> Helper loaded: common_helper
INFO - 2017-06-15 16:14:33 --> Database Driver Class Initialized
INFO - 2017-06-15 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:14:33 --> Email Class Initialized
INFO - 2017-06-15 16:14:33 --> Controller Class Initialized
INFO - 2017-06-15 16:14:33 --> Helper loaded: form_helper
INFO - 2017-06-15 16:14:33 --> Form Validation Class Initialized
INFO - 2017-06-15 16:14:33 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:14:33 --> Helper loaded: url_helper
INFO - 2017-06-15 16:14:33 --> Model Class Initialized
INFO - 2017-06-15 16:14:33 --> Model Class Initialized
INFO - 2017-06-15 19:44:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:44:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:44:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:44:33 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:44:33 --> Final output sent to browser
DEBUG - 2017-06-15 19:44:33 --> Total execution time: 0.0519
INFO - 2017-06-15 16:17:54 --> Config Class Initialized
INFO - 2017-06-15 16:17:54 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:17:54 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:17:54 --> Utf8 Class Initialized
INFO - 2017-06-15 16:17:54 --> URI Class Initialized
INFO - 2017-06-15 16:17:54 --> Router Class Initialized
INFO - 2017-06-15 16:17:54 --> Output Class Initialized
INFO - 2017-06-15 16:17:54 --> Security Class Initialized
DEBUG - 2017-06-15 16:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:17:54 --> Input Class Initialized
INFO - 2017-06-15 16:17:54 --> Language Class Initialized
INFO - 2017-06-15 16:17:54 --> Loader Class Initialized
INFO - 2017-06-15 16:17:54 --> Helper loaded: common_helper
INFO - 2017-06-15 16:17:54 --> Database Driver Class Initialized
INFO - 2017-06-15 16:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:17:54 --> Email Class Initialized
INFO - 2017-06-15 16:17:54 --> Controller Class Initialized
INFO - 2017-06-15 16:17:54 --> Helper loaded: form_helper
INFO - 2017-06-15 16:17:54 --> Form Validation Class Initialized
INFO - 2017-06-15 16:17:54 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:17:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:17:54 --> Helper loaded: url_helper
INFO - 2017-06-15 16:17:54 --> Model Class Initialized
INFO - 2017-06-15 16:17:54 --> Model Class Initialized
INFO - 2017-06-15 19:47:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:47:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:47:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:47:54 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:47:54 --> Final output sent to browser
DEBUG - 2017-06-15 19:47:54 --> Total execution time: 0.0506
INFO - 2017-06-15 16:18:10 --> Config Class Initialized
INFO - 2017-06-15 16:18:10 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:18:10 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:18:10 --> Utf8 Class Initialized
INFO - 2017-06-15 16:18:10 --> URI Class Initialized
INFO - 2017-06-15 16:18:10 --> Router Class Initialized
INFO - 2017-06-15 16:18:10 --> Output Class Initialized
INFO - 2017-06-15 16:18:10 --> Security Class Initialized
DEBUG - 2017-06-15 16:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:18:10 --> Input Class Initialized
INFO - 2017-06-15 16:18:10 --> Language Class Initialized
INFO - 2017-06-15 16:18:10 --> Loader Class Initialized
INFO - 2017-06-15 16:18:10 --> Helper loaded: common_helper
INFO - 2017-06-15 16:18:10 --> Database Driver Class Initialized
INFO - 2017-06-15 16:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:18:10 --> Email Class Initialized
INFO - 2017-06-15 16:18:10 --> Controller Class Initialized
INFO - 2017-06-15 16:18:10 --> Helper loaded: form_helper
INFO - 2017-06-15 16:18:10 --> Form Validation Class Initialized
INFO - 2017-06-15 16:18:10 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:18:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:18:10 --> Helper loaded: url_helper
INFO - 2017-06-15 16:18:10 --> Model Class Initialized
INFO - 2017-06-15 16:18:10 --> Model Class Initialized
INFO - 2017-06-15 16:18:11 --> Config Class Initialized
INFO - 2017-06-15 16:18:11 --> Hooks Class Initialized
DEBUG - 2017-06-15 16:18:11 --> UTF-8 Support Enabled
INFO - 2017-06-15 16:18:11 --> Utf8 Class Initialized
INFO - 2017-06-15 16:18:11 --> URI Class Initialized
INFO - 2017-06-15 16:18:11 --> Router Class Initialized
INFO - 2017-06-15 16:18:11 --> Output Class Initialized
INFO - 2017-06-15 16:18:11 --> Security Class Initialized
DEBUG - 2017-06-15 16:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-06-15 16:18:11 --> Input Class Initialized
INFO - 2017-06-15 16:18:11 --> Language Class Initialized
INFO - 2017-06-15 16:18:11 --> Loader Class Initialized
INFO - 2017-06-15 16:18:11 --> Helper loaded: common_helper
INFO - 2017-06-15 16:18:11 --> Database Driver Class Initialized
INFO - 2017-06-15 16:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-06-15 16:18:11 --> Email Class Initialized
INFO - 2017-06-15 16:18:11 --> Controller Class Initialized
INFO - 2017-06-15 16:18:11 --> Helper loaded: form_helper
INFO - 2017-06-15 16:18:11 --> Form Validation Class Initialized
INFO - 2017-06-15 16:18:11 --> Helper loaded: email_helper
DEBUG - 2017-06-15 16:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-06-15 16:18:11 --> Helper loaded: url_helper
INFO - 2017-06-15 16:18:11 --> Model Class Initialized
INFO - 2017-06-15 16:18:11 --> Model Class Initialized
INFO - 2017-06-15 19:48:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\header.php
INFO - 2017-06-15 19:48:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\sidemenu.php
INFO - 2017-06-15 19:48:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\users/users.php
INFO - 2017-06-15 19:48:11 --> File loaded: C:\xampp\htdocs\bloodApp\application\views\footer.php
INFO - 2017-06-15 19:48:11 --> Final output sent to browser
DEBUG - 2017-06-15 19:48:11 --> Total execution time: 0.0515
