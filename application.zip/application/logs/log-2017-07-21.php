<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-21 12:07:40 --> Config Class Initialized
INFO - 2017-07-21 12:07:40 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:07:40 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:07:40 --> Utf8 Class Initialized
INFO - 2017-07-21 12:07:40 --> URI Class Initialized
DEBUG - 2017-07-21 12:07:40 --> No URI present. Default controller set.
INFO - 2017-07-21 12:07:40 --> Router Class Initialized
INFO - 2017-07-21 12:07:40 --> Output Class Initialized
INFO - 2017-07-21 12:07:40 --> Security Class Initialized
DEBUG - 2017-07-21 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:07:40 --> Input Class Initialized
INFO - 2017-07-21 12:07:40 --> Language Class Initialized
INFO - 2017-07-21 12:07:40 --> Loader Class Initialized
INFO - 2017-07-21 12:07:40 --> Helper loaded: common_helper
INFO - 2017-07-21 12:07:40 --> Database Driver Class Initialized
INFO - 2017-07-21 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:07:40 --> Email Class Initialized
INFO - 2017-07-21 12:07:40 --> Controller Class Initialized
INFO - 2017-07-21 12:07:40 --> Helper loaded: form_helper
INFO - 2017-07-21 12:07:40 --> Form Validation Class Initialized
INFO - 2017-07-21 12:07:40 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:07:40 --> Helper loaded: url_helper
INFO - 2017-07-21 12:07:40 --> Model Class Initialized
INFO - 2017-07-21 12:07:40 --> Model Class Initialized
INFO - 2017-07-21 12:07:40 --> Config Class Initialized
INFO - 2017-07-21 12:07:40 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:07:40 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:07:40 --> Utf8 Class Initialized
INFO - 2017-07-21 12:07:40 --> URI Class Initialized
INFO - 2017-07-21 12:07:40 --> Router Class Initialized
INFO - 2017-07-21 12:07:40 --> Output Class Initialized
INFO - 2017-07-21 12:07:40 --> Security Class Initialized
DEBUG - 2017-07-21 12:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:07:40 --> Input Class Initialized
INFO - 2017-07-21 12:07:40 --> Language Class Initialized
INFO - 2017-07-21 12:07:40 --> Loader Class Initialized
INFO - 2017-07-21 12:07:40 --> Helper loaded: common_helper
INFO - 2017-07-21 12:07:40 --> Database Driver Class Initialized
INFO - 2017-07-21 12:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:07:40 --> Email Class Initialized
INFO - 2017-07-21 12:07:40 --> Controller Class Initialized
INFO - 2017-07-21 12:07:40 --> Helper loaded: form_helper
INFO - 2017-07-21 12:07:40 --> Form Validation Class Initialized
INFO - 2017-07-21 12:07:40 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:07:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:07:40 --> Helper loaded: url_helper
INFO - 2017-07-21 12:07:40 --> Model Class Initialized
INFO - 2017-07-21 12:07:40 --> Model Class Initialized
ERROR - 2017-07-21 12:07:40 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:07:40 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:07:40 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:08:53 --> Config Class Initialized
INFO - 2017-07-21 12:08:53 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:08:53 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:08:53 --> Utf8 Class Initialized
INFO - 2017-07-21 12:08:53 --> URI Class Initialized
INFO - 2017-07-21 12:08:53 --> Router Class Initialized
INFO - 2017-07-21 12:08:53 --> Output Class Initialized
INFO - 2017-07-21 12:08:53 --> Security Class Initialized
DEBUG - 2017-07-21 12:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:08:53 --> Input Class Initialized
INFO - 2017-07-21 12:08:53 --> Language Class Initialized
INFO - 2017-07-21 12:08:53 --> Loader Class Initialized
INFO - 2017-07-21 12:08:53 --> Helper loaded: common_helper
INFO - 2017-07-21 12:08:53 --> Database Driver Class Initialized
INFO - 2017-07-21 12:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:08:53 --> Email Class Initialized
INFO - 2017-07-21 12:08:53 --> Controller Class Initialized
INFO - 2017-07-21 12:08:53 --> Helper loaded: form_helper
INFO - 2017-07-21 12:08:53 --> Form Validation Class Initialized
INFO - 2017-07-21 12:08:53 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:08:53 --> Helper loaded: url_helper
INFO - 2017-07-21 12:08:53 --> Model Class Initialized
INFO - 2017-07-21 12:08:53 --> Model Class Initialized
ERROR - 2017-07-21 12:08:53 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:08:53 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:08:53 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:08:54 --> Config Class Initialized
INFO - 2017-07-21 12:08:54 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:08:54 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:08:54 --> Utf8 Class Initialized
INFO - 2017-07-21 12:08:54 --> URI Class Initialized
INFO - 2017-07-21 12:08:54 --> Router Class Initialized
INFO - 2017-07-21 12:08:54 --> Output Class Initialized
INFO - 2017-07-21 12:08:54 --> Security Class Initialized
DEBUG - 2017-07-21 12:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:08:54 --> Input Class Initialized
INFO - 2017-07-21 12:08:54 --> Language Class Initialized
INFO - 2017-07-21 12:08:54 --> Loader Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: common_helper
INFO - 2017-07-21 12:08:54 --> Database Driver Class Initialized
INFO - 2017-07-21 12:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:08:54 --> Email Class Initialized
INFO - 2017-07-21 12:08:54 --> Controller Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: form_helper
INFO - 2017-07-21 12:08:54 --> Form Validation Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:08:54 --> Helper loaded: url_helper
INFO - 2017-07-21 12:08:54 --> Model Class Initialized
INFO - 2017-07-21 12:08:54 --> Model Class Initialized
ERROR - 2017-07-21 12:08:54 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:08:54 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:08:54 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:08:54 --> Config Class Initialized
INFO - 2017-07-21 12:08:54 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:08:54 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:08:54 --> Utf8 Class Initialized
INFO - 2017-07-21 12:08:54 --> URI Class Initialized
INFO - 2017-07-21 12:08:54 --> Router Class Initialized
INFO - 2017-07-21 12:08:54 --> Output Class Initialized
INFO - 2017-07-21 12:08:54 --> Security Class Initialized
DEBUG - 2017-07-21 12:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:08:54 --> Input Class Initialized
INFO - 2017-07-21 12:08:54 --> Language Class Initialized
INFO - 2017-07-21 12:08:54 --> Loader Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: common_helper
INFO - 2017-07-21 12:08:54 --> Database Driver Class Initialized
INFO - 2017-07-21 12:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:08:54 --> Email Class Initialized
INFO - 2017-07-21 12:08:54 --> Controller Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: form_helper
INFO - 2017-07-21 12:08:54 --> Form Validation Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:08:54 --> Helper loaded: url_helper
INFO - 2017-07-21 12:08:54 --> Model Class Initialized
INFO - 2017-07-21 12:08:54 --> Model Class Initialized
ERROR - 2017-07-21 12:08:54 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:08:54 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:08:54 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:08:54 --> Config Class Initialized
INFO - 2017-07-21 12:08:54 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:08:54 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:08:54 --> Utf8 Class Initialized
INFO - 2017-07-21 12:08:54 --> URI Class Initialized
INFO - 2017-07-21 12:08:54 --> Router Class Initialized
INFO - 2017-07-21 12:08:54 --> Output Class Initialized
INFO - 2017-07-21 12:08:54 --> Security Class Initialized
DEBUG - 2017-07-21 12:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:08:54 --> Input Class Initialized
INFO - 2017-07-21 12:08:54 --> Language Class Initialized
INFO - 2017-07-21 12:08:54 --> Loader Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: common_helper
INFO - 2017-07-21 12:08:54 --> Database Driver Class Initialized
INFO - 2017-07-21 12:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:08:54 --> Email Class Initialized
INFO - 2017-07-21 12:08:54 --> Controller Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: form_helper
INFO - 2017-07-21 12:08:54 --> Form Validation Class Initialized
INFO - 2017-07-21 12:08:54 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:08:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:08:54 --> Helper loaded: url_helper
INFO - 2017-07-21 12:08:54 --> Model Class Initialized
INFO - 2017-07-21 12:08:54 --> Model Class Initialized
ERROR - 2017-07-21 12:08:54 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:08:54 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:08:54 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:08:57 --> Config Class Initialized
INFO - 2017-07-21 12:08:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:08:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:08:57 --> Utf8 Class Initialized
INFO - 2017-07-21 12:08:57 --> URI Class Initialized
DEBUG - 2017-07-21 12:08:57 --> No URI present. Default controller set.
INFO - 2017-07-21 12:08:57 --> Router Class Initialized
INFO - 2017-07-21 12:08:57 --> Output Class Initialized
INFO - 2017-07-21 12:08:57 --> Security Class Initialized
DEBUG - 2017-07-21 12:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:08:57 --> Input Class Initialized
INFO - 2017-07-21 12:08:57 --> Language Class Initialized
INFO - 2017-07-21 12:08:57 --> Loader Class Initialized
INFO - 2017-07-21 12:08:57 --> Helper loaded: common_helper
INFO - 2017-07-21 12:08:57 --> Database Driver Class Initialized
INFO - 2017-07-21 12:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:08:57 --> Email Class Initialized
INFO - 2017-07-21 12:08:57 --> Controller Class Initialized
INFO - 2017-07-21 12:08:57 --> Helper loaded: form_helper
INFO - 2017-07-21 12:08:57 --> Form Validation Class Initialized
INFO - 2017-07-21 12:08:57 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:08:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:08:57 --> Helper loaded: url_helper
INFO - 2017-07-21 12:08:57 --> Model Class Initialized
INFO - 2017-07-21 12:08:57 --> Model Class Initialized
INFO - 2017-07-21 12:09:12 --> Config Class Initialized
INFO - 2017-07-21 12:09:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:12 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:12 --> URI Class Initialized
DEBUG - 2017-07-21 12:09:12 --> No URI present. Default controller set.
INFO - 2017-07-21 12:09:12 --> Router Class Initialized
INFO - 2017-07-21 12:09:12 --> Output Class Initialized
INFO - 2017-07-21 12:09:12 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:12 --> Input Class Initialized
INFO - 2017-07-21 12:09:12 --> Language Class Initialized
INFO - 2017-07-21 12:09:12 --> Loader Class Initialized
INFO - 2017-07-21 12:09:12 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:12 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:12 --> Email Class Initialized
INFO - 2017-07-21 12:09:12 --> Controller Class Initialized
INFO - 2017-07-21 12:09:12 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:12 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:12 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:12 --> Model Class Initialized
INFO - 2017-07-21 12:09:12 --> Model Class Initialized
INFO - 2017-07-21 12:09:21 --> Config Class Initialized
INFO - 2017-07-21 12:09:21 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:21 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:21 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:21 --> URI Class Initialized
DEBUG - 2017-07-21 12:09:21 --> No URI present. Default controller set.
INFO - 2017-07-21 12:09:21 --> Router Class Initialized
INFO - 2017-07-21 12:09:21 --> Output Class Initialized
INFO - 2017-07-21 12:09:21 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:21 --> Input Class Initialized
INFO - 2017-07-21 12:09:21 --> Language Class Initialized
INFO - 2017-07-21 12:09:21 --> Loader Class Initialized
INFO - 2017-07-21 12:09:21 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:21 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:21 --> Email Class Initialized
INFO - 2017-07-21 12:09:21 --> Controller Class Initialized
INFO - 2017-07-21 12:09:21 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:21 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:21 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:21 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:21 --> Model Class Initialized
INFO - 2017-07-21 12:09:21 --> Model Class Initialized
INFO - 2017-07-21 12:09:21 --> Config Class Initialized
INFO - 2017-07-21 12:09:21 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:21 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:21 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:21 --> URI Class Initialized
INFO - 2017-07-21 12:09:21 --> Router Class Initialized
INFO - 2017-07-21 12:09:21 --> Output Class Initialized
INFO - 2017-07-21 12:09:21 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:21 --> Input Class Initialized
INFO - 2017-07-21 12:09:21 --> Language Class Initialized
INFO - 2017-07-21 12:09:21 --> Loader Class Initialized
INFO - 2017-07-21 12:09:21 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:21 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:21 --> Email Class Initialized
INFO - 2017-07-21 12:09:21 --> Controller Class Initialized
INFO - 2017-07-21 12:09:21 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:21 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:21 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:21 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:21 --> Model Class Initialized
INFO - 2017-07-21 12:09:21 --> Model Class Initialized
ERROR - 2017-07-21 12:09:21 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:09:21 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:09:21 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:09:33 --> Config Class Initialized
INFO - 2017-07-21 12:09:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:33 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:33 --> URI Class Initialized
INFO - 2017-07-21 12:09:33 --> Router Class Initialized
INFO - 2017-07-21 12:09:33 --> Output Class Initialized
INFO - 2017-07-21 12:09:33 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:33 --> Input Class Initialized
INFO - 2017-07-21 12:09:33 --> Language Class Initialized
INFO - 2017-07-21 12:09:33 --> Loader Class Initialized
INFO - 2017-07-21 12:09:33 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:33 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:33 --> Email Class Initialized
INFO - 2017-07-21 12:09:33 --> Controller Class Initialized
INFO - 2017-07-21 12:09:33 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:33 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:33 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:33 --> Model Class Initialized
INFO - 2017-07-21 12:09:33 --> Model Class Initialized
ERROR - 2017-07-21 12:09:33 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:09:33 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:09:33 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:09:40 --> Config Class Initialized
INFO - 2017-07-21 12:09:40 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:40 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:40 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:40 --> URI Class Initialized
INFO - 2017-07-21 12:09:40 --> Router Class Initialized
INFO - 2017-07-21 12:09:40 --> Output Class Initialized
INFO - 2017-07-21 12:09:40 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:40 --> Input Class Initialized
INFO - 2017-07-21 12:09:40 --> Language Class Initialized
INFO - 2017-07-21 12:09:40 --> Loader Class Initialized
INFO - 2017-07-21 12:09:40 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:40 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:40 --> Email Class Initialized
INFO - 2017-07-21 12:09:40 --> Controller Class Initialized
INFO - 2017-07-21 12:09:40 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:40 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:40 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:40 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:40 --> Model Class Initialized
INFO - 2017-07-21 12:09:40 --> Model Class Initialized
ERROR - 2017-07-21 12:09:40 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:09:40 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:09:40 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:09:41 --> Config Class Initialized
INFO - 2017-07-21 12:09:41 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:41 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:41 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:41 --> URI Class Initialized
INFO - 2017-07-21 12:09:41 --> Router Class Initialized
INFO - 2017-07-21 12:09:41 --> Output Class Initialized
INFO - 2017-07-21 12:09:41 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:41 --> Input Class Initialized
INFO - 2017-07-21 12:09:41 --> Language Class Initialized
INFO - 2017-07-21 12:09:41 --> Loader Class Initialized
INFO - 2017-07-21 12:09:41 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:41 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:41 --> Email Class Initialized
INFO - 2017-07-21 12:09:41 --> Controller Class Initialized
INFO - 2017-07-21 12:09:41 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:41 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:41 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:41 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:41 --> Model Class Initialized
INFO - 2017-07-21 12:09:41 --> Model Class Initialized
ERROR - 2017-07-21 12:09:41 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:09:41 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:09:41 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:09:42 --> Config Class Initialized
INFO - 2017-07-21 12:09:42 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:42 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:42 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:42 --> URI Class Initialized
INFO - 2017-07-21 12:09:42 --> Router Class Initialized
INFO - 2017-07-21 12:09:42 --> Output Class Initialized
INFO - 2017-07-21 12:09:42 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:42 --> Input Class Initialized
INFO - 2017-07-21 12:09:42 --> Language Class Initialized
INFO - 2017-07-21 12:09:42 --> Loader Class Initialized
INFO - 2017-07-21 12:09:42 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:42 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:42 --> Email Class Initialized
INFO - 2017-07-21 12:09:42 --> Controller Class Initialized
INFO - 2017-07-21 12:09:42 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:42 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:42 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:42 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:42 --> Model Class Initialized
INFO - 2017-07-21 12:09:42 --> Model Class Initialized
ERROR - 2017-07-21 12:09:42 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 12:09:42 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 12:09:42 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 12:09:45 --> Config Class Initialized
INFO - 2017-07-21 12:09:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:09:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:09:45 --> Utf8 Class Initialized
INFO - 2017-07-21 12:09:45 --> URI Class Initialized
DEBUG - 2017-07-21 12:09:45 --> No URI present. Default controller set.
INFO - 2017-07-21 12:09:45 --> Router Class Initialized
INFO - 2017-07-21 12:09:45 --> Output Class Initialized
INFO - 2017-07-21 12:09:45 --> Security Class Initialized
DEBUG - 2017-07-21 12:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:09:45 --> Input Class Initialized
INFO - 2017-07-21 12:09:45 --> Language Class Initialized
INFO - 2017-07-21 12:09:45 --> Loader Class Initialized
INFO - 2017-07-21 12:09:45 --> Helper loaded: common_helper
INFO - 2017-07-21 12:09:45 --> Database Driver Class Initialized
INFO - 2017-07-21 12:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:09:45 --> Email Class Initialized
INFO - 2017-07-21 12:09:45 --> Controller Class Initialized
INFO - 2017-07-21 12:09:45 --> Helper loaded: form_helper
INFO - 2017-07-21 12:09:45 --> Form Validation Class Initialized
INFO - 2017-07-21 12:09:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:09:45 --> Helper loaded: url_helper
INFO - 2017-07-21 12:09:45 --> Model Class Initialized
INFO - 2017-07-21 12:09:45 --> Model Class Initialized
INFO - 2017-07-21 12:09:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 12:09:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 12:09:45 --> Final output sent to browser
DEBUG - 2017-07-21 12:09:45 --> Total execution time: 0.0468
INFO - 2017-07-21 12:13:59 --> Config Class Initialized
INFO - 2017-07-21 12:13:59 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:13:59 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:13:59 --> Utf8 Class Initialized
INFO - 2017-07-21 12:13:59 --> URI Class Initialized
DEBUG - 2017-07-21 12:13:59 --> No URI present. Default controller set.
INFO - 2017-07-21 12:13:59 --> Router Class Initialized
INFO - 2017-07-21 12:13:59 --> Output Class Initialized
INFO - 2017-07-21 12:13:59 --> Security Class Initialized
DEBUG - 2017-07-21 12:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:13:59 --> Input Class Initialized
INFO - 2017-07-21 12:13:59 --> Language Class Initialized
INFO - 2017-07-21 12:13:59 --> Loader Class Initialized
INFO - 2017-07-21 12:13:59 --> Helper loaded: common_helper
INFO - 2017-07-21 12:13:59 --> Database Driver Class Initialized
INFO - 2017-07-21 12:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:13:59 --> Email Class Initialized
INFO - 2017-07-21 12:13:59 --> Controller Class Initialized
INFO - 2017-07-21 12:13:59 --> Helper loaded: form_helper
INFO - 2017-07-21 12:13:59 --> Form Validation Class Initialized
INFO - 2017-07-21 12:13:59 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:13:59 --> Helper loaded: url_helper
INFO - 2017-07-21 12:13:59 --> Model Class Initialized
INFO - 2017-07-21 12:13:59 --> Model Class Initialized
INFO - 2017-07-21 12:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 12:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 12:13:59 --> Final output sent to browser
DEBUG - 2017-07-21 12:13:59 --> Total execution time: 0.0522
INFO - 2017-07-21 12:14:01 --> Config Class Initialized
INFO - 2017-07-21 12:14:01 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:14:01 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:14:01 --> Utf8 Class Initialized
INFO - 2017-07-21 12:14:01 --> URI Class Initialized
DEBUG - 2017-07-21 12:14:01 --> No URI present. Default controller set.
INFO - 2017-07-21 12:14:01 --> Router Class Initialized
INFO - 2017-07-21 12:14:01 --> Output Class Initialized
INFO - 2017-07-21 12:14:01 --> Security Class Initialized
DEBUG - 2017-07-21 12:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:14:01 --> Input Class Initialized
INFO - 2017-07-21 12:14:01 --> Language Class Initialized
INFO - 2017-07-21 12:14:01 --> Loader Class Initialized
INFO - 2017-07-21 12:14:01 --> Helper loaded: common_helper
INFO - 2017-07-21 12:14:01 --> Database Driver Class Initialized
INFO - 2017-07-21 12:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:14:01 --> Email Class Initialized
INFO - 2017-07-21 12:14:01 --> Controller Class Initialized
INFO - 2017-07-21 12:14:01 --> Helper loaded: form_helper
INFO - 2017-07-21 12:14:01 --> Form Validation Class Initialized
INFO - 2017-07-21 12:14:01 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:14:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:14:01 --> Helper loaded: url_helper
INFO - 2017-07-21 12:14:01 --> Model Class Initialized
INFO - 2017-07-21 12:14:01 --> Model Class Initialized
DEBUG - 2017-07-21 12:14:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:14:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 12:14:01 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 12:14:01 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 12:14:01 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 12:20:11 --> Config Class Initialized
INFO - 2017-07-21 12:20:11 --> Hooks Class Initialized
DEBUG - 2017-07-21 12:20:11 --> UTF-8 Support Enabled
INFO - 2017-07-21 12:20:11 --> Utf8 Class Initialized
INFO - 2017-07-21 12:20:11 --> URI Class Initialized
DEBUG - 2017-07-21 12:20:11 --> No URI present. Default controller set.
INFO - 2017-07-21 12:20:11 --> Router Class Initialized
INFO - 2017-07-21 12:20:11 --> Output Class Initialized
INFO - 2017-07-21 12:20:11 --> Security Class Initialized
DEBUG - 2017-07-21 12:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 12:20:11 --> Input Class Initialized
INFO - 2017-07-21 12:20:11 --> Language Class Initialized
INFO - 2017-07-21 12:20:11 --> Loader Class Initialized
INFO - 2017-07-21 12:20:11 --> Helper loaded: common_helper
INFO - 2017-07-21 12:20:11 --> Database Driver Class Initialized
INFO - 2017-07-21 12:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 12:20:11 --> Email Class Initialized
INFO - 2017-07-21 12:20:11 --> Controller Class Initialized
INFO - 2017-07-21 12:20:11 --> Helper loaded: form_helper
INFO - 2017-07-21 12:20:11 --> Form Validation Class Initialized
INFO - 2017-07-21 12:20:11 --> Helper loaded: email_helper
DEBUG - 2017-07-21 12:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:20:11 --> Helper loaded: url_helper
INFO - 2017-07-21 12:20:11 --> Model Class Initialized
INFO - 2017-07-21 12:20:11 --> Model Class Initialized
DEBUG - 2017-07-21 12:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 12:20:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 12:20:11 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 12:20:11 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 12:20:11 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 13:54:22 --> Config Class Initialized
INFO - 2017-07-21 13:54:22 --> Hooks Class Initialized
DEBUG - 2017-07-21 13:54:22 --> UTF-8 Support Enabled
INFO - 2017-07-21 13:54:22 --> Utf8 Class Initialized
INFO - 2017-07-21 13:54:22 --> URI Class Initialized
DEBUG - 2017-07-21 13:54:22 --> No URI present. Default controller set.
INFO - 2017-07-21 13:54:22 --> Router Class Initialized
INFO - 2017-07-21 13:54:22 --> Output Class Initialized
INFO - 2017-07-21 13:54:22 --> Security Class Initialized
DEBUG - 2017-07-21 13:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 13:54:22 --> Input Class Initialized
INFO - 2017-07-21 13:54:22 --> Language Class Initialized
INFO - 2017-07-21 13:54:22 --> Loader Class Initialized
INFO - 2017-07-21 13:54:22 --> Helper loaded: common_helper
INFO - 2017-07-21 13:54:22 --> Database Driver Class Initialized
INFO - 2017-07-21 13:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 13:54:22 --> Email Class Initialized
INFO - 2017-07-21 13:54:22 --> Controller Class Initialized
INFO - 2017-07-21 13:54:22 --> Helper loaded: form_helper
INFO - 2017-07-21 13:54:22 --> Form Validation Class Initialized
INFO - 2017-07-21 13:54:22 --> Helper loaded: email_helper
DEBUG - 2017-07-21 13:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:54:22 --> Helper loaded: url_helper
INFO - 2017-07-21 13:54:22 --> Model Class Initialized
INFO - 2017-07-21 13:54:22 --> Model Class Initialized
DEBUG - 2017-07-21 13:54:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:54:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 13:54:22 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 13:54:22 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 13:54:22 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 13:54:33 --> Config Class Initialized
INFO - 2017-07-21 13:54:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 13:54:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 13:54:33 --> Utf8 Class Initialized
INFO - 2017-07-21 13:54:33 --> URI Class Initialized
DEBUG - 2017-07-21 13:54:33 --> No URI present. Default controller set.
INFO - 2017-07-21 13:54:33 --> Router Class Initialized
INFO - 2017-07-21 13:54:33 --> Output Class Initialized
INFO - 2017-07-21 13:54:33 --> Security Class Initialized
DEBUG - 2017-07-21 13:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 13:54:33 --> Input Class Initialized
INFO - 2017-07-21 13:54:33 --> Language Class Initialized
INFO - 2017-07-21 13:54:33 --> Loader Class Initialized
INFO - 2017-07-21 13:54:33 --> Helper loaded: common_helper
INFO - 2017-07-21 13:54:33 --> Database Driver Class Initialized
ERROR - 2017-07-21 13:54:33 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-07-21 13:54:33 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysql\mysql_driver.php 135
INFO - 2017-07-21 13:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 13:54:33 --> Email Class Initialized
INFO - 2017-07-21 13:54:33 --> Controller Class Initialized
INFO - 2017-07-21 13:54:33 --> Helper loaded: form_helper
INFO - 2017-07-21 13:54:33 --> Form Validation Class Initialized
INFO - 2017-07-21 13:54:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 13:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:54:33 --> Helper loaded: url_helper
INFO - 2017-07-21 13:54:33 --> Model Class Initialized
INFO - 2017-07-21 13:54:33 --> Model Class Initialized
DEBUG - 2017-07-21 13:54:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:54:33 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 13:54:33 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 13:54:33 --> Call to undefined method CI_DB_mysql_driver::_error_message()
ERROR - 2017-07-21 13:54:33 --> Severity: Error --> Call to undefined method CI_DB_mysql_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 13:54:40 --> Config Class Initialized
INFO - 2017-07-21 13:54:40 --> Hooks Class Initialized
DEBUG - 2017-07-21 13:54:40 --> UTF-8 Support Enabled
INFO - 2017-07-21 13:54:40 --> Utf8 Class Initialized
INFO - 2017-07-21 13:54:40 --> URI Class Initialized
DEBUG - 2017-07-21 13:54:40 --> No URI present. Default controller set.
INFO - 2017-07-21 13:54:40 --> Router Class Initialized
INFO - 2017-07-21 13:54:40 --> Output Class Initialized
INFO - 2017-07-21 13:54:40 --> Security Class Initialized
DEBUG - 2017-07-21 13:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 13:54:40 --> Input Class Initialized
INFO - 2017-07-21 13:54:40 --> Language Class Initialized
INFO - 2017-07-21 13:54:40 --> Loader Class Initialized
INFO - 2017-07-21 13:54:40 --> Helper loaded: common_helper
INFO - 2017-07-21 13:54:40 --> Database Driver Class Initialized
INFO - 2017-07-21 13:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 13:54:40 --> Email Class Initialized
INFO - 2017-07-21 13:54:40 --> Controller Class Initialized
INFO - 2017-07-21 13:54:40 --> Helper loaded: form_helper
INFO - 2017-07-21 13:54:40 --> Form Validation Class Initialized
INFO - 2017-07-21 13:54:40 --> Helper loaded: email_helper
DEBUG - 2017-07-21 13:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:54:40 --> Helper loaded: url_helper
INFO - 2017-07-21 13:54:40 --> Model Class Initialized
INFO - 2017-07-21 13:54:40 --> Model Class Initialized
DEBUG - 2017-07-21 13:54:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:54:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 13:54:40 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 13:54:40 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 13:54:40 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 13:55:01 --> Config Class Initialized
INFO - 2017-07-21 13:55:01 --> Hooks Class Initialized
DEBUG - 2017-07-21 13:55:01 --> UTF-8 Support Enabled
INFO - 2017-07-21 13:55:01 --> Utf8 Class Initialized
INFO - 2017-07-21 13:55:01 --> URI Class Initialized
DEBUG - 2017-07-21 13:55:01 --> No URI present. Default controller set.
INFO - 2017-07-21 13:55:01 --> Router Class Initialized
INFO - 2017-07-21 13:55:01 --> Output Class Initialized
INFO - 2017-07-21 13:55:01 --> Security Class Initialized
DEBUG - 2017-07-21 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 13:55:01 --> Input Class Initialized
INFO - 2017-07-21 13:55:01 --> Language Class Initialized
INFO - 2017-07-21 13:55:01 --> Loader Class Initialized
INFO - 2017-07-21 13:55:01 --> Helper loaded: common_helper
INFO - 2017-07-21 13:55:01 --> Database Driver Class Initialized
INFO - 2017-07-21 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 13:55:01 --> Email Class Initialized
INFO - 2017-07-21 13:55:01 --> Controller Class Initialized
INFO - 2017-07-21 13:55:01 --> Helper loaded: form_helper
INFO - 2017-07-21 13:55:01 --> Form Validation Class Initialized
INFO - 2017-07-21 13:55:01 --> Helper loaded: email_helper
DEBUG - 2017-07-21 13:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:55:01 --> Helper loaded: url_helper
INFO - 2017-07-21 13:55:01 --> Model Class Initialized
INFO - 2017-07-21 13:55:01 --> Model Class Initialized
DEBUG - 2017-07-21 13:55:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:55:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 13:55:01 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 13:55:01 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 13:55:01 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 13:55:03 --> Config Class Initialized
INFO - 2017-07-21 13:55:03 --> Hooks Class Initialized
DEBUG - 2017-07-21 13:55:03 --> UTF-8 Support Enabled
INFO - 2017-07-21 13:55:03 --> Utf8 Class Initialized
INFO - 2017-07-21 13:55:03 --> URI Class Initialized
DEBUG - 2017-07-21 13:55:03 --> No URI present. Default controller set.
INFO - 2017-07-21 13:55:03 --> Router Class Initialized
INFO - 2017-07-21 13:55:03 --> Output Class Initialized
INFO - 2017-07-21 13:55:03 --> Security Class Initialized
DEBUG - 2017-07-21 13:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 13:55:03 --> Input Class Initialized
INFO - 2017-07-21 13:55:03 --> Language Class Initialized
INFO - 2017-07-21 13:55:03 --> Loader Class Initialized
INFO - 2017-07-21 13:55:03 --> Helper loaded: common_helper
INFO - 2017-07-21 13:55:03 --> Database Driver Class Initialized
INFO - 2017-07-21 13:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 13:55:03 --> Email Class Initialized
INFO - 2017-07-21 13:55:03 --> Controller Class Initialized
INFO - 2017-07-21 13:55:03 --> Helper loaded: form_helper
INFO - 2017-07-21 13:55:03 --> Form Validation Class Initialized
INFO - 2017-07-21 13:55:03 --> Helper loaded: email_helper
DEBUG - 2017-07-21 13:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:55:03 --> Helper loaded: url_helper
INFO - 2017-07-21 13:55:03 --> Model Class Initialized
INFO - 2017-07-21 13:55:03 --> Model Class Initialized
DEBUG - 2017-07-21 13:55:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:55:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 13:55:03 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 13:55:03 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 13:55:03 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 13:55:14 --> Config Class Initialized
INFO - 2017-07-21 13:55:14 --> Hooks Class Initialized
DEBUG - 2017-07-21 13:55:14 --> UTF-8 Support Enabled
INFO - 2017-07-21 13:55:14 --> Utf8 Class Initialized
INFO - 2017-07-21 13:55:14 --> URI Class Initialized
DEBUG - 2017-07-21 13:55:14 --> No URI present. Default controller set.
INFO - 2017-07-21 13:55:14 --> Router Class Initialized
INFO - 2017-07-21 13:55:14 --> Output Class Initialized
INFO - 2017-07-21 13:55:14 --> Security Class Initialized
DEBUG - 2017-07-21 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 13:55:14 --> Input Class Initialized
INFO - 2017-07-21 13:55:14 --> Language Class Initialized
INFO - 2017-07-21 13:55:14 --> Loader Class Initialized
INFO - 2017-07-21 13:55:14 --> Helper loaded: common_helper
INFO - 2017-07-21 13:55:14 --> Database Driver Class Initialized
INFO - 2017-07-21 13:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 13:55:14 --> Email Class Initialized
INFO - 2017-07-21 13:55:14 --> Controller Class Initialized
INFO - 2017-07-21 13:55:14 --> Helper loaded: form_helper
INFO - 2017-07-21 13:55:14 --> Form Validation Class Initialized
INFO - 2017-07-21 13:55:14 --> Helper loaded: email_helper
DEBUG - 2017-07-21 13:55:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:55:14 --> Helper loaded: url_helper
INFO - 2017-07-21 13:55:14 --> Model Class Initialized
INFO - 2017-07-21 13:55:14 --> Model Class Initialized
DEBUG - 2017-07-21 13:55:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 13:55:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 13:55:14 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 13:55:14 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 13:55:14 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 14:04:19 --> Config Class Initialized
INFO - 2017-07-21 14:04:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:04:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:04:19 --> Utf8 Class Initialized
INFO - 2017-07-21 14:04:19 --> URI Class Initialized
DEBUG - 2017-07-21 14:04:19 --> No URI present. Default controller set.
INFO - 2017-07-21 14:04:19 --> Router Class Initialized
INFO - 2017-07-21 14:04:19 --> Output Class Initialized
INFO - 2017-07-21 14:04:19 --> Security Class Initialized
DEBUG - 2017-07-21 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:04:19 --> Input Class Initialized
INFO - 2017-07-21 14:04:19 --> Language Class Initialized
ERROR - 2017-07-21 14:04:19 --> Cannot use try without catch or finally
ERROR - 2017-07-21 14:04:19 --> Severity: Compile Error --> Cannot use try without catch or finally C:\xampp\htdocs\FlickNews\admin\application\controllers\Admin.php 106
INFO - 2017-07-21 14:04:30 --> Config Class Initialized
INFO - 2017-07-21 14:04:30 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:04:30 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:04:30 --> Utf8 Class Initialized
INFO - 2017-07-21 14:04:30 --> URI Class Initialized
DEBUG - 2017-07-21 14:04:30 --> No URI present. Default controller set.
INFO - 2017-07-21 14:04:30 --> Router Class Initialized
INFO - 2017-07-21 14:04:30 --> Output Class Initialized
INFO - 2017-07-21 14:04:30 --> Security Class Initialized
DEBUG - 2017-07-21 14:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:04:30 --> Input Class Initialized
INFO - 2017-07-21 14:04:30 --> Language Class Initialized
INFO - 2017-07-21 14:04:30 --> Loader Class Initialized
INFO - 2017-07-21 14:04:30 --> Helper loaded: common_helper
INFO - 2017-07-21 14:04:30 --> Database Driver Class Initialized
INFO - 2017-07-21 14:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:04:30 --> Email Class Initialized
INFO - 2017-07-21 14:04:30 --> Controller Class Initialized
INFO - 2017-07-21 14:04:30 --> Helper loaded: form_helper
INFO - 2017-07-21 14:04:30 --> Form Validation Class Initialized
INFO - 2017-07-21 14:04:30 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:04:30 --> Helper loaded: url_helper
INFO - 2017-07-21 14:04:30 --> Model Class Initialized
INFO - 2017-07-21 14:04:30 --> Model Class Initialized
DEBUG - 2017-07-21 14:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:04:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 14:04:30 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 14:04:30 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 14:04:30 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 14:05:52 --> Config Class Initialized
INFO - 2017-07-21 14:05:52 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:05:52 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:05:52 --> Utf8 Class Initialized
INFO - 2017-07-21 14:05:52 --> URI Class Initialized
DEBUG - 2017-07-21 14:05:52 --> No URI present. Default controller set.
INFO - 2017-07-21 14:05:52 --> Router Class Initialized
INFO - 2017-07-21 14:05:52 --> Output Class Initialized
INFO - 2017-07-21 14:05:52 --> Security Class Initialized
DEBUG - 2017-07-21 14:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:05:52 --> Input Class Initialized
INFO - 2017-07-21 14:05:52 --> Language Class Initialized
INFO - 2017-07-21 14:05:52 --> Loader Class Initialized
INFO - 2017-07-21 14:05:52 --> Helper loaded: common_helper
INFO - 2017-07-21 14:05:52 --> Database Driver Class Initialized
INFO - 2017-07-21 14:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:05:52 --> Email Class Initialized
INFO - 2017-07-21 14:05:52 --> Controller Class Initialized
INFO - 2017-07-21 14:05:52 --> Helper loaded: form_helper
INFO - 2017-07-21 14:05:52 --> Form Validation Class Initialized
INFO - 2017-07-21 14:05:52 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:05:52 --> Helper loaded: url_helper
INFO - 2017-07-21 14:05:52 --> Model Class Initialized
INFO - 2017-07-21 14:05:52 --> Model Class Initialized
INFO - 2017-07-21 14:05:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:05:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:05:52 --> Final output sent to browser
DEBUG - 2017-07-21 14:05:52 --> Total execution time: 0.0436
INFO - 2017-07-21 14:05:55 --> Config Class Initialized
INFO - 2017-07-21 14:05:55 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:05:55 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:05:55 --> Utf8 Class Initialized
INFO - 2017-07-21 14:05:55 --> URI Class Initialized
DEBUG - 2017-07-21 14:05:55 --> No URI present. Default controller set.
INFO - 2017-07-21 14:05:55 --> Router Class Initialized
INFO - 2017-07-21 14:05:55 --> Output Class Initialized
INFO - 2017-07-21 14:05:55 --> Security Class Initialized
DEBUG - 2017-07-21 14:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:05:55 --> Input Class Initialized
INFO - 2017-07-21 14:05:55 --> Language Class Initialized
INFO - 2017-07-21 14:05:55 --> Loader Class Initialized
INFO - 2017-07-21 14:05:55 --> Helper loaded: common_helper
INFO - 2017-07-21 14:05:55 --> Database Driver Class Initialized
INFO - 2017-07-21 14:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:05:55 --> Email Class Initialized
INFO - 2017-07-21 14:05:55 --> Controller Class Initialized
INFO - 2017-07-21 14:05:55 --> Helper loaded: form_helper
INFO - 2017-07-21 14:05:55 --> Form Validation Class Initialized
INFO - 2017-07-21 14:05:55 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:05:55 --> Helper loaded: url_helper
INFO - 2017-07-21 14:05:55 --> Model Class Initialized
INFO - 2017-07-21 14:05:55 --> Model Class Initialized
DEBUG - 2017-07-21 14:05:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:05:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 14:05:55 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 14:05:55 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 14:05:55 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 14:06:12 --> Config Class Initialized
INFO - 2017-07-21 14:06:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:06:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:06:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:06:12 --> URI Class Initialized
DEBUG - 2017-07-21 14:06:12 --> No URI present. Default controller set.
INFO - 2017-07-21 14:06:12 --> Router Class Initialized
INFO - 2017-07-21 14:06:12 --> Output Class Initialized
INFO - 2017-07-21 14:06:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:06:12 --> Input Class Initialized
INFO - 2017-07-21 14:06:12 --> Language Class Initialized
INFO - 2017-07-21 14:06:12 --> Loader Class Initialized
INFO - 2017-07-21 14:06:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:06:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:06:12 --> Email Class Initialized
INFO - 2017-07-21 14:06:12 --> Controller Class Initialized
INFO - 2017-07-21 14:06:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:06:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:06:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:06:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:06:12 --> Model Class Initialized
INFO - 2017-07-21 14:06:12 --> Model Class Initialized
DEBUG - 2017-07-21 14:06:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 14:06:12 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 14:06:12 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 14:06:12 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 14:06:13 --> Config Class Initialized
INFO - 2017-07-21 14:06:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:06:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:06:13 --> Utf8 Class Initialized
INFO - 2017-07-21 14:06:13 --> URI Class Initialized
DEBUG - 2017-07-21 14:06:13 --> No URI present. Default controller set.
INFO - 2017-07-21 14:06:13 --> Router Class Initialized
INFO - 2017-07-21 14:06:13 --> Output Class Initialized
INFO - 2017-07-21 14:06:13 --> Security Class Initialized
DEBUG - 2017-07-21 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:06:13 --> Input Class Initialized
INFO - 2017-07-21 14:06:13 --> Language Class Initialized
INFO - 2017-07-21 14:06:13 --> Loader Class Initialized
INFO - 2017-07-21 14:06:13 --> Helper loaded: common_helper
INFO - 2017-07-21 14:06:13 --> Database Driver Class Initialized
INFO - 2017-07-21 14:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:06:13 --> Email Class Initialized
INFO - 2017-07-21 14:06:13 --> Controller Class Initialized
INFO - 2017-07-21 14:06:13 --> Helper loaded: form_helper
INFO - 2017-07-21 14:06:13 --> Form Validation Class Initialized
INFO - 2017-07-21 14:06:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:13 --> Helper loaded: url_helper
INFO - 2017-07-21 14:06:13 --> Model Class Initialized
INFO - 2017-07-21 14:06:13 --> Model Class Initialized
INFO - 2017-07-21 14:06:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:06:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:06:13 --> Final output sent to browser
DEBUG - 2017-07-21 14:06:13 --> Total execution time: 0.0498
INFO - 2017-07-21 14:06:14 --> Config Class Initialized
INFO - 2017-07-21 14:06:14 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:06:14 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:06:14 --> Utf8 Class Initialized
INFO - 2017-07-21 14:06:14 --> URI Class Initialized
DEBUG - 2017-07-21 14:06:14 --> No URI present. Default controller set.
INFO - 2017-07-21 14:06:14 --> Router Class Initialized
INFO - 2017-07-21 14:06:14 --> Output Class Initialized
INFO - 2017-07-21 14:06:14 --> Security Class Initialized
DEBUG - 2017-07-21 14:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:06:14 --> Input Class Initialized
INFO - 2017-07-21 14:06:14 --> Language Class Initialized
INFO - 2017-07-21 14:06:14 --> Loader Class Initialized
INFO - 2017-07-21 14:06:14 --> Helper loaded: common_helper
INFO - 2017-07-21 14:06:14 --> Database Driver Class Initialized
INFO - 2017-07-21 14:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:06:14 --> Email Class Initialized
INFO - 2017-07-21 14:06:14 --> Controller Class Initialized
INFO - 2017-07-21 14:06:14 --> Helper loaded: form_helper
INFO - 2017-07-21 14:06:14 --> Form Validation Class Initialized
INFO - 2017-07-21 14:06:14 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:14 --> Helper loaded: url_helper
INFO - 2017-07-21 14:06:14 --> Model Class Initialized
INFO - 2017-07-21 14:06:14 --> Model Class Initialized
DEBUG - 2017-07-21 14:06:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 14:06:14 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`, `profilePicture`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 14:06:14 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 14:06:14 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 14:06:46 --> Config Class Initialized
INFO - 2017-07-21 14:06:46 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:06:46 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:06:46 --> Utf8 Class Initialized
INFO - 2017-07-21 14:06:46 --> URI Class Initialized
DEBUG - 2017-07-21 14:06:46 --> No URI present. Default controller set.
INFO - 2017-07-21 14:06:46 --> Router Class Initialized
INFO - 2017-07-21 14:06:46 --> Output Class Initialized
INFO - 2017-07-21 14:06:46 --> Security Class Initialized
DEBUG - 2017-07-21 14:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:06:46 --> Input Class Initialized
INFO - 2017-07-21 14:06:46 --> Language Class Initialized
INFO - 2017-07-21 14:06:46 --> Loader Class Initialized
INFO - 2017-07-21 14:06:46 --> Helper loaded: common_helper
INFO - 2017-07-21 14:06:46 --> Database Driver Class Initialized
INFO - 2017-07-21 14:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:06:46 --> Email Class Initialized
INFO - 2017-07-21 14:06:46 --> Controller Class Initialized
INFO - 2017-07-21 14:06:46 --> Helper loaded: form_helper
INFO - 2017-07-21 14:06:46 --> Form Validation Class Initialized
INFO - 2017-07-21 14:06:46 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:06:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:46 --> Helper loaded: url_helper
INFO - 2017-07-21 14:06:46 --> Model Class Initialized
INFO - 2017-07-21 14:06:46 --> Model Class Initialized
DEBUG - 2017-07-21 14:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:06:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:07:23 --> Config Class Initialized
INFO - 2017-07-21 14:07:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:07:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:07:23 --> Utf8 Class Initialized
INFO - 2017-07-21 14:07:23 --> URI Class Initialized
DEBUG - 2017-07-21 14:07:23 --> No URI present. Default controller set.
INFO - 2017-07-21 14:07:23 --> Router Class Initialized
INFO - 2017-07-21 14:07:23 --> Output Class Initialized
INFO - 2017-07-21 14:07:23 --> Security Class Initialized
DEBUG - 2017-07-21 14:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:07:23 --> Input Class Initialized
INFO - 2017-07-21 14:07:23 --> Language Class Initialized
INFO - 2017-07-21 14:07:23 --> Loader Class Initialized
INFO - 2017-07-21 14:07:23 --> Helper loaded: common_helper
INFO - 2017-07-21 14:07:23 --> Database Driver Class Initialized
INFO - 2017-07-21 14:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:07:23 --> Email Class Initialized
INFO - 2017-07-21 14:07:23 --> Controller Class Initialized
INFO - 2017-07-21 14:07:23 --> Helper loaded: form_helper
INFO - 2017-07-21 14:07:23 --> Form Validation Class Initialized
INFO - 2017-07-21 14:07:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:07:23 --> Helper loaded: url_helper
INFO - 2017-07-21 14:07:23 --> Model Class Initialized
INFO - 2017-07-21 14:07:23 --> Model Class Initialized
DEBUG - 2017-07-21 14:07:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:07:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:09:13 --> Config Class Initialized
INFO - 2017-07-21 14:09:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:09:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:09:13 --> Utf8 Class Initialized
INFO - 2017-07-21 14:09:13 --> URI Class Initialized
DEBUG - 2017-07-21 14:09:13 --> No URI present. Default controller set.
INFO - 2017-07-21 14:09:13 --> Router Class Initialized
INFO - 2017-07-21 14:09:13 --> Output Class Initialized
INFO - 2017-07-21 14:09:13 --> Security Class Initialized
DEBUG - 2017-07-21 14:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:09:13 --> Input Class Initialized
INFO - 2017-07-21 14:09:13 --> Language Class Initialized
INFO - 2017-07-21 14:09:13 --> Loader Class Initialized
INFO - 2017-07-21 14:09:13 --> Helper loaded: common_helper
INFO - 2017-07-21 14:09:13 --> Database Driver Class Initialized
INFO - 2017-07-21 14:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:09:13 --> Email Class Initialized
INFO - 2017-07-21 14:09:13 --> Controller Class Initialized
INFO - 2017-07-21 14:09:13 --> Helper loaded: form_helper
INFO - 2017-07-21 14:09:13 --> Form Validation Class Initialized
INFO - 2017-07-21 14:09:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:13 --> Helper loaded: url_helper
INFO - 2017-07-21 14:09:13 --> Model Class Initialized
INFO - 2017-07-21 14:09:13 --> Model Class Initialized
DEBUG - 2017-07-21 14:09:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 14:09:13 --> Undefined property: stdClass::$profilePicture
ERROR - 2017-07-21 14:09:13 --> Severity: Notice --> Undefined property: stdClass::$profilePicture C:\xampp\htdocs\FlickNews\admin\application\controllers\Admin.php 155
INFO - 2017-07-21 14:09:13 --> Config Class Initialized
INFO - 2017-07-21 14:09:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:09:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:09:13 --> Utf8 Class Initialized
INFO - 2017-07-21 14:09:13 --> URI Class Initialized
INFO - 2017-07-21 14:09:13 --> Router Class Initialized
INFO - 2017-07-21 14:09:13 --> Output Class Initialized
INFO - 2017-07-21 14:09:13 --> Security Class Initialized
DEBUG - 2017-07-21 14:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:09:13 --> Input Class Initialized
INFO - 2017-07-21 14:09:13 --> Language Class Initialized
INFO - 2017-07-21 14:09:13 --> Loader Class Initialized
INFO - 2017-07-21 14:09:13 --> Helper loaded: common_helper
INFO - 2017-07-21 14:09:13 --> Database Driver Class Initialized
INFO - 2017-07-21 14:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:09:13 --> Email Class Initialized
INFO - 2017-07-21 14:09:13 --> Controller Class Initialized
INFO - 2017-07-21 14:09:13 --> Helper loaded: form_helper
INFO - 2017-07-21 14:09:13 --> Form Validation Class Initialized
INFO - 2017-07-21 14:09:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:13 --> Helper loaded: url_helper
INFO - 2017-07-21 14:09:13 --> Model Class Initialized
INFO - 2017-07-21 14:09:13 --> Model Class Initialized
ERROR - 2017-07-21 14:09:13 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 14:09:13 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 14:09:13 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 14:09:49 --> Config Class Initialized
INFO - 2017-07-21 14:09:49 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:09:49 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:09:49 --> Utf8 Class Initialized
INFO - 2017-07-21 14:09:49 --> URI Class Initialized
INFO - 2017-07-21 14:09:49 --> Router Class Initialized
INFO - 2017-07-21 14:09:49 --> Output Class Initialized
INFO - 2017-07-21 14:09:49 --> Security Class Initialized
DEBUG - 2017-07-21 14:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:09:49 --> Input Class Initialized
INFO - 2017-07-21 14:09:49 --> Language Class Initialized
INFO - 2017-07-21 14:09:49 --> Loader Class Initialized
INFO - 2017-07-21 14:09:49 --> Helper loaded: common_helper
INFO - 2017-07-21 14:09:49 --> Database Driver Class Initialized
INFO - 2017-07-21 14:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:09:49 --> Email Class Initialized
INFO - 2017-07-21 14:09:49 --> Controller Class Initialized
INFO - 2017-07-21 14:09:49 --> Helper loaded: form_helper
INFO - 2017-07-21 14:09:49 --> Form Validation Class Initialized
INFO - 2017-07-21 14:09:49 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:49 --> Helper loaded: url_helper
INFO - 2017-07-21 14:09:49 --> Model Class Initialized
INFO - 2017-07-21 14:09:49 --> Model Class Initialized
ERROR - 2017-07-21 14:09:49 --> Query error: Table 'flicknews.bloodgroups' doesn't exist - Invalid query: SELECT count(*) as bloodGroupsCount
FROM `bloodgroups`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-07-21 14:09:49 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 14:09:49 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 14:09:50 --> Config Class Initialized
INFO - 2017-07-21 14:09:50 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:09:50 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:09:50 --> Utf8 Class Initialized
INFO - 2017-07-21 14:09:50 --> URI Class Initialized
DEBUG - 2017-07-21 14:09:50 --> No URI present. Default controller set.
INFO - 2017-07-21 14:09:50 --> Router Class Initialized
INFO - 2017-07-21 14:09:50 --> Output Class Initialized
INFO - 2017-07-21 14:09:50 --> Security Class Initialized
DEBUG - 2017-07-21 14:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:09:50 --> Input Class Initialized
INFO - 2017-07-21 14:09:50 --> Language Class Initialized
INFO - 2017-07-21 14:09:50 --> Loader Class Initialized
INFO - 2017-07-21 14:09:50 --> Helper loaded: common_helper
INFO - 2017-07-21 14:09:50 --> Database Driver Class Initialized
INFO - 2017-07-21 14:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:09:50 --> Email Class Initialized
INFO - 2017-07-21 14:09:50 --> Controller Class Initialized
INFO - 2017-07-21 14:09:50 --> Helper loaded: form_helper
INFO - 2017-07-21 14:09:50 --> Form Validation Class Initialized
INFO - 2017-07-21 14:09:50 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:09:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:50 --> Helper loaded: url_helper
INFO - 2017-07-21 14:09:50 --> Model Class Initialized
INFO - 2017-07-21 14:09:50 --> Model Class Initialized
INFO - 2017-07-21 14:09:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:09:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:09:50 --> Final output sent to browser
DEBUG - 2017-07-21 14:09:50 --> Total execution time: 0.0513
INFO - 2017-07-21 14:09:52 --> Config Class Initialized
INFO - 2017-07-21 14:09:52 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:09:52 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:09:52 --> Utf8 Class Initialized
INFO - 2017-07-21 14:09:52 --> URI Class Initialized
DEBUG - 2017-07-21 14:09:52 --> No URI present. Default controller set.
INFO - 2017-07-21 14:09:52 --> Router Class Initialized
INFO - 2017-07-21 14:09:52 --> Output Class Initialized
INFO - 2017-07-21 14:09:52 --> Security Class Initialized
DEBUG - 2017-07-21 14:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:09:52 --> Input Class Initialized
INFO - 2017-07-21 14:09:52 --> Language Class Initialized
INFO - 2017-07-21 14:09:52 --> Loader Class Initialized
INFO - 2017-07-21 14:09:52 --> Helper loaded: common_helper
INFO - 2017-07-21 14:09:52 --> Database Driver Class Initialized
INFO - 2017-07-21 14:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:09:52 --> Email Class Initialized
INFO - 2017-07-21 14:09:52 --> Controller Class Initialized
INFO - 2017-07-21 14:09:52 --> Helper loaded: form_helper
INFO - 2017-07-21 14:09:52 --> Form Validation Class Initialized
INFO - 2017-07-21 14:09:52 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:52 --> Helper loaded: url_helper
INFO - 2017-07-21 14:09:52 --> Model Class Initialized
INFO - 2017-07-21 14:09:52 --> Model Class Initialized
DEBUG - 2017-07-21 14:09:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:09:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:11:33 --> Config Class Initialized
INFO - 2017-07-21 14:11:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:11:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:11:33 --> Utf8 Class Initialized
INFO - 2017-07-21 14:11:33 --> URI Class Initialized
DEBUG - 2017-07-21 14:11:33 --> No URI present. Default controller set.
INFO - 2017-07-21 14:11:33 --> Router Class Initialized
INFO - 2017-07-21 14:11:33 --> Output Class Initialized
INFO - 2017-07-21 14:11:33 --> Security Class Initialized
DEBUG - 2017-07-21 14:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:11:33 --> Input Class Initialized
INFO - 2017-07-21 14:11:33 --> Language Class Initialized
INFO - 2017-07-21 14:11:33 --> Loader Class Initialized
INFO - 2017-07-21 14:11:33 --> Helper loaded: common_helper
INFO - 2017-07-21 14:11:33 --> Database Driver Class Initialized
INFO - 2017-07-21 14:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:11:33 --> Email Class Initialized
INFO - 2017-07-21 14:11:33 --> Controller Class Initialized
INFO - 2017-07-21 14:11:33 --> Helper loaded: form_helper
INFO - 2017-07-21 14:11:33 --> Form Validation Class Initialized
INFO - 2017-07-21 14:11:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:11:33 --> Helper loaded: url_helper
INFO - 2017-07-21 14:11:33 --> Model Class Initialized
INFO - 2017-07-21 14:11:33 --> Model Class Initialized
DEBUG - 2017-07-21 14:11:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:11:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:11:33 --> Config Class Initialized
INFO - 2017-07-21 14:11:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:11:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:11:33 --> Utf8 Class Initialized
INFO - 2017-07-21 14:11:33 --> URI Class Initialized
INFO - 2017-07-21 14:11:33 --> Router Class Initialized
INFO - 2017-07-21 14:11:33 --> Output Class Initialized
INFO - 2017-07-21 14:11:33 --> Security Class Initialized
DEBUG - 2017-07-21 14:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:11:33 --> Input Class Initialized
INFO - 2017-07-21 14:11:33 --> Language Class Initialized
INFO - 2017-07-21 14:11:33 --> Loader Class Initialized
INFO - 2017-07-21 14:11:33 --> Helper loaded: common_helper
INFO - 2017-07-21 14:11:33 --> Database Driver Class Initialized
INFO - 2017-07-21 14:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:11:33 --> Email Class Initialized
INFO - 2017-07-21 14:11:33 --> Controller Class Initialized
INFO - 2017-07-21 14:11:33 --> Helper loaded: form_helper
INFO - 2017-07-21 14:11:33 --> Form Validation Class Initialized
INFO - 2017-07-21 14:11:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:11:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:11:33 --> Helper loaded: url_helper
INFO - 2017-07-21 14:11:33 --> Model Class Initialized
INFO - 2017-07-21 14:11:33 --> Model Class Initialized
ERROR - 2017-07-21 14:11:33 --> Call to undefined function debbug()
ERROR - 2017-07-21 14:11:33 --> Severity: Error --> Call to undefined function debbug() C:\xampp\htdocs\FlickNews\admin\application\controllers\Admin.php 112
INFO - 2017-07-21 14:11:40 --> Config Class Initialized
INFO - 2017-07-21 14:11:40 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:11:40 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:11:40 --> Utf8 Class Initialized
INFO - 2017-07-21 14:11:40 --> URI Class Initialized
INFO - 2017-07-21 14:11:40 --> Router Class Initialized
INFO - 2017-07-21 14:11:40 --> Output Class Initialized
INFO - 2017-07-21 14:11:40 --> Security Class Initialized
DEBUG - 2017-07-21 14:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:11:40 --> Input Class Initialized
INFO - 2017-07-21 14:11:40 --> Language Class Initialized
INFO - 2017-07-21 14:11:40 --> Loader Class Initialized
INFO - 2017-07-21 14:11:40 --> Helper loaded: common_helper
INFO - 2017-07-21 14:11:40 --> Database Driver Class Initialized
INFO - 2017-07-21 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:11:40 --> Email Class Initialized
INFO - 2017-07-21 14:11:40 --> Controller Class Initialized
INFO - 2017-07-21 14:11:40 --> Helper loaded: form_helper
INFO - 2017-07-21 14:11:40 --> Form Validation Class Initialized
INFO - 2017-07-21 14:11:40 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:11:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:11:40 --> Helper loaded: url_helper
INFO - 2017-07-21 14:11:40 --> Model Class Initialized
INFO - 2017-07-21 14:11:40 --> Model Class Initialized
INFO - 2017-07-21 14:12:11 --> Config Class Initialized
INFO - 2017-07-21 14:12:11 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:11 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:11 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:11 --> URI Class Initialized
INFO - 2017-07-21 14:12:11 --> Router Class Initialized
INFO - 2017-07-21 14:12:11 --> Output Class Initialized
INFO - 2017-07-21 14:12:11 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:11 --> Input Class Initialized
INFO - 2017-07-21 14:12:11 --> Language Class Initialized
INFO - 2017-07-21 14:12:11 --> Loader Class Initialized
INFO - 2017-07-21 14:12:11 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:11 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:11 --> Email Class Initialized
INFO - 2017-07-21 14:12:11 --> Controller Class Initialized
INFO - 2017-07-21 14:12:11 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:11 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:11 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:11 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:11 --> Model Class Initialized
INFO - 2017-07-21 14:12:11 --> Model Class Initialized
INFO - 2017-07-21 14:12:19 --> Config Class Initialized
INFO - 2017-07-21 14:12:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:19 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:19 --> URI Class Initialized
INFO - 2017-07-21 14:12:19 --> Router Class Initialized
INFO - 2017-07-21 14:12:19 --> Output Class Initialized
INFO - 2017-07-21 14:12:19 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:19 --> Input Class Initialized
INFO - 2017-07-21 14:12:19 --> Language Class Initialized
INFO - 2017-07-21 14:12:19 --> Loader Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:19 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:19 --> Email Class Initialized
INFO - 2017-07-21 14:12:19 --> Controller Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:19 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:19 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:19 --> Model Class Initialized
INFO - 2017-07-21 14:12:19 --> Model Class Initialized
INFO - 2017-07-21 14:12:19 --> Config Class Initialized
INFO - 2017-07-21 14:12:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:19 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:19 --> URI Class Initialized
INFO - 2017-07-21 14:12:19 --> Router Class Initialized
INFO - 2017-07-21 14:12:19 --> Output Class Initialized
INFO - 2017-07-21 14:12:19 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:19 --> Input Class Initialized
INFO - 2017-07-21 14:12:19 --> Language Class Initialized
INFO - 2017-07-21 14:12:19 --> Loader Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:19 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:19 --> Email Class Initialized
INFO - 2017-07-21 14:12:19 --> Controller Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:19 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:19 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:19 --> Model Class Initialized
INFO - 2017-07-21 14:12:19 --> Model Class Initialized
INFO - 2017-07-21 14:12:19 --> Config Class Initialized
INFO - 2017-07-21 14:12:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:19 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:19 --> URI Class Initialized
INFO - 2017-07-21 14:12:19 --> Router Class Initialized
INFO - 2017-07-21 14:12:19 --> Output Class Initialized
INFO - 2017-07-21 14:12:19 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:19 --> Input Class Initialized
INFO - 2017-07-21 14:12:19 --> Language Class Initialized
INFO - 2017-07-21 14:12:19 --> Loader Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:19 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:19 --> Email Class Initialized
INFO - 2017-07-21 14:12:19 --> Controller Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:19 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:19 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:19 --> Model Class Initialized
INFO - 2017-07-21 14:12:19 --> Model Class Initialized
INFO - 2017-07-21 14:12:20 --> Config Class Initialized
INFO - 2017-07-21 14:12:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:20 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:20 --> URI Class Initialized
INFO - 2017-07-21 14:12:20 --> Router Class Initialized
INFO - 2017-07-21 14:12:20 --> Output Class Initialized
INFO - 2017-07-21 14:12:20 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:20 --> Input Class Initialized
INFO - 2017-07-21 14:12:20 --> Language Class Initialized
INFO - 2017-07-21 14:12:20 --> Loader Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:20 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:20 --> Email Class Initialized
INFO - 2017-07-21 14:12:20 --> Controller Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:20 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:20 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:20 --> Model Class Initialized
INFO - 2017-07-21 14:12:20 --> Model Class Initialized
INFO - 2017-07-21 14:12:20 --> Config Class Initialized
INFO - 2017-07-21 14:12:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:20 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:20 --> URI Class Initialized
INFO - 2017-07-21 14:12:20 --> Router Class Initialized
INFO - 2017-07-21 14:12:20 --> Output Class Initialized
INFO - 2017-07-21 14:12:20 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:20 --> Input Class Initialized
INFO - 2017-07-21 14:12:20 --> Language Class Initialized
INFO - 2017-07-21 14:12:20 --> Loader Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:20 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:20 --> Email Class Initialized
INFO - 2017-07-21 14:12:20 --> Controller Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:20 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:20 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:20 --> Model Class Initialized
INFO - 2017-07-21 14:12:20 --> Model Class Initialized
INFO - 2017-07-21 14:12:20 --> Config Class Initialized
INFO - 2017-07-21 14:12:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:20 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:20 --> URI Class Initialized
INFO - 2017-07-21 14:12:20 --> Router Class Initialized
INFO - 2017-07-21 14:12:20 --> Output Class Initialized
INFO - 2017-07-21 14:12:20 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:20 --> Input Class Initialized
INFO - 2017-07-21 14:12:20 --> Language Class Initialized
INFO - 2017-07-21 14:12:20 --> Loader Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:20 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:20 --> Email Class Initialized
INFO - 2017-07-21 14:12:20 --> Controller Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:20 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:20 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:20 --> Model Class Initialized
INFO - 2017-07-21 14:12:20 --> Model Class Initialized
INFO - 2017-07-21 14:12:30 --> Config Class Initialized
INFO - 2017-07-21 14:12:30 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:12:30 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:12:30 --> Utf8 Class Initialized
INFO - 2017-07-21 14:12:30 --> URI Class Initialized
INFO - 2017-07-21 14:12:30 --> Router Class Initialized
INFO - 2017-07-21 14:12:30 --> Output Class Initialized
INFO - 2017-07-21 14:12:30 --> Security Class Initialized
DEBUG - 2017-07-21 14:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:12:30 --> Input Class Initialized
INFO - 2017-07-21 14:12:30 --> Language Class Initialized
INFO - 2017-07-21 14:12:30 --> Loader Class Initialized
INFO - 2017-07-21 14:12:30 --> Helper loaded: common_helper
INFO - 2017-07-21 14:12:30 --> Database Driver Class Initialized
INFO - 2017-07-21 14:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:12:30 --> Email Class Initialized
INFO - 2017-07-21 14:12:30 --> Controller Class Initialized
INFO - 2017-07-21 14:12:30 --> Helper loaded: form_helper
INFO - 2017-07-21 14:12:30 --> Form Validation Class Initialized
INFO - 2017-07-21 14:12:30 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:12:30 --> Helper loaded: url_helper
INFO - 2017-07-21 14:12:30 --> Model Class Initialized
INFO - 2017-07-21 14:12:30 --> Model Class Initialized
INFO - 2017-07-21 14:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:12:30 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:12:30 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:12:30 --> Trying to get property of non-object
ERROR - 2017-07-21 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:12:30 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:12:30 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:12:30 --> Trying to get property of non-object
ERROR - 2017-07-21 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:12:30 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:12:30 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:12:30 --> Trying to get property of non-object
ERROR - 2017-07-21 14:12:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:12:30 --> Final output sent to browser
DEBUG - 2017-07-21 14:12:30 --> Total execution time: 0.0565
INFO - 2017-07-21 14:13:20 --> Config Class Initialized
INFO - 2017-07-21 14:13:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:13:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:13:20 --> Utf8 Class Initialized
INFO - 2017-07-21 14:13:20 --> URI Class Initialized
INFO - 2017-07-21 14:13:20 --> Router Class Initialized
INFO - 2017-07-21 14:13:20 --> Output Class Initialized
INFO - 2017-07-21 14:13:20 --> Security Class Initialized
DEBUG - 2017-07-21 14:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:13:20 --> Input Class Initialized
INFO - 2017-07-21 14:13:20 --> Language Class Initialized
INFO - 2017-07-21 14:13:20 --> Loader Class Initialized
INFO - 2017-07-21 14:13:20 --> Helper loaded: common_helper
INFO - 2017-07-21 14:13:20 --> Database Driver Class Initialized
INFO - 2017-07-21 14:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:13:20 --> Email Class Initialized
INFO - 2017-07-21 14:13:20 --> Controller Class Initialized
INFO - 2017-07-21 14:13:20 --> Helper loaded: form_helper
INFO - 2017-07-21 14:13:20 --> Form Validation Class Initialized
INFO - 2017-07-21 14:13:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:13:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:13:20 --> Helper loaded: url_helper
INFO - 2017-07-21 14:13:20 --> Model Class Initialized
INFO - 2017-07-21 14:13:20 --> Model Class Initialized
INFO - 2017-07-21 14:13:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:13:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:13:20 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:13:20 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:13:20 --> Trying to get property of non-object
ERROR - 2017-07-21 14:13:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:13:20 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:13:20 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:13:20 --> Trying to get property of non-object
ERROR - 2017-07-21 14:13:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:13:20 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:13:20 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:13:20 --> Trying to get property of non-object
ERROR - 2017-07-21 14:13:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:13:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:13:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:13:20 --> Final output sent to browser
DEBUG - 2017-07-21 14:13:20 --> Total execution time: 0.0523
INFO - 2017-07-21 14:15:49 --> Config Class Initialized
INFO - 2017-07-21 14:15:49 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:15:49 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:15:49 --> Utf8 Class Initialized
INFO - 2017-07-21 14:15:49 --> URI Class Initialized
INFO - 2017-07-21 14:15:49 --> Router Class Initialized
INFO - 2017-07-21 14:15:49 --> Output Class Initialized
INFO - 2017-07-21 14:15:49 --> Security Class Initialized
DEBUG - 2017-07-21 14:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:15:49 --> Input Class Initialized
INFO - 2017-07-21 14:15:49 --> Language Class Initialized
INFO - 2017-07-21 14:15:49 --> Loader Class Initialized
INFO - 2017-07-21 14:15:49 --> Helper loaded: common_helper
INFO - 2017-07-21 14:15:49 --> Database Driver Class Initialized
INFO - 2017-07-21 14:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:15:49 --> Email Class Initialized
INFO - 2017-07-21 14:15:49 --> Controller Class Initialized
INFO - 2017-07-21 14:15:49 --> Helper loaded: form_helper
INFO - 2017-07-21 14:15:49 --> Form Validation Class Initialized
INFO - 2017-07-21 14:15:49 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:15:49 --> Helper loaded: url_helper
INFO - 2017-07-21 14:15:49 --> Model Class Initialized
INFO - 2017-07-21 14:15:49 --> Model Class Initialized
INFO - 2017-07-21 14:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:15:49 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:15:49 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:15:49 --> Trying to get property of non-object
ERROR - 2017-07-21 14:15:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:15:49 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:15:49 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:15:49 --> Trying to get property of non-object
ERROR - 2017-07-21 14:15:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:15:49 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:15:49 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:15:49 --> Trying to get property of non-object
ERROR - 2017-07-21 14:15:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:15:49 --> Final output sent to browser
DEBUG - 2017-07-21 14:15:49 --> Total execution time: 0.0768
INFO - 2017-07-21 14:16:16 --> Config Class Initialized
INFO - 2017-07-21 14:16:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:16 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:16 --> URI Class Initialized
INFO - 2017-07-21 14:16:16 --> Router Class Initialized
INFO - 2017-07-21 14:16:16 --> Output Class Initialized
INFO - 2017-07-21 14:16:16 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:16 --> Input Class Initialized
INFO - 2017-07-21 14:16:16 --> Language Class Initialized
INFO - 2017-07-21 14:16:16 --> Loader Class Initialized
INFO - 2017-07-21 14:16:16 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:16 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:16 --> Email Class Initialized
INFO - 2017-07-21 14:16:16 --> Controller Class Initialized
INFO - 2017-07-21 14:16:16 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:16 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:16 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:16 --> Model Class Initialized
INFO - 2017-07-21 14:16:16 --> Model Class Initialized
INFO - 2017-07-21 14:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:16:16 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:16:16 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:16 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:16 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:16:16 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:16 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:16 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:16:16 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:16:16 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:16 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:16 --> Total execution time: 0.0546
INFO - 2017-07-21 14:16:31 --> Config Class Initialized
INFO - 2017-07-21 14:16:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:31 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:31 --> URI Class Initialized
INFO - 2017-07-21 14:16:31 --> Router Class Initialized
INFO - 2017-07-21 14:16:31 --> Output Class Initialized
INFO - 2017-07-21 14:16:31 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:31 --> Input Class Initialized
INFO - 2017-07-21 14:16:31 --> Language Class Initialized
INFO - 2017-07-21 14:16:31 --> Loader Class Initialized
INFO - 2017-07-21 14:16:31 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:31 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:31 --> Email Class Initialized
INFO - 2017-07-21 14:16:31 --> Controller Class Initialized
INFO - 2017-07-21 14:16:31 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:31 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:31 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:31 --> Model Class Initialized
INFO - 2017-07-21 14:16:31 --> Model Class Initialized
INFO - 2017-07-21 14:16:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:16:31 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:16:31 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:31 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:31 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:16:31 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:31 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:31 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:16:31 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:16:31 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:16:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:16:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:31 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:31 --> Total execution time: 0.0626
INFO - 2017-07-21 14:16:38 --> Config Class Initialized
INFO - 2017-07-21 14:16:38 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:38 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:38 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:38 --> URI Class Initialized
INFO - 2017-07-21 14:16:38 --> Router Class Initialized
INFO - 2017-07-21 14:16:38 --> Output Class Initialized
INFO - 2017-07-21 14:16:38 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:38 --> Input Class Initialized
INFO - 2017-07-21 14:16:38 --> Language Class Initialized
INFO - 2017-07-21 14:16:38 --> Loader Class Initialized
INFO - 2017-07-21 14:16:38 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:38 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:38 --> Email Class Initialized
INFO - 2017-07-21 14:16:38 --> Controller Class Initialized
INFO - 2017-07-21 14:16:38 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:38 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:38 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:38 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:38 --> Model Class Initialized
INFO - 2017-07-21 14:16:38 --> Model Class Initialized
INFO - 2017-07-21 14:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:16:38 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:16:38 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:38 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:38 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:16:38 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:38 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:38 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:16:38 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:16:38 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:38 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:38 --> Total execution time: 0.0549
INFO - 2017-07-21 14:16:40 --> Config Class Initialized
INFO - 2017-07-21 14:16:40 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:40 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:40 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:40 --> URI Class Initialized
INFO - 2017-07-21 14:16:40 --> Router Class Initialized
INFO - 2017-07-21 14:16:40 --> Output Class Initialized
INFO - 2017-07-21 14:16:40 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:40 --> Input Class Initialized
INFO - 2017-07-21 14:16:40 --> Language Class Initialized
INFO - 2017-07-21 14:16:40 --> Loader Class Initialized
INFO - 2017-07-21 14:16:40 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:40 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:40 --> Email Class Initialized
INFO - 2017-07-21 14:16:40 --> Controller Class Initialized
INFO - 2017-07-21 14:16:40 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:40 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:40 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:40 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:40 --> Model Class Initialized
INFO - 2017-07-21 14:16:40 --> Model Class Initialized
INFO - 2017-07-21 14:16:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:16:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2017-07-21 14:16:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:16:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:40 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:40 --> Total execution time: 0.0465
INFO - 2017-07-21 14:16:45 --> Config Class Initialized
INFO - 2017-07-21 14:16:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:45 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:45 --> URI Class Initialized
INFO - 2017-07-21 14:16:45 --> Router Class Initialized
INFO - 2017-07-21 14:16:45 --> Output Class Initialized
INFO - 2017-07-21 14:16:45 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:45 --> Input Class Initialized
INFO - 2017-07-21 14:16:45 --> Language Class Initialized
INFO - 2017-07-21 14:16:45 --> Loader Class Initialized
INFO - 2017-07-21 14:16:45 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:45 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:45 --> Email Class Initialized
INFO - 2017-07-21 14:16:45 --> Controller Class Initialized
INFO - 2017-07-21 14:16:45 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:45 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:45 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:45 --> Model Class Initialized
INFO - 2017-07-21 14:16:45 --> Model Class Initialized
DEBUG - 2017-07-21 14:16:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:16:45 --> Config Class Initialized
INFO - 2017-07-21 14:16:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:45 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:45 --> URI Class Initialized
INFO - 2017-07-21 14:16:45 --> Router Class Initialized
INFO - 2017-07-21 14:16:45 --> Output Class Initialized
INFO - 2017-07-21 14:16:45 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:45 --> Input Class Initialized
INFO - 2017-07-21 14:16:45 --> Language Class Initialized
INFO - 2017-07-21 14:16:45 --> Loader Class Initialized
INFO - 2017-07-21 14:16:45 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:45 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:45 --> Email Class Initialized
INFO - 2017-07-21 14:16:45 --> Controller Class Initialized
INFO - 2017-07-21 14:16:45 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:45 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:45 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:45 --> Model Class Initialized
INFO - 2017-07-21 14:16:45 --> Model Class Initialized
INFO - 2017-07-21 14:16:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:16:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2017-07-21 14:16:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:16:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:45 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:45 --> Total execution time: 0.0544
INFO - 2017-07-21 14:16:52 --> Config Class Initialized
INFO - 2017-07-21 14:16:52 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:52 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:52 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:52 --> URI Class Initialized
INFO - 2017-07-21 14:16:52 --> Router Class Initialized
INFO - 2017-07-21 14:16:52 --> Output Class Initialized
INFO - 2017-07-21 14:16:52 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:52 --> Input Class Initialized
INFO - 2017-07-21 14:16:52 --> Language Class Initialized
INFO - 2017-07-21 14:16:52 --> Loader Class Initialized
INFO - 2017-07-21 14:16:52 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:52 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:52 --> Email Class Initialized
INFO - 2017-07-21 14:16:52 --> Controller Class Initialized
INFO - 2017-07-21 14:16:52 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:52 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:52 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:52 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:52 --> Model Class Initialized
INFO - 2017-07-21 14:16:52 --> Model Class Initialized
DEBUG - 2017-07-21 14:16:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:16:52 --> Config Class Initialized
INFO - 2017-07-21 14:16:52 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:52 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:52 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:52 --> URI Class Initialized
INFO - 2017-07-21 14:16:52 --> Router Class Initialized
INFO - 2017-07-21 14:16:52 --> Output Class Initialized
INFO - 2017-07-21 14:16:52 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:52 --> Input Class Initialized
INFO - 2017-07-21 14:16:52 --> Language Class Initialized
INFO - 2017-07-21 14:16:52 --> Loader Class Initialized
INFO - 2017-07-21 14:16:52 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:52 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:52 --> Email Class Initialized
INFO - 2017-07-21 14:16:52 --> Controller Class Initialized
INFO - 2017-07-21 14:16:52 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:52 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:52 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:52 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:52 --> Model Class Initialized
INFO - 2017-07-21 14:16:52 --> Model Class Initialized
INFO - 2017-07-21 14:16:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:16:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2017-07-21 14:16:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:16:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:52 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:52 --> Total execution time: 0.0491
INFO - 2017-07-21 14:16:56 --> Config Class Initialized
INFO - 2017-07-21 14:16:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:56 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:56 --> URI Class Initialized
INFO - 2017-07-21 14:16:56 --> Router Class Initialized
INFO - 2017-07-21 14:16:56 --> Output Class Initialized
INFO - 2017-07-21 14:16:56 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:56 --> Input Class Initialized
INFO - 2017-07-21 14:16:56 --> Language Class Initialized
INFO - 2017-07-21 14:16:56 --> Loader Class Initialized
INFO - 2017-07-21 14:16:56 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:56 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:56 --> Email Class Initialized
INFO - 2017-07-21 14:16:56 --> Controller Class Initialized
INFO - 2017-07-21 14:16:56 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:56 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:56 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:56 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:56 --> Model Class Initialized
INFO - 2017-07-21 14:16:56 --> Model Class Initialized
INFO - 2017-07-21 14:16:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:16:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:16:56 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:16:56 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:56 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:16:56 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:16:56 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:56 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:16:56 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:16:56 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:16:56 --> Trying to get property of non-object
ERROR - 2017-07-21 14:16:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:16:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:16:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:16:56 --> Final output sent to browser
DEBUG - 2017-07-21 14:16:56 --> Total execution time: 0.0508
INFO - 2017-07-21 14:16:59 --> Config Class Initialized
INFO - 2017-07-21 14:16:59 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:59 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:59 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:59 --> URI Class Initialized
INFO - 2017-07-21 14:16:59 --> Router Class Initialized
INFO - 2017-07-21 14:16:59 --> Output Class Initialized
INFO - 2017-07-21 14:16:59 --> Security Class Initialized
DEBUG - 2017-07-21 14:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:16:59 --> Input Class Initialized
INFO - 2017-07-21 14:16:59 --> Language Class Initialized
INFO - 2017-07-21 14:16:59 --> Loader Class Initialized
INFO - 2017-07-21 14:16:59 --> Helper loaded: common_helper
INFO - 2017-07-21 14:16:59 --> Database Driver Class Initialized
INFO - 2017-07-21 14:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:16:59 --> Email Class Initialized
INFO - 2017-07-21 14:16:59 --> Controller Class Initialized
INFO - 2017-07-21 14:16:59 --> Helper loaded: form_helper
INFO - 2017-07-21 14:16:59 --> Form Validation Class Initialized
INFO - 2017-07-21 14:16:59 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:16:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:16:59 --> Helper loaded: url_helper
INFO - 2017-07-21 14:16:59 --> Model Class Initialized
INFO - 2017-07-21 14:16:59 --> Model Class Initialized
INFO - 2017-07-21 14:16:59 --> Config Class Initialized
INFO - 2017-07-21 14:16:59 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:16:59 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:16:59 --> Utf8 Class Initialized
INFO - 2017-07-21 14:16:59 --> URI Class Initialized
DEBUG - 2017-07-21 14:17:00 --> No URI present. Default controller set.
INFO - 2017-07-21 14:17:00 --> Router Class Initialized
INFO - 2017-07-21 14:17:00 --> Output Class Initialized
INFO - 2017-07-21 14:17:00 --> Security Class Initialized
DEBUG - 2017-07-21 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:17:00 --> Input Class Initialized
INFO - 2017-07-21 14:17:00 --> Language Class Initialized
INFO - 2017-07-21 14:17:00 --> Loader Class Initialized
INFO - 2017-07-21 14:17:00 --> Helper loaded: common_helper
INFO - 2017-07-21 14:17:00 --> Database Driver Class Initialized
INFO - 2017-07-21 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:17:00 --> Email Class Initialized
INFO - 2017-07-21 14:17:00 --> Controller Class Initialized
INFO - 2017-07-21 14:17:00 --> Helper loaded: form_helper
INFO - 2017-07-21 14:17:00 --> Form Validation Class Initialized
INFO - 2017-07-21 14:17:00 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:17:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:00 --> Helper loaded: url_helper
INFO - 2017-07-21 14:17:00 --> Model Class Initialized
INFO - 2017-07-21 14:17:00 --> Model Class Initialized
INFO - 2017-07-21 14:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:17:00 --> Final output sent to browser
DEBUG - 2017-07-21 14:17:00 --> Total execution time: 0.0484
INFO - 2017-07-21 14:17:01 --> Config Class Initialized
INFO - 2017-07-21 14:17:01 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:17:01 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:17:01 --> Utf8 Class Initialized
INFO - 2017-07-21 14:17:01 --> URI Class Initialized
DEBUG - 2017-07-21 14:17:01 --> No URI present. Default controller set.
INFO - 2017-07-21 14:17:01 --> Router Class Initialized
INFO - 2017-07-21 14:17:01 --> Output Class Initialized
INFO - 2017-07-21 14:17:01 --> Security Class Initialized
DEBUG - 2017-07-21 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:17:01 --> Input Class Initialized
INFO - 2017-07-21 14:17:01 --> Language Class Initialized
INFO - 2017-07-21 14:17:01 --> Loader Class Initialized
INFO - 2017-07-21 14:17:01 --> Helper loaded: common_helper
INFO - 2017-07-21 14:17:01 --> Database Driver Class Initialized
INFO - 2017-07-21 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:17:01 --> Email Class Initialized
INFO - 2017-07-21 14:17:01 --> Controller Class Initialized
INFO - 2017-07-21 14:17:01 --> Helper loaded: form_helper
INFO - 2017-07-21 14:17:01 --> Form Validation Class Initialized
INFO - 2017-07-21 14:17:01 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:01 --> Helper loaded: url_helper
INFO - 2017-07-21 14:17:01 --> Model Class Initialized
INFO - 2017-07-21 14:17:01 --> Model Class Initialized
DEBUG - 2017-07-21 14:17:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 14:17:01 --> Query error: Unknown column 'address' in 'field list' - Invalid query: SELECT `userId`, `name`, `emailAddress`, `phoneNumber`, `address`, `isActive`, `roleId`
FROM `users`
WHERE `isActive` = 1
AND `isDeleted` =0
AND `roleID` = 2
AND (`phoneNumber` = '1111111111' OR `name` = '1111111111')
AND `password` = 'e10adc3949ba59abbe56e057f20f883e'
 LIMIT 1
ERROR - 2017-07-21 14:17:01 --> Call to undefined method CI_DB_mysqli_driver::_error_message()
ERROR - 2017-07-21 14:17:01 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::_error_message() C:\xampp\htdocs\FlickNews\admin\application\core\Healthmodel.php 32
INFO - 2017-07-21 14:17:20 --> Config Class Initialized
INFO - 2017-07-21 14:17:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:17:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:17:20 --> Utf8 Class Initialized
INFO - 2017-07-21 14:17:20 --> URI Class Initialized
DEBUG - 2017-07-21 14:17:20 --> No URI present. Default controller set.
INFO - 2017-07-21 14:17:20 --> Router Class Initialized
INFO - 2017-07-21 14:17:20 --> Output Class Initialized
INFO - 2017-07-21 14:17:20 --> Security Class Initialized
DEBUG - 2017-07-21 14:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:17:20 --> Input Class Initialized
INFO - 2017-07-21 14:17:20 --> Language Class Initialized
INFO - 2017-07-21 14:17:20 --> Loader Class Initialized
INFO - 2017-07-21 14:17:20 --> Helper loaded: common_helper
INFO - 2017-07-21 14:17:20 --> Database Driver Class Initialized
INFO - 2017-07-21 14:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:17:20 --> Email Class Initialized
INFO - 2017-07-21 14:17:20 --> Controller Class Initialized
INFO - 2017-07-21 14:17:20 --> Helper loaded: form_helper
INFO - 2017-07-21 14:17:20 --> Form Validation Class Initialized
INFO - 2017-07-21 14:17:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:17:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:20 --> Helper loaded: url_helper
INFO - 2017-07-21 14:17:20 --> Model Class Initialized
INFO - 2017-07-21 14:17:20 --> Model Class Initialized
DEBUG - 2017-07-21 14:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:17:20 --> Final output sent to browser
DEBUG - 2017-07-21 14:17:20 --> Total execution time: 0.0476
INFO - 2017-07-21 14:17:21 --> Config Class Initialized
INFO - 2017-07-21 14:17:21 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:17:21 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:17:21 --> Utf8 Class Initialized
INFO - 2017-07-21 14:17:21 --> URI Class Initialized
DEBUG - 2017-07-21 14:17:21 --> No URI present. Default controller set.
INFO - 2017-07-21 14:17:21 --> Router Class Initialized
INFO - 2017-07-21 14:17:21 --> Output Class Initialized
INFO - 2017-07-21 14:17:21 --> Security Class Initialized
DEBUG - 2017-07-21 14:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:17:21 --> Input Class Initialized
INFO - 2017-07-21 14:17:21 --> Language Class Initialized
INFO - 2017-07-21 14:17:21 --> Loader Class Initialized
INFO - 2017-07-21 14:17:21 --> Helper loaded: common_helper
INFO - 2017-07-21 14:17:21 --> Database Driver Class Initialized
INFO - 2017-07-21 14:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:17:21 --> Email Class Initialized
INFO - 2017-07-21 14:17:21 --> Controller Class Initialized
INFO - 2017-07-21 14:17:21 --> Helper loaded: form_helper
INFO - 2017-07-21 14:17:21 --> Form Validation Class Initialized
INFO - 2017-07-21 14:17:21 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:21 --> Helper loaded: url_helper
INFO - 2017-07-21 14:17:21 --> Model Class Initialized
INFO - 2017-07-21 14:17:21 --> Model Class Initialized
DEBUG - 2017-07-21 14:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:17:21 --> Final output sent to browser
DEBUG - 2017-07-21 14:17:21 --> Total execution time: 0.0514
INFO - 2017-07-21 14:17:23 --> Config Class Initialized
INFO - 2017-07-21 14:17:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:17:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:17:23 --> Utf8 Class Initialized
INFO - 2017-07-21 14:17:23 --> URI Class Initialized
DEBUG - 2017-07-21 14:17:23 --> No URI present. Default controller set.
INFO - 2017-07-21 14:17:23 --> Router Class Initialized
INFO - 2017-07-21 14:17:23 --> Output Class Initialized
INFO - 2017-07-21 14:17:23 --> Security Class Initialized
DEBUG - 2017-07-21 14:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:17:23 --> Input Class Initialized
INFO - 2017-07-21 14:17:23 --> Language Class Initialized
INFO - 2017-07-21 14:17:23 --> Loader Class Initialized
INFO - 2017-07-21 14:17:23 --> Helper loaded: common_helper
INFO - 2017-07-21 14:17:23 --> Database Driver Class Initialized
INFO - 2017-07-21 14:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:17:23 --> Email Class Initialized
INFO - 2017-07-21 14:17:23 --> Controller Class Initialized
INFO - 2017-07-21 14:17:23 --> Helper loaded: form_helper
INFO - 2017-07-21 14:17:23 --> Form Validation Class Initialized
INFO - 2017-07-21 14:17:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:17:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:23 --> Helper loaded: url_helper
INFO - 2017-07-21 14:17:23 --> Model Class Initialized
INFO - 2017-07-21 14:17:23 --> Model Class Initialized
DEBUG - 2017-07-21 14:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:17:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:17:23 --> Final output sent to browser
DEBUG - 2017-07-21 14:17:23 --> Total execution time: 0.0499
INFO - 2017-07-21 14:18:36 --> Config Class Initialized
INFO - 2017-07-21 14:18:36 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:18:36 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:18:36 --> Utf8 Class Initialized
INFO - 2017-07-21 14:18:36 --> URI Class Initialized
DEBUG - 2017-07-21 14:18:36 --> No URI present. Default controller set.
INFO - 2017-07-21 14:18:36 --> Router Class Initialized
INFO - 2017-07-21 14:18:36 --> Output Class Initialized
INFO - 2017-07-21 14:18:36 --> Security Class Initialized
DEBUG - 2017-07-21 14:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:18:36 --> Input Class Initialized
INFO - 2017-07-21 14:18:36 --> Language Class Initialized
INFO - 2017-07-21 14:18:36 --> Loader Class Initialized
INFO - 2017-07-21 14:18:36 --> Helper loaded: common_helper
INFO - 2017-07-21 14:18:36 --> Database Driver Class Initialized
INFO - 2017-07-21 14:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:18:36 --> Email Class Initialized
INFO - 2017-07-21 14:18:36 --> Controller Class Initialized
INFO - 2017-07-21 14:18:36 --> Helper loaded: form_helper
INFO - 2017-07-21 14:18:36 --> Form Validation Class Initialized
INFO - 2017-07-21 14:18:36 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:18:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:18:36 --> Helper loaded: url_helper
INFO - 2017-07-21 14:18:36 --> Model Class Initialized
INFO - 2017-07-21 14:18:36 --> Model Class Initialized
DEBUG - 2017-07-21 14:18:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:18:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:19:39 --> Config Class Initialized
INFO - 2017-07-21 14:19:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:19:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:19:39 --> Utf8 Class Initialized
INFO - 2017-07-21 14:19:39 --> URI Class Initialized
DEBUG - 2017-07-21 14:19:39 --> No URI present. Default controller set.
INFO - 2017-07-21 14:19:39 --> Router Class Initialized
INFO - 2017-07-21 14:19:39 --> Output Class Initialized
INFO - 2017-07-21 14:19:39 --> Security Class Initialized
DEBUG - 2017-07-21 14:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:19:39 --> Input Class Initialized
INFO - 2017-07-21 14:19:39 --> Language Class Initialized
INFO - 2017-07-21 14:19:39 --> Loader Class Initialized
INFO - 2017-07-21 14:19:39 --> Helper loaded: common_helper
INFO - 2017-07-21 14:19:39 --> Database Driver Class Initialized
INFO - 2017-07-21 14:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:19:39 --> Email Class Initialized
INFO - 2017-07-21 14:19:39 --> Controller Class Initialized
INFO - 2017-07-21 14:19:39 --> Helper loaded: form_helper
INFO - 2017-07-21 14:19:39 --> Form Validation Class Initialized
INFO - 2017-07-21 14:19:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:19:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:19:39 --> Helper loaded: url_helper
INFO - 2017-07-21 14:19:39 --> Model Class Initialized
INFO - 2017-07-21 14:19:39 --> Model Class Initialized
DEBUG - 2017-07-21 14:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:19:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:19:39 --> Final output sent to browser
DEBUG - 2017-07-21 14:19:39 --> Total execution time: 0.0469
INFO - 2017-07-21 14:20:32 --> Config Class Initialized
INFO - 2017-07-21 14:20:32 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:20:32 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:20:32 --> Utf8 Class Initialized
INFO - 2017-07-21 14:20:32 --> URI Class Initialized
DEBUG - 2017-07-21 14:20:32 --> No URI present. Default controller set.
INFO - 2017-07-21 14:20:32 --> Router Class Initialized
INFO - 2017-07-21 14:20:32 --> Output Class Initialized
INFO - 2017-07-21 14:20:32 --> Security Class Initialized
DEBUG - 2017-07-21 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:20:32 --> Input Class Initialized
INFO - 2017-07-21 14:20:32 --> Language Class Initialized
INFO - 2017-07-21 14:20:32 --> Loader Class Initialized
INFO - 2017-07-21 14:20:32 --> Helper loaded: common_helper
INFO - 2017-07-21 14:20:32 --> Database Driver Class Initialized
INFO - 2017-07-21 14:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:20:32 --> Email Class Initialized
INFO - 2017-07-21 14:20:32 --> Controller Class Initialized
INFO - 2017-07-21 14:20:32 --> Helper loaded: form_helper
INFO - 2017-07-21 14:20:32 --> Form Validation Class Initialized
INFO - 2017-07-21 14:20:32 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:20:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:20:32 --> Helper loaded: url_helper
INFO - 2017-07-21 14:20:32 --> Model Class Initialized
INFO - 2017-07-21 14:20:32 --> Model Class Initialized
DEBUG - 2017-07-21 14:20:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:20:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:20:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:20:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:20:32 --> Final output sent to browser
DEBUG - 2017-07-21 14:20:32 --> Total execution time: 0.0533
INFO - 2017-07-21 14:20:33 --> Config Class Initialized
INFO - 2017-07-21 14:20:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:20:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:20:33 --> Utf8 Class Initialized
INFO - 2017-07-21 14:20:33 --> URI Class Initialized
DEBUG - 2017-07-21 14:20:33 --> No URI present. Default controller set.
INFO - 2017-07-21 14:20:33 --> Router Class Initialized
INFO - 2017-07-21 14:20:33 --> Output Class Initialized
INFO - 2017-07-21 14:20:33 --> Security Class Initialized
DEBUG - 2017-07-21 14:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:20:33 --> Input Class Initialized
INFO - 2017-07-21 14:20:33 --> Language Class Initialized
INFO - 2017-07-21 14:20:33 --> Loader Class Initialized
INFO - 2017-07-21 14:20:33 --> Helper loaded: common_helper
INFO - 2017-07-21 14:20:33 --> Database Driver Class Initialized
INFO - 2017-07-21 14:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:20:33 --> Email Class Initialized
INFO - 2017-07-21 14:20:33 --> Controller Class Initialized
INFO - 2017-07-21 14:20:33 --> Helper loaded: form_helper
INFO - 2017-07-21 14:20:33 --> Form Validation Class Initialized
INFO - 2017-07-21 14:20:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:20:33 --> Helper loaded: url_helper
INFO - 2017-07-21 14:20:33 --> Model Class Initialized
INFO - 2017-07-21 14:20:33 --> Model Class Initialized
DEBUG - 2017-07-21 14:20:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:20:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:20:33 --> Final output sent to browser
DEBUG - 2017-07-21 14:20:33 --> Total execution time: 0.0543
INFO - 2017-07-21 14:20:35 --> Config Class Initialized
INFO - 2017-07-21 14:20:35 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:20:35 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:20:35 --> Utf8 Class Initialized
INFO - 2017-07-21 14:20:35 --> URI Class Initialized
DEBUG - 2017-07-21 14:20:35 --> No URI present. Default controller set.
INFO - 2017-07-21 14:20:35 --> Router Class Initialized
INFO - 2017-07-21 14:20:35 --> Output Class Initialized
INFO - 2017-07-21 14:20:35 --> Security Class Initialized
DEBUG - 2017-07-21 14:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:20:35 --> Input Class Initialized
INFO - 2017-07-21 14:20:35 --> Language Class Initialized
INFO - 2017-07-21 14:20:35 --> Loader Class Initialized
INFO - 2017-07-21 14:20:35 --> Helper loaded: common_helper
INFO - 2017-07-21 14:20:35 --> Database Driver Class Initialized
INFO - 2017-07-21 14:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:20:35 --> Email Class Initialized
INFO - 2017-07-21 14:20:35 --> Controller Class Initialized
INFO - 2017-07-21 14:20:35 --> Helper loaded: form_helper
INFO - 2017-07-21 14:20:35 --> Form Validation Class Initialized
INFO - 2017-07-21 14:20:35 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:20:35 --> Helper loaded: url_helper
INFO - 2017-07-21 14:20:35 --> Model Class Initialized
INFO - 2017-07-21 14:20:35 --> Model Class Initialized
DEBUG - 2017-07-21 14:20:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:20:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:20:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:20:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:20:35 --> Final output sent to browser
DEBUG - 2017-07-21 14:20:35 --> Total execution time: 0.0543
INFO - 2017-07-21 14:21:10 --> Config Class Initialized
INFO - 2017-07-21 14:21:10 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:10 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:10 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:10 --> URI Class Initialized
DEBUG - 2017-07-21 14:21:10 --> No URI present. Default controller set.
INFO - 2017-07-21 14:21:10 --> Router Class Initialized
INFO - 2017-07-21 14:21:10 --> Output Class Initialized
INFO - 2017-07-21 14:21:10 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:10 --> Input Class Initialized
INFO - 2017-07-21 14:21:10 --> Language Class Initialized
INFO - 2017-07-21 14:21:10 --> Loader Class Initialized
INFO - 2017-07-21 14:21:10 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:10 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:10 --> Email Class Initialized
INFO - 2017-07-21 14:21:10 --> Controller Class Initialized
INFO - 2017-07-21 14:21:10 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:10 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:10 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:10 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:10 --> Model Class Initialized
INFO - 2017-07-21 14:21:10 --> Model Class Initialized
DEBUG - 2017-07-21 14:21:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:21:10 --> Config Class Initialized
INFO - 2017-07-21 14:21:10 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:10 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:10 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:10 --> URI Class Initialized
INFO - 2017-07-21 14:21:10 --> Router Class Initialized
INFO - 2017-07-21 14:21:10 --> Output Class Initialized
INFO - 2017-07-21 14:21:10 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:10 --> Input Class Initialized
INFO - 2017-07-21 14:21:10 --> Language Class Initialized
INFO - 2017-07-21 14:21:10 --> Loader Class Initialized
INFO - 2017-07-21 14:21:10 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:10 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:10 --> Email Class Initialized
INFO - 2017-07-21 14:21:10 --> Controller Class Initialized
INFO - 2017-07-21 14:21:10 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:10 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:10 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:10 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:10 --> Model Class Initialized
INFO - 2017-07-21 14:21:10 --> Model Class Initialized
INFO - 2017-07-21 14:21:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:10 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:10 --> Total execution time: 0.0515
INFO - 2017-07-21 14:21:13 --> Config Class Initialized
INFO - 2017-07-21 14:21:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:13 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:13 --> URI Class Initialized
INFO - 2017-07-21 14:21:13 --> Router Class Initialized
INFO - 2017-07-21 14:21:13 --> Output Class Initialized
INFO - 2017-07-21 14:21:13 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:13 --> Input Class Initialized
INFO - 2017-07-21 14:21:13 --> Language Class Initialized
INFO - 2017-07-21 14:21:13 --> Loader Class Initialized
INFO - 2017-07-21 14:21:13 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:13 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:13 --> Email Class Initialized
INFO - 2017-07-21 14:21:13 --> Controller Class Initialized
INFO - 2017-07-21 14:21:13 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:13 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:13 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:13 --> Model Class Initialized
INFO - 2017-07-21 14:21:13 --> Model Class Initialized
INFO - 2017-07-21 14:21:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:13 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:13 --> Total execution time: 0.0495
INFO - 2017-07-21 14:21:16 --> Config Class Initialized
INFO - 2017-07-21 14:21:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:16 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:16 --> URI Class Initialized
INFO - 2017-07-21 14:21:16 --> Router Class Initialized
INFO - 2017-07-21 14:21:16 --> Output Class Initialized
INFO - 2017-07-21 14:21:16 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:16 --> Input Class Initialized
INFO - 2017-07-21 14:21:16 --> Language Class Initialized
INFO - 2017-07-21 14:21:16 --> Loader Class Initialized
INFO - 2017-07-21 14:21:16 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:16 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:16 --> Email Class Initialized
INFO - 2017-07-21 14:21:16 --> Controller Class Initialized
INFO - 2017-07-21 14:21:16 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:16 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:16 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:16 --> Model Class Initialized
INFO - 2017-07-21 14:21:16 --> Model Class Initialized
DEBUG - 2017-07-21 14:21:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:21:16 --> Config Class Initialized
INFO - 2017-07-21 14:21:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:16 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:16 --> URI Class Initialized
INFO - 2017-07-21 14:21:16 --> Router Class Initialized
INFO - 2017-07-21 14:21:16 --> Output Class Initialized
INFO - 2017-07-21 14:21:16 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:16 --> Input Class Initialized
INFO - 2017-07-21 14:21:16 --> Language Class Initialized
INFO - 2017-07-21 14:21:16 --> Loader Class Initialized
INFO - 2017-07-21 14:21:16 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:16 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:16 --> Email Class Initialized
INFO - 2017-07-21 14:21:16 --> Controller Class Initialized
INFO - 2017-07-21 14:21:16 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:16 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:16 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:16 --> Model Class Initialized
INFO - 2017-07-21 14:21:16 --> Model Class Initialized
INFO - 2017-07-21 14:21:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:16 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:16 --> Total execution time: 0.0452
INFO - 2017-07-21 14:21:22 --> Config Class Initialized
INFO - 2017-07-21 14:21:22 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:22 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:22 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:22 --> URI Class Initialized
INFO - 2017-07-21 14:21:22 --> Router Class Initialized
INFO - 2017-07-21 14:21:22 --> Output Class Initialized
INFO - 2017-07-21 14:21:22 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:22 --> Input Class Initialized
INFO - 2017-07-21 14:21:22 --> Language Class Initialized
INFO - 2017-07-21 14:21:22 --> Loader Class Initialized
INFO - 2017-07-21 14:21:22 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:22 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:22 --> Email Class Initialized
INFO - 2017-07-21 14:21:22 --> Controller Class Initialized
INFO - 2017-07-21 14:21:22 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:22 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:22 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:22 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:22 --> Model Class Initialized
INFO - 2017-07-21 14:21:22 --> Model Class Initialized
INFO - 2017-07-21 14:21:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:22 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:22 --> Total execution time: 0.0455
INFO - 2017-07-21 14:21:25 --> Config Class Initialized
INFO - 2017-07-21 14:21:25 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:25 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:25 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:25 --> URI Class Initialized
DEBUG - 2017-07-21 14:21:25 --> No URI present. Default controller set.
INFO - 2017-07-21 14:21:25 --> Router Class Initialized
INFO - 2017-07-21 14:21:25 --> Output Class Initialized
INFO - 2017-07-21 14:21:25 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:25 --> Input Class Initialized
INFO - 2017-07-21 14:21:25 --> Language Class Initialized
INFO - 2017-07-21 14:21:25 --> Loader Class Initialized
INFO - 2017-07-21 14:21:25 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:25 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:25 --> Email Class Initialized
INFO - 2017-07-21 14:21:25 --> Controller Class Initialized
INFO - 2017-07-21 14:21:25 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:25 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:25 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:25 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:25 --> Model Class Initialized
INFO - 2017-07-21 14:21:25 --> Model Class Initialized
INFO - 2017-07-21 14:21:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:25 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:25 --> Total execution time: 0.0526
INFO - 2017-07-21 14:21:30 --> Config Class Initialized
INFO - 2017-07-21 14:21:30 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:30 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:30 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:30 --> URI Class Initialized
DEBUG - 2017-07-21 14:21:30 --> No URI present. Default controller set.
INFO - 2017-07-21 14:21:30 --> Router Class Initialized
INFO - 2017-07-21 14:21:30 --> Output Class Initialized
INFO - 2017-07-21 14:21:30 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:30 --> Input Class Initialized
INFO - 2017-07-21 14:21:30 --> Language Class Initialized
INFO - 2017-07-21 14:21:30 --> Loader Class Initialized
INFO - 2017-07-21 14:21:30 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:30 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:30 --> Email Class Initialized
INFO - 2017-07-21 14:21:30 --> Controller Class Initialized
INFO - 2017-07-21 14:21:30 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:30 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:30 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:30 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:30 --> Model Class Initialized
INFO - 2017-07-21 14:21:30 --> Model Class Initialized
DEBUG - 2017-07-21 14:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:21:30 --> Config Class Initialized
INFO - 2017-07-21 14:21:30 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:30 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:30 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:30 --> URI Class Initialized
INFO - 2017-07-21 14:21:30 --> Router Class Initialized
INFO - 2017-07-21 14:21:30 --> Output Class Initialized
INFO - 2017-07-21 14:21:30 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:30 --> Input Class Initialized
INFO - 2017-07-21 14:21:30 --> Language Class Initialized
INFO - 2017-07-21 14:21:30 --> Loader Class Initialized
INFO - 2017-07-21 14:21:30 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:30 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:30 --> Email Class Initialized
INFO - 2017-07-21 14:21:30 --> Controller Class Initialized
INFO - 2017-07-21 14:21:30 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:30 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:30 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:30 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:30 --> Model Class Initialized
INFO - 2017-07-21 14:21:30 --> Model Class Initialized
INFO - 2017-07-21 14:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:30 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:30 --> Total execution time: 0.0456
INFO - 2017-07-21 14:21:51 --> Config Class Initialized
INFO - 2017-07-21 14:21:51 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:51 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:51 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:51 --> URI Class Initialized
INFO - 2017-07-21 14:21:51 --> Router Class Initialized
INFO - 2017-07-21 14:21:51 --> Output Class Initialized
INFO - 2017-07-21 14:21:51 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:51 --> Input Class Initialized
INFO - 2017-07-21 14:21:51 --> Language Class Initialized
INFO - 2017-07-21 14:21:51 --> Loader Class Initialized
INFO - 2017-07-21 14:21:51 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:51 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:51 --> Email Class Initialized
INFO - 2017-07-21 14:21:51 --> Controller Class Initialized
INFO - 2017-07-21 14:21:51 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:51 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:51 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:51 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:51 --> Model Class Initialized
INFO - 2017-07-21 14:21:51 --> Model Class Initialized
INFO - 2017-07-21 14:21:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:51 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:51 --> Total execution time: 0.0474
INFO - 2017-07-21 14:21:54 --> Config Class Initialized
INFO - 2017-07-21 14:21:54 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:54 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:54 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:54 --> URI Class Initialized
DEBUG - 2017-07-21 14:21:54 --> No URI present. Default controller set.
INFO - 2017-07-21 14:21:54 --> Router Class Initialized
INFO - 2017-07-21 14:21:54 --> Output Class Initialized
INFO - 2017-07-21 14:21:54 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:54 --> Input Class Initialized
INFO - 2017-07-21 14:21:54 --> Language Class Initialized
INFO - 2017-07-21 14:21:54 --> Loader Class Initialized
INFO - 2017-07-21 14:21:54 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:54 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:54 --> Email Class Initialized
INFO - 2017-07-21 14:21:54 --> Controller Class Initialized
INFO - 2017-07-21 14:21:54 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:54 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:54 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:54 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:54 --> Model Class Initialized
INFO - 2017-07-21 14:21:54 --> Model Class Initialized
INFO - 2017-07-21 14:21:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:54 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:54 --> Total execution time: 0.0514
INFO - 2017-07-21 14:21:56 --> Config Class Initialized
INFO - 2017-07-21 14:21:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:56 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:56 --> URI Class Initialized
DEBUG - 2017-07-21 14:21:56 --> No URI present. Default controller set.
INFO - 2017-07-21 14:21:56 --> Router Class Initialized
INFO - 2017-07-21 14:21:56 --> Output Class Initialized
INFO - 2017-07-21 14:21:56 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:56 --> Input Class Initialized
INFO - 2017-07-21 14:21:56 --> Language Class Initialized
INFO - 2017-07-21 14:21:56 --> Loader Class Initialized
INFO - 2017-07-21 14:21:56 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:56 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:56 --> Email Class Initialized
INFO - 2017-07-21 14:21:56 --> Controller Class Initialized
INFO - 2017-07-21 14:21:57 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:57 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:57 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:57 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:57 --> Model Class Initialized
INFO - 2017-07-21 14:21:57 --> Model Class Initialized
DEBUG - 2017-07-21 14:21:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:21:57 --> Config Class Initialized
INFO - 2017-07-21 14:21:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:21:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:21:57 --> Utf8 Class Initialized
INFO - 2017-07-21 14:21:57 --> URI Class Initialized
INFO - 2017-07-21 14:21:57 --> Router Class Initialized
INFO - 2017-07-21 14:21:57 --> Output Class Initialized
INFO - 2017-07-21 14:21:57 --> Security Class Initialized
DEBUG - 2017-07-21 14:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:21:57 --> Input Class Initialized
INFO - 2017-07-21 14:21:57 --> Language Class Initialized
INFO - 2017-07-21 14:21:57 --> Loader Class Initialized
INFO - 2017-07-21 14:21:57 --> Helper loaded: common_helper
INFO - 2017-07-21 14:21:57 --> Database Driver Class Initialized
INFO - 2017-07-21 14:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:21:57 --> Email Class Initialized
INFO - 2017-07-21 14:21:57 --> Controller Class Initialized
INFO - 2017-07-21 14:21:57 --> Helper loaded: form_helper
INFO - 2017-07-21 14:21:57 --> Form Validation Class Initialized
INFO - 2017-07-21 14:21:57 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:21:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:21:57 --> Helper loaded: url_helper
INFO - 2017-07-21 14:21:57 --> Model Class Initialized
INFO - 2017-07-21 14:21:57 --> Model Class Initialized
INFO - 2017-07-21 14:21:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:21:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:21:57 --> Final output sent to browser
DEBUG - 2017-07-21 14:21:57 --> Total execution time: 0.0477
INFO - 2017-07-21 14:22:10 --> Config Class Initialized
INFO - 2017-07-21 14:22:10 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:10 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:10 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:10 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:10 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:10 --> Router Class Initialized
INFO - 2017-07-21 14:22:10 --> Output Class Initialized
INFO - 2017-07-21 14:22:10 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:10 --> Input Class Initialized
INFO - 2017-07-21 14:22:10 --> Language Class Initialized
INFO - 2017-07-21 14:22:10 --> Loader Class Initialized
INFO - 2017-07-21 14:22:10 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:10 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:10 --> Email Class Initialized
INFO - 2017-07-21 14:22:10 --> Controller Class Initialized
INFO - 2017-07-21 14:22:10 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:10 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:10 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:10 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:10 --> Model Class Initialized
INFO - 2017-07-21 14:22:10 --> Model Class Initialized
INFO - 2017-07-21 14:22:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:22:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:22:10 --> Final output sent to browser
DEBUG - 2017-07-21 14:22:10 --> Total execution time: 0.0531
INFO - 2017-07-21 14:22:11 --> Config Class Initialized
INFO - 2017-07-21 14:22:11 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:11 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:11 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:11 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:11 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:11 --> Router Class Initialized
INFO - 2017-07-21 14:22:11 --> Output Class Initialized
INFO - 2017-07-21 14:22:11 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:11 --> Input Class Initialized
INFO - 2017-07-21 14:22:11 --> Language Class Initialized
INFO - 2017-07-21 14:22:11 --> Loader Class Initialized
INFO - 2017-07-21 14:22:11 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:11 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:11 --> Email Class Initialized
INFO - 2017-07-21 14:22:11 --> Controller Class Initialized
INFO - 2017-07-21 14:22:11 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:11 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:11 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:11 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:11 --> Model Class Initialized
INFO - 2017-07-21 14:22:11 --> Model Class Initialized
INFO - 2017-07-21 14:22:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:22:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:22:11 --> Final output sent to browser
DEBUG - 2017-07-21 14:22:11 --> Total execution time: 0.0464
INFO - 2017-07-21 14:22:12 --> Config Class Initialized
INFO - 2017-07-21 14:22:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:12 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:12 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:12 --> Router Class Initialized
INFO - 2017-07-21 14:22:12 --> Output Class Initialized
INFO - 2017-07-21 14:22:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:12 --> Input Class Initialized
INFO - 2017-07-21 14:22:12 --> Language Class Initialized
INFO - 2017-07-21 14:22:12 --> Loader Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:12 --> Email Class Initialized
INFO - 2017-07-21 14:22:12 --> Controller Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
DEBUG - 2017-07-21 14:22:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:22:12 --> Config Class Initialized
INFO - 2017-07-21 14:22:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:12 --> URI Class Initialized
INFO - 2017-07-21 14:22:12 --> Router Class Initialized
INFO - 2017-07-21 14:22:12 --> Output Class Initialized
INFO - 2017-07-21 14:22:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:12 --> Input Class Initialized
INFO - 2017-07-21 14:22:12 --> Language Class Initialized
INFO - 2017-07-21 14:22:12 --> Loader Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:12 --> Email Class Initialized
INFO - 2017-07-21 14:22:12 --> Controller Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> Config Class Initialized
INFO - 2017-07-21 14:22:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:12 --> URI Class Initialized
INFO - 2017-07-21 14:22:12 --> Router Class Initialized
INFO - 2017-07-21 14:22:12 --> Output Class Initialized
INFO - 2017-07-21 14:22:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:12 --> Input Class Initialized
INFO - 2017-07-21 14:22:12 --> Language Class Initialized
INFO - 2017-07-21 14:22:12 --> Loader Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:12 --> Email Class Initialized
INFO - 2017-07-21 14:22:12 --> Controller Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> Config Class Initialized
INFO - 2017-07-21 14:22:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:12 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:12 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:12 --> Router Class Initialized
INFO - 2017-07-21 14:22:12 --> Output Class Initialized
INFO - 2017-07-21 14:22:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:12 --> Input Class Initialized
INFO - 2017-07-21 14:22:12 --> Language Class Initialized
INFO - 2017-07-21 14:22:12 --> Loader Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:12 --> Email Class Initialized
INFO - 2017-07-21 14:22:12 --> Controller Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> Model Class Initialized
INFO - 2017-07-21 14:22:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:22:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:22:12 --> Final output sent to browser
DEBUG - 2017-07-21 14:22:12 --> Total execution time: 0.0465
INFO - 2017-07-21 14:22:22 --> Config Class Initialized
INFO - 2017-07-21 14:22:22 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:22 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:22 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:22 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:22 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:22 --> Router Class Initialized
INFO - 2017-07-21 14:22:22 --> Output Class Initialized
INFO - 2017-07-21 14:22:22 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:22 --> Input Class Initialized
INFO - 2017-07-21 14:22:22 --> Language Class Initialized
INFO - 2017-07-21 14:22:22 --> Loader Class Initialized
INFO - 2017-07-21 14:22:22 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:22 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:22 --> Email Class Initialized
INFO - 2017-07-21 14:22:22 --> Controller Class Initialized
INFO - 2017-07-21 14:22:22 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:22 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:22 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:22 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:22 --> Model Class Initialized
INFO - 2017-07-21 14:22:22 --> Model Class Initialized
INFO - 2017-07-21 14:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:22:22 --> Final output sent to browser
DEBUG - 2017-07-21 14:22:22 --> Total execution time: 0.0489
INFO - 2017-07-21 14:22:23 --> Config Class Initialized
INFO - 2017-07-21 14:22:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:24 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:24 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:24 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:24 --> Router Class Initialized
INFO - 2017-07-21 14:22:24 --> Output Class Initialized
INFO - 2017-07-21 14:22:24 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:24 --> Input Class Initialized
INFO - 2017-07-21 14:22:24 --> Language Class Initialized
INFO - 2017-07-21 14:22:24 --> Loader Class Initialized
INFO - 2017-07-21 14:22:24 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:24 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:24 --> Email Class Initialized
INFO - 2017-07-21 14:22:24 --> Controller Class Initialized
INFO - 2017-07-21 14:22:24 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:24 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:24 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:24 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:24 --> Model Class Initialized
INFO - 2017-07-21 14:22:24 --> Model Class Initialized
DEBUG - 2017-07-21 14:22:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:22:24 --> Config Class Initialized
INFO - 2017-07-21 14:22:24 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:24 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:24 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:24 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:24 --> Router Class Initialized
INFO - 2017-07-21 14:22:24 --> Output Class Initialized
INFO - 2017-07-21 14:22:24 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:24 --> Input Class Initialized
INFO - 2017-07-21 14:22:24 --> Language Class Initialized
INFO - 2017-07-21 14:22:24 --> Loader Class Initialized
INFO - 2017-07-21 14:22:24 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:24 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:24 --> Email Class Initialized
INFO - 2017-07-21 14:22:24 --> Controller Class Initialized
INFO - 2017-07-21 14:22:24 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:24 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:24 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:24 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:24 --> Model Class Initialized
INFO - 2017-07-21 14:22:24 --> Model Class Initialized
INFO - 2017-07-21 14:22:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:22:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:22:24 --> Final output sent to browser
DEBUG - 2017-07-21 14:22:24 --> Total execution time: 0.0459
INFO - 2017-07-21 14:22:27 --> Config Class Initialized
INFO - 2017-07-21 14:22:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:27 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:27 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:27 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:27 --> Router Class Initialized
INFO - 2017-07-21 14:22:27 --> Output Class Initialized
INFO - 2017-07-21 14:22:27 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:27 --> Input Class Initialized
INFO - 2017-07-21 14:22:27 --> Language Class Initialized
INFO - 2017-07-21 14:22:27 --> Loader Class Initialized
INFO - 2017-07-21 14:22:27 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:27 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:27 --> Email Class Initialized
INFO - 2017-07-21 14:22:27 --> Controller Class Initialized
INFO - 2017-07-21 14:22:27 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:27 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:27 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:27 --> Model Class Initialized
INFO - 2017-07-21 14:22:27 --> Model Class Initialized
DEBUG - 2017-07-21 14:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:22:27 --> Config Class Initialized
INFO - 2017-07-21 14:22:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:22:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:22:27 --> Utf8 Class Initialized
INFO - 2017-07-21 14:22:27 --> URI Class Initialized
DEBUG - 2017-07-21 14:22:27 --> No URI present. Default controller set.
INFO - 2017-07-21 14:22:27 --> Router Class Initialized
INFO - 2017-07-21 14:22:27 --> Output Class Initialized
INFO - 2017-07-21 14:22:27 --> Security Class Initialized
DEBUG - 2017-07-21 14:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:22:27 --> Input Class Initialized
INFO - 2017-07-21 14:22:27 --> Language Class Initialized
INFO - 2017-07-21 14:22:27 --> Loader Class Initialized
INFO - 2017-07-21 14:22:27 --> Helper loaded: common_helper
INFO - 2017-07-21 14:22:27 --> Database Driver Class Initialized
INFO - 2017-07-21 14:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:22:27 --> Email Class Initialized
INFO - 2017-07-21 14:22:27 --> Controller Class Initialized
INFO - 2017-07-21 14:22:27 --> Helper loaded: form_helper
INFO - 2017-07-21 14:22:27 --> Form Validation Class Initialized
INFO - 2017-07-21 14:22:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:22:27 --> Helper loaded: url_helper
INFO - 2017-07-21 14:22:27 --> Model Class Initialized
INFO - 2017-07-21 14:22:27 --> Model Class Initialized
INFO - 2017-07-21 14:22:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:22:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:22:27 --> Final output sent to browser
DEBUG - 2017-07-21 14:22:27 --> Total execution time: 0.0444
INFO - 2017-07-21 14:23:19 --> Config Class Initialized
INFO - 2017-07-21 14:23:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:19 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:19 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:19 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:19 --> Router Class Initialized
INFO - 2017-07-21 14:23:19 --> Output Class Initialized
INFO - 2017-07-21 14:23:19 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:19 --> Input Class Initialized
INFO - 2017-07-21 14:23:19 --> Language Class Initialized
INFO - 2017-07-21 14:23:19 --> Loader Class Initialized
INFO - 2017-07-21 14:23:19 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:19 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:19 --> Email Class Initialized
INFO - 2017-07-21 14:23:19 --> Controller Class Initialized
INFO - 2017-07-21 14:23:19 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:19 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:19 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:19 --> Model Class Initialized
INFO - 2017-07-21 14:23:19 --> Model Class Initialized
DEBUG - 2017-07-21 14:23:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:23:19 --> Config Class Initialized
INFO - 2017-07-21 14:23:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:19 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:19 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:19 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:19 --> Router Class Initialized
INFO - 2017-07-21 14:23:19 --> Output Class Initialized
INFO - 2017-07-21 14:23:19 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:19 --> Input Class Initialized
INFO - 2017-07-21 14:23:19 --> Language Class Initialized
INFO - 2017-07-21 14:23:19 --> Loader Class Initialized
INFO - 2017-07-21 14:23:19 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:19 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:19 --> Email Class Initialized
INFO - 2017-07-21 14:23:19 --> Controller Class Initialized
INFO - 2017-07-21 14:23:19 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:19 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:19 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:19 --> Model Class Initialized
INFO - 2017-07-21 14:23:19 --> Model Class Initialized
INFO - 2017-07-21 14:23:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:23:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:23:19 --> Final output sent to browser
DEBUG - 2017-07-21 14:23:19 --> Total execution time: 0.0437
INFO - 2017-07-21 14:23:38 --> Config Class Initialized
INFO - 2017-07-21 14:23:38 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:38 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:38 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:38 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:38 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:38 --> Router Class Initialized
INFO - 2017-07-21 14:23:38 --> Output Class Initialized
INFO - 2017-07-21 14:23:38 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:38 --> Input Class Initialized
INFO - 2017-07-21 14:23:38 --> Language Class Initialized
INFO - 2017-07-21 14:23:38 --> Loader Class Initialized
INFO - 2017-07-21 14:23:38 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:38 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:38 --> Email Class Initialized
INFO - 2017-07-21 14:23:38 --> Controller Class Initialized
INFO - 2017-07-21 14:23:38 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:38 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:38 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:38 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:38 --> Model Class Initialized
INFO - 2017-07-21 14:23:38 --> Model Class Initialized
INFO - 2017-07-21 14:23:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:23:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:23:38 --> Final output sent to browser
DEBUG - 2017-07-21 14:23:38 --> Total execution time: 0.0467
INFO - 2017-07-21 14:23:41 --> Config Class Initialized
INFO - 2017-07-21 14:23:41 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:41 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:41 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:41 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:41 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:41 --> Router Class Initialized
INFO - 2017-07-21 14:23:41 --> Output Class Initialized
INFO - 2017-07-21 14:23:41 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:41 --> Input Class Initialized
INFO - 2017-07-21 14:23:41 --> Language Class Initialized
INFO - 2017-07-21 14:23:41 --> Loader Class Initialized
INFO - 2017-07-21 14:23:41 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:41 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:41 --> Email Class Initialized
INFO - 2017-07-21 14:23:41 --> Controller Class Initialized
INFO - 2017-07-21 14:23:41 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:41 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:41 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:41 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:41 --> Model Class Initialized
INFO - 2017-07-21 14:23:41 --> Model Class Initialized
DEBUG - 2017-07-21 14:23:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:23:43 --> Config Class Initialized
INFO - 2017-07-21 14:23:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:43 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:43 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:43 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:43 --> Router Class Initialized
INFO - 2017-07-21 14:23:43 --> Output Class Initialized
INFO - 2017-07-21 14:23:43 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:43 --> Input Class Initialized
INFO - 2017-07-21 14:23:43 --> Language Class Initialized
INFO - 2017-07-21 14:23:43 --> Loader Class Initialized
INFO - 2017-07-21 14:23:43 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:43 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:44 --> Email Class Initialized
INFO - 2017-07-21 14:23:44 --> Controller Class Initialized
INFO - 2017-07-21 14:23:44 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:44 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:44 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:44 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:44 --> Model Class Initialized
INFO - 2017-07-21 14:23:44 --> Model Class Initialized
INFO - 2017-07-21 14:23:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-21 14:23:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:23:44 --> Final output sent to browser
DEBUG - 2017-07-21 14:23:44 --> Total execution time: 0.0451
INFO - 2017-07-21 14:23:46 --> Config Class Initialized
INFO - 2017-07-21 14:23:46 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:46 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:46 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:46 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:46 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:46 --> Router Class Initialized
INFO - 2017-07-21 14:23:46 --> Output Class Initialized
INFO - 2017-07-21 14:23:46 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:46 --> Input Class Initialized
INFO - 2017-07-21 14:23:46 --> Language Class Initialized
INFO - 2017-07-21 14:23:46 --> Loader Class Initialized
INFO - 2017-07-21 14:23:46 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:46 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:46 --> Email Class Initialized
INFO - 2017-07-21 14:23:46 --> Controller Class Initialized
INFO - 2017-07-21 14:23:46 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:46 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:46 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:46 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:46 --> Model Class Initialized
INFO - 2017-07-21 14:23:46 --> Model Class Initialized
DEBUG - 2017-07-21 14:23:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:23:59 --> Config Class Initialized
INFO - 2017-07-21 14:23:59 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:23:59 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:23:59 --> Utf8 Class Initialized
INFO - 2017-07-21 14:23:59 --> URI Class Initialized
DEBUG - 2017-07-21 14:23:59 --> No URI present. Default controller set.
INFO - 2017-07-21 14:23:59 --> Router Class Initialized
INFO - 2017-07-21 14:23:59 --> Output Class Initialized
INFO - 2017-07-21 14:23:59 --> Security Class Initialized
DEBUG - 2017-07-21 14:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:23:59 --> Input Class Initialized
INFO - 2017-07-21 14:23:59 --> Language Class Initialized
INFO - 2017-07-21 14:23:59 --> Loader Class Initialized
INFO - 2017-07-21 14:23:59 --> Helper loaded: common_helper
INFO - 2017-07-21 14:23:59 --> Database Driver Class Initialized
INFO - 2017-07-21 14:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:23:59 --> Email Class Initialized
INFO - 2017-07-21 14:23:59 --> Controller Class Initialized
INFO - 2017-07-21 14:23:59 --> Helper loaded: form_helper
INFO - 2017-07-21 14:23:59 --> Form Validation Class Initialized
INFO - 2017-07-21 14:23:59 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:59 --> Helper loaded: url_helper
INFO - 2017-07-21 14:23:59 --> Model Class Initialized
INFO - 2017-07-21 14:23:59 --> Model Class Initialized
DEBUG - 2017-07-21 14:23:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:23:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:24:12 --> Config Class Initialized
INFO - 2017-07-21 14:24:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:24:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:24:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:24:12 --> URI Class Initialized
DEBUG - 2017-07-21 14:24:12 --> No URI present. Default controller set.
INFO - 2017-07-21 14:24:12 --> Router Class Initialized
INFO - 2017-07-21 14:24:12 --> Output Class Initialized
INFO - 2017-07-21 14:24:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:24:12 --> Input Class Initialized
INFO - 2017-07-21 14:24:12 --> Language Class Initialized
INFO - 2017-07-21 14:24:12 --> Loader Class Initialized
INFO - 2017-07-21 14:24:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:24:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:24:12 --> Email Class Initialized
INFO - 2017-07-21 14:24:12 --> Controller Class Initialized
INFO - 2017-07-21 14:24:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:24:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:24:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:24:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:24:12 --> Model Class Initialized
INFO - 2017-07-21 14:24:12 --> Model Class Initialized
DEBUG - 2017-07-21 14:24:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:24:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:24:12 --> Config Class Initialized
INFO - 2017-07-21 14:24:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:24:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:24:12 --> Utf8 Class Initialized
INFO - 2017-07-21 14:24:12 --> URI Class Initialized
INFO - 2017-07-21 14:24:12 --> Router Class Initialized
INFO - 2017-07-21 14:24:12 --> Output Class Initialized
INFO - 2017-07-21 14:24:12 --> Security Class Initialized
DEBUG - 2017-07-21 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:24:12 --> Input Class Initialized
INFO - 2017-07-21 14:24:12 --> Language Class Initialized
INFO - 2017-07-21 14:24:12 --> Loader Class Initialized
INFO - 2017-07-21 14:24:12 --> Helper loaded: common_helper
INFO - 2017-07-21 14:24:12 --> Database Driver Class Initialized
INFO - 2017-07-21 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:24:12 --> Email Class Initialized
INFO - 2017-07-21 14:24:12 --> Controller Class Initialized
INFO - 2017-07-21 14:24:12 --> Helper loaded: form_helper
INFO - 2017-07-21 14:24:12 --> Form Validation Class Initialized
INFO - 2017-07-21 14:24:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:24:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:24:12 --> Helper loaded: url_helper
INFO - 2017-07-21 14:24:12 --> Model Class Initialized
INFO - 2017-07-21 14:24:12 --> Model Class Initialized
INFO - 2017-07-21 14:24:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:24:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:24:12 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:24:12 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:24:12 --> Trying to get property of non-object
ERROR - 2017-07-21 14:24:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:24:12 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:24:12 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:24:12 --> Trying to get property of non-object
ERROR - 2017-07-21 14:24:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:24:12 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:24:12 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:24:12 --> Trying to get property of non-object
ERROR - 2017-07-21 14:24:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:24:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:24:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:24:12 --> Final output sent to browser
DEBUG - 2017-07-21 14:24:12 --> Total execution time: 0.0591
INFO - 2017-07-21 14:24:14 --> Config Class Initialized
INFO - 2017-07-21 14:24:14 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:24:14 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:24:14 --> Utf8 Class Initialized
INFO - 2017-07-21 14:24:14 --> URI Class Initialized
INFO - 2017-07-21 14:24:14 --> Router Class Initialized
INFO - 2017-07-21 14:24:14 --> Output Class Initialized
INFO - 2017-07-21 14:24:14 --> Security Class Initialized
DEBUG - 2017-07-21 14:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:24:14 --> Input Class Initialized
INFO - 2017-07-21 14:24:14 --> Language Class Initialized
INFO - 2017-07-21 14:24:14 --> Loader Class Initialized
INFO - 2017-07-21 14:24:14 --> Helper loaded: common_helper
INFO - 2017-07-21 14:24:14 --> Database Driver Class Initialized
INFO - 2017-07-21 14:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:24:14 --> Email Class Initialized
INFO - 2017-07-21 14:24:14 --> Controller Class Initialized
INFO - 2017-07-21 14:24:14 --> Helper loaded: form_helper
INFO - 2017-07-21 14:24:14 --> Form Validation Class Initialized
INFO - 2017-07-21 14:24:14 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:24:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:24:14 --> Helper loaded: url_helper
INFO - 2017-07-21 14:24:14 --> Model Class Initialized
INFO - 2017-07-21 14:24:14 --> Model Class Initialized
ERROR - 2017-07-21 14:24:14 --> Use of undefined constant TBL_BLOODGROUPS - assumed 'TBL_BLOODGROUPS'
ERROR - 2017-07-21 14:24:14 --> Severity: Notice --> Use of undefined constant TBL_BLOODGROUPS - assumed 'TBL_BLOODGROUPS' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admin.php 182
ERROR - 2017-07-21 14:24:14 --> Query error: Table 'flicknews.tbl_bloodgroups' doesn't exist - Invalid query: SELECT *
FROM `TBL_BLOODGROUPS`
WHERE `isDeleted` =0
ERROR - 2017-07-21 14:24:14 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 14:24:14 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 14:24:48 --> Config Class Initialized
INFO - 2017-07-21 14:24:48 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:24:48 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:24:48 --> Utf8 Class Initialized
INFO - 2017-07-21 14:24:48 --> URI Class Initialized
INFO - 2017-07-21 14:24:48 --> Router Class Initialized
INFO - 2017-07-21 14:24:48 --> Output Class Initialized
INFO - 2017-07-21 14:24:48 --> Security Class Initialized
DEBUG - 2017-07-21 14:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:24:48 --> Input Class Initialized
INFO - 2017-07-21 14:24:48 --> Language Class Initialized
INFO - 2017-07-21 14:24:48 --> Loader Class Initialized
INFO - 2017-07-21 14:24:48 --> Helper loaded: common_helper
INFO - 2017-07-21 14:24:48 --> Database Driver Class Initialized
INFO - 2017-07-21 14:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:24:48 --> Email Class Initialized
INFO - 2017-07-21 14:24:48 --> Controller Class Initialized
INFO - 2017-07-21 14:24:48 --> Helper loaded: form_helper
INFO - 2017-07-21 14:24:48 --> Form Validation Class Initialized
INFO - 2017-07-21 14:24:48 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:24:48 --> Helper loaded: url_helper
INFO - 2017-07-21 14:24:48 --> Model Class Initialized
INFO - 2017-07-21 14:24:48 --> Model Class Initialized
INFO - 2017-07-21 14:24:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:24:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:24:48 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 14:24:48 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\profile.php 51
INFO - 2017-07-21 14:24:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:24:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:24:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:24:48 --> Final output sent to browser
DEBUG - 2017-07-21 14:24:48 --> Total execution time: 0.0541
INFO - 2017-07-21 14:26:15 --> Config Class Initialized
INFO - 2017-07-21 14:26:15 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:26:15 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:26:15 --> Utf8 Class Initialized
INFO - 2017-07-21 14:26:15 --> URI Class Initialized
INFO - 2017-07-21 14:26:15 --> Router Class Initialized
INFO - 2017-07-21 14:26:15 --> Output Class Initialized
INFO - 2017-07-21 14:26:15 --> Security Class Initialized
DEBUG - 2017-07-21 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:26:15 --> Input Class Initialized
INFO - 2017-07-21 14:26:15 --> Language Class Initialized
INFO - 2017-07-21 14:26:15 --> Loader Class Initialized
INFO - 2017-07-21 14:26:15 --> Helper loaded: common_helper
INFO - 2017-07-21 14:26:15 --> Database Driver Class Initialized
INFO - 2017-07-21 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:26:15 --> Email Class Initialized
INFO - 2017-07-21 14:26:15 --> Controller Class Initialized
INFO - 2017-07-21 14:26:15 --> Helper loaded: form_helper
INFO - 2017-07-21 14:26:15 --> Form Validation Class Initialized
INFO - 2017-07-21 14:26:15 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:26:15 --> Helper loaded: url_helper
INFO - 2017-07-21 14:26:15 --> Model Class Initialized
INFO - 2017-07-21 14:26:15 --> Model Class Initialized
INFO - 2017-07-21 14:26:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:26:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:26:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:26:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:26:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:26:15 --> Final output sent to browser
DEBUG - 2017-07-21 14:26:15 --> Total execution time: 0.0487
INFO - 2017-07-21 14:26:55 --> Config Class Initialized
INFO - 2017-07-21 14:26:55 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:26:55 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:26:55 --> Utf8 Class Initialized
INFO - 2017-07-21 14:26:55 --> URI Class Initialized
INFO - 2017-07-21 14:26:55 --> Router Class Initialized
INFO - 2017-07-21 14:26:55 --> Output Class Initialized
INFO - 2017-07-21 14:26:55 --> Security Class Initialized
DEBUG - 2017-07-21 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:26:55 --> Input Class Initialized
INFO - 2017-07-21 14:26:55 --> Language Class Initialized
INFO - 2017-07-21 14:26:55 --> Loader Class Initialized
INFO - 2017-07-21 14:26:55 --> Helper loaded: common_helper
INFO - 2017-07-21 14:26:55 --> Database Driver Class Initialized
INFO - 2017-07-21 14:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:26:55 --> Email Class Initialized
INFO - 2017-07-21 14:26:55 --> Controller Class Initialized
INFO - 2017-07-21 14:26:55 --> Helper loaded: form_helper
INFO - 2017-07-21 14:26:55 --> Form Validation Class Initialized
INFO - 2017-07-21 14:26:55 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:26:55 --> Helper loaded: url_helper
INFO - 2017-07-21 14:26:55 --> Model Class Initialized
INFO - 2017-07-21 14:26:55 --> Model Class Initialized
INFO - 2017-07-21 14:26:55 --> Config Class Initialized
INFO - 2017-07-21 14:26:55 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:26:55 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:26:55 --> Utf8 Class Initialized
INFO - 2017-07-21 14:26:55 --> URI Class Initialized
INFO - 2017-07-21 14:26:55 --> Router Class Initialized
INFO - 2017-07-21 14:26:55 --> Output Class Initialized
INFO - 2017-07-21 14:26:55 --> Security Class Initialized
DEBUG - 2017-07-21 14:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:26:55 --> Input Class Initialized
INFO - 2017-07-21 14:26:55 --> Language Class Initialized
INFO - 2017-07-21 14:26:55 --> Loader Class Initialized
INFO - 2017-07-21 14:26:55 --> Helper loaded: common_helper
INFO - 2017-07-21 14:26:55 --> Database Driver Class Initialized
INFO - 2017-07-21 14:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:26:55 --> Email Class Initialized
INFO - 2017-07-21 14:26:55 --> Controller Class Initialized
INFO - 2017-07-21 14:26:55 --> Helper loaded: form_helper
INFO - 2017-07-21 14:26:55 --> Form Validation Class Initialized
INFO - 2017-07-21 14:26:55 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:26:55 --> Helper loaded: url_helper
INFO - 2017-07-21 14:26:55 --> Model Class Initialized
INFO - 2017-07-21 14:26:55 --> Model Class Initialized
INFO - 2017-07-21 14:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:26:55 --> Final output sent to browser
DEBUG - 2017-07-21 14:26:55 --> Total execution time: 0.0498
INFO - 2017-07-21 14:27:38 --> Config Class Initialized
INFO - 2017-07-21 14:27:38 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:27:38 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:27:38 --> Utf8 Class Initialized
INFO - 2017-07-21 14:27:38 --> URI Class Initialized
INFO - 2017-07-21 14:27:38 --> Router Class Initialized
INFO - 2017-07-21 14:27:38 --> Output Class Initialized
INFO - 2017-07-21 14:27:38 --> Security Class Initialized
DEBUG - 2017-07-21 14:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:27:38 --> Input Class Initialized
INFO - 2017-07-21 14:27:38 --> Language Class Initialized
INFO - 2017-07-21 14:27:38 --> Loader Class Initialized
INFO - 2017-07-21 14:27:38 --> Helper loaded: common_helper
INFO - 2017-07-21 14:27:38 --> Database Driver Class Initialized
INFO - 2017-07-21 14:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:27:38 --> Email Class Initialized
INFO - 2017-07-21 14:27:38 --> Controller Class Initialized
INFO - 2017-07-21 14:27:38 --> Helper loaded: form_helper
INFO - 2017-07-21 14:27:38 --> Form Validation Class Initialized
INFO - 2017-07-21 14:27:38 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:27:38 --> Helper loaded: url_helper
INFO - 2017-07-21 14:27:38 --> Model Class Initialized
INFO - 2017-07-21 14:27:38 --> Model Class Initialized
INFO - 2017-07-21 14:27:38 --> Config Class Initialized
INFO - 2017-07-21 14:27:38 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:27:38 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:27:38 --> Utf8 Class Initialized
INFO - 2017-07-21 14:27:38 --> URI Class Initialized
INFO - 2017-07-21 14:27:38 --> Router Class Initialized
INFO - 2017-07-21 14:27:38 --> Output Class Initialized
INFO - 2017-07-21 14:27:38 --> Security Class Initialized
DEBUG - 2017-07-21 14:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:27:38 --> Input Class Initialized
INFO - 2017-07-21 14:27:38 --> Language Class Initialized
INFO - 2017-07-21 14:27:38 --> Loader Class Initialized
INFO - 2017-07-21 14:27:38 --> Helper loaded: common_helper
INFO - 2017-07-21 14:27:38 --> Database Driver Class Initialized
INFO - 2017-07-21 14:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:27:38 --> Email Class Initialized
INFO - 2017-07-21 14:27:38 --> Controller Class Initialized
INFO - 2017-07-21 14:27:38 --> Helper loaded: form_helper
INFO - 2017-07-21 14:27:38 --> Form Validation Class Initialized
INFO - 2017-07-21 14:27:38 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:27:38 --> Helper loaded: url_helper
INFO - 2017-07-21 14:27:38 --> Model Class Initialized
INFO - 2017-07-21 14:27:38 --> Model Class Initialized
INFO - 2017-07-21 14:27:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:27:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:27:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:27:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:27:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:27:38 --> Final output sent to browser
DEBUG - 2017-07-21 14:27:38 --> Total execution time: 0.0544
INFO - 2017-07-21 14:28:09 --> Config Class Initialized
INFO - 2017-07-21 14:28:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:28:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:28:09 --> Utf8 Class Initialized
INFO - 2017-07-21 14:28:09 --> URI Class Initialized
INFO - 2017-07-21 14:28:09 --> Router Class Initialized
INFO - 2017-07-21 14:28:09 --> Output Class Initialized
INFO - 2017-07-21 14:28:09 --> Security Class Initialized
DEBUG - 2017-07-21 14:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:28:09 --> Input Class Initialized
INFO - 2017-07-21 14:28:09 --> Language Class Initialized
INFO - 2017-07-21 14:28:09 --> Loader Class Initialized
INFO - 2017-07-21 14:28:09 --> Helper loaded: common_helper
INFO - 2017-07-21 14:28:09 --> Database Driver Class Initialized
INFO - 2017-07-21 14:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:28:09 --> Email Class Initialized
INFO - 2017-07-21 14:28:09 --> Controller Class Initialized
INFO - 2017-07-21 14:28:09 --> Helper loaded: form_helper
INFO - 2017-07-21 14:28:09 --> Form Validation Class Initialized
INFO - 2017-07-21 14:28:09 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:28:09 --> Helper loaded: url_helper
INFO - 2017-07-21 14:28:09 --> Model Class Initialized
INFO - 2017-07-21 14:28:09 --> Model Class Initialized
INFO - 2017-07-21 14:28:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:28:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:28:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:28:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:28:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:28:09 --> Final output sent to browser
DEBUG - 2017-07-21 14:28:09 --> Total execution time: 0.0492
INFO - 2017-07-21 14:29:00 --> Config Class Initialized
INFO - 2017-07-21 14:29:00 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:29:00 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:29:00 --> Utf8 Class Initialized
INFO - 2017-07-21 14:29:00 --> URI Class Initialized
INFO - 2017-07-21 14:29:00 --> Router Class Initialized
INFO - 2017-07-21 14:29:00 --> Output Class Initialized
INFO - 2017-07-21 14:29:00 --> Security Class Initialized
DEBUG - 2017-07-21 14:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:29:00 --> Input Class Initialized
INFO - 2017-07-21 14:29:00 --> Language Class Initialized
INFO - 2017-07-21 14:29:00 --> Loader Class Initialized
INFO - 2017-07-21 14:29:00 --> Helper loaded: common_helper
INFO - 2017-07-21 14:29:00 --> Database Driver Class Initialized
INFO - 2017-07-21 14:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:29:00 --> Email Class Initialized
INFO - 2017-07-21 14:29:00 --> Controller Class Initialized
INFO - 2017-07-21 14:29:00 --> Helper loaded: form_helper
INFO - 2017-07-21 14:29:00 --> Form Validation Class Initialized
INFO - 2017-07-21 14:29:00 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:29:00 --> Helper loaded: url_helper
INFO - 2017-07-21 14:29:00 --> Model Class Initialized
INFO - 2017-07-21 14:29:00 --> Model Class Initialized
INFO - 2017-07-21 14:29:58 --> Config Class Initialized
INFO - 2017-07-21 14:29:58 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:29:58 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:29:58 --> Utf8 Class Initialized
INFO - 2017-07-21 14:29:58 --> URI Class Initialized
INFO - 2017-07-21 14:29:58 --> Router Class Initialized
INFO - 2017-07-21 14:29:58 --> Output Class Initialized
INFO - 2017-07-21 14:29:58 --> Security Class Initialized
DEBUG - 2017-07-21 14:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:29:58 --> Input Class Initialized
INFO - 2017-07-21 14:29:58 --> Language Class Initialized
INFO - 2017-07-21 14:29:58 --> Loader Class Initialized
INFO - 2017-07-21 14:29:58 --> Helper loaded: common_helper
INFO - 2017-07-21 14:29:58 --> Database Driver Class Initialized
INFO - 2017-07-21 14:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:29:58 --> Email Class Initialized
INFO - 2017-07-21 14:29:58 --> Controller Class Initialized
INFO - 2017-07-21 14:29:58 --> Helper loaded: form_helper
INFO - 2017-07-21 14:29:58 --> Form Validation Class Initialized
INFO - 2017-07-21 14:29:58 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:29:58 --> Helper loaded: url_helper
INFO - 2017-07-21 14:29:58 --> Model Class Initialized
INFO - 2017-07-21 14:29:58 --> Model Class Initialized
INFO - 2017-07-21 14:30:31 --> Config Class Initialized
INFO - 2017-07-21 14:30:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:30:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:30:31 --> Utf8 Class Initialized
INFO - 2017-07-21 14:30:31 --> URI Class Initialized
INFO - 2017-07-21 14:30:31 --> Router Class Initialized
INFO - 2017-07-21 14:30:31 --> Output Class Initialized
INFO - 2017-07-21 14:30:31 --> Security Class Initialized
DEBUG - 2017-07-21 14:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:30:31 --> Input Class Initialized
INFO - 2017-07-21 14:30:31 --> Language Class Initialized
INFO - 2017-07-21 14:30:31 --> Loader Class Initialized
INFO - 2017-07-21 14:30:31 --> Helper loaded: common_helper
INFO - 2017-07-21 14:30:31 --> Database Driver Class Initialized
INFO - 2017-07-21 14:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:30:31 --> Email Class Initialized
INFO - 2017-07-21 14:30:31 --> Controller Class Initialized
INFO - 2017-07-21 14:30:31 --> Helper loaded: form_helper
INFO - 2017-07-21 14:30:31 --> Form Validation Class Initialized
INFO - 2017-07-21 14:30:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:30:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:30:31 --> Helper loaded: url_helper
INFO - 2017-07-21 14:30:31 --> Model Class Initialized
INFO - 2017-07-21 14:30:31 --> Model Class Initialized
INFO - 2017-07-21 14:30:46 --> Config Class Initialized
INFO - 2017-07-21 14:30:46 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:30:46 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:30:46 --> Utf8 Class Initialized
INFO - 2017-07-21 14:30:46 --> URI Class Initialized
INFO - 2017-07-21 14:30:46 --> Router Class Initialized
INFO - 2017-07-21 14:30:46 --> Output Class Initialized
INFO - 2017-07-21 14:30:46 --> Security Class Initialized
DEBUG - 2017-07-21 14:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:30:46 --> Input Class Initialized
INFO - 2017-07-21 14:30:46 --> Language Class Initialized
INFO - 2017-07-21 14:30:46 --> Loader Class Initialized
INFO - 2017-07-21 14:30:46 --> Helper loaded: common_helper
INFO - 2017-07-21 14:30:46 --> Database Driver Class Initialized
INFO - 2017-07-21 14:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:30:46 --> Email Class Initialized
INFO - 2017-07-21 14:30:46 --> Controller Class Initialized
INFO - 2017-07-21 14:30:46 --> Helper loaded: form_helper
INFO - 2017-07-21 14:30:46 --> Form Validation Class Initialized
INFO - 2017-07-21 14:30:46 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:30:46 --> Helper loaded: url_helper
INFO - 2017-07-21 14:30:46 --> Model Class Initialized
INFO - 2017-07-21 14:30:46 --> Model Class Initialized
INFO - 2017-07-21 14:31:18 --> Config Class Initialized
INFO - 2017-07-21 14:31:18 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:18 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:18 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:18 --> URI Class Initialized
INFO - 2017-07-21 14:31:18 --> Router Class Initialized
INFO - 2017-07-21 14:31:18 --> Output Class Initialized
INFO - 2017-07-21 14:31:18 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:18 --> Input Class Initialized
INFO - 2017-07-21 14:31:18 --> Language Class Initialized
INFO - 2017-07-21 14:31:18 --> Loader Class Initialized
INFO - 2017-07-21 14:31:18 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:18 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:18 --> Email Class Initialized
INFO - 2017-07-21 14:31:18 --> Controller Class Initialized
INFO - 2017-07-21 14:31:18 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:18 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:18 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:18 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:18 --> Model Class Initialized
INFO - 2017-07-21 14:31:18 --> Model Class Initialized
INFO - 2017-07-21 14:31:18 --> Config Class Initialized
INFO - 2017-07-21 14:31:18 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:18 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:18 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:18 --> URI Class Initialized
INFO - 2017-07-21 14:31:18 --> Router Class Initialized
INFO - 2017-07-21 14:31:18 --> Output Class Initialized
INFO - 2017-07-21 14:31:18 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:18 --> Input Class Initialized
INFO - 2017-07-21 14:31:18 --> Language Class Initialized
INFO - 2017-07-21 14:31:18 --> Loader Class Initialized
INFO - 2017-07-21 14:31:18 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:18 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:18 --> Email Class Initialized
INFO - 2017-07-21 14:31:18 --> Controller Class Initialized
INFO - 2017-07-21 14:31:18 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:18 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:18 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:18 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:18 --> Model Class Initialized
INFO - 2017-07-21 14:31:18 --> Model Class Initialized
INFO - 2017-07-21 14:31:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:31:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:31:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:31:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:31:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:31:18 --> Final output sent to browser
DEBUG - 2017-07-21 14:31:18 --> Total execution time: 0.0468
INFO - 2017-07-21 14:31:28 --> Config Class Initialized
INFO - 2017-07-21 14:31:28 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:28 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:28 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:28 --> URI Class Initialized
INFO - 2017-07-21 14:31:28 --> Router Class Initialized
INFO - 2017-07-21 14:31:28 --> Output Class Initialized
INFO - 2017-07-21 14:31:28 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:28 --> Input Class Initialized
INFO - 2017-07-21 14:31:28 --> Language Class Initialized
INFO - 2017-07-21 14:31:28 --> Loader Class Initialized
INFO - 2017-07-21 14:31:28 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:28 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:28 --> Email Class Initialized
INFO - 2017-07-21 14:31:28 --> Controller Class Initialized
INFO - 2017-07-21 14:31:28 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:28 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:28 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:28 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:28 --> Model Class Initialized
INFO - 2017-07-21 14:31:28 --> Model Class Initialized
INFO - 2017-07-21 14:31:28 --> Config Class Initialized
INFO - 2017-07-21 14:31:28 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:28 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:28 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:28 --> URI Class Initialized
INFO - 2017-07-21 14:31:28 --> Router Class Initialized
INFO - 2017-07-21 14:31:28 --> Output Class Initialized
INFO - 2017-07-21 14:31:28 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:28 --> Input Class Initialized
INFO - 2017-07-21 14:31:28 --> Language Class Initialized
INFO - 2017-07-21 14:31:28 --> Loader Class Initialized
INFO - 2017-07-21 14:31:28 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:28 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:28 --> Email Class Initialized
INFO - 2017-07-21 14:31:28 --> Controller Class Initialized
INFO - 2017-07-21 14:31:28 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:28 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:28 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:28 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:28 --> Model Class Initialized
INFO - 2017-07-21 14:31:28 --> Model Class Initialized
INFO - 2017-07-21 14:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:31:28 --> Final output sent to browser
DEBUG - 2017-07-21 14:31:28 --> Total execution time: 0.0455
INFO - 2017-07-21 14:31:32 --> Config Class Initialized
INFO - 2017-07-21 14:31:32 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:32 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:32 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:32 --> URI Class Initialized
INFO - 2017-07-21 14:31:32 --> Router Class Initialized
INFO - 2017-07-21 14:31:32 --> Output Class Initialized
INFO - 2017-07-21 14:31:32 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:32 --> Input Class Initialized
INFO - 2017-07-21 14:31:32 --> Language Class Initialized
INFO - 2017-07-21 14:31:32 --> Loader Class Initialized
INFO - 2017-07-21 14:31:32 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:32 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:32 --> Email Class Initialized
INFO - 2017-07-21 14:31:32 --> Controller Class Initialized
INFO - 2017-07-21 14:31:32 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:32 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:32 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:32 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:32 --> Model Class Initialized
INFO - 2017-07-21 14:31:32 --> Model Class Initialized
INFO - 2017-07-21 14:31:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:31:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 14:31:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-21 14:31:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 14:31:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:31:32 --> Final output sent to browser
DEBUG - 2017-07-21 14:31:32 --> Total execution time: 0.0583
INFO - 2017-07-21 14:31:33 --> Config Class Initialized
INFO - 2017-07-21 14:31:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:33 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:33 --> URI Class Initialized
INFO - 2017-07-21 14:31:33 --> Router Class Initialized
INFO - 2017-07-21 14:31:33 --> Output Class Initialized
INFO - 2017-07-21 14:31:33 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:33 --> Input Class Initialized
INFO - 2017-07-21 14:31:33 --> Language Class Initialized
INFO - 2017-07-21 14:31:33 --> Loader Class Initialized
INFO - 2017-07-21 14:31:33 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:33 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:33 --> Email Class Initialized
INFO - 2017-07-21 14:31:33 --> Controller Class Initialized
INFO - 2017-07-21 14:31:33 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:33 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:33 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:33 --> Model Class Initialized
INFO - 2017-07-21 14:31:33 --> Model Class Initialized
INFO - 2017-07-21 14:31:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 14:31:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 14:31:33 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 14:31:33 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:31:33 --> Trying to get property of non-object
ERROR - 2017-07-21 14:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 14:31:33 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 14:31:33 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:31:33 --> Trying to get property of non-object
ERROR - 2017-07-21 14:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 14:31:33 --> Undefined variable: Evenets
ERROR - 2017-07-21 14:31:33 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 14:31:33 --> Trying to get property of non-object
ERROR - 2017-07-21 14:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 14:31:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 14:31:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 14:31:33 --> Final output sent to browser
DEBUG - 2017-07-21 14:31:33 --> Total execution time: 0.0504
INFO - 2017-07-21 14:31:35 --> Config Class Initialized
INFO - 2017-07-21 14:31:35 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:31:35 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:31:35 --> Utf8 Class Initialized
INFO - 2017-07-21 14:31:35 --> URI Class Initialized
INFO - 2017-07-21 14:31:35 --> Router Class Initialized
INFO - 2017-07-21 14:31:35 --> Output Class Initialized
INFO - 2017-07-21 14:31:35 --> Security Class Initialized
DEBUG - 2017-07-21 14:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:31:35 --> Input Class Initialized
INFO - 2017-07-21 14:31:35 --> Language Class Initialized
INFO - 2017-07-21 14:31:35 --> Loader Class Initialized
INFO - 2017-07-21 14:31:35 --> Helper loaded: common_helper
INFO - 2017-07-21 14:31:35 --> Database Driver Class Initialized
INFO - 2017-07-21 14:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:31:35 --> Email Class Initialized
INFO - 2017-07-21 14:31:35 --> Controller Class Initialized
INFO - 2017-07-21 14:31:35 --> Helper loaded: form_helper
INFO - 2017-07-21 14:31:35 --> Form Validation Class Initialized
INFO - 2017-07-21 14:31:35 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:31:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:31:35 --> Helper loaded: url_helper
INFO - 2017-07-21 14:31:35 --> Model Class Initialized
INFO - 2017-07-21 14:31:35 --> Model Class Initialized
ERROR - 2017-07-21 18:01:35 --> Query error: Unknown column 'agentId' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `isDeleted` =0
AND `agentId` =0
ERROR - 2017-07-21 18:01:35 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 18:01:35 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 14:35:02 --> Config Class Initialized
INFO - 2017-07-21 14:35:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:35:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:35:02 --> Utf8 Class Initialized
INFO - 2017-07-21 14:35:02 --> URI Class Initialized
INFO - 2017-07-21 14:35:02 --> Router Class Initialized
INFO - 2017-07-21 14:35:02 --> Output Class Initialized
INFO - 2017-07-21 14:35:02 --> Security Class Initialized
DEBUG - 2017-07-21 14:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:35:02 --> Input Class Initialized
INFO - 2017-07-21 14:35:02 --> Language Class Initialized
INFO - 2017-07-21 14:35:02 --> Loader Class Initialized
INFO - 2017-07-21 14:35:02 --> Helper loaded: common_helper
INFO - 2017-07-21 14:35:02 --> Database Driver Class Initialized
INFO - 2017-07-21 14:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:35:02 --> Email Class Initialized
INFO - 2017-07-21 14:35:02 --> Controller Class Initialized
INFO - 2017-07-21 14:35:02 --> Helper loaded: form_helper
INFO - 2017-07-21 14:35:02 --> Form Validation Class Initialized
INFO - 2017-07-21 14:35:02 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:35:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:35:02 --> Helper loaded: url_helper
INFO - 2017-07-21 14:35:02 --> Model Class Initialized
INFO - 2017-07-21 14:35:02 --> Model Class Initialized
INFO - 2017-07-21 18:05:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:05:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:05:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Invalid argument supplied for foreach()
ERROR - 2017-07-21 18:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 46
ERROR - 2017-07-21 18:05:02 --> Undefined variable: bloodGroup
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined variable: bloodGroup C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 55
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$age
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 56
ERROR - 2017-07-21 18:05:02 --> Undefined property: stdClass::$address
ERROR - 2017-07-21 18:05:02 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 57
INFO - 2017-07-21 18:05:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:05:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:05:02 --> Final output sent to browser
DEBUG - 2017-07-21 18:05:02 --> Total execution time: 0.1084
INFO - 2017-07-21 14:36:17 --> Config Class Initialized
INFO - 2017-07-21 14:36:17 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:36:17 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:36:17 --> Utf8 Class Initialized
INFO - 2017-07-21 14:36:17 --> URI Class Initialized
INFO - 2017-07-21 14:36:17 --> Router Class Initialized
INFO - 2017-07-21 14:36:17 --> Output Class Initialized
INFO - 2017-07-21 14:36:17 --> Security Class Initialized
DEBUG - 2017-07-21 14:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:36:17 --> Input Class Initialized
INFO - 2017-07-21 14:36:17 --> Language Class Initialized
INFO - 2017-07-21 14:36:17 --> Loader Class Initialized
INFO - 2017-07-21 14:36:17 --> Helper loaded: common_helper
INFO - 2017-07-21 14:36:17 --> Database Driver Class Initialized
INFO - 2017-07-21 14:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:36:17 --> Email Class Initialized
INFO - 2017-07-21 14:36:17 --> Controller Class Initialized
INFO - 2017-07-21 14:36:17 --> Helper loaded: form_helper
INFO - 2017-07-21 14:36:17 --> Form Validation Class Initialized
INFO - 2017-07-21 14:36:17 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:36:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:36:17 --> Helper loaded: url_helper
INFO - 2017-07-21 14:36:17 --> Model Class Initialized
INFO - 2017-07-21 14:36:17 --> Model Class Initialized
INFO - 2017-07-21 18:06:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:06:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:06:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:06:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:06:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:06:17 --> Final output sent to browser
DEBUG - 2017-07-21 18:06:17 --> Total execution time: 0.0495
INFO - 2017-07-21 14:37:38 --> Config Class Initialized
INFO - 2017-07-21 14:37:38 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:37:38 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:37:38 --> Utf8 Class Initialized
INFO - 2017-07-21 14:37:38 --> URI Class Initialized
INFO - 2017-07-21 14:37:38 --> Router Class Initialized
INFO - 2017-07-21 14:37:38 --> Output Class Initialized
INFO - 2017-07-21 14:37:38 --> Security Class Initialized
DEBUG - 2017-07-21 14:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:37:38 --> Input Class Initialized
INFO - 2017-07-21 14:37:38 --> Language Class Initialized
INFO - 2017-07-21 14:37:38 --> Loader Class Initialized
INFO - 2017-07-21 14:37:38 --> Helper loaded: common_helper
INFO - 2017-07-21 14:37:38 --> Database Driver Class Initialized
INFO - 2017-07-21 14:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:37:38 --> Email Class Initialized
INFO - 2017-07-21 14:37:38 --> Controller Class Initialized
INFO - 2017-07-21 14:37:38 --> Helper loaded: form_helper
INFO - 2017-07-21 14:37:38 --> Form Validation Class Initialized
INFO - 2017-07-21 14:37:38 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:37:38 --> Helper loaded: url_helper
INFO - 2017-07-21 14:37:38 --> Model Class Initialized
INFO - 2017-07-21 14:37:38 --> Model Class Initialized
INFO - 2017-07-21 18:07:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:07:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:07:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:07:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:07:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:07:38 --> Final output sent to browser
DEBUG - 2017-07-21 18:07:38 --> Total execution time: 0.0474
INFO - 2017-07-21 14:40:32 --> Config Class Initialized
INFO - 2017-07-21 14:40:32 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:40:32 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:40:32 --> Utf8 Class Initialized
INFO - 2017-07-21 14:40:32 --> URI Class Initialized
INFO - 2017-07-21 14:40:32 --> Router Class Initialized
INFO - 2017-07-21 14:40:32 --> Output Class Initialized
INFO - 2017-07-21 14:40:32 --> Security Class Initialized
DEBUG - 2017-07-21 14:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:40:32 --> Input Class Initialized
INFO - 2017-07-21 14:40:32 --> Language Class Initialized
INFO - 2017-07-21 14:40:32 --> Loader Class Initialized
INFO - 2017-07-21 14:40:32 --> Helper loaded: common_helper
INFO - 2017-07-21 14:40:32 --> Database Driver Class Initialized
INFO - 2017-07-21 14:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:40:32 --> Email Class Initialized
INFO - 2017-07-21 14:40:32 --> Controller Class Initialized
INFO - 2017-07-21 14:40:32 --> Helper loaded: form_helper
INFO - 2017-07-21 14:40:32 --> Form Validation Class Initialized
INFO - 2017-07-21 14:40:32 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:40:32 --> Helper loaded: url_helper
INFO - 2017-07-21 14:40:32 --> Model Class Initialized
INFO - 2017-07-21 14:40:32 --> Model Class Initialized
INFO - 2017-07-21 18:10:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:10:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:10:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:10:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:10:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:10:32 --> Final output sent to browser
DEBUG - 2017-07-21 18:10:32 --> Total execution time: 0.0736
INFO - 2017-07-21 14:41:43 --> Config Class Initialized
INFO - 2017-07-21 14:41:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:41:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:41:43 --> Utf8 Class Initialized
INFO - 2017-07-21 14:41:43 --> URI Class Initialized
INFO - 2017-07-21 14:41:43 --> Router Class Initialized
INFO - 2017-07-21 14:41:43 --> Output Class Initialized
INFO - 2017-07-21 14:41:43 --> Security Class Initialized
DEBUG - 2017-07-21 14:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:41:43 --> Input Class Initialized
INFO - 2017-07-21 14:41:43 --> Language Class Initialized
INFO - 2017-07-21 14:41:43 --> Loader Class Initialized
INFO - 2017-07-21 14:41:43 --> Helper loaded: common_helper
INFO - 2017-07-21 14:41:43 --> Database Driver Class Initialized
INFO - 2017-07-21 14:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:41:43 --> Email Class Initialized
INFO - 2017-07-21 14:41:43 --> Controller Class Initialized
INFO - 2017-07-21 14:41:43 --> Helper loaded: form_helper
INFO - 2017-07-21 14:41:43 --> Form Validation Class Initialized
INFO - 2017-07-21 14:41:43 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:41:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:41:43 --> Helper loaded: url_helper
INFO - 2017-07-21 14:41:43 --> Model Class Initialized
INFO - 2017-07-21 14:41:43 --> Model Class Initialized
INFO - 2017-07-21 18:11:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:11:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:11:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:11:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:11:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:11:43 --> Final output sent to browser
DEBUG - 2017-07-21 18:11:43 --> Total execution time: 0.0498
INFO - 2017-07-21 14:41:47 --> Config Class Initialized
INFO - 2017-07-21 14:41:47 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:41:47 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:41:47 --> Utf8 Class Initialized
INFO - 2017-07-21 14:41:47 --> URI Class Initialized
INFO - 2017-07-21 14:41:47 --> Router Class Initialized
INFO - 2017-07-21 14:41:47 --> Output Class Initialized
INFO - 2017-07-21 14:41:47 --> Security Class Initialized
DEBUG - 2017-07-21 14:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:41:47 --> Input Class Initialized
INFO - 2017-07-21 14:41:47 --> Language Class Initialized
INFO - 2017-07-21 14:41:47 --> Loader Class Initialized
INFO - 2017-07-21 14:41:47 --> Helper loaded: common_helper
INFO - 2017-07-21 14:41:47 --> Database Driver Class Initialized
INFO - 2017-07-21 14:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:41:47 --> Email Class Initialized
INFO - 2017-07-21 14:41:47 --> Controller Class Initialized
INFO - 2017-07-21 14:41:47 --> Helper loaded: form_helper
INFO - 2017-07-21 14:41:47 --> Form Validation Class Initialized
INFO - 2017-07-21 14:41:47 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:41:47 --> Helper loaded: url_helper
INFO - 2017-07-21 14:41:47 --> Model Class Initialized
INFO - 2017-07-21 14:41:47 --> Model Class Initialized
ERROR - 2017-07-21 18:11:47 --> Use of undefined constant TBL_BLOODGROUPS - assumed 'TBL_BLOODGROUPS'
ERROR - 2017-07-21 18:11:47 --> Severity: Notice --> Use of undefined constant TBL_BLOODGROUPS - assumed 'TBL_BLOODGROUPS' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 74
ERROR - 2017-07-21 18:11:47 --> Query error: Table 'flicknews.tbl_bloodgroups' doesn't exist - Invalid query: SELECT *
FROM `TBL_BLOODGROUPS`
WHERE `isDeleted` =0
ERROR - 2017-07-21 18:11:47 --> Call to a member function result() on a non-object
ERROR - 2017-07-21 18:11:47 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-21 14:43:31 --> Config Class Initialized
INFO - 2017-07-21 14:43:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:43:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:43:31 --> Utf8 Class Initialized
INFO - 2017-07-21 14:43:31 --> URI Class Initialized
INFO - 2017-07-21 14:43:31 --> Router Class Initialized
INFO - 2017-07-21 14:43:31 --> Output Class Initialized
INFO - 2017-07-21 14:43:31 --> Security Class Initialized
DEBUG - 2017-07-21 14:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:43:31 --> Input Class Initialized
INFO - 2017-07-21 14:43:31 --> Language Class Initialized
INFO - 2017-07-21 14:43:31 --> Loader Class Initialized
INFO - 2017-07-21 14:43:31 --> Helper loaded: common_helper
INFO - 2017-07-21 14:43:31 --> Database Driver Class Initialized
INFO - 2017-07-21 14:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:43:31 --> Email Class Initialized
INFO - 2017-07-21 14:43:31 --> Controller Class Initialized
INFO - 2017-07-21 14:43:31 --> Helper loaded: form_helper
INFO - 2017-07-21 14:43:31 --> Form Validation Class Initialized
INFO - 2017-07-21 14:43:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:43:31 --> Helper loaded: url_helper
INFO - 2017-07-21 14:43:31 --> Model Class Initialized
INFO - 2017-07-21 14:43:31 --> Model Class Initialized
INFO - 2017-07-21 18:13:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:13:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 18:13:31 --> Undefined variable: bloodGroups
ERROR - 2017-07-21 18:13:31 --> Severity: Notice --> Undefined variable: bloodGroups C:\xampp\htdocs\FlickNews\admin\application\views\users\addUser.php 79
INFO - 2017-07-21 18:13:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/addUser.php
INFO - 2017-07-21 18:13:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:13:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:13:31 --> Final output sent to browser
DEBUG - 2017-07-21 18:13:31 --> Total execution time: 0.0519
INFO - 2017-07-21 14:47:32 --> Config Class Initialized
INFO - 2017-07-21 14:47:32 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:32 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:32 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:32 --> URI Class Initialized
INFO - 2017-07-21 14:47:32 --> Router Class Initialized
INFO - 2017-07-21 14:47:32 --> Output Class Initialized
INFO - 2017-07-21 14:47:32 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:32 --> Input Class Initialized
INFO - 2017-07-21 14:47:32 --> Language Class Initialized
INFO - 2017-07-21 14:47:32 --> Loader Class Initialized
INFO - 2017-07-21 14:47:32 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:32 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:32 --> Email Class Initialized
INFO - 2017-07-21 14:47:32 --> Controller Class Initialized
INFO - 2017-07-21 14:47:32 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:32 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:32 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:32 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:32 --> Model Class Initialized
INFO - 2017-07-21 14:47:32 --> Model Class Initialized
INFO - 2017-07-21 18:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/addUser.php
INFO - 2017-07-21 18:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:17:32 --> Final output sent to browser
DEBUG - 2017-07-21 18:17:32 --> Total execution time: 0.0500
INFO - 2017-07-21 14:47:37 --> Config Class Initialized
INFO - 2017-07-21 14:47:37 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:37 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:37 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:37 --> URI Class Initialized
INFO - 2017-07-21 14:47:37 --> Router Class Initialized
INFO - 2017-07-21 14:47:37 --> Output Class Initialized
INFO - 2017-07-21 14:47:37 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:37 --> Input Class Initialized
INFO - 2017-07-21 14:47:37 --> Language Class Initialized
INFO - 2017-07-21 14:47:37 --> Loader Class Initialized
INFO - 2017-07-21 14:47:37 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:37 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:37 --> Email Class Initialized
INFO - 2017-07-21 14:47:37 --> Controller Class Initialized
INFO - 2017-07-21 14:47:37 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:37 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:37 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:37 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:37 --> Model Class Initialized
INFO - 2017-07-21 14:47:37 --> Model Class Initialized
DEBUG - 2017-07-21 18:17:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 18:17:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:47:37 --> Config Class Initialized
INFO - 2017-07-21 14:47:37 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:37 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:37 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:37 --> URI Class Initialized
INFO - 2017-07-21 14:47:37 --> Router Class Initialized
INFO - 2017-07-21 14:47:37 --> Output Class Initialized
INFO - 2017-07-21 14:47:37 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:37 --> Input Class Initialized
INFO - 2017-07-21 14:47:37 --> Language Class Initialized
INFO - 2017-07-21 14:47:37 --> Loader Class Initialized
INFO - 2017-07-21 14:47:37 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:37 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:37 --> Email Class Initialized
INFO - 2017-07-21 14:47:37 --> Controller Class Initialized
INFO - 2017-07-21 14:47:37 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:37 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:37 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:37 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:37 --> Model Class Initialized
INFO - 2017-07-21 14:47:37 --> Model Class Initialized
INFO - 2017-07-21 18:17:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:17:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:17:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:17:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:17:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:17:37 --> Final output sent to browser
DEBUG - 2017-07-21 18:17:37 --> Total execution time: 0.0455
INFO - 2017-07-21 14:47:41 --> Config Class Initialized
INFO - 2017-07-21 14:47:41 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:41 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:41 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:41 --> URI Class Initialized
INFO - 2017-07-21 14:47:41 --> Router Class Initialized
INFO - 2017-07-21 14:47:41 --> Output Class Initialized
INFO - 2017-07-21 14:47:41 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:41 --> Input Class Initialized
INFO - 2017-07-21 14:47:41 --> Language Class Initialized
INFO - 2017-07-21 14:47:41 --> Loader Class Initialized
INFO - 2017-07-21 14:47:41 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:41 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:41 --> Email Class Initialized
INFO - 2017-07-21 14:47:41 --> Controller Class Initialized
INFO - 2017-07-21 14:47:41 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:41 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:41 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:41 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:41 --> Model Class Initialized
INFO - 2017-07-21 14:47:41 --> Model Class Initialized
INFO - 2017-07-21 18:17:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:17:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:17:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/addUser.php
INFO - 2017-07-21 18:17:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:17:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:17:41 --> Final output sent to browser
DEBUG - 2017-07-21 18:17:41 --> Total execution time: 0.0454
INFO - 2017-07-21 14:47:45 --> Config Class Initialized
INFO - 2017-07-21 14:47:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:45 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:45 --> URI Class Initialized
INFO - 2017-07-21 14:47:45 --> Router Class Initialized
INFO - 2017-07-21 14:47:45 --> Output Class Initialized
INFO - 2017-07-21 14:47:45 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:45 --> Input Class Initialized
INFO - 2017-07-21 14:47:45 --> Language Class Initialized
INFO - 2017-07-21 14:47:45 --> Loader Class Initialized
INFO - 2017-07-21 14:47:45 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:45 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:45 --> Email Class Initialized
INFO - 2017-07-21 14:47:45 --> Controller Class Initialized
INFO - 2017-07-21 14:47:45 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:45 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:45 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:45 --> Model Class Initialized
INFO - 2017-07-21 14:47:45 --> Model Class Initialized
DEBUG - 2017-07-21 18:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 18:17:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:47:45 --> Config Class Initialized
INFO - 2017-07-21 14:47:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:45 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:45 --> URI Class Initialized
INFO - 2017-07-21 14:47:45 --> Router Class Initialized
INFO - 2017-07-21 14:47:45 --> Output Class Initialized
INFO - 2017-07-21 14:47:45 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:45 --> Input Class Initialized
INFO - 2017-07-21 14:47:45 --> Language Class Initialized
INFO - 2017-07-21 14:47:45 --> Loader Class Initialized
INFO - 2017-07-21 14:47:45 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:45 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:45 --> Email Class Initialized
INFO - 2017-07-21 14:47:45 --> Controller Class Initialized
INFO - 2017-07-21 14:47:45 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:45 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:45 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:45 --> Model Class Initialized
INFO - 2017-07-21 14:47:45 --> Model Class Initialized
INFO - 2017-07-21 18:17:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:17:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:17:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:17:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:17:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:17:45 --> Final output sent to browser
DEBUG - 2017-07-21 18:17:45 --> Total execution time: 0.0468
INFO - 2017-07-21 14:47:47 --> Config Class Initialized
INFO - 2017-07-21 14:47:47 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:47 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:47 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:47 --> URI Class Initialized
INFO - 2017-07-21 14:47:47 --> Router Class Initialized
INFO - 2017-07-21 14:47:47 --> Output Class Initialized
INFO - 2017-07-21 14:47:47 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:47 --> Input Class Initialized
INFO - 2017-07-21 14:47:47 --> Language Class Initialized
INFO - 2017-07-21 14:47:47 --> Loader Class Initialized
INFO - 2017-07-21 14:47:47 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:47 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:47 --> Email Class Initialized
INFO - 2017-07-21 14:47:47 --> Controller Class Initialized
INFO - 2017-07-21 14:47:47 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:47 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:47 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:47 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:47 --> Model Class Initialized
INFO - 2017-07-21 14:47:47 --> Model Class Initialized
INFO - 2017-07-21 18:17:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:17:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:17:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/addUser.php
INFO - 2017-07-21 18:17:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:17:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:17:47 --> Final output sent to browser
DEBUG - 2017-07-21 18:17:47 --> Total execution time: 0.0480
INFO - 2017-07-21 14:47:50 --> Config Class Initialized
INFO - 2017-07-21 14:47:50 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:50 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:50 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:50 --> URI Class Initialized
INFO - 2017-07-21 14:47:50 --> Router Class Initialized
INFO - 2017-07-21 14:47:50 --> Output Class Initialized
INFO - 2017-07-21 14:47:50 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:50 --> Input Class Initialized
INFO - 2017-07-21 14:47:50 --> Language Class Initialized
INFO - 2017-07-21 14:47:50 --> Loader Class Initialized
INFO - 2017-07-21 14:47:50 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:50 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:50 --> Email Class Initialized
INFO - 2017-07-21 14:47:50 --> Controller Class Initialized
INFO - 2017-07-21 14:47:50 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:50 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:50 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:50 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:50 --> Model Class Initialized
INFO - 2017-07-21 14:47:50 --> Model Class Initialized
DEBUG - 2017-07-21 18:17:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 18:17:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:47:50 --> Config Class Initialized
INFO - 2017-07-21 14:47:50 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:47:50 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:47:50 --> Utf8 Class Initialized
INFO - 2017-07-21 14:47:50 --> URI Class Initialized
INFO - 2017-07-21 14:47:50 --> Router Class Initialized
INFO - 2017-07-21 14:47:50 --> Output Class Initialized
INFO - 2017-07-21 14:47:50 --> Security Class Initialized
DEBUG - 2017-07-21 14:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:47:50 --> Input Class Initialized
INFO - 2017-07-21 14:47:50 --> Language Class Initialized
INFO - 2017-07-21 14:47:50 --> Loader Class Initialized
INFO - 2017-07-21 14:47:50 --> Helper loaded: common_helper
INFO - 2017-07-21 14:47:51 --> Database Driver Class Initialized
INFO - 2017-07-21 14:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:47:51 --> Email Class Initialized
INFO - 2017-07-21 14:47:51 --> Controller Class Initialized
INFO - 2017-07-21 14:47:51 --> Helper loaded: form_helper
INFO - 2017-07-21 14:47:51 --> Form Validation Class Initialized
INFO - 2017-07-21 14:47:51 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:47:51 --> Helper loaded: url_helper
INFO - 2017-07-21 14:47:51 --> Model Class Initialized
INFO - 2017-07-21 14:47:51 --> Model Class Initialized
INFO - 2017-07-21 18:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:17:51 --> Final output sent to browser
DEBUG - 2017-07-21 18:17:51 --> Total execution time: 0.0520
INFO - 2017-07-21 14:49:16 --> Config Class Initialized
INFO - 2017-07-21 14:49:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:49:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:49:16 --> Utf8 Class Initialized
INFO - 2017-07-21 14:49:16 --> URI Class Initialized
INFO - 2017-07-21 14:49:16 --> Router Class Initialized
INFO - 2017-07-21 14:49:16 --> Output Class Initialized
INFO - 2017-07-21 14:49:16 --> Security Class Initialized
DEBUG - 2017-07-21 14:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:49:16 --> Input Class Initialized
INFO - 2017-07-21 14:49:16 --> Language Class Initialized
INFO - 2017-07-21 14:49:16 --> Loader Class Initialized
INFO - 2017-07-21 14:49:16 --> Helper loaded: common_helper
INFO - 2017-07-21 14:49:16 --> Database Driver Class Initialized
INFO - 2017-07-21 14:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:49:16 --> Email Class Initialized
INFO - 2017-07-21 14:49:16 --> Controller Class Initialized
INFO - 2017-07-21 14:49:16 --> Helper loaded: form_helper
INFO - 2017-07-21 14:49:16 --> Form Validation Class Initialized
INFO - 2017-07-21 14:49:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:49:16 --> Helper loaded: url_helper
INFO - 2017-07-21 14:49:16 --> Model Class Initialized
INFO - 2017-07-21 14:49:16 --> Model Class Initialized
INFO - 2017-07-21 18:19:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:19:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:19:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/addUser.php
INFO - 2017-07-21 18:19:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:19:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:19:16 --> Final output sent to browser
DEBUG - 2017-07-21 18:19:16 --> Total execution time: 0.0491
INFO - 2017-07-21 14:49:36 --> Config Class Initialized
INFO - 2017-07-21 14:49:36 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:49:36 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:49:36 --> Utf8 Class Initialized
INFO - 2017-07-21 14:49:36 --> URI Class Initialized
INFO - 2017-07-21 14:49:36 --> Router Class Initialized
INFO - 2017-07-21 14:49:36 --> Output Class Initialized
INFO - 2017-07-21 14:49:36 --> Security Class Initialized
DEBUG - 2017-07-21 14:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:49:36 --> Input Class Initialized
INFO - 2017-07-21 14:49:36 --> Language Class Initialized
INFO - 2017-07-21 14:49:36 --> Loader Class Initialized
INFO - 2017-07-21 14:49:36 --> Helper loaded: common_helper
INFO - 2017-07-21 14:49:36 --> Database Driver Class Initialized
INFO - 2017-07-21 14:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:49:36 --> Email Class Initialized
INFO - 2017-07-21 14:49:36 --> Controller Class Initialized
INFO - 2017-07-21 14:49:36 --> Helper loaded: form_helper
INFO - 2017-07-21 14:49:36 --> Form Validation Class Initialized
INFO - 2017-07-21 14:49:36 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:49:36 --> Helper loaded: url_helper
INFO - 2017-07-21 14:49:36 --> Model Class Initialized
INFO - 2017-07-21 14:49:36 --> Model Class Initialized
DEBUG - 2017-07-21 18:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 18:19:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 14:49:36 --> Config Class Initialized
INFO - 2017-07-21 14:49:36 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:49:36 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:49:36 --> Utf8 Class Initialized
INFO - 2017-07-21 14:49:36 --> URI Class Initialized
INFO - 2017-07-21 14:49:36 --> Router Class Initialized
INFO - 2017-07-21 14:49:36 --> Output Class Initialized
INFO - 2017-07-21 14:49:36 --> Security Class Initialized
DEBUG - 2017-07-21 14:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:49:36 --> Input Class Initialized
INFO - 2017-07-21 14:49:36 --> Language Class Initialized
INFO - 2017-07-21 14:49:36 --> Loader Class Initialized
INFO - 2017-07-21 14:49:36 --> Helper loaded: common_helper
INFO - 2017-07-21 14:49:36 --> Database Driver Class Initialized
INFO - 2017-07-21 14:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:49:36 --> Email Class Initialized
INFO - 2017-07-21 14:49:36 --> Controller Class Initialized
INFO - 2017-07-21 14:49:36 --> Helper loaded: form_helper
INFO - 2017-07-21 14:49:36 --> Form Validation Class Initialized
INFO - 2017-07-21 14:49:36 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:49:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:49:36 --> Helper loaded: url_helper
INFO - 2017-07-21 14:49:36 --> Model Class Initialized
INFO - 2017-07-21 14:49:36 --> Model Class Initialized
INFO - 2017-07-21 18:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:19:36 --> Final output sent to browser
DEBUG - 2017-07-21 18:19:36 --> Total execution time: 0.0547
INFO - 2017-07-21 14:53:23 --> Config Class Initialized
INFO - 2017-07-21 14:53:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:53:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:53:23 --> Utf8 Class Initialized
INFO - 2017-07-21 14:53:23 --> URI Class Initialized
INFO - 2017-07-21 14:53:23 --> Router Class Initialized
INFO - 2017-07-21 14:53:23 --> Output Class Initialized
INFO - 2017-07-21 14:53:23 --> Security Class Initialized
DEBUG - 2017-07-21 14:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:53:23 --> Input Class Initialized
INFO - 2017-07-21 14:53:23 --> Language Class Initialized
INFO - 2017-07-21 14:53:23 --> Loader Class Initialized
INFO - 2017-07-21 14:53:23 --> Helper loaded: common_helper
INFO - 2017-07-21 14:53:23 --> Database Driver Class Initialized
INFO - 2017-07-21 14:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:53:23 --> Email Class Initialized
INFO - 2017-07-21 14:53:23 --> Controller Class Initialized
INFO - 2017-07-21 14:53:23 --> Helper loaded: form_helper
INFO - 2017-07-21 14:53:23 --> Form Validation Class Initialized
INFO - 2017-07-21 14:53:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:53:23 --> Helper loaded: url_helper
INFO - 2017-07-21 14:53:23 --> Model Class Initialized
INFO - 2017-07-21 14:53:23 --> Model Class Initialized
INFO - 2017-07-21 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:23:23 --> Final output sent to browser
DEBUG - 2017-07-21 18:23:23 --> Total execution time: 0.0513
INFO - 2017-07-21 14:53:41 --> Config Class Initialized
INFO - 2017-07-21 14:53:41 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:53:41 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:53:41 --> Utf8 Class Initialized
INFO - 2017-07-21 14:53:41 --> URI Class Initialized
INFO - 2017-07-21 14:53:41 --> Router Class Initialized
INFO - 2017-07-21 14:53:41 --> Output Class Initialized
INFO - 2017-07-21 14:53:41 --> Security Class Initialized
DEBUG - 2017-07-21 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:53:41 --> Input Class Initialized
INFO - 2017-07-21 14:53:41 --> Language Class Initialized
INFO - 2017-07-21 14:53:41 --> Loader Class Initialized
INFO - 2017-07-21 14:53:41 --> Helper loaded: common_helper
INFO - 2017-07-21 14:53:41 --> Database Driver Class Initialized
INFO - 2017-07-21 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:53:41 --> Email Class Initialized
INFO - 2017-07-21 14:53:41 --> Controller Class Initialized
INFO - 2017-07-21 14:53:41 --> Helper loaded: form_helper
INFO - 2017-07-21 14:53:41 --> Form Validation Class Initialized
INFO - 2017-07-21 14:53:41 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:53:41 --> Helper loaded: url_helper
INFO - 2017-07-21 14:53:41 --> Model Class Initialized
INFO - 2017-07-21 14:53:41 --> Model Class Initialized
INFO - 2017-07-21 14:53:42 --> Config Class Initialized
INFO - 2017-07-21 14:53:42 --> Hooks Class Initialized
DEBUG - 2017-07-21 14:53:42 --> UTF-8 Support Enabled
INFO - 2017-07-21 14:53:42 --> Utf8 Class Initialized
INFO - 2017-07-21 14:53:42 --> URI Class Initialized
INFO - 2017-07-21 14:53:42 --> Router Class Initialized
INFO - 2017-07-21 14:53:42 --> Output Class Initialized
INFO - 2017-07-21 14:53:42 --> Security Class Initialized
DEBUG - 2017-07-21 14:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 14:53:42 --> Input Class Initialized
INFO - 2017-07-21 14:53:42 --> Language Class Initialized
INFO - 2017-07-21 14:53:42 --> Loader Class Initialized
INFO - 2017-07-21 14:53:42 --> Helper loaded: common_helper
INFO - 2017-07-21 14:53:42 --> Database Driver Class Initialized
INFO - 2017-07-21 14:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 14:53:42 --> Email Class Initialized
INFO - 2017-07-21 14:53:42 --> Controller Class Initialized
INFO - 2017-07-21 14:53:42 --> Helper loaded: form_helper
INFO - 2017-07-21 14:53:42 --> Form Validation Class Initialized
INFO - 2017-07-21 14:53:42 --> Helper loaded: email_helper
DEBUG - 2017-07-21 14:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 14:53:42 --> Helper loaded: url_helper
INFO - 2017-07-21 14:53:42 --> Model Class Initialized
INFO - 2017-07-21 14:53:42 --> Model Class Initialized
INFO - 2017-07-21 18:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:23:42 --> Final output sent to browser
DEBUG - 2017-07-21 18:23:42 --> Total execution time: 0.0492
INFO - 2017-07-21 15:00:08 --> Config Class Initialized
INFO - 2017-07-21 15:00:08 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:00:08 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:00:08 --> Utf8 Class Initialized
INFO - 2017-07-21 15:00:08 --> URI Class Initialized
INFO - 2017-07-21 15:00:08 --> Router Class Initialized
INFO - 2017-07-21 15:00:08 --> Output Class Initialized
INFO - 2017-07-21 15:00:08 --> Security Class Initialized
DEBUG - 2017-07-21 15:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:00:08 --> Input Class Initialized
INFO - 2017-07-21 15:00:08 --> Language Class Initialized
INFO - 2017-07-21 15:00:08 --> Loader Class Initialized
INFO - 2017-07-21 15:00:08 --> Helper loaded: common_helper
INFO - 2017-07-21 15:00:08 --> Database Driver Class Initialized
INFO - 2017-07-21 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:00:08 --> Email Class Initialized
INFO - 2017-07-21 15:00:08 --> Controller Class Initialized
INFO - 2017-07-21 15:00:08 --> Helper loaded: form_helper
INFO - 2017-07-21 15:00:08 --> Form Validation Class Initialized
INFO - 2017-07-21 15:00:08 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:00:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:00:08 --> Helper loaded: url_helper
INFO - 2017-07-21 15:00:08 --> Model Class Initialized
INFO - 2017-07-21 15:00:08 --> Model Class Initialized
INFO - 2017-07-21 18:30:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:30:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:30:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:30:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:30:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:30:08 --> Final output sent to browser
DEBUG - 2017-07-21 18:30:08 --> Total execution time: 0.0476
INFO - 2017-07-21 15:00:11 --> Config Class Initialized
INFO - 2017-07-21 15:00:11 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:00:11 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:00:11 --> Utf8 Class Initialized
INFO - 2017-07-21 15:00:11 --> URI Class Initialized
INFO - 2017-07-21 15:00:11 --> Router Class Initialized
INFO - 2017-07-21 15:00:11 --> Output Class Initialized
INFO - 2017-07-21 15:00:11 --> Security Class Initialized
DEBUG - 2017-07-21 15:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:00:11 --> Input Class Initialized
INFO - 2017-07-21 15:00:11 --> Language Class Initialized
INFO - 2017-07-21 15:00:11 --> Loader Class Initialized
INFO - 2017-07-21 15:00:11 --> Helper loaded: common_helper
INFO - 2017-07-21 15:00:11 --> Database Driver Class Initialized
INFO - 2017-07-21 15:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:00:11 --> Email Class Initialized
INFO - 2017-07-21 15:00:11 --> Controller Class Initialized
INFO - 2017-07-21 15:00:11 --> Helper loaded: form_helper
INFO - 2017-07-21 15:00:11 --> Form Validation Class Initialized
INFO - 2017-07-21 15:00:11 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:00:11 --> Helper loaded: url_helper
INFO - 2017-07-21 15:00:11 --> Model Class Initialized
INFO - 2017-07-21 15:00:11 --> Model Class Initialized
INFO - 2017-07-21 18:30:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:30:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:30:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:30:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:30:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:30:11 --> Final output sent to browser
DEBUG - 2017-07-21 18:30:11 --> Total execution time: 0.0584
INFO - 2017-07-21 15:00:22 --> Config Class Initialized
INFO - 2017-07-21 15:00:22 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:00:22 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:00:22 --> Utf8 Class Initialized
INFO - 2017-07-21 15:00:22 --> URI Class Initialized
INFO - 2017-07-21 15:00:22 --> Router Class Initialized
INFO - 2017-07-21 15:00:22 --> Output Class Initialized
INFO - 2017-07-21 15:00:22 --> Security Class Initialized
DEBUG - 2017-07-21 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:00:22 --> Input Class Initialized
INFO - 2017-07-21 15:00:22 --> Language Class Initialized
INFO - 2017-07-21 15:00:22 --> Loader Class Initialized
INFO - 2017-07-21 15:00:22 --> Helper loaded: common_helper
INFO - 2017-07-21 15:00:22 --> Database Driver Class Initialized
INFO - 2017-07-21 15:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:00:22 --> Email Class Initialized
INFO - 2017-07-21 15:00:22 --> Controller Class Initialized
INFO - 2017-07-21 15:00:22 --> Helper loaded: form_helper
INFO - 2017-07-21 15:00:22 --> Form Validation Class Initialized
INFO - 2017-07-21 15:00:22 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:00:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:00:22 --> Helper loaded: url_helper
INFO - 2017-07-21 15:00:22 --> Model Class Initialized
INFO - 2017-07-21 15:00:22 --> Model Class Initialized
INFO - 2017-07-21 18:30:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:30:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:30:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:30:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:30:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:30:22 --> Final output sent to browser
DEBUG - 2017-07-21 18:30:22 --> Total execution time: 0.0559
INFO - 2017-07-21 15:01:06 --> Config Class Initialized
INFO - 2017-07-21 15:01:06 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:01:06 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:01:06 --> Utf8 Class Initialized
INFO - 2017-07-21 15:01:06 --> URI Class Initialized
INFO - 2017-07-21 15:01:06 --> Router Class Initialized
INFO - 2017-07-21 15:01:06 --> Output Class Initialized
INFO - 2017-07-21 15:01:06 --> Security Class Initialized
DEBUG - 2017-07-21 15:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:01:06 --> Input Class Initialized
INFO - 2017-07-21 15:01:06 --> Language Class Initialized
INFO - 2017-07-21 15:01:06 --> Loader Class Initialized
INFO - 2017-07-21 15:01:06 --> Helper loaded: common_helper
INFO - 2017-07-21 15:01:06 --> Database Driver Class Initialized
INFO - 2017-07-21 15:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:01:06 --> Email Class Initialized
INFO - 2017-07-21 15:01:06 --> Controller Class Initialized
INFO - 2017-07-21 15:01:07 --> Helper loaded: form_helper
INFO - 2017-07-21 15:01:07 --> Form Validation Class Initialized
INFO - 2017-07-21 15:01:07 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:01:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:01:07 --> Helper loaded: url_helper
INFO - 2017-07-21 15:01:07 --> Model Class Initialized
INFO - 2017-07-21 15:01:07 --> Model Class Initialized
INFO - 2017-07-21 18:31:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:31:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:31:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 18:31:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 18:31:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:31:07 --> Final output sent to browser
DEBUG - 2017-07-21 18:31:07 --> Total execution time: 0.0490
INFO - 2017-07-21 15:01:08 --> Config Class Initialized
INFO - 2017-07-21 15:01:08 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:01:08 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:01:08 --> Utf8 Class Initialized
INFO - 2017-07-21 15:01:08 --> URI Class Initialized
INFO - 2017-07-21 15:01:08 --> Router Class Initialized
INFO - 2017-07-21 15:01:08 --> Output Class Initialized
INFO - 2017-07-21 15:01:08 --> Security Class Initialized
DEBUG - 2017-07-21 15:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:01:08 --> Input Class Initialized
INFO - 2017-07-21 15:01:08 --> Language Class Initialized
INFO - 2017-07-21 15:01:08 --> Loader Class Initialized
INFO - 2017-07-21 15:01:08 --> Helper loaded: common_helper
INFO - 2017-07-21 15:01:08 --> Database Driver Class Initialized
INFO - 2017-07-21 15:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:01:08 --> Email Class Initialized
INFO - 2017-07-21 15:01:08 --> Controller Class Initialized
INFO - 2017-07-21 15:01:08 --> Helper loaded: form_helper
INFO - 2017-07-21 15:01:08 --> Form Validation Class Initialized
INFO - 2017-07-21 15:01:08 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:01:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:01:08 --> Helper loaded: url_helper
INFO - 2017-07-21 15:01:08 --> Model Class Initialized
INFO - 2017-07-21 15:01:08 --> Model Class Initialized
INFO - 2017-07-21 18:31:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 15:04:09 --> Config Class Initialized
INFO - 2017-07-21 15:04:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:04:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:04:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:04:09 --> URI Class Initialized
INFO - 2017-07-21 15:04:09 --> Router Class Initialized
INFO - 2017-07-21 15:04:09 --> Output Class Initialized
INFO - 2017-07-21 15:04:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:04:09 --> Input Class Initialized
INFO - 2017-07-21 15:04:09 --> Language Class Initialized
INFO - 2017-07-21 15:04:09 --> Loader Class Initialized
INFO - 2017-07-21 15:04:09 --> Helper loaded: common_helper
INFO - 2017-07-21 15:04:09 --> Database Driver Class Initialized
INFO - 2017-07-21 15:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:04:09 --> Email Class Initialized
INFO - 2017-07-21 15:04:09 --> Controller Class Initialized
INFO - 2017-07-21 15:04:09 --> Helper loaded: form_helper
INFO - 2017-07-21 15:04:09 --> Form Validation Class Initialized
INFO - 2017-07-21 15:04:09 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:04:09 --> Helper loaded: url_helper
INFO - 2017-07-21 15:04:09 --> Model Class Initialized
INFO - 2017-07-21 15:04:09 --> Model Class Initialized
INFO - 2017-07-21 18:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 18:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 18:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-21 18:34:09 --> Undefined variable: events
ERROR - 2017-07-21 18:34:09 --> Severity: Notice --> Undefined variable: events C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 51
INFO - 2017-07-21 18:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 18:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 18:34:09 --> Final output sent to browser
DEBUG - 2017-07-21 18:34:09 --> Total execution time: 0.0521
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
INFO - 2017-07-21 15:35:43 --> Loader Class Initialized
INFO - 2017-07-21 15:35:43 --> Helper loaded: common_helper
INFO - 2017-07-21 15:35:43 --> Database Driver Class Initialized
INFO - 2017-07-21 15:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:35:43 --> Email Class Initialized
INFO - 2017-07-21 15:35:43 --> Controller Class Initialized
INFO - 2017-07-21 15:35:43 --> Helper loaded: form_helper
INFO - 2017-07-21 15:35:43 --> Form Validation Class Initialized
INFO - 2017-07-21 15:35:43 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:35:43 --> Helper loaded: url_helper
INFO - 2017-07-21 15:35:43 --> Model Class Initialized
INFO - 2017-07-21 15:35:43 --> Model Class Initialized
INFO - 2017-07-21 19:05:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:05:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:05:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Undefined variable: event
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:05:43 --> Trying to get property of non-object
ERROR - 2017-07-21 19:05:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
INFO - 2017-07-21 19:05:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:05:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:05:43 --> Final output sent to browser
DEBUG - 2017-07-21 19:05:43 --> Total execution time: 0.0672
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:35:43 --> Config Class Initialized
INFO - 2017-07-21 15:35:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:35:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:35:43 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> URI Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
INFO - 2017-07-21 15:35:43 --> Router Class Initialized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Output Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
INFO - 2017-07-21 15:35:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:35:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:35:43 --> Input Class Initialized
INFO - 2017-07-21 15:35:43 --> Language Class Initialized
ERROR - 2017-07-21 15:35:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
INFO - 2017-07-21 15:36:44 --> Loader Class Initialized
INFO - 2017-07-21 15:36:44 --> Helper loaded: common_helper
INFO - 2017-07-21 15:36:44 --> Database Driver Class Initialized
INFO - 2017-07-21 15:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:36:44 --> Email Class Initialized
INFO - 2017-07-21 15:36:44 --> Controller Class Initialized
INFO - 2017-07-21 15:36:44 --> Helper loaded: form_helper
INFO - 2017-07-21 15:36:44 --> Form Validation Class Initialized
INFO - 2017-07-21 15:36:44 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:36:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:36:44 --> Helper loaded: url_helper
INFO - 2017-07-21 15:36:44 --> Model Class Initialized
INFO - 2017-07-21 15:36:44 --> Model Class Initialized
INFO - 2017-07-21 19:06:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:06:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:06:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Undefined variable: event
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:44 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
INFO - 2017-07-21 19:06:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:06:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:06:44 --> Final output sent to browser
DEBUG - 2017-07-21 19:06:44 --> Total execution time: 0.0698
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Config Class Initialized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
INFO - 2017-07-21 15:36:44 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:36:44 --> UTF-8 Support Enabled
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:44 --> URI Class Initialized
INFO - 2017-07-21 15:36:44 --> Router Class Initialized
INFO - 2017-07-21 15:36:44 --> Output Class Initialized
INFO - 2017-07-21 15:36:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:44 --> Input Class Initialized
INFO - 2017-07-21 15:36:44 --> Language Class Initialized
ERROR - 2017-07-21 15:36:44 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> Loader Class Initialized
INFO - 2017-07-21 15:36:45 --> Helper loaded: common_helper
INFO - 2017-07-21 15:36:45 --> Database Driver Class Initialized
INFO - 2017-07-21 15:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:36:45 --> Email Class Initialized
INFO - 2017-07-21 15:36:45 --> Controller Class Initialized
INFO - 2017-07-21 15:36:45 --> Helper loaded: form_helper
INFO - 2017-07-21 15:36:45 --> Form Validation Class Initialized
INFO - 2017-07-21 15:36:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:36:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:36:45 --> Helper loaded: url_helper
INFO - 2017-07-21 15:36:45 --> Model Class Initialized
INFO - 2017-07-21 15:36:45 --> Model Class Initialized
INFO - 2017-07-21 19:06:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:06:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:06:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Undefined variable: event
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Undefined variable: event C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
ERROR - 2017-07-21 19:06:45 --> Trying to get property of non-object
ERROR - 2017-07-21 19:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Categories\categories.php 57
INFO - 2017-07-21 19:06:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:06:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:06:45 --> Final output sent to browser
DEBUG - 2017-07-21 19:06:45 --> Total execution time: 0.0638
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:45 --> Config Class Initialized
INFO - 2017-07-21 15:36:45 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
INFO - 2017-07-21 15:36:45 --> URI Class Initialized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Router Class Initialized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Output Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
INFO - 2017-07-21 15:36:45 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
DEBUG - 2017-07-21 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:45 --> Input Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
INFO - 2017-07-21 15:36:45 --> Language Class Initialized
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:36:45 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> Loader Class Initialized
INFO - 2017-07-21 15:36:57 --> Helper loaded: common_helper
INFO - 2017-07-21 15:36:57 --> Database Driver Class Initialized
INFO - 2017-07-21 15:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:36:57 --> Email Class Initialized
INFO - 2017-07-21 15:36:57 --> Controller Class Initialized
INFO - 2017-07-21 15:36:57 --> Helper loaded: form_helper
INFO - 2017-07-21 15:36:57 --> Form Validation Class Initialized
INFO - 2017-07-21 15:36:57 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:36:57 --> Helper loaded: url_helper
INFO - 2017-07-21 15:36:57 --> Model Class Initialized
INFO - 2017-07-21 15:36:57 --> Model Class Initialized
INFO - 2017-07-21 19:06:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:06:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:06:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:06:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:06:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:06:57 --> Final output sent to browser
DEBUG - 2017-07-21 19:06:57 --> Total execution time: 0.0502
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Config Class Initialized
INFO - 2017-07-21 15:36:57 --> Hooks Class Initialized
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:36:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
INFO - 2017-07-21 15:36:57 --> URI Class Initialized
INFO - 2017-07-21 15:36:57 --> Router Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:36:57 --> Output Class Initialized
INFO - 2017-07-21 15:36:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:36:57 --> Input Class Initialized
INFO - 2017-07-21 15:36:57 --> Language Class Initialized
ERROR - 2017-07-21 15:36:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:23 --> Config Class Initialized
INFO - 2017-07-21 15:40:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:23 --> URI Class Initialized
INFO - 2017-07-21 15:40:23 --> Router Class Initialized
INFO - 2017-07-21 15:40:23 --> Output Class Initialized
INFO - 2017-07-21 15:40:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:23 --> Input Class Initialized
INFO - 2017-07-21 15:40:23 --> Language Class Initialized
INFO - 2017-07-21 15:40:23 --> Loader Class Initialized
INFO - 2017-07-21 15:40:23 --> Helper loaded: common_helper
INFO - 2017-07-21 15:40:23 --> Database Driver Class Initialized
INFO - 2017-07-21 15:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:40:23 --> Email Class Initialized
INFO - 2017-07-21 15:40:23 --> Controller Class Initialized
INFO - 2017-07-21 15:40:23 --> Helper loaded: form_helper
INFO - 2017-07-21 15:40:23 --> Form Validation Class Initialized
INFO - 2017-07-21 15:40:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:40:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:40:23 --> Helper loaded: url_helper
INFO - 2017-07-21 15:40:23 --> Model Class Initialized
INFO - 2017-07-21 15:40:23 --> Model Class Initialized
INFO - 2017-07-21 19:10:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:10:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:10:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:10:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:10:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:10:23 --> Final output sent to browser
DEBUG - 2017-07-21 19:10:23 --> Total execution time: 0.0496
INFO - 2017-07-21 15:40:23 --> Config Class Initialized
INFO - 2017-07-21 15:40:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:23 --> URI Class Initialized
INFO - 2017-07-21 15:40:23 --> Router Class Initialized
INFO - 2017-07-21 15:40:23 --> Output Class Initialized
INFO - 2017-07-21 15:40:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:23 --> Input Class Initialized
INFO - 2017-07-21 15:40:23 --> Language Class Initialized
ERROR - 2017-07-21 15:40:23 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
INFO - 2017-07-21 15:40:24 --> Config Class Initialized
INFO - 2017-07-21 15:40:24 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:40:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
INFO - 2017-07-21 15:40:24 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
INFO - 2017-07-21 15:40:24 --> URI Class Initialized
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
INFO - 2017-07-21 15:40:24 --> Router Class Initialized
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
INFO - 2017-07-21 15:40:24 --> Output Class Initialized
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
INFO - 2017-07-21 15:40:24 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
INFO - 2017-07-21 15:40:24 --> Input Class Initialized
INFO - 2017-07-21 15:40:24 --> Language Class Initialized
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:40:24 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> Loader Class Initialized
INFO - 2017-07-21 15:40:27 --> Helper loaded: common_helper
INFO - 2017-07-21 15:40:27 --> Database Driver Class Initialized
INFO - 2017-07-21 15:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:40:27 --> Email Class Initialized
INFO - 2017-07-21 15:40:27 --> Controller Class Initialized
INFO - 2017-07-21 15:40:27 --> Helper loaded: form_helper
INFO - 2017-07-21 15:40:27 --> Form Validation Class Initialized
INFO - 2017-07-21 15:40:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:40:27 --> Helper loaded: url_helper
INFO - 2017-07-21 15:40:27 --> Model Class Initialized
INFO - 2017-07-21 15:40:27 --> Model Class Initialized
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> Loader Class Initialized
INFO - 2017-07-21 15:40:27 --> Helper loaded: common_helper
INFO - 2017-07-21 15:40:27 --> Database Driver Class Initialized
INFO - 2017-07-21 15:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:40:27 --> Email Class Initialized
INFO - 2017-07-21 15:40:27 --> Controller Class Initialized
INFO - 2017-07-21 15:40:27 --> Helper loaded: form_helper
INFO - 2017-07-21 15:40:27 --> Form Validation Class Initialized
INFO - 2017-07-21 15:40:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:40:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:40:27 --> Helper loaded: url_helper
INFO - 2017-07-21 15:40:27 --> Model Class Initialized
INFO - 2017-07-21 15:40:27 --> Model Class Initialized
INFO - 2017-07-21 19:10:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:10:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:10:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:10:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:10:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:10:27 --> Final output sent to browser
DEBUG - 2017-07-21 19:10:27 --> Total execution time: 0.0655
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
INFO - 2017-07-21 15:40:27 --> Config Class Initialized
INFO - 2017-07-21 15:40:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
DEBUG - 2017-07-21 15:40:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> URI Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
INFO - 2017-07-21 15:40:27 --> Router Class Initialized
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:27 --> Output Class Initialized
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:27 --> Input Class Initialized
INFO - 2017-07-21 15:40:27 --> Language Class Initialized
ERROR - 2017-07-21 15:40:27 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
INFO - 2017-07-21 15:40:31 --> Loader Class Initialized
INFO - 2017-07-21 15:40:31 --> Helper loaded: common_helper
INFO - 2017-07-21 15:40:31 --> Database Driver Class Initialized
INFO - 2017-07-21 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:40:31 --> Email Class Initialized
INFO - 2017-07-21 15:40:31 --> Controller Class Initialized
INFO - 2017-07-21 15:40:31 --> Helper loaded: form_helper
INFO - 2017-07-21 15:40:31 --> Form Validation Class Initialized
INFO - 2017-07-21 15:40:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:40:31 --> Helper loaded: url_helper
INFO - 2017-07-21 15:40:31 --> Model Class Initialized
INFO - 2017-07-21 15:40:31 --> Model Class Initialized
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
INFO - 2017-07-21 15:40:31 --> Loader Class Initialized
INFO - 2017-07-21 15:40:31 --> Helper loaded: common_helper
INFO - 2017-07-21 15:40:31 --> Database Driver Class Initialized
INFO - 2017-07-21 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:40:31 --> Email Class Initialized
INFO - 2017-07-21 15:40:31 --> Controller Class Initialized
INFO - 2017-07-21 15:40:31 --> Helper loaded: form_helper
INFO - 2017-07-21 15:40:31 --> Form Validation Class Initialized
INFO - 2017-07-21 15:40:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:40:31 --> Helper loaded: url_helper
INFO - 2017-07-21 15:40:31 --> Model Class Initialized
INFO - 2017-07-21 15:40:31 --> Model Class Initialized
INFO - 2017-07-21 19:10:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:10:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:10:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:10:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:10:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:10:31 --> Final output sent to browser
DEBUG - 2017-07-21 19:10:31 --> Total execution time: 0.0494
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
ERROR - 2017-07-21 15:40:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
ERROR - 2017-07-21 15:40:31 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:40:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
ERROR - 2017-07-21 15:40:31 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
INFO - 2017-07-21 15:40:31 --> Config Class Initialized
INFO - 2017-07-21 15:40:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
DEBUG - 2017-07-21 15:40:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
INFO - 2017-07-21 15:40:31 --> URI Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Router Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
INFO - 2017-07-21 15:40:31 --> Output Class Initialized
ERROR - 2017-07-21 15:40:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:31 --> Input Class Initialized
INFO - 2017-07-21 15:40:31 --> Language Class Initialized
ERROR - 2017-07-21 15:40:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:40:34 --> Config Class Initialized
INFO - 2017-07-21 15:40:34 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:34 --> URI Class Initialized
INFO - 2017-07-21 15:40:34 --> Router Class Initialized
INFO - 2017-07-21 15:40:34 --> Output Class Initialized
INFO - 2017-07-21 15:40:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:34 --> Input Class Initialized
INFO - 2017-07-21 15:40:34 --> Language Class Initialized
ERROR - 2017-07-21 15:40:34 --> 404 Page Not Found: Categories/addCategory
INFO - 2017-07-21 15:40:56 --> Config Class Initialized
INFO - 2017-07-21 15:40:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:56 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:56 --> URI Class Initialized
INFO - 2017-07-21 15:40:56 --> Router Class Initialized
INFO - 2017-07-21 15:40:56 --> Output Class Initialized
INFO - 2017-07-21 15:40:56 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:56 --> Input Class Initialized
INFO - 2017-07-21 15:40:56 --> Language Class Initialized
ERROR - 2017-07-21 15:40:56 --> 404 Page Not Found: Categories/addCategory
INFO - 2017-07-21 15:40:57 --> Config Class Initialized
INFO - 2017-07-21 15:40:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:57 --> URI Class Initialized
INFO - 2017-07-21 15:40:57 --> Router Class Initialized
INFO - 2017-07-21 15:40:57 --> Output Class Initialized
INFO - 2017-07-21 15:40:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:57 --> Input Class Initialized
INFO - 2017-07-21 15:40:57 --> Language Class Initialized
ERROR - 2017-07-21 15:40:57 --> 404 Page Not Found: Categories/addCategory
INFO - 2017-07-21 15:40:57 --> Config Class Initialized
INFO - 2017-07-21 15:40:57 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:57 --> URI Class Initialized
INFO - 2017-07-21 15:40:57 --> Router Class Initialized
INFO - 2017-07-21 15:40:57 --> Output Class Initialized
INFO - 2017-07-21 15:40:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:57 --> Input Class Initialized
INFO - 2017-07-21 15:40:57 --> Language Class Initialized
ERROR - 2017-07-21 15:40:57 --> 404 Page Not Found: Categories/addCategory
INFO - 2017-07-21 15:40:58 --> Config Class Initialized
INFO - 2017-07-21 15:40:58 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:40:58 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:40:58 --> Utf8 Class Initialized
INFO - 2017-07-21 15:40:58 --> URI Class Initialized
INFO - 2017-07-21 15:40:58 --> Router Class Initialized
INFO - 2017-07-21 15:40:58 --> Output Class Initialized
INFO - 2017-07-21 15:40:58 --> Security Class Initialized
DEBUG - 2017-07-21 15:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:40:58 --> Input Class Initialized
INFO - 2017-07-21 15:40:58 --> Language Class Initialized
ERROR - 2017-07-21 15:40:58 --> 404 Page Not Found: Categories/addCategory
INFO - 2017-07-21 15:47:09 --> Config Class Initialized
INFO - 2017-07-21 15:47:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:09 --> URI Class Initialized
INFO - 2017-07-21 15:47:09 --> Router Class Initialized
INFO - 2017-07-21 15:47:09 --> Output Class Initialized
INFO - 2017-07-21 15:47:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:09 --> Input Class Initialized
INFO - 2017-07-21 15:47:09 --> Language Class Initialized
INFO - 2017-07-21 15:47:09 --> Loader Class Initialized
INFO - 2017-07-21 15:47:09 --> Helper loaded: common_helper
INFO - 2017-07-21 15:47:09 --> Database Driver Class Initialized
INFO - 2017-07-21 15:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:47:09 --> Email Class Initialized
INFO - 2017-07-21 15:47:09 --> Controller Class Initialized
INFO - 2017-07-21 15:47:09 --> Helper loaded: form_helper
INFO - 2017-07-21 15:47:09 --> Form Validation Class Initialized
INFO - 2017-07-21 15:47:09 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:47:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:47:09 --> Helper loaded: url_helper
INFO - 2017-07-21 15:47:09 --> Model Class Initialized
INFO - 2017-07-21 15:47:09 --> Model Class Initialized
INFO - 2017-07-21 19:17:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:17:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:17:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:17:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:17:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:17:09 --> Final output sent to browser
DEBUG - 2017-07-21 19:17:09 --> Total execution time: 0.0506
INFO - 2017-07-21 15:47:14 --> Config Class Initialized
INFO - 2017-07-21 15:47:14 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:14 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:14 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:14 --> URI Class Initialized
INFO - 2017-07-21 15:47:14 --> Router Class Initialized
INFO - 2017-07-21 15:47:14 --> Output Class Initialized
INFO - 2017-07-21 15:47:14 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:14 --> Input Class Initialized
INFO - 2017-07-21 15:47:14 --> Language Class Initialized
INFO - 2017-07-21 15:47:14 --> Loader Class Initialized
INFO - 2017-07-21 15:47:14 --> Helper loaded: common_helper
INFO - 2017-07-21 15:47:14 --> Database Driver Class Initialized
INFO - 2017-07-21 15:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:47:14 --> Email Class Initialized
INFO - 2017-07-21 15:47:14 --> Controller Class Initialized
INFO - 2017-07-21 15:47:14 --> Helper loaded: form_helper
INFO - 2017-07-21 15:47:14 --> Form Validation Class Initialized
INFO - 2017-07-21 15:47:14 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:47:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:47:14 --> Helper loaded: url_helper
INFO - 2017-07-21 15:47:14 --> Model Class Initialized
INFO - 2017-07-21 15:47:14 --> Model Class Initialized
INFO - 2017-07-21 19:17:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:17:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:17:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:17:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:17:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:17:14 --> Final output sent to browser
DEBUG - 2017-07-21 19:17:14 --> Total execution time: 0.0478
INFO - 2017-07-21 15:47:16 --> Config Class Initialized
INFO - 2017-07-21 15:47:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:16 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:16 --> URI Class Initialized
INFO - 2017-07-21 15:47:16 --> Router Class Initialized
INFO - 2017-07-21 15:47:16 --> Output Class Initialized
INFO - 2017-07-21 15:47:16 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:16 --> Input Class Initialized
INFO - 2017-07-21 15:47:16 --> Language Class Initialized
ERROR - 2017-07-21 15:47:16 --> 404 Page Not Found: Events/addEvents
INFO - 2017-07-21 15:47:18 --> Config Class Initialized
INFO - 2017-07-21 15:47:18 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:18 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:18 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:18 --> URI Class Initialized
INFO - 2017-07-21 15:47:18 --> Router Class Initialized
INFO - 2017-07-21 15:47:18 --> Output Class Initialized
INFO - 2017-07-21 15:47:18 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:18 --> Input Class Initialized
INFO - 2017-07-21 15:47:18 --> Language Class Initialized
INFO - 2017-07-21 15:47:18 --> Loader Class Initialized
INFO - 2017-07-21 15:47:18 --> Helper loaded: common_helper
INFO - 2017-07-21 15:47:18 --> Database Driver Class Initialized
INFO - 2017-07-21 15:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:47:18 --> Email Class Initialized
INFO - 2017-07-21 15:47:18 --> Controller Class Initialized
INFO - 2017-07-21 15:47:18 --> Helper loaded: form_helper
INFO - 2017-07-21 15:47:18 --> Form Validation Class Initialized
INFO - 2017-07-21 15:47:18 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:47:18 --> Helper loaded: url_helper
INFO - 2017-07-21 15:47:18 --> Model Class Initialized
INFO - 2017-07-21 15:47:18 --> Model Class Initialized
INFO - 2017-07-21 19:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:17:18 --> Final output sent to browser
DEBUG - 2017-07-21 19:17:18 --> Total execution time: 0.0480
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
INFO - 2017-07-21 15:47:34 --> Loader Class Initialized
INFO - 2017-07-21 15:47:34 --> Helper loaded: common_helper
INFO - 2017-07-21 15:47:34 --> Database Driver Class Initialized
INFO - 2017-07-21 15:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:47:34 --> Email Class Initialized
INFO - 2017-07-21 15:47:34 --> Controller Class Initialized
INFO - 2017-07-21 15:47:34 --> Helper loaded: form_helper
INFO - 2017-07-21 15:47:34 --> Form Validation Class Initialized
INFO - 2017-07-21 15:47:34 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:47:34 --> Helper loaded: url_helper
INFO - 2017-07-21 15:47:34 --> Model Class Initialized
INFO - 2017-07-21 15:47:34 --> Model Class Initialized
INFO - 2017-07-21 19:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:17:34 --> Final output sent to browser
DEBUG - 2017-07-21 19:17:34 --> Total execution time: 0.0487
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
INFO - 2017-07-21 15:47:34 --> Config Class Initialized
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> URI Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
INFO - 2017-07-21 15:47:34 --> Router Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:34 --> Output Class Initialized
INFO - 2017-07-21 15:47:34 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:34 --> Input Class Initialized
INFO - 2017-07-21 15:47:34 --> Language Class Initialized
ERROR - 2017-07-21 15:47:34 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:56 --> URI Class Initialized
INFO - 2017-07-21 15:47:56 --> Router Class Initialized
INFO - 2017-07-21 15:47:56 --> Output Class Initialized
INFO - 2017-07-21 15:47:56 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:56 --> Input Class Initialized
INFO - 2017-07-21 15:47:56 --> Language Class Initialized
INFO - 2017-07-21 15:47:56 --> Loader Class Initialized
INFO - 2017-07-21 15:47:56 --> Helper loaded: common_helper
INFO - 2017-07-21 15:47:56 --> Database Driver Class Initialized
INFO - 2017-07-21 15:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:47:56 --> Email Class Initialized
INFO - 2017-07-21 15:47:56 --> Controller Class Initialized
INFO - 2017-07-21 15:47:56 --> Helper loaded: form_helper
INFO - 2017-07-21 15:47:56 --> Form Validation Class Initialized
INFO - 2017-07-21 15:47:56 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:47:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:47:56 --> Helper loaded: url_helper
INFO - 2017-07-21 15:47:56 --> Model Class Initialized
INFO - 2017-07-21 15:47:56 --> Model Class Initialized
INFO - 2017-07-21 19:17:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:17:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:17:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:17:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:17:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:17:56 --> Final output sent to browser
DEBUG - 2017-07-21 19:17:56 --> Total execution time: 0.0482
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:56 --> URI Class Initialized
INFO - 2017-07-21 15:47:56 --> Router Class Initialized
INFO - 2017-07-21 15:47:56 --> Output Class Initialized
INFO - 2017-07-21 15:47:56 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:56 --> Input Class Initialized
INFO - 2017-07-21 15:47:56 --> Language Class Initialized
ERROR - 2017-07-21 15:47:56 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Config Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:56 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> URI Class Initialized
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:47:56 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:56 --> URI Class Initialized
INFO - 2017-07-21 15:47:56 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:56 --> Router Class Initialized
INFO - 2017-07-21 15:47:56 --> URI Class Initialized
INFO - 2017-07-21 15:47:56 --> URI Class Initialized
INFO - 2017-07-21 15:47:56 --> Router Class Initialized
INFO - 2017-07-21 15:47:56 --> Output Class Initialized
INFO - 2017-07-21 15:47:56 --> Router Class Initialized
INFO - 2017-07-21 15:47:56 --> Router Class Initialized
INFO - 2017-07-21 15:47:56 --> Security Class Initialized
INFO - 2017-07-21 15:47:56 --> Output Class Initialized
INFO - 2017-07-21 15:47:56 --> Output Class Initialized
INFO - 2017-07-21 15:47:56 --> Output Class Initialized
DEBUG - 2017-07-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:56 --> Security Class Initialized
INFO - 2017-07-21 15:47:56 --> Security Class Initialized
INFO - 2017-07-21 15:47:56 --> Input Class Initialized
INFO - 2017-07-21 15:47:56 --> Language Class Initialized
INFO - 2017-07-21 15:47:56 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:56 --> Input Class Initialized
INFO - 2017-07-21 15:47:56 --> Input Class Initialized
INFO - 2017-07-21 15:47:56 --> Language Class Initialized
DEBUG - 2017-07-21 15:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:56 --> Language Class Initialized
ERROR - 2017-07-21 15:47:56 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:57 --> Input Class Initialized
INFO - 2017-07-21 15:47:57 --> Language Class Initialized
ERROR - 2017-07-21 15:47:57 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:47:57 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:47:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:47:57 --> URI Class Initialized
INFO - 2017-07-21 15:47:57 --> Router Class Initialized
INFO - 2017-07-21 15:47:57 --> Output Class Initialized
INFO - 2017-07-21 15:47:57 --> Security Class Initialized
INFO - 2017-07-21 15:47:57 --> Config Class Initialized
DEBUG - 2017-07-21 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:57 --> Hooks Class Initialized
INFO - 2017-07-21 15:47:57 --> Input Class Initialized
INFO - 2017-07-21 15:47:57 --> Language Class Initialized
ERROR - 2017-07-21 15:47:57 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:47:57 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:47:57 --> Utf8 Class Initialized
INFO - 2017-07-21 15:47:57 --> URI Class Initialized
INFO - 2017-07-21 15:47:57 --> Router Class Initialized
INFO - 2017-07-21 15:47:57 --> Output Class Initialized
INFO - 2017-07-21 15:47:57 --> Security Class Initialized
DEBUG - 2017-07-21 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:47:57 --> Input Class Initialized
INFO - 2017-07-21 15:47:57 --> Language Class Initialized
ERROR - 2017-07-21 15:47:57 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
INFO - 2017-07-21 15:48:09 --> Loader Class Initialized
INFO - 2017-07-21 15:48:09 --> Helper loaded: common_helper
INFO - 2017-07-21 15:48:09 --> Database Driver Class Initialized
INFO - 2017-07-21 15:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:48:09 --> Email Class Initialized
INFO - 2017-07-21 15:48:09 --> Controller Class Initialized
INFO - 2017-07-21 15:48:09 --> Helper loaded: form_helper
INFO - 2017-07-21 15:48:09 --> Form Validation Class Initialized
INFO - 2017-07-21 15:48:09 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:48:09 --> Helper loaded: url_helper
INFO - 2017-07-21 15:48:09 --> Model Class Initialized
INFO - 2017-07-21 15:48:09 --> Model Class Initialized
INFO - 2017-07-21 19:18:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:18:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:18:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:18:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:18:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:18:09 --> Final output sent to browser
DEBUG - 2017-07-21 19:18:09 --> Total execution time: 0.0491
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Config Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
INFO - 2017-07-21 15:48:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:48:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> URI Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Router Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Output Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
INFO - 2017-07-21 15:48:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Input Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
INFO - 2017-07-21 15:48:09 --> Language Class Initialized
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:48:09 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:48:10 --> Config Class Initialized
INFO - 2017-07-21 15:48:10 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:10 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:10 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:10 --> URI Class Initialized
INFO - 2017-07-21 15:48:10 --> Router Class Initialized
INFO - 2017-07-21 15:48:10 --> Output Class Initialized
INFO - 2017-07-21 15:48:10 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:10 --> Input Class Initialized
INFO - 2017-07-21 15:48:10 --> Language Class Initialized
INFO - 2017-07-21 15:48:10 --> Loader Class Initialized
INFO - 2017-07-21 15:48:10 --> Helper loaded: common_helper
INFO - 2017-07-21 15:48:10 --> Database Driver Class Initialized
INFO - 2017-07-21 15:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:48:10 --> Email Class Initialized
INFO - 2017-07-21 15:48:10 --> Controller Class Initialized
INFO - 2017-07-21 15:48:10 --> Helper loaded: form_helper
INFO - 2017-07-21 15:48:10 --> Form Validation Class Initialized
INFO - 2017-07-21 15:48:10 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:48:10 --> Helper loaded: url_helper
INFO - 2017-07-21 15:48:10 --> Model Class Initialized
INFO - 2017-07-21 15:48:10 --> Model Class Initialized
INFO - 2017-07-21 19:18:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:18:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:18:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:18:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:18:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:18:10 --> Final output sent to browser
DEBUG - 2017-07-21 19:18:10 --> Total execution time: 0.0490
INFO - 2017-07-21 15:48:21 --> Config Class Initialized
INFO - 2017-07-21 15:48:21 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:48:21 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:48:21 --> Utf8 Class Initialized
INFO - 2017-07-21 15:48:21 --> URI Class Initialized
INFO - 2017-07-21 15:48:21 --> Router Class Initialized
INFO - 2017-07-21 15:48:21 --> Output Class Initialized
INFO - 2017-07-21 15:48:21 --> Security Class Initialized
DEBUG - 2017-07-21 15:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:48:21 --> Input Class Initialized
INFO - 2017-07-21 15:48:21 --> Language Class Initialized
INFO - 2017-07-21 15:48:21 --> Loader Class Initialized
INFO - 2017-07-21 15:48:21 --> Helper loaded: common_helper
INFO - 2017-07-21 15:48:21 --> Database Driver Class Initialized
INFO - 2017-07-21 15:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:48:21 --> Email Class Initialized
INFO - 2017-07-21 15:48:21 --> Controller Class Initialized
INFO - 2017-07-21 15:48:21 --> Helper loaded: form_helper
INFO - 2017-07-21 15:48:21 --> Form Validation Class Initialized
INFO - 2017-07-21 15:48:22 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:48:22 --> Helper loaded: url_helper
INFO - 2017-07-21 15:48:22 --> Model Class Initialized
INFO - 2017-07-21 15:48:22 --> Model Class Initialized
DEBUG - 2017-07-21 19:18:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:18:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:18:22 --> Undefined variable: agentID
ERROR - 2017-07-21 19:18:22 --> Severity: Notice --> Undefined variable: agentID C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 74
ERROR - 2017-07-21 19:18:22 --> Query error: Unknown column 'event' in 'where clause' - Invalid query: SELECT *
FROM `categories`
WHERE `event` IS NULL
AND `isDeleted` =0
AND `agentId` IS NULL
ERROR - 2017-07-21 19:18:22 --> Call to a member function row() on a non-object
ERROR - 2017-07-21 19:18:22 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 106
INFO - 2017-07-21 15:49:13 --> Config Class Initialized
INFO - 2017-07-21 15:49:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:13 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:13 --> URI Class Initialized
INFO - 2017-07-21 15:49:13 --> Router Class Initialized
INFO - 2017-07-21 15:49:13 --> Output Class Initialized
INFO - 2017-07-21 15:49:13 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:13 --> Input Class Initialized
INFO - 2017-07-21 15:49:13 --> Language Class Initialized
INFO - 2017-07-21 15:49:13 --> Loader Class Initialized
INFO - 2017-07-21 15:49:13 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:13 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:13 --> Email Class Initialized
INFO - 2017-07-21 15:49:13 --> Controller Class Initialized
INFO - 2017-07-21 15:49:13 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:13 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:13 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:13 --> Model Class Initialized
INFO - 2017-07-21 15:49:13 --> Model Class Initialized
DEBUG - 2017-07-21 19:19:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:19:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:19:13 --> Undefined variable: events
ERROR - 2017-07-21 19:19:13 --> Severity: Notice --> Undefined variable: events C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 122
INFO - 2017-07-21 15:49:13 --> Config Class Initialized
INFO - 2017-07-21 15:49:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:13 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:13 --> URI Class Initialized
INFO - 2017-07-21 15:49:13 --> Router Class Initialized
INFO - 2017-07-21 15:49:13 --> Output Class Initialized
INFO - 2017-07-21 15:49:13 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:13 --> Input Class Initialized
INFO - 2017-07-21 15:49:13 --> Language Class Initialized
INFO - 2017-07-21 15:49:13 --> Loader Class Initialized
INFO - 2017-07-21 15:49:13 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:13 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:13 --> Email Class Initialized
INFO - 2017-07-21 15:49:13 --> Controller Class Initialized
INFO - 2017-07-21 15:49:13 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:13 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:13 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:13 --> Model Class Initialized
INFO - 2017-07-21 15:49:13 --> Model Class Initialized
INFO - 2017-07-21 19:19:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:19:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:19:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:19:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:19:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:19:13 --> Final output sent to browser
DEBUG - 2017-07-21 19:19:13 --> Total execution time: 0.0455
INFO - 2017-07-21 15:49:19 --> Config Class Initialized
INFO - 2017-07-21 15:49:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:19 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:19 --> URI Class Initialized
INFO - 2017-07-21 15:49:19 --> Router Class Initialized
INFO - 2017-07-21 15:49:19 --> Output Class Initialized
INFO - 2017-07-21 15:49:19 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:19 --> Input Class Initialized
INFO - 2017-07-21 15:49:19 --> Language Class Initialized
INFO - 2017-07-21 15:49:19 --> Loader Class Initialized
INFO - 2017-07-21 15:49:19 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:19 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:19 --> Email Class Initialized
INFO - 2017-07-21 15:49:19 --> Controller Class Initialized
INFO - 2017-07-21 15:49:19 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:19 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:19 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:19 --> Model Class Initialized
INFO - 2017-07-21 15:49:19 --> Model Class Initialized
DEBUG - 2017-07-21 19:19:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:19:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:19:20 --> Undefined variable: events
ERROR - 2017-07-21 19:19:20 --> Severity: Notice --> Undefined variable: events C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 122
INFO - 2017-07-21 15:49:20 --> Config Class Initialized
INFO - 2017-07-21 15:49:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:20 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:20 --> URI Class Initialized
INFO - 2017-07-21 15:49:20 --> Router Class Initialized
INFO - 2017-07-21 15:49:20 --> Output Class Initialized
INFO - 2017-07-21 15:49:20 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:20 --> Input Class Initialized
INFO - 2017-07-21 15:49:20 --> Language Class Initialized
INFO - 2017-07-21 15:49:20 --> Loader Class Initialized
INFO - 2017-07-21 15:49:20 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:20 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:20 --> Email Class Initialized
INFO - 2017-07-21 15:49:20 --> Controller Class Initialized
INFO - 2017-07-21 15:49:20 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:20 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:20 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:20 --> Model Class Initialized
INFO - 2017-07-21 15:49:20 --> Model Class Initialized
INFO - 2017-07-21 19:19:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:19:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:19:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:19:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:19:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:19:20 --> Final output sent to browser
DEBUG - 2017-07-21 19:19:20 --> Total execution time: 0.0479
INFO - 2017-07-21 15:49:37 --> Config Class Initialized
INFO - 2017-07-21 15:49:37 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:37 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:37 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:37 --> URI Class Initialized
INFO - 2017-07-21 15:49:37 --> Router Class Initialized
INFO - 2017-07-21 15:49:37 --> Output Class Initialized
INFO - 2017-07-21 15:49:37 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:37 --> Input Class Initialized
INFO - 2017-07-21 15:49:37 --> Language Class Initialized
INFO - 2017-07-21 15:49:37 --> Loader Class Initialized
INFO - 2017-07-21 15:49:37 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:37 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:37 --> Email Class Initialized
INFO - 2017-07-21 15:49:37 --> Controller Class Initialized
INFO - 2017-07-21 15:49:37 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:37 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:37 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:37 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:37 --> Model Class Initialized
INFO - 2017-07-21 15:49:37 --> Model Class Initialized
INFO - 2017-07-21 19:19:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:19:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:19:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:19:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:19:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:19:37 --> Final output sent to browser
DEBUG - 2017-07-21 19:19:37 --> Total execution time: 0.0453
INFO - 2017-07-21 15:49:41 --> Config Class Initialized
INFO - 2017-07-21 15:49:41 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:41 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:41 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:41 --> URI Class Initialized
INFO - 2017-07-21 15:49:41 --> Router Class Initialized
INFO - 2017-07-21 15:49:41 --> Output Class Initialized
INFO - 2017-07-21 15:49:41 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:41 --> Input Class Initialized
INFO - 2017-07-21 15:49:41 --> Language Class Initialized
INFO - 2017-07-21 15:49:41 --> Loader Class Initialized
INFO - 2017-07-21 15:49:41 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:41 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:41 --> Email Class Initialized
INFO - 2017-07-21 15:49:41 --> Controller Class Initialized
INFO - 2017-07-21 15:49:41 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:41 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:41 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:41 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:41 --> Model Class Initialized
INFO - 2017-07-21 15:49:41 --> Model Class Initialized
DEBUG - 2017-07-21 19:19:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:19:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:19:41 --> Query error: Unknown column 'createdTime' in 'field list' - Invalid query: INSERT INTO `categories` (`cat_name`, `cat_colour_code`, `createdTime`) VALUES ('sdsd', 'wewe', '17-07-21 07:19:41')
INFO - 2017-07-21 15:49:41 --> Config Class Initialized
INFO - 2017-07-21 15:49:41 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:49:41 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:49:41 --> Utf8 Class Initialized
INFO - 2017-07-21 15:49:41 --> URI Class Initialized
INFO - 2017-07-21 15:49:41 --> Router Class Initialized
INFO - 2017-07-21 15:49:41 --> Output Class Initialized
INFO - 2017-07-21 15:49:41 --> Security Class Initialized
DEBUG - 2017-07-21 15:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:49:41 --> Input Class Initialized
INFO - 2017-07-21 15:49:41 --> Language Class Initialized
INFO - 2017-07-21 15:49:41 --> Loader Class Initialized
INFO - 2017-07-21 15:49:41 --> Helper loaded: common_helper
INFO - 2017-07-21 15:49:41 --> Database Driver Class Initialized
INFO - 2017-07-21 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:49:41 --> Email Class Initialized
INFO - 2017-07-21 15:49:41 --> Controller Class Initialized
INFO - 2017-07-21 15:49:41 --> Helper loaded: form_helper
INFO - 2017-07-21 15:49:41 --> Form Validation Class Initialized
INFO - 2017-07-21 15:49:41 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:49:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:49:41 --> Helper loaded: url_helper
INFO - 2017-07-21 15:49:41 --> Model Class Initialized
INFO - 2017-07-21 15:49:41 --> Model Class Initialized
INFO - 2017-07-21 19:19:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:19:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:19:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:19:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:19:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:19:41 --> Final output sent to browser
DEBUG - 2017-07-21 19:19:41 --> Total execution time: 0.0580
INFO - 2017-07-21 15:50:09 --> Config Class Initialized
INFO - 2017-07-21 15:50:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:50:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:50:09 --> Utf8 Class Initialized
INFO - 2017-07-21 15:50:09 --> URI Class Initialized
INFO - 2017-07-21 15:50:09 --> Router Class Initialized
INFO - 2017-07-21 15:50:09 --> Output Class Initialized
INFO - 2017-07-21 15:50:09 --> Security Class Initialized
DEBUG - 2017-07-21 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:50:09 --> Input Class Initialized
INFO - 2017-07-21 15:50:09 --> Language Class Initialized
INFO - 2017-07-21 15:50:09 --> Loader Class Initialized
INFO - 2017-07-21 15:50:09 --> Helper loaded: common_helper
INFO - 2017-07-21 15:50:09 --> Database Driver Class Initialized
INFO - 2017-07-21 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:50:09 --> Email Class Initialized
INFO - 2017-07-21 15:50:09 --> Controller Class Initialized
INFO - 2017-07-21 15:50:09 --> Helper loaded: form_helper
INFO - 2017-07-21 15:50:09 --> Form Validation Class Initialized
INFO - 2017-07-21 15:50:09 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:50:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:50:09 --> Helper loaded: url_helper
INFO - 2017-07-21 15:50:09 --> Model Class Initialized
INFO - 2017-07-21 15:50:09 --> Model Class Initialized
INFO - 2017-07-21 19:20:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:20:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:20:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:20:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:20:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:20:09 --> Final output sent to browser
DEBUG - 2017-07-21 19:20:09 --> Total execution time: 0.0662
INFO - 2017-07-21 15:50:16 --> Config Class Initialized
INFO - 2017-07-21 15:50:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:50:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:50:16 --> Utf8 Class Initialized
INFO - 2017-07-21 15:50:16 --> URI Class Initialized
INFO - 2017-07-21 15:50:16 --> Router Class Initialized
INFO - 2017-07-21 15:50:16 --> Output Class Initialized
INFO - 2017-07-21 15:50:16 --> Security Class Initialized
DEBUG - 2017-07-21 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:50:16 --> Input Class Initialized
INFO - 2017-07-21 15:50:16 --> Language Class Initialized
INFO - 2017-07-21 15:50:16 --> Loader Class Initialized
INFO - 2017-07-21 15:50:16 --> Helper loaded: common_helper
INFO - 2017-07-21 15:50:16 --> Database Driver Class Initialized
INFO - 2017-07-21 15:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:50:16 --> Email Class Initialized
INFO - 2017-07-21 15:50:16 --> Controller Class Initialized
INFO - 2017-07-21 15:50:16 --> Helper loaded: form_helper
INFO - 2017-07-21 15:50:16 --> Form Validation Class Initialized
INFO - 2017-07-21 15:50:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:50:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:50:16 --> Helper loaded: url_helper
INFO - 2017-07-21 15:50:16 --> Model Class Initialized
INFO - 2017-07-21 15:50:16 --> Model Class Initialized
DEBUG - 2017-07-21 19:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:20:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 15:50:39 --> Config Class Initialized
INFO - 2017-07-21 15:50:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:50:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:50:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:50:39 --> URI Class Initialized
INFO - 2017-07-21 15:50:39 --> Router Class Initialized
INFO - 2017-07-21 15:50:39 --> Output Class Initialized
INFO - 2017-07-21 15:50:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:50:39 --> Input Class Initialized
INFO - 2017-07-21 15:50:39 --> Language Class Initialized
INFO - 2017-07-21 15:50:39 --> Loader Class Initialized
INFO - 2017-07-21 15:50:39 --> Helper loaded: common_helper
INFO - 2017-07-21 15:50:39 --> Database Driver Class Initialized
INFO - 2017-07-21 15:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:50:39 --> Email Class Initialized
INFO - 2017-07-21 15:50:39 --> Controller Class Initialized
INFO - 2017-07-21 15:50:39 --> Helper loaded: form_helper
INFO - 2017-07-21 15:50:39 --> Form Validation Class Initialized
INFO - 2017-07-21 15:50:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:50:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:50:39 --> Helper loaded: url_helper
INFO - 2017-07-21 15:50:39 --> Model Class Initialized
INFO - 2017-07-21 15:50:39 --> Model Class Initialized
DEBUG - 2017-07-21 19:20:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:20:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:20:39 --> Query error: Unknown column 'createdTime' in 'field list' - Invalid query: INSERT INTO `categories` (`cat_name`, `cat_colour_code`, `createdTime`) VALUES ('ewewewewewewewe', 'wewewe', '17-07-21 07:20:39')
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
INFO - 2017-07-21 15:53:39 --> Loader Class Initialized
INFO - 2017-07-21 15:53:39 --> Helper loaded: common_helper
INFO - 2017-07-21 15:53:39 --> Database Driver Class Initialized
INFO - 2017-07-21 15:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:53:39 --> Email Class Initialized
INFO - 2017-07-21 15:53:39 --> Controller Class Initialized
INFO - 2017-07-21 15:53:39 --> Helper loaded: form_helper
INFO - 2017-07-21 15:53:39 --> Form Validation Class Initialized
INFO - 2017-07-21 15:53:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:53:39 --> Helper loaded: url_helper
INFO - 2017-07-21 15:53:39 --> Model Class Initialized
INFO - 2017-07-21 15:53:39 --> Model Class Initialized
DEBUG - 2017-07-21 19:23:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:23:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
INFO - 2017-07-21 15:53:39 --> Loader Class Initialized
INFO - 2017-07-21 15:53:39 --> Helper loaded: common_helper
INFO - 2017-07-21 15:53:39 --> Database Driver Class Initialized
INFO - 2017-07-21 15:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:53:39 --> Email Class Initialized
INFO - 2017-07-21 15:53:39 --> Controller Class Initialized
INFO - 2017-07-21 15:53:39 --> Helper loaded: form_helper
INFO - 2017-07-21 15:53:39 --> Form Validation Class Initialized
INFO - 2017-07-21 15:53:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:53:39 --> Helper loaded: url_helper
INFO - 2017-07-21 15:53:39 --> Model Class Initialized
INFO - 2017-07-21 15:53:39 --> Model Class Initialized
INFO - 2017-07-21 19:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:23:39 --> Final output sent to browser
DEBUG - 2017-07-21 19:23:39 --> Total execution time: 0.0473
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:53:39 --> Config Class Initialized
INFO - 2017-07-21 15:53:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:39 --> URI Class Initialized
INFO - 2017-07-21 15:53:39 --> Router Class Initialized
INFO - 2017-07-21 15:53:39 --> Output Class Initialized
INFO - 2017-07-21 15:53:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:39 --> Input Class Initialized
INFO - 2017-07-21 15:53:39 --> Language Class Initialized
ERROR - 2017-07-21 15:53:39 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:53:43 --> Config Class Initialized
INFO - 2017-07-21 15:53:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:43 --> URI Class Initialized
INFO - 2017-07-21 15:53:43 --> Router Class Initialized
INFO - 2017-07-21 15:53:43 --> Output Class Initialized
INFO - 2017-07-21 15:53:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:43 --> Input Class Initialized
INFO - 2017-07-21 15:53:43 --> Language Class Initialized
INFO - 2017-07-21 15:53:43 --> Loader Class Initialized
INFO - 2017-07-21 15:53:43 --> Helper loaded: common_helper
INFO - 2017-07-21 15:53:43 --> Database Driver Class Initialized
INFO - 2017-07-21 15:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:53:43 --> Email Class Initialized
INFO - 2017-07-21 15:53:43 --> Controller Class Initialized
INFO - 2017-07-21 15:53:43 --> Helper loaded: form_helper
INFO - 2017-07-21 15:53:43 --> Form Validation Class Initialized
INFO - 2017-07-21 15:53:43 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:53:43 --> Helper loaded: url_helper
INFO - 2017-07-21 15:53:43 --> Model Class Initialized
INFO - 2017-07-21 15:53:43 --> Model Class Initialized
INFO - 2017-07-21 19:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:23:43 --> Final output sent to browser
DEBUG - 2017-07-21 19:23:43 --> Total execution time: 0.0453
INFO - 2017-07-21 15:53:47 --> Config Class Initialized
INFO - 2017-07-21 15:53:47 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:47 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:47 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:47 --> URI Class Initialized
INFO - 2017-07-21 15:53:47 --> Router Class Initialized
INFO - 2017-07-21 15:53:47 --> Output Class Initialized
INFO - 2017-07-21 15:53:47 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:47 --> Input Class Initialized
INFO - 2017-07-21 15:53:47 --> Language Class Initialized
INFO - 2017-07-21 15:53:47 --> Loader Class Initialized
INFO - 2017-07-21 15:53:47 --> Helper loaded: common_helper
INFO - 2017-07-21 15:53:47 --> Database Driver Class Initialized
INFO - 2017-07-21 15:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:53:47 --> Email Class Initialized
INFO - 2017-07-21 15:53:47 --> Controller Class Initialized
INFO - 2017-07-21 15:53:47 --> Helper loaded: form_helper
INFO - 2017-07-21 15:53:47 --> Form Validation Class Initialized
INFO - 2017-07-21 15:53:47 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:53:47 --> Helper loaded: url_helper
INFO - 2017-07-21 15:53:47 --> Model Class Initialized
INFO - 2017-07-21 15:53:47 --> Model Class Initialized
DEBUG - 2017-07-21 19:23:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:23:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:23:47 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-21 19:23:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-21 19:23:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `cat_name` = 'ewewewewewewewe', `cat_colour_code` = 'wewewe', `updatedTime` = '' at line 1 - Invalid query: UPDATE `categories` SET `details` = , `cat_name` = 'ewewewewewewewe', `cat_colour_code` = 'wewewe', `updatedTime` = '17-07-21 07:23:47'
WHERE `cat_id` = '9'
INFO - 2017-07-21 15:53:47 --> Config Class Initialized
INFO - 2017-07-21 15:53:47 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:53:47 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:53:47 --> Utf8 Class Initialized
INFO - 2017-07-21 15:53:47 --> URI Class Initialized
INFO - 2017-07-21 15:53:47 --> Router Class Initialized
INFO - 2017-07-21 15:53:47 --> Output Class Initialized
INFO - 2017-07-21 15:53:47 --> Security Class Initialized
DEBUG - 2017-07-21 15:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:53:47 --> Input Class Initialized
INFO - 2017-07-21 15:53:47 --> Language Class Initialized
INFO - 2017-07-21 15:53:47 --> Loader Class Initialized
INFO - 2017-07-21 15:53:47 --> Helper loaded: common_helper
INFO - 2017-07-21 15:53:47 --> Database Driver Class Initialized
INFO - 2017-07-21 15:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:53:47 --> Email Class Initialized
INFO - 2017-07-21 15:53:47 --> Controller Class Initialized
INFO - 2017-07-21 15:53:47 --> Helper loaded: form_helper
INFO - 2017-07-21 15:53:47 --> Form Validation Class Initialized
INFO - 2017-07-21 15:53:47 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:53:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:53:47 --> Helper loaded: url_helper
INFO - 2017-07-21 15:53:47 --> Model Class Initialized
INFO - 2017-07-21 15:53:47 --> Model Class Initialized
INFO - 2017-07-21 19:23:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:23:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:23:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:23:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:23:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:23:47 --> Final output sent to browser
DEBUG - 2017-07-21 19:23:47 --> Total execution time: 0.0462
INFO - 2017-07-21 15:54:23 --> Config Class Initialized
INFO - 2017-07-21 15:54:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:54:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:54:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:54:23 --> URI Class Initialized
INFO - 2017-07-21 15:54:23 --> Router Class Initialized
INFO - 2017-07-21 15:54:23 --> Output Class Initialized
INFO - 2017-07-21 15:54:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:54:23 --> Input Class Initialized
INFO - 2017-07-21 15:54:23 --> Language Class Initialized
INFO - 2017-07-21 15:54:23 --> Loader Class Initialized
INFO - 2017-07-21 15:54:23 --> Helper loaded: common_helper
INFO - 2017-07-21 15:54:23 --> Database Driver Class Initialized
INFO - 2017-07-21 15:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:54:23 --> Email Class Initialized
INFO - 2017-07-21 15:54:23 --> Controller Class Initialized
INFO - 2017-07-21 15:54:23 --> Helper loaded: form_helper
INFO - 2017-07-21 15:54:23 --> Form Validation Class Initialized
INFO - 2017-07-21 15:54:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:54:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:54:23 --> Helper loaded: url_helper
INFO - 2017-07-21 15:54:23 --> Model Class Initialized
INFO - 2017-07-21 15:54:23 --> Model Class Initialized
INFO - 2017-07-21 19:24:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:24:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:24:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:24:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:24:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:24:23 --> Final output sent to browser
DEBUG - 2017-07-21 19:24:23 --> Total execution time: 0.0481
INFO - 2017-07-21 15:54:27 --> Config Class Initialized
INFO - 2017-07-21 15:54:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:54:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:54:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:54:27 --> URI Class Initialized
INFO - 2017-07-21 15:54:27 --> Router Class Initialized
INFO - 2017-07-21 15:54:27 --> Output Class Initialized
INFO - 2017-07-21 15:54:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:54:27 --> Input Class Initialized
INFO - 2017-07-21 15:54:27 --> Language Class Initialized
INFO - 2017-07-21 15:54:27 --> Loader Class Initialized
INFO - 2017-07-21 15:54:27 --> Helper loaded: common_helper
INFO - 2017-07-21 15:54:27 --> Database Driver Class Initialized
INFO - 2017-07-21 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:54:27 --> Email Class Initialized
INFO - 2017-07-21 15:54:27 --> Controller Class Initialized
INFO - 2017-07-21 15:54:27 --> Helper loaded: form_helper
INFO - 2017-07-21 15:54:27 --> Form Validation Class Initialized
INFO - 2017-07-21 15:54:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:54:27 --> Helper loaded: url_helper
INFO - 2017-07-21 15:54:27 --> Model Class Initialized
INFO - 2017-07-21 15:54:27 --> Model Class Initialized
DEBUG - 2017-07-21 19:24:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:24:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:24:27 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-21 19:24:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-21 19:24:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `cat_name` = 'ewewewewewewewe', `cat_colour_code` = 'wewewe', `updatedTime` = '' at line 1 - Invalid query: UPDATE `categories` SET `details` = , `cat_name` = 'ewewewewewewewe', `cat_colour_code` = 'wewewe', `updatedTime` = '17-07-21 07:24:27'
WHERE `cat_id` = '9'
INFO - 2017-07-21 15:54:27 --> Config Class Initialized
INFO - 2017-07-21 15:54:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:54:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:54:27 --> Utf8 Class Initialized
INFO - 2017-07-21 15:54:27 --> URI Class Initialized
INFO - 2017-07-21 15:54:27 --> Router Class Initialized
INFO - 2017-07-21 15:54:27 --> Output Class Initialized
INFO - 2017-07-21 15:54:27 --> Security Class Initialized
DEBUG - 2017-07-21 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:54:27 --> Input Class Initialized
INFO - 2017-07-21 15:54:27 --> Language Class Initialized
INFO - 2017-07-21 15:54:27 --> Loader Class Initialized
INFO - 2017-07-21 15:54:27 --> Helper loaded: common_helper
INFO - 2017-07-21 15:54:27 --> Database Driver Class Initialized
INFO - 2017-07-21 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:54:27 --> Email Class Initialized
INFO - 2017-07-21 15:54:27 --> Controller Class Initialized
INFO - 2017-07-21 15:54:27 --> Helper loaded: form_helper
INFO - 2017-07-21 15:54:27 --> Form Validation Class Initialized
INFO - 2017-07-21 15:54:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:54:27 --> Helper loaded: url_helper
INFO - 2017-07-21 15:54:27 --> Model Class Initialized
INFO - 2017-07-21 15:54:27 --> Model Class Initialized
INFO - 2017-07-21 19:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:24:27 --> Final output sent to browser
DEBUG - 2017-07-21 19:24:27 --> Total execution time: 0.0468
INFO - 2017-07-21 15:55:16 --> Config Class Initialized
INFO - 2017-07-21 15:55:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:16 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:16 --> URI Class Initialized
INFO - 2017-07-21 15:55:16 --> Router Class Initialized
INFO - 2017-07-21 15:55:16 --> Output Class Initialized
INFO - 2017-07-21 15:55:16 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:16 --> Input Class Initialized
INFO - 2017-07-21 15:55:16 --> Language Class Initialized
INFO - 2017-07-21 15:55:16 --> Loader Class Initialized
INFO - 2017-07-21 15:55:16 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:16 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:16 --> Email Class Initialized
INFO - 2017-07-21 15:55:16 --> Controller Class Initialized
INFO - 2017-07-21 15:55:16 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:16 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:16 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:16 --> Model Class Initialized
INFO - 2017-07-21 15:55:16 --> Model Class Initialized
INFO - 2017-07-21 19:25:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:25:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:25:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:25:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:25:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:25:16 --> Final output sent to browser
DEBUG - 2017-07-21 19:25:16 --> Total execution time: 0.0461
INFO - 2017-07-21 15:55:20 --> Config Class Initialized
INFO - 2017-07-21 15:55:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:20 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:20 --> URI Class Initialized
INFO - 2017-07-21 15:55:20 --> Router Class Initialized
INFO - 2017-07-21 15:55:20 --> Output Class Initialized
INFO - 2017-07-21 15:55:20 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:20 --> Input Class Initialized
INFO - 2017-07-21 15:55:20 --> Language Class Initialized
INFO - 2017-07-21 15:55:20 --> Loader Class Initialized
INFO - 2017-07-21 15:55:20 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:20 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:20 --> Email Class Initialized
INFO - 2017-07-21 15:55:20 --> Controller Class Initialized
INFO - 2017-07-21 15:55:20 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:20 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:20 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:20 --> Model Class Initialized
INFO - 2017-07-21 15:55:20 --> Model Class Initialized
DEBUG - 2017-07-21 19:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:25:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:25:20 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-21 19:25:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-21 19:25:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `cat_name` = 'ewewewewewewewe', `cat_colour_code` = 'wewewe', `updatedTime` = '' at line 1 - Invalid query: UPDATE `categories` SET `details` = , `cat_name` = 'ewewewewewewewe', `cat_colour_code` = 'wewewe', `updatedTime` = '17-07-21 07:25:20'
WHERE `cat_id` = '9'
INFO - 2017-07-21 15:55:20 --> Config Class Initialized
INFO - 2017-07-21 15:55:20 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:20 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:20 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:20 --> URI Class Initialized
INFO - 2017-07-21 15:55:20 --> Router Class Initialized
INFO - 2017-07-21 15:55:20 --> Output Class Initialized
INFO - 2017-07-21 15:55:20 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:20 --> Input Class Initialized
INFO - 2017-07-21 15:55:20 --> Language Class Initialized
INFO - 2017-07-21 15:55:20 --> Loader Class Initialized
INFO - 2017-07-21 15:55:20 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:20 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:20 --> Email Class Initialized
INFO - 2017-07-21 15:55:20 --> Controller Class Initialized
INFO - 2017-07-21 15:55:20 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:20 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:20 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:20 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:20 --> Model Class Initialized
INFO - 2017-07-21 15:55:20 --> Model Class Initialized
INFO - 2017-07-21 19:25:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:25:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:25:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:25:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:25:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:25:20 --> Final output sent to browser
DEBUG - 2017-07-21 19:25:20 --> Total execution time: 0.0563
INFO - 2017-07-21 15:55:22 --> Config Class Initialized
INFO - 2017-07-21 15:55:22 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:22 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:22 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:22 --> URI Class Initialized
INFO - 2017-07-21 15:55:22 --> Router Class Initialized
INFO - 2017-07-21 15:55:22 --> Output Class Initialized
INFO - 2017-07-21 15:55:22 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:22 --> Input Class Initialized
INFO - 2017-07-21 15:55:22 --> Language Class Initialized
INFO - 2017-07-21 15:55:22 --> Loader Class Initialized
INFO - 2017-07-21 15:55:22 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:22 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:22 --> Email Class Initialized
INFO - 2017-07-21 15:55:22 --> Controller Class Initialized
INFO - 2017-07-21 15:55:22 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:22 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:22 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:22 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:22 --> Model Class Initialized
INFO - 2017-07-21 15:55:22 --> Model Class Initialized
INFO - 2017-07-21 19:25:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:25:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:25:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:25:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:25:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:25:22 --> Final output sent to browser
DEBUG - 2017-07-21 19:25:22 --> Total execution time: 0.0472
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
INFO - 2017-07-21 15:55:23 --> Loader Class Initialized
INFO - 2017-07-21 15:55:23 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:23 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:23 --> Email Class Initialized
INFO - 2017-07-21 15:55:23 --> Controller Class Initialized
INFO - 2017-07-21 15:55:23 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:23 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:23 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:23 --> Model Class Initialized
INFO - 2017-07-21 15:55:23 --> Model Class Initialized
INFO - 2017-07-21 19:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:25:23 --> Final output sent to browser
DEBUG - 2017-07-21 19:25:23 --> Total execution time: 0.0465
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
ERROR - 2017-07-21 15:55:23 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
ERROR - 2017-07-21 15:55:23 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
ERROR - 2017-07-21 15:55:23 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:23 --> Config Class Initialized
INFO - 2017-07-21 15:55:23 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:55:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:23 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
INFO - 2017-07-21 15:55:23 --> URI Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Router Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
INFO - 2017-07-21 15:55:23 --> Output Class Initialized
ERROR - 2017-07-21 15:55:23 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
INFO - 2017-07-21 15:55:23 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
DEBUG - 2017-07-21 15:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:23 --> Input Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
INFO - 2017-07-21 15:55:23 --> Language Class Initialized
ERROR - 2017-07-21 15:55:24 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:55:24 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:55:24 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:26 --> Config Class Initialized
INFO - 2017-07-21 15:55:26 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:26 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:26 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:26 --> URI Class Initialized
INFO - 2017-07-21 15:55:26 --> Router Class Initialized
INFO - 2017-07-21 15:55:26 --> Output Class Initialized
INFO - 2017-07-21 15:55:26 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:26 --> Input Class Initialized
INFO - 2017-07-21 15:55:26 --> Language Class Initialized
INFO - 2017-07-21 15:55:26 --> Loader Class Initialized
INFO - 2017-07-21 15:55:26 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:26 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:26 --> Email Class Initialized
INFO - 2017-07-21 15:55:26 --> Controller Class Initialized
INFO - 2017-07-21 15:55:26 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:26 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:26 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:26 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:26 --> Model Class Initialized
INFO - 2017-07-21 15:55:26 --> Model Class Initialized
INFO - 2017-07-21 19:25:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:25:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:25:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:25:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:25:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:25:26 --> Final output sent to browser
DEBUG - 2017-07-21 19:25:26 --> Total execution time: 0.0457
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
INFO - 2017-07-21 15:55:31 --> Loader Class Initialized
INFO - 2017-07-21 15:55:31 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:31 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:31 --> Email Class Initialized
INFO - 2017-07-21 15:55:31 --> Controller Class Initialized
INFO - 2017-07-21 15:55:31 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:31 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:31 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:31 --> Model Class Initialized
INFO - 2017-07-21 15:55:31 --> Model Class Initialized
DEBUG - 2017-07-21 19:25:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:25:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
INFO - 2017-07-21 15:55:31 --> Loader Class Initialized
INFO - 2017-07-21 15:55:31 --> Helper loaded: common_helper
INFO - 2017-07-21 15:55:31 --> Database Driver Class Initialized
INFO - 2017-07-21 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:55:31 --> Email Class Initialized
INFO - 2017-07-21 15:55:31 --> Controller Class Initialized
INFO - 2017-07-21 15:55:31 --> Helper loaded: form_helper
INFO - 2017-07-21 15:55:31 --> Form Validation Class Initialized
INFO - 2017-07-21 15:55:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:55:31 --> Helper loaded: url_helper
INFO - 2017-07-21 15:55:31 --> Model Class Initialized
INFO - 2017-07-21 15:55:31 --> Model Class Initialized
INFO - 2017-07-21 19:25:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:25:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:25:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:25:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:25:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:25:31 --> Final output sent to browser
DEBUG - 2017-07-21 19:25:31 --> Total execution time: 0.0463
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Config Class Initialized
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> Hooks Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
DEBUG - 2017-07-21 15:55:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:55:31 --> Utf8 Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> URI Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
INFO - 2017-07-21 15:55:31 --> Router Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
INFO - 2017-07-21 15:55:31 --> Output Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
INFO - 2017-07-21 15:55:31 --> Security Class Initialized
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
DEBUG - 2017-07-21 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:55:31 --> Input Class Initialized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:55:31 --> Language Class Initialized
ERROR - 2017-07-21 15:55:31 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:56:39 --> Config Class Initialized
INFO - 2017-07-21 15:56:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:56:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:56:39 --> Utf8 Class Initialized
INFO - 2017-07-21 15:56:39 --> URI Class Initialized
INFO - 2017-07-21 15:56:39 --> Router Class Initialized
INFO - 2017-07-21 15:56:39 --> Output Class Initialized
INFO - 2017-07-21 15:56:39 --> Security Class Initialized
DEBUG - 2017-07-21 15:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:56:39 --> Input Class Initialized
INFO - 2017-07-21 15:56:39 --> Language Class Initialized
INFO - 2017-07-21 15:56:39 --> Loader Class Initialized
INFO - 2017-07-21 15:56:39 --> Helper loaded: common_helper
INFO - 2017-07-21 15:56:39 --> Database Driver Class Initialized
INFO - 2017-07-21 15:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:56:39 --> Email Class Initialized
INFO - 2017-07-21 15:56:39 --> Controller Class Initialized
INFO - 2017-07-21 15:56:39 --> Helper loaded: form_helper
INFO - 2017-07-21 15:56:39 --> Form Validation Class Initialized
INFO - 2017-07-21 15:56:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:56:39 --> Helper loaded: url_helper
INFO - 2017-07-21 15:56:39 --> Model Class Initialized
INFO - 2017-07-21 15:56:39 --> Model Class Initialized
INFO - 2017-07-21 19:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:26:39 --> Final output sent to browser
DEBUG - 2017-07-21 19:26:39 --> Total execution time: 0.0515
INFO - 2017-07-21 15:57:04 --> Config Class Initialized
INFO - 2017-07-21 15:57:04 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:57:04 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:57:04 --> Utf8 Class Initialized
INFO - 2017-07-21 15:57:04 --> URI Class Initialized
INFO - 2017-07-21 15:57:04 --> Router Class Initialized
INFO - 2017-07-21 15:57:04 --> Output Class Initialized
INFO - 2017-07-21 15:57:04 --> Security Class Initialized
DEBUG - 2017-07-21 15:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:57:04 --> Input Class Initialized
INFO - 2017-07-21 15:57:04 --> Language Class Initialized
INFO - 2017-07-21 15:57:04 --> Loader Class Initialized
INFO - 2017-07-21 15:57:04 --> Helper loaded: common_helper
INFO - 2017-07-21 15:57:04 --> Database Driver Class Initialized
INFO - 2017-07-21 15:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:57:04 --> Email Class Initialized
INFO - 2017-07-21 15:57:04 --> Controller Class Initialized
INFO - 2017-07-21 15:57:04 --> Helper loaded: form_helper
INFO - 2017-07-21 15:57:04 --> Form Validation Class Initialized
INFO - 2017-07-21 15:57:04 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:57:04 --> Helper loaded: url_helper
INFO - 2017-07-21 15:57:04 --> Model Class Initialized
INFO - 2017-07-21 15:57:04 --> Model Class Initialized
INFO - 2017-07-21 15:57:44 --> Config Class Initialized
INFO - 2017-07-21 15:57:44 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:57:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:57:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:57:44 --> URI Class Initialized
INFO - 2017-07-21 15:57:44 --> Router Class Initialized
INFO - 2017-07-21 15:57:44 --> Output Class Initialized
INFO - 2017-07-21 15:57:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:57:44 --> Input Class Initialized
INFO - 2017-07-21 15:57:44 --> Language Class Initialized
INFO - 2017-07-21 15:57:44 --> Loader Class Initialized
INFO - 2017-07-21 15:57:44 --> Helper loaded: common_helper
INFO - 2017-07-21 15:57:44 --> Database Driver Class Initialized
INFO - 2017-07-21 15:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:57:44 --> Email Class Initialized
INFO - 2017-07-21 15:57:44 --> Controller Class Initialized
INFO - 2017-07-21 15:57:44 --> Helper loaded: form_helper
INFO - 2017-07-21 15:57:44 --> Form Validation Class Initialized
INFO - 2017-07-21 15:57:44 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:57:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:57:44 --> Helper loaded: url_helper
INFO - 2017-07-21 15:57:44 --> Model Class Initialized
INFO - 2017-07-21 15:57:44 --> Model Class Initialized
DEBUG - 2017-07-21 19:27:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:27:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
INFO - 2017-07-21 15:58:02 --> Loader Class Initialized
INFO - 2017-07-21 15:58:02 --> Helper loaded: common_helper
INFO - 2017-07-21 15:58:02 --> Database Driver Class Initialized
INFO - 2017-07-21 15:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:58:02 --> Email Class Initialized
INFO - 2017-07-21 15:58:02 --> Controller Class Initialized
INFO - 2017-07-21 15:58:02 --> Helper loaded: form_helper
INFO - 2017-07-21 15:58:02 --> Form Validation Class Initialized
INFO - 2017-07-21 15:58:02 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:58:02 --> Helper loaded: url_helper
INFO - 2017-07-21 15:58:02 --> Model Class Initialized
INFO - 2017-07-21 15:58:02 --> Model Class Initialized
DEBUG - 2017-07-21 19:28:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:28:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:28:02 --> move_uploaded_file(./uploads/categories/34081500645482.jpg): failed to open stream: No such file or directory
ERROR - 2017-07-21 19:28:02 --> Severity: Warning --> move_uploaded_file(./uploads/categories/34081500645482.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
ERROR - 2017-07-21 19:28:02 --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php6F39.tmp' to './uploads/categories/34081500645482.jpg'
ERROR - 2017-07-21 19:28:02 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php6F39.tmp' to './uploads/categories/34081500645482.jpg' C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
INFO - 2017-07-21 15:58:02 --> Loader Class Initialized
INFO - 2017-07-21 15:58:02 --> Helper loaded: common_helper
INFO - 2017-07-21 15:58:02 --> Database Driver Class Initialized
INFO - 2017-07-21 15:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:58:02 --> Email Class Initialized
INFO - 2017-07-21 15:58:02 --> Controller Class Initialized
INFO - 2017-07-21 15:58:02 --> Helper loaded: form_helper
INFO - 2017-07-21 15:58:02 --> Form Validation Class Initialized
INFO - 2017-07-21 15:58:02 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:58:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:58:02 --> Helper loaded: url_helper
INFO - 2017-07-21 15:58:02 --> Model Class Initialized
INFO - 2017-07-21 15:58:02 --> Model Class Initialized
INFO - 2017-07-21 19:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:28:02 --> Final output sent to browser
DEBUG - 2017-07-21 19:28:02 --> Total execution time: 0.0477
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
INFO - 2017-07-21 15:58:02 --> Config Class Initialized
INFO - 2017-07-21 15:58:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:58:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> URI Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Router Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Output Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
INFO - 2017-07-21 15:58:02 --> Security Class Initialized
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:02 --> Input Class Initialized
INFO - 2017-07-21 15:58:02 --> Language Class Initialized
ERROR - 2017-07-21 15:58:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
INFO - 2017-07-21 15:58:43 --> Loader Class Initialized
INFO - 2017-07-21 15:58:43 --> Helper loaded: common_helper
INFO - 2017-07-21 15:58:43 --> Database Driver Class Initialized
INFO - 2017-07-21 15:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:58:43 --> Email Class Initialized
INFO - 2017-07-21 15:58:43 --> Controller Class Initialized
INFO - 2017-07-21 15:58:43 --> Helper loaded: form_helper
INFO - 2017-07-21 15:58:43 --> Form Validation Class Initialized
INFO - 2017-07-21 15:58:43 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:58:43 --> Helper loaded: url_helper
INFO - 2017-07-21 15:58:43 --> Model Class Initialized
INFO - 2017-07-21 15:58:43 --> Model Class Initialized
INFO - 2017-07-21 19:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:28:43 --> Final output sent to browser
DEBUG - 2017-07-21 19:28:43 --> Total execution time: 0.0488
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
INFO - 2017-07-21 15:58:43 --> Config Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
INFO - 2017-07-21 15:58:43 --> Hooks Class Initialized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:43 --> Utf8 Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
INFO - 2017-07-21 15:58:43 --> URI Class Initialized
INFO - 2017-07-21 15:58:43 --> Router Class Initialized
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:43 --> Output Class Initialized
INFO - 2017-07-21 15:58:43 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:43 --> Input Class Initialized
INFO - 2017-07-21 15:58:43 --> Language Class Initialized
ERROR - 2017-07-21 15:58:43 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 15:58:45 --> Config Class Initialized
INFO - 2017-07-21 15:58:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:45 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:45 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:45 --> URI Class Initialized
INFO - 2017-07-21 15:58:45 --> Router Class Initialized
INFO - 2017-07-21 15:58:45 --> Output Class Initialized
INFO - 2017-07-21 15:58:45 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:45 --> Input Class Initialized
INFO - 2017-07-21 15:58:45 --> Language Class Initialized
INFO - 2017-07-21 15:58:45 --> Loader Class Initialized
INFO - 2017-07-21 15:58:45 --> Helper loaded: common_helper
INFO - 2017-07-21 15:58:45 --> Database Driver Class Initialized
INFO - 2017-07-21 15:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:58:45 --> Email Class Initialized
INFO - 2017-07-21 15:58:45 --> Controller Class Initialized
INFO - 2017-07-21 15:58:45 --> Helper loaded: form_helper
INFO - 2017-07-21 15:58:45 --> Form Validation Class Initialized
INFO - 2017-07-21 15:58:45 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:58:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:58:45 --> Helper loaded: url_helper
INFO - 2017-07-21 15:58:45 --> Model Class Initialized
INFO - 2017-07-21 15:58:45 --> Model Class Initialized
INFO - 2017-07-21 19:28:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:28:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:28:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:28:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:28:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:28:45 --> Final output sent to browser
DEBUG - 2017-07-21 19:28:45 --> Total execution time: 0.0686
INFO - 2017-07-21 15:58:49 --> Config Class Initialized
INFO - 2017-07-21 15:58:49 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:58:49 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:58:49 --> Utf8 Class Initialized
INFO - 2017-07-21 15:58:49 --> URI Class Initialized
INFO - 2017-07-21 15:58:49 --> Router Class Initialized
INFO - 2017-07-21 15:58:49 --> Output Class Initialized
INFO - 2017-07-21 15:58:49 --> Security Class Initialized
DEBUG - 2017-07-21 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:58:49 --> Input Class Initialized
INFO - 2017-07-21 15:58:49 --> Language Class Initialized
INFO - 2017-07-21 15:58:49 --> Loader Class Initialized
INFO - 2017-07-21 15:58:49 --> Helper loaded: common_helper
INFO - 2017-07-21 15:58:49 --> Database Driver Class Initialized
INFO - 2017-07-21 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:58:49 --> Email Class Initialized
INFO - 2017-07-21 15:58:49 --> Controller Class Initialized
INFO - 2017-07-21 15:58:49 --> Helper loaded: form_helper
INFO - 2017-07-21 15:58:49 --> Form Validation Class Initialized
INFO - 2017-07-21 15:58:49 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:58:49 --> Helper loaded: url_helper
INFO - 2017-07-21 15:58:49 --> Model Class Initialized
INFO - 2017-07-21 15:58:49 --> Model Class Initialized
DEBUG - 2017-07-21 19:28:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:28:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:28:49 --> move_uploaded_file(./uploads/categories/193541500645529.jpg): failed to open stream: No such file or directory
ERROR - 2017-07-21 19:28:49 --> Severity: Warning --> move_uploaded_file(./uploads/categories/193541500645529.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
ERROR - 2017-07-21 19:28:49 --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php252C.tmp' to './uploads/categories/193541500645529.jpg'
ERROR - 2017-07-21 19:28:49 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php252C.tmp' to './uploads/categories/193541500645529.jpg' C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
INFO - 2017-07-21 15:59:00 --> Config Class Initialized
INFO - 2017-07-21 15:59:00 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:59:00 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:59:00 --> Utf8 Class Initialized
INFO - 2017-07-21 15:59:00 --> URI Class Initialized
INFO - 2017-07-21 15:59:00 --> Router Class Initialized
INFO - 2017-07-21 15:59:00 --> Output Class Initialized
INFO - 2017-07-21 15:59:00 --> Security Class Initialized
DEBUG - 2017-07-21 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:59:00 --> Input Class Initialized
INFO - 2017-07-21 15:59:00 --> Language Class Initialized
INFO - 2017-07-21 15:59:00 --> Loader Class Initialized
INFO - 2017-07-21 15:59:00 --> Helper loaded: common_helper
INFO - 2017-07-21 15:59:00 --> Database Driver Class Initialized
INFO - 2017-07-21 15:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:59:00 --> Email Class Initialized
INFO - 2017-07-21 15:59:00 --> Controller Class Initialized
INFO - 2017-07-21 15:59:00 --> Helper loaded: form_helper
INFO - 2017-07-21 15:59:00 --> Form Validation Class Initialized
INFO - 2017-07-21 15:59:00 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:59:00 --> Helper loaded: url_helper
INFO - 2017-07-21 15:59:00 --> Model Class Initialized
INFO - 2017-07-21 15:59:00 --> Model Class Initialized
DEBUG - 2017-07-21 19:29:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:29:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:29:00 --> move_uploaded_file(/uploads/categories/196591500645540.jpg): failed to open stream: No such file or directory
ERROR - 2017-07-21 19:29:00 --> Severity: Warning --> move_uploaded_file(/uploads/categories/196591500645540.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
ERROR - 2017-07-21 19:29:00 --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php5332.tmp' to '/uploads/categories/196591500645540.jpg'
ERROR - 2017-07-21 19:29:00 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\php5332.tmp' to '/uploads/categories/196591500645540.jpg' C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
INFO - 2017-07-21 15:59:32 --> Config Class Initialized
INFO - 2017-07-21 15:59:32 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:59:32 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:59:32 --> Utf8 Class Initialized
INFO - 2017-07-21 15:59:32 --> URI Class Initialized
INFO - 2017-07-21 15:59:32 --> Router Class Initialized
INFO - 2017-07-21 15:59:32 --> Output Class Initialized
INFO - 2017-07-21 15:59:32 --> Security Class Initialized
DEBUG - 2017-07-21 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:59:32 --> Input Class Initialized
INFO - 2017-07-21 15:59:32 --> Language Class Initialized
INFO - 2017-07-21 15:59:32 --> Loader Class Initialized
INFO - 2017-07-21 15:59:32 --> Helper loaded: common_helper
INFO - 2017-07-21 15:59:32 --> Database Driver Class Initialized
INFO - 2017-07-21 15:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:59:32 --> Email Class Initialized
INFO - 2017-07-21 15:59:32 --> Controller Class Initialized
INFO - 2017-07-21 15:59:32 --> Helper loaded: form_helper
INFO - 2017-07-21 15:59:32 --> Form Validation Class Initialized
INFO - 2017-07-21 15:59:32 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:59:32 --> Helper loaded: url_helper
INFO - 2017-07-21 15:59:32 --> Model Class Initialized
INFO - 2017-07-21 15:59:32 --> Model Class Initialized
DEBUG - 2017-07-21 19:29:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:29:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:29:32 --> move_uploaded_file(./uploads/categories/95161500645572.jpg): failed to open stream: No such file or directory
ERROR - 2017-07-21 19:29:32 --> Severity: Warning --> move_uploaded_file(./uploads/categories/95161500645572.jpg): failed to open stream: No such file or directory C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
ERROR - 2017-07-21 19:29:32 --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\phpCDC2.tmp' to './uploads/categories/95161500645572.jpg'
ERROR - 2017-07-21 19:29:32 --> Severity: Warning --> move_uploaded_file(): Unable to move 'C:\xampp\tmp\phpCDC2.tmp' to './uploads/categories/95161500645572.jpg' C:\xampp\htdocs\FlickNews\admin\application\controllers\Categories.php 104
INFO - 2017-07-21 15:59:44 --> Config Class Initialized
INFO - 2017-07-21 15:59:44 --> Hooks Class Initialized
DEBUG - 2017-07-21 15:59:44 --> UTF-8 Support Enabled
INFO - 2017-07-21 15:59:44 --> Utf8 Class Initialized
INFO - 2017-07-21 15:59:44 --> URI Class Initialized
INFO - 2017-07-21 15:59:44 --> Router Class Initialized
INFO - 2017-07-21 15:59:44 --> Output Class Initialized
INFO - 2017-07-21 15:59:44 --> Security Class Initialized
DEBUG - 2017-07-21 15:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 15:59:44 --> Input Class Initialized
INFO - 2017-07-21 15:59:44 --> Language Class Initialized
INFO - 2017-07-21 15:59:44 --> Loader Class Initialized
INFO - 2017-07-21 15:59:44 --> Helper loaded: common_helper
INFO - 2017-07-21 15:59:44 --> Database Driver Class Initialized
INFO - 2017-07-21 15:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 15:59:44 --> Email Class Initialized
INFO - 2017-07-21 15:59:44 --> Controller Class Initialized
INFO - 2017-07-21 15:59:44 --> Helper loaded: form_helper
INFO - 2017-07-21 15:59:44 --> Form Validation Class Initialized
INFO - 2017-07-21 15:59:44 --> Helper loaded: email_helper
DEBUG - 2017-07-21 15:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 15:59:44 --> Helper loaded: url_helper
INFO - 2017-07-21 15:59:44 --> Model Class Initialized
INFO - 2017-07-21 15:59:44 --> Model Class Initialized
DEBUG - 2017-07-21 19:29:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:29:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
INFO - 2017-07-21 16:00:02 --> Loader Class Initialized
INFO - 2017-07-21 16:00:02 --> Helper loaded: common_helper
INFO - 2017-07-21 16:00:02 --> Database Driver Class Initialized
INFO - 2017-07-21 16:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:00:02 --> Email Class Initialized
INFO - 2017-07-21 16:00:02 --> Controller Class Initialized
INFO - 2017-07-21 16:00:02 --> Helper loaded: form_helper
INFO - 2017-07-21 16:00:02 --> Form Validation Class Initialized
INFO - 2017-07-21 16:00:02 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:00:02 --> Helper loaded: url_helper
INFO - 2017-07-21 16:00:02 --> Model Class Initialized
INFO - 2017-07-21 16:00:02 --> Model Class Initialized
DEBUG - 2017-07-21 19:30:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:30:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
INFO - 2017-07-21 16:00:02 --> Loader Class Initialized
INFO - 2017-07-21 16:00:02 --> Helper loaded: common_helper
INFO - 2017-07-21 16:00:02 --> Database Driver Class Initialized
INFO - 2017-07-21 16:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:00:02 --> Email Class Initialized
INFO - 2017-07-21 16:00:02 --> Controller Class Initialized
INFO - 2017-07-21 16:00:02 --> Helper loaded: form_helper
INFO - 2017-07-21 16:00:02 --> Form Validation Class Initialized
INFO - 2017-07-21 16:00:02 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:00:02 --> Helper loaded: url_helper
INFO - 2017-07-21 16:00:02 --> Model Class Initialized
INFO - 2017-07-21 16:00:02 --> Model Class Initialized
INFO - 2017-07-21 19:30:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:30:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:30:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:30:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:30:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:30:02 --> Final output sent to browser
DEBUG - 2017-07-21 19:30:02 --> Total execution time: 0.0708
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Config Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
INFO - 2017-07-21 16:00:02 --> Hooks Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
DEBUG - 2017-07-21 16:00:02 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:00:02 --> Utf8 Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> URI Class Initialized
INFO - 2017-07-21 16:00:02 --> Router Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
INFO - 2017-07-21 16:00:02 --> Output Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Security Class Initialized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
DEBUG - 2017-07-21 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:00:02 --> Input Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:00:02 --> Language Class Initialized
ERROR - 2017-07-21 16:00:02 --> 404 Page Not Found: Uploads/categories
INFO - 2017-07-21 16:01:43 --> Config Class Initialized
INFO - 2017-07-21 16:01:43 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:01:43 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:01:43 --> Utf8 Class Initialized
INFO - 2017-07-21 16:01:43 --> URI Class Initialized
INFO - 2017-07-21 16:01:43 --> Router Class Initialized
INFO - 2017-07-21 16:01:43 --> Output Class Initialized
INFO - 2017-07-21 16:01:43 --> Security Class Initialized
DEBUG - 2017-07-21 16:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:01:43 --> Input Class Initialized
INFO - 2017-07-21 16:01:43 --> Language Class Initialized
INFO - 2017-07-21 16:01:43 --> Loader Class Initialized
INFO - 2017-07-21 16:01:43 --> Helper loaded: common_helper
INFO - 2017-07-21 16:01:43 --> Database Driver Class Initialized
INFO - 2017-07-21 16:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:01:43 --> Email Class Initialized
INFO - 2017-07-21 16:01:43 --> Controller Class Initialized
INFO - 2017-07-21 16:01:43 --> Helper loaded: form_helper
INFO - 2017-07-21 16:01:43 --> Form Validation Class Initialized
INFO - 2017-07-21 16:01:43 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:01:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:01:43 --> Helper loaded: url_helper
INFO - 2017-07-21 16:01:43 --> Model Class Initialized
INFO - 2017-07-21 16:01:43 --> Model Class Initialized
INFO - 2017-07-21 19:31:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:31:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:31:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:31:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:31:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:31:43 --> Final output sent to browser
DEBUG - 2017-07-21 19:31:43 --> Total execution time: 0.0499
INFO - 2017-07-21 16:02:33 --> Config Class Initialized
INFO - 2017-07-21 16:02:33 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:02:33 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:02:33 --> Utf8 Class Initialized
INFO - 2017-07-21 16:02:33 --> URI Class Initialized
INFO - 2017-07-21 16:02:33 --> Router Class Initialized
INFO - 2017-07-21 16:02:33 --> Output Class Initialized
INFO - 2017-07-21 16:02:33 --> Security Class Initialized
DEBUG - 2017-07-21 16:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:02:33 --> Input Class Initialized
INFO - 2017-07-21 16:02:33 --> Language Class Initialized
INFO - 2017-07-21 16:02:33 --> Loader Class Initialized
INFO - 2017-07-21 16:02:33 --> Helper loaded: common_helper
INFO - 2017-07-21 16:02:33 --> Database Driver Class Initialized
INFO - 2017-07-21 16:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:02:33 --> Email Class Initialized
INFO - 2017-07-21 16:02:33 --> Controller Class Initialized
INFO - 2017-07-21 16:02:33 --> Helper loaded: form_helper
INFO - 2017-07-21 16:02:33 --> Form Validation Class Initialized
INFO - 2017-07-21 16:02:33 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:02:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:02:33 --> Helper loaded: url_helper
INFO - 2017-07-21 16:02:33 --> Model Class Initialized
INFO - 2017-07-21 16:02:33 --> Model Class Initialized
INFO - 2017-07-21 19:32:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:32:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:32:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:32:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:32:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:32:33 --> Final output sent to browser
DEBUG - 2017-07-21 19:32:33 --> Total execution time: 0.0569
INFO - 2017-07-21 16:02:35 --> Config Class Initialized
INFO - 2017-07-21 16:02:35 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:02:35 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:02:35 --> Utf8 Class Initialized
INFO - 2017-07-21 16:02:35 --> URI Class Initialized
INFO - 2017-07-21 16:02:35 --> Router Class Initialized
INFO - 2017-07-21 16:02:35 --> Output Class Initialized
INFO - 2017-07-21 16:02:35 --> Security Class Initialized
DEBUG - 2017-07-21 16:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:02:35 --> Input Class Initialized
INFO - 2017-07-21 16:02:35 --> Language Class Initialized
INFO - 2017-07-21 16:02:35 --> Loader Class Initialized
INFO - 2017-07-21 16:02:35 --> Helper loaded: common_helper
INFO - 2017-07-21 16:02:35 --> Database Driver Class Initialized
INFO - 2017-07-21 16:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:02:35 --> Email Class Initialized
INFO - 2017-07-21 16:02:35 --> Controller Class Initialized
INFO - 2017-07-21 16:02:35 --> Helper loaded: form_helper
INFO - 2017-07-21 16:02:35 --> Form Validation Class Initialized
INFO - 2017-07-21 16:02:35 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:02:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:02:35 --> Helper loaded: url_helper
INFO - 2017-07-21 16:02:35 --> Model Class Initialized
INFO - 2017-07-21 16:02:35 --> Model Class Initialized
INFO - 2017-07-21 19:32:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:32:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:32:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:32:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:32:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:32:35 --> Final output sent to browser
DEBUG - 2017-07-21 19:32:35 --> Total execution time: 0.0600
INFO - 2017-07-21 16:02:39 --> Config Class Initialized
INFO - 2017-07-21 16:02:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:02:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:02:39 --> Utf8 Class Initialized
INFO - 2017-07-21 16:02:39 --> URI Class Initialized
INFO - 2017-07-21 16:02:39 --> Router Class Initialized
INFO - 2017-07-21 16:02:39 --> Output Class Initialized
INFO - 2017-07-21 16:02:39 --> Security Class Initialized
DEBUG - 2017-07-21 16:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:02:39 --> Input Class Initialized
INFO - 2017-07-21 16:02:39 --> Language Class Initialized
INFO - 2017-07-21 16:02:39 --> Loader Class Initialized
INFO - 2017-07-21 16:02:39 --> Helper loaded: common_helper
INFO - 2017-07-21 16:02:39 --> Database Driver Class Initialized
INFO - 2017-07-21 16:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:02:39 --> Email Class Initialized
INFO - 2017-07-21 16:02:39 --> Controller Class Initialized
INFO - 2017-07-21 16:02:39 --> Helper loaded: form_helper
INFO - 2017-07-21 16:02:39 --> Form Validation Class Initialized
INFO - 2017-07-21 16:02:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:02:39 --> Helper loaded: url_helper
INFO - 2017-07-21 16:02:39 --> Model Class Initialized
INFO - 2017-07-21 16:02:39 --> Model Class Initialized
DEBUG - 2017-07-21 19:32:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:32:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 16:02:39 --> Config Class Initialized
INFO - 2017-07-21 16:02:39 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:02:39 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:02:39 --> Utf8 Class Initialized
INFO - 2017-07-21 16:02:39 --> URI Class Initialized
INFO - 2017-07-21 16:02:39 --> Router Class Initialized
INFO - 2017-07-21 16:02:39 --> Output Class Initialized
INFO - 2017-07-21 16:02:39 --> Security Class Initialized
DEBUG - 2017-07-21 16:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:02:39 --> Input Class Initialized
INFO - 2017-07-21 16:02:39 --> Language Class Initialized
INFO - 2017-07-21 16:02:39 --> Loader Class Initialized
INFO - 2017-07-21 16:02:39 --> Helper loaded: common_helper
INFO - 2017-07-21 16:02:39 --> Database Driver Class Initialized
INFO - 2017-07-21 16:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:02:39 --> Email Class Initialized
INFO - 2017-07-21 16:02:39 --> Controller Class Initialized
INFO - 2017-07-21 16:02:39 --> Helper loaded: form_helper
INFO - 2017-07-21 16:02:39 --> Form Validation Class Initialized
INFO - 2017-07-21 16:02:39 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:02:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:02:39 --> Helper loaded: url_helper
INFO - 2017-07-21 16:02:39 --> Model Class Initialized
INFO - 2017-07-21 16:02:39 --> Model Class Initialized
INFO - 2017-07-21 19:32:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:32:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:32:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:32:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:32:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:32:39 --> Final output sent to browser
DEBUG - 2017-07-21 19:32:39 --> Total execution time: 0.0582
INFO - 2017-07-21 16:03:13 --> Config Class Initialized
INFO - 2017-07-21 16:03:13 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:13 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:13 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:13 --> URI Class Initialized
INFO - 2017-07-21 16:03:13 --> Router Class Initialized
INFO - 2017-07-21 16:03:13 --> Output Class Initialized
INFO - 2017-07-21 16:03:13 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:13 --> Input Class Initialized
INFO - 2017-07-21 16:03:13 --> Language Class Initialized
INFO - 2017-07-21 16:03:13 --> Loader Class Initialized
INFO - 2017-07-21 16:03:13 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:13 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:13 --> Email Class Initialized
INFO - 2017-07-21 16:03:13 --> Controller Class Initialized
INFO - 2017-07-21 16:03:13 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:13 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:13 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:13 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:13 --> Model Class Initialized
INFO - 2017-07-21 16:03:13 --> Model Class Initialized
INFO - 2017-07-21 19:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:33:13 --> Final output sent to browser
DEBUG - 2017-07-21 19:33:13 --> Total execution time: 0.0503
INFO - 2017-07-21 16:03:15 --> Config Class Initialized
INFO - 2017-07-21 16:03:15 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:15 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:15 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:15 --> URI Class Initialized
INFO - 2017-07-21 16:03:15 --> Router Class Initialized
INFO - 2017-07-21 16:03:15 --> Output Class Initialized
INFO - 2017-07-21 16:03:15 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:15 --> Input Class Initialized
INFO - 2017-07-21 16:03:15 --> Language Class Initialized
INFO - 2017-07-21 16:03:15 --> Loader Class Initialized
INFO - 2017-07-21 16:03:15 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:15 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:15 --> Email Class Initialized
INFO - 2017-07-21 16:03:15 --> Controller Class Initialized
INFO - 2017-07-21 16:03:15 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:15 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:15 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:15 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:15 --> Model Class Initialized
INFO - 2017-07-21 16:03:15 --> Model Class Initialized
INFO - 2017-07-21 19:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:33:15 --> Final output sent to browser
DEBUG - 2017-07-21 19:33:15 --> Total execution time: 0.0500
INFO - 2017-07-21 16:03:19 --> Config Class Initialized
INFO - 2017-07-21 16:03:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:19 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:19 --> URI Class Initialized
INFO - 2017-07-21 16:03:19 --> Router Class Initialized
INFO - 2017-07-21 16:03:19 --> Output Class Initialized
INFO - 2017-07-21 16:03:19 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:19 --> Input Class Initialized
INFO - 2017-07-21 16:03:19 --> Language Class Initialized
INFO - 2017-07-21 16:03:19 --> Loader Class Initialized
INFO - 2017-07-21 16:03:19 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:19 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:19 --> Email Class Initialized
INFO - 2017-07-21 16:03:19 --> Controller Class Initialized
INFO - 2017-07-21 16:03:19 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:19 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:19 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:19 --> Model Class Initialized
INFO - 2017-07-21 16:03:19 --> Model Class Initialized
DEBUG - 2017-07-21 19:33:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:33:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 16:03:42 --> Config Class Initialized
INFO - 2017-07-21 16:03:42 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:42 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:42 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:42 --> URI Class Initialized
INFO - 2017-07-21 16:03:42 --> Router Class Initialized
INFO - 2017-07-21 16:03:42 --> Output Class Initialized
INFO - 2017-07-21 16:03:42 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:42 --> Input Class Initialized
INFO - 2017-07-21 16:03:42 --> Language Class Initialized
INFO - 2017-07-21 16:03:42 --> Loader Class Initialized
INFO - 2017-07-21 16:03:42 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:42 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:42 --> Email Class Initialized
INFO - 2017-07-21 16:03:42 --> Controller Class Initialized
INFO - 2017-07-21 16:03:42 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:42 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:42 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:42 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:42 --> Model Class Initialized
INFO - 2017-07-21 16:03:42 --> Model Class Initialized
DEBUG - 2017-07-21 19:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:33:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 16:03:42 --> Config Class Initialized
INFO - 2017-07-21 16:03:42 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:42 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:42 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:42 --> URI Class Initialized
INFO - 2017-07-21 16:03:42 --> Router Class Initialized
INFO - 2017-07-21 16:03:42 --> Output Class Initialized
INFO - 2017-07-21 16:03:42 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:42 --> Input Class Initialized
INFO - 2017-07-21 16:03:42 --> Language Class Initialized
INFO - 2017-07-21 16:03:42 --> Loader Class Initialized
INFO - 2017-07-21 16:03:42 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:42 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:42 --> Email Class Initialized
INFO - 2017-07-21 16:03:42 --> Controller Class Initialized
INFO - 2017-07-21 16:03:42 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:42 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:42 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:42 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:42 --> Model Class Initialized
INFO - 2017-07-21 16:03:42 --> Model Class Initialized
INFO - 2017-07-21 19:33:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:33:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:33:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:33:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:33:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:33:42 --> Final output sent to browser
DEBUG - 2017-07-21 19:33:42 --> Total execution time: 0.0470
INFO - 2017-07-21 16:03:45 --> Config Class Initialized
INFO - 2017-07-21 16:03:45 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:46 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:46 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:46 --> URI Class Initialized
INFO - 2017-07-21 16:03:46 --> Router Class Initialized
INFO - 2017-07-21 16:03:46 --> Output Class Initialized
INFO - 2017-07-21 16:03:46 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:46 --> Input Class Initialized
INFO - 2017-07-21 16:03:46 --> Language Class Initialized
INFO - 2017-07-21 16:03:46 --> Loader Class Initialized
INFO - 2017-07-21 16:03:46 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:46 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:46 --> Email Class Initialized
INFO - 2017-07-21 16:03:46 --> Controller Class Initialized
INFO - 2017-07-21 16:03:46 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:46 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:46 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:46 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:46 --> Model Class Initialized
INFO - 2017-07-21 16:03:46 --> Model Class Initialized
INFO - 2017-07-21 19:33:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:33:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:33:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:33:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:33:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:33:46 --> Final output sent to browser
DEBUG - 2017-07-21 19:33:46 --> Total execution time: 0.0500
INFO - 2017-07-21 16:03:49 --> Config Class Initialized
INFO - 2017-07-21 16:03:49 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:49 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:49 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:49 --> URI Class Initialized
INFO - 2017-07-21 16:03:49 --> Router Class Initialized
INFO - 2017-07-21 16:03:49 --> Output Class Initialized
INFO - 2017-07-21 16:03:49 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:49 --> Input Class Initialized
INFO - 2017-07-21 16:03:49 --> Language Class Initialized
INFO - 2017-07-21 16:03:49 --> Loader Class Initialized
INFO - 2017-07-21 16:03:49 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:49 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:49 --> Email Class Initialized
INFO - 2017-07-21 16:03:49 --> Controller Class Initialized
INFO - 2017-07-21 16:03:49 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:49 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:49 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:49 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:49 --> Model Class Initialized
INFO - 2017-07-21 16:03:49 --> Model Class Initialized
DEBUG - 2017-07-21 19:33:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:33:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-21 16:03:49 --> Config Class Initialized
INFO - 2017-07-21 16:03:49 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:03:49 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:03:49 --> Utf8 Class Initialized
INFO - 2017-07-21 16:03:49 --> URI Class Initialized
INFO - 2017-07-21 16:03:49 --> Router Class Initialized
INFO - 2017-07-21 16:03:49 --> Output Class Initialized
INFO - 2017-07-21 16:03:49 --> Security Class Initialized
DEBUG - 2017-07-21 16:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:03:49 --> Input Class Initialized
INFO - 2017-07-21 16:03:49 --> Language Class Initialized
INFO - 2017-07-21 16:03:49 --> Loader Class Initialized
INFO - 2017-07-21 16:03:49 --> Helper loaded: common_helper
INFO - 2017-07-21 16:03:49 --> Database Driver Class Initialized
INFO - 2017-07-21 16:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:03:49 --> Email Class Initialized
INFO - 2017-07-21 16:03:49 --> Controller Class Initialized
INFO - 2017-07-21 16:03:49 --> Helper loaded: form_helper
INFO - 2017-07-21 16:03:49 --> Form Validation Class Initialized
INFO - 2017-07-21 16:03:49 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:03:49 --> Helper loaded: url_helper
INFO - 2017-07-21 16:03:49 --> Model Class Initialized
INFO - 2017-07-21 16:03:49 --> Model Class Initialized
INFO - 2017-07-21 19:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:33:49 --> Final output sent to browser
DEBUG - 2017-07-21 19:33:49 --> Total execution time: 0.0525
INFO - 2017-07-21 16:04:12 --> Config Class Initialized
INFO - 2017-07-21 16:04:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:12 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:12 --> URI Class Initialized
INFO - 2017-07-21 16:04:12 --> Router Class Initialized
INFO - 2017-07-21 16:04:12 --> Output Class Initialized
INFO - 2017-07-21 16:04:12 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:12 --> Input Class Initialized
INFO - 2017-07-21 16:04:12 --> Language Class Initialized
INFO - 2017-07-21 16:04:12 --> Loader Class Initialized
INFO - 2017-07-21 16:04:12 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:12 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:12 --> Email Class Initialized
INFO - 2017-07-21 16:04:12 --> Controller Class Initialized
INFO - 2017-07-21 16:04:12 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:12 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:12 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:12 --> Model Class Initialized
INFO - 2017-07-21 16:04:12 --> Model Class Initialized
INFO - 2017-07-21 16:04:12 --> Config Class Initialized
INFO - 2017-07-21 16:04:12 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:12 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:12 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:12 --> URI Class Initialized
INFO - 2017-07-21 16:04:12 --> Router Class Initialized
INFO - 2017-07-21 16:04:12 --> Output Class Initialized
INFO - 2017-07-21 16:04:12 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:12 --> Input Class Initialized
INFO - 2017-07-21 16:04:12 --> Language Class Initialized
INFO - 2017-07-21 16:04:12 --> Loader Class Initialized
INFO - 2017-07-21 16:04:12 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:12 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:12 --> Email Class Initialized
INFO - 2017-07-21 16:04:12 --> Controller Class Initialized
INFO - 2017-07-21 16:04:12 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:12 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:12 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:12 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:12 --> Model Class Initialized
INFO - 2017-07-21 16:04:12 --> Model Class Initialized
INFO - 2017-07-21 19:34:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:34:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:34:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:34:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:34:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:34:12 --> Final output sent to browser
DEBUG - 2017-07-21 19:34:12 --> Total execution time: 0.0502
INFO - 2017-07-21 16:04:15 --> Config Class Initialized
INFO - 2017-07-21 16:04:15 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:15 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:15 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:15 --> URI Class Initialized
INFO - 2017-07-21 16:04:15 --> Router Class Initialized
INFO - 2017-07-21 16:04:15 --> Output Class Initialized
INFO - 2017-07-21 16:04:15 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:15 --> Input Class Initialized
INFO - 2017-07-21 16:04:15 --> Language Class Initialized
INFO - 2017-07-21 16:04:15 --> Loader Class Initialized
INFO - 2017-07-21 16:04:15 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:15 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:15 --> Email Class Initialized
INFO - 2017-07-21 16:04:15 --> Controller Class Initialized
INFO - 2017-07-21 16:04:15 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:15 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:15 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:15 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:15 --> Model Class Initialized
INFO - 2017-07-21 16:04:15 --> Model Class Initialized
INFO - 2017-07-21 16:04:15 --> Config Class Initialized
INFO - 2017-07-21 16:04:15 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:15 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:15 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:15 --> URI Class Initialized
INFO - 2017-07-21 16:04:15 --> Router Class Initialized
INFO - 2017-07-21 16:04:15 --> Output Class Initialized
INFO - 2017-07-21 16:04:15 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:15 --> Input Class Initialized
INFO - 2017-07-21 16:04:15 --> Language Class Initialized
INFO - 2017-07-21 16:04:15 --> Loader Class Initialized
INFO - 2017-07-21 16:04:15 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:15 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:15 --> Email Class Initialized
INFO - 2017-07-21 16:04:15 --> Controller Class Initialized
INFO - 2017-07-21 16:04:15 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:15 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:15 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:15 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:15 --> Model Class Initialized
INFO - 2017-07-21 16:04:15 --> Model Class Initialized
INFO - 2017-07-21 19:34:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:34:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:34:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:34:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:34:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:34:15 --> Final output sent to browser
DEBUG - 2017-07-21 19:34:15 --> Total execution time: 0.0781
INFO - 2017-07-21 16:04:19 --> Config Class Initialized
INFO - 2017-07-21 16:04:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:19 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:19 --> URI Class Initialized
INFO - 2017-07-21 16:04:19 --> Router Class Initialized
INFO - 2017-07-21 16:04:19 --> Output Class Initialized
INFO - 2017-07-21 16:04:19 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:19 --> Input Class Initialized
INFO - 2017-07-21 16:04:19 --> Language Class Initialized
INFO - 2017-07-21 16:04:19 --> Loader Class Initialized
INFO - 2017-07-21 16:04:19 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:19 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:19 --> Email Class Initialized
INFO - 2017-07-21 16:04:19 --> Controller Class Initialized
INFO - 2017-07-21 16:04:19 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:19 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:19 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:19 --> Model Class Initialized
INFO - 2017-07-21 16:04:19 --> Model Class Initialized
INFO - 2017-07-21 16:04:19 --> Config Class Initialized
INFO - 2017-07-21 16:04:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:19 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:19 --> URI Class Initialized
INFO - 2017-07-21 16:04:19 --> Router Class Initialized
INFO - 2017-07-21 16:04:19 --> Output Class Initialized
INFO - 2017-07-21 16:04:19 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:19 --> Input Class Initialized
INFO - 2017-07-21 16:04:19 --> Language Class Initialized
INFO - 2017-07-21 16:04:19 --> Loader Class Initialized
INFO - 2017-07-21 16:04:19 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:19 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:19 --> Email Class Initialized
INFO - 2017-07-21 16:04:19 --> Controller Class Initialized
INFO - 2017-07-21 16:04:19 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:19 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:19 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:19 --> Model Class Initialized
INFO - 2017-07-21 16:04:19 --> Model Class Initialized
INFO - 2017-07-21 19:34:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:34:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:34:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:34:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:34:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:34:19 --> Final output sent to browser
DEBUG - 2017-07-21 19:34:19 --> Total execution time: 0.0483
INFO - 2017-07-21 16:04:23 --> Config Class Initialized
INFO - 2017-07-21 16:04:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:23 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:23 --> URI Class Initialized
INFO - 2017-07-21 16:04:23 --> Router Class Initialized
INFO - 2017-07-21 16:04:23 --> Output Class Initialized
INFO - 2017-07-21 16:04:23 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:23 --> Input Class Initialized
INFO - 2017-07-21 16:04:23 --> Language Class Initialized
INFO - 2017-07-21 16:04:23 --> Loader Class Initialized
INFO - 2017-07-21 16:04:23 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:23 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:23 --> Email Class Initialized
INFO - 2017-07-21 16:04:23 --> Controller Class Initialized
INFO - 2017-07-21 16:04:23 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:23 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:23 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:23 --> Model Class Initialized
INFO - 2017-07-21 16:04:23 --> Model Class Initialized
INFO - 2017-07-21 16:04:23 --> Config Class Initialized
INFO - 2017-07-21 16:04:23 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:23 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:23 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:23 --> URI Class Initialized
INFO - 2017-07-21 16:04:23 --> Router Class Initialized
INFO - 2017-07-21 16:04:23 --> Output Class Initialized
INFO - 2017-07-21 16:04:23 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:23 --> Input Class Initialized
INFO - 2017-07-21 16:04:23 --> Language Class Initialized
INFO - 2017-07-21 16:04:23 --> Loader Class Initialized
INFO - 2017-07-21 16:04:23 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:23 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:23 --> Email Class Initialized
INFO - 2017-07-21 16:04:23 --> Controller Class Initialized
INFO - 2017-07-21 16:04:23 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:23 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:23 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:23 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:23 --> Model Class Initialized
INFO - 2017-07-21 16:04:23 --> Model Class Initialized
INFO - 2017-07-21 19:34:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:34:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:34:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:34:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:34:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:34:23 --> Final output sent to browser
DEBUG - 2017-07-21 19:34:23 --> Total execution time: 0.0497
INFO - 2017-07-21 16:04:26 --> Config Class Initialized
INFO - 2017-07-21 16:04:26 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:26 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:26 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:26 --> URI Class Initialized
INFO - 2017-07-21 16:04:26 --> Router Class Initialized
INFO - 2017-07-21 16:04:26 --> Output Class Initialized
INFO - 2017-07-21 16:04:26 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:26 --> Input Class Initialized
INFO - 2017-07-21 16:04:26 --> Language Class Initialized
INFO - 2017-07-21 16:04:26 --> Loader Class Initialized
INFO - 2017-07-21 16:04:26 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:26 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:26 --> Email Class Initialized
INFO - 2017-07-21 16:04:26 --> Controller Class Initialized
INFO - 2017-07-21 16:04:26 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:26 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:26 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:26 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:26 --> Model Class Initialized
INFO - 2017-07-21 16:04:26 --> Model Class Initialized
INFO - 2017-07-21 16:04:26 --> Config Class Initialized
INFO - 2017-07-21 16:04:26 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:04:26 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:04:26 --> Utf8 Class Initialized
INFO - 2017-07-21 16:04:26 --> URI Class Initialized
INFO - 2017-07-21 16:04:26 --> Router Class Initialized
INFO - 2017-07-21 16:04:26 --> Output Class Initialized
INFO - 2017-07-21 16:04:26 --> Security Class Initialized
DEBUG - 2017-07-21 16:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:04:26 --> Input Class Initialized
INFO - 2017-07-21 16:04:26 --> Language Class Initialized
INFO - 2017-07-21 16:04:26 --> Loader Class Initialized
INFO - 2017-07-21 16:04:26 --> Helper loaded: common_helper
INFO - 2017-07-21 16:04:26 --> Database Driver Class Initialized
INFO - 2017-07-21 16:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:04:26 --> Email Class Initialized
INFO - 2017-07-21 16:04:26 --> Controller Class Initialized
INFO - 2017-07-21 16:04:26 --> Helper loaded: form_helper
INFO - 2017-07-21 16:04:26 --> Form Validation Class Initialized
INFO - 2017-07-21 16:04:26 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:04:26 --> Helper loaded: url_helper
INFO - 2017-07-21 16:04:26 --> Model Class Initialized
INFO - 2017-07-21 16:04:26 --> Model Class Initialized
INFO - 2017-07-21 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:34:26 --> Final output sent to browser
DEBUG - 2017-07-21 19:34:26 --> Total execution time: 0.0478
INFO - 2017-07-21 16:05:09 --> Config Class Initialized
INFO - 2017-07-21 16:05:09 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:09 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:09 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:09 --> URI Class Initialized
INFO - 2017-07-21 16:05:09 --> Router Class Initialized
INFO - 2017-07-21 16:05:09 --> Output Class Initialized
INFO - 2017-07-21 16:05:09 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:09 --> Input Class Initialized
INFO - 2017-07-21 16:05:09 --> Language Class Initialized
INFO - 2017-07-21 16:05:09 --> Loader Class Initialized
INFO - 2017-07-21 16:05:09 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:09 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:09 --> Email Class Initialized
INFO - 2017-07-21 16:05:09 --> Controller Class Initialized
INFO - 2017-07-21 16:05:09 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:09 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:09 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:09 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:09 --> Model Class Initialized
INFO - 2017-07-21 16:05:09 --> Model Class Initialized
INFO - 2017-07-21 19:35:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:35:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:35:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:35:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 19:35:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:35:09 --> Final output sent to browser
DEBUG - 2017-07-21 19:35:09 --> Total execution time: 0.0746
INFO - 2017-07-21 16:05:10 --> Config Class Initialized
INFO - 2017-07-21 16:05:10 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:10 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:10 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:10 --> URI Class Initialized
INFO - 2017-07-21 16:05:10 --> Router Class Initialized
INFO - 2017-07-21 16:05:10 --> Output Class Initialized
INFO - 2017-07-21 16:05:10 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:10 --> Input Class Initialized
INFO - 2017-07-21 16:05:10 --> Language Class Initialized
INFO - 2017-07-21 16:05:10 --> Loader Class Initialized
INFO - 2017-07-21 16:05:10 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:10 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:10 --> Email Class Initialized
INFO - 2017-07-21 16:05:10 --> Controller Class Initialized
INFO - 2017-07-21 16:05:10 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:10 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:10 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:10 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:10 --> Model Class Initialized
INFO - 2017-07-21 16:05:10 --> Model Class Initialized
INFO - 2017-07-21 19:35:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:35:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:35:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:35:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:35:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:35:10 --> Final output sent to browser
DEBUG - 2017-07-21 19:35:10 --> Total execution time: 0.0542
INFO - 2017-07-21 16:05:19 --> Config Class Initialized
INFO - 2017-07-21 16:05:19 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:19 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:19 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:19 --> URI Class Initialized
INFO - 2017-07-21 16:05:19 --> Router Class Initialized
INFO - 2017-07-21 16:05:19 --> Output Class Initialized
INFO - 2017-07-21 16:05:19 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:19 --> Input Class Initialized
INFO - 2017-07-21 16:05:19 --> Language Class Initialized
INFO - 2017-07-21 16:05:19 --> Loader Class Initialized
INFO - 2017-07-21 16:05:19 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:19 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:19 --> Email Class Initialized
INFO - 2017-07-21 16:05:19 --> Controller Class Initialized
INFO - 2017-07-21 16:05:19 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:19 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:19 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:19 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:19 --> Model Class Initialized
INFO - 2017-07-21 16:05:19 --> Model Class Initialized
INFO - 2017-07-21 19:35:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:35:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:35:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:35:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:35:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:35:19 --> Final output sent to browser
DEBUG - 2017-07-21 19:35:19 --> Total execution time: 0.0692
INFO - 2017-07-21 16:05:27 --> Config Class Initialized
INFO - 2017-07-21 16:05:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:27 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:27 --> URI Class Initialized
INFO - 2017-07-21 16:05:27 --> Router Class Initialized
INFO - 2017-07-21 16:05:27 --> Output Class Initialized
INFO - 2017-07-21 16:05:27 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:27 --> Input Class Initialized
INFO - 2017-07-21 16:05:27 --> Language Class Initialized
INFO - 2017-07-21 16:05:27 --> Loader Class Initialized
INFO - 2017-07-21 16:05:27 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:27 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:27 --> Email Class Initialized
INFO - 2017-07-21 16:05:27 --> Controller Class Initialized
INFO - 2017-07-21 16:05:27 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:27 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:27 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:27 --> Model Class Initialized
INFO - 2017-07-21 16:05:27 --> Model Class Initialized
DEBUG - 2017-07-21 19:35:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-21 19:35:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-21 19:35:27 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-21 19:35:27 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-21 19:35:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `cat_name` = 'Volly ball', `cat_colour_code` = '#FFCE00', `cat_image` = '164241' at line 1 - Invalid query: UPDATE `categories` SET `details` = , `cat_name` = 'Volly ball', `cat_colour_code` = '#FFCE00', `cat_image` = '164241500645927.jpg', `updatedTime` = '17-07-21 07:35:27'
WHERE `cat_id` = '5'
INFO - 2017-07-21 16:05:27 --> Config Class Initialized
INFO - 2017-07-21 16:05:27 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:27 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:27 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:27 --> URI Class Initialized
INFO - 2017-07-21 16:05:27 --> Router Class Initialized
INFO - 2017-07-21 16:05:27 --> Output Class Initialized
INFO - 2017-07-21 16:05:27 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:27 --> Input Class Initialized
INFO - 2017-07-21 16:05:27 --> Language Class Initialized
INFO - 2017-07-21 16:05:27 --> Loader Class Initialized
INFO - 2017-07-21 16:05:27 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:27 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:27 --> Email Class Initialized
INFO - 2017-07-21 16:05:27 --> Controller Class Initialized
INFO - 2017-07-21 16:05:27 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:27 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:27 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:27 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:27 --> Model Class Initialized
INFO - 2017-07-21 16:05:27 --> Model Class Initialized
INFO - 2017-07-21 19:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:35:27 --> Final output sent to browser
DEBUG - 2017-07-21 19:35:27 --> Total execution time: 0.0459
INFO - 2017-07-21 16:05:30 --> Config Class Initialized
INFO - 2017-07-21 16:05:30 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:30 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:30 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:30 --> URI Class Initialized
INFO - 2017-07-21 16:05:30 --> Router Class Initialized
INFO - 2017-07-21 16:05:30 --> Output Class Initialized
INFO - 2017-07-21 16:05:30 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:30 --> Input Class Initialized
INFO - 2017-07-21 16:05:30 --> Language Class Initialized
INFO - 2017-07-21 16:05:30 --> Loader Class Initialized
INFO - 2017-07-21 16:05:30 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:30 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:30 --> Email Class Initialized
INFO - 2017-07-21 16:05:30 --> Controller Class Initialized
INFO - 2017-07-21 16:05:30 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:30 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:30 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:30 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:30 --> Model Class Initialized
INFO - 2017-07-21 16:05:30 --> Model Class Initialized
INFO - 2017-07-21 19:35:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:35:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:35:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:35:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:35:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:35:30 --> Final output sent to browser
DEBUG - 2017-07-21 19:35:30 --> Total execution time: 0.0478
INFO - 2017-07-21 16:05:31 --> Config Class Initialized
INFO - 2017-07-21 16:05:31 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:05:31 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:05:31 --> Utf8 Class Initialized
INFO - 2017-07-21 16:05:31 --> URI Class Initialized
INFO - 2017-07-21 16:05:31 --> Router Class Initialized
INFO - 2017-07-21 16:05:31 --> Output Class Initialized
INFO - 2017-07-21 16:05:31 --> Security Class Initialized
DEBUG - 2017-07-21 16:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:05:31 --> Input Class Initialized
INFO - 2017-07-21 16:05:31 --> Language Class Initialized
INFO - 2017-07-21 16:05:31 --> Loader Class Initialized
INFO - 2017-07-21 16:05:31 --> Helper loaded: common_helper
INFO - 2017-07-21 16:05:31 --> Database Driver Class Initialized
INFO - 2017-07-21 16:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:05:31 --> Email Class Initialized
INFO - 2017-07-21 16:05:31 --> Controller Class Initialized
INFO - 2017-07-21 16:05:31 --> Helper loaded: form_helper
INFO - 2017-07-21 16:05:31 --> Form Validation Class Initialized
INFO - 2017-07-21 16:05:31 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:05:31 --> Helper loaded: url_helper
INFO - 2017-07-21 16:05:31 --> Model Class Initialized
INFO - 2017-07-21 16:05:31 --> Model Class Initialized
INFO - 2017-07-21 19:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:35:31 --> Final output sent to browser
DEBUG - 2017-07-21 19:35:31 --> Total execution time: 0.0514
INFO - 2017-07-21 16:06:14 --> Config Class Initialized
INFO - 2017-07-21 16:06:14 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:14 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:14 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:14 --> URI Class Initialized
INFO - 2017-07-21 16:06:14 --> Router Class Initialized
INFO - 2017-07-21 16:06:14 --> Output Class Initialized
INFO - 2017-07-21 16:06:14 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:14 --> Input Class Initialized
INFO - 2017-07-21 16:06:14 --> Language Class Initialized
INFO - 2017-07-21 16:06:14 --> Loader Class Initialized
INFO - 2017-07-21 16:06:14 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:14 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:14 --> Email Class Initialized
INFO - 2017-07-21 16:06:14 --> Controller Class Initialized
INFO - 2017-07-21 16:06:14 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:14 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:14 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:14 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:14 --> Model Class Initialized
INFO - 2017-07-21 16:06:14 --> Model Class Initialized
INFO - 2017-07-21 19:36:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:36:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:36:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:14 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:14 --> Total execution time: 0.0505
INFO - 2017-07-21 16:06:25 --> Config Class Initialized
INFO - 2017-07-21 16:06:25 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:25 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:25 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:25 --> URI Class Initialized
INFO - 2017-07-21 16:06:25 --> Router Class Initialized
INFO - 2017-07-21 16:06:25 --> Output Class Initialized
INFO - 2017-07-21 16:06:25 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:25 --> Input Class Initialized
INFO - 2017-07-21 16:06:25 --> Language Class Initialized
INFO - 2017-07-21 16:06:25 --> Loader Class Initialized
INFO - 2017-07-21 16:06:25 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:25 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:25 --> Email Class Initialized
INFO - 2017-07-21 16:06:25 --> Controller Class Initialized
INFO - 2017-07-21 16:06:25 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:25 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:25 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:25 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:25 --> Model Class Initialized
INFO - 2017-07-21 16:06:25 --> Model Class Initialized
INFO - 2017-07-21 19:36:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-21 19:36:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-21 19:36:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:25 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:25 --> Total execution time: 0.0501
INFO - 2017-07-21 16:06:28 --> Config Class Initialized
INFO - 2017-07-21 16:06:28 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:28 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:28 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:28 --> URI Class Initialized
INFO - 2017-07-21 16:06:28 --> Router Class Initialized
INFO - 2017-07-21 16:06:28 --> Output Class Initialized
INFO - 2017-07-21 16:06:28 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:28 --> Input Class Initialized
INFO - 2017-07-21 16:06:28 --> Language Class Initialized
INFO - 2017-07-21 16:06:28 --> Loader Class Initialized
INFO - 2017-07-21 16:06:28 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:28 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:28 --> Email Class Initialized
INFO - 2017-07-21 16:06:28 --> Controller Class Initialized
INFO - 2017-07-21 16:06:28 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:28 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:28 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:28 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:28 --> Model Class Initialized
INFO - 2017-07-21 16:06:28 --> Model Class Initialized
INFO - 2017-07-21 19:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 19:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:36:28 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:28 --> Total execution time: 0.0458
INFO - 2017-07-21 16:06:29 --> Config Class Initialized
INFO - 2017-07-21 16:06:29 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:29 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:29 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:29 --> URI Class Initialized
INFO - 2017-07-21 16:06:29 --> Router Class Initialized
INFO - 2017-07-21 16:06:29 --> Output Class Initialized
INFO - 2017-07-21 16:06:29 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:29 --> Input Class Initialized
INFO - 2017-07-21 16:06:29 --> Language Class Initialized
INFO - 2017-07-21 16:06:29 --> Loader Class Initialized
INFO - 2017-07-21 16:06:29 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:29 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:29 --> Email Class Initialized
INFO - 2017-07-21 16:06:29 --> Controller Class Initialized
INFO - 2017-07-21 16:06:29 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:29 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:29 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:29 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:29 --> Model Class Initialized
INFO - 2017-07-21 16:06:29 --> Model Class Initialized
INFO - 2017-07-21 19:36:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:36:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:36:29 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:29 --> Total execution time: 0.0497
INFO - 2017-07-21 16:06:34 --> Config Class Initialized
INFO - 2017-07-21 16:06:34 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:34 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:34 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:34 --> URI Class Initialized
INFO - 2017-07-21 16:06:34 --> Router Class Initialized
INFO - 2017-07-21 16:06:34 --> Output Class Initialized
INFO - 2017-07-21 16:06:34 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:34 --> Input Class Initialized
INFO - 2017-07-21 16:06:34 --> Language Class Initialized
INFO - 2017-07-21 16:06:34 --> Loader Class Initialized
INFO - 2017-07-21 16:06:34 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:34 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:34 --> Email Class Initialized
INFO - 2017-07-21 16:06:34 --> Controller Class Initialized
INFO - 2017-07-21 16:06:34 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:34 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:34 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:34 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:34 --> Model Class Initialized
INFO - 2017-07-21 16:06:34 --> Model Class Initialized
INFO - 2017-07-21 19:36:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-21 19:36:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:36:34 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:34 --> Total execution time: 0.0464
INFO - 2017-07-21 16:06:48 --> Config Class Initialized
INFO - 2017-07-21 16:06:48 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:48 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:48 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:48 --> URI Class Initialized
INFO - 2017-07-21 16:06:48 --> Router Class Initialized
INFO - 2017-07-21 16:06:48 --> Output Class Initialized
INFO - 2017-07-21 16:06:48 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:48 --> Input Class Initialized
INFO - 2017-07-21 16:06:48 --> Language Class Initialized
INFO - 2017-07-21 16:06:48 --> Loader Class Initialized
INFO - 2017-07-21 16:06:48 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:48 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:48 --> Email Class Initialized
INFO - 2017-07-21 16:06:48 --> Controller Class Initialized
INFO - 2017-07-21 16:06:48 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:48 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:48 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:48 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:48 --> Model Class Initialized
INFO - 2017-07-21 16:06:48 --> Model Class Initialized
INFO - 2017-07-21 19:36:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:36:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:36:48 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:48 --> Total execution time: 0.0640
INFO - 2017-07-21 16:06:49 --> Config Class Initialized
INFO - 2017-07-21 16:06:49 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:49 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:49 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:49 --> URI Class Initialized
INFO - 2017-07-21 16:06:49 --> Router Class Initialized
INFO - 2017-07-21 16:06:49 --> Output Class Initialized
INFO - 2017-07-21 16:06:49 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:49 --> Input Class Initialized
INFO - 2017-07-21 16:06:49 --> Language Class Initialized
INFO - 2017-07-21 16:06:49 --> Loader Class Initialized
INFO - 2017-07-21 16:06:49 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:49 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:49 --> Email Class Initialized
INFO - 2017-07-21 16:06:49 --> Controller Class Initialized
INFO - 2017-07-21 16:06:49 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:49 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:49 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:49 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:49 --> Model Class Initialized
INFO - 2017-07-21 16:06:49 --> Model Class Initialized
INFO - 2017-07-21 16:06:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 16:06:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-21 16:06:49 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-21 16:06:49 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 16:06:49 --> Trying to get property of non-object
ERROR - 2017-07-21 16:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-21 16:06:49 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-21 16:06:49 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 16:06:49 --> Trying to get property of non-object
ERROR - 2017-07-21 16:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-21 16:06:49 --> Undefined variable: Evenets
ERROR - 2017-07-21 16:06:49 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-21 16:06:49 --> Trying to get property of non-object
ERROR - 2017-07-21 16:06:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-21 16:06:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-21 16:06:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 16:06:49 --> Final output sent to browser
DEBUG - 2017-07-21 16:06:49 --> Total execution time: 0.0536
INFO - 2017-07-21 16:06:50 --> Config Class Initialized
INFO - 2017-07-21 16:06:50 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:06:50 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:06:50 --> Utf8 Class Initialized
INFO - 2017-07-21 16:06:50 --> URI Class Initialized
INFO - 2017-07-21 16:06:50 --> Router Class Initialized
INFO - 2017-07-21 16:06:50 --> Output Class Initialized
INFO - 2017-07-21 16:06:50 --> Security Class Initialized
DEBUG - 2017-07-21 16:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:06:50 --> Input Class Initialized
INFO - 2017-07-21 16:06:50 --> Language Class Initialized
INFO - 2017-07-21 16:06:50 --> Loader Class Initialized
INFO - 2017-07-21 16:06:50 --> Helper loaded: common_helper
INFO - 2017-07-21 16:06:50 --> Database Driver Class Initialized
INFO - 2017-07-21 16:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:06:50 --> Email Class Initialized
INFO - 2017-07-21 16:06:50 --> Controller Class Initialized
INFO - 2017-07-21 16:06:50 --> Helper loaded: form_helper
INFO - 2017-07-21 16:06:50 --> Form Validation Class Initialized
INFO - 2017-07-21 16:06:50 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:06:50 --> Helper loaded: url_helper
INFO - 2017-07-21 16:06:50 --> Model Class Initialized
INFO - 2017-07-21 16:06:50 --> Model Class Initialized
INFO - 2017-07-21 19:36:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:36:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:36:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:36:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:36:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:36:50 --> Final output sent to browser
DEBUG - 2017-07-21 19:36:50 --> Total execution time: 0.0494
INFO - 2017-07-21 16:07:16 --> Config Class Initialized
INFO - 2017-07-21 16:07:16 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:07:16 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:07:16 --> Utf8 Class Initialized
INFO - 2017-07-21 16:07:16 --> URI Class Initialized
INFO - 2017-07-21 16:07:16 --> Router Class Initialized
INFO - 2017-07-21 16:07:16 --> Output Class Initialized
INFO - 2017-07-21 16:07:16 --> Security Class Initialized
DEBUG - 2017-07-21 16:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:07:16 --> Input Class Initialized
INFO - 2017-07-21 16:07:16 --> Language Class Initialized
INFO - 2017-07-21 16:07:16 --> Loader Class Initialized
INFO - 2017-07-21 16:07:16 --> Helper loaded: common_helper
INFO - 2017-07-21 16:07:16 --> Database Driver Class Initialized
INFO - 2017-07-21 16:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:07:16 --> Email Class Initialized
INFO - 2017-07-21 16:07:16 --> Controller Class Initialized
INFO - 2017-07-21 16:07:16 --> Helper loaded: form_helper
INFO - 2017-07-21 16:07:16 --> Form Validation Class Initialized
INFO - 2017-07-21 16:07:16 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:07:16 --> Helper loaded: url_helper
INFO - 2017-07-21 16:07:16 --> Model Class Initialized
INFO - 2017-07-21 16:07:16 --> Model Class Initialized
INFO - 2017-07-21 19:37:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-07-21 19:37:16 --> Use of undefined constant ARTICLES_URL - assumed 'ARTICLES_URL'
ERROR - 2017-07-21 19:37:16 --> Severity: Notice --> Use of undefined constant ARTICLES_URL - assumed 'ARTICLES_URL' C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php 17
INFO - 2017-07-21 19:37:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:37:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:37:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:37:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:37:16 --> Final output sent to browser
DEBUG - 2017-07-21 19:37:16 --> Total execution time: 0.0497
INFO - 2017-07-21 16:07:24 --> Config Class Initialized
INFO - 2017-07-21 16:07:24 --> Hooks Class Initialized
DEBUG - 2017-07-21 16:07:24 --> UTF-8 Support Enabled
INFO - 2017-07-21 16:07:24 --> Utf8 Class Initialized
INFO - 2017-07-21 16:07:24 --> URI Class Initialized
INFO - 2017-07-21 16:07:24 --> Router Class Initialized
INFO - 2017-07-21 16:07:24 --> Output Class Initialized
INFO - 2017-07-21 16:07:24 --> Security Class Initialized
DEBUG - 2017-07-21 16:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-21 16:07:24 --> Input Class Initialized
INFO - 2017-07-21 16:07:24 --> Language Class Initialized
INFO - 2017-07-21 16:07:24 --> Loader Class Initialized
INFO - 2017-07-21 16:07:24 --> Helper loaded: common_helper
INFO - 2017-07-21 16:07:24 --> Database Driver Class Initialized
INFO - 2017-07-21 16:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-21 16:07:24 --> Email Class Initialized
INFO - 2017-07-21 16:07:24 --> Controller Class Initialized
INFO - 2017-07-21 16:07:24 --> Helper loaded: form_helper
INFO - 2017-07-21 16:07:24 --> Form Validation Class Initialized
INFO - 2017-07-21 16:07:24 --> Helper loaded: email_helper
DEBUG - 2017-07-21 16:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-21 16:07:24 --> Helper loaded: url_helper
INFO - 2017-07-21 16:07:24 --> Model Class Initialized
INFO - 2017-07-21 16:07:24 --> Model Class Initialized
INFO - 2017-07-21 19:37:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-21 19:37:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-21 19:37:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-21 19:37:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-21 19:37:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-21 19:37:24 --> Final output sent to browser
DEBUG - 2017-07-21 19:37:24 --> Total execution time: 0.0494
