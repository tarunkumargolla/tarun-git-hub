<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-07-22 07:26:02 --> Config Class Initialized
INFO - 2017-07-22 07:26:02 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:26:02 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:26:02 --> Utf8 Class Initialized
INFO - 2017-07-22 07:26:02 --> URI Class Initialized
DEBUG - 2017-07-22 07:26:02 --> No URI present. Default controller set.
INFO - 2017-07-22 07:26:02 --> Router Class Initialized
INFO - 2017-07-22 07:26:02 --> Output Class Initialized
INFO - 2017-07-22 07:26:02 --> Security Class Initialized
DEBUG - 2017-07-22 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:26:02 --> Input Class Initialized
INFO - 2017-07-22 07:26:02 --> Language Class Initialized
INFO - 2017-07-22 07:26:02 --> Loader Class Initialized
INFO - 2017-07-22 07:26:02 --> Helper loaded: common_helper
INFO - 2017-07-22 07:26:02 --> Database Driver Class Initialized
INFO - 2017-07-22 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:26:02 --> Email Class Initialized
INFO - 2017-07-22 07:26:02 --> Controller Class Initialized
INFO - 2017-07-22 07:26:02 --> Helper loaded: form_helper
INFO - 2017-07-22 07:26:02 --> Form Validation Class Initialized
INFO - 2017-07-22 07:26:02 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:26:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:26:02 --> Helper loaded: url_helper
INFO - 2017-07-22 07:26:02 --> Model Class Initialized
INFO - 2017-07-22 07:26:02 --> Model Class Initialized
INFO - 2017-07-22 07:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-22 07:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:26:02 --> Final output sent to browser
DEBUG - 2017-07-22 07:26:02 --> Total execution time: 0.5841
INFO - 2017-07-22 07:26:03 --> Config Class Initialized
INFO - 2017-07-22 07:26:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:26:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:26:03 --> Utf8 Class Initialized
INFO - 2017-07-22 07:26:03 --> URI Class Initialized
DEBUG - 2017-07-22 07:26:03 --> No URI present. Default controller set.
INFO - 2017-07-22 07:26:03 --> Router Class Initialized
INFO - 2017-07-22 07:26:03 --> Output Class Initialized
INFO - 2017-07-22 07:26:03 --> Security Class Initialized
DEBUG - 2017-07-22 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:26:03 --> Input Class Initialized
INFO - 2017-07-22 07:26:03 --> Language Class Initialized
INFO - 2017-07-22 07:26:03 --> Loader Class Initialized
INFO - 2017-07-22 07:26:03 --> Helper loaded: common_helper
INFO - 2017-07-22 07:26:03 --> Database Driver Class Initialized
INFO - 2017-07-22 07:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:26:03 --> Email Class Initialized
INFO - 2017-07-22 07:26:03 --> Controller Class Initialized
INFO - 2017-07-22 07:26:03 --> Helper loaded: form_helper
INFO - 2017-07-22 07:26:03 --> Form Validation Class Initialized
INFO - 2017-07-22 07:26:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:26:03 --> Helper loaded: url_helper
INFO - 2017-07-22 07:26:03 --> Model Class Initialized
INFO - 2017-07-22 07:26:03 --> Model Class Initialized
INFO - 2017-07-22 07:26:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-22 07:26:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:26:03 --> Final output sent to browser
DEBUG - 2017-07-22 07:26:03 --> Total execution time: 0.0621
INFO - 2017-07-22 07:26:08 --> Config Class Initialized
INFO - 2017-07-22 07:26:08 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:26:08 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:26:08 --> Utf8 Class Initialized
INFO - 2017-07-22 07:26:08 --> URI Class Initialized
DEBUG - 2017-07-22 07:26:08 --> No URI present. Default controller set.
INFO - 2017-07-22 07:26:08 --> Router Class Initialized
INFO - 2017-07-22 07:26:08 --> Output Class Initialized
INFO - 2017-07-22 07:26:08 --> Security Class Initialized
DEBUG - 2017-07-22 07:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:26:08 --> Input Class Initialized
INFO - 2017-07-22 07:26:08 --> Language Class Initialized
INFO - 2017-07-22 07:26:08 --> Loader Class Initialized
INFO - 2017-07-22 07:26:08 --> Helper loaded: common_helper
INFO - 2017-07-22 07:26:08 --> Database Driver Class Initialized
INFO - 2017-07-22 07:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:26:08 --> Email Class Initialized
INFO - 2017-07-22 07:26:08 --> Controller Class Initialized
INFO - 2017-07-22 07:26:08 --> Helper loaded: form_helper
INFO - 2017-07-22 07:26:08 --> Form Validation Class Initialized
INFO - 2017-07-22 07:26:08 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:26:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:26:08 --> Helper loaded: url_helper
INFO - 2017-07-22 07:26:08 --> Model Class Initialized
INFO - 2017-07-22 07:26:08 --> Model Class Initialized
INFO - 2017-07-22 07:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-22 07:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:26:08 --> Final output sent to browser
DEBUG - 2017-07-22 07:26:08 --> Total execution time: 0.0696
INFO - 2017-07-22 07:26:11 --> Config Class Initialized
INFO - 2017-07-22 07:26:11 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:26:11 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:26:11 --> Utf8 Class Initialized
INFO - 2017-07-22 07:26:11 --> URI Class Initialized
DEBUG - 2017-07-22 07:26:11 --> No URI present. Default controller set.
INFO - 2017-07-22 07:26:11 --> Router Class Initialized
INFO - 2017-07-22 07:26:11 --> Output Class Initialized
INFO - 2017-07-22 07:26:11 --> Security Class Initialized
DEBUG - 2017-07-22 07:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:26:11 --> Input Class Initialized
INFO - 2017-07-22 07:26:11 --> Language Class Initialized
INFO - 2017-07-22 07:26:11 --> Loader Class Initialized
INFO - 2017-07-22 07:26:11 --> Helper loaded: common_helper
INFO - 2017-07-22 07:26:11 --> Database Driver Class Initialized
INFO - 2017-07-22 07:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:26:11 --> Email Class Initialized
INFO - 2017-07-22 07:26:11 --> Controller Class Initialized
INFO - 2017-07-22 07:26:11 --> Helper loaded: form_helper
INFO - 2017-07-22 07:26:11 --> Form Validation Class Initialized
INFO - 2017-07-22 07:26:11 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:26:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:26:11 --> Helper loaded: url_helper
INFO - 2017-07-22 07:26:11 --> Model Class Initialized
INFO - 2017-07-22 07:26:11 --> Model Class Initialized
INFO - 2017-07-22 07:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-22 07:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:26:11 --> Final output sent to browser
DEBUG - 2017-07-22 07:26:11 --> Total execution time: 0.0433
INFO - 2017-07-22 07:26:46 --> Config Class Initialized
INFO - 2017-07-22 07:26:46 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:26:46 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:26:46 --> Utf8 Class Initialized
INFO - 2017-07-22 07:26:46 --> URI Class Initialized
DEBUG - 2017-07-22 07:26:46 --> No URI present. Default controller set.
INFO - 2017-07-22 07:26:46 --> Router Class Initialized
INFO - 2017-07-22 07:26:46 --> Output Class Initialized
INFO - 2017-07-22 07:26:46 --> Security Class Initialized
DEBUG - 2017-07-22 07:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:26:46 --> Input Class Initialized
INFO - 2017-07-22 07:26:46 --> Language Class Initialized
INFO - 2017-07-22 07:26:46 --> Loader Class Initialized
INFO - 2017-07-22 07:26:46 --> Helper loaded: common_helper
INFO - 2017-07-22 07:26:46 --> Database Driver Class Initialized
INFO - 2017-07-22 07:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:26:46 --> Email Class Initialized
INFO - 2017-07-22 07:26:46 --> Controller Class Initialized
INFO - 2017-07-22 07:26:46 --> Helper loaded: form_helper
INFO - 2017-07-22 07:26:46 --> Form Validation Class Initialized
INFO - 2017-07-22 07:26:46 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:26:46 --> Helper loaded: url_helper
INFO - 2017-07-22 07:26:46 --> Model Class Initialized
INFO - 2017-07-22 07:26:46 --> Model Class Initialized
INFO - 2017-07-22 07:27:03 --> Config Class Initialized
INFO - 2017-07-22 07:27:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:27:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:27:03 --> Utf8 Class Initialized
INFO - 2017-07-22 07:27:03 --> URI Class Initialized
DEBUG - 2017-07-22 07:27:03 --> No URI present. Default controller set.
INFO - 2017-07-22 07:27:03 --> Router Class Initialized
INFO - 2017-07-22 07:27:03 --> Output Class Initialized
INFO - 2017-07-22 07:27:03 --> Security Class Initialized
DEBUG - 2017-07-22 07:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:27:03 --> Input Class Initialized
INFO - 2017-07-22 07:27:03 --> Language Class Initialized
INFO - 2017-07-22 07:27:03 --> Loader Class Initialized
INFO - 2017-07-22 07:27:03 --> Helper loaded: common_helper
INFO - 2017-07-22 07:27:03 --> Database Driver Class Initialized
INFO - 2017-07-22 07:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:27:03 --> Email Class Initialized
INFO - 2017-07-22 07:27:03 --> Controller Class Initialized
INFO - 2017-07-22 07:27:03 --> Helper loaded: form_helper
INFO - 2017-07-22 07:27:03 --> Form Validation Class Initialized
INFO - 2017-07-22 07:27:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:27:03 --> Helper loaded: url_helper
INFO - 2017-07-22 07:27:03 --> Model Class Initialized
INFO - 2017-07-22 07:27:03 --> Model Class Initialized
INFO - 2017-07-22 07:27:12 --> Config Class Initialized
INFO - 2017-07-22 07:27:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:27:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:27:12 --> Utf8 Class Initialized
INFO - 2017-07-22 07:27:12 --> URI Class Initialized
DEBUG - 2017-07-22 07:27:12 --> No URI present. Default controller set.
INFO - 2017-07-22 07:27:12 --> Router Class Initialized
INFO - 2017-07-22 07:27:12 --> Output Class Initialized
INFO - 2017-07-22 07:27:12 --> Security Class Initialized
DEBUG - 2017-07-22 07:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:27:12 --> Input Class Initialized
INFO - 2017-07-22 07:27:12 --> Language Class Initialized
INFO - 2017-07-22 07:27:12 --> Loader Class Initialized
INFO - 2017-07-22 07:27:12 --> Helper loaded: common_helper
INFO - 2017-07-22 07:27:12 --> Database Driver Class Initialized
INFO - 2017-07-22 07:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:27:12 --> Email Class Initialized
INFO - 2017-07-22 07:27:12 --> Controller Class Initialized
INFO - 2017-07-22 07:27:12 --> Helper loaded: form_helper
INFO - 2017-07-22 07:27:12 --> Form Validation Class Initialized
INFO - 2017-07-22 07:27:12 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:27:12 --> Helper loaded: url_helper
INFO - 2017-07-22 07:27:12 --> Model Class Initialized
INFO - 2017-07-22 07:27:12 --> Model Class Initialized
INFO - 2017-07-22 07:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-07-22 07:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:27:12 --> Final output sent to browser
DEBUG - 2017-07-22 07:27:12 --> Total execution time: 0.0513
INFO - 2017-07-22 07:27:15 --> Config Class Initialized
INFO - 2017-07-22 07:27:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:27:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:27:15 --> Utf8 Class Initialized
INFO - 2017-07-22 07:27:15 --> URI Class Initialized
DEBUG - 2017-07-22 07:27:15 --> No URI present. Default controller set.
INFO - 2017-07-22 07:27:15 --> Router Class Initialized
INFO - 2017-07-22 07:27:15 --> Output Class Initialized
INFO - 2017-07-22 07:27:15 --> Security Class Initialized
DEBUG - 2017-07-22 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:27:15 --> Input Class Initialized
INFO - 2017-07-22 07:27:15 --> Language Class Initialized
INFO - 2017-07-22 07:27:15 --> Loader Class Initialized
INFO - 2017-07-22 07:27:15 --> Helper loaded: common_helper
INFO - 2017-07-22 07:27:15 --> Database Driver Class Initialized
INFO - 2017-07-22 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:27:15 --> Email Class Initialized
INFO - 2017-07-22 07:27:15 --> Controller Class Initialized
INFO - 2017-07-22 07:27:15 --> Helper loaded: form_helper
INFO - 2017-07-22 07:27:15 --> Form Validation Class Initialized
INFO - 2017-07-22 07:27:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:27:15 --> Helper loaded: url_helper
INFO - 2017-07-22 07:27:15 --> Model Class Initialized
INFO - 2017-07-22 07:27:15 --> Model Class Initialized
DEBUG - 2017-07-22 07:27:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:27:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 07:27:15 --> Config Class Initialized
INFO - 2017-07-22 07:27:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:27:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:27:15 --> Utf8 Class Initialized
INFO - 2017-07-22 07:27:15 --> URI Class Initialized
INFO - 2017-07-22 07:27:15 --> Router Class Initialized
INFO - 2017-07-22 07:27:15 --> Output Class Initialized
INFO - 2017-07-22 07:27:15 --> Security Class Initialized
DEBUG - 2017-07-22 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:27:15 --> Input Class Initialized
INFO - 2017-07-22 07:27:15 --> Language Class Initialized
INFO - 2017-07-22 07:27:15 --> Loader Class Initialized
INFO - 2017-07-22 07:27:15 --> Helper loaded: common_helper
INFO - 2017-07-22 07:27:15 --> Database Driver Class Initialized
INFO - 2017-07-22 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:27:15 --> Email Class Initialized
INFO - 2017-07-22 07:27:15 --> Controller Class Initialized
INFO - 2017-07-22 07:27:15 --> Helper loaded: form_helper
INFO - 2017-07-22 07:27:15 --> Form Validation Class Initialized
INFO - 2017-07-22 07:27:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:27:15 --> Helper loaded: url_helper
INFO - 2017-07-22 07:27:15 --> Model Class Initialized
INFO - 2017-07-22 07:27:15 --> Model Class Initialized
INFO - 2017-07-22 07:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-07-22 07:27:15 --> Use of undefined constant ARTICLES_URL - assumed 'ARTICLES_URL'
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Use of undefined constant ARTICLES_URL - assumed 'ARTICLES_URL' C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php 17
INFO - 2017-07-22 07:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 07:27:15 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 07:27:15 --> Trying to get property of non-object
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 07:27:15 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 07:27:15 --> Trying to get property of non-object
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 07:27:15 --> Undefined variable: Evenets
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 07:27:15 --> Trying to get property of non-object
ERROR - 2017-07-22 07:27:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 07:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 07:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:27:15 --> Final output sent to browser
DEBUG - 2017-07-22 07:27:15 --> Total execution time: 0.0634
INFO - 2017-07-22 07:27:50 --> Config Class Initialized
INFO - 2017-07-22 07:27:50 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:27:50 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:27:50 --> Utf8 Class Initialized
INFO - 2017-07-22 07:27:50 --> URI Class Initialized
INFO - 2017-07-22 07:27:50 --> Router Class Initialized
INFO - 2017-07-22 07:27:50 --> Output Class Initialized
INFO - 2017-07-22 07:27:50 --> Security Class Initialized
DEBUG - 2017-07-22 07:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:27:50 --> Input Class Initialized
INFO - 2017-07-22 07:27:50 --> Language Class Initialized
INFO - 2017-07-22 07:27:50 --> Loader Class Initialized
INFO - 2017-07-22 07:27:50 --> Helper loaded: common_helper
INFO - 2017-07-22 07:27:50 --> Database Driver Class Initialized
INFO - 2017-07-22 07:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:27:50 --> Email Class Initialized
INFO - 2017-07-22 07:27:50 --> Controller Class Initialized
INFO - 2017-07-22 07:27:50 --> Helper loaded: form_helper
INFO - 2017-07-22 07:27:50 --> Form Validation Class Initialized
INFO - 2017-07-22 07:27:50 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:27:50 --> Helper loaded: url_helper
INFO - 2017-07-22 07:27:50 --> Model Class Initialized
INFO - 2017-07-22 07:27:50 --> Model Class Initialized
INFO - 2017-07-22 07:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 07:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 07:27:50 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 07:27:50 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 07:27:50 --> Trying to get property of non-object
ERROR - 2017-07-22 07:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 07:27:50 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 07:27:50 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 07:27:50 --> Trying to get property of non-object
ERROR - 2017-07-22 07:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 07:27:50 --> Undefined variable: Evenets
ERROR - 2017-07-22 07:27:50 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 07:27:50 --> Trying to get property of non-object
ERROR - 2017-07-22 07:27:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 07:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 07:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:27:50 --> Final output sent to browser
DEBUG - 2017-07-22 07:27:50 --> Total execution time: 0.0536
INFO - 2017-07-22 07:29:32 --> Config Class Initialized
INFO - 2017-07-22 07:29:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:32 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:32 --> URI Class Initialized
INFO - 2017-07-22 07:29:32 --> Router Class Initialized
INFO - 2017-07-22 07:29:32 --> Output Class Initialized
INFO - 2017-07-22 07:29:32 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:32 --> Input Class Initialized
INFO - 2017-07-22 07:29:32 --> Language Class Initialized
INFO - 2017-07-22 07:29:32 --> Loader Class Initialized
INFO - 2017-07-22 07:29:32 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:32 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:32 --> Email Class Initialized
INFO - 2017-07-22 07:29:32 --> Controller Class Initialized
INFO - 2017-07-22 07:29:32 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:32 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:32 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:32 --> Model Class Initialized
INFO - 2017-07-22 07:29:32 --> Model Class Initialized
INFO - 2017-07-22 07:29:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 07:29:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 07:29:32 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 07:29:32 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 07:29:32 --> Trying to get property of non-object
ERROR - 2017-07-22 07:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 07:29:32 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 07:29:32 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 07:29:32 --> Trying to get property of non-object
ERROR - 2017-07-22 07:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 07:29:32 --> Undefined variable: Evenets
ERROR - 2017-07-22 07:29:32 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 07:29:32 --> Trying to get property of non-object
ERROR - 2017-07-22 07:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 07:29:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 07:29:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 07:29:32 --> Final output sent to browser
DEBUG - 2017-07-22 07:29:32 --> Total execution time: 0.0556
INFO - 2017-07-22 07:29:33 --> Config Class Initialized
INFO - 2017-07-22 07:29:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:33 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:33 --> URI Class Initialized
INFO - 2017-07-22 07:29:33 --> Router Class Initialized
INFO - 2017-07-22 07:29:33 --> Output Class Initialized
INFO - 2017-07-22 07:29:33 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:33 --> Input Class Initialized
INFO - 2017-07-22 07:29:33 --> Language Class Initialized
INFO - 2017-07-22 07:29:33 --> Loader Class Initialized
INFO - 2017-07-22 07:29:33 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:33 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:33 --> Email Class Initialized
INFO - 2017-07-22 07:29:33 --> Controller Class Initialized
INFO - 2017-07-22 07:29:33 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:33 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:33 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:33 --> Model Class Initialized
INFO - 2017-07-22 07:29:33 --> Model Class Initialized
INFO - 2017-07-22 10:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 10:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 10:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 10:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 10:59:33 --> Final output sent to browser
DEBUG - 2017-07-22 10:59:33 --> Total execution time: 0.0452
INFO - 2017-07-22 07:29:35 --> Config Class Initialized
INFO - 2017-07-22 07:29:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:35 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:35 --> URI Class Initialized
INFO - 2017-07-22 07:29:35 --> Router Class Initialized
INFO - 2017-07-22 07:29:35 --> Output Class Initialized
INFO - 2017-07-22 07:29:35 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:35 --> Input Class Initialized
INFO - 2017-07-22 07:29:35 --> Language Class Initialized
INFO - 2017-07-22 07:29:35 --> Loader Class Initialized
INFO - 2017-07-22 07:29:35 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:35 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:35 --> Email Class Initialized
INFO - 2017-07-22 07:29:35 --> Controller Class Initialized
INFO - 2017-07-22 07:29:35 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:35 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:35 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:35 --> Model Class Initialized
INFO - 2017-07-22 07:29:35 --> Model Class Initialized
INFO - 2017-07-22 10:59:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:59:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 10:59:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 10:59:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 10:59:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 10:59:35 --> Final output sent to browser
DEBUG - 2017-07-22 10:59:35 --> Total execution time: 0.0489
INFO - 2017-07-22 07:29:38 --> Config Class Initialized
INFO - 2017-07-22 07:29:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:38 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:38 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:38 --> URI Class Initialized
INFO - 2017-07-22 07:29:38 --> Router Class Initialized
INFO - 2017-07-22 07:29:38 --> Output Class Initialized
INFO - 2017-07-22 07:29:38 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:38 --> Input Class Initialized
INFO - 2017-07-22 07:29:38 --> Language Class Initialized
INFO - 2017-07-22 07:29:38 --> Loader Class Initialized
INFO - 2017-07-22 07:29:38 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:38 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:38 --> Email Class Initialized
INFO - 2017-07-22 07:29:38 --> Controller Class Initialized
INFO - 2017-07-22 07:29:38 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:38 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:38 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:38 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:38 --> Model Class Initialized
INFO - 2017-07-22 07:29:38 --> Model Class Initialized
INFO - 2017-07-22 10:59:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:59:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 10:59:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 10:59:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 10:59:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 10:59:38 --> Final output sent to browser
DEBUG - 2017-07-22 10:59:38 --> Total execution time: 0.0496
INFO - 2017-07-22 07:29:47 --> Config Class Initialized
INFO - 2017-07-22 07:29:47 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:47 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:47 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:47 --> URI Class Initialized
INFO - 2017-07-22 07:29:47 --> Router Class Initialized
INFO - 2017-07-22 07:29:47 --> Output Class Initialized
INFO - 2017-07-22 07:29:47 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:47 --> Input Class Initialized
INFO - 2017-07-22 07:29:47 --> Language Class Initialized
INFO - 2017-07-22 07:29:47 --> Loader Class Initialized
INFO - 2017-07-22 07:29:47 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:47 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:47 --> Email Class Initialized
INFO - 2017-07-22 07:29:47 --> Controller Class Initialized
INFO - 2017-07-22 07:29:47 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:47 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:47 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:47 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:47 --> Model Class Initialized
INFO - 2017-07-22 07:29:47 --> Model Class Initialized
INFO - 2017-07-22 10:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 10:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 10:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 10:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 10:59:47 --> Final output sent to browser
DEBUG - 2017-07-22 10:59:47 --> Total execution time: 0.0466
INFO - 2017-07-22 07:29:49 --> Config Class Initialized
INFO - 2017-07-22 07:29:49 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:49 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:49 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:49 --> URI Class Initialized
INFO - 2017-07-22 07:29:49 --> Router Class Initialized
INFO - 2017-07-22 07:29:49 --> Output Class Initialized
INFO - 2017-07-22 07:29:49 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:49 --> Input Class Initialized
INFO - 2017-07-22 07:29:49 --> Language Class Initialized
INFO - 2017-07-22 07:29:49 --> Loader Class Initialized
INFO - 2017-07-22 07:29:49 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:49 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:49 --> Email Class Initialized
INFO - 2017-07-22 07:29:49 --> Controller Class Initialized
INFO - 2017-07-22 07:29:49 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:49 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:49 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:49 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:49 --> Model Class Initialized
INFO - 2017-07-22 07:29:49 --> Model Class Initialized
INFO - 2017-07-22 10:59:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:59:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 10:59:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 10:59:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 10:59:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 10:59:49 --> Final output sent to browser
DEBUG - 2017-07-22 10:59:49 --> Total execution time: 0.0504
INFO - 2017-07-22 07:29:51 --> Config Class Initialized
INFO - 2017-07-22 07:29:51 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:29:51 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:29:51 --> Utf8 Class Initialized
INFO - 2017-07-22 07:29:51 --> URI Class Initialized
INFO - 2017-07-22 07:29:51 --> Router Class Initialized
INFO - 2017-07-22 07:29:51 --> Output Class Initialized
INFO - 2017-07-22 07:29:51 --> Security Class Initialized
DEBUG - 2017-07-22 07:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:29:51 --> Input Class Initialized
INFO - 2017-07-22 07:29:51 --> Language Class Initialized
INFO - 2017-07-22 07:29:51 --> Loader Class Initialized
INFO - 2017-07-22 07:29:51 --> Helper loaded: common_helper
INFO - 2017-07-22 07:29:51 --> Database Driver Class Initialized
INFO - 2017-07-22 07:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:29:51 --> Email Class Initialized
INFO - 2017-07-22 07:29:51 --> Controller Class Initialized
INFO - 2017-07-22 07:29:51 --> Helper loaded: form_helper
INFO - 2017-07-22 07:29:51 --> Form Validation Class Initialized
INFO - 2017-07-22 07:29:51 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:29:51 --> Helper loaded: url_helper
INFO - 2017-07-22 07:29:51 --> Model Class Initialized
INFO - 2017-07-22 07:29:51 --> Model Class Initialized
INFO - 2017-07-22 10:59:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:59:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 10:59:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 10:59:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 10:59:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 10:59:51 --> Final output sent to browser
DEBUG - 2017-07-22 10:59:51 --> Total execution time: 0.0446
INFO - 2017-07-22 07:30:06 --> Config Class Initialized
INFO - 2017-07-22 07:30:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:30:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:30:06 --> Utf8 Class Initialized
INFO - 2017-07-22 07:30:06 --> URI Class Initialized
INFO - 2017-07-22 07:30:06 --> Router Class Initialized
INFO - 2017-07-22 07:30:06 --> Output Class Initialized
INFO - 2017-07-22 07:30:06 --> Security Class Initialized
DEBUG - 2017-07-22 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:30:06 --> Input Class Initialized
INFO - 2017-07-22 07:30:06 --> Language Class Initialized
INFO - 2017-07-22 07:30:06 --> Loader Class Initialized
INFO - 2017-07-22 07:30:06 --> Helper loaded: common_helper
INFO - 2017-07-22 07:30:06 --> Database Driver Class Initialized
INFO - 2017-07-22 07:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:30:06 --> Email Class Initialized
INFO - 2017-07-22 07:30:06 --> Controller Class Initialized
INFO - 2017-07-22 07:30:06 --> Helper loaded: form_helper
INFO - 2017-07-22 07:30:06 --> Form Validation Class Initialized
INFO - 2017-07-22 07:30:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:30:06 --> Helper loaded: url_helper
INFO - 2017-07-22 07:30:06 --> Model Class Initialized
INFO - 2017-07-22 07:30:06 --> Model Class Initialized
INFO - 2017-07-22 11:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 11:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:00:06 --> Final output sent to browser
DEBUG - 2017-07-22 11:00:06 --> Total execution time: 0.0497
INFO - 2017-07-22 07:30:16 --> Config Class Initialized
INFO - 2017-07-22 07:30:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:30:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:30:16 --> Utf8 Class Initialized
INFO - 2017-07-22 07:30:16 --> URI Class Initialized
INFO - 2017-07-22 07:30:16 --> Router Class Initialized
INFO - 2017-07-22 07:30:16 --> Output Class Initialized
INFO - 2017-07-22 07:30:16 --> Security Class Initialized
DEBUG - 2017-07-22 07:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:30:16 --> Input Class Initialized
INFO - 2017-07-22 07:30:16 --> Language Class Initialized
INFO - 2017-07-22 07:30:16 --> Loader Class Initialized
INFO - 2017-07-22 07:30:16 --> Helper loaded: common_helper
INFO - 2017-07-22 07:30:16 --> Database Driver Class Initialized
INFO - 2017-07-22 07:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:30:17 --> Email Class Initialized
INFO - 2017-07-22 07:30:17 --> Controller Class Initialized
INFO - 2017-07-22 07:30:17 --> Helper loaded: form_helper
INFO - 2017-07-22 07:30:17 --> Form Validation Class Initialized
INFO - 2017-07-22 07:30:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:30:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:30:17 --> Helper loaded: url_helper
INFO - 2017-07-22 07:30:17 --> Model Class Initialized
INFO - 2017-07-22 07:30:17 --> Model Class Initialized
INFO - 2017-07-22 11:00:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:00:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:00:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:00:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 11:00:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:00:17 --> Final output sent to browser
DEBUG - 2017-07-22 11:00:17 --> Total execution time: 0.0488
INFO - 2017-07-22 07:30:18 --> Config Class Initialized
INFO - 2017-07-22 07:30:18 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:30:18 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:30:18 --> Utf8 Class Initialized
INFO - 2017-07-22 07:30:18 --> URI Class Initialized
INFO - 2017-07-22 07:30:18 --> Router Class Initialized
INFO - 2017-07-22 07:30:18 --> Output Class Initialized
INFO - 2017-07-22 07:30:18 --> Security Class Initialized
DEBUG - 2017-07-22 07:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:30:18 --> Input Class Initialized
INFO - 2017-07-22 07:30:18 --> Language Class Initialized
ERROR - 2017-07-22 07:30:18 --> 404 Page Not Found: Articles/index
INFO - 2017-07-22 07:30:19 --> Config Class Initialized
INFO - 2017-07-22 07:30:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:30:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:30:19 --> Utf8 Class Initialized
INFO - 2017-07-22 07:30:19 --> URI Class Initialized
INFO - 2017-07-22 07:30:19 --> Router Class Initialized
INFO - 2017-07-22 07:30:19 --> Output Class Initialized
INFO - 2017-07-22 07:30:19 --> Security Class Initialized
DEBUG - 2017-07-22 07:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:30:19 --> Input Class Initialized
INFO - 2017-07-22 07:30:19 --> Language Class Initialized
INFO - 2017-07-22 07:30:19 --> Loader Class Initialized
INFO - 2017-07-22 07:30:19 --> Helper loaded: common_helper
INFO - 2017-07-22 07:30:19 --> Database Driver Class Initialized
INFO - 2017-07-22 07:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:30:19 --> Email Class Initialized
INFO - 2017-07-22 07:30:19 --> Controller Class Initialized
INFO - 2017-07-22 07:30:19 --> Helper loaded: form_helper
INFO - 2017-07-22 07:30:19 --> Form Validation Class Initialized
INFO - 2017-07-22 07:30:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:30:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:30:19 --> Helper loaded: url_helper
INFO - 2017-07-22 07:30:19 --> Model Class Initialized
INFO - 2017-07-22 07:30:19 --> Model Class Initialized
INFO - 2017-07-22 11:00:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:00:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:00:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:00:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 11:00:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:00:19 --> Final output sent to browser
DEBUG - 2017-07-22 11:00:19 --> Total execution time: 0.0473
INFO - 2017-07-22 07:47:24 --> Config Class Initialized
INFO - 2017-07-22 07:47:24 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:24 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:24 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:24 --> URI Class Initialized
INFO - 2017-07-22 07:47:24 --> Router Class Initialized
INFO - 2017-07-22 07:47:24 --> Output Class Initialized
INFO - 2017-07-22 07:47:24 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:24 --> Input Class Initialized
INFO - 2017-07-22 07:47:24 --> Language Class Initialized
INFO - 2017-07-22 07:47:24 --> Loader Class Initialized
INFO - 2017-07-22 07:47:24 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:24 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:24 --> Email Class Initialized
INFO - 2017-07-22 07:47:24 --> Controller Class Initialized
INFO - 2017-07-22 07:47:24 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:24 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:24 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:24 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:17:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:24 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:24 --> Total execution time: 0.0549
INFO - 2017-07-22 07:47:27 --> Config Class Initialized
INFO - 2017-07-22 07:47:27 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:27 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:27 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:27 --> URI Class Initialized
INFO - 2017-07-22 07:47:27 --> Router Class Initialized
INFO - 2017-07-22 07:47:27 --> Output Class Initialized
INFO - 2017-07-22 07:47:27 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:27 --> Input Class Initialized
INFO - 2017-07-22 07:47:27 --> Language Class Initialized
INFO - 2017-07-22 07:47:27 --> Loader Class Initialized
INFO - 2017-07-22 07:47:27 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:27 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:27 --> Email Class Initialized
INFO - 2017-07-22 07:47:27 --> Controller Class Initialized
INFO - 2017-07-22 07:47:27 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:27 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:27 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:27 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/addArticle.php
INFO - 2017-07-22 11:17:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:27 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:27 --> Total execution time: 0.0434
INFO - 2017-07-22 07:47:30 --> Config Class Initialized
INFO - 2017-07-22 07:47:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:30 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:30 --> URI Class Initialized
INFO - 2017-07-22 07:47:30 --> Router Class Initialized
INFO - 2017-07-22 07:47:30 --> Output Class Initialized
INFO - 2017-07-22 07:47:30 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:30 --> Input Class Initialized
INFO - 2017-07-22 07:47:30 --> Language Class Initialized
INFO - 2017-07-22 07:47:30 --> Loader Class Initialized
INFO - 2017-07-22 07:47:30 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:30 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:30 --> Email Class Initialized
INFO - 2017-07-22 07:47:30 --> Controller Class Initialized
INFO - 2017-07-22 07:47:30 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:30 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:30 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:30 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:30 --> Total execution time: 0.0440
INFO - 2017-07-22 07:47:32 --> Config Class Initialized
INFO - 2017-07-22 07:47:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:32 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:32 --> URI Class Initialized
INFO - 2017-07-22 07:47:32 --> Router Class Initialized
INFO - 2017-07-22 07:47:32 --> Output Class Initialized
INFO - 2017-07-22 07:47:32 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:32 --> Input Class Initialized
INFO - 2017-07-22 07:47:32 --> Language Class Initialized
INFO - 2017-07-22 07:47:32 --> Loader Class Initialized
INFO - 2017-07-22 07:47:32 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:32 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:32 --> Email Class Initialized
INFO - 2017-07-22 07:47:32 --> Controller Class Initialized
INFO - 2017-07-22 07:47:32 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:32 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:32 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/addArticle.php
INFO - 2017-07-22 11:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:32 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:32 --> Total execution time: 0.0430
INFO - 2017-07-22 07:47:35 --> Config Class Initialized
INFO - 2017-07-22 07:47:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:35 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:35 --> URI Class Initialized
INFO - 2017-07-22 07:47:35 --> Router Class Initialized
INFO - 2017-07-22 07:47:35 --> Output Class Initialized
INFO - 2017-07-22 07:47:35 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:35 --> Input Class Initialized
INFO - 2017-07-22 07:47:35 --> Language Class Initialized
INFO - 2017-07-22 07:47:35 --> Loader Class Initialized
INFO - 2017-07-22 07:47:35 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:35 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:35 --> Email Class Initialized
INFO - 2017-07-22 07:47:35 --> Controller Class Initialized
INFO - 2017-07-22 07:47:35 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:35 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:35 --> Helper loaded: url_helper
DEBUG - 2017-07-22 11:17:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:17:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 07:47:35 --> Config Class Initialized
INFO - 2017-07-22 07:47:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:35 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:35 --> URI Class Initialized
INFO - 2017-07-22 07:47:35 --> Router Class Initialized
INFO - 2017-07-22 07:47:35 --> Output Class Initialized
INFO - 2017-07-22 07:47:35 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:35 --> Input Class Initialized
INFO - 2017-07-22 07:47:35 --> Language Class Initialized
INFO - 2017-07-22 07:47:35 --> Loader Class Initialized
INFO - 2017-07-22 07:47:35 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:35 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:35 --> Email Class Initialized
INFO - 2017-07-22 07:47:35 --> Controller Class Initialized
INFO - 2017-07-22 07:47:35 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:35 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:35 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:17:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:35 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:35 --> Total execution time: 0.0637
INFO - 2017-07-22 07:47:40 --> Config Class Initialized
INFO - 2017-07-22 07:47:40 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:40 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:40 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:40 --> URI Class Initialized
INFO - 2017-07-22 07:47:40 --> Router Class Initialized
INFO - 2017-07-22 07:47:40 --> Output Class Initialized
INFO - 2017-07-22 07:47:40 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:40 --> Input Class Initialized
INFO - 2017-07-22 07:47:40 --> Language Class Initialized
INFO - 2017-07-22 07:47:40 --> Loader Class Initialized
INFO - 2017-07-22 07:47:40 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:40 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:40 --> Email Class Initialized
INFO - 2017-07-22 07:47:40 --> Controller Class Initialized
INFO - 2017-07-22 07:47:40 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:40 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:40 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:40 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/addArticle.php
INFO - 2017-07-22 11:17:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:40 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:40 --> Total execution time: 0.0434
INFO - 2017-07-22 07:47:43 --> Config Class Initialized
INFO - 2017-07-22 07:47:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:43 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:43 --> URI Class Initialized
INFO - 2017-07-22 07:47:43 --> Router Class Initialized
INFO - 2017-07-22 07:47:43 --> Output Class Initialized
INFO - 2017-07-22 07:47:43 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:43 --> Input Class Initialized
INFO - 2017-07-22 07:47:43 --> Language Class Initialized
INFO - 2017-07-22 07:47:43 --> Loader Class Initialized
INFO - 2017-07-22 07:47:43 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:43 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:43 --> Email Class Initialized
INFO - 2017-07-22 07:47:43 --> Controller Class Initialized
INFO - 2017-07-22 07:47:43 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:43 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:43 --> Helper loaded: url_helper
DEBUG - 2017-07-22 11:17:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:17:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 07:47:43 --> Config Class Initialized
INFO - 2017-07-22 07:47:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:43 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:43 --> URI Class Initialized
INFO - 2017-07-22 07:47:43 --> Router Class Initialized
INFO - 2017-07-22 07:47:43 --> Output Class Initialized
INFO - 2017-07-22 07:47:43 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:43 --> Input Class Initialized
INFO - 2017-07-22 07:47:43 --> Language Class Initialized
INFO - 2017-07-22 07:47:43 --> Loader Class Initialized
INFO - 2017-07-22 07:47:43 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:43 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:43 --> Email Class Initialized
INFO - 2017-07-22 07:47:43 --> Controller Class Initialized
INFO - 2017-07-22 07:47:43 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:43 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:43 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:17:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:43 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:43 --> Total execution time: 0.0598
INFO - 2017-07-22 07:47:52 --> Config Class Initialized
INFO - 2017-07-22 07:47:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:52 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:52 --> URI Class Initialized
INFO - 2017-07-22 07:47:52 --> Router Class Initialized
INFO - 2017-07-22 07:47:52 --> Output Class Initialized
INFO - 2017-07-22 07:47:52 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:52 --> Input Class Initialized
INFO - 2017-07-22 07:47:52 --> Language Class Initialized
INFO - 2017-07-22 07:47:52 --> Loader Class Initialized
INFO - 2017-07-22 07:47:52 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:52 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:52 --> Email Class Initialized
INFO - 2017-07-22 07:47:52 --> Controller Class Initialized
INFO - 2017-07-22 07:47:52 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:52 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:52 --> Helper loaded: url_helper
INFO - 2017-07-22 07:47:52 --> Model Class Initialized
INFO - 2017-07-22 07:47:52 --> Model Class Initialized
INFO - 2017-07-22 07:47:52 --> Config Class Initialized
INFO - 2017-07-22 07:47:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:47:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:47:52 --> Utf8 Class Initialized
INFO - 2017-07-22 07:47:52 --> URI Class Initialized
INFO - 2017-07-22 07:47:52 --> Router Class Initialized
INFO - 2017-07-22 07:47:52 --> Output Class Initialized
INFO - 2017-07-22 07:47:52 --> Security Class Initialized
DEBUG - 2017-07-22 07:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:47:52 --> Input Class Initialized
INFO - 2017-07-22 07:47:52 --> Language Class Initialized
INFO - 2017-07-22 07:47:52 --> Loader Class Initialized
INFO - 2017-07-22 07:47:52 --> Helper loaded: common_helper
INFO - 2017-07-22 07:47:52 --> Database Driver Class Initialized
INFO - 2017-07-22 07:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:47:52 --> Email Class Initialized
INFO - 2017-07-22 07:47:52 --> Controller Class Initialized
INFO - 2017-07-22 07:47:52 --> Helper loaded: form_helper
INFO - 2017-07-22 07:47:52 --> Form Validation Class Initialized
INFO - 2017-07-22 07:47:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:47:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:47:52 --> Helper loaded: url_helper
INFO - 2017-07-22 11:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:17:52 --> Final output sent to browser
DEBUG - 2017-07-22 11:17:52 --> Total execution time: 0.0457
INFO - 2017-07-22 07:48:54 --> Config Class Initialized
INFO - 2017-07-22 07:48:54 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:48:54 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:48:54 --> Utf8 Class Initialized
INFO - 2017-07-22 07:48:54 --> URI Class Initialized
INFO - 2017-07-22 07:48:54 --> Router Class Initialized
INFO - 2017-07-22 07:48:54 --> Output Class Initialized
INFO - 2017-07-22 07:48:54 --> Security Class Initialized
DEBUG - 2017-07-22 07:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:48:54 --> Input Class Initialized
INFO - 2017-07-22 07:48:54 --> Language Class Initialized
INFO - 2017-07-22 07:48:54 --> Loader Class Initialized
INFO - 2017-07-22 07:48:54 --> Helper loaded: common_helper
INFO - 2017-07-22 07:48:54 --> Database Driver Class Initialized
INFO - 2017-07-22 07:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:48:54 --> Email Class Initialized
INFO - 2017-07-22 07:48:54 --> Controller Class Initialized
INFO - 2017-07-22 07:48:54 --> Helper loaded: form_helper
INFO - 2017-07-22 07:48:54 --> Form Validation Class Initialized
INFO - 2017-07-22 07:48:54 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:48:54 --> Helper loaded: url_helper
INFO - 2017-07-22 11:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:18:54 --> Final output sent to browser
DEBUG - 2017-07-22 11:18:54 --> Total execution time: 0.0461
INFO - 2017-07-22 07:48:58 --> Config Class Initialized
INFO - 2017-07-22 07:48:58 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:48:58 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:48:58 --> Utf8 Class Initialized
INFO - 2017-07-22 07:48:58 --> URI Class Initialized
INFO - 2017-07-22 07:48:58 --> Router Class Initialized
INFO - 2017-07-22 07:48:58 --> Output Class Initialized
INFO - 2017-07-22 07:48:58 --> Security Class Initialized
DEBUG - 2017-07-22 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:48:58 --> Input Class Initialized
INFO - 2017-07-22 07:48:58 --> Language Class Initialized
INFO - 2017-07-22 07:48:58 --> Loader Class Initialized
INFO - 2017-07-22 07:48:58 --> Helper loaded: common_helper
INFO - 2017-07-22 07:48:58 --> Database Driver Class Initialized
INFO - 2017-07-22 07:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:48:58 --> Email Class Initialized
INFO - 2017-07-22 07:48:58 --> Controller Class Initialized
INFO - 2017-07-22 07:48:58 --> Helper loaded: form_helper
INFO - 2017-07-22 07:48:58 --> Form Validation Class Initialized
INFO - 2017-07-22 07:48:58 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:48:58 --> Helper loaded: url_helper
INFO - 2017-07-22 07:48:59 --> Config Class Initialized
INFO - 2017-07-22 07:48:59 --> Hooks Class Initialized
DEBUG - 2017-07-22 07:48:59 --> UTF-8 Support Enabled
INFO - 2017-07-22 07:48:59 --> Utf8 Class Initialized
INFO - 2017-07-22 07:48:59 --> URI Class Initialized
INFO - 2017-07-22 07:48:59 --> Router Class Initialized
INFO - 2017-07-22 07:48:59 --> Output Class Initialized
INFO - 2017-07-22 07:48:59 --> Security Class Initialized
DEBUG - 2017-07-22 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 07:48:59 --> Input Class Initialized
INFO - 2017-07-22 07:48:59 --> Language Class Initialized
INFO - 2017-07-22 07:48:59 --> Loader Class Initialized
INFO - 2017-07-22 07:48:59 --> Helper loaded: common_helper
INFO - 2017-07-22 07:48:59 --> Database Driver Class Initialized
INFO - 2017-07-22 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 07:48:59 --> Email Class Initialized
INFO - 2017-07-22 07:48:59 --> Controller Class Initialized
INFO - 2017-07-22 07:48:59 --> Helper loaded: form_helper
INFO - 2017-07-22 07:48:59 --> Form Validation Class Initialized
INFO - 2017-07-22 07:48:59 --> Helper loaded: email_helper
DEBUG - 2017-07-22 07:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 07:48:59 --> Helper loaded: url_helper
INFO - 2017-07-22 11:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:18:59 --> Final output sent to browser
DEBUG - 2017-07-22 11:18:59 --> Total execution time: 0.0819
INFO - 2017-07-22 08:25:35 --> Config Class Initialized
INFO - 2017-07-22 08:25:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:25:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:25:35 --> Utf8 Class Initialized
INFO - 2017-07-22 08:25:35 --> URI Class Initialized
INFO - 2017-07-22 08:25:35 --> Router Class Initialized
INFO - 2017-07-22 08:25:35 --> Output Class Initialized
INFO - 2017-07-22 08:25:35 --> Security Class Initialized
DEBUG - 2017-07-22 08:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:25:35 --> Input Class Initialized
INFO - 2017-07-22 08:25:35 --> Language Class Initialized
INFO - 2017-07-22 08:25:35 --> Loader Class Initialized
INFO - 2017-07-22 08:25:35 --> Helper loaded: common_helper
INFO - 2017-07-22 08:25:35 --> Database Driver Class Initialized
INFO - 2017-07-22 08:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:25:35 --> Email Class Initialized
INFO - 2017-07-22 08:25:35 --> Controller Class Initialized
INFO - 2017-07-22 08:25:35 --> Helper loaded: form_helper
INFO - 2017-07-22 08:25:35 --> Form Validation Class Initialized
INFO - 2017-07-22 08:25:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:25:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:25:35 --> Helper loaded: url_helper
INFO - 2017-07-22 11:55:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:55:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:55:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:55:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:55:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:55:35 --> Final output sent to browser
DEBUG - 2017-07-22 11:55:35 --> Total execution time: 0.0530
INFO - 2017-07-22 08:25:36 --> Config Class Initialized
INFO - 2017-07-22 08:25:36 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:25:36 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:25:36 --> Utf8 Class Initialized
INFO - 2017-07-22 08:25:36 --> URI Class Initialized
INFO - 2017-07-22 08:25:36 --> Router Class Initialized
INFO - 2017-07-22 08:25:36 --> Output Class Initialized
INFO - 2017-07-22 08:25:36 --> Security Class Initialized
DEBUG - 2017-07-22 08:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:25:36 --> Input Class Initialized
INFO - 2017-07-22 08:25:36 --> Language Class Initialized
INFO - 2017-07-22 08:25:36 --> Loader Class Initialized
INFO - 2017-07-22 08:25:36 --> Helper loaded: common_helper
INFO - 2017-07-22 08:25:36 --> Database Driver Class Initialized
INFO - 2017-07-22 08:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:25:36 --> Email Class Initialized
INFO - 2017-07-22 08:25:36 --> Controller Class Initialized
INFO - 2017-07-22 08:25:36 --> Helper loaded: form_helper
INFO - 2017-07-22 08:25:36 --> Form Validation Class Initialized
INFO - 2017-07-22 08:25:36 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:25:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:25:36 --> Helper loaded: url_helper
ERROR - 2017-07-22 11:55:36 --> Query error: Unknown column 'isDeleted' in 'where clause' - Invalid query: SELECT *
FROM `bookmarks_type_ref`
WHERE `isDeleted` =0
ERROR - 2017-07-22 11:55:36 --> Call to a member function result() on a non-object
ERROR - 2017-07-22 11:55:36 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 72
INFO - 2017-07-22 08:25:37 --> Config Class Initialized
INFO - 2017-07-22 08:25:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:25:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:25:37 --> Utf8 Class Initialized
INFO - 2017-07-22 08:25:37 --> URI Class Initialized
INFO - 2017-07-22 08:25:37 --> Router Class Initialized
INFO - 2017-07-22 08:25:37 --> Output Class Initialized
INFO - 2017-07-22 08:25:37 --> Security Class Initialized
DEBUG - 2017-07-22 08:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:25:37 --> Input Class Initialized
INFO - 2017-07-22 08:25:37 --> Language Class Initialized
INFO - 2017-07-22 08:25:37 --> Loader Class Initialized
INFO - 2017-07-22 08:25:37 --> Helper loaded: common_helper
INFO - 2017-07-22 08:25:37 --> Database Driver Class Initialized
INFO - 2017-07-22 08:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:25:37 --> Email Class Initialized
INFO - 2017-07-22 08:25:37 --> Controller Class Initialized
INFO - 2017-07-22 08:25:37 --> Helper loaded: form_helper
INFO - 2017-07-22 08:25:37 --> Form Validation Class Initialized
INFO - 2017-07-22 08:25:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:25:37 --> Helper loaded: url_helper
INFO - 2017-07-22 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:55:37 --> Final output sent to browser
DEBUG - 2017-07-22 11:55:37 --> Total execution time: 0.0459
INFO - 2017-07-22 08:26:03 --> Config Class Initialized
INFO - 2017-07-22 08:26:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:26:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:26:03 --> Utf8 Class Initialized
INFO - 2017-07-22 08:26:03 --> URI Class Initialized
INFO - 2017-07-22 08:26:03 --> Router Class Initialized
INFO - 2017-07-22 08:26:03 --> Output Class Initialized
INFO - 2017-07-22 08:26:03 --> Security Class Initialized
DEBUG - 2017-07-22 08:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:26:03 --> Input Class Initialized
INFO - 2017-07-22 08:26:03 --> Language Class Initialized
INFO - 2017-07-22 08:26:03 --> Loader Class Initialized
INFO - 2017-07-22 08:26:03 --> Helper loaded: common_helper
INFO - 2017-07-22 08:26:03 --> Database Driver Class Initialized
INFO - 2017-07-22 08:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:26:03 --> Email Class Initialized
INFO - 2017-07-22 08:26:03 --> Controller Class Initialized
INFO - 2017-07-22 08:26:03 --> Helper loaded: form_helper
INFO - 2017-07-22 08:26:03 --> Form Validation Class Initialized
INFO - 2017-07-22 08:26:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:26:03 --> Helper loaded: url_helper
INFO - 2017-07-22 11:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 11:56:03 --> Undefined variable: subscriptions
ERROR - 2017-07-22 11:56:03 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\subscriptions.php 47
INFO - 2017-07-22 11:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 11:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:56:03 --> Final output sent to browser
DEBUG - 2017-07-22 11:56:03 --> Total execution time: 0.0504
INFO - 2017-07-22 08:26:30 --> Config Class Initialized
INFO - 2017-07-22 08:26:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:26:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:26:30 --> Utf8 Class Initialized
INFO - 2017-07-22 08:26:30 --> URI Class Initialized
INFO - 2017-07-22 08:26:30 --> Router Class Initialized
INFO - 2017-07-22 08:26:30 --> Output Class Initialized
INFO - 2017-07-22 08:26:30 --> Security Class Initialized
DEBUG - 2017-07-22 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:26:30 --> Input Class Initialized
INFO - 2017-07-22 08:26:30 --> Language Class Initialized
INFO - 2017-07-22 08:26:30 --> Loader Class Initialized
INFO - 2017-07-22 08:26:30 --> Helper loaded: common_helper
INFO - 2017-07-22 08:26:30 --> Database Driver Class Initialized
INFO - 2017-07-22 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:26:30 --> Email Class Initialized
INFO - 2017-07-22 08:26:30 --> Controller Class Initialized
INFO - 2017-07-22 08:26:30 --> Helper loaded: form_helper
INFO - 2017-07-22 08:26:30 --> Form Validation Class Initialized
INFO - 2017-07-22 08:26:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:26:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:26:30 --> Helper loaded: url_helper
INFO - 2017-07-22 11:56:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:56:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:56:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:56:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 11:56:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:56:30 --> Final output sent to browser
DEBUG - 2017-07-22 11:56:30 --> Total execution time: 0.0510
INFO - 2017-07-22 08:26:32 --> Config Class Initialized
INFO - 2017-07-22 08:26:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:26:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:26:32 --> Utf8 Class Initialized
INFO - 2017-07-22 08:26:32 --> URI Class Initialized
INFO - 2017-07-22 08:26:32 --> Router Class Initialized
INFO - 2017-07-22 08:26:32 --> Output Class Initialized
INFO - 2017-07-22 08:26:32 --> Security Class Initialized
DEBUG - 2017-07-22 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:26:32 --> Input Class Initialized
INFO - 2017-07-22 08:26:32 --> Language Class Initialized
INFO - 2017-07-22 08:26:32 --> Loader Class Initialized
INFO - 2017-07-22 08:26:32 --> Helper loaded: common_helper
INFO - 2017-07-22 08:26:32 --> Database Driver Class Initialized
INFO - 2017-07-22 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:26:32 --> Email Class Initialized
INFO - 2017-07-22 08:26:32 --> Controller Class Initialized
INFO - 2017-07-22 08:26:32 --> Helper loaded: form_helper
INFO - 2017-07-22 08:26:32 --> Form Validation Class Initialized
INFO - 2017-07-22 08:26:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:26:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:26:32 --> Helper loaded: url_helper
ERROR - 2017-07-22 11:56:32 --> Query error: Unknown column 'cat_id' in 'where clause' - Invalid query: SELECT *
FROM `bookmarks_type_ref`
WHERE `cat_id` = '1'
ERROR - 2017-07-22 11:56:32 --> Call to a member function row() on a non-object
ERROR - 2017-07-22 11:56:32 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 106
INFO - 2017-07-22 08:26:33 --> Config Class Initialized
INFO - 2017-07-22 08:26:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:26:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:26:33 --> Utf8 Class Initialized
INFO - 2017-07-22 08:26:33 --> URI Class Initialized
INFO - 2017-07-22 08:26:33 --> Router Class Initialized
INFO - 2017-07-22 08:26:33 --> Output Class Initialized
INFO - 2017-07-22 08:26:33 --> Security Class Initialized
DEBUG - 2017-07-22 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:26:33 --> Input Class Initialized
INFO - 2017-07-22 08:26:33 --> Language Class Initialized
INFO - 2017-07-22 08:26:33 --> Loader Class Initialized
INFO - 2017-07-22 08:26:33 --> Helper loaded: common_helper
INFO - 2017-07-22 08:26:33 --> Database Driver Class Initialized
INFO - 2017-07-22 08:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:26:33 --> Email Class Initialized
INFO - 2017-07-22 08:26:33 --> Controller Class Initialized
INFO - 2017-07-22 08:26:33 --> Helper loaded: form_helper
INFO - 2017-07-22 08:26:33 --> Form Validation Class Initialized
INFO - 2017-07-22 08:26:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:26:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:26:33 --> Helper loaded: url_helper
INFO - 2017-07-22 11:56:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 11:56:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 11:56:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 11:56:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 11:56:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 11:56:33 --> Final output sent to browser
DEBUG - 2017-07-22 11:56:33 --> Total execution time: 0.0463
INFO - 2017-07-22 08:35:19 --> Config Class Initialized
INFO - 2017-07-22 08:35:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:35:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:35:19 --> Utf8 Class Initialized
INFO - 2017-07-22 08:35:19 --> URI Class Initialized
INFO - 2017-07-22 08:35:19 --> Router Class Initialized
INFO - 2017-07-22 08:35:19 --> Output Class Initialized
INFO - 2017-07-22 08:35:19 --> Security Class Initialized
DEBUG - 2017-07-22 08:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:35:19 --> Input Class Initialized
INFO - 2017-07-22 08:35:19 --> Language Class Initialized
INFO - 2017-07-22 08:35:19 --> Loader Class Initialized
INFO - 2017-07-22 08:35:19 --> Helper loaded: common_helper
INFO - 2017-07-22 08:35:19 --> Database Driver Class Initialized
INFO - 2017-07-22 08:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:35:19 --> Email Class Initialized
INFO - 2017-07-22 08:35:19 --> Controller Class Initialized
INFO - 2017-07-22 08:35:19 --> Helper loaded: form_helper
INFO - 2017-07-22 08:35:19 --> Form Validation Class Initialized
INFO - 2017-07-22 08:35:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:35:19 --> Helper loaded: url_helper
INFO - 2017-07-22 12:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:05:19 --> Final output sent to browser
DEBUG - 2017-07-22 12:05:19 --> Total execution time: 0.0473
INFO - 2017-07-22 08:35:20 --> Config Class Initialized
INFO - 2017-07-22 08:35:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:35:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:35:20 --> Utf8 Class Initialized
INFO - 2017-07-22 08:35:20 --> URI Class Initialized
INFO - 2017-07-22 08:35:20 --> Router Class Initialized
INFO - 2017-07-22 08:35:20 --> Output Class Initialized
INFO - 2017-07-22 08:35:20 --> Security Class Initialized
DEBUG - 2017-07-22 08:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:35:20 --> Input Class Initialized
INFO - 2017-07-22 08:35:20 --> Language Class Initialized
INFO - 2017-07-22 08:35:20 --> Loader Class Initialized
INFO - 2017-07-22 08:35:20 --> Helper loaded: common_helper
INFO - 2017-07-22 08:35:20 --> Database Driver Class Initialized
INFO - 2017-07-22 08:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:35:20 --> Email Class Initialized
INFO - 2017-07-22 08:35:20 --> Controller Class Initialized
INFO - 2017-07-22 08:35:20 --> Helper loaded: form_helper
INFO - 2017-07-22 08:35:20 --> Form Validation Class Initialized
INFO - 2017-07-22 08:35:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:35:20 --> Helper loaded: url_helper
INFO - 2017-07-22 12:05:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:05:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:05:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:05:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:05:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:05:20 --> Final output sent to browser
DEBUG - 2017-07-22 12:05:20 --> Total execution time: 0.0456
INFO - 2017-07-22 08:35:21 --> Config Class Initialized
INFO - 2017-07-22 08:35:21 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:35:21 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:35:21 --> Utf8 Class Initialized
INFO - 2017-07-22 08:35:21 --> URI Class Initialized
INFO - 2017-07-22 08:35:21 --> Router Class Initialized
INFO - 2017-07-22 08:35:21 --> Output Class Initialized
INFO - 2017-07-22 08:35:21 --> Security Class Initialized
DEBUG - 2017-07-22 08:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:35:21 --> Input Class Initialized
INFO - 2017-07-22 08:35:21 --> Language Class Initialized
INFO - 2017-07-22 08:35:21 --> Loader Class Initialized
INFO - 2017-07-22 08:35:21 --> Helper loaded: common_helper
INFO - 2017-07-22 08:35:21 --> Database Driver Class Initialized
INFO - 2017-07-22 08:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:35:21 --> Email Class Initialized
INFO - 2017-07-22 08:35:21 --> Controller Class Initialized
INFO - 2017-07-22 08:35:21 --> Helper loaded: form_helper
INFO - 2017-07-22 08:35:21 --> Form Validation Class Initialized
INFO - 2017-07-22 08:35:21 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:35:21 --> Helper loaded: url_helper
INFO - 2017-07-22 12:05:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:05:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:05:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:05:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:05:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:05:21 --> Final output sent to browser
DEBUG - 2017-07-22 12:05:21 --> Total execution time: 0.0717
INFO - 2017-07-22 08:35:32 --> Config Class Initialized
INFO - 2017-07-22 08:35:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:35:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:35:32 --> Utf8 Class Initialized
INFO - 2017-07-22 08:35:32 --> URI Class Initialized
INFO - 2017-07-22 08:35:32 --> Router Class Initialized
INFO - 2017-07-22 08:35:32 --> Output Class Initialized
INFO - 2017-07-22 08:35:32 --> Security Class Initialized
DEBUG - 2017-07-22 08:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:35:32 --> Input Class Initialized
INFO - 2017-07-22 08:35:32 --> Language Class Initialized
INFO - 2017-07-22 08:35:32 --> Loader Class Initialized
INFO - 2017-07-22 08:35:32 --> Helper loaded: common_helper
INFO - 2017-07-22 08:35:32 --> Database Driver Class Initialized
INFO - 2017-07-22 08:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:35:32 --> Email Class Initialized
INFO - 2017-07-22 08:35:32 --> Controller Class Initialized
INFO - 2017-07-22 08:35:32 --> Helper loaded: form_helper
INFO - 2017-07-22 08:35:32 --> Form Validation Class Initialized
INFO - 2017-07-22 08:35:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:35:32 --> Helper loaded: url_helper
INFO - 2017-07-22 12:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:05:32 --> Final output sent to browser
DEBUG - 2017-07-22 12:05:32 --> Total execution time: 0.0467
INFO - 2017-07-22 08:47:16 --> Config Class Initialized
INFO - 2017-07-22 08:47:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:47:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:47:16 --> Utf8 Class Initialized
INFO - 2017-07-22 08:47:16 --> URI Class Initialized
INFO - 2017-07-22 08:47:16 --> Router Class Initialized
INFO - 2017-07-22 08:47:16 --> Output Class Initialized
INFO - 2017-07-22 08:47:16 --> Security Class Initialized
DEBUG - 2017-07-22 08:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:47:16 --> Input Class Initialized
INFO - 2017-07-22 08:47:16 --> Language Class Initialized
INFO - 2017-07-22 08:47:16 --> Loader Class Initialized
INFO - 2017-07-22 08:47:16 --> Helper loaded: common_helper
INFO - 2017-07-22 08:47:16 --> Database Driver Class Initialized
INFO - 2017-07-22 08:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:47:16 --> Email Class Initialized
INFO - 2017-07-22 08:47:16 --> Controller Class Initialized
INFO - 2017-07-22 08:47:16 --> Helper loaded: form_helper
INFO - 2017-07-22 08:47:16 --> Form Validation Class Initialized
INFO - 2017-07-22 08:47:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:47:16 --> Helper loaded: url_helper
INFO - 2017-07-22 12:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:17:16 --> Final output sent to browser
DEBUG - 2017-07-22 12:17:16 --> Total execution time: 0.0471
INFO - 2017-07-22 08:47:17 --> Config Class Initialized
INFO - 2017-07-22 08:47:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:47:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:47:17 --> Utf8 Class Initialized
INFO - 2017-07-22 08:47:17 --> URI Class Initialized
INFO - 2017-07-22 08:47:17 --> Router Class Initialized
INFO - 2017-07-22 08:47:17 --> Output Class Initialized
INFO - 2017-07-22 08:47:17 --> Security Class Initialized
DEBUG - 2017-07-22 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:47:17 --> Input Class Initialized
INFO - 2017-07-22 08:47:17 --> Language Class Initialized
INFO - 2017-07-22 08:47:17 --> Loader Class Initialized
INFO - 2017-07-22 08:47:17 --> Helper loaded: common_helper
INFO - 2017-07-22 08:47:17 --> Database Driver Class Initialized
INFO - 2017-07-22 08:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:47:17 --> Email Class Initialized
INFO - 2017-07-22 08:47:17 --> Controller Class Initialized
INFO - 2017-07-22 08:47:17 --> Helper loaded: form_helper
INFO - 2017-07-22 08:47:17 --> Form Validation Class Initialized
INFO - 2017-07-22 08:47:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:47:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:47:17 --> Helper loaded: url_helper
INFO - 2017-07-22 12:17:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:17:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:17:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 12:17:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 12:17:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:17:17 --> Final output sent to browser
DEBUG - 2017-07-22 12:17:17 --> Total execution time: 0.0422
INFO - 2017-07-22 08:47:55 --> Config Class Initialized
INFO - 2017-07-22 08:47:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:47:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:47:55 --> Utf8 Class Initialized
INFO - 2017-07-22 08:47:55 --> URI Class Initialized
INFO - 2017-07-22 08:47:55 --> Router Class Initialized
INFO - 2017-07-22 08:47:55 --> Output Class Initialized
INFO - 2017-07-22 08:47:55 --> Security Class Initialized
DEBUG - 2017-07-22 08:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:47:55 --> Input Class Initialized
INFO - 2017-07-22 08:47:55 --> Language Class Initialized
INFO - 2017-07-22 08:47:55 --> Loader Class Initialized
INFO - 2017-07-22 08:47:55 --> Helper loaded: common_helper
INFO - 2017-07-22 08:47:55 --> Database Driver Class Initialized
INFO - 2017-07-22 08:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:47:55 --> Email Class Initialized
INFO - 2017-07-22 08:47:55 --> Controller Class Initialized
INFO - 2017-07-22 08:47:55 --> Helper loaded: form_helper
INFO - 2017-07-22 08:47:55 --> Form Validation Class Initialized
INFO - 2017-07-22 08:47:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:47:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:47:55 --> Helper loaded: url_helper
INFO - 2017-07-22 12:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 86
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 86
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 87
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 87
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 88
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 88
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 89
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 89
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 90
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 90
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 91
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 91
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 92
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 92
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 93
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 93
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 94
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 94
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 95
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 95
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 96
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 96
ERROR - 2017-07-22 12:17:55 --> Undefined variable: details
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 97
ERROR - 2017-07-22 12:17:55 --> Trying to get property of non-object
ERROR - 2017-07-22 12:17:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 97
INFO - 2017-07-22 12:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:17:55 --> Final output sent to browser
DEBUG - 2017-07-22 12:17:55 --> Total execution time: 0.0629
INFO - 2017-07-22 08:48:11 --> Config Class Initialized
INFO - 2017-07-22 08:48:11 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:48:11 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:48:11 --> Utf8 Class Initialized
INFO - 2017-07-22 08:48:11 --> URI Class Initialized
INFO - 2017-07-22 08:48:11 --> Router Class Initialized
INFO - 2017-07-22 08:48:11 --> Output Class Initialized
INFO - 2017-07-22 08:48:11 --> Security Class Initialized
DEBUG - 2017-07-22 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:48:11 --> Input Class Initialized
INFO - 2017-07-22 08:48:11 --> Language Class Initialized
INFO - 2017-07-22 08:48:11 --> Loader Class Initialized
INFO - 2017-07-22 08:48:11 --> Helper loaded: common_helper
INFO - 2017-07-22 08:48:11 --> Database Driver Class Initialized
INFO - 2017-07-22 08:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:48:11 --> Email Class Initialized
INFO - 2017-07-22 08:48:11 --> Controller Class Initialized
INFO - 2017-07-22 08:48:11 --> Helper loaded: form_helper
INFO - 2017-07-22 08:48:11 --> Form Validation Class Initialized
INFO - 2017-07-22 08:48:11 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:48:11 --> Helper loaded: url_helper
INFO - 2017-07-22 12:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 86
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 86
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 87
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 87
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 88
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 88
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 89
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 89
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 90
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 90
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 91
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 91
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 92
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 92
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 93
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 93
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 94
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 94
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 95
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 95
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 96
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 96
ERROR - 2017-07-22 12:18:11 --> Undefined variable: details
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 97
ERROR - 2017-07-22 12:18:11 --> Trying to get property of non-object
ERROR - 2017-07-22 12:18:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 97
INFO - 2017-07-22 12:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:18:11 --> Final output sent to browser
DEBUG - 2017-07-22 12:18:11 --> Total execution time: 0.0772
INFO - 2017-07-22 08:49:01 --> Config Class Initialized
INFO - 2017-07-22 08:49:01 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:49:01 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:49:01 --> Utf8 Class Initialized
INFO - 2017-07-22 08:49:01 --> URI Class Initialized
INFO - 2017-07-22 08:49:01 --> Router Class Initialized
INFO - 2017-07-22 08:49:01 --> Output Class Initialized
INFO - 2017-07-22 08:49:01 --> Security Class Initialized
DEBUG - 2017-07-22 08:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:49:01 --> Input Class Initialized
INFO - 2017-07-22 08:49:01 --> Language Class Initialized
INFO - 2017-07-22 08:49:01 --> Loader Class Initialized
INFO - 2017-07-22 08:49:01 --> Helper loaded: common_helper
INFO - 2017-07-22 08:49:01 --> Database Driver Class Initialized
INFO - 2017-07-22 08:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:49:01 --> Email Class Initialized
INFO - 2017-07-22 08:49:01 --> Controller Class Initialized
INFO - 2017-07-22 08:49:01 --> Helper loaded: form_helper
INFO - 2017-07-22 08:49:01 --> Form Validation Class Initialized
INFO - 2017-07-22 08:49:01 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:49:01 --> Helper loaded: url_helper
INFO - 2017-07-22 12:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:19:01 --> Final output sent to browser
DEBUG - 2017-07-22 12:19:01 --> Total execution time: 0.0451
INFO - 2017-07-22 08:49:03 --> Config Class Initialized
INFO - 2017-07-22 08:49:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:49:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:49:03 --> Utf8 Class Initialized
INFO - 2017-07-22 08:49:03 --> URI Class Initialized
INFO - 2017-07-22 08:49:03 --> Router Class Initialized
INFO - 2017-07-22 08:49:03 --> Output Class Initialized
INFO - 2017-07-22 08:49:03 --> Security Class Initialized
DEBUG - 2017-07-22 08:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:49:03 --> Input Class Initialized
INFO - 2017-07-22 08:49:03 --> Language Class Initialized
INFO - 2017-07-22 08:49:03 --> Loader Class Initialized
INFO - 2017-07-22 08:49:03 --> Helper loaded: common_helper
INFO - 2017-07-22 08:49:03 --> Database Driver Class Initialized
INFO - 2017-07-22 08:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:49:03 --> Email Class Initialized
INFO - 2017-07-22 08:49:03 --> Controller Class Initialized
INFO - 2017-07-22 08:49:03 --> Helper loaded: form_helper
INFO - 2017-07-22 08:49:03 --> Form Validation Class Initialized
INFO - 2017-07-22 08:49:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:49:03 --> Helper loaded: url_helper
INFO - 2017-07-22 12:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:19:03 --> Final output sent to browser
DEBUG - 2017-07-22 12:19:03 --> Total execution time: 0.0430
INFO - 2017-07-22 08:50:07 --> Config Class Initialized
INFO - 2017-07-22 08:50:07 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:50:07 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:50:07 --> Utf8 Class Initialized
INFO - 2017-07-22 08:50:07 --> URI Class Initialized
INFO - 2017-07-22 08:50:07 --> Router Class Initialized
INFO - 2017-07-22 08:50:07 --> Output Class Initialized
INFO - 2017-07-22 08:50:07 --> Security Class Initialized
DEBUG - 2017-07-22 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:50:07 --> Input Class Initialized
INFO - 2017-07-22 08:50:07 --> Language Class Initialized
INFO - 2017-07-22 08:50:07 --> Loader Class Initialized
INFO - 2017-07-22 08:50:07 --> Helper loaded: common_helper
INFO - 2017-07-22 08:50:07 --> Database Driver Class Initialized
INFO - 2017-07-22 08:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:50:07 --> Email Class Initialized
INFO - 2017-07-22 08:50:07 --> Controller Class Initialized
INFO - 2017-07-22 08:50:07 --> Helper loaded: form_helper
INFO - 2017-07-22 08:50:07 --> Form Validation Class Initialized
INFO - 2017-07-22 08:50:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:50:07 --> Helper loaded: url_helper
INFO - 2017-07-22 12:20:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:20:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:20:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:20:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:20:07 --> Final output sent to browser
DEBUG - 2017-07-22 12:20:07 --> Total execution time: 0.0439
INFO - 2017-07-22 08:51:52 --> Config Class Initialized
INFO - 2017-07-22 08:51:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:51:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:51:52 --> Utf8 Class Initialized
INFO - 2017-07-22 08:51:52 --> URI Class Initialized
INFO - 2017-07-22 08:51:52 --> Router Class Initialized
INFO - 2017-07-22 08:51:52 --> Output Class Initialized
INFO - 2017-07-22 08:51:52 --> Security Class Initialized
DEBUG - 2017-07-22 08:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:51:52 --> Input Class Initialized
INFO - 2017-07-22 08:51:52 --> Language Class Initialized
INFO - 2017-07-22 08:51:52 --> Loader Class Initialized
INFO - 2017-07-22 08:51:52 --> Helper loaded: common_helper
INFO - 2017-07-22 08:51:52 --> Database Driver Class Initialized
INFO - 2017-07-22 08:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:51:52 --> Email Class Initialized
INFO - 2017-07-22 08:51:52 --> Controller Class Initialized
INFO - 2017-07-22 08:51:52 --> Helper loaded: form_helper
INFO - 2017-07-22 08:51:52 --> Form Validation Class Initialized
INFO - 2017-07-22 08:51:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:51:52 --> Helper loaded: url_helper
INFO - 2017-07-22 12:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:21:52 --> Final output sent to browser
DEBUG - 2017-07-22 12:21:52 --> Total execution time: 0.0469
INFO - 2017-07-22 08:59:16 --> Config Class Initialized
INFO - 2017-07-22 08:59:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:16 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:16 --> URI Class Initialized
INFO - 2017-07-22 08:59:16 --> Router Class Initialized
INFO - 2017-07-22 08:59:16 --> Output Class Initialized
INFO - 2017-07-22 08:59:16 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:16 --> Input Class Initialized
INFO - 2017-07-22 08:59:16 --> Language Class Initialized
INFO - 2017-07-22 08:59:16 --> Loader Class Initialized
INFO - 2017-07-22 08:59:16 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:16 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:16 --> Email Class Initialized
INFO - 2017-07-22 08:59:16 --> Controller Class Initialized
INFO - 2017-07-22 08:59:16 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:16 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:16 --> Helper loaded: url_helper
INFO - 2017-07-22 12:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:29:16 --> Final output sent to browser
DEBUG - 2017-07-22 12:29:16 --> Total execution time: 0.0460
INFO - 2017-07-22 08:59:17 --> Config Class Initialized
INFO - 2017-07-22 08:59:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:17 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:17 --> URI Class Initialized
INFO - 2017-07-22 08:59:17 --> Router Class Initialized
INFO - 2017-07-22 08:59:17 --> Output Class Initialized
INFO - 2017-07-22 08:59:17 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:17 --> Input Class Initialized
INFO - 2017-07-22 08:59:17 --> Language Class Initialized
INFO - 2017-07-22 08:59:17 --> Loader Class Initialized
INFO - 2017-07-22 08:59:17 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:17 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:17 --> Email Class Initialized
INFO - 2017-07-22 08:59:17 --> Controller Class Initialized
INFO - 2017-07-22 08:59:17 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:17 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:17 --> Helper loaded: url_helper
INFO - 2017-07-22 12:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:29:17 --> Final output sent to browser
DEBUG - 2017-07-22 12:29:17 --> Total execution time: 0.0425
INFO - 2017-07-22 08:59:26 --> Config Class Initialized
INFO - 2017-07-22 08:59:26 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:26 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:26 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:26 --> URI Class Initialized
INFO - 2017-07-22 08:59:26 --> Router Class Initialized
INFO - 2017-07-22 08:59:26 --> Output Class Initialized
INFO - 2017-07-22 08:59:26 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:26 --> Input Class Initialized
INFO - 2017-07-22 08:59:26 --> Language Class Initialized
INFO - 2017-07-22 08:59:26 --> Loader Class Initialized
INFO - 2017-07-22 08:59:26 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:26 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:26 --> Email Class Initialized
INFO - 2017-07-22 08:59:26 --> Controller Class Initialized
INFO - 2017-07-22 08:59:26 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:26 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:26 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:26 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:29:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:29:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 08:59:26 --> Config Class Initialized
INFO - 2017-07-22 08:59:26 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:26 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:26 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:26 --> URI Class Initialized
INFO - 2017-07-22 08:59:26 --> Router Class Initialized
INFO - 2017-07-22 08:59:26 --> Output Class Initialized
INFO - 2017-07-22 08:59:26 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:26 --> Input Class Initialized
INFO - 2017-07-22 08:59:26 --> Language Class Initialized
INFO - 2017-07-22 08:59:26 --> Loader Class Initialized
INFO - 2017-07-22 08:59:26 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:26 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:26 --> Email Class Initialized
INFO - 2017-07-22 08:59:26 --> Controller Class Initialized
INFO - 2017-07-22 08:59:26 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:26 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:26 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:26 --> Helper loaded: url_helper
INFO - 2017-07-22 12:29:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:29:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:29:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:29:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:29:26 --> Final output sent to browser
DEBUG - 2017-07-22 12:29:26 --> Total execution time: 0.0483
INFO - 2017-07-22 08:59:37 --> Config Class Initialized
INFO - 2017-07-22 08:59:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:37 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:37 --> URI Class Initialized
INFO - 2017-07-22 08:59:37 --> Router Class Initialized
INFO - 2017-07-22 08:59:37 --> Output Class Initialized
INFO - 2017-07-22 08:59:37 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:37 --> Input Class Initialized
INFO - 2017-07-22 08:59:37 --> Language Class Initialized
INFO - 2017-07-22 08:59:37 --> Loader Class Initialized
INFO - 2017-07-22 08:59:37 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:37 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:37 --> Email Class Initialized
INFO - 2017-07-22 08:59:37 --> Controller Class Initialized
INFO - 2017-07-22 08:59:37 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:37 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:37 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:29:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:29:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 08:59:37 --> Config Class Initialized
INFO - 2017-07-22 08:59:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:37 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:37 --> URI Class Initialized
INFO - 2017-07-22 08:59:37 --> Router Class Initialized
INFO - 2017-07-22 08:59:37 --> Output Class Initialized
INFO - 2017-07-22 08:59:37 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:37 --> Input Class Initialized
INFO - 2017-07-22 08:59:37 --> Language Class Initialized
INFO - 2017-07-22 08:59:37 --> Loader Class Initialized
INFO - 2017-07-22 08:59:37 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:37 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:37 --> Email Class Initialized
INFO - 2017-07-22 08:59:37 --> Controller Class Initialized
INFO - 2017-07-22 08:59:37 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:37 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:37 --> Helper loaded: url_helper
INFO - 2017-07-22 12:29:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:29:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:29:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:29:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:29:37 --> Final output sent to browser
DEBUG - 2017-07-22 12:29:37 --> Total execution time: 0.0484
INFO - 2017-07-22 08:59:58 --> Config Class Initialized
INFO - 2017-07-22 08:59:58 --> Hooks Class Initialized
DEBUG - 2017-07-22 08:59:58 --> UTF-8 Support Enabled
INFO - 2017-07-22 08:59:58 --> Utf8 Class Initialized
INFO - 2017-07-22 08:59:58 --> URI Class Initialized
INFO - 2017-07-22 08:59:58 --> Router Class Initialized
INFO - 2017-07-22 08:59:58 --> Output Class Initialized
INFO - 2017-07-22 08:59:58 --> Security Class Initialized
DEBUG - 2017-07-22 08:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 08:59:58 --> Input Class Initialized
INFO - 2017-07-22 08:59:58 --> Language Class Initialized
INFO - 2017-07-22 08:59:58 --> Loader Class Initialized
INFO - 2017-07-22 08:59:58 --> Helper loaded: common_helper
INFO - 2017-07-22 08:59:58 --> Database Driver Class Initialized
INFO - 2017-07-22 08:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 08:59:58 --> Email Class Initialized
INFO - 2017-07-22 08:59:58 --> Controller Class Initialized
INFO - 2017-07-22 08:59:58 --> Helper loaded: form_helper
INFO - 2017-07-22 08:59:58 --> Form Validation Class Initialized
INFO - 2017-07-22 08:59:58 --> Helper loaded: email_helper
DEBUG - 2017-07-22 08:59:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 08:59:58 --> Helper loaded: url_helper
INFO - 2017-07-22 12:29:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:29:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:29:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:29:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:29:58 --> Final output sent to browser
DEBUG - 2017-07-22 12:29:58 --> Total execution time: 0.0434
INFO - 2017-07-22 09:00:06 --> Config Class Initialized
INFO - 2017-07-22 09:00:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:06 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:06 --> URI Class Initialized
INFO - 2017-07-22 09:00:06 --> Router Class Initialized
INFO - 2017-07-22 09:00:06 --> Output Class Initialized
INFO - 2017-07-22 09:00:06 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:06 --> Input Class Initialized
INFO - 2017-07-22 09:00:06 --> Language Class Initialized
INFO - 2017-07-22 09:00:06 --> Loader Class Initialized
INFO - 2017-07-22 09:00:06 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:07 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:07 --> Email Class Initialized
INFO - 2017-07-22 09:00:07 --> Controller Class Initialized
INFO - 2017-07-22 09:00:07 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:07 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:07 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:30:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:30:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:00:07 --> Config Class Initialized
INFO - 2017-07-22 09:00:07 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:07 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:07 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:07 --> URI Class Initialized
INFO - 2017-07-22 09:00:07 --> Router Class Initialized
INFO - 2017-07-22 09:00:07 --> Output Class Initialized
INFO - 2017-07-22 09:00:07 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:07 --> Input Class Initialized
INFO - 2017-07-22 09:00:07 --> Language Class Initialized
INFO - 2017-07-22 09:00:07 --> Loader Class Initialized
INFO - 2017-07-22 09:00:07 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:07 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:07 --> Email Class Initialized
INFO - 2017-07-22 09:00:07 --> Controller Class Initialized
INFO - 2017-07-22 09:00:07 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:07 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:07 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:30:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:30:07 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:07 --> Total execution time: 0.0428
INFO - 2017-07-22 09:00:10 --> Config Class Initialized
INFO - 2017-07-22 09:00:10 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:10 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:10 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:10 --> URI Class Initialized
INFO - 2017-07-22 09:00:10 --> Router Class Initialized
INFO - 2017-07-22 09:00:10 --> Output Class Initialized
INFO - 2017-07-22 09:00:10 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:10 --> Input Class Initialized
INFO - 2017-07-22 09:00:10 --> Language Class Initialized
INFO - 2017-07-22 09:00:10 --> Loader Class Initialized
INFO - 2017-07-22 09:00:10 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:10 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:10 --> Email Class Initialized
INFO - 2017-07-22 09:00:10 --> Controller Class Initialized
INFO - 2017-07-22 09:00:10 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:10 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:10 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:10 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:30:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:10 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:10 --> Total execution time: 0.0428
INFO - 2017-07-22 09:00:15 --> Config Class Initialized
INFO - 2017-07-22 09:00:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:15 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:15 --> URI Class Initialized
INFO - 2017-07-22 09:00:15 --> Router Class Initialized
INFO - 2017-07-22 09:00:15 --> Output Class Initialized
INFO - 2017-07-22 09:00:15 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:15 --> Input Class Initialized
INFO - 2017-07-22 09:00:15 --> Language Class Initialized
INFO - 2017-07-22 09:00:15 --> Loader Class Initialized
INFO - 2017-07-22 09:00:15 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:15 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:15 --> Email Class Initialized
INFO - 2017-07-22 09:00:15 --> Controller Class Initialized
INFO - 2017-07-22 09:00:15 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:15 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:15 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:30:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:30:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:00:16 --> Config Class Initialized
INFO - 2017-07-22 09:00:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:16 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:16 --> URI Class Initialized
INFO - 2017-07-22 09:00:16 --> Router Class Initialized
INFO - 2017-07-22 09:00:16 --> Output Class Initialized
INFO - 2017-07-22 09:00:16 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:16 --> Input Class Initialized
INFO - 2017-07-22 09:00:16 --> Language Class Initialized
INFO - 2017-07-22 09:00:16 --> Loader Class Initialized
INFO - 2017-07-22 09:00:16 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:16 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:16 --> Email Class Initialized
INFO - 2017-07-22 09:00:16 --> Controller Class Initialized
INFO - 2017-07-22 09:00:16 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:16 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:16 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:30:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:30:16 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:16 --> Total execution time: 0.1026
INFO - 2017-07-22 09:00:20 --> Config Class Initialized
INFO - 2017-07-22 09:00:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:20 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:20 --> URI Class Initialized
INFO - 2017-07-22 09:00:20 --> Router Class Initialized
INFO - 2017-07-22 09:00:20 --> Output Class Initialized
INFO - 2017-07-22 09:00:20 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:20 --> Input Class Initialized
INFO - 2017-07-22 09:00:20 --> Language Class Initialized
INFO - 2017-07-22 09:00:20 --> Loader Class Initialized
INFO - 2017-07-22 09:00:20 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:20 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:20 --> Email Class Initialized
INFO - 2017-07-22 09:00:20 --> Controller Class Initialized
INFO - 2017-07-22 09:00:20 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:20 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:20 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:30:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:20 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:20 --> Total execution time: 0.0593
INFO - 2017-07-22 09:00:30 --> Config Class Initialized
INFO - 2017-07-22 09:00:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:31 --> URI Class Initialized
INFO - 2017-07-22 09:00:31 --> Router Class Initialized
INFO - 2017-07-22 09:00:31 --> Output Class Initialized
INFO - 2017-07-22 09:00:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:31 --> Input Class Initialized
INFO - 2017-07-22 09:00:31 --> Language Class Initialized
INFO - 2017-07-22 09:00:31 --> Loader Class Initialized
INFO - 2017-07-22 09:00:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:31 --> Email Class Initialized
INFO - 2017-07-22 09:00:31 --> Controller Class Initialized
INFO - 2017-07-22 09:00:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:31 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:30:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:30:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:00:31 --> Config Class Initialized
INFO - 2017-07-22 09:00:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:31 --> URI Class Initialized
INFO - 2017-07-22 09:00:31 --> Router Class Initialized
INFO - 2017-07-22 09:00:31 --> Output Class Initialized
INFO - 2017-07-22 09:00:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:31 --> Input Class Initialized
INFO - 2017-07-22 09:00:31 --> Language Class Initialized
INFO - 2017-07-22 09:00:31 --> Loader Class Initialized
INFO - 2017-07-22 09:00:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:31 --> Email Class Initialized
INFO - 2017-07-22 09:00:31 --> Controller Class Initialized
INFO - 2017-07-22 09:00:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:31 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:31 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:31 --> Total execution time: 0.0433
INFO - 2017-07-22 09:00:38 --> Config Class Initialized
INFO - 2017-07-22 09:00:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:38 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:38 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:38 --> URI Class Initialized
INFO - 2017-07-22 09:00:38 --> Router Class Initialized
INFO - 2017-07-22 09:00:38 --> Output Class Initialized
INFO - 2017-07-22 09:00:38 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:38 --> Input Class Initialized
INFO - 2017-07-22 09:00:38 --> Language Class Initialized
INFO - 2017-07-22 09:00:38 --> Loader Class Initialized
INFO - 2017-07-22 09:00:38 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:38 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:38 --> Email Class Initialized
INFO - 2017-07-22 09:00:38 --> Controller Class Initialized
INFO - 2017-07-22 09:00:38 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:38 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:38 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:38 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:30:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:38 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:38 --> Total execution time: 0.0470
INFO - 2017-07-22 09:00:48 --> Config Class Initialized
INFO - 2017-07-22 09:00:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:48 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:48 --> URI Class Initialized
INFO - 2017-07-22 09:00:48 --> Router Class Initialized
INFO - 2017-07-22 09:00:48 --> Output Class Initialized
INFO - 2017-07-22 09:00:48 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:48 --> Input Class Initialized
INFO - 2017-07-22 09:00:48 --> Language Class Initialized
INFO - 2017-07-22 09:00:48 --> Loader Class Initialized
INFO - 2017-07-22 09:00:48 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:48 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:48 --> Email Class Initialized
INFO - 2017-07-22 09:00:48 --> Controller Class Initialized
INFO - 2017-07-22 09:00:48 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:48 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:48 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:30:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:30:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:00:48 --> Config Class Initialized
INFO - 2017-07-22 09:00:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:00:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:00:48 --> Utf8 Class Initialized
INFO - 2017-07-22 09:00:48 --> URI Class Initialized
INFO - 2017-07-22 09:00:48 --> Router Class Initialized
INFO - 2017-07-22 09:00:48 --> Output Class Initialized
INFO - 2017-07-22 09:00:48 --> Security Class Initialized
DEBUG - 2017-07-22 09:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:00:48 --> Input Class Initialized
INFO - 2017-07-22 09:00:48 --> Language Class Initialized
INFO - 2017-07-22 09:00:48 --> Loader Class Initialized
INFO - 2017-07-22 09:00:48 --> Helper loaded: common_helper
INFO - 2017-07-22 09:00:48 --> Database Driver Class Initialized
INFO - 2017-07-22 09:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:00:48 --> Email Class Initialized
INFO - 2017-07-22 09:00:48 --> Controller Class Initialized
INFO - 2017-07-22 09:00:48 --> Helper loaded: form_helper
INFO - 2017-07-22 09:00:48 --> Form Validation Class Initialized
INFO - 2017-07-22 09:00:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:00:48 --> Helper loaded: url_helper
INFO - 2017-07-22 12:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:30:48 --> Final output sent to browser
DEBUG - 2017-07-22 12:30:48 --> Total execution time: 0.0512
INFO - 2017-07-22 09:01:23 --> Config Class Initialized
INFO - 2017-07-22 09:01:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:01:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:01:23 --> Utf8 Class Initialized
INFO - 2017-07-22 09:01:23 --> URI Class Initialized
INFO - 2017-07-22 09:01:23 --> Router Class Initialized
INFO - 2017-07-22 09:01:23 --> Output Class Initialized
INFO - 2017-07-22 09:01:23 --> Security Class Initialized
DEBUG - 2017-07-22 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:01:23 --> Input Class Initialized
INFO - 2017-07-22 09:01:23 --> Language Class Initialized
INFO - 2017-07-22 09:01:23 --> Loader Class Initialized
INFO - 2017-07-22 09:01:23 --> Helper loaded: common_helper
INFO - 2017-07-22 09:01:23 --> Database Driver Class Initialized
INFO - 2017-07-22 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:01:23 --> Email Class Initialized
INFO - 2017-07-22 09:01:23 --> Controller Class Initialized
INFO - 2017-07-22 09:01:23 --> Helper loaded: form_helper
INFO - 2017-07-22 09:01:23 --> Form Validation Class Initialized
INFO - 2017-07-22 09:01:23 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:01:23 --> Helper loaded: url_helper
INFO - 2017-07-22 12:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:31:23 --> Final output sent to browser
DEBUG - 2017-07-22 12:31:23 --> Total execution time: 0.0467
INFO - 2017-07-22 09:01:28 --> Config Class Initialized
INFO - 2017-07-22 09:01:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:01:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:01:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:01:28 --> URI Class Initialized
INFO - 2017-07-22 09:01:28 --> Router Class Initialized
INFO - 2017-07-22 09:01:28 --> Output Class Initialized
INFO - 2017-07-22 09:01:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:01:28 --> Input Class Initialized
INFO - 2017-07-22 09:01:28 --> Language Class Initialized
INFO - 2017-07-22 09:01:28 --> Loader Class Initialized
INFO - 2017-07-22 09:01:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:01:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:01:28 --> Email Class Initialized
INFO - 2017-07-22 09:01:28 --> Controller Class Initialized
INFO - 2017-07-22 09:01:28 --> Helper loaded: form_helper
INFO - 2017-07-22 09:01:28 --> Form Validation Class Initialized
INFO - 2017-07-22 09:01:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:01:28 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:31:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:31:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:01:28 --> Config Class Initialized
INFO - 2017-07-22 09:01:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:01:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:01:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:01:28 --> URI Class Initialized
INFO - 2017-07-22 09:01:28 --> Router Class Initialized
INFO - 2017-07-22 09:01:28 --> Output Class Initialized
INFO - 2017-07-22 09:01:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:01:28 --> Input Class Initialized
INFO - 2017-07-22 09:01:28 --> Language Class Initialized
INFO - 2017-07-22 09:01:28 --> Loader Class Initialized
INFO - 2017-07-22 09:01:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:01:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:01:28 --> Email Class Initialized
INFO - 2017-07-22 09:01:28 --> Controller Class Initialized
INFO - 2017-07-22 09:01:28 --> Helper loaded: form_helper
INFO - 2017-07-22 09:01:28 --> Form Validation Class Initialized
INFO - 2017-07-22 09:01:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:01:28 --> Helper loaded: url_helper
INFO - 2017-07-22 12:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:31:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:31:28 --> Final output sent to browser
DEBUG - 2017-07-22 12:31:28 --> Total execution time: 0.0407
INFO - 2017-07-22 09:02:01 --> Config Class Initialized
INFO - 2017-07-22 09:02:01 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:01 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:01 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:01 --> URI Class Initialized
INFO - 2017-07-22 09:02:01 --> Router Class Initialized
INFO - 2017-07-22 09:02:01 --> Output Class Initialized
INFO - 2017-07-22 09:02:01 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:01 --> Input Class Initialized
INFO - 2017-07-22 09:02:01 --> Language Class Initialized
INFO - 2017-07-22 09:02:01 --> Loader Class Initialized
INFO - 2017-07-22 09:02:01 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:01 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:01 --> Email Class Initialized
INFO - 2017-07-22 09:02:01 --> Controller Class Initialized
INFO - 2017-07-22 09:02:01 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:01 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:01 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:01 --> Helper loaded: url_helper
INFO - 2017-07-22 12:32:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:32:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:32:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:32:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:32:01 --> Final output sent to browser
DEBUG - 2017-07-22 12:32:01 --> Total execution time: 0.0437
INFO - 2017-07-22 09:02:12 --> Config Class Initialized
INFO - 2017-07-22 09:02:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:12 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:12 --> URI Class Initialized
INFO - 2017-07-22 09:02:12 --> Router Class Initialized
INFO - 2017-07-22 09:02:12 --> Output Class Initialized
INFO - 2017-07-22 09:02:12 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:12 --> Input Class Initialized
INFO - 2017-07-22 09:02:12 --> Language Class Initialized
INFO - 2017-07-22 09:02:12 --> Loader Class Initialized
INFO - 2017-07-22 09:02:12 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:12 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:12 --> Email Class Initialized
INFO - 2017-07-22 09:02:12 --> Controller Class Initialized
INFO - 2017-07-22 09:02:12 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:12 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:12 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:12 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:32:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:32:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:02:12 --> Config Class Initialized
INFO - 2017-07-22 09:02:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:12 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:12 --> URI Class Initialized
INFO - 2017-07-22 09:02:13 --> Router Class Initialized
INFO - 2017-07-22 09:02:13 --> Output Class Initialized
INFO - 2017-07-22 09:02:13 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:13 --> Input Class Initialized
INFO - 2017-07-22 09:02:13 --> Language Class Initialized
INFO - 2017-07-22 09:02:13 --> Loader Class Initialized
INFO - 2017-07-22 09:02:13 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:13 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:13 --> Email Class Initialized
INFO - 2017-07-22 09:02:13 --> Controller Class Initialized
INFO - 2017-07-22 09:02:13 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:13 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:13 --> Helper loaded: url_helper
INFO - 2017-07-22 12:32:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:32:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:32:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:32:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:32:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:32:13 --> Final output sent to browser
DEBUG - 2017-07-22 12:32:13 --> Total execution time: 0.0792
INFO - 2017-07-22 09:02:15 --> Config Class Initialized
INFO - 2017-07-22 09:02:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:15 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:15 --> URI Class Initialized
INFO - 2017-07-22 09:02:15 --> Router Class Initialized
INFO - 2017-07-22 09:02:15 --> Output Class Initialized
INFO - 2017-07-22 09:02:15 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:15 --> Input Class Initialized
INFO - 2017-07-22 09:02:15 --> Language Class Initialized
INFO - 2017-07-22 09:02:15 --> Loader Class Initialized
INFO - 2017-07-22 09:02:15 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:15 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:15 --> Email Class Initialized
INFO - 2017-07-22 09:02:15 --> Controller Class Initialized
INFO - 2017-07-22 09:02:15 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:15 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:15 --> Helper loaded: url_helper
INFO - 2017-07-22 12:32:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:32:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:32:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:32:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:32:15 --> Final output sent to browser
DEBUG - 2017-07-22 12:32:15 --> Total execution time: 0.0429
INFO - 2017-07-22 09:02:23 --> Config Class Initialized
INFO - 2017-07-22 09:02:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:23 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:23 --> URI Class Initialized
INFO - 2017-07-22 09:02:23 --> Router Class Initialized
INFO - 2017-07-22 09:02:23 --> Output Class Initialized
INFO - 2017-07-22 09:02:23 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:23 --> Input Class Initialized
INFO - 2017-07-22 09:02:23 --> Language Class Initialized
INFO - 2017-07-22 09:02:23 --> Loader Class Initialized
INFO - 2017-07-22 09:02:23 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:23 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:23 --> Email Class Initialized
INFO - 2017-07-22 09:02:23 --> Controller Class Initialized
INFO - 2017-07-22 09:02:23 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:23 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:23 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:23 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:32:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:32:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-22 12:32:23 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 12:32:23 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-22 12:32:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `bm_type_ref` = 'sssssss2', `bm_amount` = '22', `bm_discount` = '22', `bm_acces' at line 1 - Invalid query: UPDATE `bookmarks_type_ref` SET `details` = , `bm_type_ref` = 'sssssss2', `bm_amount` = '22', `bm_discount` = '22', `bm_access_count` = '22', `bm_cloud_save` = '22', `bm_monthly_gift_card` = '1', `bm_is_not_free` = '1', `bm_access_time` = '11 Months', `bm_updatedAt` = '17-07-22 12:32:23'
WHERE `bm_type_ref_id` = '7'
INFO - 2017-07-22 09:02:23 --> Config Class Initialized
INFO - 2017-07-22 09:02:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:23 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:23 --> URI Class Initialized
INFO - 2017-07-22 09:02:23 --> Router Class Initialized
INFO - 2017-07-22 09:02:23 --> Output Class Initialized
INFO - 2017-07-22 09:02:23 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:23 --> Input Class Initialized
INFO - 2017-07-22 09:02:23 --> Language Class Initialized
INFO - 2017-07-22 09:02:23 --> Loader Class Initialized
INFO - 2017-07-22 09:02:23 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:23 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:23 --> Email Class Initialized
INFO - 2017-07-22 09:02:23 --> Controller Class Initialized
INFO - 2017-07-22 09:02:23 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:23 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:23 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:23 --> Helper loaded: url_helper
INFO - 2017-07-22 12:32:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:32:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:32:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:32:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:32:23 --> Final output sent to browser
DEBUG - 2017-07-22 12:32:23 --> Total execution time: 0.0518
INFO - 2017-07-22 09:02:41 --> Config Class Initialized
INFO - 2017-07-22 09:02:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:41 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:41 --> URI Class Initialized
INFO - 2017-07-22 09:02:41 --> Router Class Initialized
INFO - 2017-07-22 09:02:41 --> Output Class Initialized
INFO - 2017-07-22 09:02:41 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:41 --> Input Class Initialized
INFO - 2017-07-22 09:02:41 --> Language Class Initialized
INFO - 2017-07-22 09:02:41 --> Loader Class Initialized
INFO - 2017-07-22 09:02:41 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:41 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:41 --> Email Class Initialized
INFO - 2017-07-22 09:02:41 --> Controller Class Initialized
INFO - 2017-07-22 09:02:41 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:41 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:41 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:32:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-22 12:32:41 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 12:32:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-22 12:32:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `bm_type_ref` = 'sssssss', `bm_amount` = '22', `bm_discount` = '22', `bm_access' at line 1 - Invalid query: UPDATE `bookmarks_type_ref` SET `details` = , `bm_type_ref` = 'sssssss', `bm_amount` = '22', `bm_discount` = '22', `bm_access_count` = '22', `bm_cloud_save` = '22', `bm_monthly_gift_card` = '1', `bm_is_not_free` = '1', `bm_access_time` = '12 Months', `bm_updatedAt` = '17-07-22 12:32:41'
WHERE `bm_type_ref_id` = '7'
INFO - 2017-07-22 09:02:41 --> Config Class Initialized
INFO - 2017-07-22 09:02:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:02:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:02:41 --> Utf8 Class Initialized
INFO - 2017-07-22 09:02:41 --> URI Class Initialized
INFO - 2017-07-22 09:02:41 --> Router Class Initialized
INFO - 2017-07-22 09:02:41 --> Output Class Initialized
INFO - 2017-07-22 09:02:41 --> Security Class Initialized
DEBUG - 2017-07-22 09:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:02:41 --> Input Class Initialized
INFO - 2017-07-22 09:02:41 --> Language Class Initialized
INFO - 2017-07-22 09:02:41 --> Loader Class Initialized
INFO - 2017-07-22 09:02:41 --> Helper loaded: common_helper
INFO - 2017-07-22 09:02:41 --> Database Driver Class Initialized
INFO - 2017-07-22 09:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:02:41 --> Email Class Initialized
INFO - 2017-07-22 09:02:41 --> Controller Class Initialized
INFO - 2017-07-22 09:02:41 --> Helper loaded: form_helper
INFO - 2017-07-22 09:02:41 --> Form Validation Class Initialized
INFO - 2017-07-22 09:02:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:02:41 --> Helper loaded: url_helper
INFO - 2017-07-22 12:32:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:32:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:32:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:32:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:32:41 --> Final output sent to browser
DEBUG - 2017-07-22 12:32:41 --> Total execution time: 0.0466
INFO - 2017-07-22 09:03:27 --> Config Class Initialized
INFO - 2017-07-22 09:03:27 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:03:27 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:03:27 --> Utf8 Class Initialized
INFO - 2017-07-22 09:03:27 --> URI Class Initialized
INFO - 2017-07-22 09:03:27 --> Router Class Initialized
INFO - 2017-07-22 09:03:27 --> Output Class Initialized
INFO - 2017-07-22 09:03:27 --> Security Class Initialized
DEBUG - 2017-07-22 09:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:03:27 --> Input Class Initialized
INFO - 2017-07-22 09:03:27 --> Language Class Initialized
INFO - 2017-07-22 09:03:27 --> Loader Class Initialized
INFO - 2017-07-22 09:03:27 --> Helper loaded: common_helper
INFO - 2017-07-22 09:03:27 --> Database Driver Class Initialized
INFO - 2017-07-22 09:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:03:27 --> Email Class Initialized
INFO - 2017-07-22 09:03:27 --> Controller Class Initialized
INFO - 2017-07-22 09:03:27 --> Helper loaded: form_helper
INFO - 2017-07-22 09:03:27 --> Form Validation Class Initialized
INFO - 2017-07-22 09:03:27 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:03:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:03:27 --> Helper loaded: url_helper
INFO - 2017-07-22 12:33:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:33:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:33:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:33:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:33:27 --> Final output sent to browser
DEBUG - 2017-07-22 12:33:27 --> Total execution time: 0.0433
INFO - 2017-07-22 09:03:36 --> Config Class Initialized
INFO - 2017-07-22 09:03:36 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:03:36 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:03:36 --> Utf8 Class Initialized
INFO - 2017-07-22 09:03:36 --> URI Class Initialized
INFO - 2017-07-22 09:03:36 --> Router Class Initialized
INFO - 2017-07-22 09:03:36 --> Output Class Initialized
INFO - 2017-07-22 09:03:36 --> Security Class Initialized
DEBUG - 2017-07-22 09:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:03:36 --> Input Class Initialized
INFO - 2017-07-22 09:03:36 --> Language Class Initialized
INFO - 2017-07-22 09:03:36 --> Loader Class Initialized
INFO - 2017-07-22 09:03:36 --> Helper loaded: common_helper
INFO - 2017-07-22 09:03:36 --> Database Driver Class Initialized
INFO - 2017-07-22 09:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:03:36 --> Email Class Initialized
INFO - 2017-07-22 09:03:36 --> Controller Class Initialized
INFO - 2017-07-22 09:03:36 --> Helper loaded: form_helper
INFO - 2017-07-22 09:03:36 --> Form Validation Class Initialized
INFO - 2017-07-22 09:03:36 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:03:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:03:36 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:33:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:33:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-22 12:33:36 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 12:33:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\system\database\DB_driver.php 1440
ERROR - 2017-07-22 12:33:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' `bm_type_ref` = 'sssssssrt', `bm_amount` = '24', `bm_discount` = '24', `bm_acce' at line 1 - Invalid query: UPDATE `bookmarks_type_ref` SET `details` = , `bm_type_ref` = 'sssssssrt', `bm_amount` = '24', `bm_discount` = '24', `bm_access_count` = '24', `bm_cloud_save` = '24', `bm_monthly_gift_card` = '1', `bm_is_not_free` = '1', `bm_access_time` = '2 Months', `bm_updatedAt` = '17-07-22 12:33:36'
WHERE `bm_type_ref_id` = '7'
INFO - 2017-07-22 09:05:08 --> Config Class Initialized
INFO - 2017-07-22 09:05:08 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:08 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:08 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:08 --> URI Class Initialized
INFO - 2017-07-22 09:05:08 --> Router Class Initialized
INFO - 2017-07-22 09:05:08 --> Output Class Initialized
INFO - 2017-07-22 09:05:08 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:08 --> Input Class Initialized
INFO - 2017-07-22 09:05:08 --> Language Class Initialized
INFO - 2017-07-22 09:05:08 --> Loader Class Initialized
INFO - 2017-07-22 09:05:08 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:08 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:08 --> Email Class Initialized
INFO - 2017-07-22 09:05:08 --> Controller Class Initialized
INFO - 2017-07-22 09:05:08 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:08 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:08 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:08 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:35:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:05:08 --> Config Class Initialized
INFO - 2017-07-22 09:05:08 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:08 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:08 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:08 --> URI Class Initialized
INFO - 2017-07-22 09:05:08 --> Router Class Initialized
INFO - 2017-07-22 09:05:08 --> Output Class Initialized
INFO - 2017-07-22 09:05:08 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:08 --> Input Class Initialized
INFO - 2017-07-22 09:05:08 --> Language Class Initialized
INFO - 2017-07-22 09:05:08 --> Loader Class Initialized
INFO - 2017-07-22 09:05:08 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:08 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:08 --> Email Class Initialized
INFO - 2017-07-22 09:05:08 --> Controller Class Initialized
INFO - 2017-07-22 09:05:08 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:08 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:08 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:08 --> Helper loaded: url_helper
INFO - 2017-07-22 12:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:35:08 --> Final output sent to browser
DEBUG - 2017-07-22 12:35:08 --> Total execution time: 0.0434
INFO - 2017-07-22 09:05:11 --> Config Class Initialized
INFO - 2017-07-22 09:05:11 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:11 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:11 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:11 --> URI Class Initialized
INFO - 2017-07-22 09:05:11 --> Router Class Initialized
INFO - 2017-07-22 09:05:11 --> Output Class Initialized
INFO - 2017-07-22 09:05:11 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:11 --> Input Class Initialized
INFO - 2017-07-22 09:05:11 --> Language Class Initialized
INFO - 2017-07-22 09:05:11 --> Loader Class Initialized
INFO - 2017-07-22 09:05:11 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:11 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:11 --> Email Class Initialized
INFO - 2017-07-22 09:05:11 --> Controller Class Initialized
INFO - 2017-07-22 09:05:11 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:11 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:11 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:11 --> Helper loaded: url_helper
INFO - 2017-07-22 12:35:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:35:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:35:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:35:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:35:11 --> Final output sent to browser
DEBUG - 2017-07-22 12:35:11 --> Total execution time: 0.0427
INFO - 2017-07-22 09:05:20 --> Config Class Initialized
INFO - 2017-07-22 09:05:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:20 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:20 --> URI Class Initialized
INFO - 2017-07-22 09:05:20 --> Router Class Initialized
INFO - 2017-07-22 09:05:20 --> Output Class Initialized
INFO - 2017-07-22 09:05:20 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:20 --> Input Class Initialized
INFO - 2017-07-22 09:05:20 --> Language Class Initialized
INFO - 2017-07-22 09:05:20 --> Loader Class Initialized
INFO - 2017-07-22 09:05:20 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:20 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:20 --> Email Class Initialized
INFO - 2017-07-22 09:05:20 --> Controller Class Initialized
INFO - 2017-07-22 09:05:20 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:20 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:20 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:35:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:05:20 --> Config Class Initialized
INFO - 2017-07-22 09:05:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:20 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:20 --> URI Class Initialized
INFO - 2017-07-22 09:05:20 --> Router Class Initialized
INFO - 2017-07-22 09:05:20 --> Output Class Initialized
INFO - 2017-07-22 09:05:20 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:20 --> Input Class Initialized
INFO - 2017-07-22 09:05:20 --> Language Class Initialized
INFO - 2017-07-22 09:05:20 --> Loader Class Initialized
INFO - 2017-07-22 09:05:20 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:20 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:20 --> Email Class Initialized
INFO - 2017-07-22 09:05:20 --> Controller Class Initialized
INFO - 2017-07-22 09:05:20 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:20 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:20 --> Helper loaded: url_helper
INFO - 2017-07-22 12:35:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:35:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:35:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:35:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:35:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:35:20 --> Final output sent to browser
DEBUG - 2017-07-22 12:35:20 --> Total execution time: 0.0477
INFO - 2017-07-22 09:05:22 --> Config Class Initialized
INFO - 2017-07-22 09:05:22 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:22 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:22 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:22 --> URI Class Initialized
INFO - 2017-07-22 09:05:22 --> Router Class Initialized
INFO - 2017-07-22 09:05:22 --> Output Class Initialized
INFO - 2017-07-22 09:05:22 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:22 --> Input Class Initialized
INFO - 2017-07-22 09:05:22 --> Language Class Initialized
INFO - 2017-07-22 09:05:22 --> Loader Class Initialized
INFO - 2017-07-22 09:05:22 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:22 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:23 --> Email Class Initialized
INFO - 2017-07-22 09:05:23 --> Controller Class Initialized
INFO - 2017-07-22 09:05:23 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:23 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:23 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:23 --> Helper loaded: url_helper
INFO - 2017-07-22 12:35:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:35:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:35:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:35:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:35:23 --> Final output sent to browser
DEBUG - 2017-07-22 12:35:23 --> Total execution time: 0.0418
INFO - 2017-07-22 09:05:27 --> Config Class Initialized
INFO - 2017-07-22 09:05:27 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:27 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:27 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:27 --> URI Class Initialized
INFO - 2017-07-22 09:05:27 --> Router Class Initialized
INFO - 2017-07-22 09:05:27 --> Output Class Initialized
INFO - 2017-07-22 09:05:27 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:27 --> Input Class Initialized
INFO - 2017-07-22 09:05:27 --> Language Class Initialized
INFO - 2017-07-22 09:05:27 --> Loader Class Initialized
INFO - 2017-07-22 09:05:27 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:27 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:27 --> Email Class Initialized
INFO - 2017-07-22 09:05:27 --> Controller Class Initialized
INFO - 2017-07-22 09:05:27 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:27 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:27 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:27 --> Helper loaded: url_helper
INFO - 2017-07-22 12:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:35:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:35:27 --> Final output sent to browser
DEBUG - 2017-07-22 12:35:27 --> Total execution time: 0.0451
INFO - 2017-07-22 09:05:30 --> Config Class Initialized
INFO - 2017-07-22 09:05:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:30 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:30 --> URI Class Initialized
INFO - 2017-07-22 09:05:30 --> Router Class Initialized
INFO - 2017-07-22 09:05:30 --> Output Class Initialized
INFO - 2017-07-22 09:05:30 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:30 --> Input Class Initialized
INFO - 2017-07-22 09:05:30 --> Language Class Initialized
INFO - 2017-07-22 09:05:30 --> Loader Class Initialized
INFO - 2017-07-22 09:05:30 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:30 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:30 --> Email Class Initialized
INFO - 2017-07-22 09:05:30 --> Controller Class Initialized
INFO - 2017-07-22 09:05:30 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:30 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:30 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:35:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:35:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:05:31 --> Config Class Initialized
INFO - 2017-07-22 09:05:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:05:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:05:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:05:31 --> URI Class Initialized
INFO - 2017-07-22 09:05:31 --> Router Class Initialized
INFO - 2017-07-22 09:05:31 --> Output Class Initialized
INFO - 2017-07-22 09:05:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:05:31 --> Input Class Initialized
INFO - 2017-07-22 09:05:31 --> Language Class Initialized
INFO - 2017-07-22 09:05:31 --> Loader Class Initialized
INFO - 2017-07-22 09:05:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:05:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:05:31 --> Email Class Initialized
INFO - 2017-07-22 09:05:31 --> Controller Class Initialized
INFO - 2017-07-22 09:05:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:05:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:05:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:05:31 --> Helper loaded: url_helper
INFO - 2017-07-22 12:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:35:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:35:31 --> Final output sent to browser
DEBUG - 2017-07-22 12:35:31 --> Total execution time: 0.0624
INFO - 2017-07-22 09:06:13 --> Config Class Initialized
INFO - 2017-07-22 09:06:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:06:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:06:13 --> Utf8 Class Initialized
INFO - 2017-07-22 09:06:13 --> URI Class Initialized
INFO - 2017-07-22 09:06:13 --> Router Class Initialized
INFO - 2017-07-22 09:06:13 --> Output Class Initialized
INFO - 2017-07-22 09:06:13 --> Security Class Initialized
DEBUG - 2017-07-22 09:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:06:13 --> Input Class Initialized
INFO - 2017-07-22 09:06:13 --> Language Class Initialized
INFO - 2017-07-22 09:06:13 --> Loader Class Initialized
INFO - 2017-07-22 09:06:13 --> Helper loaded: common_helper
INFO - 2017-07-22 09:06:13 --> Database Driver Class Initialized
INFO - 2017-07-22 09:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:06:13 --> Email Class Initialized
INFO - 2017-07-22 09:06:13 --> Controller Class Initialized
INFO - 2017-07-22 09:06:13 --> Helper loaded: form_helper
INFO - 2017-07-22 09:06:13 --> Form Validation Class Initialized
INFO - 2017-07-22 09:06:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:06:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:06:13 --> Helper loaded: url_helper
INFO - 2017-07-22 12:36:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:36:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:36:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:36:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:36:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:36:13 --> Final output sent to browser
DEBUG - 2017-07-22 12:36:13 --> Total execution time: 0.0464
INFO - 2017-07-22 09:06:15 --> Config Class Initialized
INFO - 2017-07-22 09:06:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:06:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:06:15 --> Utf8 Class Initialized
INFO - 2017-07-22 09:06:15 --> URI Class Initialized
INFO - 2017-07-22 09:06:15 --> Router Class Initialized
INFO - 2017-07-22 09:06:15 --> Output Class Initialized
INFO - 2017-07-22 09:06:15 --> Security Class Initialized
DEBUG - 2017-07-22 09:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:06:15 --> Input Class Initialized
INFO - 2017-07-22 09:06:15 --> Language Class Initialized
INFO - 2017-07-22 09:06:15 --> Loader Class Initialized
INFO - 2017-07-22 09:06:15 --> Helper loaded: common_helper
INFO - 2017-07-22 09:06:15 --> Database Driver Class Initialized
INFO - 2017-07-22 09:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:06:15 --> Email Class Initialized
INFO - 2017-07-22 09:06:15 --> Controller Class Initialized
INFO - 2017-07-22 09:06:15 --> Helper loaded: form_helper
INFO - 2017-07-22 09:06:15 --> Form Validation Class Initialized
INFO - 2017-07-22 09:06:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:06:15 --> Helper loaded: url_helper
INFO - 2017-07-22 12:36:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:36:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:36:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:36:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:36:15 --> Final output sent to browser
DEBUG - 2017-07-22 12:36:15 --> Total execution time: 0.0424
INFO - 2017-07-22 09:06:35 --> Config Class Initialized
INFO - 2017-07-22 09:06:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:06:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:06:35 --> Utf8 Class Initialized
INFO - 2017-07-22 09:06:35 --> URI Class Initialized
INFO - 2017-07-22 09:06:35 --> Router Class Initialized
INFO - 2017-07-22 09:06:35 --> Output Class Initialized
INFO - 2017-07-22 09:06:35 --> Security Class Initialized
DEBUG - 2017-07-22 09:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:06:35 --> Input Class Initialized
INFO - 2017-07-22 09:06:35 --> Language Class Initialized
INFO - 2017-07-22 09:06:35 --> Loader Class Initialized
INFO - 2017-07-22 09:06:35 --> Helper loaded: common_helper
INFO - 2017-07-22 09:06:35 --> Database Driver Class Initialized
INFO - 2017-07-22 09:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:06:35 --> Email Class Initialized
INFO - 2017-07-22 09:06:35 --> Controller Class Initialized
INFO - 2017-07-22 09:06:35 --> Helper loaded: form_helper
INFO - 2017-07-22 09:06:35 --> Form Validation Class Initialized
INFO - 2017-07-22 09:06:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:06:35 --> Helper loaded: url_helper
INFO - 2017-07-22 12:36:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:36:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:36:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:36:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:36:35 --> Final output sent to browser
DEBUG - 2017-07-22 12:36:35 --> Total execution time: 0.0462
INFO - 2017-07-22 09:07:00 --> Config Class Initialized
INFO - 2017-07-22 09:07:00 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:07:00 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:07:00 --> Utf8 Class Initialized
INFO - 2017-07-22 09:07:00 --> URI Class Initialized
INFO - 2017-07-22 09:07:00 --> Router Class Initialized
INFO - 2017-07-22 09:07:00 --> Output Class Initialized
INFO - 2017-07-22 09:07:00 --> Security Class Initialized
DEBUG - 2017-07-22 09:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:07:00 --> Input Class Initialized
INFO - 2017-07-22 09:07:00 --> Language Class Initialized
INFO - 2017-07-22 09:07:00 --> Loader Class Initialized
INFO - 2017-07-22 09:07:00 --> Helper loaded: common_helper
INFO - 2017-07-22 09:07:00 --> Database Driver Class Initialized
INFO - 2017-07-22 09:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:07:00 --> Email Class Initialized
INFO - 2017-07-22 09:07:00 --> Controller Class Initialized
INFO - 2017-07-22 09:07:00 --> Helper loaded: form_helper
INFO - 2017-07-22 09:07:00 --> Form Validation Class Initialized
INFO - 2017-07-22 09:07:00 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:07:00 --> Helper loaded: url_helper
INFO - 2017-07-22 12:37:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:37:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 09:07:50 --> Config Class Initialized
INFO - 2017-07-22 09:07:50 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:07:50 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:07:50 --> Utf8 Class Initialized
INFO - 2017-07-22 09:07:50 --> URI Class Initialized
INFO - 2017-07-22 09:07:50 --> Router Class Initialized
INFO - 2017-07-22 09:07:50 --> Output Class Initialized
INFO - 2017-07-22 09:07:50 --> Security Class Initialized
DEBUG - 2017-07-22 09:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:07:50 --> Input Class Initialized
INFO - 2017-07-22 09:07:50 --> Language Class Initialized
INFO - 2017-07-22 09:07:50 --> Loader Class Initialized
INFO - 2017-07-22 09:07:50 --> Helper loaded: common_helper
INFO - 2017-07-22 09:07:50 --> Database Driver Class Initialized
INFO - 2017-07-22 09:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:07:50 --> Email Class Initialized
INFO - 2017-07-22 09:07:50 --> Controller Class Initialized
INFO - 2017-07-22 09:07:50 --> Helper loaded: form_helper
INFO - 2017-07-22 09:07:50 --> Form Validation Class Initialized
INFO - 2017-07-22 09:07:50 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:07:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:07:50 --> Helper loaded: url_helper
INFO - 2017-07-22 12:37:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:37:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:37:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:37:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:37:50 --> Final output sent to browser
DEBUG - 2017-07-22 12:37:50 --> Total execution time: 0.0457
INFO - 2017-07-22 09:08:19 --> Config Class Initialized
INFO - 2017-07-22 09:08:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:08:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:08:19 --> Utf8 Class Initialized
INFO - 2017-07-22 09:08:19 --> URI Class Initialized
INFO - 2017-07-22 09:08:19 --> Router Class Initialized
INFO - 2017-07-22 09:08:19 --> Output Class Initialized
INFO - 2017-07-22 09:08:19 --> Security Class Initialized
DEBUG - 2017-07-22 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:08:19 --> Input Class Initialized
INFO - 2017-07-22 09:08:20 --> Language Class Initialized
INFO - 2017-07-22 09:08:20 --> Loader Class Initialized
INFO - 2017-07-22 09:08:20 --> Helper loaded: common_helper
INFO - 2017-07-22 09:08:20 --> Database Driver Class Initialized
INFO - 2017-07-22 09:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:08:20 --> Email Class Initialized
INFO - 2017-07-22 09:08:20 --> Controller Class Initialized
INFO - 2017-07-22 09:08:20 --> Helper loaded: form_helper
INFO - 2017-07-22 09:08:20 --> Form Validation Class Initialized
INFO - 2017-07-22 09:08:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:08:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:08:20 --> Helper loaded: url_helper
INFO - 2017-07-22 12:38:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:38:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:38:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:38:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:38:20 --> Final output sent to browser
DEBUG - 2017-07-22 12:38:20 --> Total execution time: 0.0485
INFO - 2017-07-22 09:08:32 --> Config Class Initialized
INFO - 2017-07-22 09:08:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:08:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:08:32 --> Utf8 Class Initialized
INFO - 2017-07-22 09:08:32 --> URI Class Initialized
INFO - 2017-07-22 09:08:32 --> Router Class Initialized
INFO - 2017-07-22 09:08:32 --> Output Class Initialized
INFO - 2017-07-22 09:08:32 --> Security Class Initialized
DEBUG - 2017-07-22 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:08:32 --> Input Class Initialized
INFO - 2017-07-22 09:08:32 --> Language Class Initialized
INFO - 2017-07-22 09:08:32 --> Loader Class Initialized
INFO - 2017-07-22 09:08:32 --> Helper loaded: common_helper
INFO - 2017-07-22 09:08:32 --> Database Driver Class Initialized
INFO - 2017-07-22 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:08:32 --> Email Class Initialized
INFO - 2017-07-22 09:08:32 --> Controller Class Initialized
INFO - 2017-07-22 09:08:32 --> Helper loaded: form_helper
INFO - 2017-07-22 09:08:32 --> Form Validation Class Initialized
INFO - 2017-07-22 09:08:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:08:32 --> Helper loaded: url_helper
INFO - 2017-07-22 12:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:38:32 --> Final output sent to browser
DEBUG - 2017-07-22 12:38:32 --> Total execution time: 0.0795
INFO - 2017-07-22 09:08:37 --> Config Class Initialized
INFO - 2017-07-22 09:08:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:08:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:08:37 --> Utf8 Class Initialized
INFO - 2017-07-22 09:08:37 --> URI Class Initialized
INFO - 2017-07-22 09:08:37 --> Router Class Initialized
INFO - 2017-07-22 09:08:37 --> Output Class Initialized
INFO - 2017-07-22 09:08:37 --> Security Class Initialized
DEBUG - 2017-07-22 09:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:08:37 --> Input Class Initialized
INFO - 2017-07-22 09:08:37 --> Language Class Initialized
INFO - 2017-07-22 09:08:37 --> Loader Class Initialized
INFO - 2017-07-22 09:08:37 --> Helper loaded: common_helper
INFO - 2017-07-22 09:08:37 --> Database Driver Class Initialized
INFO - 2017-07-22 09:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:08:37 --> Email Class Initialized
INFO - 2017-07-22 09:08:37 --> Controller Class Initialized
INFO - 2017-07-22 09:08:37 --> Helper loaded: form_helper
INFO - 2017-07-22 09:08:37 --> Form Validation Class Initialized
INFO - 2017-07-22 09:08:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:08:37 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:38:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:38:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:08:37 --> Config Class Initialized
INFO - 2017-07-22 09:08:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:08:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:08:37 --> Utf8 Class Initialized
INFO - 2017-07-22 09:08:37 --> URI Class Initialized
INFO - 2017-07-22 09:08:37 --> Router Class Initialized
INFO - 2017-07-22 09:08:37 --> Output Class Initialized
INFO - 2017-07-22 09:08:37 --> Security Class Initialized
DEBUG - 2017-07-22 09:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:08:37 --> Input Class Initialized
INFO - 2017-07-22 09:08:37 --> Language Class Initialized
INFO - 2017-07-22 09:08:37 --> Loader Class Initialized
INFO - 2017-07-22 09:08:37 --> Helper loaded: common_helper
INFO - 2017-07-22 09:08:37 --> Database Driver Class Initialized
INFO - 2017-07-22 09:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:08:37 --> Email Class Initialized
INFO - 2017-07-22 09:08:37 --> Controller Class Initialized
INFO - 2017-07-22 09:08:37 --> Helper loaded: form_helper
INFO - 2017-07-22 09:08:37 --> Form Validation Class Initialized
INFO - 2017-07-22 09:08:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:08:37 --> Helper loaded: url_helper
INFO - 2017-07-22 12:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:38:37 --> Final output sent to browser
DEBUG - 2017-07-22 12:38:37 --> Total execution time: 0.1058
INFO - 2017-07-22 09:08:41 --> Config Class Initialized
INFO - 2017-07-22 09:08:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:08:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:08:41 --> Utf8 Class Initialized
INFO - 2017-07-22 09:08:41 --> URI Class Initialized
INFO - 2017-07-22 09:08:41 --> Router Class Initialized
INFO - 2017-07-22 09:08:41 --> Output Class Initialized
INFO - 2017-07-22 09:08:41 --> Security Class Initialized
DEBUG - 2017-07-22 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:08:41 --> Input Class Initialized
INFO - 2017-07-22 09:08:41 --> Language Class Initialized
INFO - 2017-07-22 09:08:41 --> Loader Class Initialized
INFO - 2017-07-22 09:08:41 --> Helper loaded: common_helper
INFO - 2017-07-22 09:08:41 --> Database Driver Class Initialized
INFO - 2017-07-22 09:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:08:41 --> Email Class Initialized
INFO - 2017-07-22 09:08:41 --> Controller Class Initialized
INFO - 2017-07-22 09:08:41 --> Helper loaded: form_helper
INFO - 2017-07-22 09:08:41 --> Form Validation Class Initialized
INFO - 2017-07-22 09:08:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:08:41 --> Helper loaded: url_helper
INFO - 2017-07-22 12:38:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:38:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:38:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:38:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:38:41 --> Final output sent to browser
DEBUG - 2017-07-22 12:38:41 --> Total execution time: 0.0426
INFO - 2017-07-22 09:09:35 --> Config Class Initialized
INFO - 2017-07-22 09:09:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:09:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:09:35 --> Utf8 Class Initialized
INFO - 2017-07-22 09:09:35 --> URI Class Initialized
INFO - 2017-07-22 09:09:35 --> Router Class Initialized
INFO - 2017-07-22 09:09:35 --> Output Class Initialized
INFO - 2017-07-22 09:09:35 --> Security Class Initialized
DEBUG - 2017-07-22 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:09:35 --> Input Class Initialized
INFO - 2017-07-22 09:09:35 --> Language Class Initialized
INFO - 2017-07-22 09:09:35 --> Loader Class Initialized
INFO - 2017-07-22 09:09:35 --> Helper loaded: common_helper
INFO - 2017-07-22 09:09:35 --> Database Driver Class Initialized
INFO - 2017-07-22 09:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:09:35 --> Email Class Initialized
INFO - 2017-07-22 09:09:35 --> Controller Class Initialized
INFO - 2017-07-22 09:09:35 --> Helper loaded: form_helper
INFO - 2017-07-22 09:09:35 --> Form Validation Class Initialized
INFO - 2017-07-22 09:09:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:09:35 --> Helper loaded: url_helper
INFO - 2017-07-22 12:39:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:39:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:39:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:39:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:39:35 --> Final output sent to browser
DEBUG - 2017-07-22 12:39:35 --> Total execution time: 0.0446
INFO - 2017-07-22 09:12:25 --> Config Class Initialized
INFO - 2017-07-22 09:12:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:12:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:12:25 --> Utf8 Class Initialized
INFO - 2017-07-22 09:12:25 --> URI Class Initialized
INFO - 2017-07-22 09:12:25 --> Router Class Initialized
INFO - 2017-07-22 09:12:25 --> Output Class Initialized
INFO - 2017-07-22 09:12:25 --> Security Class Initialized
DEBUG - 2017-07-22 09:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:12:25 --> Input Class Initialized
INFO - 2017-07-22 09:12:25 --> Language Class Initialized
INFO - 2017-07-22 09:12:25 --> Loader Class Initialized
INFO - 2017-07-22 09:12:25 --> Helper loaded: common_helper
INFO - 2017-07-22 09:12:25 --> Database Driver Class Initialized
INFO - 2017-07-22 09:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:12:25 --> Email Class Initialized
INFO - 2017-07-22 09:12:25 --> Controller Class Initialized
INFO - 2017-07-22 09:12:25 --> Helper loaded: form_helper
INFO - 2017-07-22 09:12:25 --> Form Validation Class Initialized
INFO - 2017-07-22 09:12:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:12:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:12:25 --> Helper loaded: url_helper
INFO - 2017-07-22 12:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:42:25 --> Final output sent to browser
DEBUG - 2017-07-22 12:42:25 --> Total execution time: 0.0465
INFO - 2017-07-22 09:12:28 --> Config Class Initialized
INFO - 2017-07-22 09:12:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:12:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:12:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:12:28 --> URI Class Initialized
INFO - 2017-07-22 09:12:28 --> Router Class Initialized
INFO - 2017-07-22 09:12:28 --> Output Class Initialized
INFO - 2017-07-22 09:12:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:12:28 --> Input Class Initialized
INFO - 2017-07-22 09:12:28 --> Language Class Initialized
INFO - 2017-07-22 09:12:28 --> Loader Class Initialized
INFO - 2017-07-22 09:12:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:12:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:12:28 --> Email Class Initialized
INFO - 2017-07-22 09:12:28 --> Controller Class Initialized
INFO - 2017-07-22 09:12:28 --> Helper loaded: form_helper
INFO - 2017-07-22 09:12:28 --> Form Validation Class Initialized
INFO - 2017-07-22 09:12:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:12:28 --> Helper loaded: url_helper
INFO - 2017-07-22 12:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:42:28 --> Final output sent to browser
DEBUG - 2017-07-22 12:42:28 --> Total execution time: 0.0450
INFO - 2017-07-22 09:12:30 --> Config Class Initialized
INFO - 2017-07-22 09:12:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:12:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:12:30 --> Utf8 Class Initialized
INFO - 2017-07-22 09:12:30 --> URI Class Initialized
INFO - 2017-07-22 09:12:30 --> Router Class Initialized
INFO - 2017-07-22 09:12:30 --> Output Class Initialized
INFO - 2017-07-22 09:12:30 --> Security Class Initialized
DEBUG - 2017-07-22 09:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:12:30 --> Input Class Initialized
INFO - 2017-07-22 09:12:30 --> Language Class Initialized
INFO - 2017-07-22 09:12:30 --> Loader Class Initialized
INFO - 2017-07-22 09:12:30 --> Helper loaded: common_helper
INFO - 2017-07-22 09:12:30 --> Database Driver Class Initialized
INFO - 2017-07-22 09:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:12:30 --> Email Class Initialized
INFO - 2017-07-22 09:12:30 --> Controller Class Initialized
INFO - 2017-07-22 09:12:30 --> Helper loaded: form_helper
INFO - 2017-07-22 09:12:30 --> Form Validation Class Initialized
INFO - 2017-07-22 09:12:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:12:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:12:30 --> Helper loaded: url_helper
INFO - 2017-07-22 12:42:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:42:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:42:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:42:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:42:30 --> Final output sent to browser
DEBUG - 2017-07-22 12:42:30 --> Total execution time: 0.0424
INFO - 2017-07-22 09:12:40 --> Config Class Initialized
INFO - 2017-07-22 09:12:40 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:12:40 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:12:40 --> Utf8 Class Initialized
INFO - 2017-07-22 09:12:40 --> URI Class Initialized
INFO - 2017-07-22 09:12:40 --> Router Class Initialized
INFO - 2017-07-22 09:12:40 --> Output Class Initialized
INFO - 2017-07-22 09:12:40 --> Security Class Initialized
DEBUG - 2017-07-22 09:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:12:40 --> Input Class Initialized
INFO - 2017-07-22 09:12:40 --> Language Class Initialized
INFO - 2017-07-22 09:12:40 --> Loader Class Initialized
INFO - 2017-07-22 09:12:40 --> Helper loaded: common_helper
INFO - 2017-07-22 09:12:40 --> Database Driver Class Initialized
INFO - 2017-07-22 09:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:12:40 --> Email Class Initialized
INFO - 2017-07-22 09:12:40 --> Controller Class Initialized
INFO - 2017-07-22 09:12:40 --> Helper loaded: form_helper
INFO - 2017-07-22 09:12:40 --> Form Validation Class Initialized
INFO - 2017-07-22 09:12:40 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:12:40 --> Helper loaded: url_helper
INFO - 2017-07-22 12:42:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:42:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:42:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:42:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:42:40 --> Final output sent to browser
DEBUG - 2017-07-22 12:42:40 --> Total execution time: 0.0462
INFO - 2017-07-22 09:12:51 --> Config Class Initialized
INFO - 2017-07-22 09:12:51 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:12:51 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:12:51 --> Utf8 Class Initialized
INFO - 2017-07-22 09:12:51 --> URI Class Initialized
INFO - 2017-07-22 09:12:51 --> Router Class Initialized
INFO - 2017-07-22 09:12:51 --> Output Class Initialized
INFO - 2017-07-22 09:12:51 --> Security Class Initialized
DEBUG - 2017-07-22 09:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:12:51 --> Input Class Initialized
INFO - 2017-07-22 09:12:51 --> Language Class Initialized
INFO - 2017-07-22 09:12:51 --> Loader Class Initialized
INFO - 2017-07-22 09:12:51 --> Helper loaded: common_helper
INFO - 2017-07-22 09:12:51 --> Database Driver Class Initialized
INFO - 2017-07-22 09:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:12:51 --> Email Class Initialized
INFO - 2017-07-22 09:12:51 --> Controller Class Initialized
INFO - 2017-07-22 09:12:51 --> Helper loaded: form_helper
INFO - 2017-07-22 09:12:51 --> Form Validation Class Initialized
INFO - 2017-07-22 09:12:51 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:12:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:12:51 --> Helper loaded: url_helper
INFO - 2017-07-22 12:42:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-07-22 12:42:51 --> syntax error, unexpected '}', expecting ',' or ';'
ERROR - 2017-07-22 12:42:51 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 09:13:06 --> Config Class Initialized
INFO - 2017-07-22 09:13:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:13:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:13:06 --> Utf8 Class Initialized
INFO - 2017-07-22 09:13:06 --> URI Class Initialized
INFO - 2017-07-22 09:13:06 --> Router Class Initialized
INFO - 2017-07-22 09:13:06 --> Output Class Initialized
INFO - 2017-07-22 09:13:06 --> Security Class Initialized
DEBUG - 2017-07-22 09:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:13:06 --> Input Class Initialized
INFO - 2017-07-22 09:13:06 --> Language Class Initialized
INFO - 2017-07-22 09:13:06 --> Loader Class Initialized
INFO - 2017-07-22 09:13:06 --> Helper loaded: common_helper
INFO - 2017-07-22 09:13:06 --> Database Driver Class Initialized
INFO - 2017-07-22 09:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:13:06 --> Email Class Initialized
INFO - 2017-07-22 09:13:06 --> Controller Class Initialized
INFO - 2017-07-22 09:13:06 --> Helper loaded: form_helper
INFO - 2017-07-22 09:13:06 --> Form Validation Class Initialized
INFO - 2017-07-22 09:13:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:13:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:13:06 --> Helper loaded: url_helper
INFO - 2017-07-22 12:43:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:43:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:43:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:43:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:43:06 --> Final output sent to browser
DEBUG - 2017-07-22 12:43:06 --> Total execution time: 0.0430
INFO - 2017-07-22 09:13:31 --> Config Class Initialized
INFO - 2017-07-22 09:13:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:13:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:13:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:13:31 --> URI Class Initialized
INFO - 2017-07-22 09:13:31 --> Router Class Initialized
INFO - 2017-07-22 09:13:31 --> Output Class Initialized
INFO - 2017-07-22 09:13:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:13:31 --> Input Class Initialized
INFO - 2017-07-22 09:13:31 --> Language Class Initialized
INFO - 2017-07-22 09:13:31 --> Loader Class Initialized
INFO - 2017-07-22 09:13:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:13:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:13:31 --> Email Class Initialized
INFO - 2017-07-22 09:13:31 --> Controller Class Initialized
INFO - 2017-07-22 09:13:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:13:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:13:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:13:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:13:31 --> Helper loaded: url_helper
INFO - 2017-07-22 12:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:43:31 --> Final output sent to browser
DEBUG - 2017-07-22 12:43:31 --> Total execution time: 0.0441
INFO - 2017-07-22 09:13:33 --> Config Class Initialized
INFO - 2017-07-22 09:13:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:13:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:13:33 --> Utf8 Class Initialized
INFO - 2017-07-22 09:13:33 --> URI Class Initialized
INFO - 2017-07-22 09:13:33 --> Router Class Initialized
INFO - 2017-07-22 09:13:33 --> Output Class Initialized
INFO - 2017-07-22 09:13:33 --> Security Class Initialized
DEBUG - 2017-07-22 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:13:33 --> Input Class Initialized
INFO - 2017-07-22 09:13:33 --> Language Class Initialized
INFO - 2017-07-22 09:13:33 --> Loader Class Initialized
INFO - 2017-07-22 09:13:33 --> Helper loaded: common_helper
INFO - 2017-07-22 09:13:33 --> Database Driver Class Initialized
INFO - 2017-07-22 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:13:33 --> Email Class Initialized
INFO - 2017-07-22 09:13:33 --> Controller Class Initialized
INFO - 2017-07-22 09:13:33 --> Helper loaded: form_helper
INFO - 2017-07-22 09:13:33 --> Form Validation Class Initialized
INFO - 2017-07-22 09:13:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:13:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:13:33 --> Helper loaded: url_helper
INFO - 2017-07-22 12:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:43:33 --> Final output sent to browser
DEBUG - 2017-07-22 12:43:33 --> Total execution time: 0.0552
INFO - 2017-07-22 09:14:20 --> Config Class Initialized
INFO - 2017-07-22 09:14:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:14:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:14:20 --> Utf8 Class Initialized
INFO - 2017-07-22 09:14:20 --> URI Class Initialized
INFO - 2017-07-22 09:14:20 --> Router Class Initialized
INFO - 2017-07-22 09:14:20 --> Output Class Initialized
INFO - 2017-07-22 09:14:20 --> Security Class Initialized
DEBUG - 2017-07-22 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:14:20 --> Input Class Initialized
INFO - 2017-07-22 09:14:20 --> Language Class Initialized
INFO - 2017-07-22 09:14:20 --> Loader Class Initialized
INFO - 2017-07-22 09:14:20 --> Helper loaded: common_helper
INFO - 2017-07-22 09:14:20 --> Database Driver Class Initialized
INFO - 2017-07-22 09:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:14:20 --> Email Class Initialized
INFO - 2017-07-22 09:14:20 --> Controller Class Initialized
INFO - 2017-07-22 09:14:20 --> Helper loaded: form_helper
INFO - 2017-07-22 09:14:20 --> Form Validation Class Initialized
INFO - 2017-07-22 09:14:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:14:20 --> Helper loaded: url_helper
INFO - 2017-07-22 12:44:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:44:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:44:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:44:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:44:20 --> Final output sent to browser
DEBUG - 2017-07-22 12:44:20 --> Total execution time: 0.0442
INFO - 2017-07-22 09:14:34 --> Config Class Initialized
INFO - 2017-07-22 09:14:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:14:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:14:34 --> Utf8 Class Initialized
INFO - 2017-07-22 09:14:34 --> URI Class Initialized
INFO - 2017-07-22 09:14:34 --> Router Class Initialized
INFO - 2017-07-22 09:14:34 --> Output Class Initialized
INFO - 2017-07-22 09:14:34 --> Security Class Initialized
DEBUG - 2017-07-22 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:14:34 --> Input Class Initialized
INFO - 2017-07-22 09:14:34 --> Language Class Initialized
INFO - 2017-07-22 09:14:34 --> Loader Class Initialized
INFO - 2017-07-22 09:14:34 --> Helper loaded: common_helper
INFO - 2017-07-22 09:14:34 --> Database Driver Class Initialized
INFO - 2017-07-22 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:14:34 --> Email Class Initialized
INFO - 2017-07-22 09:14:34 --> Controller Class Initialized
INFO - 2017-07-22 09:14:34 --> Helper loaded: form_helper
INFO - 2017-07-22 09:14:34 --> Form Validation Class Initialized
INFO - 2017-07-22 09:14:34 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:14:34 --> Helper loaded: url_helper
INFO - 2017-07-22 12:44:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:44:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:44:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:44:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:44:34 --> Final output sent to browser
DEBUG - 2017-07-22 12:44:34 --> Total execution time: 0.0437
INFO - 2017-07-22 09:14:47 --> Config Class Initialized
INFO - 2017-07-22 09:14:47 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:14:47 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:14:47 --> Utf8 Class Initialized
INFO - 2017-07-22 09:14:47 --> URI Class Initialized
INFO - 2017-07-22 09:14:47 --> Router Class Initialized
INFO - 2017-07-22 09:14:47 --> Output Class Initialized
INFO - 2017-07-22 09:14:47 --> Security Class Initialized
DEBUG - 2017-07-22 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:14:47 --> Input Class Initialized
INFO - 2017-07-22 09:14:47 --> Language Class Initialized
INFO - 2017-07-22 09:14:47 --> Loader Class Initialized
INFO - 2017-07-22 09:14:47 --> Helper loaded: common_helper
INFO - 2017-07-22 09:14:47 --> Database Driver Class Initialized
INFO - 2017-07-22 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:14:47 --> Email Class Initialized
INFO - 2017-07-22 09:14:47 --> Controller Class Initialized
INFO - 2017-07-22 09:14:47 --> Helper loaded: form_helper
INFO - 2017-07-22 09:14:47 --> Form Validation Class Initialized
INFO - 2017-07-22 09:14:47 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:14:47 --> Helper loaded: url_helper
INFO - 2017-07-22 12:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:44:47 --> Final output sent to browser
DEBUG - 2017-07-22 12:44:47 --> Total execution time: 0.0450
INFO - 2017-07-22 09:15:15 --> Config Class Initialized
INFO - 2017-07-22 09:15:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:15 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:15 --> URI Class Initialized
INFO - 2017-07-22 09:15:15 --> Router Class Initialized
INFO - 2017-07-22 09:15:15 --> Output Class Initialized
INFO - 2017-07-22 09:15:15 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:15 --> Input Class Initialized
INFO - 2017-07-22 09:15:15 --> Language Class Initialized
INFO - 2017-07-22 09:15:15 --> Loader Class Initialized
INFO - 2017-07-22 09:15:15 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:15 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:15 --> Email Class Initialized
INFO - 2017-07-22 09:15:15 --> Controller Class Initialized
INFO - 2017-07-22 09:15:15 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:15 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:15 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:15 --> Undefined variable: details
ERROR - 2017-07-22 12:45:15 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:15 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:15 --> Total execution time: 0.0452
INFO - 2017-07-22 09:15:28 --> Config Class Initialized
INFO - 2017-07-22 09:15:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:28 --> URI Class Initialized
INFO - 2017-07-22 09:15:28 --> Router Class Initialized
INFO - 2017-07-22 09:15:28 --> Output Class Initialized
INFO - 2017-07-22 09:15:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:28 --> Input Class Initialized
INFO - 2017-07-22 09:15:28 --> Language Class Initialized
INFO - 2017-07-22 09:15:28 --> Loader Class Initialized
INFO - 2017-07-22 09:15:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:28 --> Email Class Initialized
INFO - 2017-07-22 09:15:28 --> Controller Class Initialized
INFO - 2017-07-22 09:15:28 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:28 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:28 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:28 --> Undefined variable: details
ERROR - 2017-07-22 12:45:28 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:28 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:28 --> Total execution time: 0.0460
INFO - 2017-07-22 09:15:28 --> Config Class Initialized
INFO - 2017-07-22 09:15:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:28 --> URI Class Initialized
INFO - 2017-07-22 09:15:28 --> Router Class Initialized
INFO - 2017-07-22 09:15:28 --> Output Class Initialized
INFO - 2017-07-22 09:15:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:28 --> Input Class Initialized
INFO - 2017-07-22 09:15:28 --> Language Class Initialized
INFO - 2017-07-22 09:15:28 --> Loader Class Initialized
INFO - 2017-07-22 09:15:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:28 --> Email Class Initialized
INFO - 2017-07-22 09:15:28 --> Controller Class Initialized
INFO - 2017-07-22 09:15:28 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:28 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:28 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:28 --> Undefined variable: details
ERROR - 2017-07-22 12:45:28 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:28 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:28 --> Total execution time: 0.0460
INFO - 2017-07-22 09:15:29 --> Config Class Initialized
INFO - 2017-07-22 09:15:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:29 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:29 --> URI Class Initialized
INFO - 2017-07-22 09:15:29 --> Router Class Initialized
INFO - 2017-07-22 09:15:29 --> Output Class Initialized
INFO - 2017-07-22 09:15:29 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:29 --> Input Class Initialized
INFO - 2017-07-22 09:15:29 --> Language Class Initialized
INFO - 2017-07-22 09:15:29 --> Loader Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:29 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:29 --> Email Class Initialized
INFO - 2017-07-22 09:15:29 --> Controller Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:29 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:29 --> Undefined variable: details
ERROR - 2017-07-22 12:45:29 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:29 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:29 --> Total execution time: 0.0469
INFO - 2017-07-22 09:15:29 --> Config Class Initialized
INFO - 2017-07-22 09:15:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:29 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:29 --> URI Class Initialized
INFO - 2017-07-22 09:15:29 --> Router Class Initialized
INFO - 2017-07-22 09:15:29 --> Output Class Initialized
INFO - 2017-07-22 09:15:29 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:29 --> Input Class Initialized
INFO - 2017-07-22 09:15:29 --> Language Class Initialized
INFO - 2017-07-22 09:15:29 --> Loader Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:29 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:29 --> Email Class Initialized
INFO - 2017-07-22 09:15:29 --> Controller Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:29 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:29 --> Undefined variable: details
ERROR - 2017-07-22 12:45:29 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:29 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:29 --> Total execution time: 0.0500
INFO - 2017-07-22 09:15:29 --> Config Class Initialized
INFO - 2017-07-22 09:15:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:29 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:29 --> URI Class Initialized
INFO - 2017-07-22 09:15:29 --> Router Class Initialized
INFO - 2017-07-22 09:15:29 --> Output Class Initialized
INFO - 2017-07-22 09:15:29 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:29 --> Input Class Initialized
INFO - 2017-07-22 09:15:29 --> Language Class Initialized
INFO - 2017-07-22 09:15:29 --> Loader Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:29 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:29 --> Email Class Initialized
INFO - 2017-07-22 09:15:29 --> Controller Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:29 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:29 --> Undefined variable: details
ERROR - 2017-07-22 12:45:29 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:29 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:29 --> Total execution time: 0.0508
INFO - 2017-07-22 09:15:29 --> Config Class Initialized
INFO - 2017-07-22 09:15:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:29 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:29 --> URI Class Initialized
INFO - 2017-07-22 09:15:29 --> Router Class Initialized
INFO - 2017-07-22 09:15:29 --> Output Class Initialized
INFO - 2017-07-22 09:15:29 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:29 --> Input Class Initialized
INFO - 2017-07-22 09:15:29 --> Language Class Initialized
INFO - 2017-07-22 09:15:29 --> Loader Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:29 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:29 --> Email Class Initialized
INFO - 2017-07-22 09:15:29 --> Controller Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:29 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 12:45:29 --> Undefined variable: details
ERROR - 2017-07-22 12:45:29 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions\addSubscription.php 76
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:29 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:29 --> Total execution time: 0.0479
INFO - 2017-07-22 09:15:34 --> Config Class Initialized
INFO - 2017-07-22 09:15:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:34 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:34 --> URI Class Initialized
INFO - 2017-07-22 09:15:34 --> Router Class Initialized
INFO - 2017-07-22 09:15:34 --> Output Class Initialized
INFO - 2017-07-22 09:15:34 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:34 --> Input Class Initialized
INFO - 2017-07-22 09:15:34 --> Language Class Initialized
INFO - 2017-07-22 09:15:34 --> Loader Class Initialized
INFO - 2017-07-22 09:15:34 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:34 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:34 --> Email Class Initialized
INFO - 2017-07-22 09:15:34 --> Controller Class Initialized
INFO - 2017-07-22 09:15:34 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:34 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:34 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:34 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:45:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:34 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:34 --> Total execution time: 0.0445
INFO - 2017-07-22 09:15:47 --> Config Class Initialized
INFO - 2017-07-22 09:15:47 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:15:47 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:15:47 --> Utf8 Class Initialized
INFO - 2017-07-22 09:15:47 --> URI Class Initialized
INFO - 2017-07-22 09:15:47 --> Router Class Initialized
INFO - 2017-07-22 09:15:47 --> Output Class Initialized
INFO - 2017-07-22 09:15:47 --> Security Class Initialized
DEBUG - 2017-07-22 09:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:15:47 --> Input Class Initialized
INFO - 2017-07-22 09:15:47 --> Language Class Initialized
INFO - 2017-07-22 09:15:47 --> Loader Class Initialized
INFO - 2017-07-22 09:15:47 --> Helper loaded: common_helper
INFO - 2017-07-22 09:15:47 --> Database Driver Class Initialized
INFO - 2017-07-22 09:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:15:47 --> Email Class Initialized
INFO - 2017-07-22 09:15:47 --> Controller Class Initialized
INFO - 2017-07-22 09:15:47 --> Helper loaded: form_helper
INFO - 2017-07-22 09:15:47 --> Form Validation Class Initialized
INFO - 2017-07-22 09:15:47 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:15:47 --> Helper loaded: url_helper
INFO - 2017-07-22 12:45:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:45:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:45:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:45:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:45:47 --> Final output sent to browser
DEBUG - 2017-07-22 12:45:47 --> Total execution time: 0.0432
INFO - 2017-07-22 09:16:33 --> Config Class Initialized
INFO - 2017-07-22 09:16:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:16:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:16:33 --> Utf8 Class Initialized
INFO - 2017-07-22 09:16:33 --> URI Class Initialized
INFO - 2017-07-22 09:16:33 --> Router Class Initialized
INFO - 2017-07-22 09:16:33 --> Output Class Initialized
INFO - 2017-07-22 09:16:33 --> Security Class Initialized
DEBUG - 2017-07-22 09:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:16:33 --> Input Class Initialized
INFO - 2017-07-22 09:16:33 --> Language Class Initialized
INFO - 2017-07-22 09:16:33 --> Loader Class Initialized
INFO - 2017-07-22 09:16:33 --> Helper loaded: common_helper
INFO - 2017-07-22 09:16:33 --> Database Driver Class Initialized
INFO - 2017-07-22 09:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:16:33 --> Email Class Initialized
INFO - 2017-07-22 09:16:33 --> Controller Class Initialized
INFO - 2017-07-22 09:16:33 --> Helper loaded: form_helper
INFO - 2017-07-22 09:16:33 --> Form Validation Class Initialized
INFO - 2017-07-22 09:16:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:16:33 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:46:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:46:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:16:33 --> Config Class Initialized
INFO - 2017-07-22 09:16:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:16:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:16:33 --> Utf8 Class Initialized
INFO - 2017-07-22 09:16:33 --> URI Class Initialized
INFO - 2017-07-22 09:16:33 --> Router Class Initialized
INFO - 2017-07-22 09:16:33 --> Output Class Initialized
INFO - 2017-07-22 09:16:33 --> Security Class Initialized
DEBUG - 2017-07-22 09:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:16:33 --> Input Class Initialized
INFO - 2017-07-22 09:16:33 --> Language Class Initialized
INFO - 2017-07-22 09:16:33 --> Loader Class Initialized
INFO - 2017-07-22 09:16:33 --> Helper loaded: common_helper
INFO - 2017-07-22 09:16:33 --> Database Driver Class Initialized
INFO - 2017-07-22 09:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:16:33 --> Email Class Initialized
INFO - 2017-07-22 09:16:33 --> Controller Class Initialized
INFO - 2017-07-22 09:16:33 --> Helper loaded: form_helper
INFO - 2017-07-22 09:16:33 --> Form Validation Class Initialized
INFO - 2017-07-22 09:16:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:16:33 --> Helper loaded: url_helper
INFO - 2017-07-22 12:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:46:33 --> Final output sent to browser
DEBUG - 2017-07-22 12:46:33 --> Total execution time: 0.0570
INFO - 2017-07-22 09:16:37 --> Config Class Initialized
INFO - 2017-07-22 09:16:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:16:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:16:37 --> Utf8 Class Initialized
INFO - 2017-07-22 09:16:37 --> URI Class Initialized
INFO - 2017-07-22 09:16:37 --> Router Class Initialized
INFO - 2017-07-22 09:16:37 --> Output Class Initialized
INFO - 2017-07-22 09:16:37 --> Security Class Initialized
DEBUG - 2017-07-22 09:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:16:37 --> Input Class Initialized
INFO - 2017-07-22 09:16:37 --> Language Class Initialized
INFO - 2017-07-22 09:16:37 --> Loader Class Initialized
INFO - 2017-07-22 09:16:37 --> Helper loaded: common_helper
INFO - 2017-07-22 09:16:37 --> Database Driver Class Initialized
INFO - 2017-07-22 09:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:16:37 --> Email Class Initialized
INFO - 2017-07-22 09:16:37 --> Controller Class Initialized
INFO - 2017-07-22 09:16:37 --> Helper loaded: form_helper
INFO - 2017-07-22 09:16:37 --> Form Validation Class Initialized
INFO - 2017-07-22 09:16:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:16:37 --> Helper loaded: url_helper
INFO - 2017-07-22 12:46:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:46:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:46:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:46:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:46:37 --> Final output sent to browser
DEBUG - 2017-07-22 12:46:37 --> Total execution time: 0.0426
INFO - 2017-07-22 09:16:48 --> Config Class Initialized
INFO - 2017-07-22 09:16:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:16:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:16:48 --> Utf8 Class Initialized
INFO - 2017-07-22 09:16:48 --> URI Class Initialized
INFO - 2017-07-22 09:16:48 --> Router Class Initialized
INFO - 2017-07-22 09:16:48 --> Output Class Initialized
INFO - 2017-07-22 09:16:48 --> Security Class Initialized
DEBUG - 2017-07-22 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:16:48 --> Input Class Initialized
INFO - 2017-07-22 09:16:48 --> Language Class Initialized
INFO - 2017-07-22 09:16:48 --> Loader Class Initialized
INFO - 2017-07-22 09:16:48 --> Helper loaded: common_helper
INFO - 2017-07-22 09:16:48 --> Database Driver Class Initialized
INFO - 2017-07-22 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:16:48 --> Email Class Initialized
INFO - 2017-07-22 09:16:48 --> Controller Class Initialized
INFO - 2017-07-22 09:16:48 --> Helper loaded: form_helper
INFO - 2017-07-22 09:16:48 --> Form Validation Class Initialized
INFO - 2017-07-22 09:16:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:16:48 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:46:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:46:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:16:48 --> Config Class Initialized
INFO - 2017-07-22 09:16:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:16:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:16:48 --> Utf8 Class Initialized
INFO - 2017-07-22 09:16:48 --> URI Class Initialized
INFO - 2017-07-22 09:16:48 --> Router Class Initialized
INFO - 2017-07-22 09:16:48 --> Output Class Initialized
INFO - 2017-07-22 09:16:48 --> Security Class Initialized
DEBUG - 2017-07-22 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:16:48 --> Input Class Initialized
INFO - 2017-07-22 09:16:48 --> Language Class Initialized
INFO - 2017-07-22 09:16:48 --> Loader Class Initialized
INFO - 2017-07-22 09:16:48 --> Helper loaded: common_helper
INFO - 2017-07-22 09:16:48 --> Database Driver Class Initialized
INFO - 2017-07-22 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:16:48 --> Email Class Initialized
INFO - 2017-07-22 09:16:48 --> Controller Class Initialized
INFO - 2017-07-22 09:16:48 --> Helper loaded: form_helper
INFO - 2017-07-22 09:16:48 --> Form Validation Class Initialized
INFO - 2017-07-22 09:16:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:16:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:16:48 --> Helper loaded: url_helper
INFO - 2017-07-22 12:46:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:46:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:46:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:46:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:46:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:46:48 --> Final output sent to browser
DEBUG - 2017-07-22 12:46:48 --> Total execution time: 0.0566
INFO - 2017-07-22 09:16:51 --> Config Class Initialized
INFO - 2017-07-22 09:16:51 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:16:51 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:16:51 --> Utf8 Class Initialized
INFO - 2017-07-22 09:16:51 --> URI Class Initialized
INFO - 2017-07-22 09:16:51 --> Router Class Initialized
INFO - 2017-07-22 09:16:51 --> Output Class Initialized
INFO - 2017-07-22 09:16:51 --> Security Class Initialized
DEBUG - 2017-07-22 09:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:16:51 --> Input Class Initialized
INFO - 2017-07-22 09:16:51 --> Language Class Initialized
INFO - 2017-07-22 09:16:51 --> Loader Class Initialized
INFO - 2017-07-22 09:16:51 --> Helper loaded: common_helper
INFO - 2017-07-22 09:16:51 --> Database Driver Class Initialized
INFO - 2017-07-22 09:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:16:51 --> Email Class Initialized
INFO - 2017-07-22 09:16:51 --> Controller Class Initialized
INFO - 2017-07-22 09:16:51 --> Helper loaded: form_helper
INFO - 2017-07-22 09:16:51 --> Form Validation Class Initialized
INFO - 2017-07-22 09:16:51 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:16:51 --> Helper loaded: url_helper
INFO - 2017-07-22 12:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:46:51 --> Final output sent to browser
DEBUG - 2017-07-22 12:46:51 --> Total execution time: 0.0435
INFO - 2017-07-22 09:18:48 --> Config Class Initialized
INFO - 2017-07-22 09:18:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:18:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:18:48 --> Utf8 Class Initialized
INFO - 2017-07-22 09:18:48 --> URI Class Initialized
INFO - 2017-07-22 09:18:48 --> Router Class Initialized
INFO - 2017-07-22 09:18:48 --> Output Class Initialized
INFO - 2017-07-22 09:18:48 --> Security Class Initialized
DEBUG - 2017-07-22 09:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:18:48 --> Input Class Initialized
INFO - 2017-07-22 09:18:48 --> Language Class Initialized
INFO - 2017-07-22 09:18:48 --> Loader Class Initialized
INFO - 2017-07-22 09:18:48 --> Helper loaded: common_helper
INFO - 2017-07-22 09:18:48 --> Database Driver Class Initialized
INFO - 2017-07-22 09:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:18:48 --> Email Class Initialized
INFO - 2017-07-22 09:18:48 --> Controller Class Initialized
INFO - 2017-07-22 09:18:48 --> Helper loaded: form_helper
INFO - 2017-07-22 09:18:48 --> Form Validation Class Initialized
INFO - 2017-07-22 09:18:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:18:48 --> Helper loaded: url_helper
INFO - 2017-07-22 12:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:48:48 --> Final output sent to browser
DEBUG - 2017-07-22 12:48:48 --> Total execution time: 0.0654
INFO - 2017-07-22 09:18:52 --> Config Class Initialized
INFO - 2017-07-22 09:18:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:18:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:18:52 --> Utf8 Class Initialized
INFO - 2017-07-22 09:18:52 --> URI Class Initialized
INFO - 2017-07-22 09:18:52 --> Router Class Initialized
INFO - 2017-07-22 09:18:52 --> Output Class Initialized
INFO - 2017-07-22 09:18:52 --> Security Class Initialized
DEBUG - 2017-07-22 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:18:52 --> Input Class Initialized
INFO - 2017-07-22 09:18:52 --> Language Class Initialized
INFO - 2017-07-22 09:18:52 --> Loader Class Initialized
INFO - 2017-07-22 09:18:52 --> Helper loaded: common_helper
INFO - 2017-07-22 09:18:52 --> Database Driver Class Initialized
INFO - 2017-07-22 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:18:52 --> Email Class Initialized
INFO - 2017-07-22 09:18:52 --> Controller Class Initialized
INFO - 2017-07-22 09:18:52 --> Helper loaded: form_helper
INFO - 2017-07-22 09:18:52 --> Form Validation Class Initialized
INFO - 2017-07-22 09:18:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:18:52 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:48:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:48:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:18:52 --> Config Class Initialized
INFO - 2017-07-22 09:18:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:18:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:18:52 --> Utf8 Class Initialized
INFO - 2017-07-22 09:18:52 --> URI Class Initialized
INFO - 2017-07-22 09:18:52 --> Router Class Initialized
INFO - 2017-07-22 09:18:52 --> Output Class Initialized
INFO - 2017-07-22 09:18:52 --> Security Class Initialized
DEBUG - 2017-07-22 09:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:18:52 --> Input Class Initialized
INFO - 2017-07-22 09:18:52 --> Language Class Initialized
INFO - 2017-07-22 09:18:52 --> Loader Class Initialized
INFO - 2017-07-22 09:18:52 --> Helper loaded: common_helper
INFO - 2017-07-22 09:18:52 --> Database Driver Class Initialized
INFO - 2017-07-22 09:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:18:52 --> Email Class Initialized
INFO - 2017-07-22 09:18:52 --> Controller Class Initialized
INFO - 2017-07-22 09:18:52 --> Helper loaded: form_helper
INFO - 2017-07-22 09:18:52 --> Form Validation Class Initialized
INFO - 2017-07-22 09:18:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:18:52 --> Helper loaded: url_helper
INFO - 2017-07-22 12:48:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:48:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:48:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:48:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:48:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:48:52 --> Final output sent to browser
DEBUG - 2017-07-22 12:48:52 --> Total execution time: 0.0665
INFO - 2017-07-22 09:18:54 --> Config Class Initialized
INFO - 2017-07-22 09:18:54 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:18:54 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:18:54 --> Utf8 Class Initialized
INFO - 2017-07-22 09:18:54 --> URI Class Initialized
INFO - 2017-07-22 09:18:54 --> Router Class Initialized
INFO - 2017-07-22 09:18:54 --> Output Class Initialized
INFO - 2017-07-22 09:18:54 --> Security Class Initialized
DEBUG - 2017-07-22 09:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:18:54 --> Input Class Initialized
INFO - 2017-07-22 09:18:54 --> Language Class Initialized
INFO - 2017-07-22 09:18:54 --> Loader Class Initialized
INFO - 2017-07-22 09:18:54 --> Helper loaded: common_helper
INFO - 2017-07-22 09:18:54 --> Database Driver Class Initialized
INFO - 2017-07-22 09:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:18:54 --> Email Class Initialized
INFO - 2017-07-22 09:18:54 --> Controller Class Initialized
INFO - 2017-07-22 09:18:54 --> Helper loaded: form_helper
INFO - 2017-07-22 09:18:54 --> Form Validation Class Initialized
INFO - 2017-07-22 09:18:54 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:18:54 --> Helper loaded: url_helper
INFO - 2017-07-22 12:48:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:48:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:48:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:48:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:48:54 --> Final output sent to browser
DEBUG - 2017-07-22 12:48:54 --> Total execution time: 0.0426
INFO - 2017-07-22 09:19:17 --> Config Class Initialized
INFO - 2017-07-22 09:19:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:17 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:17 --> URI Class Initialized
INFO - 2017-07-22 09:19:17 --> Router Class Initialized
INFO - 2017-07-22 09:19:17 --> Output Class Initialized
INFO - 2017-07-22 09:19:17 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:17 --> Input Class Initialized
INFO - 2017-07-22 09:19:17 --> Language Class Initialized
INFO - 2017-07-22 09:19:17 --> Loader Class Initialized
INFO - 2017-07-22 09:19:17 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:17 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:17 --> Email Class Initialized
INFO - 2017-07-22 09:19:17 --> Controller Class Initialized
INFO - 2017-07-22 09:19:17 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:17 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:17 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:49:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:17 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:17 --> Total execution time: 0.0435
INFO - 2017-07-22 09:19:18 --> Config Class Initialized
INFO - 2017-07-22 09:19:18 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:18 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:18 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:18 --> URI Class Initialized
INFO - 2017-07-22 09:19:18 --> Router Class Initialized
INFO - 2017-07-22 09:19:18 --> Output Class Initialized
INFO - 2017-07-22 09:19:18 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:18 --> Input Class Initialized
INFO - 2017-07-22 09:19:18 --> Language Class Initialized
INFO - 2017-07-22 09:19:18 --> Loader Class Initialized
INFO - 2017-07-22 09:19:18 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:18 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:18 --> Email Class Initialized
INFO - 2017-07-22 09:19:18 --> Controller Class Initialized
INFO - 2017-07-22 09:19:18 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:18 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:18 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:19 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:49:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:49:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:19:19 --> Config Class Initialized
INFO - 2017-07-22 09:19:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:19 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:19 --> URI Class Initialized
INFO - 2017-07-22 09:19:19 --> Router Class Initialized
INFO - 2017-07-22 09:19:19 --> Output Class Initialized
INFO - 2017-07-22 09:19:19 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:19 --> Input Class Initialized
INFO - 2017-07-22 09:19:19 --> Language Class Initialized
INFO - 2017-07-22 09:19:19 --> Loader Class Initialized
INFO - 2017-07-22 09:19:19 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:19 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:19 --> Email Class Initialized
INFO - 2017-07-22 09:19:19 --> Controller Class Initialized
INFO - 2017-07-22 09:19:19 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:19 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:19 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:49:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:49:19 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:19 --> Total execution time: 0.0431
INFO - 2017-07-22 09:19:21 --> Config Class Initialized
INFO - 2017-07-22 09:19:21 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:21 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:21 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:21 --> URI Class Initialized
INFO - 2017-07-22 09:19:21 --> Router Class Initialized
INFO - 2017-07-22 09:19:21 --> Output Class Initialized
INFO - 2017-07-22 09:19:21 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:21 --> Input Class Initialized
INFO - 2017-07-22 09:19:21 --> Language Class Initialized
INFO - 2017-07-22 09:19:21 --> Loader Class Initialized
INFO - 2017-07-22 09:19:21 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:21 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:21 --> Email Class Initialized
INFO - 2017-07-22 09:19:21 --> Controller Class Initialized
INFO - 2017-07-22 09:19:21 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:21 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:21 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:21 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:49:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:21 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:21 --> Total execution time: 0.0492
INFO - 2017-07-22 09:19:26 --> Config Class Initialized
INFO - 2017-07-22 09:19:26 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:26 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:26 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:26 --> URI Class Initialized
INFO - 2017-07-22 09:19:26 --> Router Class Initialized
INFO - 2017-07-22 09:19:26 --> Output Class Initialized
INFO - 2017-07-22 09:19:26 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:26 --> Input Class Initialized
INFO - 2017-07-22 09:19:26 --> Language Class Initialized
INFO - 2017-07-22 09:19:26 --> Loader Class Initialized
INFO - 2017-07-22 09:19:26 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:26 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:26 --> Email Class Initialized
INFO - 2017-07-22 09:19:26 --> Controller Class Initialized
INFO - 2017-07-22 09:19:26 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:26 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:26 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:26 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:49:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:49:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:19:26 --> Config Class Initialized
INFO - 2017-07-22 09:19:26 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:26 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:26 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:26 --> URI Class Initialized
INFO - 2017-07-22 09:19:26 --> Router Class Initialized
INFO - 2017-07-22 09:19:26 --> Output Class Initialized
INFO - 2017-07-22 09:19:26 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:26 --> Input Class Initialized
INFO - 2017-07-22 09:19:26 --> Language Class Initialized
INFO - 2017-07-22 09:19:26 --> Loader Class Initialized
INFO - 2017-07-22 09:19:26 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:26 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:26 --> Email Class Initialized
INFO - 2017-07-22 09:19:26 --> Controller Class Initialized
INFO - 2017-07-22 09:19:26 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:26 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:26 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:26 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:49:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:49:26 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:26 --> Total execution time: 0.0781
INFO - 2017-07-22 09:19:28 --> Config Class Initialized
INFO - 2017-07-22 09:19:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:28 --> URI Class Initialized
INFO - 2017-07-22 09:19:28 --> Router Class Initialized
INFO - 2017-07-22 09:19:28 --> Output Class Initialized
INFO - 2017-07-22 09:19:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:28 --> Input Class Initialized
INFO - 2017-07-22 09:19:28 --> Language Class Initialized
INFO - 2017-07-22 09:19:28 --> Loader Class Initialized
INFO - 2017-07-22 09:19:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:28 --> Email Class Initialized
INFO - 2017-07-22 09:19:28 --> Controller Class Initialized
INFO - 2017-07-22 09:19:29 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:29 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:49:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:29 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:29 --> Total execution time: 0.0431
INFO - 2017-07-22 09:19:31 --> Config Class Initialized
INFO - 2017-07-22 09:19:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:31 --> URI Class Initialized
INFO - 2017-07-22 09:19:31 --> Router Class Initialized
INFO - 2017-07-22 09:19:31 --> Output Class Initialized
INFO - 2017-07-22 09:19:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:31 --> Input Class Initialized
INFO - 2017-07-22 09:19:31 --> Language Class Initialized
INFO - 2017-07-22 09:19:31 --> Loader Class Initialized
INFO - 2017-07-22 09:19:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:31 --> Email Class Initialized
INFO - 2017-07-22 09:19:31 --> Controller Class Initialized
INFO - 2017-07-22 09:19:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:31 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:49:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:49:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:19:31 --> Config Class Initialized
INFO - 2017-07-22 09:19:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:31 --> URI Class Initialized
INFO - 2017-07-22 09:19:31 --> Router Class Initialized
INFO - 2017-07-22 09:19:31 --> Output Class Initialized
INFO - 2017-07-22 09:19:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:31 --> Input Class Initialized
INFO - 2017-07-22 09:19:31 --> Language Class Initialized
INFO - 2017-07-22 09:19:31 --> Loader Class Initialized
INFO - 2017-07-22 09:19:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:31 --> Email Class Initialized
INFO - 2017-07-22 09:19:31 --> Controller Class Initialized
INFO - 2017-07-22 09:19:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:31 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:31 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:31 --> Total execution time: 0.0420
INFO - 2017-07-22 09:19:36 --> Config Class Initialized
INFO - 2017-07-22 09:19:36 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:36 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:36 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:36 --> URI Class Initialized
INFO - 2017-07-22 09:19:36 --> Router Class Initialized
INFO - 2017-07-22 09:19:36 --> Output Class Initialized
INFO - 2017-07-22 09:19:36 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:36 --> Input Class Initialized
INFO - 2017-07-22 09:19:36 --> Language Class Initialized
INFO - 2017-07-22 09:19:36 --> Loader Class Initialized
INFO - 2017-07-22 09:19:36 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:36 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:36 --> Email Class Initialized
INFO - 2017-07-22 09:19:36 --> Controller Class Initialized
INFO - 2017-07-22 09:19:36 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:36 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:36 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:36 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:49:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:36 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:36 --> Total execution time: 0.0429
INFO - 2017-07-22 09:19:56 --> Config Class Initialized
INFO - 2017-07-22 09:19:56 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:56 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:56 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:56 --> URI Class Initialized
INFO - 2017-07-22 09:19:56 --> Router Class Initialized
INFO - 2017-07-22 09:19:56 --> Output Class Initialized
INFO - 2017-07-22 09:19:56 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:56 --> Input Class Initialized
INFO - 2017-07-22 09:19:56 --> Language Class Initialized
INFO - 2017-07-22 09:19:56 --> Loader Class Initialized
INFO - 2017-07-22 09:19:56 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:56 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:56 --> Email Class Initialized
INFO - 2017-07-22 09:19:56 --> Controller Class Initialized
INFO - 2017-07-22 09:19:56 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:56 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:56 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:56 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:49:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:56 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:56 --> Total execution time: 0.0459
INFO - 2017-07-22 09:19:59 --> Config Class Initialized
INFO - 2017-07-22 09:19:59 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:59 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:59 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:59 --> URI Class Initialized
INFO - 2017-07-22 09:19:59 --> Router Class Initialized
INFO - 2017-07-22 09:19:59 --> Output Class Initialized
INFO - 2017-07-22 09:19:59 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:59 --> Input Class Initialized
INFO - 2017-07-22 09:19:59 --> Language Class Initialized
INFO - 2017-07-22 09:19:59 --> Loader Class Initialized
INFO - 2017-07-22 09:19:59 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:59 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:59 --> Email Class Initialized
INFO - 2017-07-22 09:19:59 --> Controller Class Initialized
INFO - 2017-07-22 09:19:59 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:59 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:59 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:59 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:49:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:19:59 --> Config Class Initialized
INFO - 2017-07-22 09:19:59 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:19:59 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:19:59 --> Utf8 Class Initialized
INFO - 2017-07-22 09:19:59 --> URI Class Initialized
INFO - 2017-07-22 09:19:59 --> Router Class Initialized
INFO - 2017-07-22 09:19:59 --> Output Class Initialized
INFO - 2017-07-22 09:19:59 --> Security Class Initialized
DEBUG - 2017-07-22 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:19:59 --> Input Class Initialized
INFO - 2017-07-22 09:19:59 --> Language Class Initialized
INFO - 2017-07-22 09:19:59 --> Loader Class Initialized
INFO - 2017-07-22 09:19:59 --> Helper loaded: common_helper
INFO - 2017-07-22 09:19:59 --> Database Driver Class Initialized
INFO - 2017-07-22 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:19:59 --> Email Class Initialized
INFO - 2017-07-22 09:19:59 --> Controller Class Initialized
INFO - 2017-07-22 09:19:59 --> Helper loaded: form_helper
INFO - 2017-07-22 09:19:59 --> Form Validation Class Initialized
INFO - 2017-07-22 09:19:59 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:19:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:19:59 --> Helper loaded: url_helper
INFO - 2017-07-22 12:49:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:49:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:49:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:49:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:49:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:49:59 --> Final output sent to browser
DEBUG - 2017-07-22 12:49:59 --> Total execution time: 0.0432
INFO - 2017-07-22 09:20:01 --> Config Class Initialized
INFO - 2017-07-22 09:20:01 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:01 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:01 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:01 --> URI Class Initialized
INFO - 2017-07-22 09:20:01 --> Router Class Initialized
INFO - 2017-07-22 09:20:01 --> Output Class Initialized
INFO - 2017-07-22 09:20:01 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:01 --> Input Class Initialized
INFO - 2017-07-22 09:20:01 --> Language Class Initialized
INFO - 2017-07-22 09:20:01 --> Loader Class Initialized
INFO - 2017-07-22 09:20:01 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:01 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:01 --> Email Class Initialized
INFO - 2017-07-22 09:20:01 --> Controller Class Initialized
INFO - 2017-07-22 09:20:01 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:01 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:01 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:01 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:50:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:01 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:01 --> Total execution time: 0.0426
INFO - 2017-07-22 09:20:03 --> Config Class Initialized
INFO - 2017-07-22 09:20:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:03 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:03 --> URI Class Initialized
INFO - 2017-07-22 09:20:03 --> Router Class Initialized
INFO - 2017-07-22 09:20:03 --> Output Class Initialized
INFO - 2017-07-22 09:20:03 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:03 --> Input Class Initialized
INFO - 2017-07-22 09:20:03 --> Language Class Initialized
INFO - 2017-07-22 09:20:03 --> Loader Class Initialized
INFO - 2017-07-22 09:20:03 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:03 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:03 --> Email Class Initialized
INFO - 2017-07-22 09:20:03 --> Controller Class Initialized
INFO - 2017-07-22 09:20:03 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:03 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:03 --> Helper loaded: url_helper
DEBUG - 2017-07-22 12:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:50:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 09:20:04 --> Config Class Initialized
INFO - 2017-07-22 09:20:04 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:04 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:04 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:04 --> URI Class Initialized
INFO - 2017-07-22 09:20:04 --> Router Class Initialized
INFO - 2017-07-22 09:20:04 --> Output Class Initialized
INFO - 2017-07-22 09:20:04 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:04 --> Input Class Initialized
INFO - 2017-07-22 09:20:04 --> Language Class Initialized
INFO - 2017-07-22 09:20:04 --> Loader Class Initialized
INFO - 2017-07-22 09:20:04 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:04 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:04 --> Email Class Initialized
INFO - 2017-07-22 09:20:04 --> Controller Class Initialized
INFO - 2017-07-22 09:20:04 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:04 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:04 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:04 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:50:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:50:04 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:04 --> Total execution time: 0.0695
INFO - 2017-07-22 09:20:28 --> Config Class Initialized
INFO - 2017-07-22 09:20:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:28 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:28 --> URI Class Initialized
INFO - 2017-07-22 09:20:28 --> Router Class Initialized
INFO - 2017-07-22 09:20:28 --> Output Class Initialized
INFO - 2017-07-22 09:20:28 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:28 --> Input Class Initialized
INFO - 2017-07-22 09:20:28 --> Language Class Initialized
INFO - 2017-07-22 09:20:28 --> Loader Class Initialized
INFO - 2017-07-22 09:20:28 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:28 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:28 --> Email Class Initialized
INFO - 2017-07-22 09:20:28 --> Controller Class Initialized
INFO - 2017-07-22 09:20:28 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:28 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:28 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:50:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:50:28 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:28 --> Total execution time: 0.0452
INFO - 2017-07-22 09:20:35 --> Config Class Initialized
INFO - 2017-07-22 09:20:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:35 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:35 --> URI Class Initialized
INFO - 2017-07-22 09:20:35 --> Router Class Initialized
INFO - 2017-07-22 09:20:35 --> Output Class Initialized
INFO - 2017-07-22 09:20:35 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:35 --> Input Class Initialized
INFO - 2017-07-22 09:20:35 --> Language Class Initialized
INFO - 2017-07-22 09:20:35 --> Loader Class Initialized
INFO - 2017-07-22 09:20:35 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:35 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:35 --> Email Class Initialized
INFO - 2017-07-22 09:20:35 --> Controller Class Initialized
INFO - 2017-07-22 09:20:35 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:35 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:35 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:50:35 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:35 --> Total execution time: 0.0558
INFO - 2017-07-22 09:20:41 --> Config Class Initialized
INFO - 2017-07-22 09:20:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:41 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:41 --> URI Class Initialized
INFO - 2017-07-22 09:20:41 --> Router Class Initialized
INFO - 2017-07-22 09:20:41 --> Output Class Initialized
INFO - 2017-07-22 09:20:41 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:41 --> Input Class Initialized
INFO - 2017-07-22 09:20:41 --> Language Class Initialized
INFO - 2017-07-22 09:20:41 --> Loader Class Initialized
INFO - 2017-07-22 09:20:41 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:41 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:41 --> Email Class Initialized
INFO - 2017-07-22 09:20:41 --> Controller Class Initialized
INFO - 2017-07-22 09:20:41 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:41 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:41 --> Helper loaded: url_helper
INFO - 2017-07-22 09:20:41 --> Config Class Initialized
INFO - 2017-07-22 09:20:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:41 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:41 --> URI Class Initialized
INFO - 2017-07-22 09:20:41 --> Router Class Initialized
INFO - 2017-07-22 09:20:41 --> Output Class Initialized
INFO - 2017-07-22 09:20:41 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:41 --> Input Class Initialized
INFO - 2017-07-22 09:20:41 --> Language Class Initialized
INFO - 2017-07-22 09:20:41 --> Loader Class Initialized
INFO - 2017-07-22 09:20:41 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:41 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:41 --> Email Class Initialized
INFO - 2017-07-22 09:20:41 --> Controller Class Initialized
INFO - 2017-07-22 09:20:41 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:41 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:41 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:50:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:50:41 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:41 --> Total execution time: 0.0449
INFO - 2017-07-22 09:20:43 --> Config Class Initialized
INFO - 2017-07-22 09:20:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:43 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:43 --> URI Class Initialized
INFO - 2017-07-22 09:20:43 --> Router Class Initialized
INFO - 2017-07-22 09:20:43 --> Output Class Initialized
INFO - 2017-07-22 09:20:43 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:43 --> Input Class Initialized
INFO - 2017-07-22 09:20:43 --> Language Class Initialized
INFO - 2017-07-22 09:20:43 --> Loader Class Initialized
INFO - 2017-07-22 09:20:43 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:43 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:43 --> Email Class Initialized
INFO - 2017-07-22 09:20:43 --> Controller Class Initialized
INFO - 2017-07-22 09:20:43 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:43 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:43 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 12:50:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:43 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:43 --> Total execution time: 0.0416
INFO - 2017-07-22 09:20:48 --> Config Class Initialized
INFO - 2017-07-22 09:20:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:20:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:20:48 --> Utf8 Class Initialized
INFO - 2017-07-22 09:20:48 --> URI Class Initialized
INFO - 2017-07-22 09:20:48 --> Router Class Initialized
INFO - 2017-07-22 09:20:48 --> Output Class Initialized
INFO - 2017-07-22 09:20:48 --> Security Class Initialized
DEBUG - 2017-07-22 09:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:20:48 --> Input Class Initialized
INFO - 2017-07-22 09:20:48 --> Language Class Initialized
INFO - 2017-07-22 09:20:48 --> Loader Class Initialized
INFO - 2017-07-22 09:20:48 --> Helper loaded: common_helper
INFO - 2017-07-22 09:20:48 --> Database Driver Class Initialized
INFO - 2017-07-22 09:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:20:48 --> Email Class Initialized
INFO - 2017-07-22 09:20:48 --> Controller Class Initialized
INFO - 2017-07-22 09:20:48 --> Helper loaded: form_helper
INFO - 2017-07-22 09:20:48 --> Form Validation Class Initialized
INFO - 2017-07-22 09:20:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:20:48 --> Helper loaded: url_helper
INFO - 2017-07-22 12:50:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 12:50:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 12:50:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 12:50:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 12:50:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 12:50:48 --> Final output sent to browser
DEBUG - 2017-07-22 12:50:48 --> Total execution time: 0.0469
INFO - 2017-07-22 09:51:30 --> Config Class Initialized
INFO - 2017-07-22 09:51:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:51:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:51:30 --> Utf8 Class Initialized
INFO - 2017-07-22 09:51:30 --> URI Class Initialized
INFO - 2017-07-22 09:51:30 --> Router Class Initialized
INFO - 2017-07-22 09:51:30 --> Output Class Initialized
INFO - 2017-07-22 09:51:30 --> Security Class Initialized
DEBUG - 2017-07-22 09:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:51:30 --> Input Class Initialized
INFO - 2017-07-22 09:51:30 --> Language Class Initialized
INFO - 2017-07-22 09:51:30 --> Loader Class Initialized
INFO - 2017-07-22 09:51:30 --> Helper loaded: common_helper
INFO - 2017-07-22 09:51:30 --> Database Driver Class Initialized
INFO - 2017-07-22 09:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:51:30 --> Email Class Initialized
INFO - 2017-07-22 09:51:30 --> Controller Class Initialized
INFO - 2017-07-22 09:51:30 --> Helper loaded: form_helper
INFO - 2017-07-22 09:51:30 --> Form Validation Class Initialized
INFO - 2017-07-22 09:51:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:51:30 --> Helper loaded: url_helper
INFO - 2017-07-22 13:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 13:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 13:21:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:21:30 --> Final output sent to browser
DEBUG - 2017-07-22 13:21:30 --> Total execution time: 0.0767
INFO - 2017-07-22 09:51:31 --> Config Class Initialized
INFO - 2017-07-22 09:51:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:51:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:51:31 --> Utf8 Class Initialized
INFO - 2017-07-22 09:51:31 --> URI Class Initialized
INFO - 2017-07-22 09:51:31 --> Router Class Initialized
INFO - 2017-07-22 09:51:31 --> Output Class Initialized
INFO - 2017-07-22 09:51:31 --> Security Class Initialized
DEBUG - 2017-07-22 09:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:51:31 --> Input Class Initialized
INFO - 2017-07-22 09:51:31 --> Language Class Initialized
INFO - 2017-07-22 09:51:31 --> Loader Class Initialized
INFO - 2017-07-22 09:51:31 --> Helper loaded: common_helper
INFO - 2017-07-22 09:51:31 --> Database Driver Class Initialized
INFO - 2017-07-22 09:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:51:31 --> Email Class Initialized
INFO - 2017-07-22 09:51:31 --> Controller Class Initialized
INFO - 2017-07-22 09:51:31 --> Helper loaded: form_helper
INFO - 2017-07-22 09:51:31 --> Form Validation Class Initialized
INFO - 2017-07-22 09:51:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:51:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:51:31 --> Helper loaded: url_helper
INFO - 2017-07-22 13:21:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:21:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:21:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:21:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:21:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
INFO - 2017-07-22 13:21:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:21:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:21:31 --> Final output sent to browser
DEBUG - 2017-07-22 13:21:31 --> Total execution time: 0.0602
INFO - 2017-07-22 09:52:50 --> Config Class Initialized
INFO - 2017-07-22 09:52:50 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:52:50 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:52:50 --> Utf8 Class Initialized
INFO - 2017-07-22 09:52:50 --> URI Class Initialized
INFO - 2017-07-22 09:52:50 --> Router Class Initialized
INFO - 2017-07-22 09:52:50 --> Output Class Initialized
INFO - 2017-07-22 09:52:50 --> Security Class Initialized
DEBUG - 2017-07-22 09:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:52:50 --> Input Class Initialized
INFO - 2017-07-22 09:52:50 --> Language Class Initialized
INFO - 2017-07-22 09:52:50 --> Loader Class Initialized
INFO - 2017-07-22 09:52:50 --> Helper loaded: common_helper
INFO - 2017-07-22 09:52:50 --> Database Driver Class Initialized
INFO - 2017-07-22 09:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:52:50 --> Email Class Initialized
INFO - 2017-07-22 09:52:50 --> Controller Class Initialized
INFO - 2017-07-22 09:52:50 --> Helper loaded: form_helper
INFO - 2017-07-22 09:52:50 --> Form Validation Class Initialized
INFO - 2017-07-22 09:52:50 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:52:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:52:50 --> Helper loaded: url_helper
INFO - 2017-07-22 13:22:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:22:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:22:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:22:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:22:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
INFO - 2017-07-22 13:22:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:22:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:22:50 --> Final output sent to browser
DEBUG - 2017-07-22 13:22:50 --> Total execution time: 0.0592
INFO - 2017-07-22 09:53:16 --> Config Class Initialized
INFO - 2017-07-22 09:53:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:53:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:53:16 --> Utf8 Class Initialized
INFO - 2017-07-22 09:53:16 --> URI Class Initialized
INFO - 2017-07-22 09:53:16 --> Router Class Initialized
INFO - 2017-07-22 09:53:16 --> Output Class Initialized
INFO - 2017-07-22 09:53:16 --> Security Class Initialized
DEBUG - 2017-07-22 09:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:53:16 --> Input Class Initialized
INFO - 2017-07-22 09:53:16 --> Language Class Initialized
INFO - 2017-07-22 09:53:16 --> Loader Class Initialized
INFO - 2017-07-22 09:53:16 --> Helper loaded: common_helper
INFO - 2017-07-22 09:53:16 --> Database Driver Class Initialized
INFO - 2017-07-22 09:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:53:16 --> Email Class Initialized
INFO - 2017-07-22 09:53:16 --> Controller Class Initialized
INFO - 2017-07-22 09:53:16 --> Helper loaded: form_helper
INFO - 2017-07-22 09:53:16 --> Form Validation Class Initialized
INFO - 2017-07-22 09:53:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:53:16 --> Helper loaded: url_helper
INFO - 2017-07-22 13:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
ERROR - 2017-07-22 13:23:16 --> Object of class stdClass could not be converted to string
ERROR - 2017-07-22 13:23:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 67
ERROR - 2017-07-22 13:23:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:23:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 69
INFO - 2017-07-22 13:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:23:16 --> Final output sent to browser
DEBUG - 2017-07-22 13:23:16 --> Total execution time: 0.0730
INFO - 2017-07-22 09:54:14 --> Config Class Initialized
INFO - 2017-07-22 09:54:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:54:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:54:14 --> Utf8 Class Initialized
INFO - 2017-07-22 09:54:14 --> URI Class Initialized
INFO - 2017-07-22 09:54:14 --> Router Class Initialized
INFO - 2017-07-22 09:54:14 --> Output Class Initialized
INFO - 2017-07-22 09:54:14 --> Security Class Initialized
DEBUG - 2017-07-22 09:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:54:14 --> Input Class Initialized
INFO - 2017-07-22 09:54:14 --> Language Class Initialized
INFO - 2017-07-22 09:54:14 --> Loader Class Initialized
INFO - 2017-07-22 09:54:14 --> Helper loaded: common_helper
INFO - 2017-07-22 09:54:14 --> Database Driver Class Initialized
INFO - 2017-07-22 09:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:54:14 --> Email Class Initialized
INFO - 2017-07-22 09:54:14 --> Controller Class Initialized
INFO - 2017-07-22 09:54:14 --> Helper loaded: form_helper
INFO - 2017-07-22 09:54:14 --> Form Validation Class Initialized
INFO - 2017-07-22 09:54:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:54:14 --> Helper loaded: url_helper
INFO - 2017-07-22 13:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:14 --> Undefined variable: cat
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined variable: cat C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 66
ERROR - 2017-07-22 13:24:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:24:14 --> Final output sent to browser
DEBUG - 2017-07-22 13:24:14 --> Total execution time: 0.0721
INFO - 2017-07-22 09:54:29 --> Config Class Initialized
INFO - 2017-07-22 09:54:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:54:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:54:29 --> Utf8 Class Initialized
INFO - 2017-07-22 09:54:29 --> URI Class Initialized
INFO - 2017-07-22 09:54:29 --> Router Class Initialized
INFO - 2017-07-22 09:54:29 --> Output Class Initialized
INFO - 2017-07-22 09:54:29 --> Security Class Initialized
DEBUG - 2017-07-22 09:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:54:29 --> Input Class Initialized
INFO - 2017-07-22 09:54:29 --> Language Class Initialized
INFO - 2017-07-22 09:54:29 --> Loader Class Initialized
INFO - 2017-07-22 09:54:29 --> Helper loaded: common_helper
INFO - 2017-07-22 09:54:29 --> Database Driver Class Initialized
INFO - 2017-07-22 09:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:54:29 --> Email Class Initialized
INFO - 2017-07-22 09:54:29 --> Controller Class Initialized
INFO - 2017-07-22 09:54:29 --> Helper loaded: form_helper
INFO - 2017-07-22 09:54:29 --> Form Validation Class Initialized
INFO - 2017-07-22 09:54:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:54:29 --> Helper loaded: url_helper
INFO - 2017-07-22 13:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:24:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:24:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:24:29 --> Final output sent to browser
DEBUG - 2017-07-22 13:24:29 --> Total execution time: 0.0588
INFO - 2017-07-22 09:55:13 --> Config Class Initialized
INFO - 2017-07-22 09:55:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:55:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:55:13 --> Utf8 Class Initialized
INFO - 2017-07-22 09:55:13 --> URI Class Initialized
INFO - 2017-07-22 09:55:13 --> Router Class Initialized
INFO - 2017-07-22 09:55:13 --> Output Class Initialized
INFO - 2017-07-22 09:55:13 --> Security Class Initialized
DEBUG - 2017-07-22 09:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:55:13 --> Input Class Initialized
INFO - 2017-07-22 09:55:13 --> Language Class Initialized
INFO - 2017-07-22 09:55:13 --> Loader Class Initialized
INFO - 2017-07-22 09:55:13 --> Helper loaded: common_helper
INFO - 2017-07-22 09:55:13 --> Database Driver Class Initialized
INFO - 2017-07-22 09:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:55:13 --> Email Class Initialized
INFO - 2017-07-22 09:55:13 --> Controller Class Initialized
INFO - 2017-07-22 09:55:13 --> Helper loaded: form_helper
INFO - 2017-07-22 09:55:13 --> Form Validation Class Initialized
INFO - 2017-07-22 09:55:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:55:13 --> Helper loaded: url_helper
INFO - 2017-07-22 13:25:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:25:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:25:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:25:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:25:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:25:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:25:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:25:13 --> Final output sent to browser
DEBUG - 2017-07-22 13:25:13 --> Total execution time: 0.0583
INFO - 2017-07-22 09:56:35 --> Config Class Initialized
INFO - 2017-07-22 09:56:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:56:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:56:35 --> Utf8 Class Initialized
INFO - 2017-07-22 09:56:35 --> URI Class Initialized
INFO - 2017-07-22 09:56:35 --> Router Class Initialized
INFO - 2017-07-22 09:56:35 --> Output Class Initialized
INFO - 2017-07-22 09:56:35 --> Security Class Initialized
DEBUG - 2017-07-22 09:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:56:35 --> Input Class Initialized
INFO - 2017-07-22 09:56:35 --> Language Class Initialized
INFO - 2017-07-22 09:56:35 --> Loader Class Initialized
INFO - 2017-07-22 09:56:35 --> Helper loaded: common_helper
INFO - 2017-07-22 09:56:35 --> Database Driver Class Initialized
INFO - 2017-07-22 09:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:56:35 --> Email Class Initialized
INFO - 2017-07-22 09:56:35 --> Controller Class Initialized
INFO - 2017-07-22 09:56:35 --> Helper loaded: form_helper
INFO - 2017-07-22 09:56:35 --> Form Validation Class Initialized
INFO - 2017-07-22 09:56:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:56:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:56:35 --> Helper loaded: url_helper
INFO - 2017-07-22 13:26:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:26:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:26:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:35 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:35 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:26:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:26:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:26:35 --> Final output sent to browser
DEBUG - 2017-07-22 13:26:35 --> Total execution time: 0.0644
INFO - 2017-07-22 09:56:52 --> Config Class Initialized
INFO - 2017-07-22 09:56:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:56:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:56:52 --> Utf8 Class Initialized
INFO - 2017-07-22 09:56:52 --> URI Class Initialized
INFO - 2017-07-22 09:56:52 --> Router Class Initialized
INFO - 2017-07-22 09:56:52 --> Output Class Initialized
INFO - 2017-07-22 09:56:52 --> Security Class Initialized
DEBUG - 2017-07-22 09:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:56:52 --> Input Class Initialized
INFO - 2017-07-22 09:56:52 --> Language Class Initialized
INFO - 2017-07-22 09:56:52 --> Loader Class Initialized
INFO - 2017-07-22 09:56:52 --> Helper loaded: common_helper
INFO - 2017-07-22 09:56:52 --> Database Driver Class Initialized
INFO - 2017-07-22 09:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:56:52 --> Email Class Initialized
INFO - 2017-07-22 09:56:52 --> Controller Class Initialized
INFO - 2017-07-22 09:56:52 --> Helper loaded: form_helper
INFO - 2017-07-22 09:56:52 --> Form Validation Class Initialized
INFO - 2017-07-22 09:56:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:56:52 --> Helper loaded: url_helper
INFO - 2017-07-22 13:26:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:26:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:26:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:26:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:26:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:26:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:26:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:26:52 --> Final output sent to browser
DEBUG - 2017-07-22 13:26:52 --> Total execution time: 0.0594
INFO - 2017-07-22 09:57:50 --> Config Class Initialized
INFO - 2017-07-22 09:57:50 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:57:50 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:57:50 --> Utf8 Class Initialized
INFO - 2017-07-22 09:57:50 --> URI Class Initialized
INFO - 2017-07-22 09:57:50 --> Router Class Initialized
INFO - 2017-07-22 09:57:50 --> Output Class Initialized
INFO - 2017-07-22 09:57:50 --> Security Class Initialized
DEBUG - 2017-07-22 09:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:57:50 --> Input Class Initialized
INFO - 2017-07-22 09:57:50 --> Language Class Initialized
INFO - 2017-07-22 09:57:50 --> Loader Class Initialized
INFO - 2017-07-22 09:57:50 --> Helper loaded: common_helper
INFO - 2017-07-22 09:57:50 --> Database Driver Class Initialized
INFO - 2017-07-22 09:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:57:50 --> Email Class Initialized
INFO - 2017-07-22 09:57:50 --> Controller Class Initialized
INFO - 2017-07-22 09:57:50 --> Helper loaded: form_helper
INFO - 2017-07-22 09:57:50 --> Form Validation Class Initialized
INFO - 2017-07-22 09:57:50 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:57:50 --> Helper loaded: url_helper
INFO - 2017-07-22 13:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:27:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:27:50 --> Final output sent to browser
DEBUG - 2017-07-22 13:27:50 --> Total execution time: 0.0635
INFO - 2017-07-22 09:57:53 --> Config Class Initialized
INFO - 2017-07-22 09:57:53 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:57:53 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:57:53 --> Utf8 Class Initialized
INFO - 2017-07-22 09:57:53 --> URI Class Initialized
INFO - 2017-07-22 09:57:53 --> Router Class Initialized
INFO - 2017-07-22 09:57:53 --> Output Class Initialized
INFO - 2017-07-22 09:57:53 --> Security Class Initialized
DEBUG - 2017-07-22 09:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:57:53 --> Input Class Initialized
INFO - 2017-07-22 09:57:53 --> Language Class Initialized
INFO - 2017-07-22 09:57:53 --> Loader Class Initialized
INFO - 2017-07-22 09:57:53 --> Helper loaded: common_helper
INFO - 2017-07-22 09:57:53 --> Database Driver Class Initialized
INFO - 2017-07-22 09:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:57:53 --> Email Class Initialized
INFO - 2017-07-22 09:57:53 --> Controller Class Initialized
INFO - 2017-07-22 09:57:53 --> Helper loaded: form_helper
INFO - 2017-07-22 09:57:53 --> Form Validation Class Initialized
INFO - 2017-07-22 09:57:53 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:57:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:57:53 --> Helper loaded: url_helper
INFO - 2017-07-22 09:57:53 --> Model Class Initialized
INFO - 2017-07-22 09:57:53 --> Model Class Initialized
INFO - 2017-07-22 09:57:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 09:57:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 09:57:53 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 09:57:53 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 09:57:53 --> Trying to get property of non-object
ERROR - 2017-07-22 09:57:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 09:57:53 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 09:57:53 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 09:57:53 --> Trying to get property of non-object
ERROR - 2017-07-22 09:57:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 09:57:53 --> Undefined variable: Evenets
ERROR - 2017-07-22 09:57:53 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 09:57:53 --> Trying to get property of non-object
ERROR - 2017-07-22 09:57:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 09:57:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 09:57:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 09:57:53 --> Final output sent to browser
DEBUG - 2017-07-22 09:57:53 --> Total execution time: 0.0639
INFO - 2017-07-22 09:57:55 --> Config Class Initialized
INFO - 2017-07-22 09:57:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:57:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:57:55 --> Utf8 Class Initialized
INFO - 2017-07-22 09:57:55 --> URI Class Initialized
INFO - 2017-07-22 09:57:55 --> Router Class Initialized
INFO - 2017-07-22 09:57:55 --> Output Class Initialized
INFO - 2017-07-22 09:57:55 --> Security Class Initialized
DEBUG - 2017-07-22 09:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:57:55 --> Input Class Initialized
INFO - 2017-07-22 09:57:55 --> Language Class Initialized
INFO - 2017-07-22 09:57:55 --> Loader Class Initialized
INFO - 2017-07-22 09:57:55 --> Helper loaded: common_helper
INFO - 2017-07-22 09:57:55 --> Database Driver Class Initialized
INFO - 2017-07-22 09:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:57:55 --> Email Class Initialized
INFO - 2017-07-22 09:57:55 --> Controller Class Initialized
INFO - 2017-07-22 09:57:55 --> Helper loaded: form_helper
INFO - 2017-07-22 09:57:55 --> Form Validation Class Initialized
INFO - 2017-07-22 09:57:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:57:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:57:55 --> Helper loaded: url_helper
INFO - 2017-07-22 13:27:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:27:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:27:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:27:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:27:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:27:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:27:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:27:55 --> Final output sent to browser
DEBUG - 2017-07-22 13:27:55 --> Total execution time: 0.0570
INFO - 2017-07-22 09:59:14 --> Config Class Initialized
INFO - 2017-07-22 09:59:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:14 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:14 --> URI Class Initialized
INFO - 2017-07-22 09:59:14 --> Router Class Initialized
INFO - 2017-07-22 09:59:14 --> Output Class Initialized
INFO - 2017-07-22 09:59:14 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:14 --> Input Class Initialized
INFO - 2017-07-22 09:59:14 --> Language Class Initialized
INFO - 2017-07-22 09:59:14 --> Loader Class Initialized
INFO - 2017-07-22 09:59:14 --> Helper loaded: common_helper
INFO - 2017-07-22 09:59:14 --> Database Driver Class Initialized
INFO - 2017-07-22 09:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:59:14 --> Email Class Initialized
INFO - 2017-07-22 09:59:14 --> Controller Class Initialized
INFO - 2017-07-22 09:59:14 --> Helper loaded: form_helper
INFO - 2017-07-22 09:59:14 --> Form Validation Class Initialized
INFO - 2017-07-22 09:59:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:59:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:59:14 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:29:14 --> Final output sent to browser
DEBUG - 2017-07-22 13:29:14 --> Total execution time: 0.0610
INFO - 2017-07-22 09:59:16 --> Config Class Initialized
INFO - 2017-07-22 09:59:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:16 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:16 --> URI Class Initialized
INFO - 2017-07-22 09:59:16 --> Router Class Initialized
INFO - 2017-07-22 09:59:16 --> Output Class Initialized
INFO - 2017-07-22 09:59:16 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:16 --> Input Class Initialized
INFO - 2017-07-22 09:59:16 --> Language Class Initialized
INFO - 2017-07-22 09:59:16 --> Loader Class Initialized
INFO - 2017-07-22 09:59:16 --> Helper loaded: common_helper
INFO - 2017-07-22 09:59:16 --> Database Driver Class Initialized
INFO - 2017-07-22 09:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:59:16 --> Email Class Initialized
INFO - 2017-07-22 09:59:16 --> Controller Class Initialized
INFO - 2017-07-22 09:59:16 --> Helper loaded: form_helper
INFO - 2017-07-22 09:59:16 --> Form Validation Class Initialized
INFO - 2017-07-22 09:59:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:59:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:59:16 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:29:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:29:16 --> Final output sent to browser
DEBUG - 2017-07-22 13:29:16 --> Total execution time: 0.0578
INFO - 2017-07-22 09:59:18 --> Config Class Initialized
INFO - 2017-07-22 09:59:18 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:18 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:18 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:18 --> URI Class Initialized
INFO - 2017-07-22 09:59:18 --> Router Class Initialized
INFO - 2017-07-22 09:59:18 --> Output Class Initialized
INFO - 2017-07-22 09:59:18 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:18 --> Input Class Initialized
INFO - 2017-07-22 09:59:18 --> Language Class Initialized
ERROR - 2017-07-22 09:59:18 --> 404 Page Not Found: Hospitals/addHospital
INFO - 2017-07-22 09:59:19 --> Config Class Initialized
INFO - 2017-07-22 09:59:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:19 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:19 --> URI Class Initialized
INFO - 2017-07-22 09:59:19 --> Router Class Initialized
INFO - 2017-07-22 09:59:19 --> Output Class Initialized
INFO - 2017-07-22 09:59:19 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:19 --> Input Class Initialized
INFO - 2017-07-22 09:59:19 --> Language Class Initialized
INFO - 2017-07-22 09:59:19 --> Loader Class Initialized
INFO - 2017-07-22 09:59:19 --> Helper loaded: common_helper
INFO - 2017-07-22 09:59:19 --> Database Driver Class Initialized
INFO - 2017-07-22 09:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:59:19 --> Email Class Initialized
INFO - 2017-07-22 09:59:19 --> Controller Class Initialized
INFO - 2017-07-22 09:59:19 --> Helper loaded: form_helper
INFO - 2017-07-22 09:59:19 --> Form Validation Class Initialized
INFO - 2017-07-22 09:59:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:59:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:59:19 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:29:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:29:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:19 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:19 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:29:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:29:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:29:19 --> Final output sent to browser
DEBUG - 2017-07-22 13:29:19 --> Total execution time: 0.0599
INFO - 2017-07-22 09:59:50 --> Config Class Initialized
INFO - 2017-07-22 09:59:50 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:50 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:50 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:50 --> URI Class Initialized
INFO - 2017-07-22 09:59:50 --> Router Class Initialized
INFO - 2017-07-22 09:59:50 --> Output Class Initialized
INFO - 2017-07-22 09:59:50 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:50 --> Input Class Initialized
INFO - 2017-07-22 09:59:50 --> Language Class Initialized
INFO - 2017-07-22 09:59:50 --> Loader Class Initialized
INFO - 2017-07-22 09:59:50 --> Helper loaded: common_helper
INFO - 2017-07-22 09:59:50 --> Database Driver Class Initialized
INFO - 2017-07-22 09:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:59:50 --> Email Class Initialized
INFO - 2017-07-22 09:59:50 --> Controller Class Initialized
INFO - 2017-07-22 09:59:50 --> Helper loaded: form_helper
INFO - 2017-07-22 09:59:50 --> Form Validation Class Initialized
INFO - 2017-07-22 09:59:50 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:59:50 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:29:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:29:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:50 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:50 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:29:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:29:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:29:50 --> Final output sent to browser
DEBUG - 2017-07-22 13:29:50 --> Total execution time: 0.0610
INFO - 2017-07-22 09:59:55 --> Config Class Initialized
INFO - 2017-07-22 09:59:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:55 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:55 --> URI Class Initialized
INFO - 2017-07-22 09:59:55 --> Router Class Initialized
INFO - 2017-07-22 09:59:55 --> Output Class Initialized
INFO - 2017-07-22 09:59:55 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:55 --> Input Class Initialized
INFO - 2017-07-22 09:59:55 --> Language Class Initialized
INFO - 2017-07-22 09:59:55 --> Loader Class Initialized
INFO - 2017-07-22 09:59:55 --> Helper loaded: common_helper
INFO - 2017-07-22 09:59:55 --> Database Driver Class Initialized
INFO - 2017-07-22 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:59:55 --> Email Class Initialized
INFO - 2017-07-22 09:59:55 --> Controller Class Initialized
INFO - 2017-07-22 09:59:55 --> Helper loaded: form_helper
INFO - 2017-07-22 09:59:55 --> Form Validation Class Initialized
INFO - 2017-07-22 09:59:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:59:55 --> Helper loaded: url_helper
INFO - 2017-07-22 09:59:55 --> Config Class Initialized
INFO - 2017-07-22 09:59:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 09:59:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 09:59:55 --> Utf8 Class Initialized
INFO - 2017-07-22 09:59:55 --> URI Class Initialized
INFO - 2017-07-22 09:59:55 --> Router Class Initialized
INFO - 2017-07-22 09:59:55 --> Output Class Initialized
INFO - 2017-07-22 09:59:55 --> Security Class Initialized
DEBUG - 2017-07-22 09:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 09:59:55 --> Input Class Initialized
INFO - 2017-07-22 09:59:55 --> Language Class Initialized
INFO - 2017-07-22 09:59:55 --> Loader Class Initialized
INFO - 2017-07-22 09:59:55 --> Helper loaded: common_helper
INFO - 2017-07-22 09:59:55 --> Database Driver Class Initialized
INFO - 2017-07-22 09:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 09:59:55 --> Email Class Initialized
INFO - 2017-07-22 09:59:55 --> Controller Class Initialized
INFO - 2017-07-22 09:59:55 --> Helper loaded: form_helper
INFO - 2017-07-22 09:59:55 --> Form Validation Class Initialized
INFO - 2017-07-22 09:59:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 09:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 09:59:55 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 13:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 13:29:55 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 13:29:55 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 13:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 13:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:29:55 --> Final output sent to browser
DEBUG - 2017-07-22 13:29:55 --> Total execution time: 0.0742
INFO - 2017-07-22 10:00:05 --> Config Class Initialized
INFO - 2017-07-22 10:00:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 10:00:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 10:00:05 --> Utf8 Class Initialized
INFO - 2017-07-22 10:00:05 --> URI Class Initialized
INFO - 2017-07-22 10:00:05 --> Router Class Initialized
INFO - 2017-07-22 10:00:05 --> Output Class Initialized
INFO - 2017-07-22 10:00:05 --> Security Class Initialized
DEBUG - 2017-07-22 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 10:00:05 --> Input Class Initialized
INFO - 2017-07-22 10:00:05 --> Language Class Initialized
INFO - 2017-07-22 10:00:05 --> Loader Class Initialized
INFO - 2017-07-22 10:00:05 --> Helper loaded: common_helper
INFO - 2017-07-22 10:00:05 --> Database Driver Class Initialized
INFO - 2017-07-22 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 10:00:05 --> Email Class Initialized
INFO - 2017-07-22 10:00:05 --> Controller Class Initialized
INFO - 2017-07-22 10:00:05 --> Helper loaded: form_helper
INFO - 2017-07-22 10:00:05 --> Form Validation Class Initialized
INFO - 2017-07-22 10:00:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 10:00:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 10:00:05 --> Helper loaded: url_helper
INFO - 2017-07-22 10:00:05 --> Model Class Initialized
INFO - 2017-07-22 10:00:05 --> Model Class Initialized
INFO - 2017-07-22 10:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 10:00:05 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 10:00:05 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 10:00:05 --> Trying to get property of non-object
ERROR - 2017-07-22 10:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 10:00:05 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 10:00:05 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 10:00:05 --> Trying to get property of non-object
ERROR - 2017-07-22 10:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 10:00:05 --> Undefined variable: Evenets
ERROR - 2017-07-22 10:00:05 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 10:00:05 --> Trying to get property of non-object
ERROR - 2017-07-22 10:00:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 10:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 10:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 10:00:05 --> Final output sent to browser
DEBUG - 2017-07-22 10:00:05 --> Total execution time: 0.0538
INFO - 2017-07-22 10:00:30 --> Config Class Initialized
INFO - 2017-07-22 10:00:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 10:00:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 10:00:30 --> Utf8 Class Initialized
INFO - 2017-07-22 10:00:30 --> URI Class Initialized
INFO - 2017-07-22 10:00:30 --> Router Class Initialized
INFO - 2017-07-22 10:00:30 --> Output Class Initialized
INFO - 2017-07-22 10:00:30 --> Security Class Initialized
DEBUG - 2017-07-22 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 10:00:30 --> Input Class Initialized
INFO - 2017-07-22 10:00:30 --> Language Class Initialized
INFO - 2017-07-22 10:00:30 --> Loader Class Initialized
INFO - 2017-07-22 10:00:30 --> Helper loaded: common_helper
INFO - 2017-07-22 10:00:30 --> Database Driver Class Initialized
INFO - 2017-07-22 10:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 10:00:30 --> Email Class Initialized
INFO - 2017-07-22 10:00:30 --> Controller Class Initialized
INFO - 2017-07-22 10:00:30 --> Helper loaded: form_helper
INFO - 2017-07-22 10:00:30 --> Form Validation Class Initialized
INFO - 2017-07-22 10:00:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 10:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 10:00:30 --> Helper loaded: url_helper
INFO - 2017-07-22 10:00:30 --> Model Class Initialized
INFO - 2017-07-22 10:00:30 --> Model Class Initialized
INFO - 2017-07-22 10:00:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 10:00:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 10:00:30 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 10:00:30 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 10:00:30 --> Trying to get property of non-object
ERROR - 2017-07-22 10:00:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 10:00:30 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 10:00:30 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 10:00:30 --> Trying to get property of non-object
ERROR - 2017-07-22 10:00:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 10:00:30 --> Undefined variable: Evenets
ERROR - 2017-07-22 10:00:30 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 10:00:30 --> Trying to get property of non-object
ERROR - 2017-07-22 10:00:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 10:00:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 10:00:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 10:00:30 --> Final output sent to browser
DEBUG - 2017-07-22 10:00:30 --> Total execution time: 0.0546
INFO - 2017-07-22 10:56:27 --> Config Class Initialized
INFO - 2017-07-22 10:56:27 --> Hooks Class Initialized
DEBUG - 2017-07-22 10:56:27 --> UTF-8 Support Enabled
INFO - 2017-07-22 10:56:27 --> Utf8 Class Initialized
INFO - 2017-07-22 10:56:27 --> URI Class Initialized
INFO - 2017-07-22 10:56:27 --> Router Class Initialized
INFO - 2017-07-22 10:56:27 --> Output Class Initialized
INFO - 2017-07-22 10:56:27 --> Security Class Initialized
DEBUG - 2017-07-22 10:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 10:56:27 --> Input Class Initialized
INFO - 2017-07-22 10:56:27 --> Language Class Initialized
INFO - 2017-07-22 10:56:27 --> Loader Class Initialized
INFO - 2017-07-22 10:56:27 --> Helper loaded: common_helper
INFO - 2017-07-22 10:56:27 --> Database Driver Class Initialized
INFO - 2017-07-22 10:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 10:56:27 --> Email Class Initialized
INFO - 2017-07-22 10:56:27 --> Controller Class Initialized
INFO - 2017-07-22 10:56:27 --> Helper loaded: form_helper
INFO - 2017-07-22 10:56:27 --> Form Validation Class Initialized
INFO - 2017-07-22 10:56:27 --> Helper loaded: email_helper
DEBUG - 2017-07-22 10:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 10:56:27 --> Helper loaded: url_helper
INFO - 2017-07-22 14:26:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:26:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:26:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:26:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:26:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 14:26:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 14:26:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 14:26:27 --> Final output sent to browser
DEBUG - 2017-07-22 14:26:27 --> Total execution time: 0.0590
INFO - 2017-07-22 11:00:31 --> Config Class Initialized
INFO - 2017-07-22 11:00:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:00:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:00:31 --> Utf8 Class Initialized
INFO - 2017-07-22 11:00:31 --> URI Class Initialized
INFO - 2017-07-22 11:00:31 --> Router Class Initialized
INFO - 2017-07-22 11:00:31 --> Output Class Initialized
INFO - 2017-07-22 11:00:31 --> Security Class Initialized
DEBUG - 2017-07-22 11:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:00:31 --> Input Class Initialized
INFO - 2017-07-22 11:00:31 --> Language Class Initialized
INFO - 2017-07-22 11:00:32 --> Loader Class Initialized
INFO - 2017-07-22 11:00:32 --> Helper loaded: common_helper
INFO - 2017-07-22 11:00:32 --> Database Driver Class Initialized
INFO - 2017-07-22 11:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:00:32 --> Email Class Initialized
INFO - 2017-07-22 11:00:32 --> Controller Class Initialized
INFO - 2017-07-22 11:00:32 --> Helper loaded: form_helper
INFO - 2017-07-22 11:00:32 --> Form Validation Class Initialized
INFO - 2017-07-22 11:00:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:00:32 --> Helper loaded: url_helper
INFO - 2017-07-22 14:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 14:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 14:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 14:30:32 --> Final output sent to browser
DEBUG - 2017-07-22 14:30:32 --> Total execution time: 0.0599
INFO - 2017-07-22 11:00:34 --> Config Class Initialized
INFO - 2017-07-22 11:00:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:00:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:00:34 --> Utf8 Class Initialized
INFO - 2017-07-22 11:00:34 --> URI Class Initialized
INFO - 2017-07-22 11:00:34 --> Router Class Initialized
INFO - 2017-07-22 11:00:34 --> Output Class Initialized
INFO - 2017-07-22 11:00:34 --> Security Class Initialized
DEBUG - 2017-07-22 11:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:00:34 --> Input Class Initialized
INFO - 2017-07-22 11:00:34 --> Language Class Initialized
INFO - 2017-07-22 11:00:34 --> Loader Class Initialized
INFO - 2017-07-22 11:00:34 --> Helper loaded: common_helper
INFO - 2017-07-22 11:00:34 --> Database Driver Class Initialized
INFO - 2017-07-22 11:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:00:34 --> Email Class Initialized
INFO - 2017-07-22 11:00:34 --> Controller Class Initialized
INFO - 2017-07-22 11:00:34 --> Helper loaded: form_helper
INFO - 2017-07-22 11:00:34 --> Form Validation Class Initialized
INFO - 2017-07-22 11:00:34 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:00:34 --> Helper loaded: url_helper
INFO - 2017-07-22 14:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 14:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 14:30:34 --> Final output sent to browser
DEBUG - 2017-07-22 14:30:34 --> Total execution time: 0.0420
INFO - 2017-07-22 11:00:45 --> Config Class Initialized
INFO - 2017-07-22 11:00:45 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:00:45 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:00:45 --> Utf8 Class Initialized
INFO - 2017-07-22 11:00:45 --> URI Class Initialized
INFO - 2017-07-22 11:00:45 --> Router Class Initialized
INFO - 2017-07-22 11:00:45 --> Output Class Initialized
INFO - 2017-07-22 11:00:45 --> Security Class Initialized
DEBUG - 2017-07-22 11:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:00:45 --> Input Class Initialized
INFO - 2017-07-22 11:00:45 --> Language Class Initialized
INFO - 2017-07-22 11:00:45 --> Loader Class Initialized
INFO - 2017-07-22 11:00:45 --> Helper loaded: common_helper
INFO - 2017-07-22 11:00:45 --> Database Driver Class Initialized
INFO - 2017-07-22 11:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:00:45 --> Email Class Initialized
INFO - 2017-07-22 11:00:45 --> Controller Class Initialized
INFO - 2017-07-22 11:00:45 --> Helper loaded: form_helper
INFO - 2017-07-22 11:00:45 --> Form Validation Class Initialized
INFO - 2017-07-22 11:00:45 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:00:45 --> Helper loaded: url_helper
INFO - 2017-07-22 14:30:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:30:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:30:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:30:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:30:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 14:30:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 14:30:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 14:30:45 --> Final output sent to browser
DEBUG - 2017-07-22 14:30:45 --> Total execution time: 0.0577
INFO - 2017-07-22 11:00:48 --> Config Class Initialized
INFO - 2017-07-22 11:00:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:00:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:00:48 --> Utf8 Class Initialized
INFO - 2017-07-22 11:00:48 --> URI Class Initialized
INFO - 2017-07-22 11:00:48 --> Router Class Initialized
INFO - 2017-07-22 11:00:48 --> Output Class Initialized
INFO - 2017-07-22 11:00:48 --> Security Class Initialized
DEBUG - 2017-07-22 11:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:00:48 --> Input Class Initialized
INFO - 2017-07-22 11:00:48 --> Language Class Initialized
INFO - 2017-07-22 11:00:48 --> Loader Class Initialized
INFO - 2017-07-22 11:00:48 --> Helper loaded: common_helper
INFO - 2017-07-22 11:00:48 --> Database Driver Class Initialized
INFO - 2017-07-22 11:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:00:48 --> Email Class Initialized
INFO - 2017-07-22 11:00:48 --> Controller Class Initialized
INFO - 2017-07-22 11:00:48 --> Helper loaded: form_helper
INFO - 2017-07-22 11:00:48 --> Form Validation Class Initialized
INFO - 2017-07-22 11:00:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:00:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:00:48 --> Helper loaded: url_helper
INFO - 2017-07-22 14:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 14:30:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 14:30:48 --> Final output sent to browser
DEBUG - 2017-07-22 14:30:48 --> Total execution time: 0.0426
INFO - 2017-07-22 11:03:13 --> Config Class Initialized
INFO - 2017-07-22 11:03:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:03:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:03:13 --> Utf8 Class Initialized
INFO - 2017-07-22 11:03:13 --> URI Class Initialized
INFO - 2017-07-22 11:03:13 --> Router Class Initialized
INFO - 2017-07-22 11:03:13 --> Output Class Initialized
INFO - 2017-07-22 11:03:13 --> Security Class Initialized
DEBUG - 2017-07-22 11:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:03:13 --> Input Class Initialized
INFO - 2017-07-22 11:03:13 --> Language Class Initialized
INFO - 2017-07-22 11:03:13 --> Loader Class Initialized
INFO - 2017-07-22 11:03:13 --> Helper loaded: common_helper
INFO - 2017-07-22 11:03:13 --> Database Driver Class Initialized
INFO - 2017-07-22 11:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:03:13 --> Email Class Initialized
INFO - 2017-07-22 11:03:13 --> Controller Class Initialized
INFO - 2017-07-22 11:03:13 --> Helper loaded: form_helper
INFO - 2017-07-22 11:03:13 --> Form Validation Class Initialized
INFO - 2017-07-22 11:03:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:03:13 --> Helper loaded: url_helper
INFO - 2017-07-22 14:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:33:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:33:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 14:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 14:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 14:33:13 --> Final output sent to browser
DEBUG - 2017-07-22 14:33:13 --> Total execution time: 0.0596
INFO - 2017-07-22 11:03:20 --> Config Class Initialized
INFO - 2017-07-22 11:03:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:03:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:03:20 --> Utf8 Class Initialized
INFO - 2017-07-22 11:03:20 --> URI Class Initialized
INFO - 2017-07-22 11:03:20 --> Router Class Initialized
INFO - 2017-07-22 11:03:20 --> Output Class Initialized
INFO - 2017-07-22 11:03:20 --> Security Class Initialized
DEBUG - 2017-07-22 11:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:03:20 --> Input Class Initialized
INFO - 2017-07-22 11:03:20 --> Language Class Initialized
INFO - 2017-07-22 11:03:20 --> Loader Class Initialized
INFO - 2017-07-22 11:03:20 --> Helper loaded: common_helper
INFO - 2017-07-22 11:03:20 --> Database Driver Class Initialized
INFO - 2017-07-22 11:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:03:20 --> Email Class Initialized
INFO - 2017-07-22 11:03:20 --> Controller Class Initialized
INFO - 2017-07-22 11:03:20 --> Helper loaded: form_helper
INFO - 2017-07-22 11:03:20 --> Form Validation Class Initialized
INFO - 2017-07-22 11:03:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:03:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:03:20 --> Helper loaded: url_helper
INFO - 2017-07-22 14:33:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:33:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:33:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 14:33:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 14:33:20 --> Final output sent to browser
DEBUG - 2017-07-22 14:33:20 --> Total execution time: 0.0431
INFO - 2017-07-22 11:29:02 --> Config Class Initialized
INFO - 2017-07-22 11:29:02 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:29:02 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:29:02 --> Utf8 Class Initialized
INFO - 2017-07-22 11:29:02 --> URI Class Initialized
INFO - 2017-07-22 11:29:02 --> Router Class Initialized
INFO - 2017-07-22 11:29:02 --> Output Class Initialized
INFO - 2017-07-22 11:29:02 --> Security Class Initialized
DEBUG - 2017-07-22 11:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:29:02 --> Input Class Initialized
INFO - 2017-07-22 11:29:02 --> Language Class Initialized
INFO - 2017-07-22 11:29:02 --> Loader Class Initialized
INFO - 2017-07-22 11:29:02 --> Helper loaded: common_helper
INFO - 2017-07-22 11:29:02 --> Database Driver Class Initialized
INFO - 2017-07-22 11:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:29:02 --> Email Class Initialized
INFO - 2017-07-22 11:29:02 --> Controller Class Initialized
INFO - 2017-07-22 11:29:02 --> Helper loaded: form_helper
INFO - 2017-07-22 11:29:02 --> Form Validation Class Initialized
INFO - 2017-07-22 11:29:02 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:29:02 --> Helper loaded: url_helper
INFO - 2017-07-22 11:29:02 --> Model Class Initialized
ERROR - 2017-07-22 11:29:02 --> syntax error, unexpected end of file, expecting function (T_FUNCTION)
ERROR - 2017-07-22 11:29:02 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 41
INFO - 2017-07-22 11:29:04 --> Config Class Initialized
INFO - 2017-07-22 11:29:04 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:29:04 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:29:04 --> Utf8 Class Initialized
INFO - 2017-07-22 11:29:04 --> URI Class Initialized
INFO - 2017-07-22 11:29:04 --> Router Class Initialized
INFO - 2017-07-22 11:29:04 --> Output Class Initialized
INFO - 2017-07-22 11:29:04 --> Security Class Initialized
DEBUG - 2017-07-22 11:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:29:04 --> Input Class Initialized
INFO - 2017-07-22 11:29:04 --> Language Class Initialized
INFO - 2017-07-22 11:29:04 --> Loader Class Initialized
INFO - 2017-07-22 11:29:04 --> Helper loaded: common_helper
INFO - 2017-07-22 11:29:04 --> Database Driver Class Initialized
INFO - 2017-07-22 11:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:29:04 --> Email Class Initialized
INFO - 2017-07-22 11:29:04 --> Controller Class Initialized
INFO - 2017-07-22 11:29:04 --> Helper loaded: form_helper
INFO - 2017-07-22 11:29:04 --> Form Validation Class Initialized
INFO - 2017-07-22 11:29:04 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:29:04 --> Helper loaded: url_helper
INFO - 2017-07-22 11:29:04 --> Model Class Initialized
ERROR - 2017-07-22 11:29:04 --> syntax error, unexpected end of file, expecting function (T_FUNCTION)
ERROR - 2017-07-22 11:29:04 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 41
INFO - 2017-07-22 11:29:16 --> Config Class Initialized
INFO - 2017-07-22 11:29:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:29:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:29:16 --> Utf8 Class Initialized
INFO - 2017-07-22 11:29:16 --> URI Class Initialized
INFO - 2017-07-22 11:29:16 --> Router Class Initialized
INFO - 2017-07-22 11:29:16 --> Output Class Initialized
INFO - 2017-07-22 11:29:16 --> Security Class Initialized
DEBUG - 2017-07-22 11:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:29:16 --> Input Class Initialized
INFO - 2017-07-22 11:29:16 --> Language Class Initialized
INFO - 2017-07-22 11:29:16 --> Loader Class Initialized
INFO - 2017-07-22 11:29:16 --> Helper loaded: common_helper
INFO - 2017-07-22 11:29:16 --> Database Driver Class Initialized
INFO - 2017-07-22 11:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:29:16 --> Email Class Initialized
INFO - 2017-07-22 11:29:16 --> Controller Class Initialized
INFO - 2017-07-22 11:29:16 --> Helper loaded: form_helper
INFO - 2017-07-22 11:29:16 --> Form Validation Class Initialized
INFO - 2017-07-22 11:29:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:29:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:29:17 --> Helper loaded: url_helper
INFO - 2017-07-22 11:29:17 --> Model Class Initialized
INFO - 2017-07-22 11:29:17 --> Model Class Initialized
INFO - 2017-07-22 14:59:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 14:59:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 14:59:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 14:59:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 14:59:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 14:59:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 14:59:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 14:59:17 --> Final output sent to browser
DEBUG - 2017-07-22 14:59:17 --> Total execution time: 0.0599
INFO - 2017-07-22 11:29:20 --> Config Class Initialized
INFO - 2017-07-22 11:29:20 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:29:20 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:29:20 --> Utf8 Class Initialized
INFO - 2017-07-22 11:29:20 --> URI Class Initialized
INFO - 2017-07-22 11:29:20 --> Router Class Initialized
INFO - 2017-07-22 11:29:20 --> Output Class Initialized
INFO - 2017-07-22 11:29:20 --> Security Class Initialized
DEBUG - 2017-07-22 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:29:20 --> Input Class Initialized
INFO - 2017-07-22 11:29:20 --> Language Class Initialized
INFO - 2017-07-22 11:29:20 --> Loader Class Initialized
INFO - 2017-07-22 11:29:20 --> Helper loaded: common_helper
INFO - 2017-07-22 11:29:20 --> Database Driver Class Initialized
INFO - 2017-07-22 11:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:29:20 --> Email Class Initialized
INFO - 2017-07-22 11:29:20 --> Controller Class Initialized
INFO - 2017-07-22 11:29:20 --> Helper loaded: form_helper
INFO - 2017-07-22 11:29:20 --> Form Validation Class Initialized
INFO - 2017-07-22 11:29:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:29:20 --> Helper loaded: url_helper
INFO - 2017-07-22 11:29:20 --> Model Class Initialized
INFO - 2017-07-22 11:29:20 --> Model Class Initialized
INFO - 2017-07-22 11:30:46 --> Config Class Initialized
INFO - 2017-07-22 11:30:46 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:30:46 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:30:46 --> Utf8 Class Initialized
INFO - 2017-07-22 11:30:46 --> URI Class Initialized
INFO - 2017-07-22 11:30:46 --> Router Class Initialized
INFO - 2017-07-22 11:30:46 --> Output Class Initialized
INFO - 2017-07-22 11:30:46 --> Security Class Initialized
DEBUG - 2017-07-22 11:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:30:46 --> Input Class Initialized
INFO - 2017-07-22 11:30:46 --> Language Class Initialized
INFO - 2017-07-22 11:30:46 --> Loader Class Initialized
INFO - 2017-07-22 11:30:46 --> Helper loaded: common_helper
INFO - 2017-07-22 11:30:46 --> Database Driver Class Initialized
INFO - 2017-07-22 11:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:30:46 --> Email Class Initialized
INFO - 2017-07-22 11:30:46 --> Controller Class Initialized
INFO - 2017-07-22 11:30:46 --> Helper loaded: form_helper
INFO - 2017-07-22 11:30:46 --> Form Validation Class Initialized
INFO - 2017-07-22 11:30:46 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:30:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:30:46 --> Helper loaded: url_helper
INFO - 2017-07-22 11:30:46 --> Model Class Initialized
INFO - 2017-07-22 11:30:46 --> Model Class Initialized
INFO - 2017-07-22 11:30:54 --> Config Class Initialized
INFO - 2017-07-22 11:30:54 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:30:54 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:30:54 --> Utf8 Class Initialized
INFO - 2017-07-22 11:30:54 --> URI Class Initialized
INFO - 2017-07-22 11:30:54 --> Router Class Initialized
INFO - 2017-07-22 11:30:54 --> Output Class Initialized
INFO - 2017-07-22 11:30:54 --> Security Class Initialized
DEBUG - 2017-07-22 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:30:54 --> Input Class Initialized
INFO - 2017-07-22 11:30:54 --> Language Class Initialized
INFO - 2017-07-22 11:30:54 --> Loader Class Initialized
INFO - 2017-07-22 11:30:54 --> Helper loaded: common_helper
INFO - 2017-07-22 11:30:54 --> Database Driver Class Initialized
INFO - 2017-07-22 11:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:30:54 --> Email Class Initialized
INFO - 2017-07-22 11:30:54 --> Controller Class Initialized
INFO - 2017-07-22 11:30:54 --> Helper loaded: form_helper
INFO - 2017-07-22 11:30:54 --> Form Validation Class Initialized
INFO - 2017-07-22 11:30:54 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:30:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:30:54 --> Helper loaded: url_helper
INFO - 2017-07-22 11:30:54 --> Model Class Initialized
INFO - 2017-07-22 11:30:54 --> Model Class Initialized
INFO - 2017-07-22 11:35:52 --> Config Class Initialized
INFO - 2017-07-22 11:35:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:35:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:35:52 --> Utf8 Class Initialized
INFO - 2017-07-22 11:35:52 --> URI Class Initialized
INFO - 2017-07-22 11:35:52 --> Router Class Initialized
INFO - 2017-07-22 11:35:52 --> Output Class Initialized
INFO - 2017-07-22 11:35:52 --> Security Class Initialized
DEBUG - 2017-07-22 11:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:35:52 --> Input Class Initialized
INFO - 2017-07-22 11:35:52 --> Language Class Initialized
INFO - 2017-07-22 11:35:52 --> Loader Class Initialized
INFO - 2017-07-22 11:35:52 --> Helper loaded: common_helper
INFO - 2017-07-22 11:35:52 --> Database Driver Class Initialized
INFO - 2017-07-22 11:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:35:52 --> Email Class Initialized
INFO - 2017-07-22 11:35:52 --> Controller Class Initialized
INFO - 2017-07-22 11:35:52 --> Helper loaded: form_helper
INFO - 2017-07-22 11:35:52 --> Form Validation Class Initialized
INFO - 2017-07-22 11:35:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:35:52 --> Helper loaded: url_helper
INFO - 2017-07-22 11:35:52 --> Model Class Initialized
INFO - 2017-07-22 11:35:52 --> Model Class Initialized
ERROR - 2017-07-22 15:05:52 --> Missing argument 1 for debug(), called in C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php on line 40 and defined
ERROR - 2017-07-22 15:05:52 --> Severity: Warning --> Missing argument 1 for debug(), called in C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php on line 40 and defined C:\xampp\htdocs\FlickNews\admin\application\helpers\common_helper.php 435
ERROR - 2017-07-22 15:05:52 --> Undefined variable: variable
ERROR - 2017-07-22 15:05:52 --> Severity: Notice --> Undefined variable: variable C:\xampp\htdocs\FlickNews\admin\application\helpers\common_helper.php 437
INFO - 2017-07-22 11:36:06 --> Config Class Initialized
INFO - 2017-07-22 11:36:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:36:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:36:06 --> Utf8 Class Initialized
INFO - 2017-07-22 11:36:06 --> URI Class Initialized
INFO - 2017-07-22 11:36:06 --> Router Class Initialized
INFO - 2017-07-22 11:36:06 --> Output Class Initialized
INFO - 2017-07-22 11:36:06 --> Security Class Initialized
DEBUG - 2017-07-22 11:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:36:06 --> Input Class Initialized
INFO - 2017-07-22 11:36:06 --> Language Class Initialized
INFO - 2017-07-22 11:36:06 --> Loader Class Initialized
INFO - 2017-07-22 11:36:06 --> Helper loaded: common_helper
INFO - 2017-07-22 11:36:06 --> Database Driver Class Initialized
INFO - 2017-07-22 11:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:36:06 --> Email Class Initialized
INFO - 2017-07-22 11:36:06 --> Controller Class Initialized
INFO - 2017-07-22 11:36:06 --> Helper loaded: form_helper
INFO - 2017-07-22 11:36:06 --> Form Validation Class Initialized
INFO - 2017-07-22 11:36:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:36:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:36:06 --> Helper loaded: url_helper
INFO - 2017-07-22 11:36:06 --> Model Class Initialized
INFO - 2017-07-22 11:36:06 --> Model Class Initialized
INFO - 2017-07-22 11:37:25 --> Config Class Initialized
INFO - 2017-07-22 11:37:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:37:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:37:25 --> Utf8 Class Initialized
INFO - 2017-07-22 11:37:25 --> URI Class Initialized
INFO - 2017-07-22 11:37:25 --> Router Class Initialized
INFO - 2017-07-22 11:37:25 --> Output Class Initialized
INFO - 2017-07-22 11:37:25 --> Security Class Initialized
DEBUG - 2017-07-22 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:37:25 --> Input Class Initialized
INFO - 2017-07-22 11:37:25 --> Language Class Initialized
INFO - 2017-07-22 11:37:25 --> Loader Class Initialized
INFO - 2017-07-22 11:37:25 --> Helper loaded: common_helper
INFO - 2017-07-22 11:37:25 --> Database Driver Class Initialized
INFO - 2017-07-22 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:37:25 --> Email Class Initialized
INFO - 2017-07-22 11:37:25 --> Controller Class Initialized
INFO - 2017-07-22 11:37:25 --> Helper loaded: form_helper
INFO - 2017-07-22 11:37:25 --> Form Validation Class Initialized
INFO - 2017-07-22 11:37:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:37:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:37:25 --> Helper loaded: url_helper
INFO - 2017-07-22 11:37:25 --> Model Class Initialized
INFO - 2017-07-22 11:37:25 --> Model Class Initialized
INFO - 2017-07-22 11:51:38 --> Config Class Initialized
INFO - 2017-07-22 11:51:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:51:38 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:51:38 --> Utf8 Class Initialized
INFO - 2017-07-22 11:51:38 --> URI Class Initialized
INFO - 2017-07-22 11:51:38 --> Router Class Initialized
INFO - 2017-07-22 11:51:38 --> Output Class Initialized
INFO - 2017-07-22 11:51:38 --> Security Class Initialized
DEBUG - 2017-07-22 11:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:51:38 --> Input Class Initialized
INFO - 2017-07-22 11:51:38 --> Language Class Initialized
INFO - 2017-07-22 11:51:38 --> Loader Class Initialized
INFO - 2017-07-22 11:51:38 --> Helper loaded: common_helper
INFO - 2017-07-22 11:51:38 --> Database Driver Class Initialized
INFO - 2017-07-22 11:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:51:38 --> Email Class Initialized
INFO - 2017-07-22 11:51:38 --> Controller Class Initialized
INFO - 2017-07-22 11:51:38 --> Helper loaded: form_helper
INFO - 2017-07-22 11:51:38 --> Form Validation Class Initialized
INFO - 2017-07-22 11:51:38 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:51:38 --> Helper loaded: url_helper
INFO - 2017-07-22 11:51:38 --> Model Class Initialized
INFO - 2017-07-22 11:51:38 --> Model Class Initialized
INFO - 2017-07-22 11:59:04 --> Config Class Initialized
INFO - 2017-07-22 11:59:04 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:59:04 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:59:04 --> Utf8 Class Initialized
INFO - 2017-07-22 11:59:04 --> URI Class Initialized
INFO - 2017-07-22 11:59:04 --> Router Class Initialized
INFO - 2017-07-22 11:59:04 --> Output Class Initialized
INFO - 2017-07-22 11:59:04 --> Security Class Initialized
DEBUG - 2017-07-22 11:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:59:04 --> Input Class Initialized
INFO - 2017-07-22 11:59:04 --> Language Class Initialized
INFO - 2017-07-22 11:59:04 --> Loader Class Initialized
INFO - 2017-07-22 11:59:04 --> Helper loaded: common_helper
INFO - 2017-07-22 11:59:04 --> Database Driver Class Initialized
INFO - 2017-07-22 11:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:59:04 --> Email Class Initialized
INFO - 2017-07-22 11:59:04 --> Controller Class Initialized
INFO - 2017-07-22 11:59:04 --> Helper loaded: form_helper
INFO - 2017-07-22 11:59:04 --> Form Validation Class Initialized
INFO - 2017-07-22 11:59:04 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:59:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:59:04 --> Helper loaded: url_helper
INFO - 2017-07-22 11:59:04 --> Model Class Initialized
INFO - 2017-07-22 11:59:04 --> Model Class Initialized
INFO - 2017-07-22 15:29:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-07-22 15:29:04 --> syntax error, unexpected '}'
ERROR - 2017-07-22 15:29:04 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 31
INFO - 2017-07-22 11:59:25 --> Config Class Initialized
INFO - 2017-07-22 11:59:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:59:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:59:25 --> Utf8 Class Initialized
INFO - 2017-07-22 11:59:25 --> URI Class Initialized
INFO - 2017-07-22 11:59:25 --> Router Class Initialized
INFO - 2017-07-22 11:59:25 --> Output Class Initialized
INFO - 2017-07-22 11:59:25 --> Security Class Initialized
DEBUG - 2017-07-22 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:59:25 --> Input Class Initialized
INFO - 2017-07-22 11:59:25 --> Language Class Initialized
INFO - 2017-07-22 11:59:25 --> Loader Class Initialized
INFO - 2017-07-22 11:59:25 --> Helper loaded: common_helper
INFO - 2017-07-22 11:59:25 --> Database Driver Class Initialized
INFO - 2017-07-22 11:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 11:59:25 --> Email Class Initialized
INFO - 2017-07-22 11:59:25 --> Controller Class Initialized
INFO - 2017-07-22 11:59:25 --> Helper loaded: form_helper
INFO - 2017-07-22 11:59:25 --> Form Validation Class Initialized
INFO - 2017-07-22 11:59:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 11:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 11:59:25 --> Helper loaded: url_helper
INFO - 2017-07-22 11:59:25 --> Model Class Initialized
INFO - 2017-07-22 11:59:25 --> Model Class Initialized
INFO - 2017-07-22 15:29:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:29:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:29:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:29:25 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:29:25 --> Undefined variable: images
ERROR - 2017-07-22 15:29:25 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 92
INFO - 2017-07-22 15:29:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:29:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:29:25 --> Final output sent to browser
DEBUG - 2017-07-22 15:29:25 --> Total execution time: 0.0692
INFO - 2017-07-22 11:59:25 --> Config Class Initialized
INFO - 2017-07-22 11:59:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 11:59:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 11:59:25 --> Utf8 Class Initialized
INFO - 2017-07-22 11:59:25 --> URI Class Initialized
INFO - 2017-07-22 11:59:25 --> Router Class Initialized
INFO - 2017-07-22 11:59:25 --> Output Class Initialized
INFO - 2017-07-22 11:59:25 --> Security Class Initialized
DEBUG - 2017-07-22 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 11:59:25 --> Input Class Initialized
INFO - 2017-07-22 11:59:25 --> Language Class Initialized
ERROR - 2017-07-22 11:59:25 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:00:34 --> Config Class Initialized
INFO - 2017-07-22 12:00:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:00:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:00:34 --> Utf8 Class Initialized
INFO - 2017-07-22 12:00:34 --> URI Class Initialized
INFO - 2017-07-22 12:00:34 --> Router Class Initialized
INFO - 2017-07-22 12:00:34 --> Output Class Initialized
INFO - 2017-07-22 12:00:34 --> Security Class Initialized
DEBUG - 2017-07-22 12:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:00:34 --> Input Class Initialized
INFO - 2017-07-22 12:00:34 --> Language Class Initialized
INFO - 2017-07-22 12:00:34 --> Loader Class Initialized
INFO - 2017-07-22 12:00:34 --> Helper loaded: common_helper
INFO - 2017-07-22 12:00:34 --> Database Driver Class Initialized
INFO - 2017-07-22 12:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:00:34 --> Email Class Initialized
INFO - 2017-07-22 12:00:34 --> Controller Class Initialized
INFO - 2017-07-22 12:00:34 --> Helper loaded: form_helper
INFO - 2017-07-22 12:00:34 --> Form Validation Class Initialized
INFO - 2017-07-22 12:00:34 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:00:34 --> Helper loaded: url_helper
INFO - 2017-07-22 12:00:34 --> Model Class Initialized
INFO - 2017-07-22 12:00:34 --> Model Class Initialized
INFO - 2017-07-22 15:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:34 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:34 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
INFO - 2017-07-22 15:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:30:34 --> Final output sent to browser
DEBUG - 2017-07-22 15:30:34 --> Total execution time: 0.0667
INFO - 2017-07-22 12:00:34 --> Config Class Initialized
INFO - 2017-07-22 12:00:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:00:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:00:34 --> Utf8 Class Initialized
INFO - 2017-07-22 12:00:34 --> URI Class Initialized
INFO - 2017-07-22 12:00:34 --> Router Class Initialized
INFO - 2017-07-22 12:00:34 --> Output Class Initialized
INFO - 2017-07-22 12:00:34 --> Security Class Initialized
DEBUG - 2017-07-22 12:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:00:34 --> Input Class Initialized
INFO - 2017-07-22 12:00:34 --> Language Class Initialized
ERROR - 2017-07-22 12:00:34 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:00:34 --> Config Class Initialized
INFO - 2017-07-22 12:00:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:00:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:00:34 --> Utf8 Class Initialized
INFO - 2017-07-22 12:00:34 --> URI Class Initialized
INFO - 2017-07-22 12:00:34 --> Router Class Initialized
INFO - 2017-07-22 12:00:34 --> Output Class Initialized
INFO - 2017-07-22 12:00:34 --> Security Class Initialized
DEBUG - 2017-07-22 12:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:00:34 --> Input Class Initialized
INFO - 2017-07-22 12:00:34 --> Language Class Initialized
ERROR - 2017-07-22 12:00:34 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:00:51 --> Config Class Initialized
INFO - 2017-07-22 12:00:51 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:00:51 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:00:51 --> Utf8 Class Initialized
INFO - 2017-07-22 12:00:51 --> URI Class Initialized
INFO - 2017-07-22 12:00:51 --> Router Class Initialized
INFO - 2017-07-22 12:00:51 --> Output Class Initialized
INFO - 2017-07-22 12:00:51 --> Security Class Initialized
DEBUG - 2017-07-22 12:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:00:51 --> Input Class Initialized
INFO - 2017-07-22 12:00:51 --> Language Class Initialized
INFO - 2017-07-22 12:00:51 --> Loader Class Initialized
INFO - 2017-07-22 12:00:51 --> Helper loaded: common_helper
INFO - 2017-07-22 12:00:51 --> Database Driver Class Initialized
INFO - 2017-07-22 12:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:00:51 --> Email Class Initialized
INFO - 2017-07-22 12:00:51 --> Controller Class Initialized
INFO - 2017-07-22 12:00:51 --> Helper loaded: form_helper
INFO - 2017-07-22 12:00:51 --> Form Validation Class Initialized
INFO - 2017-07-22 12:00:51 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:00:51 --> Helper loaded: url_helper
INFO - 2017-07-22 12:00:51 --> Model Class Initialized
INFO - 2017-07-22 12:00:51 --> Model Class Initialized
INFO - 2017-07-22 15:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 84
ERROR - 2017-07-22 15:30:51 --> Undefined property: stdClass::$cat_id
ERROR - 2017-07-22 15:30:51 --> Severity: Notice --> Undefined property: stdClass::$cat_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 86
INFO - 2017-07-22 15:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:30:51 --> Final output sent to browser
DEBUG - 2017-07-22 15:30:51 --> Total execution time: 0.0791
INFO - 2017-07-22 12:01:31 --> Config Class Initialized
INFO - 2017-07-22 12:01:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:01:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:01:31 --> Utf8 Class Initialized
INFO - 2017-07-22 12:01:31 --> URI Class Initialized
INFO - 2017-07-22 12:01:31 --> Router Class Initialized
INFO - 2017-07-22 12:01:31 --> Output Class Initialized
INFO - 2017-07-22 12:01:31 --> Security Class Initialized
DEBUG - 2017-07-22 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:01:31 --> Input Class Initialized
INFO - 2017-07-22 12:01:31 --> Language Class Initialized
INFO - 2017-07-22 12:01:31 --> Loader Class Initialized
INFO - 2017-07-22 12:01:31 --> Helper loaded: common_helper
INFO - 2017-07-22 12:01:31 --> Database Driver Class Initialized
INFO - 2017-07-22 12:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:01:31 --> Email Class Initialized
INFO - 2017-07-22 12:01:31 --> Controller Class Initialized
INFO - 2017-07-22 12:01:31 --> Helper loaded: form_helper
INFO - 2017-07-22 12:01:31 --> Form Validation Class Initialized
INFO - 2017-07-22 12:01:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:01:31 --> Helper loaded: url_helper
INFO - 2017-07-22 12:01:31 --> Model Class Initialized
INFO - 2017-07-22 12:01:31 --> Model Class Initialized
INFO - 2017-07-22 15:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:31:31 --> Final output sent to browser
DEBUG - 2017-07-22 15:31:31 --> Total execution time: 0.0520
INFO - 2017-07-22 12:01:31 --> Config Class Initialized
INFO - 2017-07-22 12:01:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:01:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:01:31 --> Utf8 Class Initialized
INFO - 2017-07-22 12:01:31 --> URI Class Initialized
INFO - 2017-07-22 12:01:31 --> Router Class Initialized
INFO - 2017-07-22 12:01:31 --> Output Class Initialized
INFO - 2017-07-22 12:01:31 --> Security Class Initialized
DEBUG - 2017-07-22 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:01:31 --> Input Class Initialized
INFO - 2017-07-22 12:01:31 --> Language Class Initialized
ERROR - 2017-07-22 12:01:31 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:01:31 --> Config Class Initialized
INFO - 2017-07-22 12:01:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:01:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:01:31 --> Utf8 Class Initialized
INFO - 2017-07-22 12:01:31 --> URI Class Initialized
INFO - 2017-07-22 12:01:31 --> Router Class Initialized
INFO - 2017-07-22 12:01:31 --> Output Class Initialized
INFO - 2017-07-22 12:01:31 --> Security Class Initialized
DEBUG - 2017-07-22 12:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:01:31 --> Input Class Initialized
INFO - 2017-07-22 12:01:31 --> Language Class Initialized
ERROR - 2017-07-22 12:01:31 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:06:52 --> Config Class Initialized
INFO - 2017-07-22 12:06:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:06:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:06:52 --> Utf8 Class Initialized
INFO - 2017-07-22 12:06:52 --> URI Class Initialized
INFO - 2017-07-22 12:06:52 --> Router Class Initialized
INFO - 2017-07-22 12:06:52 --> Output Class Initialized
INFO - 2017-07-22 12:06:52 --> Security Class Initialized
DEBUG - 2017-07-22 12:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:06:52 --> Input Class Initialized
INFO - 2017-07-22 12:06:52 --> Language Class Initialized
INFO - 2017-07-22 12:06:52 --> Loader Class Initialized
INFO - 2017-07-22 12:06:52 --> Helper loaded: common_helper
INFO - 2017-07-22 12:06:52 --> Database Driver Class Initialized
INFO - 2017-07-22 12:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:06:52 --> Email Class Initialized
INFO - 2017-07-22 12:06:52 --> Controller Class Initialized
INFO - 2017-07-22 12:06:52 --> Helper loaded: form_helper
INFO - 2017-07-22 12:06:52 --> Form Validation Class Initialized
INFO - 2017-07-22 12:06:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:06:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:06:52 --> Helper loaded: url_helper
INFO - 2017-07-22 12:06:52 --> Model Class Initialized
INFO - 2017-07-22 12:06:52 --> Model Class Initialized
INFO - 2017-07-22 15:36:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:36:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:36:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:36:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:36:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:36:52 --> Final output sent to browser
DEBUG - 2017-07-22 15:36:52 --> Total execution time: 0.0634
INFO - 2017-07-22 12:06:52 --> Config Class Initialized
INFO - 2017-07-22 12:06:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:06:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:06:52 --> Utf8 Class Initialized
INFO - 2017-07-22 12:06:52 --> URI Class Initialized
INFO - 2017-07-22 12:06:52 --> Router Class Initialized
INFO - 2017-07-22 12:06:52 --> Output Class Initialized
INFO - 2017-07-22 12:06:52 --> Security Class Initialized
DEBUG - 2017-07-22 12:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:06:52 --> Input Class Initialized
INFO - 2017-07-22 12:06:52 --> Language Class Initialized
ERROR - 2017-07-22 12:06:52 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:06:52 --> Config Class Initialized
INFO - 2017-07-22 12:06:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:06:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:06:52 --> Utf8 Class Initialized
INFO - 2017-07-22 12:06:52 --> URI Class Initialized
INFO - 2017-07-22 12:06:52 --> Router Class Initialized
INFO - 2017-07-22 12:06:52 --> Output Class Initialized
INFO - 2017-07-22 12:06:52 --> Security Class Initialized
DEBUG - 2017-07-22 12:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:06:52 --> Input Class Initialized
INFO - 2017-07-22 12:06:52 --> Language Class Initialized
ERROR - 2017-07-22 12:06:52 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:13:23 --> Config Class Initialized
INFO - 2017-07-22 12:13:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:13:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:13:23 --> Utf8 Class Initialized
INFO - 2017-07-22 12:13:23 --> URI Class Initialized
INFO - 2017-07-22 12:13:23 --> Router Class Initialized
INFO - 2017-07-22 12:13:23 --> Output Class Initialized
INFO - 2017-07-22 12:13:23 --> Security Class Initialized
DEBUG - 2017-07-22 12:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:13:23 --> Input Class Initialized
INFO - 2017-07-22 12:13:23 --> Language Class Initialized
ERROR - 2017-07-22 12:13:23 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:13:39 --> Config Class Initialized
INFO - 2017-07-22 12:13:39 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:13:39 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:13:39 --> Utf8 Class Initialized
INFO - 2017-07-22 12:13:39 --> URI Class Initialized
INFO - 2017-07-22 12:13:39 --> Router Class Initialized
INFO - 2017-07-22 12:13:39 --> Output Class Initialized
INFO - 2017-07-22 12:13:39 --> Security Class Initialized
DEBUG - 2017-07-22 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:13:39 --> Input Class Initialized
INFO - 2017-07-22 12:13:39 --> Language Class Initialized
ERROR - 2017-07-22 12:13:39 --> 404 Page Not Found: Uploads/sourceimages
INFO - 2017-07-22 12:13:45 --> Config Class Initialized
INFO - 2017-07-22 12:13:45 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:13:45 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:13:45 --> Utf8 Class Initialized
INFO - 2017-07-22 12:13:45 --> URI Class Initialized
INFO - 2017-07-22 12:13:45 --> Router Class Initialized
INFO - 2017-07-22 12:13:45 --> Output Class Initialized
INFO - 2017-07-22 12:13:45 --> Security Class Initialized
DEBUG - 2017-07-22 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:13:45 --> Input Class Initialized
INFO - 2017-07-22 12:13:45 --> Language Class Initialized
INFO - 2017-07-22 12:13:45 --> Loader Class Initialized
INFO - 2017-07-22 12:13:45 --> Helper loaded: common_helper
INFO - 2017-07-22 12:13:45 --> Database Driver Class Initialized
INFO - 2017-07-22 12:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:13:45 --> Email Class Initialized
INFO - 2017-07-22 12:13:45 --> Controller Class Initialized
INFO - 2017-07-22 12:13:45 --> Helper loaded: form_helper
INFO - 2017-07-22 12:13:45 --> Form Validation Class Initialized
INFO - 2017-07-22 12:13:45 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:13:45 --> Helper loaded: url_helper
INFO - 2017-07-22 12:13:45 --> Model Class Initialized
INFO - 2017-07-22 12:13:45 --> Model Class Initialized
INFO - 2017-07-22 15:43:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:43:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:43:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:43:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:43:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:43:45 --> Final output sent to browser
DEBUG - 2017-07-22 15:43:45 --> Total execution time: 0.0757
INFO - 2017-07-22 12:14:41 --> Config Class Initialized
INFO - 2017-07-22 12:14:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:14:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:14:41 --> Utf8 Class Initialized
INFO - 2017-07-22 12:14:41 --> URI Class Initialized
INFO - 2017-07-22 12:14:41 --> Router Class Initialized
INFO - 2017-07-22 12:14:41 --> Output Class Initialized
INFO - 2017-07-22 12:14:41 --> Security Class Initialized
DEBUG - 2017-07-22 12:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:14:41 --> Input Class Initialized
INFO - 2017-07-22 12:14:41 --> Language Class Initialized
INFO - 2017-07-22 12:14:41 --> Loader Class Initialized
INFO - 2017-07-22 12:14:41 --> Helper loaded: common_helper
INFO - 2017-07-22 12:14:41 --> Database Driver Class Initialized
INFO - 2017-07-22 12:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:14:41 --> Email Class Initialized
INFO - 2017-07-22 12:14:41 --> Controller Class Initialized
INFO - 2017-07-22 12:14:41 --> Helper loaded: form_helper
INFO - 2017-07-22 12:14:41 --> Form Validation Class Initialized
INFO - 2017-07-22 12:14:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:14:41 --> Helper loaded: url_helper
INFO - 2017-07-22 12:14:41 --> Model Class Initialized
INFO - 2017-07-22 12:14:41 --> Model Class Initialized
INFO - 2017-07-22 15:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:44:41 --> Final output sent to browser
DEBUG - 2017-07-22 15:44:41 --> Total execution time: 0.0507
INFO - 2017-07-22 12:16:23 --> Config Class Initialized
INFO - 2017-07-22 12:16:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:16:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:16:23 --> Utf8 Class Initialized
INFO - 2017-07-22 12:16:23 --> URI Class Initialized
INFO - 2017-07-22 12:16:23 --> Router Class Initialized
INFO - 2017-07-22 12:16:23 --> Output Class Initialized
INFO - 2017-07-22 12:16:23 --> Security Class Initialized
DEBUG - 2017-07-22 12:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:16:23 --> Input Class Initialized
INFO - 2017-07-22 12:16:23 --> Language Class Initialized
INFO - 2017-07-22 12:16:23 --> Loader Class Initialized
INFO - 2017-07-22 12:16:23 --> Helper loaded: common_helper
INFO - 2017-07-22 12:16:23 --> Database Driver Class Initialized
INFO - 2017-07-22 12:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:16:23 --> Email Class Initialized
INFO - 2017-07-22 12:16:23 --> Controller Class Initialized
INFO - 2017-07-22 12:16:23 --> Helper loaded: form_helper
INFO - 2017-07-22 12:16:23 --> Form Validation Class Initialized
INFO - 2017-07-22 12:16:23 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:16:23 --> Helper loaded: url_helper
INFO - 2017-07-22 12:16:23 --> Model Class Initialized
INFO - 2017-07-22 12:16:23 --> Model Class Initialized
INFO - 2017-07-22 15:46:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:46:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:46:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:46:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:46:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:46:23 --> Final output sent to browser
DEBUG - 2017-07-22 15:46:23 --> Total execution time: 0.0511
INFO - 2017-07-22 12:16:35 --> Config Class Initialized
INFO - 2017-07-22 12:16:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:16:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:16:35 --> Utf8 Class Initialized
INFO - 2017-07-22 12:16:35 --> URI Class Initialized
INFO - 2017-07-22 12:16:35 --> Router Class Initialized
INFO - 2017-07-22 12:16:35 --> Output Class Initialized
INFO - 2017-07-22 12:16:35 --> Security Class Initialized
DEBUG - 2017-07-22 12:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:16:35 --> Input Class Initialized
INFO - 2017-07-22 12:16:35 --> Language Class Initialized
INFO - 2017-07-22 12:16:35 --> Loader Class Initialized
INFO - 2017-07-22 12:16:35 --> Helper loaded: common_helper
INFO - 2017-07-22 12:16:35 --> Database Driver Class Initialized
INFO - 2017-07-22 12:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:16:35 --> Email Class Initialized
INFO - 2017-07-22 12:16:35 --> Controller Class Initialized
INFO - 2017-07-22 12:16:35 --> Helper loaded: form_helper
INFO - 2017-07-22 12:16:35 --> Form Validation Class Initialized
INFO - 2017-07-22 12:16:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:16:35 --> Helper loaded: url_helper
INFO - 2017-07-22 12:16:35 --> Model Class Initialized
INFO - 2017-07-22 12:16:35 --> Model Class Initialized
INFO - 2017-07-22 15:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:46:35 --> Final output sent to browser
DEBUG - 2017-07-22 15:46:35 --> Total execution time: 0.0497
INFO - 2017-07-22 12:16:44 --> Config Class Initialized
INFO - 2017-07-22 12:16:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:16:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:16:44 --> Utf8 Class Initialized
INFO - 2017-07-22 12:16:44 --> URI Class Initialized
INFO - 2017-07-22 12:16:44 --> Router Class Initialized
INFO - 2017-07-22 12:16:44 --> Output Class Initialized
INFO - 2017-07-22 12:16:44 --> Security Class Initialized
DEBUG - 2017-07-22 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:16:44 --> Input Class Initialized
INFO - 2017-07-22 12:16:44 --> Language Class Initialized
INFO - 2017-07-22 12:16:44 --> Loader Class Initialized
INFO - 2017-07-22 12:16:44 --> Helper loaded: common_helper
INFO - 2017-07-22 12:16:44 --> Database Driver Class Initialized
INFO - 2017-07-22 12:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:16:44 --> Email Class Initialized
INFO - 2017-07-22 12:16:44 --> Controller Class Initialized
INFO - 2017-07-22 12:16:44 --> Helper loaded: form_helper
INFO - 2017-07-22 12:16:44 --> Form Validation Class Initialized
INFO - 2017-07-22 12:16:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:16:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:16:44 --> Helper loaded: url_helper
INFO - 2017-07-22 12:16:44 --> Model Class Initialized
INFO - 2017-07-22 12:16:44 --> Model Class Initialized
INFO - 2017-07-22 15:46:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:46:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:46:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:46:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:46:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:46:44 --> Final output sent to browser
DEBUG - 2017-07-22 15:46:44 --> Total execution time: 0.0491
INFO - 2017-07-22 12:16:51 --> Config Class Initialized
INFO - 2017-07-22 12:16:51 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:16:51 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:16:51 --> Utf8 Class Initialized
INFO - 2017-07-22 12:16:51 --> URI Class Initialized
INFO - 2017-07-22 12:16:51 --> Router Class Initialized
INFO - 2017-07-22 12:16:51 --> Output Class Initialized
INFO - 2017-07-22 12:16:51 --> Security Class Initialized
DEBUG - 2017-07-22 12:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:16:51 --> Input Class Initialized
INFO - 2017-07-22 12:16:51 --> Language Class Initialized
INFO - 2017-07-22 12:16:51 --> Loader Class Initialized
INFO - 2017-07-22 12:16:51 --> Helper loaded: common_helper
INFO - 2017-07-22 12:16:51 --> Database Driver Class Initialized
INFO - 2017-07-22 12:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:16:51 --> Email Class Initialized
INFO - 2017-07-22 12:16:51 --> Controller Class Initialized
INFO - 2017-07-22 12:16:51 --> Helper loaded: form_helper
INFO - 2017-07-22 12:16:51 --> Form Validation Class Initialized
INFO - 2017-07-22 12:16:51 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:16:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:16:51 --> Helper loaded: url_helper
INFO - 2017-07-22 12:16:51 --> Model Class Initialized
INFO - 2017-07-22 12:16:51 --> Model Class Initialized
INFO - 2017-07-22 15:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:46:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:46:51 --> Final output sent to browser
DEBUG - 2017-07-22 15:46:51 --> Total execution time: 0.0498
INFO - 2017-07-22 12:16:56 --> Config Class Initialized
INFO - 2017-07-22 12:16:56 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:16:57 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:16:57 --> Utf8 Class Initialized
INFO - 2017-07-22 12:16:57 --> URI Class Initialized
INFO - 2017-07-22 12:16:57 --> Router Class Initialized
INFO - 2017-07-22 12:16:57 --> Output Class Initialized
INFO - 2017-07-22 12:16:57 --> Security Class Initialized
DEBUG - 2017-07-22 12:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:16:57 --> Input Class Initialized
INFO - 2017-07-22 12:16:57 --> Language Class Initialized
INFO - 2017-07-22 12:16:57 --> Loader Class Initialized
INFO - 2017-07-22 12:16:57 --> Helper loaded: common_helper
INFO - 2017-07-22 12:16:57 --> Database Driver Class Initialized
INFO - 2017-07-22 12:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:16:57 --> Email Class Initialized
INFO - 2017-07-22 12:16:57 --> Controller Class Initialized
INFO - 2017-07-22 12:16:57 --> Helper loaded: form_helper
INFO - 2017-07-22 12:16:57 --> Form Validation Class Initialized
INFO - 2017-07-22 12:16:57 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:16:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:16:57 --> Helper loaded: url_helper
INFO - 2017-07-22 12:16:57 --> Model Class Initialized
INFO - 2017-07-22 12:16:57 --> Model Class Initialized
INFO - 2017-07-22 15:46:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:46:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:46:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 15:46:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 15:46:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:46:57 --> Final output sent to browser
DEBUG - 2017-07-22 15:46:57 --> Total execution time: 0.0460
INFO - 2017-07-22 12:24:29 --> Config Class Initialized
INFO - 2017-07-22 12:24:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:24:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:24:29 --> Utf8 Class Initialized
INFO - 2017-07-22 12:24:29 --> URI Class Initialized
INFO - 2017-07-22 12:24:29 --> Router Class Initialized
INFO - 2017-07-22 12:24:29 --> Output Class Initialized
INFO - 2017-07-22 12:24:29 --> Security Class Initialized
DEBUG - 2017-07-22 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:24:29 --> Input Class Initialized
INFO - 2017-07-22 12:24:29 --> Language Class Initialized
INFO - 2017-07-22 12:24:29 --> Loader Class Initialized
INFO - 2017-07-22 12:24:29 --> Helper loaded: common_helper
INFO - 2017-07-22 12:24:29 --> Database Driver Class Initialized
INFO - 2017-07-22 12:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:24:29 --> Email Class Initialized
INFO - 2017-07-22 12:24:29 --> Controller Class Initialized
INFO - 2017-07-22 12:24:29 --> Helper loaded: form_helper
INFO - 2017-07-22 12:24:29 --> Form Validation Class Initialized
INFO - 2017-07-22 12:24:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:24:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:24:29 --> Model Class Initialized
INFO - 2017-07-22 12:24:29 --> Model Class Initialized
INFO - 2017-07-22 15:54:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:54:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:54:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 12:33:40 --> Config Class Initialized
INFO - 2017-07-22 12:33:40 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:33:40 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:33:40 --> Utf8 Class Initialized
INFO - 2017-07-22 12:33:40 --> URI Class Initialized
INFO - 2017-07-22 12:33:40 --> Router Class Initialized
INFO - 2017-07-22 12:33:40 --> Output Class Initialized
INFO - 2017-07-22 12:33:40 --> Security Class Initialized
DEBUG - 2017-07-22 12:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:33:40 --> Input Class Initialized
INFO - 2017-07-22 12:33:40 --> Language Class Initialized
INFO - 2017-07-22 12:33:40 --> Loader Class Initialized
INFO - 2017-07-22 12:33:40 --> Helper loaded: common_helper
INFO - 2017-07-22 12:33:40 --> Database Driver Class Initialized
INFO - 2017-07-22 12:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:33:40 --> Email Class Initialized
INFO - 2017-07-22 12:33:40 --> Controller Class Initialized
INFO - 2017-07-22 12:33:40 --> Helper loaded: form_helper
INFO - 2017-07-22 12:33:40 --> Form Validation Class Initialized
INFO - 2017-07-22 12:33:40 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:33:40 --> Helper loaded: url_helper
INFO - 2017-07-22 12:33:40 --> Model Class Initialized
INFO - 2017-07-22 12:33:40 --> Model Class Initialized
INFO - 2017-07-22 16:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:03:40 --> Final output sent to browser
DEBUG - 2017-07-22 16:03:40 --> Total execution time: 0.0523
INFO - 2017-07-22 12:34:06 --> Config Class Initialized
INFO - 2017-07-22 12:34:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:34:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:34:06 --> Utf8 Class Initialized
INFO - 2017-07-22 12:34:06 --> URI Class Initialized
INFO - 2017-07-22 12:34:06 --> Router Class Initialized
INFO - 2017-07-22 12:34:06 --> Output Class Initialized
INFO - 2017-07-22 12:34:06 --> Security Class Initialized
DEBUG - 2017-07-22 12:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:34:06 --> Input Class Initialized
INFO - 2017-07-22 12:34:06 --> Language Class Initialized
INFO - 2017-07-22 12:34:06 --> Loader Class Initialized
INFO - 2017-07-22 12:34:06 --> Helper loaded: common_helper
INFO - 2017-07-22 12:34:06 --> Database Driver Class Initialized
INFO - 2017-07-22 12:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:34:06 --> Email Class Initialized
INFO - 2017-07-22 12:34:06 --> Controller Class Initialized
INFO - 2017-07-22 12:34:06 --> Helper loaded: form_helper
INFO - 2017-07-22 12:34:06 --> Form Validation Class Initialized
INFO - 2017-07-22 12:34:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:34:06 --> Helper loaded: url_helper
INFO - 2017-07-22 12:34:06 --> Model Class Initialized
INFO - 2017-07-22 12:34:06 --> Model Class Initialized
INFO - 2017-07-22 12:34:55 --> Config Class Initialized
INFO - 2017-07-22 12:34:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:34:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:34:55 --> Utf8 Class Initialized
INFO - 2017-07-22 12:34:55 --> URI Class Initialized
INFO - 2017-07-22 12:34:55 --> Router Class Initialized
INFO - 2017-07-22 12:34:55 --> Output Class Initialized
INFO - 2017-07-22 12:34:55 --> Security Class Initialized
DEBUG - 2017-07-22 12:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:34:55 --> Input Class Initialized
INFO - 2017-07-22 12:34:55 --> Language Class Initialized
INFO - 2017-07-22 12:34:55 --> Loader Class Initialized
INFO - 2017-07-22 12:34:55 --> Helper loaded: common_helper
INFO - 2017-07-22 12:34:55 --> Database Driver Class Initialized
INFO - 2017-07-22 12:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:34:55 --> Email Class Initialized
INFO - 2017-07-22 12:34:55 --> Controller Class Initialized
INFO - 2017-07-22 12:34:55 --> Helper loaded: form_helper
INFO - 2017-07-22 12:34:55 --> Form Validation Class Initialized
INFO - 2017-07-22 12:34:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:34:55 --> Helper loaded: url_helper
INFO - 2017-07-22 12:34:55 --> Model Class Initialized
INFO - 2017-07-22 12:34:55 --> Model Class Initialized
INFO - 2017-07-22 12:36:03 --> Config Class Initialized
INFO - 2017-07-22 12:36:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:36:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:36:03 --> Utf8 Class Initialized
INFO - 2017-07-22 12:36:03 --> URI Class Initialized
INFO - 2017-07-22 12:36:03 --> Router Class Initialized
INFO - 2017-07-22 12:36:03 --> Output Class Initialized
INFO - 2017-07-22 12:36:03 --> Security Class Initialized
DEBUG - 2017-07-22 12:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:36:03 --> Input Class Initialized
INFO - 2017-07-22 12:36:03 --> Language Class Initialized
INFO - 2017-07-22 12:36:03 --> Loader Class Initialized
INFO - 2017-07-22 12:36:03 --> Helper loaded: common_helper
INFO - 2017-07-22 12:36:03 --> Database Driver Class Initialized
INFO - 2017-07-22 12:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:36:03 --> Email Class Initialized
INFO - 2017-07-22 12:36:03 --> Controller Class Initialized
INFO - 2017-07-22 12:36:03 --> Helper loaded: form_helper
INFO - 2017-07-22 12:36:03 --> Form Validation Class Initialized
INFO - 2017-07-22 12:36:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:36:03 --> Helper loaded: url_helper
INFO - 2017-07-22 12:36:03 --> Model Class Initialized
INFO - 2017-07-22 12:36:03 --> Model Class Initialized
INFO - 2017-07-22 12:36:12 --> Config Class Initialized
INFO - 2017-07-22 12:36:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:36:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:36:12 --> Utf8 Class Initialized
INFO - 2017-07-22 12:36:12 --> URI Class Initialized
INFO - 2017-07-22 12:36:12 --> Router Class Initialized
INFO - 2017-07-22 12:36:12 --> Output Class Initialized
INFO - 2017-07-22 12:36:12 --> Security Class Initialized
DEBUG - 2017-07-22 12:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:36:12 --> Input Class Initialized
INFO - 2017-07-22 12:36:12 --> Language Class Initialized
INFO - 2017-07-22 12:36:12 --> Loader Class Initialized
INFO - 2017-07-22 12:36:12 --> Helper loaded: common_helper
INFO - 2017-07-22 12:36:12 --> Database Driver Class Initialized
INFO - 2017-07-22 12:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:36:12 --> Email Class Initialized
INFO - 2017-07-22 12:36:12 --> Controller Class Initialized
INFO - 2017-07-22 12:36:12 --> Helper loaded: form_helper
INFO - 2017-07-22 12:36:12 --> Form Validation Class Initialized
INFO - 2017-07-22 12:36:12 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:36:12 --> Helper loaded: url_helper
INFO - 2017-07-22 12:36:12 --> Model Class Initialized
INFO - 2017-07-22 12:36:12 --> Model Class Initialized
INFO - 2017-07-22 16:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:06:12 --> Final output sent to browser
DEBUG - 2017-07-22 16:06:12 --> Total execution time: 0.0489
INFO - 2017-07-22 12:36:19 --> Config Class Initialized
INFO - 2017-07-22 12:36:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:36:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:36:19 --> Utf8 Class Initialized
INFO - 2017-07-22 12:36:19 --> URI Class Initialized
INFO - 2017-07-22 12:36:19 --> Router Class Initialized
INFO - 2017-07-22 12:36:19 --> Output Class Initialized
INFO - 2017-07-22 12:36:19 --> Security Class Initialized
DEBUG - 2017-07-22 12:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:36:19 --> Input Class Initialized
INFO - 2017-07-22 12:36:19 --> Language Class Initialized
INFO - 2017-07-22 12:36:19 --> Loader Class Initialized
INFO - 2017-07-22 12:36:19 --> Helper loaded: common_helper
INFO - 2017-07-22 12:36:19 --> Database Driver Class Initialized
INFO - 2017-07-22 12:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:36:19 --> Email Class Initialized
INFO - 2017-07-22 12:36:19 --> Controller Class Initialized
INFO - 2017-07-22 12:36:19 --> Helper loaded: form_helper
INFO - 2017-07-22 12:36:19 --> Form Validation Class Initialized
INFO - 2017-07-22 12:36:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:36:19 --> Helper loaded: url_helper
INFO - 2017-07-22 12:36:19 --> Model Class Initialized
INFO - 2017-07-22 12:36:19 --> Model Class Initialized
INFO - 2017-07-22 12:37:03 --> Config Class Initialized
INFO - 2017-07-22 12:37:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:37:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:37:03 --> Utf8 Class Initialized
INFO - 2017-07-22 12:37:03 --> URI Class Initialized
INFO - 2017-07-22 12:37:03 --> Router Class Initialized
INFO - 2017-07-22 12:37:03 --> Output Class Initialized
INFO - 2017-07-22 12:37:03 --> Security Class Initialized
DEBUG - 2017-07-22 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:37:03 --> Input Class Initialized
INFO - 2017-07-22 12:37:03 --> Language Class Initialized
INFO - 2017-07-22 12:37:03 --> Loader Class Initialized
INFO - 2017-07-22 12:37:03 --> Helper loaded: common_helper
INFO - 2017-07-22 12:37:03 --> Database Driver Class Initialized
INFO - 2017-07-22 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:37:03 --> Email Class Initialized
INFO - 2017-07-22 12:37:03 --> Controller Class Initialized
INFO - 2017-07-22 12:37:03 --> Helper loaded: form_helper
INFO - 2017-07-22 12:37:03 --> Form Validation Class Initialized
INFO - 2017-07-22 12:37:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:37:03 --> Helper loaded: url_helper
INFO - 2017-07-22 12:37:03 --> Model Class Initialized
INFO - 2017-07-22 12:37:03 --> Model Class Initialized
INFO - 2017-07-22 12:37:06 --> Config Class Initialized
INFO - 2017-07-22 12:37:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:37:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:37:06 --> Utf8 Class Initialized
INFO - 2017-07-22 12:37:06 --> URI Class Initialized
INFO - 2017-07-22 12:37:06 --> Router Class Initialized
INFO - 2017-07-22 12:37:06 --> Output Class Initialized
INFO - 2017-07-22 12:37:06 --> Security Class Initialized
DEBUG - 2017-07-22 12:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:37:06 --> Input Class Initialized
INFO - 2017-07-22 12:37:06 --> Language Class Initialized
INFO - 2017-07-22 12:37:06 --> Loader Class Initialized
INFO - 2017-07-22 12:37:06 --> Helper loaded: common_helper
INFO - 2017-07-22 12:37:06 --> Database Driver Class Initialized
INFO - 2017-07-22 12:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:37:06 --> Email Class Initialized
INFO - 2017-07-22 12:37:06 --> Controller Class Initialized
INFO - 2017-07-22 12:37:06 --> Helper loaded: form_helper
INFO - 2017-07-22 12:37:06 --> Form Validation Class Initialized
INFO - 2017-07-22 12:37:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:37:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:37:06 --> Helper loaded: url_helper
INFO - 2017-07-22 12:37:06 --> Model Class Initialized
INFO - 2017-07-22 12:37:06 --> Model Class Initialized
INFO - 2017-07-22 16:07:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:07:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:07:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:07:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:07:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:07:06 --> Final output sent to browser
DEBUG - 2017-07-22 16:07:06 --> Total execution time: 0.0500
INFO - 2017-07-22 12:37:07 --> Config Class Initialized
INFO - 2017-07-22 12:37:07 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:37:07 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:37:07 --> Utf8 Class Initialized
INFO - 2017-07-22 12:37:07 --> URI Class Initialized
INFO - 2017-07-22 12:37:07 --> Router Class Initialized
INFO - 2017-07-22 12:37:07 --> Output Class Initialized
INFO - 2017-07-22 12:37:07 --> Security Class Initialized
DEBUG - 2017-07-22 12:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:37:07 --> Input Class Initialized
INFO - 2017-07-22 12:37:07 --> Language Class Initialized
INFO - 2017-07-22 12:37:07 --> Loader Class Initialized
INFO - 2017-07-22 12:37:07 --> Helper loaded: common_helper
INFO - 2017-07-22 12:37:07 --> Database Driver Class Initialized
INFO - 2017-07-22 12:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:37:07 --> Email Class Initialized
INFO - 2017-07-22 12:37:07 --> Controller Class Initialized
INFO - 2017-07-22 12:37:07 --> Helper loaded: form_helper
INFO - 2017-07-22 12:37:07 --> Form Validation Class Initialized
INFO - 2017-07-22 12:37:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:37:07 --> Helper loaded: url_helper
INFO - 2017-07-22 12:37:07 --> Model Class Initialized
INFO - 2017-07-22 12:37:07 --> Model Class Initialized
INFO - 2017-07-22 16:07:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:07:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:07:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:07:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:07:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:07:07 --> Final output sent to browser
DEBUG - 2017-07-22 16:07:07 --> Total execution time: 0.0495
INFO - 2017-07-22 12:37:13 --> Config Class Initialized
INFO - 2017-07-22 12:37:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:37:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:37:13 --> Utf8 Class Initialized
INFO - 2017-07-22 12:37:13 --> URI Class Initialized
INFO - 2017-07-22 12:37:13 --> Router Class Initialized
INFO - 2017-07-22 12:37:13 --> Output Class Initialized
INFO - 2017-07-22 12:37:13 --> Security Class Initialized
DEBUG - 2017-07-22 12:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:37:13 --> Input Class Initialized
INFO - 2017-07-22 12:37:13 --> Language Class Initialized
INFO - 2017-07-22 12:37:13 --> Loader Class Initialized
INFO - 2017-07-22 12:37:13 --> Helper loaded: common_helper
INFO - 2017-07-22 12:37:13 --> Database Driver Class Initialized
INFO - 2017-07-22 12:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:37:13 --> Email Class Initialized
INFO - 2017-07-22 12:37:13 --> Controller Class Initialized
INFO - 2017-07-22 12:37:13 --> Helper loaded: form_helper
INFO - 2017-07-22 12:37:13 --> Form Validation Class Initialized
INFO - 2017-07-22 12:37:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:37:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:37:13 --> Helper loaded: url_helper
INFO - 2017-07-22 12:37:13 --> Model Class Initialized
INFO - 2017-07-22 12:37:13 --> Model Class Initialized
INFO - 2017-07-22 12:41:38 --> Config Class Initialized
INFO - 2017-07-22 12:41:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:41:38 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:41:38 --> Utf8 Class Initialized
INFO - 2017-07-22 12:41:38 --> URI Class Initialized
INFO - 2017-07-22 12:41:38 --> Router Class Initialized
INFO - 2017-07-22 12:41:38 --> Output Class Initialized
INFO - 2017-07-22 12:41:38 --> Security Class Initialized
DEBUG - 2017-07-22 12:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:41:38 --> Input Class Initialized
INFO - 2017-07-22 12:41:38 --> Language Class Initialized
INFO - 2017-07-22 12:41:38 --> Loader Class Initialized
INFO - 2017-07-22 12:41:38 --> Helper loaded: common_helper
INFO - 2017-07-22 12:41:38 --> Database Driver Class Initialized
INFO - 2017-07-22 12:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:41:38 --> Email Class Initialized
INFO - 2017-07-22 12:41:38 --> Controller Class Initialized
INFO - 2017-07-22 12:41:38 --> Helper loaded: form_helper
INFO - 2017-07-22 12:41:38 --> Form Validation Class Initialized
INFO - 2017-07-22 12:41:38 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:41:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:41:38 --> Helper loaded: url_helper
INFO - 2017-07-22 12:41:38 --> Model Class Initialized
INFO - 2017-07-22 12:41:38 --> Model Class Initialized
INFO - 2017-07-22 12:51:23 --> Config Class Initialized
INFO - 2017-07-22 12:51:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:51:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:51:23 --> Utf8 Class Initialized
INFO - 2017-07-22 12:51:23 --> URI Class Initialized
INFO - 2017-07-22 12:51:23 --> Router Class Initialized
INFO - 2017-07-22 12:51:23 --> Output Class Initialized
INFO - 2017-07-22 12:51:23 --> Security Class Initialized
DEBUG - 2017-07-22 12:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:51:23 --> Input Class Initialized
INFO - 2017-07-22 12:51:23 --> Language Class Initialized
ERROR - 2017-07-22 12:51:23 --> syntax error, unexpected '}'
ERROR - 2017-07-22 12:51:23 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 175
INFO - 2017-07-22 12:51:42 --> Config Class Initialized
INFO - 2017-07-22 12:51:42 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:51:42 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:51:42 --> Utf8 Class Initialized
INFO - 2017-07-22 12:51:42 --> URI Class Initialized
INFO - 2017-07-22 12:51:42 --> Router Class Initialized
INFO - 2017-07-22 12:51:42 --> Output Class Initialized
INFO - 2017-07-22 12:51:42 --> Security Class Initialized
DEBUG - 2017-07-22 12:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:51:42 --> Input Class Initialized
INFO - 2017-07-22 12:51:42 --> Language Class Initialized
ERROR - 2017-07-22 12:51:42 --> syntax error, unexpected end of file, expecting function (T_FUNCTION)
ERROR - 2017-07-22 12:51:42 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 266
INFO - 2017-07-22 12:53:03 --> Config Class Initialized
INFO - 2017-07-22 12:53:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:53:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:53:03 --> Utf8 Class Initialized
INFO - 2017-07-22 12:53:03 --> URI Class Initialized
INFO - 2017-07-22 12:53:03 --> Router Class Initialized
INFO - 2017-07-22 12:53:03 --> Output Class Initialized
INFO - 2017-07-22 12:53:03 --> Security Class Initialized
DEBUG - 2017-07-22 12:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:53:03 --> Input Class Initialized
INFO - 2017-07-22 12:53:03 --> Language Class Initialized
INFO - 2017-07-22 12:53:03 --> Loader Class Initialized
INFO - 2017-07-22 12:53:03 --> Helper loaded: common_helper
INFO - 2017-07-22 12:53:03 --> Database Driver Class Initialized
INFO - 2017-07-22 12:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:53:03 --> Email Class Initialized
INFO - 2017-07-22 12:53:03 --> Controller Class Initialized
INFO - 2017-07-22 12:53:03 --> Helper loaded: form_helper
INFO - 2017-07-22 12:53:03 --> Form Validation Class Initialized
INFO - 2017-07-22 12:53:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:53:03 --> Helper loaded: url_helper
INFO - 2017-07-22 12:53:03 --> Model Class Initialized
INFO - 2017-07-22 12:53:03 --> Model Class Initialized
ERROR - 2017-07-22 16:23:03 --> Undefined variable: news_content
ERROR - 2017-07-22 16:23:03 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 176
ERROR - 2017-07-22 16:23:03 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:23:03 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 205
ERROR - 2017-07-22 16:23:03 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news1', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
ERROR - 2017-07-22 16:23:03 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:23:03 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 214
ERROR - 2017-07-22 16:23:03 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:23:03 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 215
ERROR - 2017-07-22 16:23:03 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:23:03 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 217
INFO - 2017-07-22 12:53:03 --> Config Class Initialized
INFO - 2017-07-22 12:53:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:53:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:53:03 --> Utf8 Class Initialized
INFO - 2017-07-22 12:53:03 --> URI Class Initialized
INFO - 2017-07-22 12:53:03 --> Router Class Initialized
INFO - 2017-07-22 12:53:03 --> Output Class Initialized
INFO - 2017-07-22 12:53:03 --> Security Class Initialized
DEBUG - 2017-07-22 12:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:53:03 --> Input Class Initialized
INFO - 2017-07-22 12:53:03 --> Language Class Initialized
INFO - 2017-07-22 12:53:03 --> Loader Class Initialized
INFO - 2017-07-22 12:53:03 --> Helper loaded: common_helper
INFO - 2017-07-22 12:53:03 --> Database Driver Class Initialized
INFO - 2017-07-22 12:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:53:03 --> Email Class Initialized
INFO - 2017-07-22 12:53:03 --> Controller Class Initialized
INFO - 2017-07-22 12:53:04 --> Helper loaded: form_helper
INFO - 2017-07-22 12:53:04 --> Form Validation Class Initialized
INFO - 2017-07-22 12:53:04 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:53:04 --> Helper loaded: url_helper
INFO - 2017-07-22 12:53:04 --> Model Class Initialized
INFO - 2017-07-22 12:53:04 --> Model Class Initialized
INFO - 2017-07-22 16:23:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:23:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:23:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:23:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 16:23:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:23:04 --> Final output sent to browser
DEBUG - 2017-07-22 16:23:04 --> Total execution time: 0.0446
INFO - 2017-07-22 12:53:14 --> Config Class Initialized
INFO - 2017-07-22 12:53:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:53:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:53:14 --> Utf8 Class Initialized
INFO - 2017-07-22 12:53:14 --> URI Class Initialized
INFO - 2017-07-22 12:53:14 --> Router Class Initialized
INFO - 2017-07-22 12:53:14 --> Output Class Initialized
INFO - 2017-07-22 12:53:14 --> Security Class Initialized
DEBUG - 2017-07-22 12:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:53:14 --> Input Class Initialized
INFO - 2017-07-22 12:53:14 --> Language Class Initialized
INFO - 2017-07-22 12:53:14 --> Loader Class Initialized
INFO - 2017-07-22 12:53:14 --> Helper loaded: common_helper
INFO - 2017-07-22 12:53:14 --> Database Driver Class Initialized
INFO - 2017-07-22 12:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:53:14 --> Email Class Initialized
INFO - 2017-07-22 12:53:14 --> Controller Class Initialized
INFO - 2017-07-22 12:53:14 --> Helper loaded: form_helper
INFO - 2017-07-22 12:53:14 --> Form Validation Class Initialized
INFO - 2017-07-22 12:53:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:53:14 --> Helper loaded: url_helper
INFO - 2017-07-22 12:53:14 --> Model Class Initialized
INFO - 2017-07-22 12:53:14 --> Model Class Initialized
INFO - 2017-07-22 16:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:23:14 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:23:14 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 16:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 16:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 16:23:14 --> Final output sent to browser
DEBUG - 2017-07-22 16:23:14 --> Total execution time: 0.0669
INFO - 2017-07-22 12:53:17 --> Config Class Initialized
INFO - 2017-07-22 12:53:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:53:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:53:17 --> Utf8 Class Initialized
INFO - 2017-07-22 12:53:17 --> URI Class Initialized
INFO - 2017-07-22 12:53:17 --> Router Class Initialized
INFO - 2017-07-22 12:53:17 --> Output Class Initialized
INFO - 2017-07-22 12:53:17 --> Security Class Initialized
DEBUG - 2017-07-22 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:53:17 --> Input Class Initialized
INFO - 2017-07-22 12:53:17 --> Language Class Initialized
INFO - 2017-07-22 12:53:17 --> Loader Class Initialized
INFO - 2017-07-22 12:53:17 --> Helper loaded: common_helper
INFO - 2017-07-22 12:53:17 --> Database Driver Class Initialized
INFO - 2017-07-22 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:53:17 --> Email Class Initialized
INFO - 2017-07-22 12:53:17 --> Controller Class Initialized
INFO - 2017-07-22 12:53:17 --> Helper loaded: form_helper
INFO - 2017-07-22 12:53:17 --> Form Validation Class Initialized
INFO - 2017-07-22 12:53:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:53:17 --> Helper loaded: url_helper
INFO - 2017-07-22 12:53:17 --> Model Class Initialized
INFO - 2017-07-22 12:53:17 --> Model Class Initialized
INFO - 2017-07-22 16:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:23:17 --> Final output sent to browser
DEBUG - 2017-07-22 16:23:17 --> Total execution time: 0.0610
INFO - 2017-07-22 12:53:25 --> Config Class Initialized
INFO - 2017-07-22 12:53:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:53:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:53:25 --> Utf8 Class Initialized
INFO - 2017-07-22 12:53:25 --> URI Class Initialized
INFO - 2017-07-22 12:53:25 --> Router Class Initialized
INFO - 2017-07-22 12:53:25 --> Output Class Initialized
INFO - 2017-07-22 12:53:25 --> Security Class Initialized
DEBUG - 2017-07-22 12:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:53:25 --> Input Class Initialized
INFO - 2017-07-22 12:53:25 --> Language Class Initialized
INFO - 2017-07-22 12:53:25 --> Loader Class Initialized
INFO - 2017-07-22 12:53:25 --> Helper loaded: common_helper
INFO - 2017-07-22 12:53:25 --> Database Driver Class Initialized
INFO - 2017-07-22 12:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:53:25 --> Email Class Initialized
INFO - 2017-07-22 12:53:25 --> Controller Class Initialized
INFO - 2017-07-22 12:53:25 --> Helper loaded: form_helper
INFO - 2017-07-22 12:53:25 --> Form Validation Class Initialized
INFO - 2017-07-22 12:53:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:53:25 --> Helper loaded: url_helper
INFO - 2017-07-22 12:53:25 --> Model Class Initialized
INFO - 2017-07-22 12:53:25 --> Model Class Initialized
ERROR - 2017-07-22 16:23:25 --> Undefined variable: news_content
ERROR - 2017-07-22 16:23:25 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 176
ERROR - 2017-07-22 16:23:25 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:23:25 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 205
ERROR - 2017-07-22 16:23:25 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news2 w344', `news_article_type` = '2', `news_category_id` = '1'
WHERE `newsID` = '2'
ERROR - 2017-07-22 16:23:25 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:23:25 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 214
ERROR - 2017-07-22 16:23:25 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:23:25 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 215
ERROR - 2017-07-22 16:23:25 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:23:25 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 217
INFO - 2017-07-22 12:53:25 --> Config Class Initialized
INFO - 2017-07-22 12:53:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:53:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:53:25 --> Utf8 Class Initialized
INFO - 2017-07-22 12:53:25 --> URI Class Initialized
INFO - 2017-07-22 12:53:25 --> Router Class Initialized
INFO - 2017-07-22 12:53:25 --> Output Class Initialized
INFO - 2017-07-22 12:53:25 --> Security Class Initialized
DEBUG - 2017-07-22 12:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:53:25 --> Input Class Initialized
INFO - 2017-07-22 12:53:25 --> Language Class Initialized
INFO - 2017-07-22 12:53:25 --> Loader Class Initialized
INFO - 2017-07-22 12:53:25 --> Helper loaded: common_helper
INFO - 2017-07-22 12:53:25 --> Database Driver Class Initialized
INFO - 2017-07-22 12:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:53:25 --> Email Class Initialized
INFO - 2017-07-22 12:53:25 --> Controller Class Initialized
INFO - 2017-07-22 12:53:25 --> Helper loaded: form_helper
INFO - 2017-07-22 12:53:25 --> Form Validation Class Initialized
INFO - 2017-07-22 12:53:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:53:25 --> Helper loaded: url_helper
INFO - 2017-07-22 12:53:25 --> Model Class Initialized
INFO - 2017-07-22 12:53:25 --> Model Class Initialized
INFO - 2017-07-22 16:23:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:23:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:23:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:23:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2017-07-22 16:23:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:23:25 --> Final output sent to browser
DEBUG - 2017-07-22 16:23:25 --> Total execution time: 0.0454
INFO - 2017-07-22 12:54:44 --> Config Class Initialized
INFO - 2017-07-22 12:54:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:54:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:54:44 --> Utf8 Class Initialized
INFO - 2017-07-22 12:54:44 --> URI Class Initialized
INFO - 2017-07-22 12:54:44 --> Router Class Initialized
INFO - 2017-07-22 12:54:44 --> Output Class Initialized
INFO - 2017-07-22 12:54:44 --> Security Class Initialized
DEBUG - 2017-07-22 12:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:54:44 --> Input Class Initialized
INFO - 2017-07-22 12:54:44 --> Language Class Initialized
INFO - 2017-07-22 12:54:44 --> Loader Class Initialized
INFO - 2017-07-22 12:54:44 --> Helper loaded: common_helper
INFO - 2017-07-22 12:54:44 --> Database Driver Class Initialized
INFO - 2017-07-22 12:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:54:44 --> Email Class Initialized
INFO - 2017-07-22 12:54:44 --> Controller Class Initialized
INFO - 2017-07-22 12:54:44 --> Helper loaded: form_helper
INFO - 2017-07-22 12:54:44 --> Form Validation Class Initialized
INFO - 2017-07-22 12:54:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:54:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:54:44 --> Helper loaded: url_helper
INFO - 2017-07-22 12:54:44 --> Model Class Initialized
INFO - 2017-07-22 12:54:44 --> Model Class Initialized
INFO - 2017-07-22 16:24:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:24:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:24:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 16:24:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 16:24:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 16:24:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 16:24:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 16:24:44 --> Final output sent to browser
DEBUG - 2017-07-22 16:24:44 --> Total execution time: 0.0678
INFO - 2017-07-22 12:54:46 --> Config Class Initialized
INFO - 2017-07-22 12:54:46 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:54:46 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:54:46 --> Utf8 Class Initialized
INFO - 2017-07-22 12:54:46 --> URI Class Initialized
INFO - 2017-07-22 12:54:46 --> Router Class Initialized
INFO - 2017-07-22 12:54:46 --> Output Class Initialized
INFO - 2017-07-22 12:54:46 --> Security Class Initialized
DEBUG - 2017-07-22 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:54:46 --> Input Class Initialized
INFO - 2017-07-22 12:54:46 --> Language Class Initialized
INFO - 2017-07-22 12:54:46 --> Loader Class Initialized
INFO - 2017-07-22 12:54:46 --> Helper loaded: common_helper
INFO - 2017-07-22 12:54:46 --> Database Driver Class Initialized
INFO - 2017-07-22 12:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:54:46 --> Email Class Initialized
INFO - 2017-07-22 12:54:46 --> Controller Class Initialized
INFO - 2017-07-22 12:54:46 --> Helper loaded: form_helper
INFO - 2017-07-22 12:54:46 --> Form Validation Class Initialized
INFO - 2017-07-22 12:54:46 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:54:46 --> Helper loaded: url_helper
INFO - 2017-07-22 12:54:46 --> Model Class Initialized
INFO - 2017-07-22 12:54:46 --> Model Class Initialized
INFO - 2017-07-22 16:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:24:46 --> Final output sent to browser
DEBUG - 2017-07-22 16:24:46 --> Total execution time: 0.0461
INFO - 2017-07-22 12:54:52 --> Config Class Initialized
INFO - 2017-07-22 12:54:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:54:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:54:52 --> Utf8 Class Initialized
INFO - 2017-07-22 12:54:52 --> URI Class Initialized
INFO - 2017-07-22 12:54:52 --> Router Class Initialized
INFO - 2017-07-22 12:54:52 --> Output Class Initialized
INFO - 2017-07-22 12:54:52 --> Security Class Initialized
DEBUG - 2017-07-22 12:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:54:52 --> Input Class Initialized
INFO - 2017-07-22 12:54:52 --> Language Class Initialized
INFO - 2017-07-22 12:54:52 --> Loader Class Initialized
INFO - 2017-07-22 12:54:52 --> Helper loaded: common_helper
INFO - 2017-07-22 12:54:52 --> Database Driver Class Initialized
INFO - 2017-07-22 12:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:54:52 --> Email Class Initialized
INFO - 2017-07-22 12:54:52 --> Controller Class Initialized
INFO - 2017-07-22 12:54:52 --> Helper loaded: form_helper
INFO - 2017-07-22 12:54:52 --> Form Validation Class Initialized
INFO - 2017-07-22 12:54:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:54:52 --> Helper loaded: url_helper
INFO - 2017-07-22 12:54:52 --> Model Class Initialized
INFO - 2017-07-22 12:54:52 --> Model Class Initialized
ERROR - 2017-07-22 16:24:52 --> Undefined variable: news_content
ERROR - 2017-07-22 16:24:52 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 177
ERROR - 2017-07-22 16:24:52 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:24:52 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 206
ERROR - 2017-07-22 16:24:52 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news1', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
ERROR - 2017-07-22 16:24:52 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:24:52 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 215
ERROR - 2017-07-22 16:24:52 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:24:52 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 216
ERROR - 2017-07-22 16:24:52 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:24:52 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 218
INFO - 2017-07-22 12:54:52 --> Config Class Initialized
INFO - 2017-07-22 12:54:52 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:54:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:54:52 --> Utf8 Class Initialized
INFO - 2017-07-22 12:54:52 --> URI Class Initialized
INFO - 2017-07-22 12:54:52 --> Router Class Initialized
INFO - 2017-07-22 12:54:52 --> Output Class Initialized
INFO - 2017-07-22 12:54:52 --> Security Class Initialized
DEBUG - 2017-07-22 12:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:54:52 --> Input Class Initialized
INFO - 2017-07-22 12:54:52 --> Language Class Initialized
INFO - 2017-07-22 12:54:52 --> Loader Class Initialized
INFO - 2017-07-22 12:54:52 --> Helper loaded: common_helper
INFO - 2017-07-22 12:54:52 --> Database Driver Class Initialized
INFO - 2017-07-22 12:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:54:52 --> Email Class Initialized
INFO - 2017-07-22 12:54:52 --> Controller Class Initialized
INFO - 2017-07-22 12:54:52 --> Helper loaded: form_helper
INFO - 2017-07-22 12:54:52 --> Form Validation Class Initialized
INFO - 2017-07-22 12:54:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:54:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:54:52 --> Helper loaded: url_helper
INFO - 2017-07-22 12:54:52 --> Model Class Initialized
INFO - 2017-07-22 12:54:52 --> Model Class Initialized
INFO - 2017-07-22 16:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:24:52 --> Final output sent to browser
DEBUG - 2017-07-22 16:24:52 --> Total execution time: 0.0459
INFO - 2017-07-22 12:55:12 --> Config Class Initialized
INFO - 2017-07-22 12:55:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:55:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:55:12 --> Utf8 Class Initialized
INFO - 2017-07-22 12:55:12 --> URI Class Initialized
INFO - 2017-07-22 12:55:12 --> Router Class Initialized
INFO - 2017-07-22 12:55:12 --> Output Class Initialized
INFO - 2017-07-22 12:55:12 --> Security Class Initialized
DEBUG - 2017-07-22 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:55:12 --> Input Class Initialized
INFO - 2017-07-22 12:55:12 --> Language Class Initialized
INFO - 2017-07-22 12:55:12 --> Loader Class Initialized
INFO - 2017-07-22 12:55:12 --> Helper loaded: common_helper
INFO - 2017-07-22 12:55:12 --> Database Driver Class Initialized
INFO - 2017-07-22 12:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:55:12 --> Email Class Initialized
INFO - 2017-07-22 12:55:12 --> Controller Class Initialized
INFO - 2017-07-22 12:55:12 --> Helper loaded: form_helper
INFO - 2017-07-22 12:55:12 --> Form Validation Class Initialized
INFO - 2017-07-22 12:55:12 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:55:12 --> Helper loaded: url_helper
INFO - 2017-07-22 12:55:12 --> Model Class Initialized
INFO - 2017-07-22 12:55:12 --> Model Class Initialized
ERROR - 2017-07-22 16:25:12 --> Undefined variable: news_content
ERROR - 2017-07-22 16:25:12 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 177
ERROR - 2017-07-22 16:25:12 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:25:12 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 206
ERROR - 2017-07-22 16:25:12 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news1', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
ERROR - 2017-07-22 16:25:12 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:25:12 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 215
ERROR - 2017-07-22 16:25:12 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:25:12 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 216
ERROR - 2017-07-22 16:25:12 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:25:12 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 218
INFO - 2017-07-22 12:55:12 --> Config Class Initialized
INFO - 2017-07-22 12:55:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:55:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:55:12 --> Utf8 Class Initialized
INFO - 2017-07-22 12:55:12 --> URI Class Initialized
INFO - 2017-07-22 12:55:12 --> Router Class Initialized
INFO - 2017-07-22 12:55:12 --> Output Class Initialized
INFO - 2017-07-22 12:55:12 --> Security Class Initialized
DEBUG - 2017-07-22 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:55:12 --> Input Class Initialized
INFO - 2017-07-22 12:55:12 --> Language Class Initialized
INFO - 2017-07-22 12:55:12 --> Loader Class Initialized
INFO - 2017-07-22 12:55:12 --> Helper loaded: common_helper
INFO - 2017-07-22 12:55:12 --> Database Driver Class Initialized
INFO - 2017-07-22 12:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:55:12 --> Email Class Initialized
INFO - 2017-07-22 12:55:12 --> Controller Class Initialized
INFO - 2017-07-22 12:55:12 --> Helper loaded: form_helper
INFO - 2017-07-22 12:55:12 --> Form Validation Class Initialized
INFO - 2017-07-22 12:55:12 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:55:12 --> Helper loaded: url_helper
INFO - 2017-07-22 12:55:12 --> Model Class Initialized
INFO - 2017-07-22 12:55:12 --> Model Class Initialized
INFO - 2017-07-22 16:25:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:25:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:25:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:25:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:25:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:25:12 --> Final output sent to browser
DEBUG - 2017-07-22 16:25:12 --> Total execution time: 0.0490
INFO - 2017-07-22 12:55:42 --> Config Class Initialized
INFO - 2017-07-22 12:55:42 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:55:42 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:55:42 --> Utf8 Class Initialized
INFO - 2017-07-22 12:55:42 --> URI Class Initialized
INFO - 2017-07-22 12:55:42 --> Router Class Initialized
INFO - 2017-07-22 12:55:42 --> Output Class Initialized
INFO - 2017-07-22 12:55:42 --> Security Class Initialized
DEBUG - 2017-07-22 12:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:55:42 --> Input Class Initialized
INFO - 2017-07-22 12:55:42 --> Language Class Initialized
INFO - 2017-07-22 12:55:42 --> Loader Class Initialized
INFO - 2017-07-22 12:55:42 --> Helper loaded: common_helper
INFO - 2017-07-22 12:55:42 --> Database Driver Class Initialized
INFO - 2017-07-22 12:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:55:42 --> Email Class Initialized
INFO - 2017-07-22 12:55:42 --> Controller Class Initialized
INFO - 2017-07-22 12:55:42 --> Helper loaded: form_helper
INFO - 2017-07-22 12:55:42 --> Form Validation Class Initialized
INFO - 2017-07-22 12:55:42 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:55:42 --> Helper loaded: url_helper
INFO - 2017-07-22 12:55:42 --> Model Class Initialized
INFO - 2017-07-22 12:55:42 --> Model Class Initialized
INFO - 2017-07-22 16:25:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:25:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:25:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:25:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:25:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:25:42 --> Final output sent to browser
DEBUG - 2017-07-22 16:25:42 --> Total execution time: 0.0497
INFO - 2017-07-22 12:55:44 --> Config Class Initialized
INFO - 2017-07-22 12:55:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:55:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:55:44 --> Utf8 Class Initialized
INFO - 2017-07-22 12:55:44 --> URI Class Initialized
INFO - 2017-07-22 12:55:44 --> Router Class Initialized
INFO - 2017-07-22 12:55:44 --> Output Class Initialized
INFO - 2017-07-22 12:55:44 --> Security Class Initialized
DEBUG - 2017-07-22 12:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:55:44 --> Input Class Initialized
INFO - 2017-07-22 12:55:44 --> Language Class Initialized
INFO - 2017-07-22 12:55:44 --> Loader Class Initialized
INFO - 2017-07-22 12:55:44 --> Helper loaded: common_helper
INFO - 2017-07-22 12:55:44 --> Database Driver Class Initialized
INFO - 2017-07-22 12:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:55:44 --> Email Class Initialized
INFO - 2017-07-22 12:55:44 --> Controller Class Initialized
INFO - 2017-07-22 12:55:44 --> Helper loaded: form_helper
INFO - 2017-07-22 12:55:44 --> Form Validation Class Initialized
INFO - 2017-07-22 12:55:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:55:44 --> Helper loaded: url_helper
INFO - 2017-07-22 12:55:44 --> Model Class Initialized
INFO - 2017-07-22 12:55:44 --> Model Class Initialized
ERROR - 2017-07-22 16:25:44 --> Undefined variable: news_content
ERROR - 2017-07-22 16:25:44 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 177
ERROR - 2017-07-22 16:25:44 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:25:44 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 207
ERROR - 2017-07-22 16:25:44 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news1', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
ERROR - 2017-07-22 16:25:44 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:25:44 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 216
ERROR - 2017-07-22 16:25:44 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:25:44 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 217
ERROR - 2017-07-22 16:25:44 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:25:44 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 219
INFO - 2017-07-22 12:55:44 --> Config Class Initialized
INFO - 2017-07-22 12:55:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:55:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:55:44 --> Utf8 Class Initialized
INFO - 2017-07-22 12:55:44 --> URI Class Initialized
INFO - 2017-07-22 12:55:44 --> Router Class Initialized
INFO - 2017-07-22 12:55:44 --> Output Class Initialized
INFO - 2017-07-22 12:55:44 --> Security Class Initialized
DEBUG - 2017-07-22 12:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:55:44 --> Input Class Initialized
INFO - 2017-07-22 12:55:44 --> Language Class Initialized
INFO - 2017-07-22 12:55:44 --> Loader Class Initialized
INFO - 2017-07-22 12:55:44 --> Helper loaded: common_helper
INFO - 2017-07-22 12:55:44 --> Database Driver Class Initialized
INFO - 2017-07-22 12:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:55:44 --> Email Class Initialized
INFO - 2017-07-22 12:55:44 --> Controller Class Initialized
INFO - 2017-07-22 12:55:44 --> Helper loaded: form_helper
INFO - 2017-07-22 12:55:44 --> Form Validation Class Initialized
INFO - 2017-07-22 12:55:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:55:44 --> Helper loaded: url_helper
INFO - 2017-07-22 12:55:44 --> Model Class Initialized
INFO - 2017-07-22 12:55:44 --> Model Class Initialized
INFO - 2017-07-22 16:25:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:25:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:25:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:25:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:25:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:25:44 --> Final output sent to browser
DEBUG - 2017-07-22 16:25:44 --> Total execution time: 0.0684
INFO - 2017-07-22 12:56:08 --> Config Class Initialized
INFO - 2017-07-22 12:56:08 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:56:08 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:56:08 --> Utf8 Class Initialized
INFO - 2017-07-22 12:56:08 --> URI Class Initialized
INFO - 2017-07-22 12:56:08 --> Router Class Initialized
INFO - 2017-07-22 12:56:08 --> Output Class Initialized
INFO - 2017-07-22 12:56:08 --> Security Class Initialized
DEBUG - 2017-07-22 12:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:56:08 --> Input Class Initialized
INFO - 2017-07-22 12:56:08 --> Language Class Initialized
INFO - 2017-07-22 12:56:08 --> Loader Class Initialized
INFO - 2017-07-22 12:56:08 --> Helper loaded: common_helper
INFO - 2017-07-22 12:56:08 --> Database Driver Class Initialized
INFO - 2017-07-22 12:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:56:08 --> Email Class Initialized
INFO - 2017-07-22 12:56:08 --> Controller Class Initialized
INFO - 2017-07-22 12:56:08 --> Helper loaded: form_helper
INFO - 2017-07-22 12:56:08 --> Form Validation Class Initialized
INFO - 2017-07-22 12:56:08 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:56:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:56:08 --> Helper loaded: url_helper
INFO - 2017-07-22 12:56:08 --> Model Class Initialized
INFO - 2017-07-22 12:56:08 --> Model Class Initialized
INFO - 2017-07-22 16:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:26:08 --> Final output sent to browser
DEBUG - 2017-07-22 16:26:08 --> Total execution time: 0.0459
INFO - 2017-07-22 12:57:14 --> Config Class Initialized
INFO - 2017-07-22 12:57:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:57:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:57:14 --> Utf8 Class Initialized
INFO - 2017-07-22 12:57:14 --> URI Class Initialized
INFO - 2017-07-22 12:57:14 --> Router Class Initialized
INFO - 2017-07-22 12:57:14 --> Output Class Initialized
INFO - 2017-07-22 12:57:14 --> Security Class Initialized
DEBUG - 2017-07-22 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:57:14 --> Input Class Initialized
INFO - 2017-07-22 12:57:14 --> Language Class Initialized
INFO - 2017-07-22 12:57:14 --> Loader Class Initialized
INFO - 2017-07-22 12:57:14 --> Helper loaded: common_helper
INFO - 2017-07-22 12:57:14 --> Database Driver Class Initialized
INFO - 2017-07-22 12:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:57:14 --> Email Class Initialized
INFO - 2017-07-22 12:57:14 --> Controller Class Initialized
INFO - 2017-07-22 12:57:14 --> Helper loaded: form_helper
INFO - 2017-07-22 12:57:14 --> Form Validation Class Initialized
INFO - 2017-07-22 12:57:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:57:14 --> Helper loaded: url_helper
INFO - 2017-07-22 12:57:14 --> Model Class Initialized
INFO - 2017-07-22 12:57:14 --> Model Class Initialized
ERROR - 2017-07-22 16:27:14 --> Undefined variable: news_content
ERROR - 2017-07-22 16:27:14 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 177
ERROR - 2017-07-22 16:27:14 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:27:14 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 207
ERROR - 2017-07-22 16:27:14 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news12323', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
ERROR - 2017-07-22 16:27:14 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:27:14 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 216
ERROR - 2017-07-22 16:27:14 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:27:14 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 217
ERROR - 2017-07-22 16:27:14 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:27:14 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 219
INFO - 2017-07-22 12:57:14 --> Config Class Initialized
INFO - 2017-07-22 12:57:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:57:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:57:14 --> Utf8 Class Initialized
INFO - 2017-07-22 12:57:14 --> URI Class Initialized
INFO - 2017-07-22 12:57:14 --> Router Class Initialized
INFO - 2017-07-22 12:57:14 --> Output Class Initialized
INFO - 2017-07-22 12:57:14 --> Security Class Initialized
DEBUG - 2017-07-22 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:57:14 --> Input Class Initialized
INFO - 2017-07-22 12:57:14 --> Language Class Initialized
INFO - 2017-07-22 12:57:14 --> Loader Class Initialized
INFO - 2017-07-22 12:57:14 --> Helper loaded: common_helper
INFO - 2017-07-22 12:57:14 --> Database Driver Class Initialized
INFO - 2017-07-22 12:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:57:14 --> Email Class Initialized
INFO - 2017-07-22 12:57:14 --> Controller Class Initialized
INFO - 2017-07-22 12:57:14 --> Helper loaded: form_helper
INFO - 2017-07-22 12:57:14 --> Form Validation Class Initialized
INFO - 2017-07-22 12:57:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:57:14 --> Helper loaded: url_helper
INFO - 2017-07-22 12:57:14 --> Model Class Initialized
INFO - 2017-07-22 12:57:14 --> Model Class Initialized
INFO - 2017-07-22 16:27:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:27:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:27:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:27:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:27:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:27:14 --> Final output sent to browser
DEBUG - 2017-07-22 16:27:14 --> Total execution time: 0.0716
INFO - 2017-07-22 12:57:17 --> Config Class Initialized
INFO - 2017-07-22 12:57:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:57:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:57:17 --> Utf8 Class Initialized
INFO - 2017-07-22 12:57:17 --> URI Class Initialized
INFO - 2017-07-22 12:57:17 --> Router Class Initialized
INFO - 2017-07-22 12:57:17 --> Output Class Initialized
INFO - 2017-07-22 12:57:17 --> Security Class Initialized
DEBUG - 2017-07-22 12:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:57:17 --> Input Class Initialized
INFO - 2017-07-22 12:57:17 --> Language Class Initialized
INFO - 2017-07-22 12:57:17 --> Loader Class Initialized
INFO - 2017-07-22 12:57:17 --> Helper loaded: common_helper
INFO - 2017-07-22 12:57:17 --> Database Driver Class Initialized
INFO - 2017-07-22 12:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:57:17 --> Email Class Initialized
INFO - 2017-07-22 12:57:17 --> Controller Class Initialized
INFO - 2017-07-22 12:57:17 --> Helper loaded: form_helper
INFO - 2017-07-22 12:57:17 --> Form Validation Class Initialized
INFO - 2017-07-22 12:57:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:57:17 --> Helper loaded: url_helper
INFO - 2017-07-22 12:57:17 --> Model Class Initialized
INFO - 2017-07-22 12:57:17 --> Model Class Initialized
INFO - 2017-07-22 16:27:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:27:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:27:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:27:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:27:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:27:17 --> Final output sent to browser
DEBUG - 2017-07-22 16:27:17 --> Total execution time: 0.0457
INFO - 2017-07-22 12:58:29 --> Config Class Initialized
INFO - 2017-07-22 12:58:29 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:58:29 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:58:29 --> Utf8 Class Initialized
INFO - 2017-07-22 12:58:29 --> URI Class Initialized
INFO - 2017-07-22 12:58:29 --> Router Class Initialized
INFO - 2017-07-22 12:58:29 --> Output Class Initialized
INFO - 2017-07-22 12:58:29 --> Security Class Initialized
DEBUG - 2017-07-22 12:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:58:29 --> Input Class Initialized
INFO - 2017-07-22 12:58:29 --> Language Class Initialized
INFO - 2017-07-22 12:58:29 --> Loader Class Initialized
INFO - 2017-07-22 12:58:29 --> Helper loaded: common_helper
INFO - 2017-07-22 12:58:29 --> Database Driver Class Initialized
INFO - 2017-07-22 12:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:58:29 --> Email Class Initialized
INFO - 2017-07-22 12:58:29 --> Controller Class Initialized
INFO - 2017-07-22 12:58:29 --> Helper loaded: form_helper
INFO - 2017-07-22 12:58:29 --> Form Validation Class Initialized
INFO - 2017-07-22 12:58:29 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:58:29 --> Helper loaded: url_helper
INFO - 2017-07-22 12:58:29 --> Model Class Initialized
INFO - 2017-07-22 12:58:29 --> Model Class Initialized
INFO - 2017-07-22 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:28:29 --> Final output sent to browser
DEBUG - 2017-07-22 16:28:29 --> Total execution time: 0.0498
INFO - 2017-07-22 12:58:33 --> Config Class Initialized
INFO - 2017-07-22 12:58:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:58:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:58:33 --> Utf8 Class Initialized
INFO - 2017-07-22 12:58:33 --> URI Class Initialized
INFO - 2017-07-22 12:58:33 --> Router Class Initialized
INFO - 2017-07-22 12:58:33 --> Output Class Initialized
INFO - 2017-07-22 12:58:33 --> Security Class Initialized
DEBUG - 2017-07-22 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:58:33 --> Input Class Initialized
INFO - 2017-07-22 12:58:33 --> Language Class Initialized
INFO - 2017-07-22 12:58:33 --> Loader Class Initialized
INFO - 2017-07-22 12:58:33 --> Helper loaded: common_helper
INFO - 2017-07-22 12:58:33 --> Database Driver Class Initialized
INFO - 2017-07-22 12:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:58:33 --> Email Class Initialized
INFO - 2017-07-22 12:58:33 --> Controller Class Initialized
INFO - 2017-07-22 12:58:33 --> Helper loaded: form_helper
INFO - 2017-07-22 12:58:33 --> Form Validation Class Initialized
INFO - 2017-07-22 12:58:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:58:33 --> Helper loaded: url_helper
INFO - 2017-07-22 12:58:33 --> Model Class Initialized
INFO - 2017-07-22 12:58:33 --> Model Class Initialized
ERROR - 2017-07-22 16:28:33 --> Undefined variable: news_content
ERROR - 2017-07-22 16:28:33 --> Severity: Notice --> Undefined variable: news_content C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 177
INFO - 2017-07-22 12:59:28 --> Config Class Initialized
INFO - 2017-07-22 12:59:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:59:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:59:28 --> Utf8 Class Initialized
INFO - 2017-07-22 12:59:28 --> URI Class Initialized
INFO - 2017-07-22 12:59:28 --> Router Class Initialized
INFO - 2017-07-22 12:59:28 --> Output Class Initialized
INFO - 2017-07-22 12:59:28 --> Security Class Initialized
DEBUG - 2017-07-22 12:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:59:28 --> Input Class Initialized
INFO - 2017-07-22 12:59:28 --> Language Class Initialized
INFO - 2017-07-22 12:59:28 --> Loader Class Initialized
INFO - 2017-07-22 12:59:28 --> Helper loaded: common_helper
INFO - 2017-07-22 12:59:28 --> Database Driver Class Initialized
INFO - 2017-07-22 12:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:59:28 --> Email Class Initialized
INFO - 2017-07-22 12:59:28 --> Controller Class Initialized
INFO - 2017-07-22 12:59:28 --> Helper loaded: form_helper
INFO - 2017-07-22 12:59:28 --> Form Validation Class Initialized
INFO - 2017-07-22 12:59:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:59:28 --> Helper loaded: url_helper
INFO - 2017-07-22 12:59:28 --> Model Class Initialized
INFO - 2017-07-22 12:59:28 --> Model Class Initialized
INFO - 2017-07-22 12:59:53 --> Config Class Initialized
INFO - 2017-07-22 12:59:53 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:59:53 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:59:53 --> Utf8 Class Initialized
INFO - 2017-07-22 12:59:53 --> URI Class Initialized
INFO - 2017-07-22 12:59:53 --> Router Class Initialized
INFO - 2017-07-22 12:59:53 --> Output Class Initialized
INFO - 2017-07-22 12:59:53 --> Security Class Initialized
DEBUG - 2017-07-22 12:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:59:53 --> Input Class Initialized
INFO - 2017-07-22 12:59:53 --> Language Class Initialized
INFO - 2017-07-22 12:59:53 --> Loader Class Initialized
INFO - 2017-07-22 12:59:53 --> Helper loaded: common_helper
INFO - 2017-07-22 12:59:53 --> Database Driver Class Initialized
INFO - 2017-07-22 12:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:59:53 --> Email Class Initialized
INFO - 2017-07-22 12:59:53 --> Controller Class Initialized
INFO - 2017-07-22 12:59:53 --> Helper loaded: form_helper
INFO - 2017-07-22 12:59:53 --> Form Validation Class Initialized
INFO - 2017-07-22 12:59:53 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:59:53 --> Helper loaded: url_helper
INFO - 2017-07-22 12:59:53 --> Model Class Initialized
INFO - 2017-07-22 12:59:53 --> Model Class Initialized
ERROR - 2017-07-22 16:29:53 --> Undefined variable: sourceImage
ERROR - 2017-07-22 16:29:53 --> Severity: Notice --> Undefined variable: sourceImage C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 207
ERROR - 2017-07-22 16:29:53 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news12323', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
ERROR - 2017-07-22 16:29:53 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:29:53 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 216
ERROR - 2017-07-22 16:29:53 --> basename() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:29:53 --> Severity: Warning --> basename() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 217
ERROR - 2017-07-22 16:29:53 --> pathinfo() expects parameter 1 to be string, array given
ERROR - 2017-07-22 16:29:53 --> Severity: Warning --> pathinfo() expects parameter 1 to be string, array given C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 219
INFO - 2017-07-22 12:59:53 --> Config Class Initialized
INFO - 2017-07-22 12:59:53 --> Hooks Class Initialized
DEBUG - 2017-07-22 12:59:53 --> UTF-8 Support Enabled
INFO - 2017-07-22 12:59:53 --> Utf8 Class Initialized
INFO - 2017-07-22 12:59:53 --> URI Class Initialized
INFO - 2017-07-22 12:59:53 --> Router Class Initialized
INFO - 2017-07-22 12:59:53 --> Output Class Initialized
INFO - 2017-07-22 12:59:53 --> Security Class Initialized
DEBUG - 2017-07-22 12:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 12:59:53 --> Input Class Initialized
INFO - 2017-07-22 12:59:53 --> Language Class Initialized
INFO - 2017-07-22 12:59:53 --> Loader Class Initialized
INFO - 2017-07-22 12:59:53 --> Helper loaded: common_helper
INFO - 2017-07-22 12:59:53 --> Database Driver Class Initialized
INFO - 2017-07-22 12:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 12:59:53 --> Email Class Initialized
INFO - 2017-07-22 12:59:53 --> Controller Class Initialized
INFO - 2017-07-22 12:59:53 --> Helper loaded: form_helper
INFO - 2017-07-22 12:59:53 --> Form Validation Class Initialized
INFO - 2017-07-22 12:59:53 --> Helper loaded: email_helper
DEBUG - 2017-07-22 12:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 12:59:53 --> Helper loaded: url_helper
INFO - 2017-07-22 12:59:53 --> Model Class Initialized
INFO - 2017-07-22 12:59:53 --> Model Class Initialized
INFO - 2017-07-22 16:29:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:29:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:29:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:29:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:29:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:29:53 --> Final output sent to browser
DEBUG - 2017-07-22 16:29:53 --> Total execution time: 0.0603
INFO - 2017-07-22 13:00:14 --> Config Class Initialized
INFO - 2017-07-22 13:00:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:00:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:00:14 --> Utf8 Class Initialized
INFO - 2017-07-22 13:00:14 --> URI Class Initialized
INFO - 2017-07-22 13:00:14 --> Router Class Initialized
INFO - 2017-07-22 13:00:14 --> Output Class Initialized
INFO - 2017-07-22 13:00:14 --> Security Class Initialized
DEBUG - 2017-07-22 13:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:00:14 --> Input Class Initialized
INFO - 2017-07-22 13:00:14 --> Language Class Initialized
INFO - 2017-07-22 13:00:14 --> Loader Class Initialized
INFO - 2017-07-22 13:00:14 --> Helper loaded: common_helper
INFO - 2017-07-22 13:00:14 --> Database Driver Class Initialized
INFO - 2017-07-22 13:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:00:14 --> Email Class Initialized
INFO - 2017-07-22 13:00:14 --> Controller Class Initialized
INFO - 2017-07-22 13:00:14 --> Helper loaded: form_helper
INFO - 2017-07-22 13:00:14 --> Form Validation Class Initialized
INFO - 2017-07-22 13:00:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:00:14 --> Helper loaded: url_helper
INFO - 2017-07-22 13:00:14 --> Model Class Initialized
INFO - 2017-07-22 13:00:14 --> Model Class Initialized
INFO - 2017-07-22 16:30:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:30:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:30:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:30:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:30:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:30:14 --> Final output sent to browser
DEBUG - 2017-07-22 16:30:14 --> Total execution time: 0.0488
INFO - 2017-07-22 13:00:55 --> Config Class Initialized
INFO - 2017-07-22 13:00:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:00:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:00:55 --> Utf8 Class Initialized
INFO - 2017-07-22 13:00:55 --> URI Class Initialized
INFO - 2017-07-22 13:00:55 --> Router Class Initialized
INFO - 2017-07-22 13:00:55 --> Output Class Initialized
INFO - 2017-07-22 13:00:55 --> Security Class Initialized
DEBUG - 2017-07-22 13:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:00:55 --> Input Class Initialized
INFO - 2017-07-22 13:00:55 --> Language Class Initialized
INFO - 2017-07-22 13:00:55 --> Loader Class Initialized
INFO - 2017-07-22 13:00:55 --> Helper loaded: common_helper
INFO - 2017-07-22 13:00:55 --> Database Driver Class Initialized
INFO - 2017-07-22 13:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:00:55 --> Email Class Initialized
INFO - 2017-07-22 13:00:55 --> Controller Class Initialized
INFO - 2017-07-22 13:00:55 --> Helper loaded: form_helper
INFO - 2017-07-22 13:00:55 --> Form Validation Class Initialized
INFO - 2017-07-22 13:00:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:00:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:00:55 --> Helper loaded: url_helper
INFO - 2017-07-22 13:00:55 --> Model Class Initialized
INFO - 2017-07-22 13:00:55 --> Model Class Initialized
INFO - 2017-07-22 16:30:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:30:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:30:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:30:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:30:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:30:55 --> Final output sent to browser
DEBUG - 2017-07-22 16:30:55 --> Total execution time: 0.0519
INFO - 2017-07-22 13:00:59 --> Config Class Initialized
INFO - 2017-07-22 13:00:59 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:00:59 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:00:59 --> Utf8 Class Initialized
INFO - 2017-07-22 13:00:59 --> URI Class Initialized
INFO - 2017-07-22 13:00:59 --> Router Class Initialized
INFO - 2017-07-22 13:00:59 --> Output Class Initialized
INFO - 2017-07-22 13:00:59 --> Security Class Initialized
DEBUG - 2017-07-22 13:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:00:59 --> Input Class Initialized
INFO - 2017-07-22 13:00:59 --> Language Class Initialized
INFO - 2017-07-22 13:00:59 --> Loader Class Initialized
INFO - 2017-07-22 13:00:59 --> Helper loaded: common_helper
INFO - 2017-07-22 13:00:59 --> Database Driver Class Initialized
INFO - 2017-07-22 13:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:00:59 --> Email Class Initialized
INFO - 2017-07-22 13:00:59 --> Controller Class Initialized
INFO - 2017-07-22 13:00:59 --> Helper loaded: form_helper
INFO - 2017-07-22 13:00:59 --> Form Validation Class Initialized
INFO - 2017-07-22 13:00:59 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:00:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:00:59 --> Helper loaded: url_helper
INFO - 2017-07-22 13:00:59 --> Model Class Initialized
INFO - 2017-07-22 13:00:59 --> Model Class Initialized
INFO - 2017-07-22 13:01:27 --> Config Class Initialized
INFO - 2017-07-22 13:01:27 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:01:27 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:01:27 --> Utf8 Class Initialized
INFO - 2017-07-22 13:01:27 --> URI Class Initialized
INFO - 2017-07-22 13:01:27 --> Router Class Initialized
INFO - 2017-07-22 13:01:27 --> Output Class Initialized
INFO - 2017-07-22 13:01:27 --> Security Class Initialized
DEBUG - 2017-07-22 13:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:01:27 --> Input Class Initialized
INFO - 2017-07-22 13:01:27 --> Language Class Initialized
INFO - 2017-07-22 13:01:27 --> Loader Class Initialized
INFO - 2017-07-22 13:01:27 --> Helper loaded: common_helper
INFO - 2017-07-22 13:01:27 --> Database Driver Class Initialized
INFO - 2017-07-22 13:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:01:27 --> Email Class Initialized
INFO - 2017-07-22 13:01:27 --> Controller Class Initialized
INFO - 2017-07-22 13:01:27 --> Helper loaded: form_helper
INFO - 2017-07-22 13:01:27 --> Form Validation Class Initialized
INFO - 2017-07-22 13:01:27 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:01:27 --> Helper loaded: url_helper
INFO - 2017-07-22 13:01:27 --> Model Class Initialized
INFO - 2017-07-22 13:01:27 --> Model Class Initialized
INFO - 2017-07-22 13:02:05 --> Config Class Initialized
INFO - 2017-07-22 13:02:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:02:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:02:05 --> Utf8 Class Initialized
INFO - 2017-07-22 13:02:05 --> URI Class Initialized
INFO - 2017-07-22 13:02:05 --> Router Class Initialized
INFO - 2017-07-22 13:02:05 --> Output Class Initialized
INFO - 2017-07-22 13:02:05 --> Security Class Initialized
DEBUG - 2017-07-22 13:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:02:05 --> Input Class Initialized
INFO - 2017-07-22 13:02:05 --> Language Class Initialized
INFO - 2017-07-22 13:02:05 --> Loader Class Initialized
INFO - 2017-07-22 13:02:05 --> Helper loaded: common_helper
INFO - 2017-07-22 13:02:05 --> Database Driver Class Initialized
INFO - 2017-07-22 13:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:02:05 --> Email Class Initialized
INFO - 2017-07-22 13:02:05 --> Controller Class Initialized
INFO - 2017-07-22 13:02:05 --> Helper loaded: form_helper
INFO - 2017-07-22 13:02:05 --> Form Validation Class Initialized
INFO - 2017-07-22 13:02:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:02:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:02:05 --> Helper loaded: url_helper
INFO - 2017-07-22 13:02:05 --> Model Class Initialized
INFO - 2017-07-22 13:02:05 --> Model Class Initialized
ERROR - 2017-07-22 16:32:05 --> Query error: Unknown column 'news_title' in 'field list' - Invalid query: UPDATE `news_sources` SET `news_title` = 'foot ball news12323', `news_content` = 'Talismanic striker Sunil Chhetri today said a mid-match dressing down from coach Stephen Constantine got the best out of the Indian football team in its AFC Asian Cup 2019 qualifier against Kyrgyzstan.', `news_article_type` = '1', `news_category_id` = '1'
WHERE `newsID` = '1'
INFO - 2017-07-22 13:02:59 --> Config Class Initialized
INFO - 2017-07-22 13:02:59 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:02:59 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:02:59 --> Utf8 Class Initialized
INFO - 2017-07-22 13:02:59 --> URI Class Initialized
INFO - 2017-07-22 13:02:59 --> Router Class Initialized
INFO - 2017-07-22 13:02:59 --> Output Class Initialized
INFO - 2017-07-22 13:02:59 --> Security Class Initialized
DEBUG - 2017-07-22 13:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:02:59 --> Input Class Initialized
INFO - 2017-07-22 13:02:59 --> Language Class Initialized
INFO - 2017-07-22 13:02:59 --> Loader Class Initialized
INFO - 2017-07-22 13:02:59 --> Helper loaded: common_helper
INFO - 2017-07-22 13:02:59 --> Database Driver Class Initialized
INFO - 2017-07-22 13:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:02:59 --> Email Class Initialized
INFO - 2017-07-22 13:02:59 --> Controller Class Initialized
INFO - 2017-07-22 13:02:59 --> Helper loaded: form_helper
INFO - 2017-07-22 13:02:59 --> Form Validation Class Initialized
INFO - 2017-07-22 13:02:59 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:02:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:02:59 --> Helper loaded: url_helper
INFO - 2017-07-22 13:02:59 --> Model Class Initialized
INFO - 2017-07-22 13:02:59 --> Model Class Initialized
INFO - 2017-07-22 16:32:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:32:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:32:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:32:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:32:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:32:59 --> Final output sent to browser
DEBUG - 2017-07-22 16:32:59 --> Total execution time: 0.1804
INFO - 2017-07-22 13:03:03 --> Config Class Initialized
INFO - 2017-07-22 13:03:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:03:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:03:03 --> Utf8 Class Initialized
INFO - 2017-07-22 13:03:03 --> URI Class Initialized
INFO - 2017-07-22 13:03:03 --> Router Class Initialized
INFO - 2017-07-22 13:03:03 --> Output Class Initialized
INFO - 2017-07-22 13:03:03 --> Security Class Initialized
DEBUG - 2017-07-22 13:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:03:03 --> Input Class Initialized
INFO - 2017-07-22 13:03:03 --> Language Class Initialized
INFO - 2017-07-22 13:03:03 --> Loader Class Initialized
INFO - 2017-07-22 13:03:03 --> Helper loaded: common_helper
INFO - 2017-07-22 13:03:03 --> Database Driver Class Initialized
INFO - 2017-07-22 13:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:03:03 --> Email Class Initialized
INFO - 2017-07-22 13:03:03 --> Controller Class Initialized
INFO - 2017-07-22 13:03:03 --> Helper loaded: form_helper
INFO - 2017-07-22 13:03:03 --> Form Validation Class Initialized
INFO - 2017-07-22 13:03:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:03:03 --> Helper loaded: url_helper
INFO - 2017-07-22 13:03:03 --> Model Class Initialized
INFO - 2017-07-22 13:03:03 --> Model Class Initialized
INFO - 2017-07-22 16:33:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:33:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:33:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:33:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:33:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:33:04 --> Final output sent to browser
DEBUG - 2017-07-22 16:33:04 --> Total execution time: 0.1845
INFO - 2017-07-22 13:03:06 --> Config Class Initialized
INFO - 2017-07-22 13:03:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:03:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:03:06 --> Utf8 Class Initialized
INFO - 2017-07-22 13:03:06 --> URI Class Initialized
INFO - 2017-07-22 13:03:06 --> Router Class Initialized
INFO - 2017-07-22 13:03:06 --> Output Class Initialized
INFO - 2017-07-22 13:03:06 --> Security Class Initialized
DEBUG - 2017-07-22 13:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:03:06 --> Input Class Initialized
INFO - 2017-07-22 13:03:06 --> Language Class Initialized
INFO - 2017-07-22 13:03:06 --> Loader Class Initialized
INFO - 2017-07-22 13:03:06 --> Helper loaded: common_helper
INFO - 2017-07-22 13:03:06 --> Database Driver Class Initialized
INFO - 2017-07-22 13:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:03:06 --> Email Class Initialized
INFO - 2017-07-22 13:03:06 --> Controller Class Initialized
INFO - 2017-07-22 13:03:06 --> Helper loaded: form_helper
INFO - 2017-07-22 13:03:06 --> Form Validation Class Initialized
INFO - 2017-07-22 13:03:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:03:06 --> Helper loaded: url_helper
INFO - 2017-07-22 13:03:06 --> Model Class Initialized
INFO - 2017-07-22 13:03:06 --> Model Class Initialized
INFO - 2017-07-22 16:33:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:33:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:33:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:33:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:33:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:33:06 --> Final output sent to browser
DEBUG - 2017-07-22 16:33:06 --> Total execution time: 0.0460
INFO - 2017-07-22 13:03:09 --> Config Class Initialized
INFO - 2017-07-22 13:03:09 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:03:09 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:03:09 --> Utf8 Class Initialized
INFO - 2017-07-22 13:03:09 --> URI Class Initialized
INFO - 2017-07-22 13:03:09 --> Router Class Initialized
INFO - 2017-07-22 13:03:09 --> Output Class Initialized
INFO - 2017-07-22 13:03:09 --> Security Class Initialized
DEBUG - 2017-07-22 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:03:09 --> Input Class Initialized
INFO - 2017-07-22 13:03:09 --> Language Class Initialized
INFO - 2017-07-22 13:03:09 --> Loader Class Initialized
INFO - 2017-07-22 13:03:09 --> Helper loaded: common_helper
INFO - 2017-07-22 13:03:09 --> Database Driver Class Initialized
INFO - 2017-07-22 13:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:03:09 --> Email Class Initialized
INFO - 2017-07-22 13:03:09 --> Controller Class Initialized
INFO - 2017-07-22 13:03:09 --> Helper loaded: form_helper
INFO - 2017-07-22 13:03:09 --> Form Validation Class Initialized
INFO - 2017-07-22 13:03:09 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:03:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:03:09 --> Helper loaded: url_helper
INFO - 2017-07-22 13:03:09 --> Model Class Initialized
INFO - 2017-07-22 13:03:09 --> Model Class Initialized
INFO - 2017-07-22 16:33:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:33:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:33:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:33:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:33:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:33:09 --> Final output sent to browser
DEBUG - 2017-07-22 16:33:09 --> Total execution time: 0.0469
INFO - 2017-07-22 13:03:11 --> Config Class Initialized
INFO - 2017-07-22 13:03:11 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:03:11 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:03:11 --> Utf8 Class Initialized
INFO - 2017-07-22 13:03:11 --> URI Class Initialized
INFO - 2017-07-22 13:03:11 --> Router Class Initialized
INFO - 2017-07-22 13:03:11 --> Output Class Initialized
INFO - 2017-07-22 13:03:11 --> Security Class Initialized
DEBUG - 2017-07-22 13:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:03:11 --> Input Class Initialized
INFO - 2017-07-22 13:03:11 --> Language Class Initialized
INFO - 2017-07-22 13:03:11 --> Loader Class Initialized
INFO - 2017-07-22 13:03:11 --> Helper loaded: common_helper
INFO - 2017-07-22 13:03:11 --> Database Driver Class Initialized
INFO - 2017-07-22 13:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:03:11 --> Email Class Initialized
INFO - 2017-07-22 13:03:11 --> Controller Class Initialized
INFO - 2017-07-22 13:03:11 --> Helper loaded: form_helper
INFO - 2017-07-22 13:03:11 --> Form Validation Class Initialized
INFO - 2017-07-22 13:03:11 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:03:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:03:11 --> Helper loaded: url_helper
INFO - 2017-07-22 13:03:11 --> Model Class Initialized
INFO - 2017-07-22 13:03:11 --> Model Class Initialized
INFO - 2017-07-22 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:33:11 --> Final output sent to browser
DEBUG - 2017-07-22 16:33:11 --> Total execution time: 0.0456
INFO - 2017-07-22 13:03:12 --> Config Class Initialized
INFO - 2017-07-22 13:03:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:03:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:03:12 --> Utf8 Class Initialized
INFO - 2017-07-22 13:03:12 --> URI Class Initialized
INFO - 2017-07-22 13:03:12 --> Router Class Initialized
INFO - 2017-07-22 13:03:12 --> Output Class Initialized
INFO - 2017-07-22 13:03:12 --> Security Class Initialized
DEBUG - 2017-07-22 13:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:03:12 --> Input Class Initialized
INFO - 2017-07-22 13:03:12 --> Language Class Initialized
INFO - 2017-07-22 13:03:12 --> Loader Class Initialized
INFO - 2017-07-22 13:03:12 --> Helper loaded: common_helper
INFO - 2017-07-22 13:03:12 --> Database Driver Class Initialized
INFO - 2017-07-22 13:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:03:12 --> Email Class Initialized
INFO - 2017-07-22 13:03:12 --> Controller Class Initialized
INFO - 2017-07-22 13:03:12 --> Helper loaded: form_helper
INFO - 2017-07-22 13:03:12 --> Form Validation Class Initialized
INFO - 2017-07-22 13:03:12 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:03:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:03:12 --> Helper loaded: url_helper
INFO - 2017-07-22 13:03:12 --> Model Class Initialized
INFO - 2017-07-22 13:03:12 --> Model Class Initialized
INFO - 2017-07-22 16:33:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:33:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:33:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:33:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:33:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:33:12 --> Final output sent to browser
DEBUG - 2017-07-22 16:33:12 --> Total execution time: 0.0530
INFO - 2017-07-22 13:11:30 --> Config Class Initialized
INFO - 2017-07-22 13:11:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:11:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:11:30 --> Utf8 Class Initialized
INFO - 2017-07-22 13:11:30 --> URI Class Initialized
INFO - 2017-07-22 13:11:30 --> Router Class Initialized
INFO - 2017-07-22 13:11:30 --> Output Class Initialized
INFO - 2017-07-22 13:11:30 --> Security Class Initialized
DEBUG - 2017-07-22 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:11:30 --> Input Class Initialized
INFO - 2017-07-22 13:11:30 --> Language Class Initialized
INFO - 2017-07-22 13:11:30 --> Loader Class Initialized
INFO - 2017-07-22 13:11:30 --> Helper loaded: common_helper
INFO - 2017-07-22 13:11:30 --> Database Driver Class Initialized
INFO - 2017-07-22 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:11:30 --> Email Class Initialized
INFO - 2017-07-22 13:11:30 --> Controller Class Initialized
INFO - 2017-07-22 13:11:30 --> Helper loaded: form_helper
INFO - 2017-07-22 13:11:30 --> Form Validation Class Initialized
INFO - 2017-07-22 13:11:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:11:30 --> Helper loaded: url_helper
INFO - 2017-07-22 13:11:30 --> Model Class Initialized
INFO - 2017-07-22 13:11:30 --> Model Class Initialized
INFO - 2017-07-22 16:41:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:41:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:41:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:41:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:41:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:41:30 --> Final output sent to browser
DEBUG - 2017-07-22 16:41:30 --> Total execution time: 0.1294
INFO - 2017-07-22 13:12:32 --> Config Class Initialized
INFO - 2017-07-22 13:12:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:12:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:12:32 --> Utf8 Class Initialized
INFO - 2017-07-22 13:12:32 --> URI Class Initialized
INFO - 2017-07-22 13:12:32 --> Router Class Initialized
INFO - 2017-07-22 13:12:32 --> Output Class Initialized
INFO - 2017-07-22 13:12:32 --> Security Class Initialized
DEBUG - 2017-07-22 13:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:12:32 --> Input Class Initialized
INFO - 2017-07-22 13:12:32 --> Language Class Initialized
INFO - 2017-07-22 13:12:32 --> Loader Class Initialized
INFO - 2017-07-22 13:12:32 --> Helper loaded: common_helper
INFO - 2017-07-22 13:12:32 --> Database Driver Class Initialized
INFO - 2017-07-22 13:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:12:32 --> Email Class Initialized
INFO - 2017-07-22 13:12:32 --> Controller Class Initialized
INFO - 2017-07-22 13:12:32 --> Helper loaded: form_helper
INFO - 2017-07-22 13:12:32 --> Form Validation Class Initialized
INFO - 2017-07-22 13:12:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:12:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:12:32 --> Helper loaded: url_helper
INFO - 2017-07-22 13:12:32 --> Model Class Initialized
INFO - 2017-07-22 13:12:32 --> Model Class Initialized
INFO - 2017-07-22 13:27:27 --> Config Class Initialized
INFO - 2017-07-22 13:27:27 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:27:27 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:27:27 --> Utf8 Class Initialized
INFO - 2017-07-22 13:27:27 --> URI Class Initialized
INFO - 2017-07-22 13:27:27 --> Router Class Initialized
INFO - 2017-07-22 13:27:27 --> Output Class Initialized
INFO - 2017-07-22 13:27:27 --> Security Class Initialized
DEBUG - 2017-07-22 13:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:27:27 --> Input Class Initialized
INFO - 2017-07-22 13:27:27 --> Language Class Initialized
ERROR - 2017-07-22 13:27:27 --> syntax error, unexpected end of file, expecting function (T_FUNCTION)
ERROR - 2017-07-22 13:27:27 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 270
INFO - 2017-07-22 13:28:00 --> Config Class Initialized
INFO - 2017-07-22 13:28:00 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:28:00 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:28:00 --> Utf8 Class Initialized
INFO - 2017-07-22 13:28:00 --> URI Class Initialized
INFO - 2017-07-22 13:28:00 --> Router Class Initialized
INFO - 2017-07-22 13:28:00 --> Output Class Initialized
INFO - 2017-07-22 13:28:00 --> Security Class Initialized
DEBUG - 2017-07-22 13:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:28:00 --> Input Class Initialized
INFO - 2017-07-22 13:28:00 --> Language Class Initialized
ERROR - 2017-07-22 13:28:00 --> syntax error, unexpected end of file, expecting function (T_FUNCTION)
ERROR - 2017-07-22 13:28:00 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 268
INFO - 2017-07-22 13:29:28 --> Config Class Initialized
INFO - 2017-07-22 13:29:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:29:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:29:28 --> Utf8 Class Initialized
INFO - 2017-07-22 13:29:28 --> URI Class Initialized
INFO - 2017-07-22 13:29:28 --> Router Class Initialized
INFO - 2017-07-22 13:29:28 --> Output Class Initialized
INFO - 2017-07-22 13:29:28 --> Security Class Initialized
DEBUG - 2017-07-22 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:29:28 --> Input Class Initialized
INFO - 2017-07-22 13:29:28 --> Language Class Initialized
INFO - 2017-07-22 13:29:28 --> Loader Class Initialized
INFO - 2017-07-22 13:29:28 --> Helper loaded: common_helper
INFO - 2017-07-22 13:29:28 --> Database Driver Class Initialized
INFO - 2017-07-22 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:29:28 --> Email Class Initialized
INFO - 2017-07-22 13:29:28 --> Controller Class Initialized
INFO - 2017-07-22 13:29:28 --> Helper loaded: form_helper
INFO - 2017-07-22 13:29:28 --> Form Validation Class Initialized
INFO - 2017-07-22 13:29:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:29:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:29:28 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:28 --> Model Class Initialized
INFO - 2017-07-22 13:29:28 --> Model Class Initialized
INFO - 2017-07-22 16:59:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:59:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:59:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:59:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:59:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:59:28 --> Final output sent to browser
DEBUG - 2017-07-22 16:59:28 --> Total execution time: 0.1467
INFO - 2017-07-22 13:29:32 --> Config Class Initialized
INFO - 2017-07-22 13:29:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:29:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:29:32 --> Utf8 Class Initialized
INFO - 2017-07-22 13:29:32 --> URI Class Initialized
INFO - 2017-07-22 13:29:32 --> Router Class Initialized
INFO - 2017-07-22 13:29:32 --> Output Class Initialized
INFO - 2017-07-22 13:29:32 --> Security Class Initialized
DEBUG - 2017-07-22 13:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:29:32 --> Input Class Initialized
INFO - 2017-07-22 13:29:32 --> Language Class Initialized
INFO - 2017-07-22 13:29:32 --> Loader Class Initialized
INFO - 2017-07-22 13:29:32 --> Helper loaded: common_helper
INFO - 2017-07-22 13:29:32 --> Database Driver Class Initialized
INFO - 2017-07-22 13:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:29:32 --> Email Class Initialized
INFO - 2017-07-22 13:29:32 --> Controller Class Initialized
INFO - 2017-07-22 13:29:32 --> Helper loaded: form_helper
INFO - 2017-07-22 13:29:32 --> Form Validation Class Initialized
INFO - 2017-07-22 13:29:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:29:32 --> Helper loaded: url_helper
INFO - 2017-07-22 13:29:32 --> Model Class Initialized
INFO - 2017-07-22 13:29:32 --> Model Class Initialized
INFO - 2017-07-22 16:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 16:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 16:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 16:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 16:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 16:59:32 --> Final output sent to browser
DEBUG - 2017-07-22 16:59:32 --> Total execution time: 0.1407
INFO - 2017-07-22 13:30:39 --> Config Class Initialized
INFO - 2017-07-22 13:30:39 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:30:39 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:30:39 --> Utf8 Class Initialized
INFO - 2017-07-22 13:30:39 --> URI Class Initialized
INFO - 2017-07-22 13:30:39 --> Router Class Initialized
INFO - 2017-07-22 13:30:39 --> Output Class Initialized
INFO - 2017-07-22 13:30:39 --> Security Class Initialized
DEBUG - 2017-07-22 13:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:30:39 --> Input Class Initialized
INFO - 2017-07-22 13:30:39 --> Language Class Initialized
ERROR - 2017-07-22 13:30:39 --> syntax error, unexpected end of file, expecting function (T_FUNCTION)
ERROR - 2017-07-22 13:30:39 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 264
INFO - 2017-07-22 13:30:57 --> Config Class Initialized
INFO - 2017-07-22 13:30:57 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:30:57 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:30:57 --> Utf8 Class Initialized
INFO - 2017-07-22 13:30:57 --> URI Class Initialized
INFO - 2017-07-22 13:30:57 --> Router Class Initialized
INFO - 2017-07-22 13:30:57 --> Output Class Initialized
INFO - 2017-07-22 13:30:57 --> Security Class Initialized
DEBUG - 2017-07-22 13:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:30:57 --> Input Class Initialized
INFO - 2017-07-22 13:30:57 --> Language Class Initialized
INFO - 2017-07-22 13:30:57 --> Loader Class Initialized
INFO - 2017-07-22 13:30:57 --> Helper loaded: common_helper
INFO - 2017-07-22 13:30:57 --> Database Driver Class Initialized
INFO - 2017-07-22 13:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:30:57 --> Email Class Initialized
INFO - 2017-07-22 13:30:57 --> Controller Class Initialized
INFO - 2017-07-22 13:30:57 --> Helper loaded: form_helper
INFO - 2017-07-22 13:30:57 --> Form Validation Class Initialized
INFO - 2017-07-22 13:30:57 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:30:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:30:57 --> Helper loaded: url_helper
INFO - 2017-07-22 13:30:57 --> Model Class Initialized
INFO - 2017-07-22 13:30:57 --> Model Class Initialized
INFO - 2017-07-22 17:00:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:00:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:00:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:00:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:00:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:00:57 --> Final output sent to browser
DEBUG - 2017-07-22 17:00:57 --> Total execution time: 0.1592
INFO - 2017-07-22 13:31:14 --> Config Class Initialized
INFO - 2017-07-22 13:31:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:31:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:31:14 --> Utf8 Class Initialized
INFO - 2017-07-22 13:31:14 --> URI Class Initialized
INFO - 2017-07-22 13:31:14 --> Router Class Initialized
INFO - 2017-07-22 13:31:14 --> Output Class Initialized
INFO - 2017-07-22 13:31:14 --> Security Class Initialized
DEBUG - 2017-07-22 13:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:31:14 --> Input Class Initialized
INFO - 2017-07-22 13:31:14 --> Language Class Initialized
INFO - 2017-07-22 13:31:14 --> Loader Class Initialized
INFO - 2017-07-22 13:31:14 --> Helper loaded: common_helper
INFO - 2017-07-22 13:31:14 --> Database Driver Class Initialized
INFO - 2017-07-22 13:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:31:14 --> Email Class Initialized
INFO - 2017-07-22 13:31:14 --> Controller Class Initialized
INFO - 2017-07-22 13:31:14 --> Helper loaded: form_helper
INFO - 2017-07-22 13:31:14 --> Form Validation Class Initialized
INFO - 2017-07-22 13:31:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:31:14 --> Helper loaded: url_helper
INFO - 2017-07-22 13:31:14 --> Model Class Initialized
INFO - 2017-07-22 13:31:14 --> Model Class Initialized
INFO - 2017-07-22 17:01:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:01:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:01:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:01:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:01:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:01:14 --> Final output sent to browser
DEBUG - 2017-07-22 17:01:14 --> Total execution time: 0.1420
INFO - 2017-07-22 13:31:17 --> Config Class Initialized
INFO - 2017-07-22 13:31:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:31:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:31:17 --> Utf8 Class Initialized
INFO - 2017-07-22 13:31:17 --> URI Class Initialized
INFO - 2017-07-22 13:31:17 --> Router Class Initialized
INFO - 2017-07-22 13:31:17 --> Output Class Initialized
INFO - 2017-07-22 13:31:17 --> Security Class Initialized
DEBUG - 2017-07-22 13:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:31:17 --> Input Class Initialized
INFO - 2017-07-22 13:31:17 --> Language Class Initialized
INFO - 2017-07-22 13:31:17 --> Loader Class Initialized
INFO - 2017-07-22 13:31:17 --> Helper loaded: common_helper
INFO - 2017-07-22 13:31:17 --> Database Driver Class Initialized
INFO - 2017-07-22 13:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:31:17 --> Email Class Initialized
INFO - 2017-07-22 13:31:17 --> Controller Class Initialized
INFO - 2017-07-22 13:31:17 --> Helper loaded: form_helper
INFO - 2017-07-22 13:31:17 --> Form Validation Class Initialized
INFO - 2017-07-22 13:31:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:31:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:31:17 --> Helper loaded: url_helper
INFO - 2017-07-22 13:31:17 --> Model Class Initialized
INFO - 2017-07-22 13:31:17 --> Model Class Initialized
INFO - 2017-07-22 17:01:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:01:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:01:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:01:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:01:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:01:17 --> Final output sent to browser
DEBUG - 2017-07-22 17:01:17 --> Total execution time: 0.1416
INFO - 2017-07-22 13:31:36 --> Config Class Initialized
INFO - 2017-07-22 13:31:36 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:31:36 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:31:36 --> Utf8 Class Initialized
INFO - 2017-07-22 13:31:36 --> URI Class Initialized
INFO - 2017-07-22 13:31:36 --> Router Class Initialized
INFO - 2017-07-22 13:31:36 --> Output Class Initialized
INFO - 2017-07-22 13:31:36 --> Security Class Initialized
DEBUG - 2017-07-22 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:31:36 --> Input Class Initialized
INFO - 2017-07-22 13:31:36 --> Language Class Initialized
INFO - 2017-07-22 13:31:36 --> Loader Class Initialized
INFO - 2017-07-22 13:31:36 --> Helper loaded: common_helper
INFO - 2017-07-22 13:31:36 --> Database Driver Class Initialized
INFO - 2017-07-22 13:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:31:36 --> Email Class Initialized
INFO - 2017-07-22 13:31:36 --> Controller Class Initialized
INFO - 2017-07-22 13:31:36 --> Helper loaded: form_helper
INFO - 2017-07-22 13:31:36 --> Form Validation Class Initialized
INFO - 2017-07-22 13:31:36 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:31:36 --> Helper loaded: url_helper
INFO - 2017-07-22 13:31:36 --> Model Class Initialized
INFO - 2017-07-22 13:31:36 --> Model Class Initialized
ERROR - 2017-07-22 17:01:36 --> Array to string conversion
ERROR - 2017-07-22 17:01:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 234
ERROR - 2017-07-22 17:01:36 --> Undefined variable: Array
ERROR - 2017-07-22 17:01:36 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 234
INFO - 2017-07-22 13:31:45 --> Config Class Initialized
INFO - 2017-07-22 13:31:45 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:31:45 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:31:45 --> Utf8 Class Initialized
INFO - 2017-07-22 13:31:45 --> URI Class Initialized
INFO - 2017-07-22 13:31:45 --> Router Class Initialized
INFO - 2017-07-22 13:31:45 --> Output Class Initialized
INFO - 2017-07-22 13:31:45 --> Security Class Initialized
DEBUG - 2017-07-22 13:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:31:45 --> Input Class Initialized
INFO - 2017-07-22 13:31:45 --> Language Class Initialized
INFO - 2017-07-22 13:31:45 --> Loader Class Initialized
INFO - 2017-07-22 13:31:45 --> Helper loaded: common_helper
INFO - 2017-07-22 13:31:45 --> Database Driver Class Initialized
INFO - 2017-07-22 13:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:31:45 --> Email Class Initialized
INFO - 2017-07-22 13:31:45 --> Controller Class Initialized
INFO - 2017-07-22 13:31:45 --> Helper loaded: form_helper
INFO - 2017-07-22 13:31:45 --> Form Validation Class Initialized
INFO - 2017-07-22 13:31:45 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:31:45 --> Helper loaded: url_helper
INFO - 2017-07-22 13:31:45 --> Model Class Initialized
INFO - 2017-07-22 13:31:45 --> Model Class Initialized
INFO - 2017-07-22 13:34:36 --> Config Class Initialized
INFO - 2017-07-22 13:34:36 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:36 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:36 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:36 --> URI Class Initialized
DEBUG - 2017-07-22 13:34:36 --> No URI present. Default controller set.
INFO - 2017-07-22 13:34:36 --> Router Class Initialized
INFO - 2017-07-22 13:34:36 --> Output Class Initialized
INFO - 2017-07-22 13:34:36 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:36 --> Input Class Initialized
INFO - 2017-07-22 13:34:36 --> Language Class Initialized
INFO - 2017-07-22 13:34:36 --> Loader Class Initialized
INFO - 2017-07-22 13:34:36 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:36 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:36 --> Email Class Initialized
INFO - 2017-07-22 13:34:36 --> Controller Class Initialized
INFO - 2017-07-22 13:34:36 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:36 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:36 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:36 --> Helper loaded: url_helper
INFO - 2017-07-22 13:34:36 --> Model Class Initialized
INFO - 2017-07-22 13:34:36 --> Model Class Initialized
INFO - 2017-07-22 13:34:36 --> Config Class Initialized
INFO - 2017-07-22 13:34:36 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:36 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:36 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:36 --> URI Class Initialized
INFO - 2017-07-22 13:34:36 --> Router Class Initialized
INFO - 2017-07-22 13:34:36 --> Output Class Initialized
INFO - 2017-07-22 13:34:36 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:36 --> Input Class Initialized
INFO - 2017-07-22 13:34:36 --> Language Class Initialized
INFO - 2017-07-22 13:34:36 --> Loader Class Initialized
INFO - 2017-07-22 13:34:36 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:36 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:36 --> Email Class Initialized
INFO - 2017-07-22 13:34:36 --> Controller Class Initialized
INFO - 2017-07-22 13:34:36 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:36 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:36 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:36 --> Helper loaded: url_helper
INFO - 2017-07-22 13:34:36 --> Model Class Initialized
INFO - 2017-07-22 13:34:36 --> Model Class Initialized
INFO - 2017-07-22 13:34:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 13:34:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-07-22 13:34:36 --> Undefined variable: bloodGroupsCount
ERROR - 2017-07-22 13:34:36 --> Severity: Notice --> Undefined variable: bloodGroupsCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 13:34:36 --> Trying to get property of non-object
ERROR - 2017-07-22 13:34:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 39
ERROR - 2017-07-22 13:34:36 --> Undefined variable: bloodBanksCount
ERROR - 2017-07-22 13:34:36 --> Severity: Notice --> Undefined variable: bloodBanksCount C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 13:34:36 --> Trying to get property of non-object
ERROR - 2017-07-22 13:34:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 51
ERROR - 2017-07-22 13:34:36 --> Undefined variable: Evenets
ERROR - 2017-07-22 13:34:36 --> Severity: Notice --> Undefined variable: Evenets C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
ERROR - 2017-07-22 13:34:36 --> Trying to get property of non-object
ERROR - 2017-07-22 13:34:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php 63
INFO - 2017-07-22 13:34:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-07-22 13:34:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 13:34:36 --> Final output sent to browser
DEBUG - 2017-07-22 13:34:36 --> Total execution time: 0.0712
INFO - 2017-07-22 13:34:44 --> Config Class Initialized
INFO - 2017-07-22 13:34:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:44 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:44 --> URI Class Initialized
INFO - 2017-07-22 13:34:44 --> Router Class Initialized
INFO - 2017-07-22 13:34:44 --> Output Class Initialized
INFO - 2017-07-22 13:34:44 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:44 --> Input Class Initialized
INFO - 2017-07-22 13:34:44 --> Language Class Initialized
INFO - 2017-07-22 13:34:44 --> Loader Class Initialized
INFO - 2017-07-22 13:34:44 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:44 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:44 --> Email Class Initialized
INFO - 2017-07-22 13:34:44 --> Controller Class Initialized
INFO - 2017-07-22 13:34:44 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:44 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:44 --> Helper loaded: url_helper
INFO - 2017-07-22 13:34:44 --> Model Class Initialized
INFO - 2017-07-22 13:34:44 --> Model Class Initialized
INFO - 2017-07-22 17:04:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:04:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:04:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:04:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-22 17:04:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:04:44 --> Final output sent to browser
DEBUG - 2017-07-22 17:04:44 --> Total execution time: 0.0499
INFO - 2017-07-22 13:34:47 --> Config Class Initialized
INFO - 2017-07-22 13:34:47 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:47 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:47 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:47 --> URI Class Initialized
INFO - 2017-07-22 13:34:47 --> Router Class Initialized
INFO - 2017-07-22 13:34:47 --> Output Class Initialized
INFO - 2017-07-22 13:34:47 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:47 --> Input Class Initialized
INFO - 2017-07-22 13:34:47 --> Language Class Initialized
INFO - 2017-07-22 13:34:47 --> Loader Class Initialized
INFO - 2017-07-22 13:34:47 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:47 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:47 --> Email Class Initialized
INFO - 2017-07-22 13:34:47 --> Controller Class Initialized
INFO - 2017-07-22 13:34:47 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:47 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:47 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:47 --> Helper loaded: url_helper
INFO - 2017-07-22 13:34:47 --> Model Class Initialized
INFO - 2017-07-22 13:34:47 --> Model Class Initialized
INFO - 2017-07-22 17:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 17:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:04:47 --> Final output sent to browser
DEBUG - 2017-07-22 17:04:47 --> Total execution time: 0.0453
INFO - 2017-07-22 13:34:48 --> Config Class Initialized
INFO - 2017-07-22 13:34:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:48 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:48 --> URI Class Initialized
INFO - 2017-07-22 13:34:48 --> Router Class Initialized
INFO - 2017-07-22 13:34:48 --> Output Class Initialized
INFO - 2017-07-22 13:34:48 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:48 --> Input Class Initialized
INFO - 2017-07-22 13:34:48 --> Language Class Initialized
INFO - 2017-07-22 13:34:48 --> Loader Class Initialized
INFO - 2017-07-22 13:34:48 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:48 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:48 --> Email Class Initialized
INFO - 2017-07-22 13:34:48 --> Controller Class Initialized
INFO - 2017-07-22 13:34:48 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:48 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:48 --> Helper loaded: url_helper
INFO - 2017-07-22 17:04:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:04:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:04:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:04:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 17:04:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:04:48 --> Final output sent to browser
DEBUG - 2017-07-22 17:04:48 --> Total execution time: 0.0423
INFO - 2017-07-22 13:34:49 --> Config Class Initialized
INFO - 2017-07-22 13:34:49 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:49 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:49 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:49 --> URI Class Initialized
INFO - 2017-07-22 13:34:49 --> Router Class Initialized
INFO - 2017-07-22 13:34:49 --> Output Class Initialized
INFO - 2017-07-22 13:34:49 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:49 --> Input Class Initialized
INFO - 2017-07-22 13:34:49 --> Language Class Initialized
INFO - 2017-07-22 13:34:49 --> Loader Class Initialized
INFO - 2017-07-22 13:34:49 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:49 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:49 --> Email Class Initialized
INFO - 2017-07-22 13:34:49 --> Controller Class Initialized
INFO - 2017-07-22 13:34:49 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:49 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:49 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:49 --> Helper loaded: url_helper
INFO - 2017-07-22 17:04:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:04:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:04:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:04:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 17:04:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:04:50 --> Final output sent to browser
DEBUG - 2017-07-22 17:04:50 --> Total execution time: 0.0614
INFO - 2017-07-22 13:34:56 --> Config Class Initialized
INFO - 2017-07-22 13:34:56 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:34:56 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:34:56 --> Utf8 Class Initialized
INFO - 2017-07-22 13:34:56 --> URI Class Initialized
INFO - 2017-07-22 13:34:56 --> Router Class Initialized
INFO - 2017-07-22 13:34:56 --> Output Class Initialized
INFO - 2017-07-22 13:34:56 --> Security Class Initialized
DEBUG - 2017-07-22 13:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:34:56 --> Input Class Initialized
INFO - 2017-07-22 13:34:56 --> Language Class Initialized
INFO - 2017-07-22 13:34:56 --> Loader Class Initialized
INFO - 2017-07-22 13:34:56 --> Helper loaded: common_helper
INFO - 2017-07-22 13:34:56 --> Database Driver Class Initialized
INFO - 2017-07-22 13:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:34:56 --> Email Class Initialized
INFO - 2017-07-22 13:34:56 --> Controller Class Initialized
INFO - 2017-07-22 13:34:56 --> Helper loaded: form_helper
INFO - 2017-07-22 13:34:56 --> Form Validation Class Initialized
INFO - 2017-07-22 13:34:56 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:34:56 --> Helper loaded: url_helper
INFO - 2017-07-22 13:34:56 --> Model Class Initialized
INFO - 2017-07-22 13:34:56 --> Model Class Initialized
INFO - 2017-07-22 17:04:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:04:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:04:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:04:57 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:04:57 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 17:04:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 17:04:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:04:57 --> Final output sent to browser
DEBUG - 2017-07-22 17:04:57 --> Total execution time: 0.0666
INFO - 2017-07-22 13:35:57 --> Config Class Initialized
INFO - 2017-07-22 13:35:57 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:35:57 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:35:57 --> Utf8 Class Initialized
INFO - 2017-07-22 13:35:57 --> URI Class Initialized
INFO - 2017-07-22 13:35:57 --> Router Class Initialized
INFO - 2017-07-22 13:35:57 --> Output Class Initialized
INFO - 2017-07-22 13:35:57 --> Security Class Initialized
DEBUG - 2017-07-22 13:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:35:57 --> Input Class Initialized
INFO - 2017-07-22 13:35:57 --> Language Class Initialized
INFO - 2017-07-22 13:35:57 --> Loader Class Initialized
INFO - 2017-07-22 13:35:57 --> Helper loaded: common_helper
INFO - 2017-07-22 13:35:57 --> Database Driver Class Initialized
INFO - 2017-07-22 13:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:35:57 --> Email Class Initialized
INFO - 2017-07-22 13:35:57 --> Controller Class Initialized
INFO - 2017-07-22 13:35:57 --> Helper loaded: form_helper
INFO - 2017-07-22 13:35:57 --> Form Validation Class Initialized
INFO - 2017-07-22 13:35:57 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:35:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:35:57 --> Helper loaded: url_helper
INFO - 2017-07-22 13:35:57 --> Model Class Initialized
INFO - 2017-07-22 13:35:57 --> Model Class Initialized
INFO - 2017-07-22 17:05:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:05:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:05:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:05:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:05:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:05:57 --> Final output sent to browser
DEBUG - 2017-07-22 17:05:57 --> Total execution time: 0.0462
INFO - 2017-07-22 13:36:43 --> Config Class Initialized
INFO - 2017-07-22 13:36:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:36:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:36:43 --> Utf8 Class Initialized
INFO - 2017-07-22 13:36:43 --> URI Class Initialized
INFO - 2017-07-22 13:36:43 --> Router Class Initialized
INFO - 2017-07-22 13:36:43 --> Output Class Initialized
INFO - 2017-07-22 13:36:43 --> Security Class Initialized
DEBUG - 2017-07-22 13:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:36:43 --> Input Class Initialized
INFO - 2017-07-22 13:36:43 --> Language Class Initialized
INFO - 2017-07-22 13:36:43 --> Loader Class Initialized
INFO - 2017-07-22 13:36:43 --> Helper loaded: common_helper
INFO - 2017-07-22 13:36:43 --> Database Driver Class Initialized
INFO - 2017-07-22 13:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:36:43 --> Email Class Initialized
INFO - 2017-07-22 13:36:43 --> Controller Class Initialized
INFO - 2017-07-22 13:36:43 --> Helper loaded: form_helper
INFO - 2017-07-22 13:36:43 --> Form Validation Class Initialized
INFO - 2017-07-22 13:36:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:36:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:36:43 --> Helper loaded: url_helper
INFO - 2017-07-22 13:36:43 --> Model Class Initialized
INFO - 2017-07-22 13:36:43 --> Model Class Initialized
INFO - 2017-07-22 17:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:06:43 --> Final output sent to browser
DEBUG - 2017-07-22 17:06:43 --> Total execution time: 0.1531
INFO - 2017-07-22 13:37:02 --> Config Class Initialized
INFO - 2017-07-22 13:37:02 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:02 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:02 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:02 --> URI Class Initialized
INFO - 2017-07-22 13:37:02 --> Router Class Initialized
INFO - 2017-07-22 13:37:02 --> Output Class Initialized
INFO - 2017-07-22 13:37:02 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:02 --> Input Class Initialized
INFO - 2017-07-22 13:37:02 --> Language Class Initialized
ERROR - 2017-07-22 13:37:02 --> syntax error, unexpected '=>' (T_DOUBLE_ARROW)
ERROR - 2017-07-22 13:37:02 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 239
INFO - 2017-07-22 13:37:05 --> Config Class Initialized
INFO - 2017-07-22 13:37:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:05 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:05 --> URI Class Initialized
INFO - 2017-07-22 13:37:05 --> Router Class Initialized
INFO - 2017-07-22 13:37:05 --> Output Class Initialized
INFO - 2017-07-22 13:37:05 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:05 --> Input Class Initialized
INFO - 2017-07-22 13:37:05 --> Language Class Initialized
ERROR - 2017-07-22 13:37:05 --> syntax error, unexpected '=>' (T_DOUBLE_ARROW)
ERROR - 2017-07-22 13:37:05 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 239
INFO - 2017-07-22 13:37:06 --> Config Class Initialized
INFO - 2017-07-22 13:37:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:06 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:06 --> URI Class Initialized
INFO - 2017-07-22 13:37:06 --> Router Class Initialized
INFO - 2017-07-22 13:37:06 --> Output Class Initialized
INFO - 2017-07-22 13:37:06 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:06 --> Input Class Initialized
INFO - 2017-07-22 13:37:06 --> Language Class Initialized
ERROR - 2017-07-22 13:37:06 --> syntax error, unexpected '=>' (T_DOUBLE_ARROW)
ERROR - 2017-07-22 13:37:06 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 239
INFO - 2017-07-22 13:37:14 --> Config Class Initialized
INFO - 2017-07-22 13:37:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:14 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:14 --> URI Class Initialized
INFO - 2017-07-22 13:37:14 --> Router Class Initialized
INFO - 2017-07-22 13:37:14 --> Output Class Initialized
INFO - 2017-07-22 13:37:14 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:14 --> Input Class Initialized
INFO - 2017-07-22 13:37:14 --> Language Class Initialized
ERROR - 2017-07-22 13:37:14 --> syntax error, unexpected ';'
ERROR - 2017-07-22 13:37:14 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 239
INFO - 2017-07-22 13:37:32 --> Config Class Initialized
INFO - 2017-07-22 13:37:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:32 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:32 --> URI Class Initialized
INFO - 2017-07-22 13:37:32 --> Router Class Initialized
INFO - 2017-07-22 13:37:32 --> Output Class Initialized
INFO - 2017-07-22 13:37:32 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:32 --> Input Class Initialized
INFO - 2017-07-22 13:37:32 --> Language Class Initialized
INFO - 2017-07-22 13:37:32 --> Loader Class Initialized
INFO - 2017-07-22 13:37:32 --> Helper loaded: common_helper
INFO - 2017-07-22 13:37:32 --> Database Driver Class Initialized
INFO - 2017-07-22 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:37:32 --> Email Class Initialized
INFO - 2017-07-22 13:37:32 --> Controller Class Initialized
INFO - 2017-07-22 13:37:32 --> Helper loaded: form_helper
INFO - 2017-07-22 13:37:32 --> Form Validation Class Initialized
INFO - 2017-07-22 13:37:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:37:32 --> Helper loaded: url_helper
INFO - 2017-07-22 13:37:32 --> Model Class Initialized
INFO - 2017-07-22 13:37:32 --> Model Class Initialized
INFO - 2017-07-22 17:07:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:07:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:07:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:07:32 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:07:32 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 17:07:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 17:07:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:07:32 --> Final output sent to browser
DEBUG - 2017-07-22 17:07:32 --> Total execution time: 0.0720
INFO - 2017-07-22 13:37:41 --> Config Class Initialized
INFO - 2017-07-22 13:37:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:41 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:41 --> URI Class Initialized
INFO - 2017-07-22 13:37:41 --> Router Class Initialized
INFO - 2017-07-22 13:37:41 --> Output Class Initialized
INFO - 2017-07-22 13:37:41 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:41 --> Input Class Initialized
INFO - 2017-07-22 13:37:41 --> Language Class Initialized
INFO - 2017-07-22 13:37:41 --> Loader Class Initialized
INFO - 2017-07-22 13:37:41 --> Helper loaded: common_helper
INFO - 2017-07-22 13:37:41 --> Database Driver Class Initialized
INFO - 2017-07-22 13:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:37:41 --> Email Class Initialized
INFO - 2017-07-22 13:37:41 --> Controller Class Initialized
INFO - 2017-07-22 13:37:41 --> Helper loaded: form_helper
INFO - 2017-07-22 13:37:41 --> Form Validation Class Initialized
INFO - 2017-07-22 13:37:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:37:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:37:41 --> Helper loaded: url_helper
INFO - 2017-07-22 13:37:41 --> Model Class Initialized
INFO - 2017-07-22 13:37:41 --> Model Class Initialized
INFO - 2017-07-22 17:07:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:07:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:07:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:07:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:07:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:07:41 --> Final output sent to browser
DEBUG - 2017-07-22 17:07:41 --> Total execution time: 0.0476
INFO - 2017-07-22 13:37:45 --> Config Class Initialized
INFO - 2017-07-22 13:37:45 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:37:45 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:37:45 --> Utf8 Class Initialized
INFO - 2017-07-22 13:37:45 --> URI Class Initialized
INFO - 2017-07-22 13:37:45 --> Router Class Initialized
INFO - 2017-07-22 13:37:45 --> Output Class Initialized
INFO - 2017-07-22 13:37:45 --> Security Class Initialized
DEBUG - 2017-07-22 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:37:45 --> Input Class Initialized
INFO - 2017-07-22 13:37:45 --> Language Class Initialized
INFO - 2017-07-22 13:37:45 --> Loader Class Initialized
INFO - 2017-07-22 13:37:45 --> Helper loaded: common_helper
INFO - 2017-07-22 13:37:45 --> Database Driver Class Initialized
INFO - 2017-07-22 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:37:45 --> Email Class Initialized
INFO - 2017-07-22 13:37:45 --> Controller Class Initialized
INFO - 2017-07-22 13:37:45 --> Helper loaded: form_helper
INFO - 2017-07-22 13:37:45 --> Form Validation Class Initialized
INFO - 2017-07-22 13:37:45 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:37:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:37:45 --> Helper loaded: url_helper
INFO - 2017-07-22 13:37:45 --> Model Class Initialized
INFO - 2017-07-22 13:37:45 --> Model Class Initialized
INFO - 2017-07-22 17:07:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:07:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:07:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:07:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:07:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:07:45 --> Final output sent to browser
DEBUG - 2017-07-22 17:07:45 --> Total execution time: 0.1164
INFO - 2017-07-22 13:38:12 --> Config Class Initialized
INFO - 2017-07-22 13:38:12 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:38:12 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:38:12 --> Utf8 Class Initialized
INFO - 2017-07-22 13:38:12 --> URI Class Initialized
INFO - 2017-07-22 13:38:12 --> Router Class Initialized
INFO - 2017-07-22 13:38:12 --> Output Class Initialized
INFO - 2017-07-22 13:38:12 --> Security Class Initialized
DEBUG - 2017-07-22 13:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:38:12 --> Input Class Initialized
INFO - 2017-07-22 13:38:12 --> Language Class Initialized
INFO - 2017-07-22 13:38:12 --> Loader Class Initialized
INFO - 2017-07-22 13:38:13 --> Helper loaded: common_helper
INFO - 2017-07-22 13:38:13 --> Database Driver Class Initialized
INFO - 2017-07-22 13:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:38:13 --> Email Class Initialized
INFO - 2017-07-22 13:38:13 --> Controller Class Initialized
INFO - 2017-07-22 13:38:13 --> Helper loaded: form_helper
INFO - 2017-07-22 13:38:13 --> Form Validation Class Initialized
INFO - 2017-07-22 13:38:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:38:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:38:13 --> Helper loaded: url_helper
INFO - 2017-07-22 13:38:13 --> Model Class Initialized
INFO - 2017-07-22 13:38:13 --> Model Class Initialized
INFO - 2017-07-22 13:38:33 --> Config Class Initialized
INFO - 2017-07-22 13:38:33 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:38:33 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:38:33 --> Utf8 Class Initialized
INFO - 2017-07-22 13:38:33 --> URI Class Initialized
INFO - 2017-07-22 13:38:33 --> Router Class Initialized
INFO - 2017-07-22 13:38:33 --> Output Class Initialized
INFO - 2017-07-22 13:38:33 --> Security Class Initialized
DEBUG - 2017-07-22 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:38:33 --> Input Class Initialized
INFO - 2017-07-22 13:38:33 --> Language Class Initialized
INFO - 2017-07-22 13:38:33 --> Loader Class Initialized
INFO - 2017-07-22 13:38:33 --> Helper loaded: common_helper
INFO - 2017-07-22 13:38:33 --> Database Driver Class Initialized
INFO - 2017-07-22 13:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:38:33 --> Email Class Initialized
INFO - 2017-07-22 13:38:33 --> Controller Class Initialized
INFO - 2017-07-22 13:38:33 --> Helper loaded: form_helper
INFO - 2017-07-22 13:38:33 --> Form Validation Class Initialized
INFO - 2017-07-22 13:38:33 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:38:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:38:33 --> Helper loaded: url_helper
INFO - 2017-07-22 13:38:33 --> Model Class Initialized
INFO - 2017-07-22 13:38:33 --> Model Class Initialized
INFO - 2017-07-22 17:08:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:08:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:08:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:08:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:08:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:08:33 --> Final output sent to browser
DEBUG - 2017-07-22 17:08:33 --> Total execution time: 0.0465
INFO - 2017-07-22 13:38:43 --> Config Class Initialized
INFO - 2017-07-22 13:38:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:38:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:38:43 --> Utf8 Class Initialized
INFO - 2017-07-22 13:38:43 --> URI Class Initialized
INFO - 2017-07-22 13:38:43 --> Router Class Initialized
INFO - 2017-07-22 13:38:43 --> Output Class Initialized
INFO - 2017-07-22 13:38:43 --> Security Class Initialized
DEBUG - 2017-07-22 13:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:38:43 --> Input Class Initialized
INFO - 2017-07-22 13:38:43 --> Language Class Initialized
INFO - 2017-07-22 13:38:43 --> Loader Class Initialized
INFO - 2017-07-22 13:38:43 --> Helper loaded: common_helper
INFO - 2017-07-22 13:38:43 --> Database Driver Class Initialized
INFO - 2017-07-22 13:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:38:43 --> Email Class Initialized
INFO - 2017-07-22 13:38:43 --> Controller Class Initialized
INFO - 2017-07-22 13:38:43 --> Helper loaded: form_helper
INFO - 2017-07-22 13:38:43 --> Form Validation Class Initialized
INFO - 2017-07-22 13:38:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:38:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:38:43 --> Helper loaded: url_helper
INFO - 2017-07-22 13:38:43 --> Model Class Initialized
INFO - 2017-07-22 13:38:43 --> Model Class Initialized
INFO - 2017-07-22 13:39:03 --> Config Class Initialized
INFO - 2017-07-22 13:39:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:39:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:39:03 --> Utf8 Class Initialized
INFO - 2017-07-22 13:39:03 --> URI Class Initialized
INFO - 2017-07-22 13:39:03 --> Router Class Initialized
INFO - 2017-07-22 13:39:03 --> Output Class Initialized
INFO - 2017-07-22 13:39:03 --> Security Class Initialized
DEBUG - 2017-07-22 13:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:39:03 --> Input Class Initialized
INFO - 2017-07-22 13:39:03 --> Language Class Initialized
INFO - 2017-07-22 13:39:03 --> Loader Class Initialized
INFO - 2017-07-22 13:39:03 --> Helper loaded: common_helper
INFO - 2017-07-22 13:39:03 --> Database Driver Class Initialized
INFO - 2017-07-22 13:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:39:03 --> Email Class Initialized
INFO - 2017-07-22 13:39:03 --> Controller Class Initialized
INFO - 2017-07-22 13:39:03 --> Helper loaded: form_helper
INFO - 2017-07-22 13:39:03 --> Form Validation Class Initialized
INFO - 2017-07-22 13:39:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:39:03 --> Helper loaded: url_helper
INFO - 2017-07-22 13:39:03 --> Model Class Initialized
INFO - 2017-07-22 13:39:03 --> Model Class Initialized
INFO - 2017-07-22 13:39:04 --> Config Class Initialized
INFO - 2017-07-22 13:39:04 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:39:04 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:39:04 --> Utf8 Class Initialized
INFO - 2017-07-22 13:39:04 --> URI Class Initialized
INFO - 2017-07-22 13:39:04 --> Router Class Initialized
INFO - 2017-07-22 13:39:04 --> Output Class Initialized
INFO - 2017-07-22 13:39:04 --> Security Class Initialized
DEBUG - 2017-07-22 13:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:39:04 --> Input Class Initialized
INFO - 2017-07-22 13:39:04 --> Language Class Initialized
INFO - 2017-07-22 13:39:04 --> Loader Class Initialized
INFO - 2017-07-22 13:39:04 --> Helper loaded: common_helper
INFO - 2017-07-22 13:39:04 --> Database Driver Class Initialized
INFO - 2017-07-22 13:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:39:04 --> Email Class Initialized
INFO - 2017-07-22 13:39:04 --> Controller Class Initialized
INFO - 2017-07-22 13:39:04 --> Helper loaded: form_helper
INFO - 2017-07-22 13:39:04 --> Form Validation Class Initialized
INFO - 2017-07-22 13:39:04 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:39:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:39:04 --> Helper loaded: url_helper
INFO - 2017-07-22 13:39:04 --> Model Class Initialized
INFO - 2017-07-22 13:39:04 --> Model Class Initialized
INFO - 2017-07-22 17:09:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:09:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:09:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:09:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:09:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:09:04 --> Final output sent to browser
DEBUG - 2017-07-22 17:09:04 --> Total execution time: 0.0462
INFO - 2017-07-22 13:39:08 --> Config Class Initialized
INFO - 2017-07-22 13:39:08 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:39:08 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:39:08 --> Utf8 Class Initialized
INFO - 2017-07-22 13:39:08 --> URI Class Initialized
INFO - 2017-07-22 13:39:08 --> Router Class Initialized
INFO - 2017-07-22 13:39:08 --> Output Class Initialized
INFO - 2017-07-22 13:39:08 --> Security Class Initialized
DEBUG - 2017-07-22 13:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:39:08 --> Input Class Initialized
INFO - 2017-07-22 13:39:08 --> Language Class Initialized
INFO - 2017-07-22 13:39:08 --> Loader Class Initialized
INFO - 2017-07-22 13:39:08 --> Helper loaded: common_helper
INFO - 2017-07-22 13:39:08 --> Database Driver Class Initialized
INFO - 2017-07-22 13:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:39:08 --> Email Class Initialized
INFO - 2017-07-22 13:39:08 --> Controller Class Initialized
INFO - 2017-07-22 13:39:08 --> Helper loaded: form_helper
INFO - 2017-07-22 13:39:08 --> Form Validation Class Initialized
INFO - 2017-07-22 13:39:08 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:39:08 --> Helper loaded: url_helper
INFO - 2017-07-22 13:39:08 --> Model Class Initialized
INFO - 2017-07-22 13:39:08 --> Model Class Initialized
INFO - 2017-07-22 13:39:31 --> Config Class Initialized
INFO - 2017-07-22 13:39:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:39:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:39:31 --> Utf8 Class Initialized
INFO - 2017-07-22 13:39:31 --> URI Class Initialized
INFO - 2017-07-22 13:39:31 --> Router Class Initialized
INFO - 2017-07-22 13:39:31 --> Output Class Initialized
INFO - 2017-07-22 13:39:31 --> Security Class Initialized
DEBUG - 2017-07-22 13:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:39:31 --> Input Class Initialized
INFO - 2017-07-22 13:39:31 --> Language Class Initialized
INFO - 2017-07-22 13:39:31 --> Loader Class Initialized
INFO - 2017-07-22 13:39:31 --> Helper loaded: common_helper
INFO - 2017-07-22 13:39:31 --> Database Driver Class Initialized
INFO - 2017-07-22 13:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:39:31 --> Email Class Initialized
INFO - 2017-07-22 13:39:31 --> Controller Class Initialized
INFO - 2017-07-22 13:39:31 --> Helper loaded: form_helper
INFO - 2017-07-22 13:39:31 --> Form Validation Class Initialized
INFO - 2017-07-22 13:39:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:39:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:39:31 --> Helper loaded: url_helper
INFO - 2017-07-22 13:39:31 --> Model Class Initialized
INFO - 2017-07-22 13:39:31 --> Model Class Initialized
INFO - 2017-07-22 17:09:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:09:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:09:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 17:09:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 17:09:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 17:09:31 --> Final output sent to browser
DEBUG - 2017-07-22 17:09:31 --> Total execution time: 0.0469
INFO - 2017-07-22 13:39:35 --> Config Class Initialized
INFO - 2017-07-22 13:39:35 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:39:35 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:39:35 --> Utf8 Class Initialized
INFO - 2017-07-22 13:39:35 --> URI Class Initialized
INFO - 2017-07-22 13:39:35 --> Router Class Initialized
INFO - 2017-07-22 13:39:35 --> Output Class Initialized
INFO - 2017-07-22 13:39:35 --> Security Class Initialized
DEBUG - 2017-07-22 13:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:39:35 --> Input Class Initialized
INFO - 2017-07-22 13:39:35 --> Language Class Initialized
INFO - 2017-07-22 13:39:35 --> Loader Class Initialized
INFO - 2017-07-22 13:39:35 --> Helper loaded: common_helper
INFO - 2017-07-22 13:39:35 --> Database Driver Class Initialized
INFO - 2017-07-22 13:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:39:35 --> Email Class Initialized
INFO - 2017-07-22 13:39:35 --> Controller Class Initialized
INFO - 2017-07-22 13:39:35 --> Helper loaded: form_helper
INFO - 2017-07-22 13:39:35 --> Form Validation Class Initialized
INFO - 2017-07-22 13:39:35 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:39:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:39:35 --> Helper loaded: url_helper
INFO - 2017-07-22 13:39:35 --> Model Class Initialized
INFO - 2017-07-22 13:39:35 --> Model Class Initialized
INFO - 2017-07-22 13:40:15 --> Config Class Initialized
INFO - 2017-07-22 13:40:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:40:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:40:15 --> Utf8 Class Initialized
INFO - 2017-07-22 13:40:15 --> URI Class Initialized
INFO - 2017-07-22 13:40:15 --> Router Class Initialized
INFO - 2017-07-22 13:40:15 --> Output Class Initialized
INFO - 2017-07-22 13:40:15 --> Security Class Initialized
DEBUG - 2017-07-22 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:40:15 --> Input Class Initialized
INFO - 2017-07-22 13:40:15 --> Language Class Initialized
INFO - 2017-07-22 13:40:15 --> Loader Class Initialized
INFO - 2017-07-22 13:40:15 --> Helper loaded: common_helper
INFO - 2017-07-22 13:40:15 --> Database Driver Class Initialized
INFO - 2017-07-22 13:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:40:15 --> Email Class Initialized
INFO - 2017-07-22 13:40:15 --> Controller Class Initialized
INFO - 2017-07-22 13:40:15 --> Helper loaded: form_helper
INFO - 2017-07-22 13:40:15 --> Form Validation Class Initialized
INFO - 2017-07-22 13:40:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:40:15 --> Helper loaded: url_helper
INFO - 2017-07-22 13:40:15 --> Model Class Initialized
INFO - 2017-07-22 13:40:15 --> Model Class Initialized
INFO - 2017-07-22 13:40:32 --> Config Class Initialized
INFO - 2017-07-22 13:40:32 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:40:32 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:40:32 --> Utf8 Class Initialized
INFO - 2017-07-22 13:40:32 --> URI Class Initialized
INFO - 2017-07-22 13:40:32 --> Router Class Initialized
INFO - 2017-07-22 13:40:32 --> Output Class Initialized
INFO - 2017-07-22 13:40:32 --> Security Class Initialized
DEBUG - 2017-07-22 13:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:40:32 --> Input Class Initialized
INFO - 2017-07-22 13:40:32 --> Language Class Initialized
INFO - 2017-07-22 13:40:32 --> Loader Class Initialized
INFO - 2017-07-22 13:40:32 --> Helper loaded: common_helper
INFO - 2017-07-22 13:40:32 --> Database Driver Class Initialized
INFO - 2017-07-22 13:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:40:32 --> Email Class Initialized
INFO - 2017-07-22 13:40:32 --> Controller Class Initialized
INFO - 2017-07-22 13:40:32 --> Helper loaded: form_helper
INFO - 2017-07-22 13:40:32 --> Form Validation Class Initialized
INFO - 2017-07-22 13:40:32 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:40:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:40:32 --> Helper loaded: url_helper
INFO - 2017-07-22 13:40:32 --> Model Class Initialized
INFO - 2017-07-22 13:40:32 --> Model Class Initialized
INFO - 2017-07-22 13:41:43 --> Config Class Initialized
INFO - 2017-07-22 13:41:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 13:41:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 13:41:43 --> Utf8 Class Initialized
INFO - 2017-07-22 13:41:43 --> URI Class Initialized
INFO - 2017-07-22 13:41:43 --> Router Class Initialized
INFO - 2017-07-22 13:41:44 --> Output Class Initialized
INFO - 2017-07-22 13:41:44 --> Security Class Initialized
DEBUG - 2017-07-22 13:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 13:41:44 --> Input Class Initialized
INFO - 2017-07-22 13:41:44 --> Language Class Initialized
INFO - 2017-07-22 13:41:44 --> Loader Class Initialized
INFO - 2017-07-22 13:41:44 --> Helper loaded: common_helper
INFO - 2017-07-22 13:41:44 --> Database Driver Class Initialized
INFO - 2017-07-22 13:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 13:41:44 --> Email Class Initialized
INFO - 2017-07-22 13:41:44 --> Controller Class Initialized
INFO - 2017-07-22 13:41:44 --> Helper loaded: form_helper
INFO - 2017-07-22 13:41:44 --> Form Validation Class Initialized
INFO - 2017-07-22 13:41:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 13:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 13:41:44 --> Helper loaded: url_helper
INFO - 2017-07-22 13:41:44 --> Model Class Initialized
INFO - 2017-07-22 13:41:44 --> Model Class Initialized
INFO - 2017-07-22 17:11:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 17:11:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 17:11:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 17:11:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 17:11:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 17:11:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 17:11:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 17:11:44 --> Final output sent to browser
DEBUG - 2017-07-22 17:11:44 --> Total execution time: 0.1371
INFO - 2017-07-22 14:54:18 --> Config Class Initialized
INFO - 2017-07-22 14:54:18 --> Hooks Class Initialized
DEBUG - 2017-07-22 14:54:18 --> UTF-8 Support Enabled
INFO - 2017-07-22 14:54:18 --> Utf8 Class Initialized
INFO - 2017-07-22 14:54:18 --> URI Class Initialized
INFO - 2017-07-22 14:54:18 --> Router Class Initialized
INFO - 2017-07-22 14:54:18 --> Output Class Initialized
INFO - 2017-07-22 14:54:18 --> Security Class Initialized
DEBUG - 2017-07-22 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 14:54:18 --> Input Class Initialized
INFO - 2017-07-22 14:54:18 --> Language Class Initialized
ERROR - 2017-07-22 14:54:18 --> syntax error, unexpected '*'
ERROR - 2017-07-22 14:54:18 --> Severity: Parsing Error --> syntax error, unexpected '*' C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 116
INFO - 2017-07-22 14:54:40 --> Config Class Initialized
INFO - 2017-07-22 14:54:40 --> Hooks Class Initialized
DEBUG - 2017-07-22 14:54:40 --> UTF-8 Support Enabled
INFO - 2017-07-22 14:54:40 --> Utf8 Class Initialized
INFO - 2017-07-22 14:54:40 --> URI Class Initialized
INFO - 2017-07-22 14:54:40 --> Router Class Initialized
INFO - 2017-07-22 14:54:40 --> Output Class Initialized
INFO - 2017-07-22 14:54:40 --> Security Class Initialized
DEBUG - 2017-07-22 14:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 14:54:40 --> Input Class Initialized
INFO - 2017-07-22 14:54:40 --> Language Class Initialized
INFO - 2017-07-22 14:54:40 --> Loader Class Initialized
INFO - 2017-07-22 14:54:40 --> Helper loaded: common_helper
INFO - 2017-07-22 14:54:40 --> Database Driver Class Initialized
INFO - 2017-07-22 14:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 14:54:40 --> Email Class Initialized
INFO - 2017-07-22 14:54:40 --> Controller Class Initialized
INFO - 2017-07-22 14:54:40 --> Helper loaded: form_helper
INFO - 2017-07-22 14:54:40 --> Form Validation Class Initialized
INFO - 2017-07-22 14:54:40 --> Helper loaded: email_helper
DEBUG - 2017-07-22 14:54:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 14:54:40 --> Helper loaded: url_helper
INFO - 2017-07-22 14:54:40 --> Model Class Initialized
INFO - 2017-07-22 14:54:40 --> Model Class Initialized
INFO - 2017-07-22 18:24:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:24:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:24:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:24:40 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:24:40 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:24:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:24:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:24:40 --> Final output sent to browser
DEBUG - 2017-07-22 18:24:40 --> Total execution time: 0.0708
INFO - 2017-07-22 14:54:43 --> Config Class Initialized
INFO - 2017-07-22 14:54:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 14:54:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 14:54:43 --> Utf8 Class Initialized
INFO - 2017-07-22 14:54:43 --> URI Class Initialized
INFO - 2017-07-22 14:54:43 --> Router Class Initialized
INFO - 2017-07-22 14:54:43 --> Output Class Initialized
INFO - 2017-07-22 14:54:43 --> Security Class Initialized
DEBUG - 2017-07-22 14:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 14:54:43 --> Input Class Initialized
INFO - 2017-07-22 14:54:43 --> Language Class Initialized
INFO - 2017-07-22 14:54:43 --> Loader Class Initialized
INFO - 2017-07-22 14:54:43 --> Helper loaded: common_helper
INFO - 2017-07-22 14:54:43 --> Database Driver Class Initialized
INFO - 2017-07-22 14:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 14:54:43 --> Email Class Initialized
INFO - 2017-07-22 14:54:43 --> Controller Class Initialized
INFO - 2017-07-22 14:54:43 --> Helper loaded: form_helper
INFO - 2017-07-22 14:54:43 --> Form Validation Class Initialized
INFO - 2017-07-22 14:54:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 14:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 14:54:43 --> Helper loaded: url_helper
INFO - 2017-07-22 14:54:43 --> Model Class Initialized
INFO - 2017-07-22 14:54:43 --> Model Class Initialized
INFO - 2017-07-22 18:24:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:24:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:24:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:24:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:24:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:24:43 --> Final output sent to browser
DEBUG - 2017-07-22 18:24:43 --> Total execution time: 0.0509
INFO - 2017-07-22 14:55:10 --> Config Class Initialized
INFO - 2017-07-22 14:55:10 --> Hooks Class Initialized
DEBUG - 2017-07-22 14:55:10 --> UTF-8 Support Enabled
INFO - 2017-07-22 14:55:10 --> Utf8 Class Initialized
INFO - 2017-07-22 14:55:10 --> URI Class Initialized
INFO - 2017-07-22 14:55:10 --> Router Class Initialized
INFO - 2017-07-22 14:55:10 --> Output Class Initialized
INFO - 2017-07-22 14:55:10 --> Security Class Initialized
DEBUG - 2017-07-22 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 14:55:10 --> Input Class Initialized
INFO - 2017-07-22 14:55:10 --> Language Class Initialized
INFO - 2017-07-22 14:55:10 --> Loader Class Initialized
INFO - 2017-07-22 14:55:10 --> Helper loaded: common_helper
INFO - 2017-07-22 14:55:10 --> Database Driver Class Initialized
INFO - 2017-07-22 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 14:55:10 --> Email Class Initialized
INFO - 2017-07-22 14:55:10 --> Controller Class Initialized
INFO - 2017-07-22 14:55:10 --> Helper loaded: form_helper
INFO - 2017-07-22 14:55:10 --> Form Validation Class Initialized
INFO - 2017-07-22 14:55:10 --> Helper loaded: email_helper
DEBUG - 2017-07-22 14:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 14:55:10 --> Helper loaded: url_helper
INFO - 2017-07-22 14:55:10 --> Model Class Initialized
INFO - 2017-07-22 14:55:10 --> Model Class Initialized
DEBUG - 2017-07-22 18:25:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 18:25:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-07-22 18:25:10 --> Undefined variable: id
ERROR - 2017-07-22 18:25:10 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 112
INFO - 2017-07-22 14:55:10 --> Config Class Initialized
INFO - 2017-07-22 14:55:10 --> Hooks Class Initialized
DEBUG - 2017-07-22 14:55:10 --> UTF-8 Support Enabled
INFO - 2017-07-22 14:55:10 --> Utf8 Class Initialized
INFO - 2017-07-22 14:55:10 --> URI Class Initialized
INFO - 2017-07-22 14:55:10 --> Router Class Initialized
INFO - 2017-07-22 14:55:10 --> Output Class Initialized
INFO - 2017-07-22 14:55:10 --> Security Class Initialized
DEBUG - 2017-07-22 14:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 14:55:10 --> Input Class Initialized
INFO - 2017-07-22 14:55:10 --> Language Class Initialized
INFO - 2017-07-22 14:55:10 --> Loader Class Initialized
INFO - 2017-07-22 14:55:10 --> Helper loaded: common_helper
INFO - 2017-07-22 14:55:10 --> Database Driver Class Initialized
INFO - 2017-07-22 14:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 14:55:10 --> Email Class Initialized
INFO - 2017-07-22 14:55:10 --> Controller Class Initialized
INFO - 2017-07-22 14:55:10 --> Helper loaded: form_helper
INFO - 2017-07-22 14:55:10 --> Form Validation Class Initialized
INFO - 2017-07-22 14:55:10 --> Helper loaded: email_helper
DEBUG - 2017-07-22 14:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 14:55:10 --> Helper loaded: url_helper
INFO - 2017-07-22 18:25:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:25:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:25:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 18:25:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:25:10 --> Final output sent to browser
DEBUG - 2017-07-22 18:25:10 --> Total execution time: 0.0429
INFO - 2017-07-22 14:55:19 --> Config Class Initialized
INFO - 2017-07-22 14:55:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 14:55:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 14:55:19 --> Utf8 Class Initialized
INFO - 2017-07-22 14:55:19 --> URI Class Initialized
INFO - 2017-07-22 14:55:19 --> Router Class Initialized
INFO - 2017-07-22 14:55:19 --> Output Class Initialized
INFO - 2017-07-22 14:55:19 --> Security Class Initialized
DEBUG - 2017-07-22 14:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 14:55:19 --> Input Class Initialized
INFO - 2017-07-22 14:55:19 --> Language Class Initialized
INFO - 2017-07-22 14:55:19 --> Loader Class Initialized
INFO - 2017-07-22 14:55:19 --> Helper loaded: common_helper
INFO - 2017-07-22 14:55:19 --> Database Driver Class Initialized
INFO - 2017-07-22 14:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 14:55:19 --> Email Class Initialized
INFO - 2017-07-22 14:55:19 --> Controller Class Initialized
INFO - 2017-07-22 14:55:19 --> Helper loaded: form_helper
INFO - 2017-07-22 14:55:19 --> Form Validation Class Initialized
INFO - 2017-07-22 14:55:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 14:55:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 14:55:19 --> Helper loaded: url_helper
INFO - 2017-07-22 14:55:19 --> Model Class Initialized
INFO - 2017-07-22 14:55:19 --> Model Class Initialized
INFO - 2017-07-22 18:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:25:19 --> Final output sent to browser
DEBUG - 2017-07-22 18:25:19 --> Total execution time: 0.0503
INFO - 2017-07-22 15:07:11 --> Config Class Initialized
INFO - 2017-07-22 15:07:11 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:07:11 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:07:11 --> Utf8 Class Initialized
INFO - 2017-07-22 15:07:11 --> URI Class Initialized
INFO - 2017-07-22 15:07:11 --> Router Class Initialized
INFO - 2017-07-22 15:07:11 --> Output Class Initialized
INFO - 2017-07-22 15:07:11 --> Security Class Initialized
DEBUG - 2017-07-22 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:07:11 --> Input Class Initialized
INFO - 2017-07-22 15:07:11 --> Language Class Initialized
INFO - 2017-07-22 15:07:11 --> Loader Class Initialized
INFO - 2017-07-22 15:07:11 --> Helper loaded: common_helper
INFO - 2017-07-22 15:07:11 --> Database Driver Class Initialized
INFO - 2017-07-22 15:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:07:11 --> Email Class Initialized
INFO - 2017-07-22 15:07:11 --> Controller Class Initialized
INFO - 2017-07-22 15:07:11 --> Helper loaded: form_helper
INFO - 2017-07-22 15:07:11 --> Form Validation Class Initialized
INFO - 2017-07-22 15:07:11 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:07:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:07:11 --> Helper loaded: url_helper
INFO - 2017-07-22 15:07:11 --> Model Class Initialized
INFO - 2017-07-22 15:07:11 --> Model Class Initialized
INFO - 2017-07-22 18:37:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:37:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:37:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:37:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:37:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:37:11 --> Final output sent to browser
DEBUG - 2017-07-22 18:37:11 --> Total execution time: 0.0484
INFO - 2017-07-22 15:09:07 --> Config Class Initialized
INFO - 2017-07-22 15:09:07 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:09:07 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:09:07 --> Utf8 Class Initialized
INFO - 2017-07-22 15:09:07 --> URI Class Initialized
INFO - 2017-07-22 15:09:07 --> Router Class Initialized
INFO - 2017-07-22 15:09:07 --> Output Class Initialized
INFO - 2017-07-22 15:09:07 --> Security Class Initialized
DEBUG - 2017-07-22 15:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:09:07 --> Input Class Initialized
INFO - 2017-07-22 15:09:07 --> Language Class Initialized
INFO - 2017-07-22 15:09:07 --> Loader Class Initialized
INFO - 2017-07-22 15:09:07 --> Helper loaded: common_helper
INFO - 2017-07-22 15:09:07 --> Database Driver Class Initialized
INFO - 2017-07-22 15:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:09:07 --> Email Class Initialized
INFO - 2017-07-22 15:09:07 --> Controller Class Initialized
INFO - 2017-07-22 15:09:07 --> Helper loaded: form_helper
INFO - 2017-07-22 15:09:07 --> Form Validation Class Initialized
INFO - 2017-07-22 15:09:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:09:07 --> Helper loaded: url_helper
INFO - 2017-07-22 15:09:07 --> Model Class Initialized
INFO - 2017-07-22 15:09:07 --> Model Class Initialized
INFO - 2017-07-22 18:39:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:39:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:39:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:39:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:39:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:39:07 --> Final output sent to browser
DEBUG - 2017-07-22 18:39:07 --> Total execution time: 0.0526
INFO - 2017-07-22 15:09:43 --> Config Class Initialized
INFO - 2017-07-22 15:09:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:09:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:09:43 --> Utf8 Class Initialized
INFO - 2017-07-22 15:09:43 --> URI Class Initialized
INFO - 2017-07-22 15:09:43 --> Router Class Initialized
INFO - 2017-07-22 15:09:43 --> Output Class Initialized
INFO - 2017-07-22 15:09:43 --> Security Class Initialized
DEBUG - 2017-07-22 15:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:09:43 --> Input Class Initialized
INFO - 2017-07-22 15:09:43 --> Language Class Initialized
INFO - 2017-07-22 15:09:43 --> Loader Class Initialized
INFO - 2017-07-22 15:09:43 --> Helper loaded: common_helper
INFO - 2017-07-22 15:09:43 --> Database Driver Class Initialized
INFO - 2017-07-22 15:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:09:43 --> Email Class Initialized
INFO - 2017-07-22 15:09:43 --> Controller Class Initialized
INFO - 2017-07-22 15:09:43 --> Helper loaded: form_helper
INFO - 2017-07-22 15:09:43 --> Form Validation Class Initialized
INFO - 2017-07-22 15:09:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:09:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:09:43 --> Helper loaded: url_helper
INFO - 2017-07-22 15:09:43 --> Model Class Initialized
INFO - 2017-07-22 15:09:43 --> Model Class Initialized
INFO - 2017-07-22 18:39:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:39:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:39:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:39:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:39:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:39:43 --> Final output sent to browser
DEBUG - 2017-07-22 18:39:43 --> Total execution time: 0.0526
INFO - 2017-07-22 15:09:51 --> Config Class Initialized
INFO - 2017-07-22 15:09:51 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:09:52 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:09:52 --> Utf8 Class Initialized
INFO - 2017-07-22 15:09:52 --> URI Class Initialized
INFO - 2017-07-22 15:09:52 --> Router Class Initialized
INFO - 2017-07-22 15:09:52 --> Output Class Initialized
INFO - 2017-07-22 15:09:52 --> Security Class Initialized
DEBUG - 2017-07-22 15:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:09:52 --> Input Class Initialized
INFO - 2017-07-22 15:09:52 --> Language Class Initialized
INFO - 2017-07-22 15:09:52 --> Loader Class Initialized
INFO - 2017-07-22 15:09:52 --> Helper loaded: common_helper
INFO - 2017-07-22 15:09:52 --> Database Driver Class Initialized
INFO - 2017-07-22 15:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:09:52 --> Email Class Initialized
INFO - 2017-07-22 15:09:52 --> Controller Class Initialized
INFO - 2017-07-22 15:09:52 --> Helper loaded: form_helper
INFO - 2017-07-22 15:09:52 --> Form Validation Class Initialized
INFO - 2017-07-22 15:09:52 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:09:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:09:52 --> Helper loaded: url_helper
INFO - 2017-07-22 15:09:52 --> Model Class Initialized
INFO - 2017-07-22 15:09:52 --> Model Class Initialized
INFO - 2017-07-22 15:14:39 --> Config Class Initialized
INFO - 2017-07-22 15:14:39 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:14:39 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:14:39 --> Utf8 Class Initialized
INFO - 2017-07-22 15:14:39 --> URI Class Initialized
INFO - 2017-07-22 15:14:39 --> Router Class Initialized
INFO - 2017-07-22 15:14:39 --> Output Class Initialized
INFO - 2017-07-22 15:14:39 --> Security Class Initialized
DEBUG - 2017-07-22 15:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:14:39 --> Input Class Initialized
INFO - 2017-07-22 15:14:39 --> Language Class Initialized
INFO - 2017-07-22 15:14:39 --> Loader Class Initialized
INFO - 2017-07-22 15:14:39 --> Helper loaded: common_helper
INFO - 2017-07-22 15:14:39 --> Database Driver Class Initialized
INFO - 2017-07-22 15:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:14:39 --> Email Class Initialized
INFO - 2017-07-22 15:14:39 --> Controller Class Initialized
INFO - 2017-07-22 15:14:39 --> Helper loaded: form_helper
INFO - 2017-07-22 15:14:39 --> Form Validation Class Initialized
INFO - 2017-07-22 15:14:39 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:14:39 --> Helper loaded: url_helper
INFO - 2017-07-22 15:14:39 --> Model Class Initialized
INFO - 2017-07-22 15:14:39 --> Model Class Initialized
INFO - 2017-07-22 15:14:49 --> Config Class Initialized
INFO - 2017-07-22 15:14:49 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:14:49 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:14:49 --> Utf8 Class Initialized
INFO - 2017-07-22 15:14:49 --> URI Class Initialized
INFO - 2017-07-22 15:14:49 --> Router Class Initialized
INFO - 2017-07-22 15:14:49 --> Output Class Initialized
INFO - 2017-07-22 15:14:49 --> Security Class Initialized
DEBUG - 2017-07-22 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:14:49 --> Input Class Initialized
INFO - 2017-07-22 15:14:49 --> Language Class Initialized
INFO - 2017-07-22 15:14:49 --> Loader Class Initialized
INFO - 2017-07-22 15:14:49 --> Helper loaded: common_helper
INFO - 2017-07-22 15:14:49 --> Database Driver Class Initialized
INFO - 2017-07-22 15:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:14:49 --> Email Class Initialized
INFO - 2017-07-22 15:14:49 --> Controller Class Initialized
INFO - 2017-07-22 15:14:49 --> Helper loaded: form_helper
INFO - 2017-07-22 15:14:49 --> Form Validation Class Initialized
INFO - 2017-07-22 15:14:49 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:14:49 --> Helper loaded: url_helper
INFO - 2017-07-22 15:14:49 --> Model Class Initialized
INFO - 2017-07-22 15:14:49 --> Model Class Initialized
DEBUG - 2017-07-22 18:44:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 18:44:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 15:14:49 --> Config Class Initialized
INFO - 2017-07-22 15:14:49 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:14:49 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:14:49 --> Utf8 Class Initialized
INFO - 2017-07-22 15:14:49 --> URI Class Initialized
INFO - 2017-07-22 15:14:49 --> Router Class Initialized
INFO - 2017-07-22 15:14:49 --> Output Class Initialized
INFO - 2017-07-22 15:14:49 --> Security Class Initialized
DEBUG - 2017-07-22 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:14:49 --> Input Class Initialized
INFO - 2017-07-22 15:14:49 --> Language Class Initialized
INFO - 2017-07-22 15:14:49 --> Loader Class Initialized
INFO - 2017-07-22 15:14:49 --> Helper loaded: common_helper
INFO - 2017-07-22 15:14:49 --> Database Driver Class Initialized
INFO - 2017-07-22 15:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:14:49 --> Email Class Initialized
INFO - 2017-07-22 15:14:49 --> Controller Class Initialized
INFO - 2017-07-22 15:14:49 --> Helper loaded: form_helper
INFO - 2017-07-22 15:14:49 --> Form Validation Class Initialized
INFO - 2017-07-22 15:14:49 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:14:49 --> Helper loaded: url_helper
INFO - 2017-07-22 15:14:49 --> Model Class Initialized
INFO - 2017-07-22 15:14:49 --> Model Class Initialized
INFO - 2017-07-22 18:44:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:44:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:44:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:44:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:44:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:44:49 --> Final output sent to browser
DEBUG - 2017-07-22 18:44:49 --> Total execution time: 0.0482
INFO - 2017-07-22 15:14:56 --> Config Class Initialized
INFO - 2017-07-22 15:14:56 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:14:56 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:14:56 --> Utf8 Class Initialized
INFO - 2017-07-22 15:14:56 --> URI Class Initialized
INFO - 2017-07-22 15:14:56 --> Router Class Initialized
INFO - 2017-07-22 15:14:56 --> Output Class Initialized
INFO - 2017-07-22 15:14:56 --> Security Class Initialized
DEBUG - 2017-07-22 15:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:14:56 --> Input Class Initialized
INFO - 2017-07-22 15:14:56 --> Language Class Initialized
INFO - 2017-07-22 15:14:56 --> Loader Class Initialized
INFO - 2017-07-22 15:14:56 --> Helper loaded: common_helper
INFO - 2017-07-22 15:14:56 --> Database Driver Class Initialized
INFO - 2017-07-22 15:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:14:56 --> Email Class Initialized
INFO - 2017-07-22 15:14:56 --> Controller Class Initialized
INFO - 2017-07-22 15:14:56 --> Helper loaded: form_helper
INFO - 2017-07-22 15:14:56 --> Form Validation Class Initialized
INFO - 2017-07-22 15:14:56 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:14:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:14:56 --> Helper loaded: url_helper
INFO - 2017-07-22 15:14:56 --> Model Class Initialized
INFO - 2017-07-22 15:14:56 --> Model Class Initialized
INFO - 2017-07-22 18:44:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:44:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:44:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:44:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:44:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:44:56 --> Final output sent to browser
DEBUG - 2017-07-22 18:44:56 --> Total execution time: 0.0509
INFO - 2017-07-22 15:15:13 --> Config Class Initialized
INFO - 2017-07-22 15:15:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:15:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:15:13 --> Utf8 Class Initialized
INFO - 2017-07-22 15:15:13 --> URI Class Initialized
INFO - 2017-07-22 15:15:13 --> Router Class Initialized
INFO - 2017-07-22 15:15:13 --> Output Class Initialized
INFO - 2017-07-22 15:15:13 --> Security Class Initialized
DEBUG - 2017-07-22 15:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:15:13 --> Input Class Initialized
INFO - 2017-07-22 15:15:13 --> Language Class Initialized
INFO - 2017-07-22 15:15:13 --> Loader Class Initialized
INFO - 2017-07-22 15:15:13 --> Helper loaded: common_helper
INFO - 2017-07-22 15:15:13 --> Database Driver Class Initialized
INFO - 2017-07-22 15:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:15:13 --> Email Class Initialized
INFO - 2017-07-22 15:15:13 --> Controller Class Initialized
INFO - 2017-07-22 15:15:13 --> Helper loaded: form_helper
INFO - 2017-07-22 15:15:13 --> Form Validation Class Initialized
INFO - 2017-07-22 15:15:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:15:13 --> Helper loaded: url_helper
INFO - 2017-07-22 15:15:13 --> Model Class Initialized
INFO - 2017-07-22 15:15:13 --> Model Class Initialized
DEBUG - 2017-07-22 18:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-07-22 18:45:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-07-22 15:15:13 --> Config Class Initialized
INFO - 2017-07-22 15:15:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:15:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:15:13 --> Utf8 Class Initialized
INFO - 2017-07-22 15:15:13 --> URI Class Initialized
INFO - 2017-07-22 15:15:13 --> Router Class Initialized
INFO - 2017-07-22 15:15:13 --> Output Class Initialized
INFO - 2017-07-22 15:15:13 --> Security Class Initialized
DEBUG - 2017-07-22 15:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:15:13 --> Input Class Initialized
INFO - 2017-07-22 15:15:13 --> Language Class Initialized
INFO - 2017-07-22 15:15:13 --> Loader Class Initialized
INFO - 2017-07-22 15:15:13 --> Helper loaded: common_helper
INFO - 2017-07-22 15:15:13 --> Database Driver Class Initialized
INFO - 2017-07-22 15:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:15:13 --> Email Class Initialized
INFO - 2017-07-22 15:15:13 --> Controller Class Initialized
INFO - 2017-07-22 15:15:13 --> Helper loaded: form_helper
INFO - 2017-07-22 15:15:13 --> Form Validation Class Initialized
INFO - 2017-07-22 15:15:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:15:13 --> Helper loaded: url_helper
INFO - 2017-07-22 15:15:13 --> Model Class Initialized
INFO - 2017-07-22 15:15:13 --> Model Class Initialized
INFO - 2017-07-22 18:45:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:45:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:45:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:45:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:45:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:45:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:45:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:45:13 --> Final output sent to browser
DEBUG - 2017-07-22 18:45:13 --> Total execution time: 0.0996
INFO - 2017-07-22 15:15:19 --> Config Class Initialized
INFO - 2017-07-22 15:15:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:15:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:15:19 --> Utf8 Class Initialized
INFO - 2017-07-22 15:15:19 --> URI Class Initialized
INFO - 2017-07-22 15:15:19 --> Router Class Initialized
INFO - 2017-07-22 15:15:19 --> Output Class Initialized
INFO - 2017-07-22 15:15:19 --> Security Class Initialized
DEBUG - 2017-07-22 15:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:15:19 --> Input Class Initialized
INFO - 2017-07-22 15:15:19 --> Language Class Initialized
INFO - 2017-07-22 15:15:19 --> Loader Class Initialized
INFO - 2017-07-22 15:15:19 --> Helper loaded: common_helper
INFO - 2017-07-22 15:15:19 --> Database Driver Class Initialized
INFO - 2017-07-22 15:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:15:19 --> Email Class Initialized
INFO - 2017-07-22 15:15:19 --> Controller Class Initialized
INFO - 2017-07-22 15:15:19 --> Helper loaded: form_helper
INFO - 2017-07-22 15:15:19 --> Form Validation Class Initialized
INFO - 2017-07-22 15:15:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:15:19 --> Helper loaded: url_helper
INFO - 2017-07-22 15:15:19 --> Model Class Initialized
INFO - 2017-07-22 15:15:19 --> Model Class Initialized
INFO - 2017-07-22 18:45:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:45:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:45:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:45:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:45:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:45:19 --> Final output sent to browser
DEBUG - 2017-07-22 18:45:19 --> Total execution time: 0.0485
INFO - 2017-07-22 15:15:37 --> Config Class Initialized
INFO - 2017-07-22 15:15:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:15:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:15:37 --> Utf8 Class Initialized
INFO - 2017-07-22 15:15:37 --> URI Class Initialized
INFO - 2017-07-22 15:15:37 --> Router Class Initialized
INFO - 2017-07-22 15:15:37 --> Output Class Initialized
INFO - 2017-07-22 15:15:37 --> Security Class Initialized
DEBUG - 2017-07-22 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:15:37 --> Input Class Initialized
INFO - 2017-07-22 15:15:37 --> Language Class Initialized
INFO - 2017-07-22 15:15:37 --> Loader Class Initialized
INFO - 2017-07-22 15:15:37 --> Helper loaded: common_helper
INFO - 2017-07-22 15:15:37 --> Database Driver Class Initialized
INFO - 2017-07-22 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:15:37 --> Email Class Initialized
INFO - 2017-07-22 15:15:37 --> Controller Class Initialized
INFO - 2017-07-22 15:15:37 --> Helper loaded: form_helper
INFO - 2017-07-22 15:15:37 --> Form Validation Class Initialized
INFO - 2017-07-22 15:15:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:15:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:15:37 --> Helper loaded: url_helper
INFO - 2017-07-22 15:15:37 --> Model Class Initialized
INFO - 2017-07-22 15:15:37 --> Model Class Initialized
ERROR - 2017-07-22 18:45:37 --> Undefined index: edit_news_Image
ERROR - 2017-07-22 18:45:37 --> Severity: Notice --> Undefined index: edit_news_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 211
ERROR - 2017-07-22 18:45:37 --> Undefined variable: imageData
ERROR - 2017-07-22 18:45:37 --> Severity: Notice --> Undefined variable: imageData C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 233
INFO - 2017-07-22 18:45:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:45:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:45:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:45:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:45:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:45:37 --> Final output sent to browser
DEBUG - 2017-07-22 18:45:37 --> Total execution time: 0.1728
INFO - 2017-07-22 15:16:09 --> Config Class Initialized
INFO - 2017-07-22 15:16:09 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:16:09 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:16:09 --> Utf8 Class Initialized
INFO - 2017-07-22 15:16:09 --> URI Class Initialized
INFO - 2017-07-22 15:16:09 --> Router Class Initialized
INFO - 2017-07-22 15:16:09 --> Output Class Initialized
INFO - 2017-07-22 15:16:09 --> Security Class Initialized
DEBUG - 2017-07-22 15:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:16:09 --> Input Class Initialized
INFO - 2017-07-22 15:16:09 --> Language Class Initialized
INFO - 2017-07-22 15:16:09 --> Loader Class Initialized
INFO - 2017-07-22 15:16:09 --> Helper loaded: common_helper
INFO - 2017-07-22 15:16:09 --> Database Driver Class Initialized
INFO - 2017-07-22 15:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:16:09 --> Email Class Initialized
INFO - 2017-07-22 15:16:09 --> Controller Class Initialized
INFO - 2017-07-22 15:16:09 --> Helper loaded: form_helper
INFO - 2017-07-22 15:16:09 --> Form Validation Class Initialized
INFO - 2017-07-22 15:16:09 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:16:09 --> Helper loaded: url_helper
INFO - 2017-07-22 15:16:09 --> Model Class Initialized
INFO - 2017-07-22 15:16:09 --> Model Class Initialized
INFO - 2017-07-22 18:46:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:46:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:46:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:46:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:46:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:46:09 --> Final output sent to browser
DEBUG - 2017-07-22 18:46:09 --> Total execution time: 0.0518
INFO - 2017-07-22 15:16:13 --> Config Class Initialized
INFO - 2017-07-22 15:16:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:16:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:16:14 --> Utf8 Class Initialized
INFO - 2017-07-22 15:16:14 --> URI Class Initialized
INFO - 2017-07-22 15:16:14 --> Router Class Initialized
INFO - 2017-07-22 15:16:14 --> Output Class Initialized
INFO - 2017-07-22 15:16:14 --> Security Class Initialized
DEBUG - 2017-07-22 15:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:16:14 --> Input Class Initialized
INFO - 2017-07-22 15:16:14 --> Language Class Initialized
INFO - 2017-07-22 15:16:14 --> Loader Class Initialized
INFO - 2017-07-22 15:16:14 --> Helper loaded: common_helper
INFO - 2017-07-22 15:16:14 --> Database Driver Class Initialized
INFO - 2017-07-22 15:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:16:14 --> Email Class Initialized
INFO - 2017-07-22 15:16:14 --> Controller Class Initialized
INFO - 2017-07-22 15:16:14 --> Helper loaded: form_helper
INFO - 2017-07-22 15:16:14 --> Form Validation Class Initialized
INFO - 2017-07-22 15:16:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:16:14 --> Helper loaded: url_helper
INFO - 2017-07-22 15:16:14 --> Model Class Initialized
INFO - 2017-07-22 15:16:14 --> Model Class Initialized
ERROR - 2017-07-22 18:46:14 --> Undefined index: edit_news_Image
ERROR - 2017-07-22 18:46:14 --> Severity: Notice --> Undefined index: edit_news_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 211
INFO - 2017-07-22 18:46:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:46:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:46:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:46:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:46:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:46:14 --> Final output sent to browser
DEBUG - 2017-07-22 18:46:14 --> Total execution time: 0.1749
INFO - 2017-07-22 15:17:04 --> Config Class Initialized
INFO - 2017-07-22 15:17:04 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:17:04 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:17:04 --> Utf8 Class Initialized
INFO - 2017-07-22 15:17:04 --> URI Class Initialized
INFO - 2017-07-22 15:17:04 --> Router Class Initialized
INFO - 2017-07-22 15:17:04 --> Output Class Initialized
INFO - 2017-07-22 15:17:04 --> Security Class Initialized
DEBUG - 2017-07-22 15:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:17:04 --> Input Class Initialized
INFO - 2017-07-22 15:17:04 --> Language Class Initialized
INFO - 2017-07-22 15:17:04 --> Loader Class Initialized
INFO - 2017-07-22 15:17:04 --> Helper loaded: common_helper
INFO - 2017-07-22 15:17:04 --> Database Driver Class Initialized
INFO - 2017-07-22 15:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:17:04 --> Email Class Initialized
INFO - 2017-07-22 15:17:04 --> Controller Class Initialized
INFO - 2017-07-22 15:17:04 --> Helper loaded: form_helper
INFO - 2017-07-22 15:17:04 --> Form Validation Class Initialized
INFO - 2017-07-22 15:17:04 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:17:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:17:04 --> Helper loaded: url_helper
INFO - 2017-07-22 15:17:04 --> Model Class Initialized
INFO - 2017-07-22 15:17:04 --> Model Class Initialized
INFO - 2017-07-22 18:47:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:47:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:47:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:47:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:47:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:47:04 --> Final output sent to browser
DEBUG - 2017-07-22 18:47:04 --> Total execution time: 0.0512
INFO - 2017-07-22 15:17:06 --> Config Class Initialized
INFO - 2017-07-22 15:17:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:17:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:17:06 --> Utf8 Class Initialized
INFO - 2017-07-22 15:17:06 --> URI Class Initialized
INFO - 2017-07-22 15:17:06 --> Router Class Initialized
INFO - 2017-07-22 15:17:06 --> Output Class Initialized
INFO - 2017-07-22 15:17:06 --> Security Class Initialized
DEBUG - 2017-07-22 15:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:17:06 --> Input Class Initialized
INFO - 2017-07-22 15:17:06 --> Language Class Initialized
INFO - 2017-07-22 15:17:06 --> Loader Class Initialized
INFO - 2017-07-22 15:17:06 --> Helper loaded: common_helper
INFO - 2017-07-22 15:17:06 --> Database Driver Class Initialized
INFO - 2017-07-22 15:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:17:06 --> Email Class Initialized
INFO - 2017-07-22 15:17:06 --> Controller Class Initialized
INFO - 2017-07-22 15:17:06 --> Helper loaded: form_helper
INFO - 2017-07-22 15:17:06 --> Form Validation Class Initialized
INFO - 2017-07-22 15:17:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:17:06 --> Helper loaded: url_helper
INFO - 2017-07-22 15:17:06 --> Model Class Initialized
INFO - 2017-07-22 15:17:06 --> Model Class Initialized
INFO - 2017-07-22 15:17:16 --> Config Class Initialized
INFO - 2017-07-22 15:17:16 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:17:16 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:17:16 --> Utf8 Class Initialized
INFO - 2017-07-22 15:17:16 --> URI Class Initialized
INFO - 2017-07-22 15:17:16 --> Router Class Initialized
INFO - 2017-07-22 15:17:16 --> Output Class Initialized
INFO - 2017-07-22 15:17:16 --> Security Class Initialized
DEBUG - 2017-07-22 15:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:17:16 --> Input Class Initialized
INFO - 2017-07-22 15:17:16 --> Language Class Initialized
INFO - 2017-07-22 15:17:16 --> Loader Class Initialized
INFO - 2017-07-22 15:17:16 --> Helper loaded: common_helper
INFO - 2017-07-22 15:17:16 --> Database Driver Class Initialized
INFO - 2017-07-22 15:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:17:16 --> Email Class Initialized
INFO - 2017-07-22 15:17:16 --> Controller Class Initialized
INFO - 2017-07-22 15:17:16 --> Helper loaded: form_helper
INFO - 2017-07-22 15:17:16 --> Form Validation Class Initialized
INFO - 2017-07-22 15:17:16 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:17:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:17:16 --> Helper loaded: url_helper
INFO - 2017-07-22 15:17:16 --> Model Class Initialized
INFO - 2017-07-22 15:17:16 --> Model Class Initialized
ERROR - 2017-07-22 18:47:17 --> Undefined index: edit_news_Image
ERROR - 2017-07-22 18:47:17 --> Severity: Notice --> Undefined index: edit_news_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 212
INFO - 2017-07-22 15:18:19 --> Config Class Initialized
INFO - 2017-07-22 15:18:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:18:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:18:19 --> Utf8 Class Initialized
INFO - 2017-07-22 15:18:19 --> URI Class Initialized
INFO - 2017-07-22 15:18:19 --> Router Class Initialized
INFO - 2017-07-22 15:18:19 --> Output Class Initialized
INFO - 2017-07-22 15:18:19 --> Security Class Initialized
DEBUG - 2017-07-22 15:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:18:19 --> Input Class Initialized
INFO - 2017-07-22 15:18:19 --> Language Class Initialized
INFO - 2017-07-22 15:18:19 --> Loader Class Initialized
INFO - 2017-07-22 15:18:19 --> Helper loaded: common_helper
INFO - 2017-07-22 15:18:19 --> Database Driver Class Initialized
INFO - 2017-07-22 15:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:18:19 --> Email Class Initialized
INFO - 2017-07-22 15:18:19 --> Controller Class Initialized
INFO - 2017-07-22 15:18:19 --> Helper loaded: form_helper
INFO - 2017-07-22 15:18:19 --> Form Validation Class Initialized
INFO - 2017-07-22 15:18:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:18:19 --> Helper loaded: url_helper
INFO - 2017-07-22 15:18:19 --> Model Class Initialized
INFO - 2017-07-22 15:18:19 --> Model Class Initialized
ERROR - 2017-07-22 18:48:19 --> Undefined index: edit_news_Image
ERROR - 2017-07-22 18:48:19 --> Severity: Notice --> Undefined index: edit_news_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 212
INFO - 2017-07-22 15:18:22 --> Config Class Initialized
INFO - 2017-07-22 15:18:22 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:18:22 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:18:22 --> Utf8 Class Initialized
INFO - 2017-07-22 15:18:22 --> URI Class Initialized
INFO - 2017-07-22 15:18:22 --> Router Class Initialized
INFO - 2017-07-22 15:18:22 --> Output Class Initialized
INFO - 2017-07-22 15:18:22 --> Security Class Initialized
DEBUG - 2017-07-22 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:18:22 --> Input Class Initialized
INFO - 2017-07-22 15:18:22 --> Language Class Initialized
INFO - 2017-07-22 15:18:22 --> Loader Class Initialized
INFO - 2017-07-22 15:18:22 --> Helper loaded: common_helper
INFO - 2017-07-22 15:18:22 --> Database Driver Class Initialized
INFO - 2017-07-22 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:18:22 --> Email Class Initialized
INFO - 2017-07-22 15:18:22 --> Controller Class Initialized
INFO - 2017-07-22 15:18:22 --> Helper loaded: form_helper
INFO - 2017-07-22 15:18:22 --> Form Validation Class Initialized
INFO - 2017-07-22 15:18:22 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:18:22 --> Helper loaded: url_helper
INFO - 2017-07-22 15:18:22 --> Model Class Initialized
INFO - 2017-07-22 15:18:22 --> Model Class Initialized
INFO - 2017-07-22 18:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:48:22 --> Final output sent to browser
DEBUG - 2017-07-22 18:48:22 --> Total execution time: 0.0504
INFO - 2017-07-22 15:18:47 --> Config Class Initialized
INFO - 2017-07-22 15:18:47 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:18:47 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:18:47 --> Utf8 Class Initialized
INFO - 2017-07-22 15:18:47 --> URI Class Initialized
INFO - 2017-07-22 15:18:47 --> Router Class Initialized
INFO - 2017-07-22 15:18:47 --> Output Class Initialized
INFO - 2017-07-22 15:18:47 --> Security Class Initialized
DEBUG - 2017-07-22 15:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:18:47 --> Input Class Initialized
INFO - 2017-07-22 15:18:47 --> Language Class Initialized
INFO - 2017-07-22 15:18:47 --> Loader Class Initialized
INFO - 2017-07-22 15:18:47 --> Helper loaded: common_helper
INFO - 2017-07-22 15:18:47 --> Database Driver Class Initialized
INFO - 2017-07-22 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:18:47 --> Email Class Initialized
INFO - 2017-07-22 15:18:47 --> Controller Class Initialized
INFO - 2017-07-22 15:18:47 --> Helper loaded: form_helper
INFO - 2017-07-22 15:18:47 --> Form Validation Class Initialized
INFO - 2017-07-22 15:18:47 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:18:47 --> Helper loaded: url_helper
INFO - 2017-07-22 15:18:47 --> Model Class Initialized
INFO - 2017-07-22 15:18:47 --> Model Class Initialized
INFO - 2017-07-22 18:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:48:47 --> Final output sent to browser
DEBUG - 2017-07-22 18:48:47 --> Total execution time: 0.0555
INFO - 2017-07-22 15:18:53 --> Config Class Initialized
INFO - 2017-07-22 15:18:53 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:18:53 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:18:53 --> Utf8 Class Initialized
INFO - 2017-07-22 15:18:53 --> URI Class Initialized
INFO - 2017-07-22 15:18:53 --> Router Class Initialized
INFO - 2017-07-22 15:18:53 --> Output Class Initialized
INFO - 2017-07-22 15:18:53 --> Security Class Initialized
DEBUG - 2017-07-22 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:18:53 --> Input Class Initialized
INFO - 2017-07-22 15:18:53 --> Language Class Initialized
INFO - 2017-07-22 15:18:53 --> Loader Class Initialized
INFO - 2017-07-22 15:18:53 --> Helper loaded: common_helper
INFO - 2017-07-22 15:18:53 --> Database Driver Class Initialized
INFO - 2017-07-22 15:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:18:53 --> Email Class Initialized
INFO - 2017-07-22 15:18:53 --> Controller Class Initialized
INFO - 2017-07-22 15:18:53 --> Helper loaded: form_helper
INFO - 2017-07-22 15:18:53 --> Form Validation Class Initialized
INFO - 2017-07-22 15:18:53 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:18:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:18:53 --> Helper loaded: url_helper
INFO - 2017-07-22 15:18:53 --> Model Class Initialized
INFO - 2017-07-22 15:18:53 --> Model Class Initialized
ERROR - 2017-07-22 18:48:53 --> Undefined variable: imageData
ERROR - 2017-07-22 18:48:53 --> Severity: Notice --> Undefined variable: imageData C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 233
INFO - 2017-07-22 15:19:17 --> Config Class Initialized
INFO - 2017-07-22 15:19:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:19:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:19:17 --> Utf8 Class Initialized
INFO - 2017-07-22 15:19:17 --> URI Class Initialized
INFO - 2017-07-22 15:19:17 --> Router Class Initialized
INFO - 2017-07-22 15:19:17 --> Output Class Initialized
INFO - 2017-07-22 15:19:17 --> Security Class Initialized
DEBUG - 2017-07-22 15:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:19:17 --> Input Class Initialized
INFO - 2017-07-22 15:19:17 --> Language Class Initialized
INFO - 2017-07-22 15:19:17 --> Loader Class Initialized
INFO - 2017-07-22 15:19:17 --> Helper loaded: common_helper
INFO - 2017-07-22 15:19:17 --> Database Driver Class Initialized
INFO - 2017-07-22 15:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:19:17 --> Email Class Initialized
INFO - 2017-07-22 15:19:17 --> Controller Class Initialized
INFO - 2017-07-22 15:19:17 --> Helper loaded: form_helper
INFO - 2017-07-22 15:19:17 --> Form Validation Class Initialized
INFO - 2017-07-22 15:19:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:19:17 --> Helper loaded: url_helper
INFO - 2017-07-22 15:19:17 --> Model Class Initialized
INFO - 2017-07-22 15:19:17 --> Model Class Initialized
INFO - 2017-07-22 15:19:25 --> Config Class Initialized
INFO - 2017-07-22 15:19:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:19:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:19:25 --> Utf8 Class Initialized
INFO - 2017-07-22 15:19:25 --> URI Class Initialized
INFO - 2017-07-22 15:19:25 --> Router Class Initialized
INFO - 2017-07-22 15:19:25 --> Output Class Initialized
INFO - 2017-07-22 15:19:25 --> Security Class Initialized
DEBUG - 2017-07-22 15:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:19:25 --> Input Class Initialized
INFO - 2017-07-22 15:19:25 --> Language Class Initialized
INFO - 2017-07-22 15:19:25 --> Loader Class Initialized
INFO - 2017-07-22 15:19:25 --> Helper loaded: common_helper
INFO - 2017-07-22 15:19:25 --> Database Driver Class Initialized
INFO - 2017-07-22 15:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:19:25 --> Email Class Initialized
INFO - 2017-07-22 15:19:25 --> Controller Class Initialized
INFO - 2017-07-22 15:19:25 --> Helper loaded: form_helper
INFO - 2017-07-22 15:19:25 --> Form Validation Class Initialized
INFO - 2017-07-22 15:19:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:19:25 --> Helper loaded: url_helper
INFO - 2017-07-22 15:19:25 --> Model Class Initialized
INFO - 2017-07-22 15:19:25 --> Model Class Initialized
INFO - 2017-07-22 18:49:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:49:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:49:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:49:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:49:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:49:25 --> Final output sent to browser
DEBUG - 2017-07-22 18:49:25 --> Total execution time: 0.1103
INFO - 2017-07-22 15:19:30 --> Config Class Initialized
INFO - 2017-07-22 15:19:30 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:19:30 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:19:30 --> Utf8 Class Initialized
INFO - 2017-07-22 15:19:30 --> URI Class Initialized
INFO - 2017-07-22 15:19:30 --> Router Class Initialized
INFO - 2017-07-22 15:19:30 --> Output Class Initialized
INFO - 2017-07-22 15:19:30 --> Security Class Initialized
DEBUG - 2017-07-22 15:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:19:30 --> Input Class Initialized
INFO - 2017-07-22 15:19:30 --> Language Class Initialized
INFO - 2017-07-22 15:19:30 --> Loader Class Initialized
INFO - 2017-07-22 15:19:30 --> Helper loaded: common_helper
INFO - 2017-07-22 15:19:30 --> Database Driver Class Initialized
INFO - 2017-07-22 15:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:19:30 --> Email Class Initialized
INFO - 2017-07-22 15:19:30 --> Controller Class Initialized
INFO - 2017-07-22 15:19:30 --> Helper loaded: form_helper
INFO - 2017-07-22 15:19:30 --> Form Validation Class Initialized
INFO - 2017-07-22 15:19:30 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:19:30 --> Helper loaded: url_helper
INFO - 2017-07-22 15:19:30 --> Model Class Initialized
INFO - 2017-07-22 15:19:30 --> Model Class Initialized
INFO - 2017-07-22 15:20:55 --> Config Class Initialized
INFO - 2017-07-22 15:20:55 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:20:55 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:20:55 --> Utf8 Class Initialized
INFO - 2017-07-22 15:20:55 --> URI Class Initialized
INFO - 2017-07-22 15:20:55 --> Router Class Initialized
INFO - 2017-07-22 15:20:55 --> Output Class Initialized
INFO - 2017-07-22 15:20:55 --> Security Class Initialized
DEBUG - 2017-07-22 15:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:20:55 --> Input Class Initialized
INFO - 2017-07-22 15:20:55 --> Language Class Initialized
INFO - 2017-07-22 15:20:55 --> Loader Class Initialized
INFO - 2017-07-22 15:20:55 --> Helper loaded: common_helper
INFO - 2017-07-22 15:20:55 --> Database Driver Class Initialized
INFO - 2017-07-22 15:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:20:55 --> Email Class Initialized
INFO - 2017-07-22 15:20:55 --> Controller Class Initialized
INFO - 2017-07-22 15:20:55 --> Helper loaded: form_helper
INFO - 2017-07-22 15:20:55 --> Form Validation Class Initialized
INFO - 2017-07-22 15:20:55 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:20:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:20:55 --> Helper loaded: url_helper
INFO - 2017-07-22 15:20:55 --> Model Class Initialized
INFO - 2017-07-22 15:20:55 --> Model Class Initialized
INFO - 2017-07-22 18:50:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:50:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:50:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:50:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 18:50:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:50:55 --> Final output sent to browser
DEBUG - 2017-07-22 18:50:55 --> Total execution time: 0.0516
INFO - 2017-07-22 15:20:59 --> Config Class Initialized
INFO - 2017-07-22 15:20:59 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:20:59 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:20:59 --> Utf8 Class Initialized
INFO - 2017-07-22 15:20:59 --> URI Class Initialized
INFO - 2017-07-22 15:21:00 --> Router Class Initialized
INFO - 2017-07-22 15:21:00 --> Output Class Initialized
INFO - 2017-07-22 15:21:00 --> Security Class Initialized
DEBUG - 2017-07-22 15:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:21:00 --> Input Class Initialized
INFO - 2017-07-22 15:21:00 --> Language Class Initialized
INFO - 2017-07-22 15:21:00 --> Loader Class Initialized
INFO - 2017-07-22 15:21:00 --> Helper loaded: common_helper
INFO - 2017-07-22 15:21:00 --> Database Driver Class Initialized
INFO - 2017-07-22 15:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:21:00 --> Email Class Initialized
INFO - 2017-07-22 15:21:00 --> Controller Class Initialized
INFO - 2017-07-22 15:21:00 --> Helper loaded: form_helper
INFO - 2017-07-22 15:21:00 --> Form Validation Class Initialized
INFO - 2017-07-22 15:21:00 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:21:00 --> Helper loaded: url_helper
INFO - 2017-07-22 15:21:00 --> Model Class Initialized
INFO - 2017-07-22 15:21:00 --> Model Class Initialized
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:51:00 --> Final output sent to browser
DEBUG - 2017-07-22 18:51:00 --> Total execution time: 0.0617
INFO - 2017-07-22 15:21:00 --> Config Class Initialized
INFO - 2017-07-22 15:21:00 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:21:00 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:21:00 --> Utf8 Class Initialized
INFO - 2017-07-22 15:21:00 --> URI Class Initialized
INFO - 2017-07-22 15:21:00 --> Router Class Initialized
INFO - 2017-07-22 15:21:00 --> Output Class Initialized
INFO - 2017-07-22 15:21:00 --> Security Class Initialized
DEBUG - 2017-07-22 15:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:21:00 --> Input Class Initialized
INFO - 2017-07-22 15:21:00 --> Language Class Initialized
INFO - 2017-07-22 15:21:00 --> Loader Class Initialized
INFO - 2017-07-22 15:21:00 --> Helper loaded: common_helper
INFO - 2017-07-22 15:21:00 --> Database Driver Class Initialized
INFO - 2017-07-22 15:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:21:00 --> Email Class Initialized
INFO - 2017-07-22 15:21:00 --> Controller Class Initialized
INFO - 2017-07-22 15:21:00 --> Helper loaded: form_helper
INFO - 2017-07-22 15:21:00 --> Form Validation Class Initialized
INFO - 2017-07-22 15:21:00 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:21:00 --> Helper loaded: url_helper
INFO - 2017-07-22 15:21:00 --> Model Class Initialized
INFO - 2017-07-22 15:21:00 --> Model Class Initialized
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 18:51:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:51:00 --> Final output sent to browser
DEBUG - 2017-07-22 18:51:00 --> Total execution time: 0.0484
INFO - 2017-07-22 15:21:01 --> Config Class Initialized
INFO - 2017-07-22 15:21:01 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:21:01 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:21:01 --> Utf8 Class Initialized
INFO - 2017-07-22 15:21:01 --> URI Class Initialized
INFO - 2017-07-22 15:21:01 --> Router Class Initialized
INFO - 2017-07-22 15:21:01 --> Output Class Initialized
INFO - 2017-07-22 15:21:01 --> Security Class Initialized
DEBUG - 2017-07-22 15:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:21:01 --> Input Class Initialized
INFO - 2017-07-22 15:21:01 --> Language Class Initialized
INFO - 2017-07-22 15:21:01 --> Loader Class Initialized
INFO - 2017-07-22 15:21:01 --> Helper loaded: common_helper
INFO - 2017-07-22 15:21:01 --> Database Driver Class Initialized
INFO - 2017-07-22 15:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:21:01 --> Email Class Initialized
INFO - 2017-07-22 15:21:01 --> Controller Class Initialized
INFO - 2017-07-22 15:21:01 --> Helper loaded: form_helper
INFO - 2017-07-22 15:21:01 --> Form Validation Class Initialized
INFO - 2017-07-22 15:21:01 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:21:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:21:01 --> Helper loaded: url_helper
INFO - 2017-07-22 18:51:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:51:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:51:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:51:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 18:51:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:51:01 --> Final output sent to browser
DEBUG - 2017-07-22 18:51:01 --> Total execution time: 0.0448
INFO - 2017-07-22 15:21:02 --> Config Class Initialized
INFO - 2017-07-22 15:21:02 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:21:02 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:21:02 --> Utf8 Class Initialized
INFO - 2017-07-22 15:21:02 --> URI Class Initialized
INFO - 2017-07-22 15:21:02 --> Router Class Initialized
INFO - 2017-07-22 15:21:02 --> Output Class Initialized
INFO - 2017-07-22 15:21:02 --> Security Class Initialized
DEBUG - 2017-07-22 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:21:02 --> Input Class Initialized
INFO - 2017-07-22 15:21:02 --> Language Class Initialized
INFO - 2017-07-22 15:21:02 --> Loader Class Initialized
INFO - 2017-07-22 15:21:02 --> Helper loaded: common_helper
INFO - 2017-07-22 15:21:02 --> Database Driver Class Initialized
INFO - 2017-07-22 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:21:02 --> Email Class Initialized
INFO - 2017-07-22 15:21:02 --> Controller Class Initialized
INFO - 2017-07-22 15:21:02 --> Helper loaded: form_helper
INFO - 2017-07-22 15:21:02 --> Form Validation Class Initialized
INFO - 2017-07-22 15:21:02 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:21:02 --> Helper loaded: url_helper
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:51:02 --> Final output sent to browser
DEBUG - 2017-07-22 18:51:02 --> Total execution time: 0.0653
INFO - 2017-07-22 15:21:02 --> Config Class Initialized
INFO - 2017-07-22 15:21:02 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:21:02 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:21:02 --> Utf8 Class Initialized
INFO - 2017-07-22 15:21:02 --> URI Class Initialized
INFO - 2017-07-22 15:21:02 --> Router Class Initialized
INFO - 2017-07-22 15:21:02 --> Output Class Initialized
INFO - 2017-07-22 15:21:02 --> Security Class Initialized
DEBUG - 2017-07-22 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:21:02 --> Input Class Initialized
INFO - 2017-07-22 15:21:02 --> Language Class Initialized
INFO - 2017-07-22 15:21:02 --> Loader Class Initialized
INFO - 2017-07-22 15:21:02 --> Helper loaded: common_helper
INFO - 2017-07-22 15:21:02 --> Database Driver Class Initialized
INFO - 2017-07-22 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:21:02 --> Email Class Initialized
INFO - 2017-07-22 15:21:02 --> Controller Class Initialized
INFO - 2017-07-22 15:21:02 --> Helper loaded: form_helper
INFO - 2017-07-22 15:21:02 --> Form Validation Class Initialized
INFO - 2017-07-22 15:21:02 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:21:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:21:02 --> Helper loaded: url_helper
INFO - 2017-07-22 15:21:02 --> Model Class Initialized
INFO - 2017-07-22 15:21:02 --> Model Class Initialized
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:51:02 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:51:02 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:51:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:51:02 --> Final output sent to browser
DEBUG - 2017-07-22 18:51:02 --> Total execution time: 0.0744
INFO - 2017-07-22 15:21:05 --> Config Class Initialized
INFO - 2017-07-22 15:21:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:21:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:21:05 --> Utf8 Class Initialized
INFO - 2017-07-22 15:21:05 --> URI Class Initialized
INFO - 2017-07-22 15:21:05 --> Router Class Initialized
INFO - 2017-07-22 15:21:05 --> Output Class Initialized
INFO - 2017-07-22 15:21:05 --> Security Class Initialized
DEBUG - 2017-07-22 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:21:05 --> Input Class Initialized
INFO - 2017-07-22 15:21:05 --> Language Class Initialized
INFO - 2017-07-22 15:21:05 --> Loader Class Initialized
INFO - 2017-07-22 15:21:05 --> Helper loaded: common_helper
INFO - 2017-07-22 15:21:05 --> Database Driver Class Initialized
INFO - 2017-07-22 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:21:05 --> Email Class Initialized
INFO - 2017-07-22 15:21:05 --> Controller Class Initialized
INFO - 2017-07-22 15:21:05 --> Helper loaded: form_helper
INFO - 2017-07-22 15:21:05 --> Form Validation Class Initialized
INFO - 2017-07-22 15:21:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:21:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:21:05 --> Helper loaded: url_helper
INFO - 2017-07-22 15:21:05 --> Model Class Initialized
INFO - 2017-07-22 15:21:05 --> Model Class Initialized
INFO - 2017-07-22 18:51:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:51:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:51:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:51:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:51:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:51:05 --> Final output sent to browser
DEBUG - 2017-07-22 18:51:05 --> Total execution time: 0.0495
INFO - 2017-07-22 15:22:05 --> Config Class Initialized
INFO - 2017-07-22 15:22:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:05 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:05 --> URI Class Initialized
INFO - 2017-07-22 15:22:05 --> Router Class Initialized
INFO - 2017-07-22 15:22:05 --> Output Class Initialized
INFO - 2017-07-22 15:22:05 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:05 --> Input Class Initialized
INFO - 2017-07-22 15:22:05 --> Language Class Initialized
INFO - 2017-07-22 15:22:05 --> Loader Class Initialized
INFO - 2017-07-22 15:22:05 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:05 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:05 --> Email Class Initialized
INFO - 2017-07-22 15:22:05 --> Controller Class Initialized
INFO - 2017-07-22 15:22:05 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:05 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:05 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:05 --> Model Class Initialized
INFO - 2017-07-22 15:22:05 --> Model Class Initialized
INFO - 2017-07-22 18:52:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:52:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:52:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:05 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:05 --> Total execution time: 0.0518
INFO - 2017-07-22 15:22:13 --> Config Class Initialized
INFO - 2017-07-22 15:22:13 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:13 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:13 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:13 --> URI Class Initialized
INFO - 2017-07-22 15:22:13 --> Router Class Initialized
INFO - 2017-07-22 15:22:13 --> Output Class Initialized
INFO - 2017-07-22 15:22:13 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:13 --> Input Class Initialized
INFO - 2017-07-22 15:22:13 --> Language Class Initialized
INFO - 2017-07-22 15:22:13 --> Loader Class Initialized
INFO - 2017-07-22 15:22:13 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:13 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:13 --> Email Class Initialized
INFO - 2017-07-22 15:22:13 --> Controller Class Initialized
INFO - 2017-07-22 15:22:13 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:13 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:13 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:13 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:13 --> Model Class Initialized
INFO - 2017-07-22 15:22:13 --> Model Class Initialized
INFO - 2017-07-22 18:52:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:52:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:52:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:13 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:13 --> Total execution time: 0.0512
INFO - 2017-07-22 15:22:15 --> Config Class Initialized
INFO - 2017-07-22 15:22:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:15 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:15 --> URI Class Initialized
INFO - 2017-07-22 15:22:15 --> Router Class Initialized
INFO - 2017-07-22 15:22:15 --> Output Class Initialized
INFO - 2017-07-22 15:22:15 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:15 --> Input Class Initialized
INFO - 2017-07-22 15:22:15 --> Language Class Initialized
INFO - 2017-07-22 15:22:15 --> Loader Class Initialized
INFO - 2017-07-22 15:22:15 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:15 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:15 --> Email Class Initialized
INFO - 2017-07-22 15:22:15 --> Controller Class Initialized
INFO - 2017-07-22 15:22:15 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:15 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:15 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:15 --> Model Class Initialized
INFO - 2017-07-22 15:22:15 --> Model Class Initialized
INFO - 2017-07-22 18:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-22 18:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:15 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:15 --> Total execution time: 0.0469
INFO - 2017-07-22 15:22:17 --> Config Class Initialized
INFO - 2017-07-22 15:22:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:17 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:17 --> URI Class Initialized
INFO - 2017-07-22 15:22:17 --> Router Class Initialized
INFO - 2017-07-22 15:22:17 --> Output Class Initialized
INFO - 2017-07-22 15:22:17 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:17 --> Input Class Initialized
INFO - 2017-07-22 15:22:17 --> Language Class Initialized
INFO - 2017-07-22 15:22:17 --> Loader Class Initialized
INFO - 2017-07-22 15:22:17 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:17 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:17 --> Email Class Initialized
INFO - 2017-07-22 15:22:17 --> Controller Class Initialized
INFO - 2017-07-22 15:22:17 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:17 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:17 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:17 --> Model Class Initialized
INFO - 2017-07-22 15:22:17 --> Model Class Initialized
INFO - 2017-07-22 18:52:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:52:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:52:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:17 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:17 --> Total execution time: 0.0810
INFO - 2017-07-22 15:22:21 --> Config Class Initialized
INFO - 2017-07-22 15:22:21 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:21 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:21 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:21 --> URI Class Initialized
INFO - 2017-07-22 15:22:21 --> Router Class Initialized
INFO - 2017-07-22 15:22:21 --> Output Class Initialized
INFO - 2017-07-22 15:22:21 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:21 --> Input Class Initialized
INFO - 2017-07-22 15:22:21 --> Language Class Initialized
INFO - 2017-07-22 15:22:21 --> Loader Class Initialized
INFO - 2017-07-22 15:22:21 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:21 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:21 --> Email Class Initialized
INFO - 2017-07-22 15:22:21 --> Controller Class Initialized
INFO - 2017-07-22 15:22:21 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:21 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:21 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:21 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:21 --> Model Class Initialized
INFO - 2017-07-22 15:22:21 --> Model Class Initialized
INFO - 2017-07-22 18:52:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-22 18:52:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:21 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:21 --> Total execution time: 0.0562
INFO - 2017-07-22 15:22:22 --> Config Class Initialized
INFO - 2017-07-22 15:22:22 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:22 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:22 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:22 --> URI Class Initialized
INFO - 2017-07-22 15:22:22 --> Router Class Initialized
INFO - 2017-07-22 15:22:22 --> Output Class Initialized
INFO - 2017-07-22 15:22:22 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:22 --> Input Class Initialized
INFO - 2017-07-22 15:22:22 --> Language Class Initialized
INFO - 2017-07-22 15:22:22 --> Loader Class Initialized
INFO - 2017-07-22 15:22:22 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:22 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:22 --> Email Class Initialized
INFO - 2017-07-22 15:22:22 --> Controller Class Initialized
INFO - 2017-07-22 15:22:22 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:22 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:22 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:22 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:22 --> Model Class Initialized
INFO - 2017-07-22 15:22:22 --> Model Class Initialized
INFO - 2017-07-22 18:52:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/addUser.php
INFO - 2017-07-22 18:52:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:22 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:22 --> Total execution time: 0.0591
INFO - 2017-07-22 15:22:25 --> Config Class Initialized
INFO - 2017-07-22 15:22:25 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:25 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:25 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:25 --> URI Class Initialized
INFO - 2017-07-22 15:22:25 --> Router Class Initialized
INFO - 2017-07-22 15:22:25 --> Output Class Initialized
INFO - 2017-07-22 15:22:25 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:25 --> Input Class Initialized
INFO - 2017-07-22 15:22:25 --> Language Class Initialized
INFO - 2017-07-22 15:22:25 --> Loader Class Initialized
INFO - 2017-07-22 15:22:25 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:25 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:25 --> Email Class Initialized
INFO - 2017-07-22 15:22:25 --> Controller Class Initialized
INFO - 2017-07-22 15:22:25 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:25 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:25 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:25 --> Helper loaded: url_helper
INFO - 2017-07-22 18:52:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 18:52:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:25 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:25 --> Total execution time: 0.0444
INFO - 2017-07-22 15:22:28 --> Config Class Initialized
INFO - 2017-07-22 15:22:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:28 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:28 --> URI Class Initialized
INFO - 2017-07-22 15:22:28 --> Router Class Initialized
INFO - 2017-07-22 15:22:28 --> Output Class Initialized
INFO - 2017-07-22 15:22:28 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:28 --> Input Class Initialized
INFO - 2017-07-22 15:22:28 --> Language Class Initialized
INFO - 2017-07-22 15:22:28 --> Loader Class Initialized
INFO - 2017-07-22 15:22:28 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:28 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:28 --> Email Class Initialized
INFO - 2017-07-22 15:22:28 --> Controller Class Initialized
INFO - 2017-07-22 15:22:28 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:28 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:28 --> Helper loaded: url_helper
INFO - 2017-07-22 18:52:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 18:52:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:28 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:28 --> Total execution time: 0.0460
INFO - 2017-07-22 15:22:31 --> Config Class Initialized
INFO - 2017-07-22 15:22:31 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:31 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:31 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:31 --> URI Class Initialized
INFO - 2017-07-22 15:22:31 --> Router Class Initialized
INFO - 2017-07-22 15:22:31 --> Output Class Initialized
INFO - 2017-07-22 15:22:31 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:31 --> Input Class Initialized
INFO - 2017-07-22 15:22:31 --> Language Class Initialized
INFO - 2017-07-22 15:22:31 --> Loader Class Initialized
INFO - 2017-07-22 15:22:31 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:31 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:31 --> Email Class Initialized
INFO - 2017-07-22 15:22:31 --> Controller Class Initialized
INFO - 2017-07-22 15:22:31 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:31 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:31 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:31 --> Helper loaded: url_helper
INFO - 2017-07-22 18:52:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2017-07-22 18:52:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:31 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:31 --> Total execution time: 0.0455
INFO - 2017-07-22 15:22:34 --> Config Class Initialized
INFO - 2017-07-22 15:22:34 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:34 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:34 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:34 --> URI Class Initialized
INFO - 2017-07-22 15:22:34 --> Router Class Initialized
INFO - 2017-07-22 15:22:34 --> Output Class Initialized
INFO - 2017-07-22 15:22:34 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:34 --> Input Class Initialized
INFO - 2017-07-22 15:22:34 --> Language Class Initialized
INFO - 2017-07-22 15:22:34 --> Loader Class Initialized
INFO - 2017-07-22 15:22:34 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:34 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:34 --> Email Class Initialized
INFO - 2017-07-22 15:22:34 --> Controller Class Initialized
INFO - 2017-07-22 15:22:34 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:34 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:34 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:34 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:34 --> Model Class Initialized
INFO - 2017-07-22 15:22:34 --> Model Class Initialized
INFO - 2017-07-22 18:52:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:34 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:34 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:52:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:52:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:34 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:34 --> Total execution time: 0.0724
INFO - 2017-07-22 15:22:37 --> Config Class Initialized
INFO - 2017-07-22 15:22:37 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:37 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:37 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:37 --> URI Class Initialized
INFO - 2017-07-22 15:22:37 --> Router Class Initialized
INFO - 2017-07-22 15:22:37 --> Output Class Initialized
INFO - 2017-07-22 15:22:37 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:37 --> Input Class Initialized
INFO - 2017-07-22 15:22:37 --> Language Class Initialized
INFO - 2017-07-22 15:22:37 --> Loader Class Initialized
INFO - 2017-07-22 15:22:37 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:37 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:37 --> Email Class Initialized
INFO - 2017-07-22 15:22:37 --> Controller Class Initialized
INFO - 2017-07-22 15:22:37 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:37 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:37 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:37 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:37 --> Model Class Initialized
INFO - 2017-07-22 15:22:37 --> Model Class Initialized
INFO - 2017-07-22 18:52:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:52:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:52:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:37 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:37 --> Total execution time: 0.0480
INFO - 2017-07-22 15:22:41 --> Config Class Initialized
INFO - 2017-07-22 15:22:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:41 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:41 --> URI Class Initialized
INFO - 2017-07-22 15:22:41 --> Router Class Initialized
INFO - 2017-07-22 15:22:41 --> Output Class Initialized
INFO - 2017-07-22 15:22:41 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:41 --> Input Class Initialized
INFO - 2017-07-22 15:22:41 --> Language Class Initialized
INFO - 2017-07-22 15:22:41 --> Loader Class Initialized
INFO - 2017-07-22 15:22:41 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:41 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:41 --> Email Class Initialized
INFO - 2017-07-22 15:22:41 --> Controller Class Initialized
INFO - 2017-07-22 15:22:41 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:41 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:41 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:41 --> Model Class Initialized
INFO - 2017-07-22 15:22:41 --> Model Class Initialized
INFO - 2017-07-22 18:52:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 18:52:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 18:52:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:41 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:41 --> Total execution time: 0.0505
INFO - 2017-07-22 15:22:42 --> Config Class Initialized
INFO - 2017-07-22 15:22:42 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:42 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:42 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:42 --> URI Class Initialized
INFO - 2017-07-22 15:22:42 --> Router Class Initialized
INFO - 2017-07-22 15:22:42 --> Output Class Initialized
INFO - 2017-07-22 15:22:42 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:42 --> Input Class Initialized
INFO - 2017-07-22 15:22:42 --> Language Class Initialized
INFO - 2017-07-22 15:22:42 --> Loader Class Initialized
INFO - 2017-07-22 15:22:42 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:42 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:42 --> Email Class Initialized
INFO - 2017-07-22 15:22:42 --> Controller Class Initialized
INFO - 2017-07-22 15:22:42 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:42 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:42 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:42 --> Helper loaded: url_helper
INFO - 2017-07-22 18:52:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 18:52:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:42 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:42 --> Total execution time: 0.0515
INFO - 2017-07-22 15:22:44 --> Config Class Initialized
INFO - 2017-07-22 15:22:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:44 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:44 --> URI Class Initialized
INFO - 2017-07-22 15:22:44 --> Router Class Initialized
INFO - 2017-07-22 15:22:44 --> Output Class Initialized
INFO - 2017-07-22 15:22:44 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:44 --> Input Class Initialized
INFO - 2017-07-22 15:22:44 --> Language Class Initialized
INFO - 2017-07-22 15:22:44 --> Loader Class Initialized
INFO - 2017-07-22 15:22:44 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:44 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:44 --> Email Class Initialized
INFO - 2017-07-22 15:22:44 --> Controller Class Initialized
INFO - 2017-07-22 15:22:44 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:44 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:44 --> Helper loaded: url_helper
INFO - 2017-07-22 18:52:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/addArticle.php
INFO - 2017-07-22 18:52:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:44 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:44 --> Total execution time: 0.0478
INFO - 2017-07-22 15:22:47 --> Config Class Initialized
INFO - 2017-07-22 15:22:47 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:47 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:47 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:47 --> URI Class Initialized
INFO - 2017-07-22 15:22:47 --> Router Class Initialized
INFO - 2017-07-22 15:22:47 --> Output Class Initialized
INFO - 2017-07-22 15:22:47 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:47 --> Input Class Initialized
INFO - 2017-07-22 15:22:47 --> Language Class Initialized
INFO - 2017-07-22 15:22:47 --> Loader Class Initialized
INFO - 2017-07-22 15:22:47 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:47 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:47 --> Email Class Initialized
INFO - 2017-07-22 15:22:47 --> Controller Class Initialized
INFO - 2017-07-22 15:22:47 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:47 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:47 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:47 --> Helper loaded: url_helper
INFO - 2017-07-22 18:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 18:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:47 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:47 --> Total execution time: 0.0474
INFO - 2017-07-22 15:22:48 --> Config Class Initialized
INFO - 2017-07-22 15:22:48 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:22:48 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:22:48 --> Utf8 Class Initialized
INFO - 2017-07-22 15:22:48 --> URI Class Initialized
INFO - 2017-07-22 15:22:48 --> Router Class Initialized
INFO - 2017-07-22 15:22:48 --> Output Class Initialized
INFO - 2017-07-22 15:22:48 --> Security Class Initialized
DEBUG - 2017-07-22 15:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:22:48 --> Input Class Initialized
INFO - 2017-07-22 15:22:48 --> Language Class Initialized
INFO - 2017-07-22 15:22:48 --> Loader Class Initialized
INFO - 2017-07-22 15:22:48 --> Helper loaded: common_helper
INFO - 2017-07-22 15:22:48 --> Database Driver Class Initialized
INFO - 2017-07-22 15:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:22:48 --> Email Class Initialized
INFO - 2017-07-22 15:22:48 --> Controller Class Initialized
INFO - 2017-07-22 15:22:48 --> Helper loaded: form_helper
INFO - 2017-07-22 15:22:48 --> Form Validation Class Initialized
INFO - 2017-07-22 15:22:48 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:22:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:22:48 --> Helper loaded: url_helper
INFO - 2017-07-22 15:22:48 --> Model Class Initialized
INFO - 2017-07-22 15:22:48 --> Model Class Initialized
INFO - 2017-07-22 18:52:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:52:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:52:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:52:48 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:52:48 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:52:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:52:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:52:48 --> Final output sent to browser
DEBUG - 2017-07-22 18:52:48 --> Total execution time: 0.0751
INFO - 2017-07-22 15:23:03 --> Config Class Initialized
INFO - 2017-07-22 15:23:03 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:03 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:03 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:03 --> URI Class Initialized
INFO - 2017-07-22 15:23:03 --> Router Class Initialized
INFO - 2017-07-22 15:23:03 --> Output Class Initialized
INFO - 2017-07-22 15:23:03 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:03 --> Input Class Initialized
INFO - 2017-07-22 15:23:03 --> Language Class Initialized
INFO - 2017-07-22 15:23:03 --> Loader Class Initialized
INFO - 2017-07-22 15:23:03 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:03 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:03 --> Email Class Initialized
INFO - 2017-07-22 15:23:03 --> Controller Class Initialized
INFO - 2017-07-22 15:23:03 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:03 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:03 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:03 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:03 --> Model Class Initialized
INFO - 2017-07-22 15:23:03 --> Model Class Initialized
INFO - 2017-07-22 18:53:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:53:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-07-22 18:53:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:03 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:03 --> Total execution time: 0.0467
INFO - 2017-07-22 15:23:05 --> Config Class Initialized
INFO - 2017-07-22 15:23:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:05 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:05 --> URI Class Initialized
INFO - 2017-07-22 15:23:05 --> Router Class Initialized
INFO - 2017-07-22 15:23:05 --> Output Class Initialized
INFO - 2017-07-22 15:23:05 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:05 --> Input Class Initialized
INFO - 2017-07-22 15:23:05 --> Language Class Initialized
INFO - 2017-07-22 15:23:05 --> Loader Class Initialized
INFO - 2017-07-22 15:23:05 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:05 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:05 --> Email Class Initialized
INFO - 2017-07-22 15:23:05 --> Controller Class Initialized
INFO - 2017-07-22 15:23:05 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:05 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:05 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:05 --> Model Class Initialized
INFO - 2017-07-22 15:23:05 --> Model Class Initialized
INFO - 2017-07-22 18:53:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:53:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-07-22 18:53:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:05 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:05 --> Total execution time: 0.0457
INFO - 2017-07-22 15:23:06 --> Config Class Initialized
INFO - 2017-07-22 15:23:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:06 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:06 --> URI Class Initialized
INFO - 2017-07-22 15:23:06 --> Router Class Initialized
INFO - 2017-07-22 15:23:06 --> Output Class Initialized
INFO - 2017-07-22 15:23:06 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:06 --> Input Class Initialized
INFO - 2017-07-22 15:23:06 --> Language Class Initialized
INFO - 2017-07-22 15:23:06 --> Loader Class Initialized
INFO - 2017-07-22 15:23:06 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:06 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:06 --> Email Class Initialized
INFO - 2017-07-22 15:23:06 --> Controller Class Initialized
INFO - 2017-07-22 15:23:06 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:06 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:06 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:06 --> Helper loaded: url_helper
INFO - 2017-07-22 18:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-07-22 18:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:06 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:06 --> Total execution time: 0.0488
INFO - 2017-07-22 15:23:06 --> Config Class Initialized
INFO - 2017-07-22 15:23:06 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:06 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:06 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:06 --> URI Class Initialized
INFO - 2017-07-22 15:23:06 --> Router Class Initialized
INFO - 2017-07-22 15:23:06 --> Output Class Initialized
INFO - 2017-07-22 15:23:06 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:06 --> Input Class Initialized
INFO - 2017-07-22 15:23:06 --> Language Class Initialized
INFO - 2017-07-22 15:23:06 --> Loader Class Initialized
INFO - 2017-07-22 15:23:06 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:06 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:07 --> Email Class Initialized
INFO - 2017-07-22 15:23:07 --> Controller Class Initialized
INFO - 2017-07-22 15:23:07 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:07 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:07 --> Helper loaded: url_helper
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:07 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:07 --> Total execution time: 0.0583
INFO - 2017-07-22 15:23:07 --> Config Class Initialized
INFO - 2017-07-22 15:23:07 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:07 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:07 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:07 --> URI Class Initialized
INFO - 2017-07-22 15:23:07 --> Router Class Initialized
INFO - 2017-07-22 15:23:07 --> Output Class Initialized
INFO - 2017-07-22 15:23:07 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:07 --> Input Class Initialized
INFO - 2017-07-22 15:23:07 --> Language Class Initialized
INFO - 2017-07-22 15:23:07 --> Loader Class Initialized
INFO - 2017-07-22 15:23:07 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:07 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:07 --> Email Class Initialized
INFO - 2017-07-22 15:23:07 --> Controller Class Initialized
INFO - 2017-07-22 15:23:07 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:07 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:07 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:07 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:07 --> Model Class Initialized
INFO - 2017-07-22 15:23:07 --> Model Class Initialized
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:07 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:07 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:07 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:07 --> Total execution time: 0.0821
INFO - 2017-07-22 15:23:08 --> Config Class Initialized
INFO - 2017-07-22 15:23:08 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:08 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:08 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:08 --> URI Class Initialized
INFO - 2017-07-22 15:23:08 --> Router Class Initialized
INFO - 2017-07-22 15:23:08 --> Output Class Initialized
INFO - 2017-07-22 15:23:08 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:08 --> Input Class Initialized
INFO - 2017-07-22 15:23:08 --> Language Class Initialized
INFO - 2017-07-22 15:23:08 --> Loader Class Initialized
INFO - 2017-07-22 15:23:08 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:08 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:08 --> Email Class Initialized
INFO - 2017-07-22 15:23:08 --> Controller Class Initialized
INFO - 2017-07-22 15:23:08 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:08 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:08 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:08 --> Helper loaded: url_helper
INFO - 2017-07-22 18:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 18:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-07-22 18:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:08 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:08 --> Total execution time: 0.0431
INFO - 2017-07-22 15:23:10 --> Config Class Initialized
INFO - 2017-07-22 15:23:10 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:10 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:10 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:10 --> URI Class Initialized
INFO - 2017-07-22 15:23:10 --> Router Class Initialized
INFO - 2017-07-22 15:23:10 --> Output Class Initialized
INFO - 2017-07-22 15:23:10 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:10 --> Input Class Initialized
INFO - 2017-07-22 15:23:10 --> Language Class Initialized
INFO - 2017-07-22 15:23:10 --> Loader Class Initialized
INFO - 2017-07-22 15:23:10 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:10 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:10 --> Email Class Initialized
INFO - 2017-07-22 15:23:10 --> Controller Class Initialized
INFO - 2017-07-22 15:23:10 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:10 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:10 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:10 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:10 --> Model Class Initialized
INFO - 2017-07-22 15:23:10 --> Model Class Initialized
INFO - 2017-07-22 18:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:10 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:10 --> Total execution time: 0.0685
INFO - 2017-07-22 15:23:14 --> Config Class Initialized
INFO - 2017-07-22 15:23:14 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:14 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:14 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:14 --> URI Class Initialized
INFO - 2017-07-22 15:23:14 --> Router Class Initialized
INFO - 2017-07-22 15:23:14 --> Output Class Initialized
INFO - 2017-07-22 15:23:14 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:14 --> Input Class Initialized
INFO - 2017-07-22 15:23:14 --> Language Class Initialized
INFO - 2017-07-22 15:23:14 --> Loader Class Initialized
INFO - 2017-07-22 15:23:14 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:14 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:14 --> Email Class Initialized
INFO - 2017-07-22 15:23:14 --> Controller Class Initialized
INFO - 2017-07-22 15:23:14 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:14 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:14 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:14 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:14 --> Model Class Initialized
INFO - 2017-07-22 15:23:14 --> Model Class Initialized
INFO - 2017-07-22 15:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2017-07-22 15:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:23:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 15:23:14 --> Final output sent to browser
DEBUG - 2017-07-22 15:23:14 --> Total execution time: 0.0455
INFO - 2017-07-22 15:23:15 --> Config Class Initialized
INFO - 2017-07-22 15:23:15 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:15 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:15 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:15 --> URI Class Initialized
INFO - 2017-07-22 15:23:15 --> Router Class Initialized
INFO - 2017-07-22 15:23:15 --> Output Class Initialized
INFO - 2017-07-22 15:23:15 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:15 --> Input Class Initialized
INFO - 2017-07-22 15:23:15 --> Language Class Initialized
INFO - 2017-07-22 15:23:15 --> Loader Class Initialized
INFO - 2017-07-22 15:23:15 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:15 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:15 --> Email Class Initialized
INFO - 2017-07-22 15:23:15 --> Controller Class Initialized
INFO - 2017-07-22 15:23:15 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:15 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:15 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:15 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:15 --> Model Class Initialized
INFO - 2017-07-22 15:23:15 --> Model Class Initialized
INFO - 2017-07-22 18:53:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:15 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:15 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:53:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:53:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:15 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:15 --> Total execution time: 0.0806
INFO - 2017-07-22 15:23:17 --> Config Class Initialized
INFO - 2017-07-22 15:23:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:17 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:17 --> URI Class Initialized
INFO - 2017-07-22 15:23:17 --> Router Class Initialized
INFO - 2017-07-22 15:23:17 --> Output Class Initialized
INFO - 2017-07-22 15:23:17 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:17 --> Input Class Initialized
INFO - 2017-07-22 15:23:17 --> Language Class Initialized
INFO - 2017-07-22 15:23:17 --> Loader Class Initialized
INFO - 2017-07-22 15:23:17 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:17 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:17 --> Email Class Initialized
INFO - 2017-07-22 15:23:17 --> Controller Class Initialized
INFO - 2017-07-22 15:23:17 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:17 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:17 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:17 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:17 --> Model Class Initialized
INFO - 2017-07-22 15:23:17 --> Model Class Initialized
INFO - 2017-07-22 15:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 15:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 15:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\profile.php
INFO - 2017-07-22 15:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 15:23:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 15:23:17 --> Final output sent to browser
DEBUG - 2017-07-22 15:23:17 --> Total execution time: 0.0449
INFO - 2017-07-22 15:23:19 --> Config Class Initialized
INFO - 2017-07-22 15:23:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:23:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:23:19 --> Utf8 Class Initialized
INFO - 2017-07-22 15:23:19 --> URI Class Initialized
INFO - 2017-07-22 15:23:19 --> Router Class Initialized
INFO - 2017-07-22 15:23:19 --> Output Class Initialized
INFO - 2017-07-22 15:23:19 --> Security Class Initialized
DEBUG - 2017-07-22 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:23:20 --> Input Class Initialized
INFO - 2017-07-22 15:23:20 --> Language Class Initialized
INFO - 2017-07-22 15:23:20 --> Loader Class Initialized
INFO - 2017-07-22 15:23:20 --> Helper loaded: common_helper
INFO - 2017-07-22 15:23:20 --> Database Driver Class Initialized
INFO - 2017-07-22 15:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:23:20 --> Email Class Initialized
INFO - 2017-07-22 15:23:20 --> Controller Class Initialized
INFO - 2017-07-22 15:23:20 --> Helper loaded: form_helper
INFO - 2017-07-22 15:23:20 --> Form Validation Class Initialized
INFO - 2017-07-22 15:23:20 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:23:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:23:20 --> Helper loaded: url_helper
INFO - 2017-07-22 15:23:20 --> Model Class Initialized
INFO - 2017-07-22 15:23:20 --> Model Class Initialized
INFO - 2017-07-22 18:53:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 18:53:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 18:53:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 18:53:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 18:53:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 18:53:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 18:53:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 18:53:20 --> Final output sent to browser
DEBUG - 2017-07-22 18:53:20 --> Total execution time: 0.0740
INFO - 2017-07-22 15:30:38 --> Config Class Initialized
INFO - 2017-07-22 15:30:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:30:38 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:30:38 --> Utf8 Class Initialized
INFO - 2017-07-22 15:30:38 --> URI Class Initialized
INFO - 2017-07-22 15:30:38 --> Router Class Initialized
INFO - 2017-07-22 15:30:38 --> Output Class Initialized
INFO - 2017-07-22 15:30:38 --> Security Class Initialized
DEBUG - 2017-07-22 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:30:38 --> Input Class Initialized
INFO - 2017-07-22 15:30:38 --> Language Class Initialized
INFO - 2017-07-22 15:30:38 --> Loader Class Initialized
INFO - 2017-07-22 15:30:38 --> Helper loaded: common_helper
INFO - 2017-07-22 15:30:38 --> Database Driver Class Initialized
INFO - 2017-07-22 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:30:38 --> Email Class Initialized
INFO - 2017-07-22 15:30:38 --> Controller Class Initialized
INFO - 2017-07-22 15:30:38 --> Helper loaded: form_helper
INFO - 2017-07-22 15:30:38 --> Form Validation Class Initialized
INFO - 2017-07-22 15:30:38 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:30:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:30:38 --> Helper loaded: url_helper
INFO - 2017-07-22 15:30:38 --> Model Class Initialized
INFO - 2017-07-22 15:30:38 --> Model Class Initialized
INFO - 2017-07-22 19:00:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:00:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:00:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:00:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 19:00:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 19:00:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 19:00:38 --> Final output sent to browser
DEBUG - 2017-07-22 19:00:38 --> Total execution time: 0.0710
INFO - 2017-07-22 15:30:43 --> Config Class Initialized
INFO - 2017-07-22 15:30:43 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:30:43 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:30:43 --> Utf8 Class Initialized
INFO - 2017-07-22 15:30:43 --> URI Class Initialized
INFO - 2017-07-22 15:30:43 --> Router Class Initialized
INFO - 2017-07-22 15:30:43 --> Output Class Initialized
INFO - 2017-07-22 15:30:43 --> Security Class Initialized
DEBUG - 2017-07-22 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:30:43 --> Input Class Initialized
INFO - 2017-07-22 15:30:43 --> Language Class Initialized
INFO - 2017-07-22 15:30:43 --> Loader Class Initialized
INFO - 2017-07-22 15:30:43 --> Helper loaded: common_helper
INFO - 2017-07-22 15:30:43 --> Database Driver Class Initialized
INFO - 2017-07-22 15:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:30:43 --> Email Class Initialized
INFO - 2017-07-22 15:30:43 --> Controller Class Initialized
INFO - 2017-07-22 15:30:43 --> Helper loaded: form_helper
INFO - 2017-07-22 15:30:43 --> Form Validation Class Initialized
INFO - 2017-07-22 15:30:43 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:30:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:30:43 --> Helper loaded: url_helper
INFO - 2017-07-22 15:30:43 --> Model Class Initialized
INFO - 2017-07-22 15:30:43 --> Model Class Initialized
INFO - 2017-07-22 19:00:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:00:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:00:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:00:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:00:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:00:43 --> Final output sent to browser
DEBUG - 2017-07-22 19:00:43 --> Total execution time: 0.0476
INFO - 2017-07-22 15:31:05 --> Config Class Initialized
INFO - 2017-07-22 15:31:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:31:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:31:05 --> Utf8 Class Initialized
INFO - 2017-07-22 15:31:05 --> URI Class Initialized
INFO - 2017-07-22 15:31:05 --> Router Class Initialized
INFO - 2017-07-22 15:31:05 --> Output Class Initialized
INFO - 2017-07-22 15:31:05 --> Security Class Initialized
DEBUG - 2017-07-22 15:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:31:05 --> Input Class Initialized
INFO - 2017-07-22 15:31:05 --> Language Class Initialized
INFO - 2017-07-22 15:31:05 --> Loader Class Initialized
INFO - 2017-07-22 15:31:05 --> Helper loaded: common_helper
INFO - 2017-07-22 15:31:05 --> Database Driver Class Initialized
INFO - 2017-07-22 15:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:31:05 --> Email Class Initialized
INFO - 2017-07-22 15:31:05 --> Controller Class Initialized
INFO - 2017-07-22 15:31:05 --> Helper loaded: form_helper
INFO - 2017-07-22 15:31:05 --> Form Validation Class Initialized
INFO - 2017-07-22 15:31:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:31:05 --> Helper loaded: url_helper
INFO - 2017-07-22 15:31:05 --> Model Class Initialized
INFO - 2017-07-22 15:31:05 --> Model Class Initialized
INFO - 2017-07-22 19:01:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:01:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:01:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:01:05 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:01:05 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 19:01:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 19:01:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 19:01:05 --> Final output sent to browser
DEBUG - 2017-07-22 19:01:05 --> Total execution time: 0.0765
INFO - 2017-07-22 15:40:00 --> Config Class Initialized
INFO - 2017-07-22 15:40:00 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:40:00 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:40:00 --> Utf8 Class Initialized
INFO - 2017-07-22 15:40:00 --> URI Class Initialized
INFO - 2017-07-22 15:40:00 --> Router Class Initialized
INFO - 2017-07-22 15:40:00 --> Output Class Initialized
INFO - 2017-07-22 15:40:00 --> Security Class Initialized
DEBUG - 2017-07-22 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:40:00 --> Input Class Initialized
INFO - 2017-07-22 15:40:00 --> Language Class Initialized
INFO - 2017-07-22 15:40:00 --> Loader Class Initialized
INFO - 2017-07-22 15:40:00 --> Helper loaded: common_helper
INFO - 2017-07-22 15:40:00 --> Database Driver Class Initialized
INFO - 2017-07-22 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:40:00 --> Email Class Initialized
INFO - 2017-07-22 15:40:00 --> Controller Class Initialized
INFO - 2017-07-22 15:40:00 --> Helper loaded: form_helper
INFO - 2017-07-22 15:40:00 --> Form Validation Class Initialized
INFO - 2017-07-22 15:40:00 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:40:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:40:00 --> Helper loaded: url_helper
INFO - 2017-07-22 15:40:00 --> Model Class Initialized
INFO - 2017-07-22 15:40:00 --> Model Class Initialized
INFO - 2017-07-22 19:10:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:10:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:10:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:10:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:10:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 19:10:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 19:10:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 19:10:00 --> Final output sent to browser
DEBUG - 2017-07-22 19:10:00 --> Total execution time: 0.0783
INFO - 2017-07-22 15:40:02 --> Config Class Initialized
INFO - 2017-07-22 15:40:02 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:40:02 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:40:02 --> Utf8 Class Initialized
INFO - 2017-07-22 15:40:02 --> URI Class Initialized
INFO - 2017-07-22 15:40:02 --> Router Class Initialized
INFO - 2017-07-22 15:40:02 --> Output Class Initialized
INFO - 2017-07-22 15:40:02 --> Security Class Initialized
DEBUG - 2017-07-22 15:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:40:02 --> Input Class Initialized
INFO - 2017-07-22 15:40:02 --> Language Class Initialized
INFO - 2017-07-22 15:40:02 --> Loader Class Initialized
INFO - 2017-07-22 15:40:02 --> Helper loaded: common_helper
INFO - 2017-07-22 15:40:02 --> Database Driver Class Initialized
INFO - 2017-07-22 15:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:40:02 --> Email Class Initialized
INFO - 2017-07-22 15:40:02 --> Controller Class Initialized
INFO - 2017-07-22 15:40:02 --> Helper loaded: form_helper
INFO - 2017-07-22 15:40:02 --> Form Validation Class Initialized
INFO - 2017-07-22 15:40:02 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:40:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:40:02 --> Helper loaded: url_helper
INFO - 2017-07-22 15:40:02 --> Model Class Initialized
INFO - 2017-07-22 15:40:02 --> Model Class Initialized
INFO - 2017-07-22 19:10:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:10:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:10:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:10:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:10:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:10:02 --> Final output sent to browser
DEBUG - 2017-07-22 19:10:02 --> Total execution time: 0.0483
INFO - 2017-07-22 15:40:05 --> Config Class Initialized
INFO - 2017-07-22 15:40:05 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:40:05 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:40:05 --> Utf8 Class Initialized
INFO - 2017-07-22 15:40:05 --> URI Class Initialized
INFO - 2017-07-22 15:40:05 --> Router Class Initialized
INFO - 2017-07-22 15:40:05 --> Output Class Initialized
INFO - 2017-07-22 15:40:05 --> Security Class Initialized
DEBUG - 2017-07-22 15:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:40:05 --> Input Class Initialized
INFO - 2017-07-22 15:40:05 --> Language Class Initialized
INFO - 2017-07-22 15:40:05 --> Loader Class Initialized
INFO - 2017-07-22 15:40:05 --> Helper loaded: common_helper
INFO - 2017-07-22 15:40:05 --> Database Driver Class Initialized
INFO - 2017-07-22 15:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:40:05 --> Email Class Initialized
INFO - 2017-07-22 15:40:05 --> Controller Class Initialized
INFO - 2017-07-22 15:40:05 --> Helper loaded: form_helper
INFO - 2017-07-22 15:40:05 --> Form Validation Class Initialized
INFO - 2017-07-22 15:40:05 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:40:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:40:05 --> Helper loaded: url_helper
INFO - 2017-07-22 15:40:05 --> Model Class Initialized
INFO - 2017-07-22 15:40:05 --> Model Class Initialized
INFO - 2017-07-22 19:10:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:10:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:10:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:10:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:10:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:10:05 --> Final output sent to browser
DEBUG - 2017-07-22 19:10:05 --> Total execution time: 0.1483
INFO - 2017-07-22 15:40:44 --> Config Class Initialized
INFO - 2017-07-22 15:40:44 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:40:44 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:40:44 --> Utf8 Class Initialized
INFO - 2017-07-22 15:40:44 --> URI Class Initialized
INFO - 2017-07-22 15:40:44 --> Router Class Initialized
INFO - 2017-07-22 15:40:44 --> Output Class Initialized
INFO - 2017-07-22 15:40:44 --> Security Class Initialized
DEBUG - 2017-07-22 15:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:40:44 --> Input Class Initialized
INFO - 2017-07-22 15:40:44 --> Language Class Initialized
INFO - 2017-07-22 15:40:44 --> Loader Class Initialized
INFO - 2017-07-22 15:40:44 --> Helper loaded: common_helper
INFO - 2017-07-22 15:40:44 --> Database Driver Class Initialized
INFO - 2017-07-22 15:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:40:44 --> Email Class Initialized
INFO - 2017-07-22 15:40:44 --> Controller Class Initialized
INFO - 2017-07-22 15:40:44 --> Helper loaded: form_helper
INFO - 2017-07-22 15:40:44 --> Form Validation Class Initialized
INFO - 2017-07-22 15:40:44 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:40:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:40:44 --> Helper loaded: url_helper
INFO - 2017-07-22 15:40:44 --> Model Class Initialized
INFO - 2017-07-22 15:40:44 --> Model Class Initialized
INFO - 2017-07-22 15:40:46 --> Config Class Initialized
INFO - 2017-07-22 15:40:46 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:40:46 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:40:46 --> Utf8 Class Initialized
INFO - 2017-07-22 15:40:46 --> URI Class Initialized
INFO - 2017-07-22 15:40:46 --> Router Class Initialized
INFO - 2017-07-22 15:40:46 --> Output Class Initialized
INFO - 2017-07-22 15:40:46 --> Security Class Initialized
DEBUG - 2017-07-22 15:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:40:46 --> Input Class Initialized
INFO - 2017-07-22 15:40:46 --> Language Class Initialized
INFO - 2017-07-22 15:40:46 --> Loader Class Initialized
INFO - 2017-07-22 15:40:46 --> Helper loaded: common_helper
INFO - 2017-07-22 15:40:46 --> Database Driver Class Initialized
INFO - 2017-07-22 15:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:40:46 --> Email Class Initialized
INFO - 2017-07-22 15:40:46 --> Controller Class Initialized
INFO - 2017-07-22 15:40:46 --> Helper loaded: form_helper
INFO - 2017-07-22 15:40:46 --> Form Validation Class Initialized
INFO - 2017-07-22 15:40:46 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:40:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:40:46 --> Helper loaded: url_helper
INFO - 2017-07-22 15:40:46 --> Model Class Initialized
INFO - 2017-07-22 15:40:46 --> Model Class Initialized
INFO - 2017-07-22 19:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:10:46 --> Final output sent to browser
DEBUG - 2017-07-22 19:10:46 --> Total execution time: 0.0512
INFO - 2017-07-22 15:40:49 --> Config Class Initialized
INFO - 2017-07-22 15:40:49 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:40:49 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:40:49 --> Utf8 Class Initialized
INFO - 2017-07-22 15:40:49 --> URI Class Initialized
INFO - 2017-07-22 15:40:49 --> Router Class Initialized
INFO - 2017-07-22 15:40:49 --> Output Class Initialized
INFO - 2017-07-22 15:40:49 --> Security Class Initialized
DEBUG - 2017-07-22 15:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:40:49 --> Input Class Initialized
INFO - 2017-07-22 15:40:49 --> Language Class Initialized
INFO - 2017-07-22 15:40:49 --> Loader Class Initialized
INFO - 2017-07-22 15:40:49 --> Helper loaded: common_helper
INFO - 2017-07-22 15:40:49 --> Database Driver Class Initialized
INFO - 2017-07-22 15:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:40:49 --> Email Class Initialized
INFO - 2017-07-22 15:40:49 --> Controller Class Initialized
INFO - 2017-07-22 15:40:49 --> Helper loaded: form_helper
INFO - 2017-07-22 15:40:49 --> Form Validation Class Initialized
INFO - 2017-07-22 15:40:49 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:40:49 --> Helper loaded: url_helper
INFO - 2017-07-22 15:40:49 --> Model Class Initialized
INFO - 2017-07-22 15:40:49 --> Model Class Initialized
INFO - 2017-07-22 15:41:17 --> Config Class Initialized
INFO - 2017-07-22 15:41:17 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:41:17 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:41:17 --> Utf8 Class Initialized
INFO - 2017-07-22 15:41:17 --> URI Class Initialized
INFO - 2017-07-22 15:41:17 --> Router Class Initialized
INFO - 2017-07-22 15:41:17 --> Output Class Initialized
INFO - 2017-07-22 15:41:17 --> Security Class Initialized
DEBUG - 2017-07-22 15:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:41:17 --> Input Class Initialized
INFO - 2017-07-22 15:41:17 --> Language Class Initialized
INFO - 2017-07-22 15:41:17 --> Loader Class Initialized
INFO - 2017-07-22 15:41:17 --> Helper loaded: common_helper
INFO - 2017-07-22 15:41:17 --> Database Driver Class Initialized
INFO - 2017-07-22 15:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:41:17 --> Email Class Initialized
INFO - 2017-07-22 15:41:17 --> Controller Class Initialized
INFO - 2017-07-22 15:41:18 --> Helper loaded: form_helper
INFO - 2017-07-22 15:41:18 --> Form Validation Class Initialized
INFO - 2017-07-22 15:41:18 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:41:18 --> Helper loaded: url_helper
INFO - 2017-07-22 15:41:18 --> Model Class Initialized
INFO - 2017-07-22 15:41:18 --> Model Class Initialized
INFO - 2017-07-22 19:11:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:11:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:11:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:11:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:11:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:11:18 --> Final output sent to browser
DEBUG - 2017-07-22 19:11:18 --> Total execution time: 0.1546
INFO - 2017-07-22 15:42:19 --> Config Class Initialized
INFO - 2017-07-22 15:42:19 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:19 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:19 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:19 --> URI Class Initialized
INFO - 2017-07-22 15:42:19 --> Router Class Initialized
INFO - 2017-07-22 15:42:19 --> Output Class Initialized
INFO - 2017-07-22 15:42:19 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:19 --> Input Class Initialized
INFO - 2017-07-22 15:42:19 --> Language Class Initialized
INFO - 2017-07-22 15:42:19 --> Loader Class Initialized
INFO - 2017-07-22 15:42:19 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:19 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:19 --> Email Class Initialized
INFO - 2017-07-22 15:42:19 --> Controller Class Initialized
INFO - 2017-07-22 15:42:19 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:19 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:19 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:19 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:19 --> Model Class Initialized
INFO - 2017-07-22 15:42:19 --> Model Class Initialized
INFO - 2017-07-22 19:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:12:19 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:19 --> Total execution time: 0.2563
INFO - 2017-07-22 15:42:23 --> Config Class Initialized
INFO - 2017-07-22 15:42:23 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:23 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:23 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:23 --> URI Class Initialized
INFO - 2017-07-22 15:42:23 --> Router Class Initialized
INFO - 2017-07-22 15:42:23 --> Output Class Initialized
INFO - 2017-07-22 15:42:23 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:23 --> Input Class Initialized
INFO - 2017-07-22 15:42:23 --> Language Class Initialized
INFO - 2017-07-22 15:42:23 --> Loader Class Initialized
INFO - 2017-07-22 15:42:23 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:23 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:23 --> Email Class Initialized
INFO - 2017-07-22 15:42:23 --> Controller Class Initialized
INFO - 2017-07-22 15:42:23 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:23 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:23 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:23 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:23 --> Model Class Initialized
INFO - 2017-07-22 15:42:23 --> Model Class Initialized
INFO - 2017-07-22 19:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:12:23 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:23 --> Total execution time: 0.1651
INFO - 2017-07-22 15:42:28 --> Config Class Initialized
INFO - 2017-07-22 15:42:28 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:28 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:28 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:28 --> URI Class Initialized
INFO - 2017-07-22 15:42:28 --> Router Class Initialized
INFO - 2017-07-22 15:42:28 --> Output Class Initialized
INFO - 2017-07-22 15:42:28 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:28 --> Input Class Initialized
INFO - 2017-07-22 15:42:28 --> Language Class Initialized
INFO - 2017-07-22 15:42:28 --> Loader Class Initialized
INFO - 2017-07-22 15:42:28 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:28 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:28 --> Email Class Initialized
INFO - 2017-07-22 15:42:28 --> Controller Class Initialized
INFO - 2017-07-22 15:42:28 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:28 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:28 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:28 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:28 --> Model Class Initialized
INFO - 2017-07-22 15:42:28 --> Model Class Initialized
INFO - 2017-07-22 19:12:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:12:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:12:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:12:28 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:28 --> Total execution time: 0.1652
INFO - 2017-07-22 15:42:38 --> Config Class Initialized
INFO - 2017-07-22 15:42:38 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:38 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:38 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:38 --> URI Class Initialized
INFO - 2017-07-22 15:42:38 --> Router Class Initialized
INFO - 2017-07-22 15:42:38 --> Output Class Initialized
INFO - 2017-07-22 15:42:38 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:38 --> Input Class Initialized
INFO - 2017-07-22 15:42:38 --> Language Class Initialized
INFO - 2017-07-22 15:42:38 --> Loader Class Initialized
INFO - 2017-07-22 15:42:38 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:38 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:38 --> Email Class Initialized
INFO - 2017-07-22 15:42:38 --> Controller Class Initialized
INFO - 2017-07-22 15:42:38 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:38 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:38 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:38 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:38 --> Model Class Initialized
INFO - 2017-07-22 15:42:38 --> Model Class Initialized
INFO - 2017-07-22 19:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:38 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:38 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 19:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 19:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 19:12:38 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:38 --> Total execution time: 0.0917
INFO - 2017-07-22 15:42:40 --> Config Class Initialized
INFO - 2017-07-22 15:42:40 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:40 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:40 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:40 --> URI Class Initialized
INFO - 2017-07-22 15:42:40 --> Router Class Initialized
INFO - 2017-07-22 15:42:40 --> Output Class Initialized
INFO - 2017-07-22 15:42:40 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:40 --> Input Class Initialized
INFO - 2017-07-22 15:42:40 --> Language Class Initialized
INFO - 2017-07-22 15:42:40 --> Loader Class Initialized
INFO - 2017-07-22 15:42:40 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:40 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:40 --> Email Class Initialized
INFO - 2017-07-22 15:42:40 --> Controller Class Initialized
INFO - 2017-07-22 15:42:40 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:40 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:40 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:40 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:40 --> Model Class Initialized
INFO - 2017-07-22 15:42:40 --> Model Class Initialized
INFO - 2017-07-22 19:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-07-22 19:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:12:40 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:40 --> Total execution time: 0.0694
INFO - 2017-07-22 15:42:41 --> Config Class Initialized
INFO - 2017-07-22 15:42:41 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:41 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:41 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:41 --> URI Class Initialized
INFO - 2017-07-22 15:42:41 --> Router Class Initialized
INFO - 2017-07-22 15:42:41 --> Output Class Initialized
INFO - 2017-07-22 15:42:41 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:41 --> Input Class Initialized
INFO - 2017-07-22 15:42:41 --> Language Class Initialized
INFO - 2017-07-22 15:42:41 --> Loader Class Initialized
INFO - 2017-07-22 15:42:41 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:41 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:41 --> Email Class Initialized
INFO - 2017-07-22 15:42:41 --> Controller Class Initialized
INFO - 2017-07-22 15:42:41 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:41 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:41 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:41 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:41 --> Model Class Initialized
INFO - 2017-07-22 15:42:41 --> Model Class Initialized
INFO - 2017-07-22 19:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-07-22 19:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-07-22 19:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-07-22 19:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-07-22 19:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-07-22 19:12:41 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:41 --> Total execution time: 0.0850
INFO - 2017-07-22 15:42:45 --> Config Class Initialized
INFO - 2017-07-22 15:42:45 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:45 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:45 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:45 --> URI Class Initialized
INFO - 2017-07-22 15:42:45 --> Router Class Initialized
INFO - 2017-07-22 15:42:45 --> Output Class Initialized
INFO - 2017-07-22 15:42:45 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:45 --> Input Class Initialized
INFO - 2017-07-22 15:42:45 --> Language Class Initialized
INFO - 2017-07-22 15:42:45 --> Loader Class Initialized
INFO - 2017-07-22 15:42:45 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:45 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:45 --> Email Class Initialized
INFO - 2017-07-22 15:42:45 --> Controller Class Initialized
INFO - 2017-07-22 15:42:45 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:45 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:45 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:45 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:45 --> Model Class Initialized
INFO - 2017-07-22 15:42:45 --> Model Class Initialized
INFO - 2017-07-22 19:12:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:12:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:12:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:12:45 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:45 --> Total execution time: 0.0538
INFO - 2017-07-22 15:42:54 --> Config Class Initialized
INFO - 2017-07-22 15:42:54 --> Hooks Class Initialized
DEBUG - 2017-07-22 15:42:54 --> UTF-8 Support Enabled
INFO - 2017-07-22 15:42:54 --> Utf8 Class Initialized
INFO - 2017-07-22 15:42:54 --> URI Class Initialized
INFO - 2017-07-22 15:42:54 --> Router Class Initialized
INFO - 2017-07-22 15:42:54 --> Output Class Initialized
INFO - 2017-07-22 15:42:54 --> Security Class Initialized
DEBUG - 2017-07-22 15:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-07-22 15:42:54 --> Input Class Initialized
INFO - 2017-07-22 15:42:54 --> Language Class Initialized
INFO - 2017-07-22 15:42:54 --> Loader Class Initialized
INFO - 2017-07-22 15:42:54 --> Helper loaded: common_helper
INFO - 2017-07-22 15:42:54 --> Database Driver Class Initialized
INFO - 2017-07-22 15:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-07-22 15:42:54 --> Email Class Initialized
INFO - 2017-07-22 15:42:54 --> Controller Class Initialized
INFO - 2017-07-22 15:42:54 --> Helper loaded: form_helper
INFO - 2017-07-22 15:42:54 --> Form Validation Class Initialized
INFO - 2017-07-22 15:42:54 --> Helper loaded: email_helper
DEBUG - 2017-07-22 15:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-07-22 15:42:54 --> Helper loaded: url_helper
INFO - 2017-07-22 15:42:54 --> Model Class Initialized
INFO - 2017-07-22 15:42:54 --> Model Class Initialized
INFO - 2017-07-22 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-07-22 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-07-22 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\calender.php
INFO - 2017-07-22 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-07-22 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-07-22 19:12:54 --> Final output sent to browser
DEBUG - 2017-07-22 19:12:54 --> Total execution time: 0.2096
