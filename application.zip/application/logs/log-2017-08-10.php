<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-10 07:51:32 --> Config Class Initialized
INFO - 2017-08-10 07:51:32 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:51:32 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:51:32 --> Utf8 Class Initialized
INFO - 2017-08-10 07:51:32 --> URI Class Initialized
INFO - 2017-08-10 07:51:32 --> Router Class Initialized
INFO - 2017-08-10 07:51:32 --> Output Class Initialized
INFO - 2017-08-10 07:51:32 --> Security Class Initialized
DEBUG - 2017-08-10 07:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:51:32 --> Input Class Initialized
INFO - 2017-08-10 07:51:32 --> Language Class Initialized
INFO - 2017-08-10 07:51:32 --> Loader Class Initialized
INFO - 2017-08-10 07:51:32 --> Helper loaded: common_helper
INFO - 2017-08-10 07:51:33 --> Database Driver Class Initialized
INFO - 2017-08-10 07:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:51:33 --> Email Class Initialized
INFO - 2017-08-10 07:51:33 --> Controller Class Initialized
INFO - 2017-08-10 07:51:33 --> Helper loaded: form_helper
INFO - 2017-08-10 07:51:33 --> Form Validation Class Initialized
INFO - 2017-08-10 07:51:33 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:51:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:51:33 --> Helper loaded: url_helper
INFO - 2017-08-10 07:51:33 --> Model Class Initialized
INFO - 2017-08-10 07:51:33 --> Model Class Initialized
INFO - 2017-08-10 11:21:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:21:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:21:33 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:21:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:21:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:21:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:21:33 --> Final output sent to browser
DEBUG - 2017-08-10 11:21:33 --> Total execution time: 1.5887
INFO - 2017-08-10 07:51:34 --> Config Class Initialized
INFO - 2017-08-10 07:51:34 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:51:34 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:51:34 --> Utf8 Class Initialized
INFO - 2017-08-10 07:51:34 --> URI Class Initialized
INFO - 2017-08-10 07:51:34 --> Router Class Initialized
INFO - 2017-08-10 07:51:34 --> Output Class Initialized
INFO - 2017-08-10 07:51:34 --> Security Class Initialized
DEBUG - 2017-08-10 07:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:51:34 --> Input Class Initialized
INFO - 2017-08-10 07:51:34 --> Language Class Initialized
INFO - 2017-08-10 07:51:34 --> Loader Class Initialized
INFO - 2017-08-10 07:51:34 --> Helper loaded: common_helper
INFO - 2017-08-10 07:51:34 --> Database Driver Class Initialized
INFO - 2017-08-10 07:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:51:34 --> Email Class Initialized
INFO - 2017-08-10 07:51:34 --> Controller Class Initialized
INFO - 2017-08-10 07:51:34 --> Helper loaded: form_helper
INFO - 2017-08-10 07:51:34 --> Form Validation Class Initialized
INFO - 2017-08-10 07:51:34 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:51:34 --> Helper loaded: url_helper
INFO - 2017-08-10 07:51:34 --> Model Class Initialized
INFO - 2017-08-10 07:51:34 --> Model Class Initialized
INFO - 2017-08-10 11:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:21:34 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:21:34 --> Final output sent to browser
DEBUG - 2017-08-10 11:21:34 --> Total execution time: 0.1097
INFO - 2017-08-10 07:51:38 --> Config Class Initialized
INFO - 2017-08-10 07:51:38 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:51:38 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:51:38 --> Utf8 Class Initialized
INFO - 2017-08-10 07:51:38 --> URI Class Initialized
DEBUG - 2017-08-10 07:51:38 --> No URI present. Default controller set.
INFO - 2017-08-10 07:51:38 --> Router Class Initialized
INFO - 2017-08-10 07:51:38 --> Output Class Initialized
INFO - 2017-08-10 07:51:38 --> Security Class Initialized
DEBUG - 2017-08-10 07:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:51:38 --> Input Class Initialized
INFO - 2017-08-10 07:51:38 --> Language Class Initialized
INFO - 2017-08-10 07:51:38 --> Loader Class Initialized
INFO - 2017-08-10 07:51:38 --> Helper loaded: common_helper
INFO - 2017-08-10 07:51:38 --> Database Driver Class Initialized
INFO - 2017-08-10 07:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:51:38 --> Email Class Initialized
INFO - 2017-08-10 07:51:38 --> Controller Class Initialized
INFO - 2017-08-10 07:51:38 --> Helper loaded: form_helper
INFO - 2017-08-10 07:51:38 --> Form Validation Class Initialized
INFO - 2017-08-10 07:51:38 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:51:38 --> Helper loaded: url_helper
INFO - 2017-08-10 07:51:38 --> Model Class Initialized
INFO - 2017-08-10 07:51:38 --> Model Class Initialized
INFO - 2017-08-10 07:51:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-08-10 07:51:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 07:51:38 --> Final output sent to browser
DEBUG - 2017-08-10 07:51:38 --> Total execution time: 0.2652
INFO - 2017-08-10 07:51:47 --> Config Class Initialized
INFO - 2017-08-10 07:51:47 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:51:47 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:51:47 --> Utf8 Class Initialized
INFO - 2017-08-10 07:51:47 --> URI Class Initialized
INFO - 2017-08-10 07:51:47 --> Router Class Initialized
INFO - 2017-08-10 07:51:47 --> Output Class Initialized
INFO - 2017-08-10 07:51:47 --> Security Class Initialized
DEBUG - 2017-08-10 07:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:51:47 --> Input Class Initialized
INFO - 2017-08-10 07:51:47 --> Language Class Initialized
INFO - 2017-08-10 07:51:47 --> Loader Class Initialized
INFO - 2017-08-10 07:51:47 --> Helper loaded: common_helper
INFO - 2017-08-10 07:51:47 --> Database Driver Class Initialized
INFO - 2017-08-10 07:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:51:47 --> Email Class Initialized
INFO - 2017-08-10 07:51:47 --> Controller Class Initialized
INFO - 2017-08-10 07:51:47 --> Helper loaded: form_helper
INFO - 2017-08-10 07:51:47 --> Form Validation Class Initialized
INFO - 2017-08-10 07:51:47 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:51:47 --> Helper loaded: url_helper
INFO - 2017-08-10 07:51:47 --> Model Class Initialized
INFO - 2017-08-10 07:51:47 --> Model Class Initialized
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:21:47 --> Final output sent to browser
DEBUG - 2017-08-10 11:21:47 --> Total execution time: 0.1209
INFO - 2017-08-10 07:51:47 --> Config Class Initialized
INFO - 2017-08-10 07:51:47 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:51:47 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:51:47 --> Utf8 Class Initialized
INFO - 2017-08-10 07:51:47 --> URI Class Initialized
INFO - 2017-08-10 07:51:47 --> Router Class Initialized
INFO - 2017-08-10 07:51:47 --> Output Class Initialized
INFO - 2017-08-10 07:51:47 --> Security Class Initialized
DEBUG - 2017-08-10 07:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:51:47 --> Input Class Initialized
INFO - 2017-08-10 07:51:47 --> Language Class Initialized
INFO - 2017-08-10 07:51:47 --> Loader Class Initialized
INFO - 2017-08-10 07:51:47 --> Helper loaded: common_helper
INFO - 2017-08-10 07:51:47 --> Database Driver Class Initialized
INFO - 2017-08-10 07:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:51:47 --> Email Class Initialized
INFO - 2017-08-10 07:51:47 --> Controller Class Initialized
INFO - 2017-08-10 07:51:47 --> Helper loaded: form_helper
INFO - 2017-08-10 07:51:47 --> Form Validation Class Initialized
INFO - 2017-08-10 07:51:47 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:51:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:51:47 --> Helper loaded: url_helper
INFO - 2017-08-10 07:51:47 --> Model Class Initialized
INFO - 2017-08-10 07:51:47 --> Model Class Initialized
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:21:47 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:21:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:21:47 --> Final output sent to browser
DEBUG - 2017-08-10 11:21:47 --> Total execution time: 0.1328
INFO - 2017-08-10 07:51:52 --> Config Class Initialized
INFO - 2017-08-10 07:51:52 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:51:52 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:51:52 --> Utf8 Class Initialized
INFO - 2017-08-10 07:51:52 --> URI Class Initialized
INFO - 2017-08-10 07:51:52 --> Router Class Initialized
INFO - 2017-08-10 07:51:52 --> Output Class Initialized
INFO - 2017-08-10 07:51:52 --> Security Class Initialized
DEBUG - 2017-08-10 07:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:51:52 --> Input Class Initialized
INFO - 2017-08-10 07:51:52 --> Language Class Initialized
INFO - 2017-08-10 07:51:52 --> Loader Class Initialized
INFO - 2017-08-10 07:51:52 --> Helper loaded: common_helper
INFO - 2017-08-10 07:51:52 --> Database Driver Class Initialized
INFO - 2017-08-10 07:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:51:52 --> Email Class Initialized
INFO - 2017-08-10 07:51:52 --> Controller Class Initialized
INFO - 2017-08-10 07:51:52 --> Helper loaded: form_helper
INFO - 2017-08-10 07:51:52 --> Form Validation Class Initialized
INFO - 2017-08-10 07:51:52 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:51:52 --> Helper loaded: url_helper
INFO - 2017-08-10 07:51:52 --> Model Class Initialized
INFO - 2017-08-10 07:51:52 --> Model Class Initialized
INFO - 2017-08-10 11:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:21:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:52 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:21:53 --> Trying to get property of non-object
ERROR - 2017-08-10 11:21:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:21:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:21:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:21:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:21:53 --> Final output sent to browser
DEBUG - 2017-08-10 11:21:53 --> Total execution time: 0.1147
INFO - 2017-08-10 07:52:23 --> Config Class Initialized
INFO - 2017-08-10 07:52:23 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:23 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:23 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:23 --> URI Class Initialized
INFO - 2017-08-10 07:52:23 --> Router Class Initialized
INFO - 2017-08-10 07:52:23 --> Output Class Initialized
INFO - 2017-08-10 07:52:23 --> Security Class Initialized
DEBUG - 2017-08-10 07:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:52:23 --> Input Class Initialized
INFO - 2017-08-10 07:52:23 --> Language Class Initialized
INFO - 2017-08-10 07:52:23 --> Loader Class Initialized
INFO - 2017-08-10 07:52:23 --> Helper loaded: common_helper
INFO - 2017-08-10 07:52:23 --> Database Driver Class Initialized
INFO - 2017-08-10 07:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:52:23 --> Email Class Initialized
INFO - 2017-08-10 07:52:23 --> Controller Class Initialized
INFO - 2017-08-10 07:52:23 --> Helper loaded: form_helper
INFO - 2017-08-10 07:52:23 --> Form Validation Class Initialized
INFO - 2017-08-10 07:52:23 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:52:23 --> Helper loaded: url_helper
INFO - 2017-08-10 07:52:23 --> Model Class Initialized
INFO - 2017-08-10 07:52:23 --> Model Class Initialized
INFO - 2017-08-10 11:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:22:23 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:22:23 --> Final output sent to browser
DEBUG - 2017-08-10 11:22:23 --> Total execution time: 0.0949
INFO - 2017-08-10 07:52:29 --> Config Class Initialized
INFO - 2017-08-10 07:52:29 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:29 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:29 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:29 --> URI Class Initialized
INFO - 2017-08-10 07:52:29 --> Router Class Initialized
INFO - 2017-08-10 07:52:29 --> Output Class Initialized
INFO - 2017-08-10 07:52:29 --> Security Class Initialized
DEBUG - 2017-08-10 07:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:52:29 --> Input Class Initialized
INFO - 2017-08-10 07:52:29 --> Language Class Initialized
INFO - 2017-08-10 07:52:29 --> Loader Class Initialized
INFO - 2017-08-10 07:52:29 --> Helper loaded: common_helper
INFO - 2017-08-10 07:52:29 --> Database Driver Class Initialized
INFO - 2017-08-10 07:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:52:29 --> Email Class Initialized
INFO - 2017-08-10 07:52:29 --> Controller Class Initialized
INFO - 2017-08-10 07:52:29 --> Helper loaded: form_helper
INFO - 2017-08-10 07:52:29 --> Form Validation Class Initialized
INFO - 2017-08-10 07:52:29 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:52:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:52:29 --> Helper loaded: url_helper
INFO - 2017-08-10 07:52:29 --> Model Class Initialized
INFO - 2017-08-10 07:52:29 --> Model Class Initialized
INFO - 2017-08-10 11:22:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:22:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:22:29 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:22:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:22:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:22:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:22:29 --> Final output sent to browser
DEBUG - 2017-08-10 11:22:29 --> Total execution time: 0.1030
INFO - 2017-08-10 07:52:40 --> Config Class Initialized
INFO - 2017-08-10 07:52:40 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:40 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:40 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:40 --> URI Class Initialized
INFO - 2017-08-10 07:52:40 --> Router Class Initialized
INFO - 2017-08-10 07:52:40 --> Output Class Initialized
INFO - 2017-08-10 07:52:40 --> Security Class Initialized
DEBUG - 2017-08-10 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:52:40 --> Input Class Initialized
INFO - 2017-08-10 07:52:40 --> Language Class Initialized
INFO - 2017-08-10 07:52:40 --> Loader Class Initialized
INFO - 2017-08-10 07:52:40 --> Helper loaded: common_helper
INFO - 2017-08-10 07:52:40 --> Database Driver Class Initialized
INFO - 2017-08-10 07:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:52:40 --> Email Class Initialized
INFO - 2017-08-10 07:52:40 --> Controller Class Initialized
INFO - 2017-08-10 07:52:40 --> Helper loaded: form_helper
INFO - 2017-08-10 07:52:40 --> Form Validation Class Initialized
INFO - 2017-08-10 07:52:40 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:52:40 --> Helper loaded: url_helper
INFO - 2017-08-10 07:52:40 --> Model Class Initialized
INFO - 2017-08-10 07:52:40 --> Model Class Initialized
INFO - 2017-08-10 11:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:22:40 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:22:40 --> Final output sent to browser
DEBUG - 2017-08-10 11:22:40 --> Total execution time: 0.1098
INFO - 2017-08-10 07:52:58 --> Config Class Initialized
INFO - 2017-08-10 07:52:58 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:58 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:58 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:58 --> URI Class Initialized
INFO - 2017-08-10 07:52:58 --> Router Class Initialized
INFO - 2017-08-10 07:52:58 --> Output Class Initialized
INFO - 2017-08-10 07:52:58 --> Security Class Initialized
DEBUG - 2017-08-10 07:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:52:58 --> Input Class Initialized
INFO - 2017-08-10 07:52:58 --> Language Class Initialized
INFO - 2017-08-10 07:52:58 --> Loader Class Initialized
INFO - 2017-08-10 07:52:58 --> Helper loaded: common_helper
INFO - 2017-08-10 07:52:58 --> Database Driver Class Initialized
INFO - 2017-08-10 07:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:52:58 --> Email Class Initialized
INFO - 2017-08-10 07:52:58 --> Controller Class Initialized
INFO - 2017-08-10 07:52:58 --> Helper loaded: form_helper
INFO - 2017-08-10 07:52:58 --> Form Validation Class Initialized
INFO - 2017-08-10 07:52:58 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:52:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:52:58 --> Helper loaded: url_helper
INFO - 2017-08-10 07:52:58 --> Model Class Initialized
INFO - 2017-08-10 07:52:58 --> Model Class Initialized
INFO - 2017-08-10 11:22:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:22:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:22:58 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:22:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:22:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:22:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:22:58 --> Final output sent to browser
DEBUG - 2017-08-10 11:22:58 --> Total execution time: 0.0960
INFO - 2017-08-10 07:52:59 --> Config Class Initialized
INFO - 2017-08-10 07:52:59 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:59 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:59 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:59 --> URI Class Initialized
INFO - 2017-08-10 07:52:59 --> Router Class Initialized
INFO - 2017-08-10 07:52:59 --> Output Class Initialized
INFO - 2017-08-10 07:52:59 --> Security Class Initialized
DEBUG - 2017-08-10 07:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:52:59 --> Input Class Initialized
INFO - 2017-08-10 07:52:59 --> Language Class Initialized
INFO - 2017-08-10 07:52:59 --> Loader Class Initialized
INFO - 2017-08-10 07:52:59 --> Helper loaded: common_helper
INFO - 2017-08-10 07:52:59 --> Database Driver Class Initialized
INFO - 2017-08-10 07:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:52:59 --> Email Class Initialized
INFO - 2017-08-10 07:52:59 --> Controller Class Initialized
INFO - 2017-08-10 07:52:59 --> Helper loaded: form_helper
INFO - 2017-08-10 07:52:59 --> Form Validation Class Initialized
INFO - 2017-08-10 07:52:59 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:52:59 --> Helper loaded: url_helper
INFO - 2017-08-10 07:52:59 --> Model Class Initialized
INFO - 2017-08-10 07:52:59 --> Model Class Initialized
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:22:59 --> Final output sent to browser
DEBUG - 2017-08-10 11:22:59 --> Total execution time: 0.0970
INFO - 2017-08-10 07:52:59 --> Config Class Initialized
INFO - 2017-08-10 07:52:59 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:59 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:59 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:59 --> URI Class Initialized
INFO - 2017-08-10 07:52:59 --> Router Class Initialized
INFO - 2017-08-10 07:52:59 --> Output Class Initialized
INFO - 2017-08-10 07:52:59 --> Security Class Initialized
DEBUG - 2017-08-10 07:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:52:59 --> Input Class Initialized
INFO - 2017-08-10 07:52:59 --> Language Class Initialized
INFO - 2017-08-10 07:52:59 --> Loader Class Initialized
INFO - 2017-08-10 07:52:59 --> Helper loaded: common_helper
INFO - 2017-08-10 07:52:59 --> Database Driver Class Initialized
INFO - 2017-08-10 07:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:52:59 --> Email Class Initialized
INFO - 2017-08-10 07:52:59 --> Controller Class Initialized
INFO - 2017-08-10 07:52:59 --> Helper loaded: form_helper
INFO - 2017-08-10 07:52:59 --> Form Validation Class Initialized
INFO - 2017-08-10 07:52:59 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:52:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:52:59 --> Helper loaded: url_helper
INFO - 2017-08-10 07:52:59 --> Model Class Initialized
INFO - 2017-08-10 07:52:59 --> Model Class Initialized
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:22:59 --> Trying to get property of non-object
ERROR - 2017-08-10 11:22:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:22:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:22:59 --> Final output sent to browser
DEBUG - 2017-08-10 11:22:59 --> Total execution time: 0.0959
INFO - 2017-08-10 07:52:59 --> Config Class Initialized
INFO - 2017-08-10 07:52:59 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:52:59 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:52:59 --> Utf8 Class Initialized
INFO - 2017-08-10 07:52:59 --> URI Class Initialized
INFO - 2017-08-10 07:52:59 --> Router Class Initialized
INFO - 2017-08-10 07:52:59 --> Output Class Initialized
INFO - 2017-08-10 07:53:00 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:00 --> Input Class Initialized
INFO - 2017-08-10 07:53:00 --> Language Class Initialized
INFO - 2017-08-10 07:53:00 --> Loader Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:00 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:00 --> Email Class Initialized
INFO - 2017-08-10 07:53:00 --> Controller Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:00 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:00 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:00 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:00 --> Total execution time: 0.1178
INFO - 2017-08-10 07:53:00 --> Config Class Initialized
INFO - 2017-08-10 07:53:00 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:00 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:00 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:00 --> URI Class Initialized
INFO - 2017-08-10 07:53:00 --> Router Class Initialized
INFO - 2017-08-10 07:53:00 --> Output Class Initialized
INFO - 2017-08-10 07:53:00 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:00 --> Input Class Initialized
INFO - 2017-08-10 07:53:00 --> Language Class Initialized
INFO - 2017-08-10 07:53:00 --> Loader Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:00 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:00 --> Email Class Initialized
INFO - 2017-08-10 07:53:00 --> Controller Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:00 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:00 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:00 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:00 --> Total execution time: 0.1461
INFO - 2017-08-10 07:53:00 --> Config Class Initialized
INFO - 2017-08-10 07:53:00 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:00 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:00 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:00 --> URI Class Initialized
INFO - 2017-08-10 07:53:00 --> Router Class Initialized
INFO - 2017-08-10 07:53:00 --> Output Class Initialized
INFO - 2017-08-10 07:53:00 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:00 --> Input Class Initialized
INFO - 2017-08-10 07:53:00 --> Language Class Initialized
INFO - 2017-08-10 07:53:00 --> Loader Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:00 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:00 --> Email Class Initialized
INFO - 2017-08-10 07:53:00 --> Controller Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:00 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:00 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:00 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:00 --> Total execution time: 0.1127
INFO - 2017-08-10 07:53:00 --> Config Class Initialized
INFO - 2017-08-10 07:53:00 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:00 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:00 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:00 --> URI Class Initialized
INFO - 2017-08-10 07:53:00 --> Router Class Initialized
INFO - 2017-08-10 07:53:00 --> Output Class Initialized
INFO - 2017-08-10 07:53:00 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:00 --> Input Class Initialized
INFO - 2017-08-10 07:53:00 --> Language Class Initialized
INFO - 2017-08-10 07:53:00 --> Loader Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:00 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:00 --> Email Class Initialized
INFO - 2017-08-10 07:53:00 --> Controller Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:00 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:00 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:00 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 07:53:00 --> Model Class Initialized
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 180
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Chats.php 187
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 39
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 49
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 50
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 51
ERROR - 2017-08-10 11:23:00 --> Trying to get property of non-object
ERROR - 2017-08-10 11:23:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addBarChartVlues.php 54
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:00 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:00 --> Total execution time: 0.1194
INFO - 2017-08-10 07:53:11 --> Config Class Initialized
INFO - 2017-08-10 07:53:11 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:11 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:11 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:11 --> URI Class Initialized
INFO - 2017-08-10 07:53:11 --> Router Class Initialized
INFO - 2017-08-10 07:53:11 --> Output Class Initialized
INFO - 2017-08-10 07:53:11 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:11 --> Input Class Initialized
INFO - 2017-08-10 07:53:11 --> Language Class Initialized
INFO - 2017-08-10 07:53:11 --> Loader Class Initialized
INFO - 2017-08-10 07:53:11 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:11 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:11 --> Email Class Initialized
INFO - 2017-08-10 07:53:11 --> Controller Class Initialized
INFO - 2017-08-10 07:53:11 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:11 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:11 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:11 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:11 --> Model Class Initialized
INFO - 2017-08-10 07:53:11 --> Model Class Initialized
INFO - 2017-08-10 07:53:28 --> Config Class Initialized
INFO - 2017-08-10 07:53:28 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:28 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:28 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:28 --> URI Class Initialized
INFO - 2017-08-10 07:53:28 --> Router Class Initialized
INFO - 2017-08-10 07:53:28 --> Output Class Initialized
INFO - 2017-08-10 07:53:28 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:28 --> Input Class Initialized
INFO - 2017-08-10 07:53:28 --> Language Class Initialized
INFO - 2017-08-10 07:53:28 --> Loader Class Initialized
INFO - 2017-08-10 07:53:28 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:28 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:28 --> Email Class Initialized
INFO - 2017-08-10 07:53:28 --> Controller Class Initialized
INFO - 2017-08-10 07:53:28 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:28 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:28 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:28 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:28 --> Model Class Initialized
INFO - 2017-08-10 07:53:28 --> Model Class Initialized
INFO - 2017-08-10 07:53:28 --> Config Class Initialized
INFO - 2017-08-10 07:53:28 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:28 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:28 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:28 --> URI Class Initialized
INFO - 2017-08-10 07:53:28 --> Router Class Initialized
INFO - 2017-08-10 07:53:28 --> Output Class Initialized
INFO - 2017-08-10 07:53:28 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:28 --> Input Class Initialized
INFO - 2017-08-10 07:53:28 --> Language Class Initialized
INFO - 2017-08-10 07:53:28 --> Loader Class Initialized
INFO - 2017-08-10 07:53:28 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:28 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:28 --> Email Class Initialized
INFO - 2017-08-10 07:53:28 --> Controller Class Initialized
INFO - 2017-08-10 07:53:28 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:28 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:28 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:28 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:28 --> Model Class Initialized
INFO - 2017-08-10 07:53:28 --> Model Class Initialized
INFO - 2017-08-10 07:53:28 --> Config Class Initialized
INFO - 2017-08-10 07:53:28 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:28 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:28 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:28 --> URI Class Initialized
DEBUG - 2017-08-10 07:53:28 --> No URI present. Default controller set.
INFO - 2017-08-10 07:53:28 --> Router Class Initialized
INFO - 2017-08-10 07:53:28 --> Output Class Initialized
INFO - 2017-08-10 07:53:28 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:29 --> Input Class Initialized
INFO - 2017-08-10 07:53:29 --> Language Class Initialized
INFO - 2017-08-10 07:53:29 --> Loader Class Initialized
INFO - 2017-08-10 07:53:29 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:29 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:29 --> Email Class Initialized
INFO - 2017-08-10 07:53:29 --> Controller Class Initialized
INFO - 2017-08-10 07:53:29 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:29 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:29 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:29 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:29 --> Model Class Initialized
INFO - 2017-08-10 07:53:29 --> Model Class Initialized
INFO - 2017-08-10 07:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-08-10 07:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 07:53:29 --> Final output sent to browser
DEBUG - 2017-08-10 07:53:29 --> Total execution time: 0.0586
INFO - 2017-08-10 07:53:39 --> Config Class Initialized
INFO - 2017-08-10 07:53:39 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:39 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:39 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:39 --> URI Class Initialized
DEBUG - 2017-08-10 07:53:39 --> No URI present. Default controller set.
INFO - 2017-08-10 07:53:39 --> Router Class Initialized
INFO - 2017-08-10 07:53:39 --> Output Class Initialized
INFO - 2017-08-10 07:53:39 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:39 --> Input Class Initialized
INFO - 2017-08-10 07:53:39 --> Language Class Initialized
INFO - 2017-08-10 07:53:39 --> Loader Class Initialized
INFO - 2017-08-10 07:53:39 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:39 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:39 --> Email Class Initialized
INFO - 2017-08-10 07:53:39 --> Controller Class Initialized
INFO - 2017-08-10 07:53:39 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:39 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:39 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:39 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:39 --> Model Class Initialized
INFO - 2017-08-10 07:53:39 --> Model Class Initialized
DEBUG - 2017-08-10 07:53:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-10 07:53:39 --> Config Class Initialized
INFO - 2017-08-10 07:53:39 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:39 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:39 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:39 --> URI Class Initialized
INFO - 2017-08-10 07:53:39 --> Router Class Initialized
INFO - 2017-08-10 07:53:39 --> Output Class Initialized
INFO - 2017-08-10 07:53:39 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:39 --> Input Class Initialized
INFO - 2017-08-10 07:53:39 --> Language Class Initialized
INFO - 2017-08-10 07:53:39 --> Loader Class Initialized
INFO - 2017-08-10 07:53:39 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:39 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:39 --> Email Class Initialized
INFO - 2017-08-10 07:53:39 --> Controller Class Initialized
INFO - 2017-08-10 07:53:39 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:39 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:39 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:39 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:39 --> Model Class Initialized
INFO - 2017-08-10 07:53:39 --> Model Class Initialized
INFO - 2017-08-10 07:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 07:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 07:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-08-10 07:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 07:53:40 --> Final output sent to browser
DEBUG - 2017-08-10 07:53:40 --> Total execution time: 0.5999
INFO - 2017-08-10 07:53:42 --> Config Class Initialized
INFO - 2017-08-10 07:53:42 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:42 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:42 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:42 --> URI Class Initialized
INFO - 2017-08-10 07:53:42 --> Router Class Initialized
INFO - 2017-08-10 07:53:42 --> Output Class Initialized
INFO - 2017-08-10 07:53:42 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:42 --> Input Class Initialized
INFO - 2017-08-10 07:53:42 --> Language Class Initialized
INFO - 2017-08-10 07:53:42 --> Loader Class Initialized
INFO - 2017-08-10 07:53:42 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:42 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:42 --> Email Class Initialized
INFO - 2017-08-10 07:53:42 --> Controller Class Initialized
INFO - 2017-08-10 07:53:42 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:42 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:42 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:42 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:42 --> Model Class Initialized
INFO - 2017-08-10 07:53:42 --> Model Class Initialized
INFO - 2017-08-10 11:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 11:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 11:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-08-10 11:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:42 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:42 --> Total execution time: 0.1046
INFO - 2017-08-10 07:53:46 --> Config Class Initialized
INFO - 2017-08-10 07:53:46 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:46 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:46 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:46 --> URI Class Initialized
INFO - 2017-08-10 07:53:46 --> Router Class Initialized
INFO - 2017-08-10 07:53:46 --> Output Class Initialized
INFO - 2017-08-10 07:53:46 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:46 --> Input Class Initialized
INFO - 2017-08-10 07:53:46 --> Language Class Initialized
INFO - 2017-08-10 07:53:46 --> Loader Class Initialized
INFO - 2017-08-10 07:53:46 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:46 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:46 --> Email Class Initialized
INFO - 2017-08-10 07:53:46 --> Controller Class Initialized
INFO - 2017-08-10 07:53:46 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:46 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:46 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:46 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:46 --> Model Class Initialized
INFO - 2017-08-10 07:53:46 --> Model Class Initialized
INFO - 2017-08-10 07:53:46 --> Model Class Initialized
INFO - 2017-08-10 11:23:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 11:23:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 11:23:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 11:23:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 11:23:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-10 11:23:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-10 11:23:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:46 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:46 --> Total execution time: 0.2232
INFO - 2017-08-10 07:53:48 --> Config Class Initialized
INFO - 2017-08-10 07:53:48 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:53:48 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:53:48 --> Utf8 Class Initialized
INFO - 2017-08-10 07:53:48 --> URI Class Initialized
INFO - 2017-08-10 07:53:48 --> Router Class Initialized
INFO - 2017-08-10 07:53:48 --> Output Class Initialized
INFO - 2017-08-10 07:53:48 --> Security Class Initialized
DEBUG - 2017-08-10 07:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:53:48 --> Input Class Initialized
INFO - 2017-08-10 07:53:48 --> Language Class Initialized
INFO - 2017-08-10 07:53:48 --> Loader Class Initialized
INFO - 2017-08-10 07:53:48 --> Helper loaded: common_helper
INFO - 2017-08-10 07:53:48 --> Database Driver Class Initialized
INFO - 2017-08-10 07:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:53:48 --> Email Class Initialized
INFO - 2017-08-10 07:53:48 --> Controller Class Initialized
INFO - 2017-08-10 07:53:48 --> Helper loaded: form_helper
INFO - 2017-08-10 07:53:48 --> Form Validation Class Initialized
INFO - 2017-08-10 07:53:48 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:53:48 --> Helper loaded: url_helper
INFO - 2017-08-10 07:53:48 --> Model Class Initialized
INFO - 2017-08-10 07:53:48 --> Model Class Initialized
INFO - 2017-08-10 07:53:48 --> Model Class Initialized
INFO - 2017-08-10 11:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 11:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 11:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 11:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:23:48 --> Final output sent to browser
DEBUG - 2017-08-10 11:23:48 --> Total execution time: 0.0810
INFO - 2017-08-10 07:54:14 --> Config Class Initialized
INFO - 2017-08-10 07:54:14 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:54:14 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:54:14 --> Utf8 Class Initialized
INFO - 2017-08-10 07:54:14 --> URI Class Initialized
INFO - 2017-08-10 07:54:14 --> Router Class Initialized
INFO - 2017-08-10 07:54:14 --> Output Class Initialized
INFO - 2017-08-10 07:54:14 --> Security Class Initialized
DEBUG - 2017-08-10 07:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:54:14 --> Input Class Initialized
INFO - 2017-08-10 07:54:14 --> Language Class Initialized
INFO - 2017-08-10 07:54:14 --> Loader Class Initialized
INFO - 2017-08-10 07:54:14 --> Helper loaded: common_helper
INFO - 2017-08-10 07:54:14 --> Database Driver Class Initialized
INFO - 2017-08-10 07:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:54:14 --> Email Class Initialized
INFO - 2017-08-10 07:54:14 --> Controller Class Initialized
INFO - 2017-08-10 07:54:14 --> Helper loaded: form_helper
INFO - 2017-08-10 07:54:14 --> Form Validation Class Initialized
INFO - 2017-08-10 07:54:14 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:54:14 --> Helper loaded: url_helper
INFO - 2017-08-10 07:54:14 --> Model Class Initialized
INFO - 2017-08-10 07:54:14 --> Model Class Initialized
INFO - 2017-08-10 07:54:14 --> Model Class Initialized
INFO - 2017-08-10 11:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 11:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 11:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 11:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:24:14 --> Final output sent to browser
DEBUG - 2017-08-10 11:24:14 --> Total execution time: 0.0611
INFO - 2017-08-10 07:54:35 --> Config Class Initialized
INFO - 2017-08-10 07:54:35 --> Hooks Class Initialized
DEBUG - 2017-08-10 07:54:35 --> UTF-8 Support Enabled
INFO - 2017-08-10 07:54:35 --> Utf8 Class Initialized
INFO - 2017-08-10 07:54:35 --> URI Class Initialized
INFO - 2017-08-10 07:54:35 --> Router Class Initialized
INFO - 2017-08-10 07:54:35 --> Output Class Initialized
INFO - 2017-08-10 07:54:35 --> Security Class Initialized
DEBUG - 2017-08-10 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 07:54:35 --> Input Class Initialized
INFO - 2017-08-10 07:54:35 --> Language Class Initialized
INFO - 2017-08-10 07:54:35 --> Loader Class Initialized
INFO - 2017-08-10 07:54:35 --> Helper loaded: common_helper
INFO - 2017-08-10 07:54:35 --> Database Driver Class Initialized
INFO - 2017-08-10 07:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 07:54:35 --> Email Class Initialized
INFO - 2017-08-10 07:54:35 --> Controller Class Initialized
INFO - 2017-08-10 07:54:35 --> Helper loaded: form_helper
INFO - 2017-08-10 07:54:35 --> Form Validation Class Initialized
INFO - 2017-08-10 07:54:35 --> Helper loaded: email_helper
DEBUG - 2017-08-10 07:54:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 07:54:35 --> Helper loaded: url_helper
INFO - 2017-08-10 07:54:35 --> Model Class Initialized
INFO - 2017-08-10 07:54:35 --> Model Class Initialized
INFO - 2017-08-10 07:54:35 --> Model Class Initialized
INFO - 2017-08-10 11:24:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 11:24:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 11:24:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:24:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 11:24:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 11:24:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 11:24:35 --> Final output sent to browser
DEBUG - 2017-08-10 11:24:35 --> Total execution time: 0.0634
INFO - 2017-08-10 14:28:30 --> Config Class Initialized
INFO - 2017-08-10 14:28:30 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:28:30 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:28:30 --> Utf8 Class Initialized
INFO - 2017-08-10 14:28:30 --> URI Class Initialized
INFO - 2017-08-10 14:28:30 --> Router Class Initialized
INFO - 2017-08-10 14:28:30 --> Output Class Initialized
INFO - 2017-08-10 14:28:30 --> Security Class Initialized
DEBUG - 2017-08-10 14:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:28:30 --> Input Class Initialized
INFO - 2017-08-10 14:28:30 --> Language Class Initialized
INFO - 2017-08-10 14:28:30 --> Loader Class Initialized
INFO - 2017-08-10 14:28:30 --> Helper loaded: common_helper
INFO - 2017-08-10 14:28:30 --> Database Driver Class Initialized
INFO - 2017-08-10 14:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:28:30 --> Email Class Initialized
INFO - 2017-08-10 14:28:30 --> Controller Class Initialized
INFO - 2017-08-10 14:28:30 --> Helper loaded: form_helper
INFO - 2017-08-10 14:28:30 --> Form Validation Class Initialized
INFO - 2017-08-10 14:28:30 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:28:30 --> Helper loaded: url_helper
INFO - 2017-08-10 14:28:30 --> Model Class Initialized
INFO - 2017-08-10 14:28:30 --> Model Class Initialized
INFO - 2017-08-10 14:28:30 --> Model Class Initialized
INFO - 2017-08-10 17:58:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 17:58:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 17:58:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 17:58:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 17:58:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-10 17:58:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-10 17:58:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 17:58:30 --> Final output sent to browser
DEBUG - 2017-08-10 17:58:30 --> Total execution time: 0.1492
INFO - 2017-08-10 14:28:32 --> Config Class Initialized
INFO - 2017-08-10 14:28:32 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:28:32 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:28:32 --> Utf8 Class Initialized
INFO - 2017-08-10 14:28:32 --> URI Class Initialized
INFO - 2017-08-10 14:28:32 --> Router Class Initialized
INFO - 2017-08-10 14:28:32 --> Output Class Initialized
INFO - 2017-08-10 14:28:32 --> Security Class Initialized
DEBUG - 2017-08-10 14:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:28:32 --> Input Class Initialized
INFO - 2017-08-10 14:28:32 --> Language Class Initialized
INFO - 2017-08-10 14:28:32 --> Loader Class Initialized
INFO - 2017-08-10 14:28:32 --> Helper loaded: common_helper
INFO - 2017-08-10 14:28:32 --> Database Driver Class Initialized
INFO - 2017-08-10 14:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:28:32 --> Email Class Initialized
INFO - 2017-08-10 14:28:32 --> Controller Class Initialized
INFO - 2017-08-10 14:28:32 --> Helper loaded: form_helper
INFO - 2017-08-10 14:28:32 --> Form Validation Class Initialized
INFO - 2017-08-10 14:28:32 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:28:32 --> Helper loaded: url_helper
INFO - 2017-08-10 14:28:32 --> Model Class Initialized
INFO - 2017-08-10 14:28:32 --> Model Class Initialized
INFO - 2017-08-10 14:28:32 --> Model Class Initialized
INFO - 2017-08-10 17:58:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 17:58:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 17:58:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 17:58:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 17:58:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 17:58:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 17:58:32 --> Final output sent to browser
DEBUG - 2017-08-10 17:58:32 --> Total execution time: 0.0581
INFO - 2017-08-10 14:29:13 --> Config Class Initialized
INFO - 2017-08-10 14:29:13 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:29:13 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:29:13 --> Utf8 Class Initialized
INFO - 2017-08-10 14:29:13 --> URI Class Initialized
INFO - 2017-08-10 14:29:13 --> Router Class Initialized
INFO - 2017-08-10 14:29:13 --> Output Class Initialized
INFO - 2017-08-10 14:29:13 --> Security Class Initialized
DEBUG - 2017-08-10 14:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:29:13 --> Input Class Initialized
INFO - 2017-08-10 14:29:13 --> Language Class Initialized
INFO - 2017-08-10 14:29:13 --> Loader Class Initialized
INFO - 2017-08-10 14:29:13 --> Helper loaded: common_helper
INFO - 2017-08-10 14:29:13 --> Database Driver Class Initialized
INFO - 2017-08-10 14:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:29:13 --> Email Class Initialized
INFO - 2017-08-10 14:29:13 --> Controller Class Initialized
INFO - 2017-08-10 14:29:13 --> Helper loaded: form_helper
INFO - 2017-08-10 14:29:13 --> Form Validation Class Initialized
INFO - 2017-08-10 14:29:13 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:29:13 --> Helper loaded: url_helper
INFO - 2017-08-10 14:29:13 --> Model Class Initialized
INFO - 2017-08-10 14:29:13 --> Model Class Initialized
INFO - 2017-08-10 14:29:13 --> Model Class Initialized
INFO - 2017-08-10 17:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 17:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 17:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 17:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 17:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 17:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 17:59:13 --> Final output sent to browser
DEBUG - 2017-08-10 17:59:13 --> Total execution time: 0.0505
INFO - 2017-08-10 14:33:33 --> Config Class Initialized
INFO - 2017-08-10 14:33:33 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:33:33 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:33:33 --> Utf8 Class Initialized
INFO - 2017-08-10 14:33:33 --> URI Class Initialized
INFO - 2017-08-10 14:33:33 --> Router Class Initialized
INFO - 2017-08-10 14:33:33 --> Output Class Initialized
INFO - 2017-08-10 14:33:33 --> Security Class Initialized
DEBUG - 2017-08-10 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:33:33 --> Input Class Initialized
INFO - 2017-08-10 14:33:33 --> Language Class Initialized
INFO - 2017-08-10 14:33:33 --> Loader Class Initialized
INFO - 2017-08-10 14:33:33 --> Helper loaded: common_helper
INFO - 2017-08-10 14:33:33 --> Database Driver Class Initialized
INFO - 2017-08-10 14:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:33:33 --> Email Class Initialized
INFO - 2017-08-10 14:33:33 --> Controller Class Initialized
INFO - 2017-08-10 14:33:33 --> Helper loaded: form_helper
INFO - 2017-08-10 14:33:33 --> Form Validation Class Initialized
INFO - 2017-08-10 14:33:33 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:33:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:33:33 --> Helper loaded: url_helper
INFO - 2017-08-10 14:33:33 --> Model Class Initialized
INFO - 2017-08-10 14:33:33 --> Model Class Initialized
INFO - 2017-08-10 14:33:33 --> Model Class Initialized
INFO - 2017-08-10 18:03:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:03:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:03:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:03:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:03:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:03:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:03:33 --> Final output sent to browser
DEBUG - 2017-08-10 18:03:33 --> Total execution time: 0.0485
INFO - 2017-08-10 14:36:28 --> Config Class Initialized
INFO - 2017-08-10 14:36:28 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:36:28 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:36:28 --> Utf8 Class Initialized
INFO - 2017-08-10 14:36:28 --> URI Class Initialized
INFO - 2017-08-10 14:36:28 --> Router Class Initialized
INFO - 2017-08-10 14:36:28 --> Output Class Initialized
INFO - 2017-08-10 14:36:28 --> Security Class Initialized
DEBUG - 2017-08-10 14:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:36:28 --> Input Class Initialized
INFO - 2017-08-10 14:36:28 --> Language Class Initialized
INFO - 2017-08-10 14:36:28 --> Loader Class Initialized
INFO - 2017-08-10 14:36:28 --> Helper loaded: common_helper
INFO - 2017-08-10 14:36:28 --> Database Driver Class Initialized
INFO - 2017-08-10 14:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:36:28 --> Email Class Initialized
INFO - 2017-08-10 14:36:28 --> Controller Class Initialized
INFO - 2017-08-10 14:36:28 --> Helper loaded: form_helper
INFO - 2017-08-10 14:36:28 --> Form Validation Class Initialized
INFO - 2017-08-10 14:36:28 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:36:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:36:28 --> Helper loaded: url_helper
INFO - 2017-08-10 14:36:28 --> Model Class Initialized
INFO - 2017-08-10 14:36:28 --> Model Class Initialized
INFO - 2017-08-10 14:36:28 --> Model Class Initialized
INFO - 2017-08-10 18:06:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:06:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:06:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:06:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:06:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:06:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:06:28 --> Final output sent to browser
DEBUG - 2017-08-10 18:06:28 --> Total execution time: 0.0538
INFO - 2017-08-10 14:37:37 --> Config Class Initialized
INFO - 2017-08-10 14:37:37 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:37:37 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:37:37 --> Utf8 Class Initialized
INFO - 2017-08-10 14:37:37 --> URI Class Initialized
INFO - 2017-08-10 14:37:37 --> Router Class Initialized
INFO - 2017-08-10 14:37:37 --> Output Class Initialized
INFO - 2017-08-10 14:37:37 --> Security Class Initialized
DEBUG - 2017-08-10 14:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:37:37 --> Input Class Initialized
INFO - 2017-08-10 14:37:37 --> Language Class Initialized
INFO - 2017-08-10 14:37:37 --> Loader Class Initialized
INFO - 2017-08-10 14:37:37 --> Helper loaded: common_helper
INFO - 2017-08-10 14:37:37 --> Database Driver Class Initialized
INFO - 2017-08-10 14:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:37:37 --> Email Class Initialized
INFO - 2017-08-10 14:37:37 --> Controller Class Initialized
INFO - 2017-08-10 14:37:37 --> Helper loaded: form_helper
INFO - 2017-08-10 14:37:37 --> Form Validation Class Initialized
INFO - 2017-08-10 14:37:37 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:37:37 --> Helper loaded: url_helper
INFO - 2017-08-10 14:37:37 --> Model Class Initialized
INFO - 2017-08-10 14:37:37 --> Model Class Initialized
INFO - 2017-08-10 14:37:37 --> Model Class Initialized
INFO - 2017-08-10 18:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:07:37 --> Final output sent to browser
DEBUG - 2017-08-10 18:07:37 --> Total execution time: 0.0551
INFO - 2017-08-10 14:37:51 --> Config Class Initialized
INFO - 2017-08-10 14:37:51 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:37:51 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:37:51 --> Utf8 Class Initialized
INFO - 2017-08-10 14:37:51 --> URI Class Initialized
INFO - 2017-08-10 14:37:51 --> Router Class Initialized
INFO - 2017-08-10 14:37:51 --> Output Class Initialized
INFO - 2017-08-10 14:37:51 --> Security Class Initialized
DEBUG - 2017-08-10 14:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:37:51 --> Input Class Initialized
INFO - 2017-08-10 14:37:51 --> Language Class Initialized
INFO - 2017-08-10 14:37:51 --> Loader Class Initialized
INFO - 2017-08-10 14:37:51 --> Helper loaded: common_helper
INFO - 2017-08-10 14:37:51 --> Database Driver Class Initialized
INFO - 2017-08-10 14:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:37:51 --> Email Class Initialized
INFO - 2017-08-10 14:37:51 --> Controller Class Initialized
INFO - 2017-08-10 14:37:51 --> Helper loaded: form_helper
INFO - 2017-08-10 14:37:51 --> Form Validation Class Initialized
INFO - 2017-08-10 14:37:51 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:37:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:37:51 --> Helper loaded: url_helper
INFO - 2017-08-10 14:37:51 --> Model Class Initialized
INFO - 2017-08-10 14:37:51 --> Model Class Initialized
INFO - 2017-08-10 14:37:51 --> Model Class Initialized
INFO - 2017-08-10 18:07:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:07:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:07:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:07:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:07:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:07:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:07:51 --> Final output sent to browser
DEBUG - 2017-08-10 18:07:51 --> Total execution time: 0.0590
INFO - 2017-08-10 14:38:38 --> Config Class Initialized
INFO - 2017-08-10 14:38:38 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:38:38 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:38:38 --> Utf8 Class Initialized
INFO - 2017-08-10 14:38:38 --> URI Class Initialized
INFO - 2017-08-10 14:38:38 --> Router Class Initialized
INFO - 2017-08-10 14:38:38 --> Output Class Initialized
INFO - 2017-08-10 14:38:38 --> Security Class Initialized
DEBUG - 2017-08-10 14:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:38:38 --> Input Class Initialized
INFO - 2017-08-10 14:38:38 --> Language Class Initialized
INFO - 2017-08-10 14:38:38 --> Loader Class Initialized
INFO - 2017-08-10 14:38:38 --> Helper loaded: common_helper
INFO - 2017-08-10 14:38:38 --> Database Driver Class Initialized
INFO - 2017-08-10 14:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:38:38 --> Email Class Initialized
INFO - 2017-08-10 14:38:38 --> Controller Class Initialized
INFO - 2017-08-10 14:38:38 --> Helper loaded: form_helper
INFO - 2017-08-10 14:38:38 --> Form Validation Class Initialized
INFO - 2017-08-10 14:38:38 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:38:38 --> Helper loaded: url_helper
INFO - 2017-08-10 14:38:38 --> Model Class Initialized
INFO - 2017-08-10 14:38:38 --> Model Class Initialized
INFO - 2017-08-10 14:38:38 --> Model Class Initialized
INFO - 2017-08-10 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:08:38 --> Final output sent to browser
DEBUG - 2017-08-10 18:08:38 --> Total execution time: 0.0624
INFO - 2017-08-10 14:39:57 --> Config Class Initialized
INFO - 2017-08-10 14:39:57 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:39:57 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:39:57 --> Utf8 Class Initialized
INFO - 2017-08-10 14:39:57 --> URI Class Initialized
INFO - 2017-08-10 14:39:57 --> Router Class Initialized
INFO - 2017-08-10 14:39:57 --> Output Class Initialized
INFO - 2017-08-10 14:39:57 --> Security Class Initialized
DEBUG - 2017-08-10 14:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:39:57 --> Input Class Initialized
INFO - 2017-08-10 14:39:57 --> Language Class Initialized
INFO - 2017-08-10 14:39:57 --> Loader Class Initialized
INFO - 2017-08-10 14:39:57 --> Helper loaded: common_helper
INFO - 2017-08-10 14:39:57 --> Database Driver Class Initialized
INFO - 2017-08-10 14:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:39:57 --> Email Class Initialized
INFO - 2017-08-10 14:39:57 --> Controller Class Initialized
INFO - 2017-08-10 14:39:57 --> Helper loaded: form_helper
INFO - 2017-08-10 14:39:57 --> Form Validation Class Initialized
INFO - 2017-08-10 14:39:57 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:39:57 --> Helper loaded: url_helper
INFO - 2017-08-10 14:39:57 --> Model Class Initialized
INFO - 2017-08-10 14:39:57 --> Model Class Initialized
INFO - 2017-08-10 14:39:57 --> Model Class Initialized
INFO - 2017-08-10 18:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:09:57 --> Final output sent to browser
DEBUG - 2017-08-10 18:09:57 --> Total execution time: 0.0513
INFO - 2017-08-10 14:41:54 --> Config Class Initialized
INFO - 2017-08-10 14:41:54 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:41:54 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:41:54 --> Utf8 Class Initialized
INFO - 2017-08-10 14:41:54 --> URI Class Initialized
INFO - 2017-08-10 14:41:54 --> Router Class Initialized
INFO - 2017-08-10 14:41:54 --> Output Class Initialized
INFO - 2017-08-10 14:41:54 --> Security Class Initialized
DEBUG - 2017-08-10 14:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:41:54 --> Input Class Initialized
INFO - 2017-08-10 14:41:54 --> Language Class Initialized
INFO - 2017-08-10 14:41:54 --> Loader Class Initialized
INFO - 2017-08-10 14:41:54 --> Helper loaded: common_helper
INFO - 2017-08-10 14:41:54 --> Database Driver Class Initialized
INFO - 2017-08-10 14:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:41:54 --> Email Class Initialized
INFO - 2017-08-10 14:41:54 --> Controller Class Initialized
INFO - 2017-08-10 14:41:54 --> Helper loaded: form_helper
INFO - 2017-08-10 14:41:54 --> Form Validation Class Initialized
INFO - 2017-08-10 14:41:54 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:41:54 --> Helper loaded: url_helper
INFO - 2017-08-10 14:41:54 --> Model Class Initialized
INFO - 2017-08-10 14:41:54 --> Model Class Initialized
INFO - 2017-08-10 14:41:54 --> Model Class Initialized
INFO - 2017-08-10 18:11:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:11:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:11:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:11:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:11:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:11:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:11:54 --> Final output sent to browser
DEBUG - 2017-08-10 18:11:54 --> Total execution time: 0.0540
INFO - 2017-08-10 14:42:01 --> Config Class Initialized
INFO - 2017-08-10 14:42:01 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:42:01 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:42:01 --> Utf8 Class Initialized
INFO - 2017-08-10 14:42:01 --> URI Class Initialized
INFO - 2017-08-10 14:42:01 --> Router Class Initialized
INFO - 2017-08-10 14:42:01 --> Output Class Initialized
INFO - 2017-08-10 14:42:01 --> Security Class Initialized
DEBUG - 2017-08-10 14:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:42:01 --> Input Class Initialized
INFO - 2017-08-10 14:42:01 --> Language Class Initialized
INFO - 2017-08-10 14:42:01 --> Loader Class Initialized
INFO - 2017-08-10 14:42:01 --> Helper loaded: common_helper
INFO - 2017-08-10 14:42:01 --> Database Driver Class Initialized
INFO - 2017-08-10 14:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:42:01 --> Email Class Initialized
INFO - 2017-08-10 14:42:01 --> Controller Class Initialized
INFO - 2017-08-10 14:42:01 --> Helper loaded: form_helper
INFO - 2017-08-10 14:42:01 --> Form Validation Class Initialized
INFO - 2017-08-10 14:42:01 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:42:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:42:01 --> Helper loaded: url_helper
INFO - 2017-08-10 14:42:01 --> Model Class Initialized
INFO - 2017-08-10 14:42:01 --> Model Class Initialized
INFO - 2017-08-10 14:42:01 --> Model Class Initialized
INFO - 2017-08-10 18:12:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:12:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:12:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:12:01 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:12:01 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-10 18:12:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-10 18:12:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:12:01 --> Final output sent to browser
DEBUG - 2017-08-10 18:12:01 --> Total execution time: 0.1153
INFO - 2017-08-10 14:42:02 --> Config Class Initialized
INFO - 2017-08-10 14:42:02 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:42:02 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:42:02 --> Utf8 Class Initialized
INFO - 2017-08-10 14:42:02 --> URI Class Initialized
INFO - 2017-08-10 14:42:02 --> Router Class Initialized
INFO - 2017-08-10 14:42:02 --> Output Class Initialized
INFO - 2017-08-10 14:42:02 --> Security Class Initialized
DEBUG - 2017-08-10 14:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:42:02 --> Input Class Initialized
INFO - 2017-08-10 14:42:02 --> Language Class Initialized
INFO - 2017-08-10 14:42:02 --> Loader Class Initialized
INFO - 2017-08-10 14:42:02 --> Helper loaded: common_helper
INFO - 2017-08-10 14:42:02 --> Database Driver Class Initialized
INFO - 2017-08-10 14:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:42:02 --> Email Class Initialized
INFO - 2017-08-10 14:42:02 --> Controller Class Initialized
INFO - 2017-08-10 14:42:02 --> Helper loaded: form_helper
INFO - 2017-08-10 14:42:02 --> Form Validation Class Initialized
INFO - 2017-08-10 14:42:02 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:42:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:42:02 --> Helper loaded: url_helper
INFO - 2017-08-10 14:42:02 --> Model Class Initialized
INFO - 2017-08-10 14:42:02 --> Model Class Initialized
INFO - 2017-08-10 14:42:02 --> Model Class Initialized
INFO - 2017-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:12:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:12:02 --> Final output sent to browser
DEBUG - 2017-08-10 18:12:02 --> Total execution time: 0.0493
INFO - 2017-08-10 14:43:35 --> Config Class Initialized
INFO - 2017-08-10 14:43:35 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:43:35 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:43:35 --> Utf8 Class Initialized
INFO - 2017-08-10 14:43:35 --> URI Class Initialized
INFO - 2017-08-10 14:43:35 --> Router Class Initialized
INFO - 2017-08-10 14:43:35 --> Output Class Initialized
INFO - 2017-08-10 14:43:35 --> Security Class Initialized
DEBUG - 2017-08-10 14:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:43:35 --> Input Class Initialized
INFO - 2017-08-10 14:43:35 --> Language Class Initialized
INFO - 2017-08-10 14:43:35 --> Loader Class Initialized
INFO - 2017-08-10 14:43:35 --> Helper loaded: common_helper
INFO - 2017-08-10 14:43:35 --> Database Driver Class Initialized
INFO - 2017-08-10 14:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:43:35 --> Email Class Initialized
INFO - 2017-08-10 14:43:35 --> Controller Class Initialized
INFO - 2017-08-10 14:43:35 --> Helper loaded: form_helper
INFO - 2017-08-10 14:43:35 --> Form Validation Class Initialized
INFO - 2017-08-10 14:43:35 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:43:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:43:35 --> Helper loaded: url_helper
INFO - 2017-08-10 14:43:35 --> Model Class Initialized
INFO - 2017-08-10 14:43:35 --> Model Class Initialized
INFO - 2017-08-10 14:43:35 --> Model Class Initialized
INFO - 2017-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:13:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:13:35 --> Final output sent to browser
DEBUG - 2017-08-10 18:13:35 --> Total execution time: 0.0558
INFO - 2017-08-10 14:44:27 --> Config Class Initialized
INFO - 2017-08-10 14:44:27 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:44:27 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:44:27 --> Utf8 Class Initialized
INFO - 2017-08-10 14:44:27 --> URI Class Initialized
INFO - 2017-08-10 14:44:27 --> Router Class Initialized
INFO - 2017-08-10 14:44:27 --> Output Class Initialized
INFO - 2017-08-10 14:44:27 --> Security Class Initialized
DEBUG - 2017-08-10 14:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:44:27 --> Input Class Initialized
INFO - 2017-08-10 14:44:27 --> Language Class Initialized
INFO - 2017-08-10 14:44:27 --> Loader Class Initialized
INFO - 2017-08-10 14:44:27 --> Helper loaded: common_helper
INFO - 2017-08-10 14:44:27 --> Database Driver Class Initialized
INFO - 2017-08-10 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:44:27 --> Email Class Initialized
INFO - 2017-08-10 14:44:27 --> Controller Class Initialized
INFO - 2017-08-10 14:44:27 --> Helper loaded: form_helper
INFO - 2017-08-10 14:44:27 --> Form Validation Class Initialized
INFO - 2017-08-10 14:44:27 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:44:27 --> Helper loaded: url_helper
INFO - 2017-08-10 14:44:27 --> Model Class Initialized
INFO - 2017-08-10 14:44:27 --> Model Class Initialized
INFO - 2017-08-10 14:44:27 --> Model Class Initialized
INFO - 2017-08-10 18:14:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:14:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:14:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:14:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:14:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:14:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:14:27 --> Final output sent to browser
DEBUG - 2017-08-10 18:14:27 --> Total execution time: 0.0541
INFO - 2017-08-10 14:44:56 --> Config Class Initialized
INFO - 2017-08-10 14:44:56 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:44:56 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:44:56 --> Utf8 Class Initialized
INFO - 2017-08-10 14:44:56 --> URI Class Initialized
INFO - 2017-08-10 14:44:56 --> Router Class Initialized
INFO - 2017-08-10 14:44:56 --> Output Class Initialized
INFO - 2017-08-10 14:44:56 --> Security Class Initialized
DEBUG - 2017-08-10 14:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:44:56 --> Input Class Initialized
INFO - 2017-08-10 14:44:56 --> Language Class Initialized
INFO - 2017-08-10 14:44:56 --> Loader Class Initialized
INFO - 2017-08-10 14:44:56 --> Helper loaded: common_helper
INFO - 2017-08-10 14:44:56 --> Database Driver Class Initialized
INFO - 2017-08-10 14:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:44:56 --> Email Class Initialized
INFO - 2017-08-10 14:44:56 --> Controller Class Initialized
INFO - 2017-08-10 14:44:56 --> Helper loaded: form_helper
INFO - 2017-08-10 14:44:56 --> Form Validation Class Initialized
INFO - 2017-08-10 14:44:56 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:44:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:44:56 --> Helper loaded: url_helper
INFO - 2017-08-10 14:44:56 --> Model Class Initialized
INFO - 2017-08-10 14:44:56 --> Model Class Initialized
INFO - 2017-08-10 14:44:56 --> Model Class Initialized
INFO - 2017-08-10 18:14:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:14:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:14:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:14:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:14:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:14:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:14:56 --> Final output sent to browser
DEBUG - 2017-08-10 18:14:56 --> Total execution time: 0.0508
INFO - 2017-08-10 14:45:19 --> Config Class Initialized
INFO - 2017-08-10 14:45:19 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:45:19 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:45:19 --> Utf8 Class Initialized
INFO - 2017-08-10 14:45:19 --> URI Class Initialized
INFO - 2017-08-10 14:45:19 --> Router Class Initialized
INFO - 2017-08-10 14:45:19 --> Output Class Initialized
INFO - 2017-08-10 14:45:19 --> Security Class Initialized
DEBUG - 2017-08-10 14:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:45:19 --> Input Class Initialized
INFO - 2017-08-10 14:45:19 --> Language Class Initialized
INFO - 2017-08-10 14:45:19 --> Loader Class Initialized
INFO - 2017-08-10 14:45:19 --> Helper loaded: common_helper
INFO - 2017-08-10 14:45:19 --> Database Driver Class Initialized
INFO - 2017-08-10 14:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:45:19 --> Email Class Initialized
INFO - 2017-08-10 14:45:19 --> Controller Class Initialized
INFO - 2017-08-10 14:45:19 --> Helper loaded: form_helper
INFO - 2017-08-10 14:45:19 --> Form Validation Class Initialized
INFO - 2017-08-10 14:45:19 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:45:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:45:19 --> Helper loaded: url_helper
INFO - 2017-08-10 14:45:19 --> Model Class Initialized
INFO - 2017-08-10 14:45:19 --> Model Class Initialized
INFO - 2017-08-10 14:45:19 --> Model Class Initialized
INFO - 2017-08-10 18:15:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:15:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:15:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:15:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:15:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:15:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:15:19 --> Final output sent to browser
DEBUG - 2017-08-10 18:15:19 --> Total execution time: 0.0525
INFO - 2017-08-10 14:46:16 --> Config Class Initialized
INFO - 2017-08-10 14:46:16 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:46:16 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:46:16 --> Utf8 Class Initialized
INFO - 2017-08-10 14:46:16 --> URI Class Initialized
INFO - 2017-08-10 14:46:16 --> Router Class Initialized
INFO - 2017-08-10 14:46:16 --> Output Class Initialized
INFO - 2017-08-10 14:46:16 --> Security Class Initialized
DEBUG - 2017-08-10 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:46:16 --> Input Class Initialized
INFO - 2017-08-10 14:46:16 --> Language Class Initialized
INFO - 2017-08-10 14:46:16 --> Loader Class Initialized
INFO - 2017-08-10 14:46:16 --> Helper loaded: common_helper
INFO - 2017-08-10 14:46:16 --> Database Driver Class Initialized
INFO - 2017-08-10 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:46:16 --> Email Class Initialized
INFO - 2017-08-10 14:46:16 --> Controller Class Initialized
INFO - 2017-08-10 14:46:16 --> Helper loaded: form_helper
INFO - 2017-08-10 14:46:16 --> Form Validation Class Initialized
INFO - 2017-08-10 14:46:16 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:46:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:46:16 --> Helper loaded: url_helper
INFO - 2017-08-10 14:46:16 --> Model Class Initialized
INFO - 2017-08-10 14:46:16 --> Model Class Initialized
INFO - 2017-08-10 14:46:16 --> Model Class Initialized
INFO - 2017-08-10 18:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:16:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:16:16 --> Final output sent to browser
DEBUG - 2017-08-10 18:16:16 --> Total execution time: 0.0542
INFO - 2017-08-10 14:48:46 --> Config Class Initialized
INFO - 2017-08-10 14:48:46 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:48:46 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:48:46 --> Utf8 Class Initialized
INFO - 2017-08-10 14:48:46 --> URI Class Initialized
INFO - 2017-08-10 14:48:46 --> Router Class Initialized
INFO - 2017-08-10 14:48:46 --> Output Class Initialized
INFO - 2017-08-10 14:48:46 --> Security Class Initialized
DEBUG - 2017-08-10 14:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:48:46 --> Input Class Initialized
INFO - 2017-08-10 14:48:46 --> Language Class Initialized
INFO - 2017-08-10 14:48:46 --> Loader Class Initialized
INFO - 2017-08-10 14:48:46 --> Helper loaded: common_helper
INFO - 2017-08-10 14:48:46 --> Database Driver Class Initialized
INFO - 2017-08-10 14:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:48:46 --> Email Class Initialized
INFO - 2017-08-10 14:48:46 --> Controller Class Initialized
INFO - 2017-08-10 14:48:46 --> Helper loaded: form_helper
INFO - 2017-08-10 14:48:46 --> Form Validation Class Initialized
INFO - 2017-08-10 14:48:46 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:48:46 --> Helper loaded: url_helper
INFO - 2017-08-10 14:48:46 --> Model Class Initialized
INFO - 2017-08-10 14:48:46 --> Model Class Initialized
INFO - 2017-08-10 14:48:46 --> Model Class Initialized
INFO - 2017-08-10 18:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:18:46 --> Final output sent to browser
DEBUG - 2017-08-10 18:18:46 --> Total execution time: 0.0529
INFO - 2017-08-10 14:48:56 --> Config Class Initialized
INFO - 2017-08-10 14:48:56 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:48:56 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:48:56 --> Utf8 Class Initialized
INFO - 2017-08-10 14:48:56 --> URI Class Initialized
INFO - 2017-08-10 14:48:56 --> Router Class Initialized
INFO - 2017-08-10 14:48:56 --> Output Class Initialized
INFO - 2017-08-10 14:48:56 --> Security Class Initialized
DEBUG - 2017-08-10 14:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:48:56 --> Input Class Initialized
INFO - 2017-08-10 14:48:56 --> Language Class Initialized
INFO - 2017-08-10 14:48:56 --> Loader Class Initialized
INFO - 2017-08-10 14:48:56 --> Helper loaded: common_helper
INFO - 2017-08-10 14:48:56 --> Database Driver Class Initialized
INFO - 2017-08-10 14:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:48:56 --> Email Class Initialized
INFO - 2017-08-10 14:48:56 --> Controller Class Initialized
INFO - 2017-08-10 14:48:56 --> Helper loaded: form_helper
INFO - 2017-08-10 14:48:56 --> Form Validation Class Initialized
INFO - 2017-08-10 14:48:56 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:48:56 --> Helper loaded: url_helper
INFO - 2017-08-10 14:48:56 --> Model Class Initialized
INFO - 2017-08-10 14:48:56 --> Model Class Initialized
INFO - 2017-08-10 14:48:56 --> Model Class Initialized
INFO - 2017-08-10 18:18:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:18:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:18:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:18:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:18:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:18:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:18:56 --> Final output sent to browser
DEBUG - 2017-08-10 18:18:56 --> Total execution time: 0.0536
INFO - 2017-08-10 14:49:53 --> Config Class Initialized
INFO - 2017-08-10 14:49:53 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:49:53 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:49:53 --> Utf8 Class Initialized
INFO - 2017-08-10 14:49:53 --> URI Class Initialized
INFO - 2017-08-10 14:49:53 --> Router Class Initialized
INFO - 2017-08-10 14:49:53 --> Output Class Initialized
INFO - 2017-08-10 14:49:53 --> Security Class Initialized
DEBUG - 2017-08-10 14:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:49:53 --> Input Class Initialized
INFO - 2017-08-10 14:49:53 --> Language Class Initialized
INFO - 2017-08-10 14:49:53 --> Loader Class Initialized
INFO - 2017-08-10 14:49:53 --> Helper loaded: common_helper
INFO - 2017-08-10 14:49:53 --> Database Driver Class Initialized
INFO - 2017-08-10 14:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:49:53 --> Email Class Initialized
INFO - 2017-08-10 14:49:53 --> Controller Class Initialized
INFO - 2017-08-10 14:49:53 --> Helper loaded: form_helper
INFO - 2017-08-10 14:49:53 --> Form Validation Class Initialized
INFO - 2017-08-10 14:49:53 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:49:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:49:53 --> Helper loaded: url_helper
INFO - 2017-08-10 14:49:53 --> Model Class Initialized
INFO - 2017-08-10 14:49:53 --> Model Class Initialized
INFO - 2017-08-10 14:49:53 --> Model Class Initialized
INFO - 2017-08-10 18:19:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:19:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:19:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:19:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:19:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:19:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:19:53 --> Final output sent to browser
DEBUG - 2017-08-10 18:19:53 --> Total execution time: 0.0522
INFO - 2017-08-10 14:50:37 --> Config Class Initialized
INFO - 2017-08-10 14:50:37 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:50:37 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:50:37 --> Utf8 Class Initialized
INFO - 2017-08-10 14:50:37 --> URI Class Initialized
INFO - 2017-08-10 14:50:37 --> Router Class Initialized
INFO - 2017-08-10 14:50:37 --> Output Class Initialized
INFO - 2017-08-10 14:50:37 --> Security Class Initialized
DEBUG - 2017-08-10 14:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:50:37 --> Input Class Initialized
INFO - 2017-08-10 14:50:37 --> Language Class Initialized
INFO - 2017-08-10 14:50:37 --> Loader Class Initialized
INFO - 2017-08-10 14:50:37 --> Helper loaded: common_helper
INFO - 2017-08-10 14:50:37 --> Database Driver Class Initialized
INFO - 2017-08-10 14:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:50:37 --> Email Class Initialized
INFO - 2017-08-10 14:50:37 --> Controller Class Initialized
INFO - 2017-08-10 14:50:37 --> Helper loaded: form_helper
INFO - 2017-08-10 14:50:37 --> Form Validation Class Initialized
INFO - 2017-08-10 14:50:37 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:50:37 --> Helper loaded: url_helper
INFO - 2017-08-10 14:50:37 --> Model Class Initialized
INFO - 2017-08-10 14:50:37 --> Model Class Initialized
INFO - 2017-08-10 14:50:37 --> Model Class Initialized
INFO - 2017-08-10 18:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:20:37 --> Final output sent to browser
DEBUG - 2017-08-10 18:20:37 --> Total execution time: 0.0524
INFO - 2017-08-10 14:51:17 --> Config Class Initialized
INFO - 2017-08-10 14:51:17 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:51:17 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:51:17 --> Utf8 Class Initialized
INFO - 2017-08-10 14:51:17 --> URI Class Initialized
INFO - 2017-08-10 14:51:17 --> Router Class Initialized
INFO - 2017-08-10 14:51:17 --> Output Class Initialized
INFO - 2017-08-10 14:51:17 --> Security Class Initialized
DEBUG - 2017-08-10 14:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:51:17 --> Input Class Initialized
INFO - 2017-08-10 14:51:17 --> Language Class Initialized
INFO - 2017-08-10 14:51:17 --> Loader Class Initialized
INFO - 2017-08-10 14:51:17 --> Helper loaded: common_helper
INFO - 2017-08-10 14:51:17 --> Database Driver Class Initialized
INFO - 2017-08-10 14:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:51:17 --> Email Class Initialized
INFO - 2017-08-10 14:51:17 --> Controller Class Initialized
INFO - 2017-08-10 14:51:17 --> Helper loaded: form_helper
INFO - 2017-08-10 14:51:17 --> Form Validation Class Initialized
INFO - 2017-08-10 14:51:17 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:51:17 --> Helper loaded: url_helper
INFO - 2017-08-10 14:51:17 --> Model Class Initialized
INFO - 2017-08-10 14:51:17 --> Model Class Initialized
INFO - 2017-08-10 14:51:17 --> Model Class Initialized
INFO - 2017-08-10 18:21:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:21:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:21:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:21:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:21:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:21:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:21:17 --> Final output sent to browser
DEBUG - 2017-08-10 18:21:17 --> Total execution time: 0.0525
INFO - 2017-08-10 14:51:43 --> Config Class Initialized
INFO - 2017-08-10 14:51:43 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:51:43 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:51:43 --> Utf8 Class Initialized
INFO - 2017-08-10 14:51:43 --> URI Class Initialized
INFO - 2017-08-10 14:51:43 --> Router Class Initialized
INFO - 2017-08-10 14:51:43 --> Output Class Initialized
INFO - 2017-08-10 14:51:43 --> Security Class Initialized
DEBUG - 2017-08-10 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:51:43 --> Input Class Initialized
INFO - 2017-08-10 14:51:43 --> Language Class Initialized
INFO - 2017-08-10 14:51:43 --> Loader Class Initialized
INFO - 2017-08-10 14:51:43 --> Helper loaded: common_helper
INFO - 2017-08-10 14:51:43 --> Database Driver Class Initialized
INFO - 2017-08-10 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:51:43 --> Email Class Initialized
INFO - 2017-08-10 14:51:43 --> Controller Class Initialized
INFO - 2017-08-10 14:51:43 --> Helper loaded: form_helper
INFO - 2017-08-10 14:51:43 --> Form Validation Class Initialized
INFO - 2017-08-10 14:51:43 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:51:43 --> Helper loaded: url_helper
INFO - 2017-08-10 14:51:43 --> Model Class Initialized
INFO - 2017-08-10 14:51:43 --> Model Class Initialized
INFO - 2017-08-10 14:51:43 --> Model Class Initialized
INFO - 2017-08-10 18:21:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:21:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:21:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:21:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:21:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:21:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:21:43 --> Final output sent to browser
DEBUG - 2017-08-10 18:21:43 --> Total execution time: 0.0493
INFO - 2017-08-10 14:52:06 --> Config Class Initialized
INFO - 2017-08-10 14:52:06 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:52:06 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:52:06 --> Utf8 Class Initialized
INFO - 2017-08-10 14:52:06 --> URI Class Initialized
INFO - 2017-08-10 14:52:06 --> Router Class Initialized
INFO - 2017-08-10 14:52:06 --> Output Class Initialized
INFO - 2017-08-10 14:52:06 --> Security Class Initialized
DEBUG - 2017-08-10 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:52:06 --> Input Class Initialized
INFO - 2017-08-10 14:52:06 --> Language Class Initialized
INFO - 2017-08-10 14:52:06 --> Loader Class Initialized
INFO - 2017-08-10 14:52:06 --> Helper loaded: common_helper
INFO - 2017-08-10 14:52:06 --> Database Driver Class Initialized
INFO - 2017-08-10 14:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:52:06 --> Email Class Initialized
INFO - 2017-08-10 14:52:06 --> Controller Class Initialized
INFO - 2017-08-10 14:52:06 --> Helper loaded: form_helper
INFO - 2017-08-10 14:52:06 --> Form Validation Class Initialized
INFO - 2017-08-10 14:52:06 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:52:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:52:06 --> Helper loaded: url_helper
INFO - 2017-08-10 14:52:06 --> Model Class Initialized
INFO - 2017-08-10 14:52:06 --> Model Class Initialized
INFO - 2017-08-10 14:52:06 --> Model Class Initialized
INFO - 2017-08-10 18:22:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:22:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:22:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:22:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:22:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:22:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:22:06 --> Final output sent to browser
DEBUG - 2017-08-10 18:22:06 --> Total execution time: 0.0533
INFO - 2017-08-10 14:52:15 --> Config Class Initialized
INFO - 2017-08-10 14:52:15 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:52:15 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:52:15 --> Utf8 Class Initialized
INFO - 2017-08-10 14:52:15 --> URI Class Initialized
INFO - 2017-08-10 14:52:15 --> Router Class Initialized
INFO - 2017-08-10 14:52:15 --> Output Class Initialized
INFO - 2017-08-10 14:52:15 --> Security Class Initialized
DEBUG - 2017-08-10 14:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:52:15 --> Input Class Initialized
INFO - 2017-08-10 14:52:15 --> Language Class Initialized
INFO - 2017-08-10 14:52:15 --> Loader Class Initialized
INFO - 2017-08-10 14:52:15 --> Helper loaded: common_helper
INFO - 2017-08-10 14:52:15 --> Database Driver Class Initialized
INFO - 2017-08-10 14:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:52:15 --> Email Class Initialized
INFO - 2017-08-10 14:52:15 --> Controller Class Initialized
INFO - 2017-08-10 14:52:15 --> Helper loaded: form_helper
INFO - 2017-08-10 14:52:15 --> Form Validation Class Initialized
INFO - 2017-08-10 14:52:15 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:52:15 --> Helper loaded: url_helper
INFO - 2017-08-10 14:52:15 --> Model Class Initialized
INFO - 2017-08-10 14:52:15 --> Model Class Initialized
INFO - 2017-08-10 14:52:15 --> Model Class Initialized
INFO - 2017-08-10 18:22:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:22:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:22:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:22:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:22:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:22:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:22:15 --> Final output sent to browser
DEBUG - 2017-08-10 18:22:15 --> Total execution time: 0.0562
INFO - 2017-08-10 14:52:48 --> Config Class Initialized
INFO - 2017-08-10 14:52:48 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:52:48 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:52:48 --> Utf8 Class Initialized
INFO - 2017-08-10 14:52:48 --> URI Class Initialized
INFO - 2017-08-10 14:52:48 --> Router Class Initialized
INFO - 2017-08-10 14:52:48 --> Output Class Initialized
INFO - 2017-08-10 14:52:48 --> Security Class Initialized
DEBUG - 2017-08-10 14:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:52:48 --> Input Class Initialized
INFO - 2017-08-10 14:52:48 --> Language Class Initialized
INFO - 2017-08-10 14:52:48 --> Loader Class Initialized
INFO - 2017-08-10 14:52:48 --> Helper loaded: common_helper
INFO - 2017-08-10 14:52:48 --> Database Driver Class Initialized
INFO - 2017-08-10 14:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:52:48 --> Email Class Initialized
INFO - 2017-08-10 14:52:48 --> Controller Class Initialized
INFO - 2017-08-10 14:52:48 --> Helper loaded: form_helper
INFO - 2017-08-10 14:52:48 --> Form Validation Class Initialized
INFO - 2017-08-10 14:52:48 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:52:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:52:48 --> Helper loaded: url_helper
INFO - 2017-08-10 14:52:48 --> Model Class Initialized
INFO - 2017-08-10 14:52:48 --> Model Class Initialized
INFO - 2017-08-10 14:52:48 --> Model Class Initialized
INFO - 2017-08-10 18:22:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:22:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:22:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:22:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:22:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:22:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:22:48 --> Final output sent to browser
DEBUG - 2017-08-10 18:22:48 --> Total execution time: 0.0506
INFO - 2017-08-10 14:53:15 --> Config Class Initialized
INFO - 2017-08-10 14:53:15 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:53:15 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:53:15 --> Utf8 Class Initialized
INFO - 2017-08-10 14:53:15 --> URI Class Initialized
INFO - 2017-08-10 14:53:15 --> Router Class Initialized
INFO - 2017-08-10 14:53:15 --> Output Class Initialized
INFO - 2017-08-10 14:53:15 --> Security Class Initialized
DEBUG - 2017-08-10 14:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:53:15 --> Input Class Initialized
INFO - 2017-08-10 14:53:15 --> Language Class Initialized
INFO - 2017-08-10 14:53:15 --> Loader Class Initialized
INFO - 2017-08-10 14:53:15 --> Helper loaded: common_helper
INFO - 2017-08-10 14:53:15 --> Database Driver Class Initialized
INFO - 2017-08-10 14:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:53:15 --> Email Class Initialized
INFO - 2017-08-10 14:53:15 --> Controller Class Initialized
INFO - 2017-08-10 14:53:15 --> Helper loaded: form_helper
INFO - 2017-08-10 14:53:15 --> Form Validation Class Initialized
INFO - 2017-08-10 14:53:15 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:53:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:53:15 --> Helper loaded: url_helper
INFO - 2017-08-10 14:53:15 --> Model Class Initialized
INFO - 2017-08-10 14:53:15 --> Model Class Initialized
INFO - 2017-08-10 14:53:15 --> Model Class Initialized
INFO - 2017-08-10 18:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:23:15 --> Final output sent to browser
DEBUG - 2017-08-10 18:23:15 --> Total execution time: 0.0503
INFO - 2017-08-10 14:53:23 --> Config Class Initialized
INFO - 2017-08-10 14:53:23 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:53:23 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:53:23 --> Utf8 Class Initialized
INFO - 2017-08-10 14:53:23 --> URI Class Initialized
INFO - 2017-08-10 14:53:23 --> Router Class Initialized
INFO - 2017-08-10 14:53:23 --> Output Class Initialized
INFO - 2017-08-10 14:53:23 --> Security Class Initialized
DEBUG - 2017-08-10 14:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:53:23 --> Input Class Initialized
INFO - 2017-08-10 14:53:23 --> Language Class Initialized
INFO - 2017-08-10 14:53:23 --> Loader Class Initialized
INFO - 2017-08-10 14:53:23 --> Helper loaded: common_helper
INFO - 2017-08-10 14:53:23 --> Database Driver Class Initialized
INFO - 2017-08-10 14:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:53:23 --> Email Class Initialized
INFO - 2017-08-10 14:53:23 --> Controller Class Initialized
INFO - 2017-08-10 14:53:23 --> Helper loaded: form_helper
INFO - 2017-08-10 14:53:23 --> Form Validation Class Initialized
INFO - 2017-08-10 14:53:23 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:53:23 --> Helper loaded: url_helper
INFO - 2017-08-10 14:53:23 --> Model Class Initialized
INFO - 2017-08-10 14:53:23 --> Model Class Initialized
INFO - 2017-08-10 14:53:23 --> Model Class Initialized
INFO - 2017-08-10 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:23:23 --> Final output sent to browser
DEBUG - 2017-08-10 18:23:23 --> Total execution time: 0.0584
INFO - 2017-08-10 14:53:35 --> Config Class Initialized
INFO - 2017-08-10 14:53:35 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:53:35 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:53:35 --> Utf8 Class Initialized
INFO - 2017-08-10 14:53:35 --> URI Class Initialized
INFO - 2017-08-10 14:53:35 --> Router Class Initialized
INFO - 2017-08-10 14:53:35 --> Output Class Initialized
INFO - 2017-08-10 14:53:35 --> Security Class Initialized
DEBUG - 2017-08-10 14:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:53:35 --> Input Class Initialized
INFO - 2017-08-10 14:53:35 --> Language Class Initialized
INFO - 2017-08-10 14:53:35 --> Loader Class Initialized
INFO - 2017-08-10 14:53:35 --> Helper loaded: common_helper
INFO - 2017-08-10 14:53:35 --> Database Driver Class Initialized
INFO - 2017-08-10 14:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:53:35 --> Email Class Initialized
INFO - 2017-08-10 14:53:35 --> Controller Class Initialized
INFO - 2017-08-10 14:53:35 --> Helper loaded: form_helper
INFO - 2017-08-10 14:53:35 --> Form Validation Class Initialized
INFO - 2017-08-10 14:53:35 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:53:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:53:35 --> Helper loaded: url_helper
INFO - 2017-08-10 14:53:35 --> Model Class Initialized
INFO - 2017-08-10 14:53:35 --> Model Class Initialized
INFO - 2017-08-10 14:53:35 --> Model Class Initialized
INFO - 2017-08-10 18:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:23:35 --> Final output sent to browser
DEBUG - 2017-08-10 18:23:35 --> Total execution time: 0.0660
INFO - 2017-08-10 14:53:43 --> Config Class Initialized
INFO - 2017-08-10 14:53:43 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:53:43 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:53:43 --> Utf8 Class Initialized
INFO - 2017-08-10 14:53:43 --> URI Class Initialized
INFO - 2017-08-10 14:53:43 --> Router Class Initialized
INFO - 2017-08-10 14:53:43 --> Output Class Initialized
INFO - 2017-08-10 14:53:43 --> Security Class Initialized
DEBUG - 2017-08-10 14:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:53:43 --> Input Class Initialized
INFO - 2017-08-10 14:53:43 --> Language Class Initialized
INFO - 2017-08-10 14:53:43 --> Loader Class Initialized
INFO - 2017-08-10 14:53:43 --> Helper loaded: common_helper
INFO - 2017-08-10 14:53:43 --> Database Driver Class Initialized
INFO - 2017-08-10 14:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:53:43 --> Email Class Initialized
INFO - 2017-08-10 14:53:43 --> Controller Class Initialized
INFO - 2017-08-10 14:53:43 --> Helper loaded: form_helper
INFO - 2017-08-10 14:53:43 --> Form Validation Class Initialized
INFO - 2017-08-10 14:53:43 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:53:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:53:43 --> Helper loaded: url_helper
INFO - 2017-08-10 14:53:43 --> Model Class Initialized
INFO - 2017-08-10 14:53:43 --> Model Class Initialized
INFO - 2017-08-10 14:53:43 --> Model Class Initialized
INFO - 2017-08-10 18:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:23:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:23:43 --> Final output sent to browser
DEBUG - 2017-08-10 18:23:43 --> Total execution time: 0.0598
INFO - 2017-08-10 14:55:28 --> Config Class Initialized
INFO - 2017-08-10 14:55:28 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:55:28 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:55:28 --> Utf8 Class Initialized
INFO - 2017-08-10 14:55:28 --> URI Class Initialized
INFO - 2017-08-10 14:55:28 --> Router Class Initialized
INFO - 2017-08-10 14:55:28 --> Output Class Initialized
INFO - 2017-08-10 14:55:28 --> Security Class Initialized
DEBUG - 2017-08-10 14:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:55:28 --> Input Class Initialized
INFO - 2017-08-10 14:55:28 --> Language Class Initialized
INFO - 2017-08-10 14:55:28 --> Loader Class Initialized
INFO - 2017-08-10 14:55:28 --> Helper loaded: common_helper
INFO - 2017-08-10 14:55:28 --> Database Driver Class Initialized
INFO - 2017-08-10 14:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:55:28 --> Email Class Initialized
INFO - 2017-08-10 14:55:28 --> Controller Class Initialized
INFO - 2017-08-10 14:55:28 --> Helper loaded: form_helper
INFO - 2017-08-10 14:55:28 --> Form Validation Class Initialized
INFO - 2017-08-10 14:55:28 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:55:28 --> Helper loaded: url_helper
INFO - 2017-08-10 14:55:28 --> Model Class Initialized
INFO - 2017-08-10 14:55:28 --> Model Class Initialized
INFO - 2017-08-10 14:55:28 --> Model Class Initialized
INFO - 2017-08-10 18:25:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:25:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:25:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:25:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:25:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:25:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:25:28 --> Final output sent to browser
DEBUG - 2017-08-10 18:25:28 --> Total execution time: 0.0525
INFO - 2017-08-10 14:56:45 --> Config Class Initialized
INFO - 2017-08-10 14:56:45 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:56:45 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:56:45 --> Utf8 Class Initialized
INFO - 2017-08-10 14:56:45 --> URI Class Initialized
INFO - 2017-08-10 14:56:45 --> Router Class Initialized
INFO - 2017-08-10 14:56:45 --> Output Class Initialized
INFO - 2017-08-10 14:56:45 --> Security Class Initialized
DEBUG - 2017-08-10 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:56:45 --> Input Class Initialized
INFO - 2017-08-10 14:56:45 --> Language Class Initialized
INFO - 2017-08-10 14:56:45 --> Loader Class Initialized
INFO - 2017-08-10 14:56:45 --> Helper loaded: common_helper
INFO - 2017-08-10 14:56:45 --> Database Driver Class Initialized
INFO - 2017-08-10 14:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:56:45 --> Email Class Initialized
INFO - 2017-08-10 14:56:45 --> Controller Class Initialized
INFO - 2017-08-10 14:56:45 --> Helper loaded: form_helper
INFO - 2017-08-10 14:56:45 --> Form Validation Class Initialized
INFO - 2017-08-10 14:56:45 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:56:45 --> Helper loaded: url_helper
INFO - 2017-08-10 14:56:45 --> Model Class Initialized
INFO - 2017-08-10 14:56:45 --> Model Class Initialized
INFO - 2017-08-10 14:56:45 --> Model Class Initialized
INFO - 2017-08-10 18:26:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:26:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:26:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:26:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:26:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:26:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:26:45 --> Final output sent to browser
DEBUG - 2017-08-10 18:26:45 --> Total execution time: 0.0508
INFO - 2017-08-10 14:56:55 --> Config Class Initialized
INFO - 2017-08-10 14:56:55 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:56:55 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:56:55 --> Utf8 Class Initialized
INFO - 2017-08-10 14:56:55 --> URI Class Initialized
INFO - 2017-08-10 14:56:55 --> Router Class Initialized
INFO - 2017-08-10 14:56:55 --> Output Class Initialized
INFO - 2017-08-10 14:56:55 --> Security Class Initialized
DEBUG - 2017-08-10 14:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:56:55 --> Input Class Initialized
INFO - 2017-08-10 14:56:55 --> Language Class Initialized
INFO - 2017-08-10 14:56:55 --> Loader Class Initialized
INFO - 2017-08-10 14:56:55 --> Helper loaded: common_helper
INFO - 2017-08-10 14:56:55 --> Database Driver Class Initialized
INFO - 2017-08-10 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:56:55 --> Email Class Initialized
INFO - 2017-08-10 14:56:55 --> Controller Class Initialized
INFO - 2017-08-10 14:56:55 --> Helper loaded: form_helper
INFO - 2017-08-10 14:56:55 --> Form Validation Class Initialized
INFO - 2017-08-10 14:56:55 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:56:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:56:55 --> Helper loaded: url_helper
INFO - 2017-08-10 14:56:55 --> Model Class Initialized
INFO - 2017-08-10 14:56:55 --> Model Class Initialized
INFO - 2017-08-10 14:56:55 --> Model Class Initialized
INFO - 2017-08-10 18:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:26:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:26:55 --> Final output sent to browser
DEBUG - 2017-08-10 18:26:55 --> Total execution time: 0.0509
INFO - 2017-08-10 14:57:11 --> Config Class Initialized
INFO - 2017-08-10 14:57:11 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:57:11 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:57:11 --> Utf8 Class Initialized
INFO - 2017-08-10 14:57:11 --> URI Class Initialized
INFO - 2017-08-10 14:57:11 --> Router Class Initialized
INFO - 2017-08-10 14:57:11 --> Output Class Initialized
INFO - 2017-08-10 14:57:11 --> Security Class Initialized
DEBUG - 2017-08-10 14:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:57:11 --> Input Class Initialized
INFO - 2017-08-10 14:57:11 --> Language Class Initialized
INFO - 2017-08-10 14:57:11 --> Loader Class Initialized
INFO - 2017-08-10 14:57:11 --> Helper loaded: common_helper
INFO - 2017-08-10 14:57:11 --> Database Driver Class Initialized
INFO - 2017-08-10 14:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:57:11 --> Email Class Initialized
INFO - 2017-08-10 14:57:11 --> Controller Class Initialized
INFO - 2017-08-10 14:57:11 --> Helper loaded: form_helper
INFO - 2017-08-10 14:57:11 --> Form Validation Class Initialized
INFO - 2017-08-10 14:57:11 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:57:11 --> Helper loaded: url_helper
INFO - 2017-08-10 14:57:11 --> Model Class Initialized
INFO - 2017-08-10 14:57:11 --> Model Class Initialized
INFO - 2017-08-10 14:57:11 --> Model Class Initialized
INFO - 2017-08-10 18:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:27:11 --> Final output sent to browser
DEBUG - 2017-08-10 18:27:11 --> Total execution time: 0.0493
INFO - 2017-08-10 14:57:58 --> Config Class Initialized
INFO - 2017-08-10 14:57:58 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:57:58 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:57:58 --> Utf8 Class Initialized
INFO - 2017-08-10 14:57:58 --> URI Class Initialized
INFO - 2017-08-10 14:57:58 --> Router Class Initialized
INFO - 2017-08-10 14:57:58 --> Output Class Initialized
INFO - 2017-08-10 14:57:58 --> Security Class Initialized
DEBUG - 2017-08-10 14:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:57:58 --> Input Class Initialized
INFO - 2017-08-10 14:57:58 --> Language Class Initialized
INFO - 2017-08-10 14:57:58 --> Loader Class Initialized
INFO - 2017-08-10 14:57:58 --> Helper loaded: common_helper
INFO - 2017-08-10 14:57:58 --> Database Driver Class Initialized
INFO - 2017-08-10 14:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:57:58 --> Email Class Initialized
INFO - 2017-08-10 14:57:58 --> Controller Class Initialized
INFO - 2017-08-10 14:57:58 --> Helper loaded: form_helper
INFO - 2017-08-10 14:57:58 --> Form Validation Class Initialized
INFO - 2017-08-10 14:57:59 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:57:59 --> Helper loaded: url_helper
INFO - 2017-08-10 14:57:59 --> Model Class Initialized
INFO - 2017-08-10 14:57:59 --> Model Class Initialized
INFO - 2017-08-10 14:57:59 --> Model Class Initialized
INFO - 2017-08-10 18:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:27:59 --> Final output sent to browser
DEBUG - 2017-08-10 18:27:59 --> Total execution time: 0.0543
INFO - 2017-08-10 14:58:32 --> Config Class Initialized
INFO - 2017-08-10 14:58:32 --> Hooks Class Initialized
DEBUG - 2017-08-10 14:58:32 --> UTF-8 Support Enabled
INFO - 2017-08-10 14:58:32 --> Utf8 Class Initialized
INFO - 2017-08-10 14:58:32 --> URI Class Initialized
INFO - 2017-08-10 14:58:32 --> Router Class Initialized
INFO - 2017-08-10 14:58:32 --> Output Class Initialized
INFO - 2017-08-10 14:58:32 --> Security Class Initialized
DEBUG - 2017-08-10 14:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 14:58:32 --> Input Class Initialized
INFO - 2017-08-10 14:58:32 --> Language Class Initialized
INFO - 2017-08-10 14:58:32 --> Loader Class Initialized
INFO - 2017-08-10 14:58:32 --> Helper loaded: common_helper
INFO - 2017-08-10 14:58:32 --> Database Driver Class Initialized
INFO - 2017-08-10 14:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 14:58:32 --> Email Class Initialized
INFO - 2017-08-10 14:58:32 --> Controller Class Initialized
INFO - 2017-08-10 14:58:32 --> Helper loaded: form_helper
INFO - 2017-08-10 14:58:32 --> Form Validation Class Initialized
INFO - 2017-08-10 14:58:32 --> Helper loaded: email_helper
DEBUG - 2017-08-10 14:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 14:58:32 --> Helper loaded: url_helper
INFO - 2017-08-10 14:58:32 --> Model Class Initialized
INFO - 2017-08-10 14:58:32 --> Model Class Initialized
INFO - 2017-08-10 14:58:32 --> Model Class Initialized
INFO - 2017-08-10 18:28:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:28:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:28:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:28:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:28:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:28:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:28:32 --> Final output sent to browser
DEBUG - 2017-08-10 18:28:32 --> Total execution time: 0.0530
INFO - 2017-08-10 15:00:47 --> Config Class Initialized
INFO - 2017-08-10 15:00:47 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:00:47 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:00:47 --> Utf8 Class Initialized
INFO - 2017-08-10 15:00:47 --> URI Class Initialized
INFO - 2017-08-10 15:00:47 --> Router Class Initialized
INFO - 2017-08-10 15:00:47 --> Output Class Initialized
INFO - 2017-08-10 15:00:47 --> Security Class Initialized
DEBUG - 2017-08-10 15:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:00:47 --> Input Class Initialized
INFO - 2017-08-10 15:00:47 --> Language Class Initialized
INFO - 2017-08-10 15:00:47 --> Loader Class Initialized
INFO - 2017-08-10 15:00:47 --> Helper loaded: common_helper
INFO - 2017-08-10 15:00:47 --> Database Driver Class Initialized
INFO - 2017-08-10 15:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:00:47 --> Email Class Initialized
INFO - 2017-08-10 15:00:47 --> Controller Class Initialized
INFO - 2017-08-10 15:00:47 --> Helper loaded: form_helper
INFO - 2017-08-10 15:00:47 --> Form Validation Class Initialized
INFO - 2017-08-10 15:00:47 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:00:47 --> Helper loaded: url_helper
INFO - 2017-08-10 15:00:47 --> Model Class Initialized
INFO - 2017-08-10 15:00:47 --> Model Class Initialized
INFO - 2017-08-10 15:00:47 --> Model Class Initialized
INFO - 2017-08-10 18:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:30:47 --> Final output sent to browser
DEBUG - 2017-08-10 18:30:47 --> Total execution time: 0.0527
INFO - 2017-08-10 15:01:27 --> Config Class Initialized
INFO - 2017-08-10 15:01:27 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:01:27 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:01:27 --> Utf8 Class Initialized
INFO - 2017-08-10 15:01:27 --> URI Class Initialized
INFO - 2017-08-10 15:01:27 --> Router Class Initialized
INFO - 2017-08-10 15:01:27 --> Output Class Initialized
INFO - 2017-08-10 15:01:27 --> Security Class Initialized
DEBUG - 2017-08-10 15:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:01:27 --> Input Class Initialized
INFO - 2017-08-10 15:01:27 --> Language Class Initialized
INFO - 2017-08-10 15:01:27 --> Loader Class Initialized
INFO - 2017-08-10 15:01:27 --> Helper loaded: common_helper
INFO - 2017-08-10 15:01:27 --> Database Driver Class Initialized
INFO - 2017-08-10 15:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:01:27 --> Email Class Initialized
INFO - 2017-08-10 15:01:27 --> Controller Class Initialized
INFO - 2017-08-10 15:01:27 --> Helper loaded: form_helper
INFO - 2017-08-10 15:01:27 --> Form Validation Class Initialized
INFO - 2017-08-10 15:01:27 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:01:27 --> Helper loaded: url_helper
INFO - 2017-08-10 15:01:27 --> Model Class Initialized
INFO - 2017-08-10 15:01:27 --> Model Class Initialized
INFO - 2017-08-10 15:01:27 --> Model Class Initialized
INFO - 2017-08-10 18:31:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:31:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:31:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:31:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:31:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:31:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:31:27 --> Final output sent to browser
DEBUG - 2017-08-10 18:31:27 --> Total execution time: 0.0507
INFO - 2017-08-10 15:01:29 --> Config Class Initialized
INFO - 2017-08-10 15:01:29 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:01:29 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:01:29 --> Utf8 Class Initialized
INFO - 2017-08-10 15:01:29 --> URI Class Initialized
INFO - 2017-08-10 15:01:29 --> Router Class Initialized
INFO - 2017-08-10 15:01:29 --> Output Class Initialized
INFO - 2017-08-10 15:01:29 --> Security Class Initialized
DEBUG - 2017-08-10 15:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:01:29 --> Input Class Initialized
INFO - 2017-08-10 15:01:29 --> Language Class Initialized
INFO - 2017-08-10 15:01:29 --> Loader Class Initialized
INFO - 2017-08-10 15:01:29 --> Helper loaded: common_helper
INFO - 2017-08-10 15:01:29 --> Database Driver Class Initialized
INFO - 2017-08-10 15:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:01:29 --> Email Class Initialized
INFO - 2017-08-10 15:01:29 --> Controller Class Initialized
INFO - 2017-08-10 15:01:29 --> Helper loaded: form_helper
INFO - 2017-08-10 15:01:29 --> Form Validation Class Initialized
INFO - 2017-08-10 15:01:29 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:01:29 --> Helper loaded: url_helper
INFO - 2017-08-10 15:01:29 --> Model Class Initialized
INFO - 2017-08-10 15:01:29 --> Model Class Initialized
INFO - 2017-08-10 15:01:29 --> Model Class Initialized
INFO - 2017-08-10 18:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:31:29 --> Final output sent to browser
DEBUG - 2017-08-10 18:31:29 --> Total execution time: 0.0474
INFO - 2017-08-10 15:09:59 --> Config Class Initialized
INFO - 2017-08-10 15:09:59 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:09:59 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:09:59 --> Utf8 Class Initialized
INFO - 2017-08-10 15:09:59 --> URI Class Initialized
INFO - 2017-08-10 15:09:59 --> Router Class Initialized
INFO - 2017-08-10 15:09:59 --> Output Class Initialized
INFO - 2017-08-10 15:09:59 --> Security Class Initialized
DEBUG - 2017-08-10 15:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:09:59 --> Input Class Initialized
INFO - 2017-08-10 15:09:59 --> Language Class Initialized
INFO - 2017-08-10 15:09:59 --> Loader Class Initialized
INFO - 2017-08-10 15:09:59 --> Helper loaded: common_helper
INFO - 2017-08-10 15:09:59 --> Database Driver Class Initialized
INFO - 2017-08-10 15:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:10:00 --> Email Class Initialized
INFO - 2017-08-10 15:10:00 --> Controller Class Initialized
INFO - 2017-08-10 15:10:00 --> Helper loaded: form_helper
INFO - 2017-08-10 15:10:00 --> Form Validation Class Initialized
INFO - 2017-08-10 15:10:00 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:10:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:10:00 --> Helper loaded: url_helper
INFO - 2017-08-10 15:10:00 --> Model Class Initialized
INFO - 2017-08-10 15:10:00 --> Model Class Initialized
INFO - 2017-08-10 15:10:00 --> Model Class Initialized
INFO - 2017-08-10 18:40:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:40:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:40:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:40:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:40:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:40:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:40:00 --> Final output sent to browser
DEBUG - 2017-08-10 18:40:00 --> Total execution time: 0.0615
INFO - 2017-08-10 15:10:36 --> Config Class Initialized
INFO - 2017-08-10 15:10:36 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:10:36 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:10:36 --> Utf8 Class Initialized
INFO - 2017-08-10 15:10:36 --> URI Class Initialized
INFO - 2017-08-10 15:10:36 --> Router Class Initialized
INFO - 2017-08-10 15:10:36 --> Output Class Initialized
INFO - 2017-08-10 15:10:36 --> Security Class Initialized
DEBUG - 2017-08-10 15:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:10:36 --> Input Class Initialized
INFO - 2017-08-10 15:10:36 --> Language Class Initialized
INFO - 2017-08-10 15:10:36 --> Loader Class Initialized
INFO - 2017-08-10 15:10:36 --> Helper loaded: common_helper
INFO - 2017-08-10 15:10:36 --> Database Driver Class Initialized
INFO - 2017-08-10 15:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:10:36 --> Email Class Initialized
INFO - 2017-08-10 15:10:36 --> Controller Class Initialized
INFO - 2017-08-10 15:10:36 --> Helper loaded: form_helper
INFO - 2017-08-10 15:10:36 --> Form Validation Class Initialized
INFO - 2017-08-10 15:10:36 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:10:36 --> Helper loaded: url_helper
INFO - 2017-08-10 15:10:36 --> Model Class Initialized
INFO - 2017-08-10 15:10:36 --> Model Class Initialized
INFO - 2017-08-10 15:10:36 --> Model Class Initialized
DEBUG - 2017-08-10 18:40:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-10 18:40:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-10 18:40:36 --> Query error: Unknown column 'option1' in 'field list' - Invalid query: INSERT INTO `news_polls` (`npNewsId`, `option1`, `option2`) VALUES (48, '1', '2')
INFO - 2017-08-10 15:10:36 --> Config Class Initialized
INFO - 2017-08-10 15:10:36 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:10:36 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:10:36 --> Utf8 Class Initialized
INFO - 2017-08-10 15:10:36 --> URI Class Initialized
INFO - 2017-08-10 15:10:36 --> Router Class Initialized
INFO - 2017-08-10 15:10:36 --> Output Class Initialized
INFO - 2017-08-10 15:10:36 --> Security Class Initialized
DEBUG - 2017-08-10 15:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:10:36 --> Input Class Initialized
INFO - 2017-08-10 15:10:36 --> Language Class Initialized
INFO - 2017-08-10 15:10:36 --> Loader Class Initialized
INFO - 2017-08-10 15:10:36 --> Helper loaded: common_helper
INFO - 2017-08-10 15:10:36 --> Database Driver Class Initialized
INFO - 2017-08-10 15:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:10:36 --> Email Class Initialized
INFO - 2017-08-10 15:10:36 --> Controller Class Initialized
INFO - 2017-08-10 15:10:36 --> Helper loaded: form_helper
INFO - 2017-08-10 15:10:36 --> Form Validation Class Initialized
INFO - 2017-08-10 15:10:36 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:10:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:10:36 --> Helper loaded: url_helper
INFO - 2017-08-10 15:10:36 --> Model Class Initialized
INFO - 2017-08-10 15:10:36 --> Model Class Initialized
INFO - 2017-08-10 15:10:36 --> Model Class Initialized
INFO - 2017-08-10 18:40:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:40:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:40:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:40:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:40:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-10 18:40:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-10 18:40:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:40:36 --> Final output sent to browser
DEBUG - 2017-08-10 18:40:36 --> Total execution time: 0.1333
INFO - 2017-08-10 15:11:10 --> Config Class Initialized
INFO - 2017-08-10 15:11:10 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:11:10 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:11:10 --> Utf8 Class Initialized
INFO - 2017-08-10 15:11:10 --> URI Class Initialized
INFO - 2017-08-10 15:11:10 --> Router Class Initialized
INFO - 2017-08-10 15:11:10 --> Output Class Initialized
INFO - 2017-08-10 15:11:10 --> Security Class Initialized
DEBUG - 2017-08-10 15:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:11:10 --> Input Class Initialized
INFO - 2017-08-10 15:11:10 --> Language Class Initialized
INFO - 2017-08-10 15:11:10 --> Loader Class Initialized
INFO - 2017-08-10 15:11:10 --> Helper loaded: common_helper
INFO - 2017-08-10 15:11:10 --> Database Driver Class Initialized
INFO - 2017-08-10 15:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:11:10 --> Email Class Initialized
INFO - 2017-08-10 15:11:10 --> Controller Class Initialized
INFO - 2017-08-10 15:11:10 --> Helper loaded: form_helper
INFO - 2017-08-10 15:11:10 --> Form Validation Class Initialized
INFO - 2017-08-10 15:11:10 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:11:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:11:10 --> Helper loaded: url_helper
INFO - 2017-08-10 15:11:10 --> Model Class Initialized
INFO - 2017-08-10 15:11:10 --> Model Class Initialized
INFO - 2017-08-10 15:11:10 --> Model Class Initialized
INFO - 2017-08-10 18:41:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:41:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:41:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:41:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:41:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:41:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:41:10 --> Final output sent to browser
DEBUG - 2017-08-10 18:41:10 --> Total execution time: 0.0576
INFO - 2017-08-10 15:11:12 --> Config Class Initialized
INFO - 2017-08-10 15:11:12 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:11:12 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:11:12 --> Utf8 Class Initialized
INFO - 2017-08-10 15:11:12 --> URI Class Initialized
INFO - 2017-08-10 15:11:12 --> Router Class Initialized
INFO - 2017-08-10 15:11:12 --> Output Class Initialized
INFO - 2017-08-10 15:11:12 --> Security Class Initialized
DEBUG - 2017-08-10 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:11:12 --> Input Class Initialized
INFO - 2017-08-10 15:11:12 --> Language Class Initialized
INFO - 2017-08-10 15:11:12 --> Loader Class Initialized
INFO - 2017-08-10 15:11:12 --> Helper loaded: common_helper
INFO - 2017-08-10 15:11:12 --> Database Driver Class Initialized
INFO - 2017-08-10 15:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:11:12 --> Email Class Initialized
INFO - 2017-08-10 15:11:12 --> Controller Class Initialized
INFO - 2017-08-10 15:11:12 --> Helper loaded: form_helper
INFO - 2017-08-10 15:11:12 --> Form Validation Class Initialized
INFO - 2017-08-10 15:11:12 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:11:12 --> Helper loaded: url_helper
INFO - 2017-08-10 15:11:12 --> Model Class Initialized
INFO - 2017-08-10 15:11:12 --> Model Class Initialized
INFO - 2017-08-10 15:11:12 --> Model Class Initialized
DEBUG - 2017-08-10 18:41:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-10 18:41:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-10 15:11:12 --> Config Class Initialized
INFO - 2017-08-10 15:11:12 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:11:12 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:11:12 --> Utf8 Class Initialized
INFO - 2017-08-10 15:11:12 --> URI Class Initialized
INFO - 2017-08-10 15:11:12 --> Router Class Initialized
INFO - 2017-08-10 15:11:12 --> Output Class Initialized
INFO - 2017-08-10 15:11:12 --> Security Class Initialized
DEBUG - 2017-08-10 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:11:12 --> Input Class Initialized
INFO - 2017-08-10 15:11:12 --> Language Class Initialized
INFO - 2017-08-10 15:11:12 --> Loader Class Initialized
INFO - 2017-08-10 15:11:12 --> Helper loaded: common_helper
INFO - 2017-08-10 15:11:12 --> Database Driver Class Initialized
INFO - 2017-08-10 15:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:11:12 --> Email Class Initialized
INFO - 2017-08-10 15:11:12 --> Controller Class Initialized
INFO - 2017-08-10 15:11:12 --> Helper loaded: form_helper
INFO - 2017-08-10 15:11:12 --> Form Validation Class Initialized
INFO - 2017-08-10 15:11:12 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:11:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:11:12 --> Helper loaded: url_helper
INFO - 2017-08-10 15:11:12 --> Model Class Initialized
INFO - 2017-08-10 15:11:12 --> Model Class Initialized
INFO - 2017-08-10 15:11:12 --> Model Class Initialized
INFO - 2017-08-10 18:41:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:41:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:41:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:41:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:41:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:41:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:41:12 --> Final output sent to browser
DEBUG - 2017-08-10 18:41:12 --> Total execution time: 0.0481
INFO - 2017-08-10 15:11:24 --> Config Class Initialized
INFO - 2017-08-10 15:11:24 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:11:24 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:11:24 --> Utf8 Class Initialized
INFO - 2017-08-10 15:11:24 --> URI Class Initialized
INFO - 2017-08-10 15:11:24 --> Router Class Initialized
INFO - 2017-08-10 15:11:24 --> Output Class Initialized
INFO - 2017-08-10 15:11:24 --> Security Class Initialized
DEBUG - 2017-08-10 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:11:24 --> Input Class Initialized
INFO - 2017-08-10 15:11:24 --> Language Class Initialized
INFO - 2017-08-10 15:11:24 --> Loader Class Initialized
INFO - 2017-08-10 15:11:24 --> Helper loaded: common_helper
INFO - 2017-08-10 15:11:24 --> Database Driver Class Initialized
INFO - 2017-08-10 15:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:11:24 --> Email Class Initialized
INFO - 2017-08-10 15:11:24 --> Controller Class Initialized
INFO - 2017-08-10 15:11:24 --> Helper loaded: form_helper
INFO - 2017-08-10 15:11:24 --> Form Validation Class Initialized
INFO - 2017-08-10 15:11:24 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:11:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:11:24 --> Helper loaded: url_helper
INFO - 2017-08-10 15:11:24 --> Model Class Initialized
INFO - 2017-08-10 15:11:24 --> Model Class Initialized
INFO - 2017-08-10 15:11:24 --> Model Class Initialized
INFO - 2017-08-10 18:41:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:41:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:41:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:41:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:41:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:41:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:41:24 --> Final output sent to browser
DEBUG - 2017-08-10 18:41:24 --> Total execution time: 0.0541
INFO - 2017-08-10 15:12:09 --> Config Class Initialized
INFO - 2017-08-10 15:12:09 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:12:09 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:12:09 --> Utf8 Class Initialized
INFO - 2017-08-10 15:12:09 --> URI Class Initialized
INFO - 2017-08-10 15:12:09 --> Router Class Initialized
INFO - 2017-08-10 15:12:09 --> Output Class Initialized
INFO - 2017-08-10 15:12:09 --> Security Class Initialized
DEBUG - 2017-08-10 15:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:12:09 --> Input Class Initialized
INFO - 2017-08-10 15:12:09 --> Language Class Initialized
INFO - 2017-08-10 15:12:09 --> Loader Class Initialized
INFO - 2017-08-10 15:12:09 --> Helper loaded: common_helper
INFO - 2017-08-10 15:12:09 --> Database Driver Class Initialized
INFO - 2017-08-10 15:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:12:09 --> Email Class Initialized
INFO - 2017-08-10 15:12:09 --> Controller Class Initialized
INFO - 2017-08-10 15:12:09 --> Helper loaded: form_helper
INFO - 2017-08-10 15:12:09 --> Form Validation Class Initialized
INFO - 2017-08-10 15:12:09 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:12:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:12:09 --> Helper loaded: url_helper
INFO - 2017-08-10 15:12:09 --> Model Class Initialized
INFO - 2017-08-10 15:12:09 --> Model Class Initialized
INFO - 2017-08-10 15:12:09 --> Model Class Initialized
INFO - 2017-08-10 18:42:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:42:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:42:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:42:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-10 18:42:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:42:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:42:09 --> Final output sent to browser
DEBUG - 2017-08-10 18:42:09 --> Total execution time: 0.0862
INFO - 2017-08-10 15:12:41 --> Config Class Initialized
INFO - 2017-08-10 15:12:41 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:12:41 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:12:41 --> Utf8 Class Initialized
INFO - 2017-08-10 15:12:41 --> URI Class Initialized
INFO - 2017-08-10 15:12:41 --> Router Class Initialized
INFO - 2017-08-10 15:12:41 --> Output Class Initialized
INFO - 2017-08-10 15:12:41 --> Security Class Initialized
DEBUG - 2017-08-10 15:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:12:41 --> Input Class Initialized
INFO - 2017-08-10 15:12:41 --> Language Class Initialized
INFO - 2017-08-10 15:12:41 --> Loader Class Initialized
INFO - 2017-08-10 15:12:41 --> Helper loaded: common_helper
INFO - 2017-08-10 15:12:41 --> Database Driver Class Initialized
INFO - 2017-08-10 15:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:12:41 --> Email Class Initialized
INFO - 2017-08-10 15:12:41 --> Controller Class Initialized
INFO - 2017-08-10 15:12:41 --> Helper loaded: form_helper
INFO - 2017-08-10 15:12:41 --> Form Validation Class Initialized
INFO - 2017-08-10 15:12:41 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:12:41 --> Helper loaded: url_helper
INFO - 2017-08-10 15:12:41 --> Model Class Initialized
INFO - 2017-08-10 15:12:41 --> Model Class Initialized
INFO - 2017-08-10 15:12:41 --> Model Class Initialized
DEBUG - 2017-08-10 18:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-10 18:42:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-10 15:12:42 --> Config Class Initialized
INFO - 2017-08-10 15:12:42 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:12:42 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:12:42 --> Utf8 Class Initialized
INFO - 2017-08-10 15:12:42 --> URI Class Initialized
INFO - 2017-08-10 15:12:42 --> Router Class Initialized
INFO - 2017-08-10 15:12:42 --> Output Class Initialized
INFO - 2017-08-10 15:12:42 --> Security Class Initialized
DEBUG - 2017-08-10 15:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:12:42 --> Input Class Initialized
INFO - 2017-08-10 15:12:42 --> Language Class Initialized
INFO - 2017-08-10 15:12:42 --> Loader Class Initialized
INFO - 2017-08-10 15:12:42 --> Helper loaded: common_helper
INFO - 2017-08-10 15:12:42 --> Database Driver Class Initialized
INFO - 2017-08-10 15:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:12:42 --> Email Class Initialized
INFO - 2017-08-10 15:12:42 --> Controller Class Initialized
INFO - 2017-08-10 15:12:42 --> Helper loaded: form_helper
INFO - 2017-08-10 15:12:42 --> Form Validation Class Initialized
INFO - 2017-08-10 15:12:42 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:12:42 --> Helper loaded: url_helper
INFO - 2017-08-10 15:12:42 --> Model Class Initialized
INFO - 2017-08-10 15:12:42 --> Model Class Initialized
INFO - 2017-08-10 15:12:42 --> Model Class Initialized
INFO - 2017-08-10 18:42:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:42:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:42:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-10 18:42:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-10 18:42:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-10 18:42:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-10 18:42:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:42:42 --> Final output sent to browser
DEBUG - 2017-08-10 18:42:42 --> Total execution time: 0.1731
INFO - 2017-08-10 15:13:13 --> Config Class Initialized
INFO - 2017-08-10 15:13:13 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:13:13 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:13:13 --> Utf8 Class Initialized
INFO - 2017-08-10 15:13:13 --> URI Class Initialized
INFO - 2017-08-10 15:13:13 --> Router Class Initialized
INFO - 2017-08-10 15:13:13 --> Output Class Initialized
INFO - 2017-08-10 15:13:13 --> Security Class Initialized
DEBUG - 2017-08-10 15:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:13:13 --> Input Class Initialized
INFO - 2017-08-10 15:13:13 --> Language Class Initialized
INFO - 2017-08-10 15:13:13 --> Loader Class Initialized
INFO - 2017-08-10 15:13:13 --> Helper loaded: common_helper
INFO - 2017-08-10 15:13:13 --> Database Driver Class Initialized
INFO - 2017-08-10 15:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:13:13 --> Email Class Initialized
INFO - 2017-08-10 15:13:13 --> Controller Class Initialized
INFO - 2017-08-10 15:13:13 --> Helper loaded: form_helper
INFO - 2017-08-10 15:13:13 --> Form Validation Class Initialized
INFO - 2017-08-10 15:13:13 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:13:13 --> Helper loaded: url_helper
INFO - 2017-08-10 15:13:13 --> Model Class Initialized
INFO - 2017-08-10 15:13:13 --> Model Class Initialized
INFO - 2017-08-10 15:13:13 --> Model Class Initialized
INFO - 2017-08-10 18:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 18:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 18:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 18:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 18:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 18:43:13 --> Final output sent to browser
DEBUG - 2017-08-10 18:43:13 --> Total execution time: 0.0657
INFO - 2017-08-10 15:24:59 --> Config Class Initialized
INFO - 2017-08-10 15:24:59 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:24:59 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:24:59 --> Utf8 Class Initialized
INFO - 2017-08-10 15:24:59 --> URI Class Initialized
INFO - 2017-08-10 15:24:59 --> Router Class Initialized
INFO - 2017-08-10 15:24:59 --> Output Class Initialized
INFO - 2017-08-10 15:24:59 --> Security Class Initialized
DEBUG - 2017-08-10 15:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:24:59 --> Input Class Initialized
INFO - 2017-08-10 15:24:59 --> Language Class Initialized
INFO - 2017-08-10 15:24:59 --> Loader Class Initialized
INFO - 2017-08-10 15:24:59 --> Helper loaded: common_helper
INFO - 2017-08-10 15:24:59 --> Database Driver Class Initialized
INFO - 2017-08-10 15:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:24:59 --> Email Class Initialized
INFO - 2017-08-10 15:24:59 --> Controller Class Initialized
INFO - 2017-08-10 15:24:59 --> Helper loaded: form_helper
INFO - 2017-08-10 15:24:59 --> Form Validation Class Initialized
INFO - 2017-08-10 15:24:59 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:24:59 --> Helper loaded: url_helper
INFO - 2017-08-10 15:24:59 --> Model Class Initialized
INFO - 2017-08-10 15:24:59 --> Model Class Initialized
INFO - 2017-08-10 15:24:59 --> Model Class Initialized
INFO - 2017-08-10 15:26:04 --> Config Class Initialized
INFO - 2017-08-10 15:26:04 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:26:04 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:26:04 --> Utf8 Class Initialized
INFO - 2017-08-10 15:26:04 --> URI Class Initialized
INFO - 2017-08-10 15:26:04 --> Router Class Initialized
INFO - 2017-08-10 15:26:04 --> Output Class Initialized
INFO - 2017-08-10 15:26:04 --> Security Class Initialized
DEBUG - 2017-08-10 15:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:26:04 --> Input Class Initialized
INFO - 2017-08-10 15:26:04 --> Language Class Initialized
INFO - 2017-08-10 15:26:04 --> Loader Class Initialized
INFO - 2017-08-10 15:26:04 --> Helper loaded: common_helper
INFO - 2017-08-10 15:26:04 --> Database Driver Class Initialized
INFO - 2017-08-10 15:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:26:04 --> Email Class Initialized
INFO - 2017-08-10 15:26:04 --> Controller Class Initialized
INFO - 2017-08-10 15:26:04 --> Helper loaded: form_helper
INFO - 2017-08-10 15:26:04 --> Form Validation Class Initialized
INFO - 2017-08-10 15:26:04 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:26:04 --> Helper loaded: url_helper
INFO - 2017-08-10 15:26:04 --> Model Class Initialized
INFO - 2017-08-10 15:26:04 --> Model Class Initialized
INFO - 2017-08-10 15:26:04 --> Model Class Initialized
ERROR - 2017-08-10 18:56:04 --> Creating default object from empty value
ERROR - 2017-08-10 18:56:04 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 81
INFO - 2017-08-10 15:26:21 --> Config Class Initialized
INFO - 2017-08-10 15:26:21 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:26:21 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:26:21 --> Utf8 Class Initialized
INFO - 2017-08-10 15:26:21 --> URI Class Initialized
INFO - 2017-08-10 15:26:21 --> Router Class Initialized
INFO - 2017-08-10 15:26:21 --> Output Class Initialized
INFO - 2017-08-10 15:26:21 --> Security Class Initialized
DEBUG - 2017-08-10 15:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:26:21 --> Input Class Initialized
INFO - 2017-08-10 15:26:21 --> Language Class Initialized
INFO - 2017-08-10 15:26:21 --> Loader Class Initialized
INFO - 2017-08-10 15:26:21 --> Helper loaded: common_helper
INFO - 2017-08-10 15:26:21 --> Database Driver Class Initialized
INFO - 2017-08-10 15:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:26:21 --> Email Class Initialized
INFO - 2017-08-10 15:26:21 --> Controller Class Initialized
INFO - 2017-08-10 15:26:21 --> Helper loaded: form_helper
INFO - 2017-08-10 15:26:21 --> Form Validation Class Initialized
INFO - 2017-08-10 15:26:21 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:26:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:26:21 --> Helper loaded: url_helper
INFO - 2017-08-10 15:26:21 --> Model Class Initialized
INFO - 2017-08-10 15:26:21 --> Model Class Initialized
INFO - 2017-08-10 15:26:21 --> Model Class Initialized
INFO - 2017-08-10 15:27:15 --> Config Class Initialized
INFO - 2017-08-10 15:27:15 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:27:15 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:27:15 --> Utf8 Class Initialized
INFO - 2017-08-10 15:27:15 --> URI Class Initialized
INFO - 2017-08-10 15:27:15 --> Router Class Initialized
INFO - 2017-08-10 15:27:15 --> Output Class Initialized
INFO - 2017-08-10 15:27:15 --> Security Class Initialized
DEBUG - 2017-08-10 15:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:27:15 --> Input Class Initialized
INFO - 2017-08-10 15:27:15 --> Language Class Initialized
INFO - 2017-08-10 15:27:15 --> Loader Class Initialized
INFO - 2017-08-10 15:27:15 --> Helper loaded: common_helper
INFO - 2017-08-10 15:27:15 --> Database Driver Class Initialized
INFO - 2017-08-10 15:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:27:15 --> Email Class Initialized
INFO - 2017-08-10 15:27:15 --> Controller Class Initialized
INFO - 2017-08-10 15:27:15 --> Helper loaded: form_helper
INFO - 2017-08-10 15:27:15 --> Form Validation Class Initialized
INFO - 2017-08-10 15:27:15 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:27:15 --> Helper loaded: url_helper
INFO - 2017-08-10 15:27:15 --> Model Class Initialized
INFO - 2017-08-10 15:27:15 --> Model Class Initialized
INFO - 2017-08-10 15:27:15 --> Model Class Initialized
INFO - 2017-08-10 15:40:08 --> Config Class Initialized
INFO - 2017-08-10 15:40:08 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:40:08 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:40:08 --> Utf8 Class Initialized
INFO - 2017-08-10 15:40:08 --> URI Class Initialized
INFO - 2017-08-10 15:40:08 --> Router Class Initialized
INFO - 2017-08-10 15:40:08 --> Output Class Initialized
INFO - 2017-08-10 15:40:08 --> Security Class Initialized
DEBUG - 2017-08-10 15:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:40:08 --> Input Class Initialized
INFO - 2017-08-10 15:40:08 --> Language Class Initialized
INFO - 2017-08-10 15:40:08 --> Loader Class Initialized
INFO - 2017-08-10 15:40:08 --> Helper loaded: common_helper
INFO - 2017-08-10 15:40:08 --> Database Driver Class Initialized
INFO - 2017-08-10 15:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:40:08 --> Email Class Initialized
INFO - 2017-08-10 15:40:08 --> Controller Class Initialized
INFO - 2017-08-10 15:40:08 --> Helper loaded: form_helper
INFO - 2017-08-10 15:40:08 --> Form Validation Class Initialized
INFO - 2017-08-10 15:40:08 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:40:08 --> Helper loaded: url_helper
INFO - 2017-08-10 15:40:08 --> Model Class Initialized
INFO - 2017-08-10 15:40:08 --> Model Class Initialized
INFO - 2017-08-10 15:40:08 --> Model Class Initialized
INFO - 2017-08-10 15:40:17 --> Config Class Initialized
INFO - 2017-08-10 15:40:17 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:40:17 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:40:17 --> Utf8 Class Initialized
INFO - 2017-08-10 15:40:17 --> URI Class Initialized
INFO - 2017-08-10 15:40:17 --> Router Class Initialized
INFO - 2017-08-10 15:40:17 --> Output Class Initialized
INFO - 2017-08-10 15:40:17 --> Security Class Initialized
DEBUG - 2017-08-10 15:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:40:17 --> Input Class Initialized
INFO - 2017-08-10 15:40:17 --> Language Class Initialized
INFO - 2017-08-10 15:40:17 --> Loader Class Initialized
INFO - 2017-08-10 15:40:17 --> Helper loaded: common_helper
INFO - 2017-08-10 15:40:17 --> Database Driver Class Initialized
INFO - 2017-08-10 15:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:40:17 --> Email Class Initialized
INFO - 2017-08-10 15:40:17 --> Controller Class Initialized
INFO - 2017-08-10 15:40:17 --> Helper loaded: form_helper
INFO - 2017-08-10 15:40:17 --> Form Validation Class Initialized
INFO - 2017-08-10 15:40:17 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:40:17 --> Helper loaded: url_helper
INFO - 2017-08-10 15:40:17 --> Model Class Initialized
INFO - 2017-08-10 15:40:17 --> Model Class Initialized
INFO - 2017-08-10 15:40:17 --> Model Class Initialized
INFO - 2017-08-10 19:10:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:10:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:10:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:10:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:10:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:10:17 --> Final output sent to browser
DEBUG - 2017-08-10 19:10:17 --> Total execution time: 0.0546
INFO - 2017-08-10 15:40:34 --> Config Class Initialized
INFO - 2017-08-10 15:40:34 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:40:34 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:40:34 --> Utf8 Class Initialized
INFO - 2017-08-10 15:40:34 --> URI Class Initialized
INFO - 2017-08-10 15:40:34 --> Router Class Initialized
INFO - 2017-08-10 15:40:34 --> Output Class Initialized
INFO - 2017-08-10 15:40:34 --> Security Class Initialized
DEBUG - 2017-08-10 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:40:34 --> Input Class Initialized
INFO - 2017-08-10 15:40:34 --> Language Class Initialized
INFO - 2017-08-10 15:40:34 --> Loader Class Initialized
INFO - 2017-08-10 15:40:34 --> Helper loaded: common_helper
INFO - 2017-08-10 15:40:34 --> Database Driver Class Initialized
INFO - 2017-08-10 15:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:40:34 --> Email Class Initialized
INFO - 2017-08-10 15:40:34 --> Controller Class Initialized
INFO - 2017-08-10 15:40:34 --> Helper loaded: form_helper
INFO - 2017-08-10 15:40:34 --> Form Validation Class Initialized
INFO - 2017-08-10 15:40:34 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:40:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:40:34 --> Helper loaded: url_helper
INFO - 2017-08-10 15:40:34 --> Model Class Initialized
INFO - 2017-08-10 15:40:34 --> Model Class Initialized
INFO - 2017-08-10 15:40:34 --> Model Class Initialized
INFO - 2017-08-10 19:10:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:10:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 19:10:34 --> Undefined variable: pollDetails
ERROR - 2017-08-10 19:10:34 --> Severity: Notice --> Undefined variable: pollDetails C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 123
ERROR - 2017-08-10 19:10:34 --> Trying to get property of non-object
ERROR - 2017-08-10 19:10:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 123
ERROR - 2017-08-10 19:10:34 --> Undefined variable: pollDetails
ERROR - 2017-08-10 19:10:34 --> Severity: Notice --> Undefined variable: pollDetails C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 124
ERROR - 2017-08-10 19:10:34 --> Trying to get property of non-object
ERROR - 2017-08-10 19:10:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 124
ERROR - 2017-08-10 19:10:34 --> Undefined variable: pollDetails
ERROR - 2017-08-10 19:10:34 --> Severity: Notice --> Undefined variable: pollDetails C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 125
ERROR - 2017-08-10 19:10:34 --> Trying to get property of non-object
ERROR - 2017-08-10 19:10:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 125
INFO - 2017-08-10 19:10:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:10:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:10:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:10:34 --> Final output sent to browser
DEBUG - 2017-08-10 19:10:34 --> Total execution time: 0.0675
INFO - 2017-08-10 15:41:06 --> Config Class Initialized
INFO - 2017-08-10 15:41:06 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:41:06 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:41:06 --> Utf8 Class Initialized
INFO - 2017-08-10 15:41:06 --> URI Class Initialized
INFO - 2017-08-10 15:41:06 --> Router Class Initialized
INFO - 2017-08-10 15:41:06 --> Output Class Initialized
INFO - 2017-08-10 15:41:06 --> Security Class Initialized
DEBUG - 2017-08-10 15:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:41:06 --> Input Class Initialized
INFO - 2017-08-10 15:41:06 --> Language Class Initialized
INFO - 2017-08-10 15:41:06 --> Loader Class Initialized
INFO - 2017-08-10 15:41:06 --> Helper loaded: common_helper
INFO - 2017-08-10 15:41:06 --> Database Driver Class Initialized
INFO - 2017-08-10 15:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:41:06 --> Email Class Initialized
INFO - 2017-08-10 15:41:06 --> Controller Class Initialized
INFO - 2017-08-10 15:41:06 --> Helper loaded: form_helper
INFO - 2017-08-10 15:41:06 --> Form Validation Class Initialized
INFO - 2017-08-10 15:41:06 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:41:06 --> Helper loaded: url_helper
INFO - 2017-08-10 15:41:06 --> Model Class Initialized
INFO - 2017-08-10 15:41:06 --> Model Class Initialized
INFO - 2017-08-10 15:41:06 --> Model Class Initialized
INFO - 2017-08-10 19:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-10 19:11:06 --> Undefined variable: i
ERROR - 2017-08-10 19:11:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 146
ERROR - 2017-08-10 19:11:06 --> Undefined variable: i
ERROR - 2017-08-10 19:11:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 146
INFO - 2017-08-10 19:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:11:06 --> Final output sent to browser
DEBUG - 2017-08-10 19:11:06 --> Total execution time: 0.0607
INFO - 2017-08-10 15:41:21 --> Config Class Initialized
INFO - 2017-08-10 15:41:21 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:41:21 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:41:21 --> Utf8 Class Initialized
INFO - 2017-08-10 15:41:21 --> URI Class Initialized
INFO - 2017-08-10 15:41:21 --> Router Class Initialized
INFO - 2017-08-10 15:41:21 --> Output Class Initialized
INFO - 2017-08-10 15:41:21 --> Security Class Initialized
DEBUG - 2017-08-10 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:41:21 --> Input Class Initialized
INFO - 2017-08-10 15:41:21 --> Language Class Initialized
INFO - 2017-08-10 15:41:21 --> Loader Class Initialized
INFO - 2017-08-10 15:41:21 --> Helper loaded: common_helper
INFO - 2017-08-10 15:41:21 --> Database Driver Class Initialized
INFO - 2017-08-10 15:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:41:21 --> Email Class Initialized
INFO - 2017-08-10 15:41:21 --> Controller Class Initialized
INFO - 2017-08-10 15:41:21 --> Helper loaded: form_helper
INFO - 2017-08-10 15:41:21 --> Form Validation Class Initialized
INFO - 2017-08-10 15:41:21 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:41:21 --> Helper loaded: url_helper
INFO - 2017-08-10 15:41:21 --> Model Class Initialized
INFO - 2017-08-10 15:41:21 --> Model Class Initialized
INFO - 2017-08-10 15:41:21 --> Model Class Initialized
INFO - 2017-08-10 19:11:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:11:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:11:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:11:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:11:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:11:21 --> Final output sent to browser
DEBUG - 2017-08-10 19:11:21 --> Total execution time: 0.0581
INFO - 2017-08-10 15:43:47 --> Config Class Initialized
INFO - 2017-08-10 15:43:47 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:43:47 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:43:47 --> Utf8 Class Initialized
INFO - 2017-08-10 15:43:47 --> URI Class Initialized
INFO - 2017-08-10 15:43:47 --> Router Class Initialized
INFO - 2017-08-10 15:43:47 --> Output Class Initialized
INFO - 2017-08-10 15:43:47 --> Security Class Initialized
DEBUG - 2017-08-10 15:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:43:47 --> Input Class Initialized
INFO - 2017-08-10 15:43:47 --> Language Class Initialized
INFO - 2017-08-10 15:43:47 --> Loader Class Initialized
INFO - 2017-08-10 15:43:47 --> Helper loaded: common_helper
INFO - 2017-08-10 15:43:47 --> Database Driver Class Initialized
INFO - 2017-08-10 15:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:43:47 --> Email Class Initialized
INFO - 2017-08-10 15:43:47 --> Controller Class Initialized
INFO - 2017-08-10 15:43:47 --> Helper loaded: form_helper
INFO - 2017-08-10 15:43:47 --> Form Validation Class Initialized
INFO - 2017-08-10 15:43:47 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:43:47 --> Helper loaded: url_helper
INFO - 2017-08-10 15:43:47 --> Model Class Initialized
INFO - 2017-08-10 15:43:47 --> Model Class Initialized
INFO - 2017-08-10 15:43:47 --> Model Class Initialized
INFO - 2017-08-10 19:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:13:47 --> Final output sent to browser
DEBUG - 2017-08-10 19:13:47 --> Total execution time: 0.0551
INFO - 2017-08-10 15:44:00 --> Config Class Initialized
INFO - 2017-08-10 15:44:00 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:44:00 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:44:00 --> Utf8 Class Initialized
INFO - 2017-08-10 15:44:00 --> URI Class Initialized
INFO - 2017-08-10 15:44:00 --> Router Class Initialized
INFO - 2017-08-10 15:44:00 --> Output Class Initialized
INFO - 2017-08-10 15:44:00 --> Security Class Initialized
DEBUG - 2017-08-10 15:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:44:00 --> Input Class Initialized
INFO - 2017-08-10 15:44:00 --> Language Class Initialized
INFO - 2017-08-10 15:44:00 --> Loader Class Initialized
INFO - 2017-08-10 15:44:00 --> Helper loaded: common_helper
INFO - 2017-08-10 15:44:00 --> Database Driver Class Initialized
INFO - 2017-08-10 15:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:44:00 --> Email Class Initialized
INFO - 2017-08-10 15:44:00 --> Controller Class Initialized
INFO - 2017-08-10 15:44:00 --> Helper loaded: form_helper
INFO - 2017-08-10 15:44:00 --> Form Validation Class Initialized
INFO - 2017-08-10 15:44:00 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:44:00 --> Helper loaded: url_helper
INFO - 2017-08-10 15:44:00 --> Model Class Initialized
INFO - 2017-08-10 15:44:00 --> Model Class Initialized
INFO - 2017-08-10 15:44:00 --> Model Class Initialized
INFO - 2017-08-10 19:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:14:00 --> Final output sent to browser
DEBUG - 2017-08-10 19:14:00 --> Total execution time: 0.0565
INFO - 2017-08-10 15:44:38 --> Config Class Initialized
INFO - 2017-08-10 15:44:38 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:44:38 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:44:38 --> Utf8 Class Initialized
INFO - 2017-08-10 15:44:38 --> URI Class Initialized
INFO - 2017-08-10 15:44:38 --> Router Class Initialized
INFO - 2017-08-10 15:44:38 --> Output Class Initialized
INFO - 2017-08-10 15:44:38 --> Security Class Initialized
DEBUG - 2017-08-10 15:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:44:38 --> Input Class Initialized
INFO - 2017-08-10 15:44:38 --> Language Class Initialized
INFO - 2017-08-10 15:44:38 --> Loader Class Initialized
INFO - 2017-08-10 15:44:38 --> Helper loaded: common_helper
INFO - 2017-08-10 15:44:38 --> Database Driver Class Initialized
INFO - 2017-08-10 15:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:44:38 --> Email Class Initialized
INFO - 2017-08-10 15:44:38 --> Controller Class Initialized
INFO - 2017-08-10 15:44:38 --> Helper loaded: form_helper
INFO - 2017-08-10 15:44:38 --> Form Validation Class Initialized
INFO - 2017-08-10 15:44:38 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:44:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:44:38 --> Helper loaded: url_helper
INFO - 2017-08-10 15:44:38 --> Model Class Initialized
INFO - 2017-08-10 15:44:38 --> Model Class Initialized
INFO - 2017-08-10 15:44:38 --> Model Class Initialized
INFO - 2017-08-10 19:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:14:38 --> Final output sent to browser
DEBUG - 2017-08-10 19:14:38 --> Total execution time: 0.0584
INFO - 2017-08-10 15:45:36 --> Config Class Initialized
INFO - 2017-08-10 15:45:36 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:45:36 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:45:36 --> Utf8 Class Initialized
INFO - 2017-08-10 15:45:36 --> URI Class Initialized
INFO - 2017-08-10 15:45:36 --> Router Class Initialized
INFO - 2017-08-10 15:45:36 --> Output Class Initialized
INFO - 2017-08-10 15:45:36 --> Security Class Initialized
DEBUG - 2017-08-10 15:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:45:36 --> Input Class Initialized
INFO - 2017-08-10 15:45:36 --> Language Class Initialized
INFO - 2017-08-10 15:45:36 --> Loader Class Initialized
INFO - 2017-08-10 15:45:36 --> Helper loaded: common_helper
INFO - 2017-08-10 15:45:36 --> Database Driver Class Initialized
INFO - 2017-08-10 15:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:45:36 --> Email Class Initialized
INFO - 2017-08-10 15:45:36 --> Controller Class Initialized
INFO - 2017-08-10 15:45:36 --> Helper loaded: form_helper
INFO - 2017-08-10 15:45:36 --> Form Validation Class Initialized
INFO - 2017-08-10 15:45:36 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:45:36 --> Helper loaded: url_helper
INFO - 2017-08-10 15:45:36 --> Model Class Initialized
INFO - 2017-08-10 15:45:36 --> Model Class Initialized
INFO - 2017-08-10 15:45:36 --> Model Class Initialized
INFO - 2017-08-10 19:15:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:15:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:15:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:15:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:15:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:15:36 --> Final output sent to browser
DEBUG - 2017-08-10 19:15:36 --> Total execution time: 0.0581
INFO - 2017-08-10 15:45:49 --> Config Class Initialized
INFO - 2017-08-10 15:45:49 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:45:49 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:45:49 --> Utf8 Class Initialized
INFO - 2017-08-10 15:45:49 --> URI Class Initialized
INFO - 2017-08-10 15:45:49 --> Router Class Initialized
INFO - 2017-08-10 15:45:49 --> Output Class Initialized
INFO - 2017-08-10 15:45:49 --> Security Class Initialized
DEBUG - 2017-08-10 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:45:49 --> Input Class Initialized
INFO - 2017-08-10 15:45:49 --> Language Class Initialized
INFO - 2017-08-10 15:45:49 --> Loader Class Initialized
INFO - 2017-08-10 15:45:49 --> Helper loaded: common_helper
INFO - 2017-08-10 15:45:49 --> Database Driver Class Initialized
INFO - 2017-08-10 15:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:45:49 --> Email Class Initialized
INFO - 2017-08-10 15:45:49 --> Controller Class Initialized
INFO - 2017-08-10 15:45:49 --> Helper loaded: form_helper
INFO - 2017-08-10 15:45:49 --> Form Validation Class Initialized
INFO - 2017-08-10 15:45:49 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:45:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:45:49 --> Helper loaded: url_helper
INFO - 2017-08-10 15:45:49 --> Model Class Initialized
INFO - 2017-08-10 15:45:49 --> Model Class Initialized
INFO - 2017-08-10 15:45:49 --> Model Class Initialized
INFO - 2017-08-10 19:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:15:49 --> Final output sent to browser
DEBUG - 2017-08-10 19:15:49 --> Total execution time: 0.0596
INFO - 2017-08-10 15:47:23 --> Config Class Initialized
INFO - 2017-08-10 15:47:23 --> Hooks Class Initialized
DEBUG - 2017-08-10 15:47:23 --> UTF-8 Support Enabled
INFO - 2017-08-10 15:47:23 --> Utf8 Class Initialized
INFO - 2017-08-10 15:47:23 --> URI Class Initialized
INFO - 2017-08-10 15:47:23 --> Router Class Initialized
INFO - 2017-08-10 15:47:23 --> Output Class Initialized
INFO - 2017-08-10 15:47:23 --> Security Class Initialized
DEBUG - 2017-08-10 15:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 15:47:23 --> Input Class Initialized
INFO - 2017-08-10 15:47:23 --> Language Class Initialized
INFO - 2017-08-10 15:47:23 --> Loader Class Initialized
INFO - 2017-08-10 15:47:23 --> Helper loaded: common_helper
INFO - 2017-08-10 15:47:23 --> Database Driver Class Initialized
INFO - 2017-08-10 15:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 15:47:23 --> Email Class Initialized
INFO - 2017-08-10 15:47:23 --> Controller Class Initialized
INFO - 2017-08-10 15:47:23 --> Helper loaded: form_helper
INFO - 2017-08-10 15:47:23 --> Form Validation Class Initialized
INFO - 2017-08-10 15:47:23 --> Helper loaded: email_helper
DEBUG - 2017-08-10 15:47:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 15:47:23 --> Helper loaded: url_helper
INFO - 2017-08-10 15:47:23 --> Model Class Initialized
INFO - 2017-08-10 15:47:23 --> Model Class Initialized
INFO - 2017-08-10 15:47:23 --> Model Class Initialized
INFO - 2017-08-10 19:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:17:23 --> Final output sent to browser
DEBUG - 2017-08-10 19:17:23 --> Total execution time: 0.0692
INFO - 2017-08-10 16:00:15 --> Config Class Initialized
INFO - 2017-08-10 16:00:15 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:00:15 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:00:15 --> Utf8 Class Initialized
INFO - 2017-08-10 16:00:15 --> URI Class Initialized
INFO - 2017-08-10 16:00:15 --> Router Class Initialized
INFO - 2017-08-10 16:00:15 --> Output Class Initialized
INFO - 2017-08-10 16:00:15 --> Security Class Initialized
DEBUG - 2017-08-10 16:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:00:15 --> Input Class Initialized
INFO - 2017-08-10 16:00:15 --> Language Class Initialized
INFO - 2017-08-10 16:00:15 --> Loader Class Initialized
INFO - 2017-08-10 16:00:15 --> Helper loaded: common_helper
INFO - 2017-08-10 16:00:15 --> Database Driver Class Initialized
INFO - 2017-08-10 16:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:00:15 --> Email Class Initialized
INFO - 2017-08-10 16:00:15 --> Controller Class Initialized
INFO - 2017-08-10 16:00:15 --> Helper loaded: form_helper
INFO - 2017-08-10 16:00:15 --> Form Validation Class Initialized
INFO - 2017-08-10 16:00:15 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:00:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:00:15 --> Helper loaded: url_helper
INFO - 2017-08-10 16:00:15 --> Model Class Initialized
INFO - 2017-08-10 16:00:15 --> Model Class Initialized
INFO - 2017-08-10 16:00:15 --> Model Class Initialized
INFO - 2017-08-10 19:30:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:30:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:30:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:30:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:30:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:30:15 --> Final output sent to browser
DEBUG - 2017-08-10 19:30:15 --> Total execution time: 0.0589
INFO - 2017-08-10 16:00:25 --> Config Class Initialized
INFO - 2017-08-10 16:00:25 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:00:25 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:00:25 --> Utf8 Class Initialized
INFO - 2017-08-10 16:00:25 --> URI Class Initialized
INFO - 2017-08-10 16:00:25 --> Router Class Initialized
INFO - 2017-08-10 16:00:25 --> Output Class Initialized
INFO - 2017-08-10 16:00:25 --> Security Class Initialized
DEBUG - 2017-08-10 16:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:00:25 --> Input Class Initialized
INFO - 2017-08-10 16:00:25 --> Language Class Initialized
INFO - 2017-08-10 16:00:25 --> Loader Class Initialized
INFO - 2017-08-10 16:00:25 --> Helper loaded: common_helper
INFO - 2017-08-10 16:00:25 --> Database Driver Class Initialized
INFO - 2017-08-10 16:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:00:25 --> Email Class Initialized
INFO - 2017-08-10 16:00:25 --> Controller Class Initialized
INFO - 2017-08-10 16:00:25 --> Helper loaded: form_helper
INFO - 2017-08-10 16:00:25 --> Form Validation Class Initialized
INFO - 2017-08-10 16:00:25 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:00:25 --> Helper loaded: url_helper
INFO - 2017-08-10 16:00:25 --> Model Class Initialized
INFO - 2017-08-10 16:00:25 --> Model Class Initialized
INFO - 2017-08-10 16:00:25 --> Model Class Initialized
ERROR - 2017-08-10 19:30:25 --> Query error: Unknown column 'news_id' in 'where clause' - Invalid query: UPDATE `news_polls_images` SET `image` = '318241502373625.png', `updatedAt` = '17-08-10 07:30:25'
WHERE `news_id` = '49'
INFO - 2017-08-10 16:00:25 --> Config Class Initialized
INFO - 2017-08-10 16:00:25 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:00:25 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:00:25 --> Utf8 Class Initialized
INFO - 2017-08-10 16:00:25 --> URI Class Initialized
INFO - 2017-08-10 16:00:25 --> Router Class Initialized
INFO - 2017-08-10 16:00:25 --> Output Class Initialized
INFO - 2017-08-10 16:00:25 --> Security Class Initialized
DEBUG - 2017-08-10 16:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:00:25 --> Input Class Initialized
INFO - 2017-08-10 16:00:25 --> Language Class Initialized
INFO - 2017-08-10 16:00:25 --> Loader Class Initialized
INFO - 2017-08-10 16:00:25 --> Helper loaded: common_helper
INFO - 2017-08-10 16:00:25 --> Database Driver Class Initialized
INFO - 2017-08-10 16:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:00:25 --> Email Class Initialized
INFO - 2017-08-10 16:00:25 --> Controller Class Initialized
INFO - 2017-08-10 16:00:25 --> Helper loaded: form_helper
INFO - 2017-08-10 16:00:25 --> Form Validation Class Initialized
INFO - 2017-08-10 16:00:25 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:00:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:00:25 --> Helper loaded: url_helper
INFO - 2017-08-10 16:00:25 --> Model Class Initialized
INFO - 2017-08-10 16:00:25 --> Model Class Initialized
INFO - 2017-08-10 16:00:25 --> Model Class Initialized
INFO - 2017-08-10 19:30:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:30:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:30:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:30:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:30:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:30:25 --> Final output sent to browser
DEBUG - 2017-08-10 19:30:25 --> Total execution time: 0.0465
INFO - 2017-08-10 16:00:31 --> Config Class Initialized
INFO - 2017-08-10 16:00:31 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:00:31 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:00:31 --> Utf8 Class Initialized
INFO - 2017-08-10 16:00:31 --> URI Class Initialized
INFO - 2017-08-10 16:00:31 --> Router Class Initialized
INFO - 2017-08-10 16:00:31 --> Output Class Initialized
INFO - 2017-08-10 16:00:31 --> Security Class Initialized
DEBUG - 2017-08-10 16:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:00:31 --> Input Class Initialized
INFO - 2017-08-10 16:00:31 --> Language Class Initialized
INFO - 2017-08-10 16:00:31 --> Loader Class Initialized
INFO - 2017-08-10 16:00:31 --> Helper loaded: common_helper
INFO - 2017-08-10 16:00:31 --> Database Driver Class Initialized
INFO - 2017-08-10 16:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:00:31 --> Email Class Initialized
INFO - 2017-08-10 16:00:31 --> Controller Class Initialized
INFO - 2017-08-10 16:00:31 --> Helper loaded: form_helper
INFO - 2017-08-10 16:00:31 --> Form Validation Class Initialized
INFO - 2017-08-10 16:00:31 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:00:31 --> Helper loaded: url_helper
INFO - 2017-08-10 16:00:31 --> Model Class Initialized
INFO - 2017-08-10 16:00:31 --> Model Class Initialized
INFO - 2017-08-10 16:00:31 --> Model Class Initialized
ERROR - 2017-08-10 19:30:31 --> Query error: Unknown column 'news_id' in 'where clause' - Invalid query: UPDATE `news_polls_images` SET `image` = '323291502373631.jpg', `updatedAt` = '17-08-10 07:30:31'
WHERE `news_id` = '49'
INFO - 2017-08-10 16:00:31 --> Config Class Initialized
INFO - 2017-08-10 16:00:31 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:00:31 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:00:31 --> Utf8 Class Initialized
INFO - 2017-08-10 16:00:31 --> URI Class Initialized
INFO - 2017-08-10 16:00:31 --> Router Class Initialized
INFO - 2017-08-10 16:00:31 --> Output Class Initialized
INFO - 2017-08-10 16:00:31 --> Security Class Initialized
DEBUG - 2017-08-10 16:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:00:31 --> Input Class Initialized
INFO - 2017-08-10 16:00:31 --> Language Class Initialized
INFO - 2017-08-10 16:00:31 --> Loader Class Initialized
INFO - 2017-08-10 16:00:31 --> Helper loaded: common_helper
INFO - 2017-08-10 16:00:31 --> Database Driver Class Initialized
INFO - 2017-08-10 16:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:00:31 --> Email Class Initialized
INFO - 2017-08-10 16:00:31 --> Controller Class Initialized
INFO - 2017-08-10 16:00:31 --> Helper loaded: form_helper
INFO - 2017-08-10 16:00:31 --> Form Validation Class Initialized
INFO - 2017-08-10 16:00:31 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:00:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:00:31 --> Helper loaded: url_helper
INFO - 2017-08-10 16:00:31 --> Model Class Initialized
INFO - 2017-08-10 16:00:31 --> Model Class Initialized
INFO - 2017-08-10 16:00:31 --> Model Class Initialized
INFO - 2017-08-10 19:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:30:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:30:31 --> Final output sent to browser
DEBUG - 2017-08-10 19:30:31 --> Total execution time: 0.0708
INFO - 2017-08-10 16:01:01 --> Config Class Initialized
INFO - 2017-08-10 16:01:01 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:01:01 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:01:01 --> Utf8 Class Initialized
INFO - 2017-08-10 16:01:01 --> URI Class Initialized
INFO - 2017-08-10 16:01:01 --> Router Class Initialized
INFO - 2017-08-10 16:01:01 --> Output Class Initialized
INFO - 2017-08-10 16:01:01 --> Security Class Initialized
DEBUG - 2017-08-10 16:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:01:01 --> Input Class Initialized
INFO - 2017-08-10 16:01:01 --> Language Class Initialized
INFO - 2017-08-10 16:01:01 --> Loader Class Initialized
INFO - 2017-08-10 16:01:01 --> Helper loaded: common_helper
INFO - 2017-08-10 16:01:01 --> Database Driver Class Initialized
INFO - 2017-08-10 16:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:01:01 --> Email Class Initialized
INFO - 2017-08-10 16:01:01 --> Controller Class Initialized
INFO - 2017-08-10 16:01:01 --> Helper loaded: form_helper
INFO - 2017-08-10 16:01:01 --> Form Validation Class Initialized
INFO - 2017-08-10 16:01:01 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:01:01 --> Helper loaded: url_helper
INFO - 2017-08-10 16:01:01 --> Model Class Initialized
INFO - 2017-08-10 16:01:01 --> Model Class Initialized
INFO - 2017-08-10 16:01:01 --> Model Class Initialized
INFO - 2017-08-10 19:31:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:31:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:31:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:31:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:31:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:31:01 --> Final output sent to browser
DEBUG - 2017-08-10 19:31:01 --> Total execution time: 0.0596
INFO - 2017-08-10 16:01:05 --> Config Class Initialized
INFO - 2017-08-10 16:01:05 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:01:05 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:01:05 --> Utf8 Class Initialized
INFO - 2017-08-10 16:01:05 --> URI Class Initialized
INFO - 2017-08-10 16:01:05 --> Router Class Initialized
INFO - 2017-08-10 16:01:05 --> Output Class Initialized
INFO - 2017-08-10 16:01:05 --> Security Class Initialized
DEBUG - 2017-08-10 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:01:05 --> Input Class Initialized
INFO - 2017-08-10 16:01:05 --> Language Class Initialized
INFO - 2017-08-10 16:01:05 --> Loader Class Initialized
INFO - 2017-08-10 16:01:05 --> Helper loaded: common_helper
INFO - 2017-08-10 16:01:05 --> Database Driver Class Initialized
INFO - 2017-08-10 16:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:01:05 --> Email Class Initialized
INFO - 2017-08-10 16:01:05 --> Controller Class Initialized
INFO - 2017-08-10 16:01:05 --> Helper loaded: form_helper
INFO - 2017-08-10 16:01:05 --> Form Validation Class Initialized
INFO - 2017-08-10 16:01:05 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:01:05 --> Helper loaded: url_helper
INFO - 2017-08-10 16:01:05 --> Model Class Initialized
INFO - 2017-08-10 16:01:05 --> Model Class Initialized
INFO - 2017-08-10 16:01:05 --> Model Class Initialized
INFO - 2017-08-10 16:01:32 --> Config Class Initialized
INFO - 2017-08-10 16:01:32 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:01:32 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:01:32 --> Utf8 Class Initialized
INFO - 2017-08-10 16:01:32 --> URI Class Initialized
INFO - 2017-08-10 16:01:32 --> Router Class Initialized
INFO - 2017-08-10 16:01:32 --> Output Class Initialized
INFO - 2017-08-10 16:01:32 --> Security Class Initialized
DEBUG - 2017-08-10 16:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:01:32 --> Input Class Initialized
INFO - 2017-08-10 16:01:32 --> Language Class Initialized
INFO - 2017-08-10 16:01:32 --> Loader Class Initialized
INFO - 2017-08-10 16:01:32 --> Helper loaded: common_helper
INFO - 2017-08-10 16:01:32 --> Database Driver Class Initialized
INFO - 2017-08-10 16:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:01:32 --> Email Class Initialized
INFO - 2017-08-10 16:01:32 --> Controller Class Initialized
INFO - 2017-08-10 16:01:32 --> Helper loaded: form_helper
INFO - 2017-08-10 16:01:32 --> Form Validation Class Initialized
INFO - 2017-08-10 16:01:32 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:01:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:01:32 --> Helper loaded: url_helper
INFO - 2017-08-10 16:01:32 --> Model Class Initialized
INFO - 2017-08-10 16:01:32 --> Model Class Initialized
INFO - 2017-08-10 16:01:32 --> Model Class Initialized
ERROR - 2017-08-10 19:31:32 --> Query error: Unknown column 'pollimageId' in 'where clause' - Invalid query: UPDATE `news_polls_images` SET `image` = '195671502373692.jpg', `updatedAt` = '17-08-10 07:31:32'
WHERE `pollimageId` = '12'
INFO - 2017-08-10 16:01:44 --> Config Class Initialized
INFO - 2017-08-10 16:01:44 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:01:44 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:01:44 --> Utf8 Class Initialized
INFO - 2017-08-10 16:01:44 --> URI Class Initialized
INFO - 2017-08-10 16:01:44 --> Router Class Initialized
INFO - 2017-08-10 16:01:44 --> Output Class Initialized
INFO - 2017-08-10 16:01:44 --> Security Class Initialized
DEBUG - 2017-08-10 16:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:01:44 --> Input Class Initialized
INFO - 2017-08-10 16:01:44 --> Language Class Initialized
INFO - 2017-08-10 16:01:44 --> Loader Class Initialized
INFO - 2017-08-10 16:01:44 --> Helper loaded: common_helper
INFO - 2017-08-10 16:01:44 --> Database Driver Class Initialized
INFO - 2017-08-10 16:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:01:44 --> Email Class Initialized
INFO - 2017-08-10 16:01:44 --> Controller Class Initialized
INFO - 2017-08-10 16:01:44 --> Helper loaded: form_helper
INFO - 2017-08-10 16:01:44 --> Form Validation Class Initialized
INFO - 2017-08-10 16:01:44 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:01:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:01:44 --> Helper loaded: url_helper
INFO - 2017-08-10 16:01:44 --> Model Class Initialized
INFO - 2017-08-10 16:01:44 --> Model Class Initialized
INFO - 2017-08-10 16:01:44 --> Model Class Initialized
INFO - 2017-08-10 19:31:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:31:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:31:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:31:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:31:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:31:44 --> Final output sent to browser
DEBUG - 2017-08-10 19:31:44 --> Total execution time: 0.0509
INFO - 2017-08-10 16:01:49 --> Config Class Initialized
INFO - 2017-08-10 16:01:49 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:01:49 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:01:49 --> Utf8 Class Initialized
INFO - 2017-08-10 16:01:49 --> URI Class Initialized
INFO - 2017-08-10 16:01:49 --> Router Class Initialized
INFO - 2017-08-10 16:01:49 --> Output Class Initialized
INFO - 2017-08-10 16:01:49 --> Security Class Initialized
DEBUG - 2017-08-10 16:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:01:49 --> Input Class Initialized
INFO - 2017-08-10 16:01:49 --> Language Class Initialized
INFO - 2017-08-10 16:01:49 --> Loader Class Initialized
INFO - 2017-08-10 16:01:49 --> Helper loaded: common_helper
INFO - 2017-08-10 16:01:49 --> Database Driver Class Initialized
INFO - 2017-08-10 16:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:01:49 --> Email Class Initialized
INFO - 2017-08-10 16:01:49 --> Controller Class Initialized
INFO - 2017-08-10 16:01:49 --> Helper loaded: form_helper
INFO - 2017-08-10 16:01:49 --> Form Validation Class Initialized
INFO - 2017-08-10 16:01:49 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:01:49 --> Helper loaded: url_helper
INFO - 2017-08-10 16:01:49 --> Model Class Initialized
INFO - 2017-08-10 16:01:49 --> Model Class Initialized
INFO - 2017-08-10 16:01:49 --> Model Class Initialized
ERROR - 2017-08-10 19:31:49 --> Query error: Unknown column 'pollimageId' in 'where clause' - Invalid query: UPDATE `news_polls_images` SET `image` = '34521502373709.jpg', `updatedAt` = '17-08-10 07:31:49'
WHERE `pollimageId` = '12'
INFO - 2017-08-10 16:01:49 --> Config Class Initialized
INFO - 2017-08-10 16:01:49 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:01:49 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:01:49 --> Utf8 Class Initialized
INFO - 2017-08-10 16:01:49 --> URI Class Initialized
INFO - 2017-08-10 16:01:49 --> Router Class Initialized
INFO - 2017-08-10 16:01:49 --> Output Class Initialized
INFO - 2017-08-10 16:01:49 --> Security Class Initialized
DEBUG - 2017-08-10 16:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:01:49 --> Input Class Initialized
INFO - 2017-08-10 16:01:49 --> Language Class Initialized
INFO - 2017-08-10 16:01:49 --> Loader Class Initialized
INFO - 2017-08-10 16:01:49 --> Helper loaded: common_helper
INFO - 2017-08-10 16:01:49 --> Database Driver Class Initialized
INFO - 2017-08-10 16:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:01:49 --> Email Class Initialized
INFO - 2017-08-10 16:01:49 --> Controller Class Initialized
INFO - 2017-08-10 16:01:49 --> Helper loaded: form_helper
INFO - 2017-08-10 16:01:49 --> Form Validation Class Initialized
INFO - 2017-08-10 16:01:49 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:01:49 --> Helper loaded: url_helper
INFO - 2017-08-10 16:01:49 --> Model Class Initialized
INFO - 2017-08-10 16:01:49 --> Model Class Initialized
INFO - 2017-08-10 16:01:49 --> Model Class Initialized
INFO - 2017-08-10 19:31:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:31:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:31:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:31:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:31:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:31:49 --> Final output sent to browser
DEBUG - 2017-08-10 19:31:49 --> Total execution time: 0.0488
INFO - 2017-08-10 16:02:51 --> Config Class Initialized
INFO - 2017-08-10 16:02:51 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:02:51 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:02:51 --> Utf8 Class Initialized
INFO - 2017-08-10 16:02:51 --> URI Class Initialized
INFO - 2017-08-10 16:02:51 --> Router Class Initialized
INFO - 2017-08-10 16:02:51 --> Output Class Initialized
INFO - 2017-08-10 16:02:51 --> Security Class Initialized
DEBUG - 2017-08-10 16:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:02:51 --> Input Class Initialized
INFO - 2017-08-10 16:02:51 --> Language Class Initialized
INFO - 2017-08-10 16:02:51 --> Loader Class Initialized
INFO - 2017-08-10 16:02:51 --> Helper loaded: common_helper
INFO - 2017-08-10 16:02:51 --> Database Driver Class Initialized
INFO - 2017-08-10 16:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:02:51 --> Email Class Initialized
INFO - 2017-08-10 16:02:51 --> Controller Class Initialized
INFO - 2017-08-10 16:02:51 --> Helper loaded: form_helper
INFO - 2017-08-10 16:02:51 --> Form Validation Class Initialized
INFO - 2017-08-10 16:02:51 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:02:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:02:51 --> Helper loaded: url_helper
INFO - 2017-08-10 16:02:51 --> Model Class Initialized
INFO - 2017-08-10 16:02:51 --> Model Class Initialized
INFO - 2017-08-10 16:02:51 --> Model Class Initialized
INFO - 2017-08-10 19:32:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:32:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:32:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:32:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:32:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:32:51 --> Final output sent to browser
DEBUG - 2017-08-10 19:32:51 --> Total execution time: 0.0601
INFO - 2017-08-10 16:02:54 --> Config Class Initialized
INFO - 2017-08-10 16:02:54 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:02:54 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:02:54 --> Utf8 Class Initialized
INFO - 2017-08-10 16:02:54 --> URI Class Initialized
INFO - 2017-08-10 16:02:54 --> Router Class Initialized
INFO - 2017-08-10 16:02:54 --> Output Class Initialized
INFO - 2017-08-10 16:02:54 --> Security Class Initialized
DEBUG - 2017-08-10 16:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:02:54 --> Input Class Initialized
INFO - 2017-08-10 16:02:54 --> Language Class Initialized
INFO - 2017-08-10 16:02:54 --> Loader Class Initialized
INFO - 2017-08-10 16:02:54 --> Helper loaded: common_helper
INFO - 2017-08-10 16:02:54 --> Database Driver Class Initialized
INFO - 2017-08-10 16:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:02:54 --> Email Class Initialized
INFO - 2017-08-10 16:02:54 --> Controller Class Initialized
INFO - 2017-08-10 16:02:54 --> Helper loaded: form_helper
INFO - 2017-08-10 16:02:54 --> Form Validation Class Initialized
INFO - 2017-08-10 16:02:54 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:02:54 --> Helper loaded: url_helper
INFO - 2017-08-10 16:02:54 --> Model Class Initialized
INFO - 2017-08-10 16:02:54 --> Model Class Initialized
INFO - 2017-08-10 16:02:54 --> Model Class Initialized
INFO - 2017-08-10 16:02:54 --> Config Class Initialized
INFO - 2017-08-10 16:02:54 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:02:54 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:02:54 --> Utf8 Class Initialized
INFO - 2017-08-10 16:02:54 --> URI Class Initialized
INFO - 2017-08-10 16:02:54 --> Router Class Initialized
INFO - 2017-08-10 16:02:54 --> Output Class Initialized
INFO - 2017-08-10 16:02:54 --> Security Class Initialized
DEBUG - 2017-08-10 16:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:02:54 --> Input Class Initialized
INFO - 2017-08-10 16:02:54 --> Language Class Initialized
INFO - 2017-08-10 16:02:54 --> Loader Class Initialized
INFO - 2017-08-10 16:02:54 --> Helper loaded: common_helper
INFO - 2017-08-10 16:02:54 --> Database Driver Class Initialized
INFO - 2017-08-10 16:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:02:54 --> Email Class Initialized
INFO - 2017-08-10 16:02:54 --> Controller Class Initialized
INFO - 2017-08-10 16:02:54 --> Helper loaded: form_helper
INFO - 2017-08-10 16:02:54 --> Form Validation Class Initialized
INFO - 2017-08-10 16:02:54 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:02:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:02:54 --> Helper loaded: url_helper
INFO - 2017-08-10 16:02:54 --> Model Class Initialized
INFO - 2017-08-10 16:02:54 --> Model Class Initialized
INFO - 2017-08-10 16:02:54 --> Model Class Initialized
INFO - 2017-08-10 19:32:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:32:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:32:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:32:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:32:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:32:54 --> Final output sent to browser
DEBUG - 2017-08-10 19:32:54 --> Total execution time: 0.0514
INFO - 2017-08-10 16:03:01 --> Config Class Initialized
INFO - 2017-08-10 16:03:01 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:03:01 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:03:01 --> Utf8 Class Initialized
INFO - 2017-08-10 16:03:01 --> URI Class Initialized
INFO - 2017-08-10 16:03:01 --> Router Class Initialized
INFO - 2017-08-10 16:03:01 --> Output Class Initialized
INFO - 2017-08-10 16:03:01 --> Security Class Initialized
DEBUG - 2017-08-10 16:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:03:01 --> Input Class Initialized
INFO - 2017-08-10 16:03:01 --> Language Class Initialized
INFO - 2017-08-10 16:03:01 --> Loader Class Initialized
INFO - 2017-08-10 16:03:01 --> Helper loaded: common_helper
INFO - 2017-08-10 16:03:01 --> Database Driver Class Initialized
INFO - 2017-08-10 16:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:03:01 --> Email Class Initialized
INFO - 2017-08-10 16:03:01 --> Controller Class Initialized
INFO - 2017-08-10 16:03:01 --> Helper loaded: form_helper
INFO - 2017-08-10 16:03:01 --> Form Validation Class Initialized
INFO - 2017-08-10 16:03:01 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:03:01 --> Helper loaded: url_helper
INFO - 2017-08-10 16:03:01 --> Model Class Initialized
INFO - 2017-08-10 16:03:01 --> Model Class Initialized
INFO - 2017-08-10 16:03:01 --> Model Class Initialized
INFO - 2017-08-10 16:03:02 --> Config Class Initialized
INFO - 2017-08-10 16:03:02 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:03:02 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:03:02 --> Utf8 Class Initialized
INFO - 2017-08-10 16:03:02 --> URI Class Initialized
INFO - 2017-08-10 16:03:02 --> Router Class Initialized
INFO - 2017-08-10 16:03:02 --> Output Class Initialized
INFO - 2017-08-10 16:03:02 --> Security Class Initialized
DEBUG - 2017-08-10 16:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:03:02 --> Input Class Initialized
INFO - 2017-08-10 16:03:02 --> Language Class Initialized
INFO - 2017-08-10 16:03:02 --> Loader Class Initialized
INFO - 2017-08-10 16:03:02 --> Helper loaded: common_helper
INFO - 2017-08-10 16:03:02 --> Database Driver Class Initialized
INFO - 2017-08-10 16:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:03:02 --> Email Class Initialized
INFO - 2017-08-10 16:03:02 --> Controller Class Initialized
INFO - 2017-08-10 16:03:02 --> Helper loaded: form_helper
INFO - 2017-08-10 16:03:02 --> Form Validation Class Initialized
INFO - 2017-08-10 16:03:02 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:03:02 --> Helper loaded: url_helper
INFO - 2017-08-10 16:03:02 --> Model Class Initialized
INFO - 2017-08-10 16:03:02 --> Model Class Initialized
INFO - 2017-08-10 16:03:02 --> Model Class Initialized
INFO - 2017-08-10 19:33:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:33:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:33:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:33:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:33:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:33:02 --> Final output sent to browser
DEBUG - 2017-08-10 19:33:02 --> Total execution time: 0.0613
INFO - 2017-08-10 16:03:07 --> Config Class Initialized
INFO - 2017-08-10 16:03:07 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:03:07 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:03:07 --> Utf8 Class Initialized
INFO - 2017-08-10 16:03:07 --> URI Class Initialized
INFO - 2017-08-10 16:03:07 --> Router Class Initialized
INFO - 2017-08-10 16:03:07 --> Output Class Initialized
INFO - 2017-08-10 16:03:07 --> Security Class Initialized
DEBUG - 2017-08-10 16:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:03:07 --> Input Class Initialized
INFO - 2017-08-10 16:03:07 --> Language Class Initialized
INFO - 2017-08-10 16:03:07 --> Loader Class Initialized
INFO - 2017-08-10 16:03:07 --> Helper loaded: common_helper
INFO - 2017-08-10 16:03:07 --> Database Driver Class Initialized
INFO - 2017-08-10 16:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:03:07 --> Email Class Initialized
INFO - 2017-08-10 16:03:07 --> Controller Class Initialized
INFO - 2017-08-10 16:03:07 --> Helper loaded: form_helper
INFO - 2017-08-10 16:03:07 --> Form Validation Class Initialized
INFO - 2017-08-10 16:03:07 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:03:07 --> Helper loaded: url_helper
INFO - 2017-08-10 16:03:07 --> Model Class Initialized
INFO - 2017-08-10 16:03:07 --> Model Class Initialized
INFO - 2017-08-10 16:03:07 --> Model Class Initialized
INFO - 2017-08-10 16:03:07 --> Config Class Initialized
INFO - 2017-08-10 16:03:07 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:03:07 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:03:07 --> Utf8 Class Initialized
INFO - 2017-08-10 16:03:07 --> URI Class Initialized
INFO - 2017-08-10 16:03:07 --> Router Class Initialized
INFO - 2017-08-10 16:03:07 --> Output Class Initialized
INFO - 2017-08-10 16:03:07 --> Security Class Initialized
DEBUG - 2017-08-10 16:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:03:07 --> Input Class Initialized
INFO - 2017-08-10 16:03:07 --> Language Class Initialized
INFO - 2017-08-10 16:03:07 --> Loader Class Initialized
INFO - 2017-08-10 16:03:07 --> Helper loaded: common_helper
INFO - 2017-08-10 16:03:07 --> Database Driver Class Initialized
INFO - 2017-08-10 16:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:03:07 --> Email Class Initialized
INFO - 2017-08-10 16:03:07 --> Controller Class Initialized
INFO - 2017-08-10 16:03:07 --> Helper loaded: form_helper
INFO - 2017-08-10 16:03:07 --> Form Validation Class Initialized
INFO - 2017-08-10 16:03:07 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:03:07 --> Helper loaded: url_helper
INFO - 2017-08-10 16:03:07 --> Model Class Initialized
INFO - 2017-08-10 16:03:07 --> Model Class Initialized
INFO - 2017-08-10 16:03:07 --> Model Class Initialized
INFO - 2017-08-10 19:33:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:33:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:33:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:33:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:33:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:33:07 --> Final output sent to browser
DEBUG - 2017-08-10 19:33:07 --> Total execution time: 0.0490
INFO - 2017-08-10 16:06:20 --> Config Class Initialized
INFO - 2017-08-10 16:06:20 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:06:20 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:06:20 --> Utf8 Class Initialized
INFO - 2017-08-10 16:06:20 --> URI Class Initialized
INFO - 2017-08-10 16:06:20 --> Router Class Initialized
INFO - 2017-08-10 16:06:20 --> Output Class Initialized
INFO - 2017-08-10 16:06:20 --> Security Class Initialized
DEBUG - 2017-08-10 16:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:06:20 --> Input Class Initialized
INFO - 2017-08-10 16:06:20 --> Language Class Initialized
INFO - 2017-08-10 16:06:20 --> Loader Class Initialized
INFO - 2017-08-10 16:06:20 --> Helper loaded: common_helper
INFO - 2017-08-10 16:06:20 --> Database Driver Class Initialized
INFO - 2017-08-10 16:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:06:20 --> Email Class Initialized
INFO - 2017-08-10 16:06:20 --> Controller Class Initialized
INFO - 2017-08-10 16:06:20 --> Helper loaded: form_helper
INFO - 2017-08-10 16:06:20 --> Form Validation Class Initialized
INFO - 2017-08-10 16:06:20 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:06:20 --> Helper loaded: url_helper
INFO - 2017-08-10 16:06:20 --> Model Class Initialized
INFO - 2017-08-10 16:06:20 --> Model Class Initialized
INFO - 2017-08-10 16:06:20 --> Model Class Initialized
INFO - 2017-08-10 19:36:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:36:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:36:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:36:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:36:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:36:20 --> Final output sent to browser
DEBUG - 2017-08-10 19:36:20 --> Total execution time: 0.0524
INFO - 2017-08-10 16:06:22 --> Config Class Initialized
INFO - 2017-08-10 16:06:22 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:06:22 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:06:22 --> Utf8 Class Initialized
INFO - 2017-08-10 16:06:22 --> URI Class Initialized
INFO - 2017-08-10 16:06:22 --> Router Class Initialized
INFO - 2017-08-10 16:06:22 --> Output Class Initialized
INFO - 2017-08-10 16:06:22 --> Security Class Initialized
DEBUG - 2017-08-10 16:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:06:22 --> Input Class Initialized
INFO - 2017-08-10 16:06:22 --> Language Class Initialized
INFO - 2017-08-10 16:06:22 --> Loader Class Initialized
INFO - 2017-08-10 16:06:22 --> Helper loaded: common_helper
INFO - 2017-08-10 16:06:22 --> Database Driver Class Initialized
INFO - 2017-08-10 16:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:06:22 --> Email Class Initialized
INFO - 2017-08-10 16:06:22 --> Controller Class Initialized
INFO - 2017-08-10 16:06:22 --> Helper loaded: form_helper
INFO - 2017-08-10 16:06:22 --> Form Validation Class Initialized
INFO - 2017-08-10 16:06:22 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:06:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:06:22 --> Helper loaded: url_helper
INFO - 2017-08-10 16:06:22 --> Model Class Initialized
INFO - 2017-08-10 16:06:22 --> Model Class Initialized
INFO - 2017-08-10 16:06:22 --> Model Class Initialized
INFO - 2017-08-10 19:36:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:36:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:36:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:36:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:36:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:36:22 --> Final output sent to browser
DEBUG - 2017-08-10 19:36:22 --> Total execution time: 0.0551
INFO - 2017-08-10 16:06:31 --> Config Class Initialized
INFO - 2017-08-10 16:06:31 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:06:31 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:06:31 --> Utf8 Class Initialized
INFO - 2017-08-10 16:06:31 --> URI Class Initialized
INFO - 2017-08-10 16:06:31 --> Router Class Initialized
INFO - 2017-08-10 16:06:31 --> Output Class Initialized
INFO - 2017-08-10 16:06:31 --> Security Class Initialized
DEBUG - 2017-08-10 16:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:06:31 --> Input Class Initialized
INFO - 2017-08-10 16:06:31 --> Language Class Initialized
INFO - 2017-08-10 16:06:31 --> Loader Class Initialized
INFO - 2017-08-10 16:06:31 --> Helper loaded: common_helper
INFO - 2017-08-10 16:06:31 --> Database Driver Class Initialized
INFO - 2017-08-10 16:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:06:31 --> Email Class Initialized
INFO - 2017-08-10 16:06:31 --> Controller Class Initialized
INFO - 2017-08-10 16:06:31 --> Helper loaded: form_helper
INFO - 2017-08-10 16:06:31 --> Form Validation Class Initialized
INFO - 2017-08-10 16:06:31 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:06:31 --> Helper loaded: url_helper
INFO - 2017-08-10 16:06:31 --> Model Class Initialized
INFO - 2017-08-10 16:06:31 --> Model Class Initialized
INFO - 2017-08-10 16:06:31 --> Model Class Initialized
INFO - 2017-08-10 16:06:31 --> Config Class Initialized
INFO - 2017-08-10 16:06:31 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:06:31 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:06:31 --> Utf8 Class Initialized
INFO - 2017-08-10 16:06:31 --> URI Class Initialized
INFO - 2017-08-10 16:06:31 --> Router Class Initialized
INFO - 2017-08-10 16:06:31 --> Output Class Initialized
INFO - 2017-08-10 16:06:31 --> Security Class Initialized
DEBUG - 2017-08-10 16:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:06:31 --> Input Class Initialized
INFO - 2017-08-10 16:06:31 --> Language Class Initialized
INFO - 2017-08-10 16:06:31 --> Loader Class Initialized
INFO - 2017-08-10 16:06:31 --> Helper loaded: common_helper
INFO - 2017-08-10 16:06:31 --> Database Driver Class Initialized
INFO - 2017-08-10 16:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:06:31 --> Email Class Initialized
INFO - 2017-08-10 16:06:31 --> Controller Class Initialized
INFO - 2017-08-10 16:06:31 --> Helper loaded: form_helper
INFO - 2017-08-10 16:06:31 --> Form Validation Class Initialized
INFO - 2017-08-10 16:06:31 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:06:31 --> Helper loaded: url_helper
INFO - 2017-08-10 16:06:31 --> Model Class Initialized
INFO - 2017-08-10 16:06:31 --> Model Class Initialized
INFO - 2017-08-10 16:06:31 --> Model Class Initialized
INFO - 2017-08-10 19:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:36:31 --> Final output sent to browser
DEBUG - 2017-08-10 19:36:31 --> Total execution time: 0.0496
INFO - 2017-08-10 16:07:30 --> Config Class Initialized
INFO - 2017-08-10 16:07:30 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:07:30 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:07:30 --> Utf8 Class Initialized
INFO - 2017-08-10 16:07:30 --> URI Class Initialized
INFO - 2017-08-10 16:07:30 --> Router Class Initialized
INFO - 2017-08-10 16:07:30 --> Output Class Initialized
INFO - 2017-08-10 16:07:30 --> Security Class Initialized
DEBUG - 2017-08-10 16:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:07:30 --> Input Class Initialized
INFO - 2017-08-10 16:07:30 --> Language Class Initialized
INFO - 2017-08-10 16:07:30 --> Loader Class Initialized
INFO - 2017-08-10 16:07:30 --> Helper loaded: common_helper
INFO - 2017-08-10 16:07:30 --> Database Driver Class Initialized
INFO - 2017-08-10 16:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:07:30 --> Email Class Initialized
INFO - 2017-08-10 16:07:30 --> Controller Class Initialized
INFO - 2017-08-10 16:07:30 --> Helper loaded: form_helper
INFO - 2017-08-10 16:07:30 --> Form Validation Class Initialized
INFO - 2017-08-10 16:07:30 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:07:30 --> Helper loaded: url_helper
INFO - 2017-08-10 16:07:30 --> Model Class Initialized
INFO - 2017-08-10 16:07:30 --> Model Class Initialized
INFO - 2017-08-10 16:07:30 --> Model Class Initialized
INFO - 2017-08-10 19:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:37:30 --> Final output sent to browser
DEBUG - 2017-08-10 19:37:30 --> Total execution time: 0.0547
INFO - 2017-08-10 16:07:34 --> Config Class Initialized
INFO - 2017-08-10 16:07:34 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:07:34 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:07:34 --> Utf8 Class Initialized
INFO - 2017-08-10 16:07:34 --> URI Class Initialized
INFO - 2017-08-10 16:07:34 --> Router Class Initialized
INFO - 2017-08-10 16:07:34 --> Output Class Initialized
INFO - 2017-08-10 16:07:34 --> Security Class Initialized
DEBUG - 2017-08-10 16:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:07:34 --> Input Class Initialized
INFO - 2017-08-10 16:07:34 --> Language Class Initialized
INFO - 2017-08-10 16:07:34 --> Loader Class Initialized
INFO - 2017-08-10 16:07:34 --> Helper loaded: common_helper
INFO - 2017-08-10 16:07:34 --> Database Driver Class Initialized
INFO - 2017-08-10 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:07:34 --> Email Class Initialized
INFO - 2017-08-10 16:07:34 --> Controller Class Initialized
INFO - 2017-08-10 16:07:34 --> Helper loaded: form_helper
INFO - 2017-08-10 16:07:34 --> Form Validation Class Initialized
INFO - 2017-08-10 16:07:34 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:07:34 --> Helper loaded: url_helper
INFO - 2017-08-10 16:07:34 --> Model Class Initialized
INFO - 2017-08-10 16:07:34 --> Model Class Initialized
INFO - 2017-08-10 16:07:34 --> Model Class Initialized
ERROR - 2017-08-10 19:37:34 --> Undefined variable: wherep
ERROR - 2017-08-10 19:37:34 --> Severity: Notice --> Undefined variable: wherep C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 479
INFO - 2017-08-10 16:07:34 --> Config Class Initialized
INFO - 2017-08-10 16:07:34 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:07:34 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:07:34 --> Utf8 Class Initialized
INFO - 2017-08-10 16:07:34 --> URI Class Initialized
INFO - 2017-08-10 16:07:34 --> Router Class Initialized
INFO - 2017-08-10 16:07:34 --> Output Class Initialized
INFO - 2017-08-10 16:07:34 --> Security Class Initialized
DEBUG - 2017-08-10 16:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:07:34 --> Input Class Initialized
INFO - 2017-08-10 16:07:34 --> Language Class Initialized
INFO - 2017-08-10 16:07:34 --> Loader Class Initialized
INFO - 2017-08-10 16:07:34 --> Helper loaded: common_helper
INFO - 2017-08-10 16:07:34 --> Database Driver Class Initialized
INFO - 2017-08-10 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:07:34 --> Email Class Initialized
INFO - 2017-08-10 16:07:34 --> Controller Class Initialized
INFO - 2017-08-10 16:07:34 --> Helper loaded: form_helper
INFO - 2017-08-10 16:07:34 --> Form Validation Class Initialized
INFO - 2017-08-10 16:07:34 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:07:34 --> Helper loaded: url_helper
INFO - 2017-08-10 16:07:34 --> Model Class Initialized
INFO - 2017-08-10 16:07:34 --> Model Class Initialized
INFO - 2017-08-10 16:07:34 --> Model Class Initialized
INFO - 2017-08-10 19:37:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:37:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:37:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:37:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:37:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:37:34 --> Final output sent to browser
DEBUG - 2017-08-10 19:37:34 --> Total execution time: 0.0500
INFO - 2017-08-10 16:08:04 --> Config Class Initialized
INFO - 2017-08-10 16:08:04 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:08:04 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:08:04 --> Utf8 Class Initialized
INFO - 2017-08-10 16:08:04 --> URI Class Initialized
INFO - 2017-08-10 16:08:04 --> Router Class Initialized
INFO - 2017-08-10 16:08:04 --> Output Class Initialized
INFO - 2017-08-10 16:08:04 --> Security Class Initialized
DEBUG - 2017-08-10 16:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:08:04 --> Input Class Initialized
INFO - 2017-08-10 16:08:04 --> Language Class Initialized
INFO - 2017-08-10 16:08:04 --> Loader Class Initialized
INFO - 2017-08-10 16:08:04 --> Helper loaded: common_helper
INFO - 2017-08-10 16:08:04 --> Database Driver Class Initialized
INFO - 2017-08-10 16:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:08:04 --> Email Class Initialized
INFO - 2017-08-10 16:08:04 --> Controller Class Initialized
INFO - 2017-08-10 16:08:04 --> Helper loaded: form_helper
INFO - 2017-08-10 16:08:04 --> Form Validation Class Initialized
INFO - 2017-08-10 16:08:04 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:08:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:08:04 --> Helper loaded: url_helper
INFO - 2017-08-10 16:08:04 --> Model Class Initialized
INFO - 2017-08-10 16:08:04 --> Model Class Initialized
INFO - 2017-08-10 16:08:04 --> Model Class Initialized
INFO - 2017-08-10 19:38:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:38:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:38:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:38:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:38:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:38:04 --> Final output sent to browser
DEBUG - 2017-08-10 19:38:04 --> Total execution time: 0.0568
INFO - 2017-08-10 16:08:08 --> Config Class Initialized
INFO - 2017-08-10 16:08:08 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:08:08 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:08:08 --> Utf8 Class Initialized
INFO - 2017-08-10 16:08:08 --> URI Class Initialized
INFO - 2017-08-10 16:08:08 --> Router Class Initialized
INFO - 2017-08-10 16:08:08 --> Output Class Initialized
INFO - 2017-08-10 16:08:08 --> Security Class Initialized
DEBUG - 2017-08-10 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:08:08 --> Input Class Initialized
INFO - 2017-08-10 16:08:08 --> Language Class Initialized
INFO - 2017-08-10 16:08:08 --> Loader Class Initialized
INFO - 2017-08-10 16:08:08 --> Helper loaded: common_helper
INFO - 2017-08-10 16:08:08 --> Database Driver Class Initialized
INFO - 2017-08-10 16:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:08:08 --> Email Class Initialized
INFO - 2017-08-10 16:08:08 --> Controller Class Initialized
INFO - 2017-08-10 16:08:08 --> Helper loaded: form_helper
INFO - 2017-08-10 16:08:08 --> Form Validation Class Initialized
INFO - 2017-08-10 16:08:08 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:08:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:08:08 --> Helper loaded: url_helper
INFO - 2017-08-10 16:08:08 --> Model Class Initialized
INFO - 2017-08-10 16:08:08 --> Model Class Initialized
INFO - 2017-08-10 16:08:08 --> Model Class Initialized
ERROR - 2017-08-10 19:38:08 --> Undefined variable: wherep
ERROR - 2017-08-10 19:38:08 --> Severity: Notice --> Undefined variable: wherep C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 479
INFO - 2017-08-10 16:09:04 --> Config Class Initialized
INFO - 2017-08-10 16:09:04 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:09:04 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:09:04 --> Utf8 Class Initialized
INFO - 2017-08-10 16:09:04 --> URI Class Initialized
INFO - 2017-08-10 16:09:04 --> Router Class Initialized
INFO - 2017-08-10 16:09:04 --> Output Class Initialized
INFO - 2017-08-10 16:09:04 --> Security Class Initialized
DEBUG - 2017-08-10 16:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:09:04 --> Input Class Initialized
INFO - 2017-08-10 16:09:04 --> Language Class Initialized
INFO - 2017-08-10 16:09:04 --> Loader Class Initialized
INFO - 2017-08-10 16:09:04 --> Helper loaded: common_helper
INFO - 2017-08-10 16:09:04 --> Database Driver Class Initialized
INFO - 2017-08-10 16:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:09:04 --> Email Class Initialized
INFO - 2017-08-10 16:09:04 --> Controller Class Initialized
INFO - 2017-08-10 16:09:04 --> Helper loaded: form_helper
INFO - 2017-08-10 16:09:04 --> Form Validation Class Initialized
INFO - 2017-08-10 16:09:04 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:09:04 --> Helper loaded: url_helper
INFO - 2017-08-10 16:09:04 --> Model Class Initialized
INFO - 2017-08-10 16:09:04 --> Model Class Initialized
INFO - 2017-08-10 16:09:04 --> Model Class Initialized
ERROR - 2017-08-10 19:39:04 --> Undefined variable: wherep
ERROR - 2017-08-10 19:39:04 --> Severity: Notice --> Undefined variable: wherep C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 478
INFO - 2017-08-10 16:09:28 --> Config Class Initialized
INFO - 2017-08-10 16:09:28 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:09:28 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:09:28 --> Utf8 Class Initialized
INFO - 2017-08-10 16:09:28 --> URI Class Initialized
INFO - 2017-08-10 16:09:28 --> Router Class Initialized
INFO - 2017-08-10 16:09:28 --> Output Class Initialized
INFO - 2017-08-10 16:09:28 --> Security Class Initialized
DEBUG - 2017-08-10 16:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:09:28 --> Input Class Initialized
INFO - 2017-08-10 16:09:28 --> Language Class Initialized
INFO - 2017-08-10 16:09:28 --> Loader Class Initialized
INFO - 2017-08-10 16:09:28 --> Helper loaded: common_helper
INFO - 2017-08-10 16:09:28 --> Database Driver Class Initialized
INFO - 2017-08-10 16:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:09:28 --> Email Class Initialized
INFO - 2017-08-10 16:09:28 --> Controller Class Initialized
INFO - 2017-08-10 16:09:28 --> Helper loaded: form_helper
INFO - 2017-08-10 16:09:28 --> Form Validation Class Initialized
INFO - 2017-08-10 16:09:28 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:09:28 --> Helper loaded: url_helper
INFO - 2017-08-10 16:09:28 --> Model Class Initialized
INFO - 2017-08-10 16:09:28 --> Model Class Initialized
INFO - 2017-08-10 16:09:28 --> Model Class Initialized
INFO - 2017-08-10 16:09:34 --> Config Class Initialized
INFO - 2017-08-10 16:09:34 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:09:34 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:09:34 --> Utf8 Class Initialized
INFO - 2017-08-10 16:09:34 --> URI Class Initialized
INFO - 2017-08-10 16:09:34 --> Router Class Initialized
INFO - 2017-08-10 16:09:34 --> Output Class Initialized
INFO - 2017-08-10 16:09:34 --> Security Class Initialized
DEBUG - 2017-08-10 16:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:09:34 --> Input Class Initialized
INFO - 2017-08-10 16:09:34 --> Language Class Initialized
INFO - 2017-08-10 16:09:34 --> Loader Class Initialized
INFO - 2017-08-10 16:09:34 --> Helper loaded: common_helper
INFO - 2017-08-10 16:09:34 --> Database Driver Class Initialized
INFO - 2017-08-10 16:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:09:34 --> Email Class Initialized
INFO - 2017-08-10 16:09:34 --> Controller Class Initialized
INFO - 2017-08-10 16:09:34 --> Helper loaded: form_helper
INFO - 2017-08-10 16:09:34 --> Form Validation Class Initialized
INFO - 2017-08-10 16:09:34 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:09:34 --> Helper loaded: url_helper
INFO - 2017-08-10 16:09:34 --> Model Class Initialized
INFO - 2017-08-10 16:09:34 --> Model Class Initialized
INFO - 2017-08-10 16:09:34 --> Model Class Initialized
INFO - 2017-08-10 16:09:34 --> Config Class Initialized
INFO - 2017-08-10 16:09:34 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:09:34 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:09:34 --> Utf8 Class Initialized
INFO - 2017-08-10 16:09:34 --> URI Class Initialized
INFO - 2017-08-10 16:09:34 --> Router Class Initialized
INFO - 2017-08-10 16:09:34 --> Output Class Initialized
INFO - 2017-08-10 16:09:34 --> Security Class Initialized
DEBUG - 2017-08-10 16:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:09:34 --> Input Class Initialized
INFO - 2017-08-10 16:09:34 --> Language Class Initialized
INFO - 2017-08-10 16:09:34 --> Loader Class Initialized
INFO - 2017-08-10 16:09:34 --> Helper loaded: common_helper
INFO - 2017-08-10 16:09:34 --> Database Driver Class Initialized
INFO - 2017-08-10 16:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:09:34 --> Email Class Initialized
INFO - 2017-08-10 16:09:34 --> Controller Class Initialized
INFO - 2017-08-10 16:09:34 --> Helper loaded: form_helper
INFO - 2017-08-10 16:09:34 --> Form Validation Class Initialized
INFO - 2017-08-10 16:09:34 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:09:34 --> Helper loaded: url_helper
INFO - 2017-08-10 16:09:34 --> Model Class Initialized
INFO - 2017-08-10 16:09:34 --> Model Class Initialized
INFO - 2017-08-10 16:09:34 --> Model Class Initialized
INFO - 2017-08-10 19:39:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:39:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:39:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:39:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:39:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:39:34 --> Final output sent to browser
DEBUG - 2017-08-10 19:39:34 --> Total execution time: 0.0488
INFO - 2017-08-10 16:09:46 --> Config Class Initialized
INFO - 2017-08-10 16:09:46 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:09:46 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:09:46 --> Utf8 Class Initialized
INFO - 2017-08-10 16:09:46 --> URI Class Initialized
INFO - 2017-08-10 16:09:46 --> Router Class Initialized
INFO - 2017-08-10 16:09:46 --> Output Class Initialized
INFO - 2017-08-10 16:09:46 --> Security Class Initialized
DEBUG - 2017-08-10 16:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:09:46 --> Input Class Initialized
INFO - 2017-08-10 16:09:46 --> Language Class Initialized
INFO - 2017-08-10 16:09:46 --> Loader Class Initialized
INFO - 2017-08-10 16:09:46 --> Helper loaded: common_helper
INFO - 2017-08-10 16:09:46 --> Database Driver Class Initialized
INFO - 2017-08-10 16:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:09:46 --> Email Class Initialized
INFO - 2017-08-10 16:09:46 --> Controller Class Initialized
INFO - 2017-08-10 16:09:46 --> Helper loaded: form_helper
INFO - 2017-08-10 16:09:46 --> Form Validation Class Initialized
INFO - 2017-08-10 16:09:46 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:09:46 --> Helper loaded: url_helper
INFO - 2017-08-10 16:09:46 --> Model Class Initialized
INFO - 2017-08-10 16:09:46 --> Model Class Initialized
INFO - 2017-08-10 16:09:46 --> Model Class Initialized
INFO - 2017-08-10 16:09:46 --> Config Class Initialized
INFO - 2017-08-10 16:09:46 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:09:46 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:09:46 --> Utf8 Class Initialized
INFO - 2017-08-10 16:09:46 --> URI Class Initialized
INFO - 2017-08-10 16:09:46 --> Router Class Initialized
INFO - 2017-08-10 16:09:46 --> Output Class Initialized
INFO - 2017-08-10 16:09:46 --> Security Class Initialized
DEBUG - 2017-08-10 16:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:09:46 --> Input Class Initialized
INFO - 2017-08-10 16:09:46 --> Language Class Initialized
INFO - 2017-08-10 16:09:46 --> Loader Class Initialized
INFO - 2017-08-10 16:09:46 --> Helper loaded: common_helper
INFO - 2017-08-10 16:09:46 --> Database Driver Class Initialized
INFO - 2017-08-10 16:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:09:46 --> Email Class Initialized
INFO - 2017-08-10 16:09:46 --> Controller Class Initialized
INFO - 2017-08-10 16:09:46 --> Helper loaded: form_helper
INFO - 2017-08-10 16:09:46 --> Form Validation Class Initialized
INFO - 2017-08-10 16:09:46 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:09:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:09:46 --> Helper loaded: url_helper
INFO - 2017-08-10 16:09:46 --> Model Class Initialized
INFO - 2017-08-10 16:09:46 --> Model Class Initialized
INFO - 2017-08-10 16:09:46 --> Model Class Initialized
INFO - 2017-08-10 19:39:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:39:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:39:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:39:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:39:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:39:46 --> Final output sent to browser
DEBUG - 2017-08-10 19:39:46 --> Total execution time: 0.0675
INFO - 2017-08-10 16:10:06 --> Config Class Initialized
INFO - 2017-08-10 16:10:06 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:06 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:06 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:06 --> URI Class Initialized
INFO - 2017-08-10 16:10:06 --> Router Class Initialized
INFO - 2017-08-10 16:10:06 --> Output Class Initialized
INFO - 2017-08-10 16:10:06 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:06 --> Input Class Initialized
INFO - 2017-08-10 16:10:06 --> Language Class Initialized
INFO - 2017-08-10 16:10:06 --> Loader Class Initialized
INFO - 2017-08-10 16:10:06 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:06 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:06 --> Email Class Initialized
INFO - 2017-08-10 16:10:06 --> Controller Class Initialized
INFO - 2017-08-10 16:10:06 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:06 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:06 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:06 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:06 --> Model Class Initialized
INFO - 2017-08-10 16:10:06 --> Model Class Initialized
INFO - 2017-08-10 16:10:06 --> Model Class Initialized
INFO - 2017-08-10 16:10:06 --> Config Class Initialized
INFO - 2017-08-10 16:10:06 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:06 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:06 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:06 --> URI Class Initialized
INFO - 2017-08-10 16:10:06 --> Router Class Initialized
INFO - 2017-08-10 16:10:06 --> Output Class Initialized
INFO - 2017-08-10 16:10:06 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:06 --> Input Class Initialized
INFO - 2017-08-10 16:10:06 --> Language Class Initialized
INFO - 2017-08-10 16:10:06 --> Loader Class Initialized
INFO - 2017-08-10 16:10:06 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:06 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:06 --> Email Class Initialized
INFO - 2017-08-10 16:10:06 --> Controller Class Initialized
INFO - 2017-08-10 16:10:06 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:06 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:06 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:06 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:06 --> Model Class Initialized
INFO - 2017-08-10 16:10:06 --> Model Class Initialized
INFO - 2017-08-10 16:10:06 --> Model Class Initialized
INFO - 2017-08-10 19:40:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:40:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:40:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:40:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:40:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:40:06 --> Final output sent to browser
DEBUG - 2017-08-10 19:40:06 --> Total execution time: 0.1196
INFO - 2017-08-10 16:10:13 --> Config Class Initialized
INFO - 2017-08-10 16:10:13 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:13 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:13 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:13 --> URI Class Initialized
INFO - 2017-08-10 16:10:13 --> Router Class Initialized
INFO - 2017-08-10 16:10:13 --> Output Class Initialized
INFO - 2017-08-10 16:10:13 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:13 --> Input Class Initialized
INFO - 2017-08-10 16:10:13 --> Language Class Initialized
INFO - 2017-08-10 16:10:13 --> Loader Class Initialized
INFO - 2017-08-10 16:10:13 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:13 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:13 --> Email Class Initialized
INFO - 2017-08-10 16:10:13 --> Controller Class Initialized
INFO - 2017-08-10 16:10:13 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:13 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:13 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:13 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:13 --> Model Class Initialized
INFO - 2017-08-10 16:10:13 --> Model Class Initialized
INFO - 2017-08-10 16:10:13 --> Model Class Initialized
INFO - 2017-08-10 16:10:14 --> Config Class Initialized
INFO - 2017-08-10 16:10:14 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:14 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:14 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:14 --> URI Class Initialized
INFO - 2017-08-10 16:10:14 --> Router Class Initialized
INFO - 2017-08-10 16:10:14 --> Output Class Initialized
INFO - 2017-08-10 16:10:14 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:14 --> Input Class Initialized
INFO - 2017-08-10 16:10:14 --> Language Class Initialized
INFO - 2017-08-10 16:10:14 --> Loader Class Initialized
INFO - 2017-08-10 16:10:14 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:14 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:14 --> Email Class Initialized
INFO - 2017-08-10 16:10:14 --> Controller Class Initialized
INFO - 2017-08-10 16:10:14 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:14 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:14 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:14 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:14 --> Model Class Initialized
INFO - 2017-08-10 16:10:14 --> Model Class Initialized
INFO - 2017-08-10 16:10:14 --> Model Class Initialized
INFO - 2017-08-10 19:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:40:14 --> Final output sent to browser
DEBUG - 2017-08-10 19:40:14 --> Total execution time: 0.0468
INFO - 2017-08-10 16:10:25 --> Config Class Initialized
INFO - 2017-08-10 16:10:25 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:25 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:25 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:25 --> URI Class Initialized
INFO - 2017-08-10 16:10:25 --> Router Class Initialized
INFO - 2017-08-10 16:10:25 --> Output Class Initialized
INFO - 2017-08-10 16:10:25 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:25 --> Input Class Initialized
INFO - 2017-08-10 16:10:25 --> Language Class Initialized
INFO - 2017-08-10 16:10:25 --> Loader Class Initialized
INFO - 2017-08-10 16:10:25 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:25 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:25 --> Email Class Initialized
INFO - 2017-08-10 16:10:25 --> Controller Class Initialized
INFO - 2017-08-10 16:10:25 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:25 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:25 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:25 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:25 --> Model Class Initialized
INFO - 2017-08-10 16:10:25 --> Model Class Initialized
INFO - 2017-08-10 16:10:25 --> Model Class Initialized
INFO - 2017-08-10 16:10:25 --> Config Class Initialized
INFO - 2017-08-10 16:10:25 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:25 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:25 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:25 --> URI Class Initialized
INFO - 2017-08-10 16:10:25 --> Router Class Initialized
INFO - 2017-08-10 16:10:25 --> Output Class Initialized
INFO - 2017-08-10 16:10:25 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:25 --> Input Class Initialized
INFO - 2017-08-10 16:10:25 --> Language Class Initialized
INFO - 2017-08-10 16:10:25 --> Loader Class Initialized
INFO - 2017-08-10 16:10:25 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:25 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:25 --> Email Class Initialized
INFO - 2017-08-10 16:10:25 --> Controller Class Initialized
INFO - 2017-08-10 16:10:25 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:25 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:25 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:25 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:25 --> Model Class Initialized
INFO - 2017-08-10 16:10:25 --> Model Class Initialized
INFO - 2017-08-10 16:10:25 --> Model Class Initialized
INFO - 2017-08-10 19:40:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:40:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:40:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:40:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:40:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:40:25 --> Final output sent to browser
DEBUG - 2017-08-10 19:40:25 --> Total execution time: 0.0476
INFO - 2017-08-10 16:10:33 --> Config Class Initialized
INFO - 2017-08-10 16:10:33 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:33 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:33 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:33 --> URI Class Initialized
INFO - 2017-08-10 16:10:33 --> Router Class Initialized
INFO - 2017-08-10 16:10:33 --> Output Class Initialized
INFO - 2017-08-10 16:10:33 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:33 --> Input Class Initialized
INFO - 2017-08-10 16:10:33 --> Language Class Initialized
INFO - 2017-08-10 16:10:33 --> Loader Class Initialized
INFO - 2017-08-10 16:10:33 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:33 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:33 --> Email Class Initialized
INFO - 2017-08-10 16:10:33 --> Controller Class Initialized
INFO - 2017-08-10 16:10:33 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:33 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:33 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:33 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:33 --> Model Class Initialized
INFO - 2017-08-10 16:10:33 --> Model Class Initialized
INFO - 2017-08-10 16:10:33 --> Model Class Initialized
INFO - 2017-08-10 16:10:33 --> Config Class Initialized
INFO - 2017-08-10 16:10:33 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:10:33 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:10:33 --> Utf8 Class Initialized
INFO - 2017-08-10 16:10:33 --> URI Class Initialized
INFO - 2017-08-10 16:10:33 --> Router Class Initialized
INFO - 2017-08-10 16:10:33 --> Output Class Initialized
INFO - 2017-08-10 16:10:33 --> Security Class Initialized
DEBUG - 2017-08-10 16:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:10:33 --> Input Class Initialized
INFO - 2017-08-10 16:10:33 --> Language Class Initialized
INFO - 2017-08-10 16:10:33 --> Loader Class Initialized
INFO - 2017-08-10 16:10:33 --> Helper loaded: common_helper
INFO - 2017-08-10 16:10:33 --> Database Driver Class Initialized
INFO - 2017-08-10 16:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:10:33 --> Email Class Initialized
INFO - 2017-08-10 16:10:33 --> Controller Class Initialized
INFO - 2017-08-10 16:10:33 --> Helper loaded: form_helper
INFO - 2017-08-10 16:10:33 --> Form Validation Class Initialized
INFO - 2017-08-10 16:10:33 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:10:33 --> Helper loaded: url_helper
INFO - 2017-08-10 16:10:33 --> Model Class Initialized
INFO - 2017-08-10 16:10:33 --> Model Class Initialized
INFO - 2017-08-10 16:10:33 --> Model Class Initialized
INFO - 2017-08-10 19:40:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:40:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:40:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:40:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:40:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:40:33 --> Final output sent to browser
DEBUG - 2017-08-10 19:40:33 --> Total execution time: 0.0636
INFO - 2017-08-10 16:11:16 --> Config Class Initialized
INFO - 2017-08-10 16:11:16 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:11:16 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:11:16 --> Utf8 Class Initialized
INFO - 2017-08-10 16:11:16 --> URI Class Initialized
INFO - 2017-08-10 16:11:16 --> Router Class Initialized
INFO - 2017-08-10 16:11:16 --> Output Class Initialized
INFO - 2017-08-10 16:11:16 --> Security Class Initialized
DEBUG - 2017-08-10 16:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:11:16 --> Input Class Initialized
INFO - 2017-08-10 16:11:16 --> Language Class Initialized
INFO - 2017-08-10 16:11:16 --> Loader Class Initialized
INFO - 2017-08-10 16:11:16 --> Helper loaded: common_helper
INFO - 2017-08-10 16:11:16 --> Database Driver Class Initialized
INFO - 2017-08-10 16:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:11:16 --> Email Class Initialized
INFO - 2017-08-10 16:11:16 --> Controller Class Initialized
INFO - 2017-08-10 16:11:16 --> Helper loaded: form_helper
INFO - 2017-08-10 16:11:16 --> Form Validation Class Initialized
INFO - 2017-08-10 16:11:16 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:11:16 --> Helper loaded: url_helper
INFO - 2017-08-10 16:11:16 --> Model Class Initialized
INFO - 2017-08-10 16:11:16 --> Model Class Initialized
INFO - 2017-08-10 16:11:16 --> Model Class Initialized
INFO - 2017-08-10 16:11:16 --> Config Class Initialized
INFO - 2017-08-10 16:11:16 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:11:16 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:11:16 --> Utf8 Class Initialized
INFO - 2017-08-10 16:11:16 --> URI Class Initialized
INFO - 2017-08-10 16:11:16 --> Router Class Initialized
INFO - 2017-08-10 16:11:16 --> Output Class Initialized
INFO - 2017-08-10 16:11:16 --> Security Class Initialized
DEBUG - 2017-08-10 16:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:11:16 --> Input Class Initialized
INFO - 2017-08-10 16:11:16 --> Language Class Initialized
INFO - 2017-08-10 16:11:16 --> Loader Class Initialized
INFO - 2017-08-10 16:11:16 --> Helper loaded: common_helper
INFO - 2017-08-10 16:11:16 --> Database Driver Class Initialized
INFO - 2017-08-10 16:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:11:16 --> Email Class Initialized
INFO - 2017-08-10 16:11:16 --> Controller Class Initialized
INFO - 2017-08-10 16:11:16 --> Helper loaded: form_helper
INFO - 2017-08-10 16:11:16 --> Form Validation Class Initialized
INFO - 2017-08-10 16:11:16 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:11:16 --> Helper loaded: url_helper
INFO - 2017-08-10 16:11:16 --> Model Class Initialized
INFO - 2017-08-10 16:11:16 --> Model Class Initialized
INFO - 2017-08-10 16:11:16 --> Model Class Initialized
INFO - 2017-08-10 19:41:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:41:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:41:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:41:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:41:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:41:16 --> Final output sent to browser
DEBUG - 2017-08-10 19:41:16 --> Total execution time: 0.0510
INFO - 2017-08-10 16:11:29 --> Config Class Initialized
INFO - 2017-08-10 16:11:29 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:11:29 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:11:29 --> Utf8 Class Initialized
INFO - 2017-08-10 16:11:29 --> URI Class Initialized
INFO - 2017-08-10 16:11:29 --> Router Class Initialized
INFO - 2017-08-10 16:11:29 --> Output Class Initialized
INFO - 2017-08-10 16:11:29 --> Security Class Initialized
DEBUG - 2017-08-10 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:11:29 --> Input Class Initialized
INFO - 2017-08-10 16:11:29 --> Language Class Initialized
INFO - 2017-08-10 16:11:29 --> Loader Class Initialized
INFO - 2017-08-10 16:11:29 --> Helper loaded: common_helper
INFO - 2017-08-10 16:11:29 --> Database Driver Class Initialized
INFO - 2017-08-10 16:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:11:29 --> Email Class Initialized
INFO - 2017-08-10 16:11:29 --> Controller Class Initialized
INFO - 2017-08-10 16:11:29 --> Helper loaded: form_helper
INFO - 2017-08-10 16:11:29 --> Form Validation Class Initialized
INFO - 2017-08-10 16:11:29 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:11:29 --> Helper loaded: url_helper
INFO - 2017-08-10 16:11:29 --> Model Class Initialized
INFO - 2017-08-10 16:11:29 --> Model Class Initialized
INFO - 2017-08-10 16:11:29 --> Model Class Initialized
INFO - 2017-08-10 16:11:29 --> Config Class Initialized
INFO - 2017-08-10 16:11:29 --> Hooks Class Initialized
DEBUG - 2017-08-10 16:11:29 --> UTF-8 Support Enabled
INFO - 2017-08-10 16:11:29 --> Utf8 Class Initialized
INFO - 2017-08-10 16:11:29 --> URI Class Initialized
INFO - 2017-08-10 16:11:29 --> Router Class Initialized
INFO - 2017-08-10 16:11:29 --> Output Class Initialized
INFO - 2017-08-10 16:11:29 --> Security Class Initialized
DEBUG - 2017-08-10 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-10 16:11:29 --> Input Class Initialized
INFO - 2017-08-10 16:11:29 --> Language Class Initialized
INFO - 2017-08-10 16:11:29 --> Loader Class Initialized
INFO - 2017-08-10 16:11:29 --> Helper loaded: common_helper
INFO - 2017-08-10 16:11:29 --> Database Driver Class Initialized
INFO - 2017-08-10 16:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-10 16:11:29 --> Email Class Initialized
INFO - 2017-08-10 16:11:29 --> Controller Class Initialized
INFO - 2017-08-10 16:11:29 --> Helper loaded: form_helper
INFO - 2017-08-10 16:11:29 --> Form Validation Class Initialized
INFO - 2017-08-10 16:11:29 --> Helper loaded: email_helper
DEBUG - 2017-08-10 16:11:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-10 16:11:29 --> Helper loaded: url_helper
INFO - 2017-08-10 16:11:29 --> Model Class Initialized
INFO - 2017-08-10 16:11:29 --> Model Class Initialized
INFO - 2017-08-10 16:11:29 --> Model Class Initialized
INFO - 2017-08-10 19:41:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-10 19:41:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-10 19:41:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-10 19:41:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-10 19:41:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-10 19:41:29 --> Final output sent to browser
DEBUG - 2017-08-10 19:41:29 --> Total execution time: 0.0517
