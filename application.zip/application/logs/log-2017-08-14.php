<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-08-14 07:43:35 --> Config Class Initialized
INFO - 2017-08-14 07:43:35 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:35 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:35 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:35 --> URI Class Initialized
DEBUG - 2017-08-14 07:43:35 --> No URI present. Default controller set.
INFO - 2017-08-14 07:43:35 --> Router Class Initialized
INFO - 2017-08-14 07:43:35 --> Output Class Initialized
INFO - 2017-08-14 07:43:35 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:35 --> Input Class Initialized
INFO - 2017-08-14 07:43:35 --> Language Class Initialized
INFO - 2017-08-14 07:43:35 --> Loader Class Initialized
INFO - 2017-08-14 07:43:35 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:35 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:36 --> Email Class Initialized
INFO - 2017-08-14 07:43:36 --> Controller Class Initialized
INFO - 2017-08-14 07:43:36 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:36 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:36 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:36 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:36 --> Model Class Initialized
INFO - 2017-08-14 07:43:36 --> Model Class Initialized
INFO - 2017-08-14 07:43:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-08-14 07:43:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 07:43:36 --> Final output sent to browser
DEBUG - 2017-08-14 07:43:36 --> Total execution time: 0.8394
INFO - 2017-08-14 07:43:38 --> Config Class Initialized
INFO - 2017-08-14 07:43:38 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:38 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:38 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:38 --> URI Class Initialized
DEBUG - 2017-08-14 07:43:38 --> No URI present. Default controller set.
INFO - 2017-08-14 07:43:38 --> Router Class Initialized
INFO - 2017-08-14 07:43:38 --> Output Class Initialized
INFO - 2017-08-14 07:43:38 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:38 --> Input Class Initialized
INFO - 2017-08-14 07:43:38 --> Language Class Initialized
INFO - 2017-08-14 07:43:38 --> Loader Class Initialized
INFO - 2017-08-14 07:43:38 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:38 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:38 --> Email Class Initialized
INFO - 2017-08-14 07:43:38 --> Controller Class Initialized
INFO - 2017-08-14 07:43:38 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:38 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:38 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:38 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:38 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:38 --> Model Class Initialized
INFO - 2017-08-14 07:43:38 --> Model Class Initialized
DEBUG - 2017-08-14 07:43:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 07:43:39 --> Config Class Initialized
INFO - 2017-08-14 07:43:39 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:39 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:39 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:39 --> URI Class Initialized
INFO - 2017-08-14 07:43:39 --> Router Class Initialized
INFO - 2017-08-14 07:43:39 --> Output Class Initialized
INFO - 2017-08-14 07:43:39 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:39 --> Input Class Initialized
INFO - 2017-08-14 07:43:39 --> Language Class Initialized
INFO - 2017-08-14 07:43:39 --> Loader Class Initialized
INFO - 2017-08-14 07:43:39 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:39 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:39 --> Email Class Initialized
INFO - 2017-08-14 07:43:39 --> Controller Class Initialized
INFO - 2017-08-14 07:43:39 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:39 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:39 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:39 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:39 --> Model Class Initialized
INFO - 2017-08-14 07:43:39 --> Model Class Initialized
INFO - 2017-08-14 07:43:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 07:43:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 07:43:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-08-14 07:43:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 07:43:39 --> Final output sent to browser
DEBUG - 2017-08-14 07:43:39 --> Total execution time: 0.2382
INFO - 2017-08-14 07:43:40 --> Config Class Initialized
INFO - 2017-08-14 07:43:40 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:40 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:40 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:40 --> URI Class Initialized
INFO - 2017-08-14 07:43:40 --> Router Class Initialized
INFO - 2017-08-14 07:43:40 --> Output Class Initialized
INFO - 2017-08-14 07:43:40 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:40 --> Input Class Initialized
INFO - 2017-08-14 07:43:40 --> Language Class Initialized
INFO - 2017-08-14 07:43:40 --> Loader Class Initialized
INFO - 2017-08-14 07:43:40 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:40 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:40 --> Email Class Initialized
INFO - 2017-08-14 07:43:40 --> Controller Class Initialized
INFO - 2017-08-14 07:43:40 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:40 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:41 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:41 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:41 --> Model Class Initialized
INFO - 2017-08-14 07:43:41 --> Model Class Initialized
INFO - 2017-08-14 11:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-08-14 11:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:13:41 --> Final output sent to browser
DEBUG - 2017-08-14 11:13:41 --> Total execution time: 0.2517
INFO - 2017-08-14 07:43:42 --> Config Class Initialized
INFO - 2017-08-14 07:43:42 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:42 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:42 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:42 --> URI Class Initialized
INFO - 2017-08-14 07:43:42 --> Router Class Initialized
INFO - 2017-08-14 07:43:42 --> Output Class Initialized
INFO - 2017-08-14 07:43:42 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:42 --> Input Class Initialized
INFO - 2017-08-14 07:43:42 --> Language Class Initialized
INFO - 2017-08-14 07:43:42 --> Loader Class Initialized
INFO - 2017-08-14 07:43:42 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:42 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:42 --> Email Class Initialized
INFO - 2017-08-14 07:43:42 --> Controller Class Initialized
INFO - 2017-08-14 07:43:42 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:42 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:42 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:42 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:42 --> Model Class Initialized
INFO - 2017-08-14 07:43:42 --> Model Class Initialized
INFO - 2017-08-14 11:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-08-14 11:13:42 --> Undefined variable: details
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-08-14 11:13:42 --> Undefined variable: details
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-08-14 11:13:42 --> Trying to get property of non-object
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-08-14 11:13:42 --> Undefined variable: details
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-08-14 11:13:42 --> Undefined variable: details
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-08-14 11:13:42 --> Trying to get property of non-object
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-08-14 11:13:42 --> Undefined variable: details
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-08-14 11:13:42 --> Trying to get property of non-object
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-08-14 11:13:42 --> Undefined variable: details
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-08-14 11:13:42 --> Trying to get property of non-object
ERROR - 2017-08-14 11:13:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-08-14 11:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-08-14 11:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:13:42 --> Final output sent to browser
DEBUG - 2017-08-14 11:13:42 --> Total execution time: 0.1484
INFO - 2017-08-14 07:43:45 --> Config Class Initialized
INFO - 2017-08-14 07:43:45 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:45 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:45 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:45 --> URI Class Initialized
INFO - 2017-08-14 07:43:45 --> Router Class Initialized
INFO - 2017-08-14 07:43:45 --> Output Class Initialized
INFO - 2017-08-14 07:43:45 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:45 --> Input Class Initialized
INFO - 2017-08-14 07:43:45 --> Language Class Initialized
INFO - 2017-08-14 07:43:45 --> Loader Class Initialized
INFO - 2017-08-14 07:43:45 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:45 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:45 --> Email Class Initialized
INFO - 2017-08-14 07:43:45 --> Controller Class Initialized
INFO - 2017-08-14 07:43:45 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:45 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:45 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:45 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:45 --> Model Class Initialized
INFO - 2017-08-14 07:43:45 --> Model Class Initialized
INFO - 2017-08-14 11:13:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:13:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:13:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:13:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-08-14 11:13:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:13:45 --> Final output sent to browser
DEBUG - 2017-08-14 11:13:45 --> Total execution time: 0.0591
INFO - 2017-08-14 07:43:47 --> Config Class Initialized
INFO - 2017-08-14 07:43:47 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:47 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:47 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:47 --> URI Class Initialized
INFO - 2017-08-14 07:43:47 --> Router Class Initialized
INFO - 2017-08-14 07:43:47 --> Output Class Initialized
INFO - 2017-08-14 07:43:47 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:47 --> Input Class Initialized
INFO - 2017-08-14 07:43:47 --> Language Class Initialized
INFO - 2017-08-14 07:43:47 --> Loader Class Initialized
INFO - 2017-08-14 07:43:47 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:47 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:47 --> Email Class Initialized
INFO - 2017-08-14 07:43:47 --> Controller Class Initialized
INFO - 2017-08-14 07:43:47 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:47 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:47 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:47 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:47 --> Model Class Initialized
INFO - 2017-08-14 07:43:47 --> Model Class Initialized
INFO - 2017-08-14 11:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:13:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:13:47 --> Final output sent to browser
DEBUG - 2017-08-14 11:13:47 --> Total execution time: 0.0963
INFO - 2017-08-14 07:43:57 --> Config Class Initialized
INFO - 2017-08-14 07:43:57 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:57 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:57 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:57 --> URI Class Initialized
INFO - 2017-08-14 07:43:57 --> Router Class Initialized
INFO - 2017-08-14 07:43:57 --> Output Class Initialized
INFO - 2017-08-14 07:43:57 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:57 --> Input Class Initialized
INFO - 2017-08-14 07:43:57 --> Language Class Initialized
INFO - 2017-08-14 07:43:57 --> Loader Class Initialized
INFO - 2017-08-14 07:43:57 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:57 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:57 --> Email Class Initialized
INFO - 2017-08-14 07:43:57 --> Controller Class Initialized
INFO - 2017-08-14 07:43:57 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:57 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:57 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:57 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:57 --> Model Class Initialized
INFO - 2017-08-14 07:43:57 --> Model Class Initialized
INFO - 2017-08-14 11:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-08-14 11:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:13:57 --> Final output sent to browser
DEBUG - 2017-08-14 11:13:57 --> Total execution time: 0.0765
INFO - 2017-08-14 07:43:59 --> Config Class Initialized
INFO - 2017-08-14 07:43:59 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:43:59 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:43:59 --> Utf8 Class Initialized
INFO - 2017-08-14 07:43:59 --> URI Class Initialized
INFO - 2017-08-14 07:43:59 --> Router Class Initialized
INFO - 2017-08-14 07:43:59 --> Output Class Initialized
INFO - 2017-08-14 07:43:59 --> Security Class Initialized
DEBUG - 2017-08-14 07:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:43:59 --> Input Class Initialized
INFO - 2017-08-14 07:43:59 --> Language Class Initialized
INFO - 2017-08-14 07:43:59 --> Loader Class Initialized
INFO - 2017-08-14 07:43:59 --> Helper loaded: common_helper
INFO - 2017-08-14 07:43:59 --> Database Driver Class Initialized
INFO - 2017-08-14 07:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:43:59 --> Email Class Initialized
INFO - 2017-08-14 07:43:59 --> Controller Class Initialized
INFO - 2017-08-14 07:43:59 --> Helper loaded: form_helper
INFO - 2017-08-14 07:43:59 --> Form Validation Class Initialized
INFO - 2017-08-14 07:43:59 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:43:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:43:59 --> Helper loaded: url_helper
INFO - 2017-08-14 07:43:59 --> Model Class Initialized
INFO - 2017-08-14 07:43:59 --> Model Class Initialized
INFO - 2017-08-14 11:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:13:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:13:59 --> Final output sent to browser
DEBUG - 2017-08-14 11:13:59 --> Total execution time: 0.0927
INFO - 2017-08-14 07:45:21 --> Config Class Initialized
INFO - 2017-08-14 07:45:21 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:45:21 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:45:21 --> Utf8 Class Initialized
INFO - 2017-08-14 07:45:21 --> URI Class Initialized
INFO - 2017-08-14 07:45:21 --> Router Class Initialized
INFO - 2017-08-14 07:45:21 --> Output Class Initialized
INFO - 2017-08-14 07:45:21 --> Security Class Initialized
DEBUG - 2017-08-14 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:45:21 --> Input Class Initialized
INFO - 2017-08-14 07:45:21 --> Language Class Initialized
INFO - 2017-08-14 07:45:21 --> Loader Class Initialized
INFO - 2017-08-14 07:45:21 --> Helper loaded: common_helper
INFO - 2017-08-14 07:45:21 --> Database Driver Class Initialized
INFO - 2017-08-14 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:45:21 --> Email Class Initialized
INFO - 2017-08-14 07:45:21 --> Controller Class Initialized
INFO - 2017-08-14 07:45:21 --> Helper loaded: form_helper
INFO - 2017-08-14 07:45:21 --> Form Validation Class Initialized
INFO - 2017-08-14 07:45:21 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:45:21 --> Helper loaded: url_helper
INFO - 2017-08-14 07:45:21 --> Model Class Initialized
INFO - 2017-08-14 07:45:21 --> Model Class Initialized
INFO - 2017-08-14 11:15:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:15:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:15:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:15:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:15:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:15:21 --> Final output sent to browser
DEBUG - 2017-08-14 11:15:21 --> Total execution time: 0.0527
INFO - 2017-08-14 07:45:51 --> Config Class Initialized
INFO - 2017-08-14 07:45:51 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:45:51 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:45:51 --> Utf8 Class Initialized
INFO - 2017-08-14 07:45:51 --> URI Class Initialized
INFO - 2017-08-14 07:45:51 --> Router Class Initialized
INFO - 2017-08-14 07:45:51 --> Output Class Initialized
INFO - 2017-08-14 07:45:51 --> Security Class Initialized
DEBUG - 2017-08-14 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:45:51 --> Input Class Initialized
INFO - 2017-08-14 07:45:51 --> Language Class Initialized
INFO - 2017-08-14 07:45:51 --> Loader Class Initialized
INFO - 2017-08-14 07:45:51 --> Helper loaded: common_helper
INFO - 2017-08-14 07:45:51 --> Database Driver Class Initialized
INFO - 2017-08-14 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:45:51 --> Email Class Initialized
INFO - 2017-08-14 07:45:51 --> Controller Class Initialized
INFO - 2017-08-14 07:45:51 --> Helper loaded: form_helper
INFO - 2017-08-14 07:45:51 --> Form Validation Class Initialized
INFO - 2017-08-14 07:45:51 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:45:51 --> Helper loaded: url_helper
INFO - 2017-08-14 07:45:51 --> Model Class Initialized
INFO - 2017-08-14 07:45:51 --> Model Class Initialized
INFO - 2017-08-14 11:15:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:15:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:15:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:15:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:15:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:15:51 --> Final output sent to browser
DEBUG - 2017-08-14 11:15:51 --> Total execution time: 0.0670
INFO - 2017-08-14 07:46:06 --> Config Class Initialized
INFO - 2017-08-14 07:46:06 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:46:06 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:46:06 --> Utf8 Class Initialized
INFO - 2017-08-14 07:46:06 --> URI Class Initialized
INFO - 2017-08-14 07:46:06 --> Router Class Initialized
INFO - 2017-08-14 07:46:06 --> Output Class Initialized
INFO - 2017-08-14 07:46:06 --> Security Class Initialized
DEBUG - 2017-08-14 07:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:46:06 --> Input Class Initialized
INFO - 2017-08-14 07:46:06 --> Language Class Initialized
INFO - 2017-08-14 07:46:06 --> Loader Class Initialized
INFO - 2017-08-14 07:46:06 --> Helper loaded: common_helper
INFO - 2017-08-14 07:46:06 --> Database Driver Class Initialized
INFO - 2017-08-14 07:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:46:06 --> Email Class Initialized
INFO - 2017-08-14 07:46:06 --> Controller Class Initialized
INFO - 2017-08-14 07:46:06 --> Helper loaded: form_helper
INFO - 2017-08-14 07:46:06 --> Form Validation Class Initialized
INFO - 2017-08-14 07:46:06 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:46:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:46:06 --> Helper loaded: url_helper
INFO - 2017-08-14 07:46:06 --> Model Class Initialized
INFO - 2017-08-14 07:46:06 --> Model Class Initialized
INFO - 2017-08-14 11:16:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:16:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:16:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:16:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:16:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:16:06 --> Final output sent to browser
DEBUG - 2017-08-14 11:16:06 --> Total execution time: 0.0513
INFO - 2017-08-14 07:46:07 --> Config Class Initialized
INFO - 2017-08-14 07:46:07 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:46:07 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:46:07 --> Utf8 Class Initialized
INFO - 2017-08-14 07:46:07 --> URI Class Initialized
INFO - 2017-08-14 07:46:07 --> Router Class Initialized
INFO - 2017-08-14 07:46:07 --> Output Class Initialized
INFO - 2017-08-14 07:46:07 --> Security Class Initialized
DEBUG - 2017-08-14 07:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:46:07 --> Input Class Initialized
INFO - 2017-08-14 07:46:07 --> Language Class Initialized
INFO - 2017-08-14 07:46:07 --> Loader Class Initialized
INFO - 2017-08-14 07:46:07 --> Helper loaded: common_helper
INFO - 2017-08-14 07:46:07 --> Database Driver Class Initialized
INFO - 2017-08-14 07:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:46:07 --> Email Class Initialized
INFO - 2017-08-14 07:46:07 --> Controller Class Initialized
INFO - 2017-08-14 07:46:07 --> Helper loaded: form_helper
INFO - 2017-08-14 07:46:07 --> Form Validation Class Initialized
INFO - 2017-08-14 07:46:07 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:46:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:46:07 --> Helper loaded: url_helper
INFO - 2017-08-14 07:46:07 --> Model Class Initialized
INFO - 2017-08-14 07:46:07 --> Model Class Initialized
INFO - 2017-08-14 11:16:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:16:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:16:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:16:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:16:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:16:07 --> Final output sent to browser
DEBUG - 2017-08-14 11:16:07 --> Total execution time: 0.0630
INFO - 2017-08-14 07:47:06 --> Config Class Initialized
INFO - 2017-08-14 07:47:06 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:47:06 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:47:06 --> Utf8 Class Initialized
INFO - 2017-08-14 07:47:06 --> URI Class Initialized
INFO - 2017-08-14 07:47:06 --> Router Class Initialized
INFO - 2017-08-14 07:47:06 --> Output Class Initialized
INFO - 2017-08-14 07:47:06 --> Security Class Initialized
DEBUG - 2017-08-14 07:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:47:06 --> Input Class Initialized
INFO - 2017-08-14 07:47:06 --> Language Class Initialized
INFO - 2017-08-14 07:47:06 --> Loader Class Initialized
INFO - 2017-08-14 07:47:06 --> Helper loaded: common_helper
INFO - 2017-08-14 07:47:06 --> Database Driver Class Initialized
INFO - 2017-08-14 07:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:47:06 --> Email Class Initialized
INFO - 2017-08-14 07:47:06 --> Controller Class Initialized
INFO - 2017-08-14 07:47:06 --> Helper loaded: form_helper
INFO - 2017-08-14 07:47:06 --> Form Validation Class Initialized
INFO - 2017-08-14 07:47:06 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:47:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:47:06 --> Helper loaded: url_helper
INFO - 2017-08-14 07:47:06 --> Model Class Initialized
INFO - 2017-08-14 07:47:06 --> Model Class Initialized
INFO - 2017-08-14 11:17:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:17:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:17:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:17:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:17:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:17:06 --> Final output sent to browser
DEBUG - 2017-08-14 11:17:06 --> Total execution time: 0.0552
INFO - 2017-08-14 07:47:21 --> Config Class Initialized
INFO - 2017-08-14 07:47:21 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:47:21 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:47:21 --> Utf8 Class Initialized
INFO - 2017-08-14 07:47:21 --> URI Class Initialized
INFO - 2017-08-14 07:47:21 --> Router Class Initialized
INFO - 2017-08-14 07:47:21 --> Output Class Initialized
INFO - 2017-08-14 07:47:21 --> Security Class Initialized
DEBUG - 2017-08-14 07:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:47:21 --> Input Class Initialized
INFO - 2017-08-14 07:47:21 --> Language Class Initialized
INFO - 2017-08-14 07:47:21 --> Loader Class Initialized
INFO - 2017-08-14 07:47:21 --> Helper loaded: common_helper
INFO - 2017-08-14 07:47:21 --> Database Driver Class Initialized
INFO - 2017-08-14 07:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:47:21 --> Email Class Initialized
INFO - 2017-08-14 07:47:21 --> Controller Class Initialized
INFO - 2017-08-14 07:47:21 --> Helper loaded: form_helper
INFO - 2017-08-14 07:47:21 --> Form Validation Class Initialized
INFO - 2017-08-14 07:47:21 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:47:21 --> Helper loaded: url_helper
INFO - 2017-08-14 07:47:21 --> Model Class Initialized
INFO - 2017-08-14 07:47:21 --> Model Class Initialized
INFO - 2017-08-14 11:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:17:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:17:21 --> Final output sent to browser
DEBUG - 2017-08-14 11:17:21 --> Total execution time: 0.0572
INFO - 2017-08-14 07:47:50 --> Config Class Initialized
INFO - 2017-08-14 07:47:50 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:47:50 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:47:50 --> Utf8 Class Initialized
INFO - 2017-08-14 07:47:50 --> URI Class Initialized
INFO - 2017-08-14 07:47:50 --> Router Class Initialized
INFO - 2017-08-14 07:47:50 --> Output Class Initialized
INFO - 2017-08-14 07:47:50 --> Security Class Initialized
DEBUG - 2017-08-14 07:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:47:50 --> Input Class Initialized
INFO - 2017-08-14 07:47:50 --> Language Class Initialized
INFO - 2017-08-14 07:47:50 --> Loader Class Initialized
INFO - 2017-08-14 07:47:50 --> Helper loaded: common_helper
INFO - 2017-08-14 07:47:50 --> Database Driver Class Initialized
INFO - 2017-08-14 07:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:47:50 --> Email Class Initialized
INFO - 2017-08-14 07:47:50 --> Controller Class Initialized
INFO - 2017-08-14 07:47:50 --> Helper loaded: form_helper
INFO - 2017-08-14 07:47:50 --> Form Validation Class Initialized
INFO - 2017-08-14 07:47:50 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:47:50 --> Helper loaded: url_helper
INFO - 2017-08-14 07:47:50 --> Model Class Initialized
INFO - 2017-08-14 07:47:50 --> Model Class Initialized
INFO - 2017-08-14 11:17:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:17:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:17:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:17:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:17:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:17:50 --> Final output sent to browser
DEBUG - 2017-08-14 11:17:50 --> Total execution time: 0.0774
INFO - 2017-08-14 07:48:11 --> Config Class Initialized
INFO - 2017-08-14 07:48:11 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:48:11 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:48:11 --> Utf8 Class Initialized
INFO - 2017-08-14 07:48:11 --> URI Class Initialized
INFO - 2017-08-14 07:48:11 --> Router Class Initialized
INFO - 2017-08-14 07:48:11 --> Output Class Initialized
INFO - 2017-08-14 07:48:11 --> Security Class Initialized
DEBUG - 2017-08-14 07:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:48:11 --> Input Class Initialized
INFO - 2017-08-14 07:48:11 --> Language Class Initialized
INFO - 2017-08-14 07:48:11 --> Loader Class Initialized
INFO - 2017-08-14 07:48:11 --> Helper loaded: common_helper
INFO - 2017-08-14 07:48:11 --> Database Driver Class Initialized
INFO - 2017-08-14 07:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:48:11 --> Email Class Initialized
INFO - 2017-08-14 07:48:11 --> Controller Class Initialized
INFO - 2017-08-14 07:48:11 --> Helper loaded: form_helper
INFO - 2017-08-14 07:48:11 --> Form Validation Class Initialized
INFO - 2017-08-14 07:48:11 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:48:11 --> Helper loaded: url_helper
INFO - 2017-08-14 07:48:11 --> Model Class Initialized
INFO - 2017-08-14 07:48:11 --> Model Class Initialized
INFO - 2017-08-14 11:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:18:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:18:11 --> Final output sent to browser
DEBUG - 2017-08-14 11:18:11 --> Total execution time: 0.0706
INFO - 2017-08-14 07:48:43 --> Config Class Initialized
INFO - 2017-08-14 07:48:43 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:48:43 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:48:43 --> Utf8 Class Initialized
INFO - 2017-08-14 07:48:43 --> URI Class Initialized
INFO - 2017-08-14 07:48:43 --> Router Class Initialized
INFO - 2017-08-14 07:48:43 --> Output Class Initialized
INFO - 2017-08-14 07:48:43 --> Security Class Initialized
DEBUG - 2017-08-14 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:48:43 --> Input Class Initialized
INFO - 2017-08-14 07:48:43 --> Language Class Initialized
INFO - 2017-08-14 07:48:43 --> Loader Class Initialized
INFO - 2017-08-14 07:48:43 --> Helper loaded: common_helper
INFO - 2017-08-14 07:48:43 --> Database Driver Class Initialized
INFO - 2017-08-14 07:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:48:43 --> Email Class Initialized
INFO - 2017-08-14 07:48:43 --> Controller Class Initialized
INFO - 2017-08-14 07:48:43 --> Helper loaded: form_helper
INFO - 2017-08-14 07:48:43 --> Form Validation Class Initialized
INFO - 2017-08-14 07:48:43 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:48:43 --> Helper loaded: url_helper
INFO - 2017-08-14 07:48:43 --> Model Class Initialized
INFO - 2017-08-14 07:48:43 --> Model Class Initialized
INFO - 2017-08-14 11:18:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:18:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:18:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:18:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:18:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:18:43 --> Final output sent to browser
DEBUG - 2017-08-14 11:18:43 --> Total execution time: 0.0532
INFO - 2017-08-14 07:50:48 --> Config Class Initialized
INFO - 2017-08-14 07:50:48 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:50:48 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:50:48 --> Utf8 Class Initialized
INFO - 2017-08-14 07:50:48 --> URI Class Initialized
INFO - 2017-08-14 07:50:48 --> Router Class Initialized
INFO - 2017-08-14 07:50:48 --> Output Class Initialized
INFO - 2017-08-14 07:50:48 --> Security Class Initialized
DEBUG - 2017-08-14 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:50:48 --> Input Class Initialized
INFO - 2017-08-14 07:50:48 --> Language Class Initialized
INFO - 2017-08-14 07:50:48 --> Loader Class Initialized
INFO - 2017-08-14 07:50:48 --> Helper loaded: common_helper
INFO - 2017-08-14 07:50:48 --> Database Driver Class Initialized
INFO - 2017-08-14 07:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:50:48 --> Email Class Initialized
INFO - 2017-08-14 07:50:48 --> Controller Class Initialized
INFO - 2017-08-14 07:50:48 --> Helper loaded: form_helper
INFO - 2017-08-14 07:50:48 --> Form Validation Class Initialized
INFO - 2017-08-14 07:50:48 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:50:48 --> Helper loaded: url_helper
INFO - 2017-08-14 07:50:48 --> Model Class Initialized
INFO - 2017-08-14 07:50:48 --> Model Class Initialized
INFO - 2017-08-14 11:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addBarChartVlues.php
INFO - 2017-08-14 11:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:20:48 --> Final output sent to browser
DEBUG - 2017-08-14 11:20:48 --> Total execution time: 0.0636
INFO - 2017-08-14 07:50:50 --> Config Class Initialized
INFO - 2017-08-14 07:50:50 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:50:50 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:50:50 --> Utf8 Class Initialized
INFO - 2017-08-14 07:50:50 --> URI Class Initialized
INFO - 2017-08-14 07:50:50 --> Router Class Initialized
INFO - 2017-08-14 07:50:50 --> Output Class Initialized
INFO - 2017-08-14 07:50:50 --> Security Class Initialized
DEBUG - 2017-08-14 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:50:50 --> Input Class Initialized
INFO - 2017-08-14 07:50:50 --> Language Class Initialized
INFO - 2017-08-14 07:50:50 --> Loader Class Initialized
INFO - 2017-08-14 07:50:50 --> Helper loaded: common_helper
INFO - 2017-08-14 07:50:50 --> Database Driver Class Initialized
INFO - 2017-08-14 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:50:50 --> Email Class Initialized
INFO - 2017-08-14 07:50:50 --> Controller Class Initialized
INFO - 2017-08-14 07:50:50 --> Helper loaded: form_helper
INFO - 2017-08-14 07:50:50 --> Form Validation Class Initialized
INFO - 2017-08-14 07:50:50 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:50:50 --> Helper loaded: url_helper
INFO - 2017-08-14 07:50:50 --> Model Class Initialized
INFO - 2017-08-14 07:50:50 --> Model Class Initialized
INFO - 2017-08-14 11:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-08-14 11:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:20:50 --> Final output sent to browser
DEBUG - 2017-08-14 11:20:50 --> Total execution time: 0.0584
INFO - 2017-08-14 07:50:53 --> Config Class Initialized
INFO - 2017-08-14 07:50:53 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:50:53 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:50:53 --> Utf8 Class Initialized
INFO - 2017-08-14 07:50:53 --> URI Class Initialized
INFO - 2017-08-14 07:50:53 --> Router Class Initialized
INFO - 2017-08-14 07:50:53 --> Output Class Initialized
INFO - 2017-08-14 07:50:53 --> Security Class Initialized
DEBUG - 2017-08-14 07:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:50:53 --> Input Class Initialized
INFO - 2017-08-14 07:50:53 --> Language Class Initialized
INFO - 2017-08-14 07:50:53 --> Loader Class Initialized
INFO - 2017-08-14 07:50:53 --> Helper loaded: common_helper
INFO - 2017-08-14 07:50:53 --> Database Driver Class Initialized
INFO - 2017-08-14 07:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:50:53 --> Email Class Initialized
INFO - 2017-08-14 07:50:53 --> Controller Class Initialized
INFO - 2017-08-14 07:50:53 --> Helper loaded: form_helper
INFO - 2017-08-14 07:50:53 --> Form Validation Class Initialized
INFO - 2017-08-14 07:50:53 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:50:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:50:53 --> Helper loaded: url_helper
INFO - 2017-08-14 07:50:53 --> Model Class Initialized
INFO - 2017-08-14 07:50:53 --> Model Class Initialized
INFO - 2017-08-14 11:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:20:53 --> Final output sent to browser
DEBUG - 2017-08-14 11:20:53 --> Total execution time: 0.0637
INFO - 2017-08-14 07:51:08 --> Config Class Initialized
INFO - 2017-08-14 07:51:08 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:51:08 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:51:08 --> Utf8 Class Initialized
INFO - 2017-08-14 07:51:08 --> URI Class Initialized
INFO - 2017-08-14 07:51:08 --> Router Class Initialized
INFO - 2017-08-14 07:51:08 --> Output Class Initialized
INFO - 2017-08-14 07:51:08 --> Security Class Initialized
DEBUG - 2017-08-14 07:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:51:08 --> Input Class Initialized
INFO - 2017-08-14 07:51:08 --> Language Class Initialized
INFO - 2017-08-14 07:51:08 --> Loader Class Initialized
INFO - 2017-08-14 07:51:08 --> Helper loaded: common_helper
INFO - 2017-08-14 07:51:08 --> Database Driver Class Initialized
INFO - 2017-08-14 07:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:51:08 --> Email Class Initialized
INFO - 2017-08-14 07:51:08 --> Controller Class Initialized
INFO - 2017-08-14 07:51:08 --> Helper loaded: form_helper
INFO - 2017-08-14 07:51:08 --> Form Validation Class Initialized
INFO - 2017-08-14 07:51:08 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:51:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:51:08 --> Helper loaded: url_helper
INFO - 2017-08-14 07:51:08 --> Model Class Initialized
INFO - 2017-08-14 07:51:08 --> Model Class Initialized
INFO - 2017-08-14 11:21:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:21:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:21:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:21:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:21:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:21:08 --> Final output sent to browser
DEBUG - 2017-08-14 11:21:08 --> Total execution time: 0.0955
INFO - 2017-08-14 07:51:58 --> Config Class Initialized
INFO - 2017-08-14 07:51:58 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:51:58 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:51:58 --> Utf8 Class Initialized
INFO - 2017-08-14 07:51:58 --> URI Class Initialized
INFO - 2017-08-14 07:51:58 --> Router Class Initialized
INFO - 2017-08-14 07:51:58 --> Output Class Initialized
INFO - 2017-08-14 07:51:58 --> Security Class Initialized
DEBUG - 2017-08-14 07:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:51:58 --> Input Class Initialized
INFO - 2017-08-14 07:51:58 --> Language Class Initialized
INFO - 2017-08-14 07:51:58 --> Loader Class Initialized
INFO - 2017-08-14 07:51:58 --> Helper loaded: common_helper
INFO - 2017-08-14 07:51:58 --> Database Driver Class Initialized
INFO - 2017-08-14 07:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:51:58 --> Email Class Initialized
INFO - 2017-08-14 07:51:58 --> Controller Class Initialized
INFO - 2017-08-14 07:51:58 --> Helper loaded: form_helper
INFO - 2017-08-14 07:51:58 --> Form Validation Class Initialized
INFO - 2017-08-14 07:51:58 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:51:58 --> Helper loaded: url_helper
INFO - 2017-08-14 07:51:58 --> Model Class Initialized
INFO - 2017-08-14 07:51:58 --> Model Class Initialized
INFO - 2017-08-14 11:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:21:58 --> Final output sent to browser
DEBUG - 2017-08-14 11:21:58 --> Total execution time: 0.0502
INFO - 2017-08-14 07:55:51 --> Config Class Initialized
INFO - 2017-08-14 07:55:51 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:55:51 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:55:51 --> Utf8 Class Initialized
INFO - 2017-08-14 07:55:51 --> URI Class Initialized
INFO - 2017-08-14 07:55:51 --> Router Class Initialized
INFO - 2017-08-14 07:55:51 --> Output Class Initialized
INFO - 2017-08-14 07:55:51 --> Security Class Initialized
DEBUG - 2017-08-14 07:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:55:51 --> Input Class Initialized
INFO - 2017-08-14 07:55:51 --> Language Class Initialized
INFO - 2017-08-14 07:55:51 --> Loader Class Initialized
INFO - 2017-08-14 07:55:51 --> Helper loaded: common_helper
INFO - 2017-08-14 07:55:51 --> Database Driver Class Initialized
INFO - 2017-08-14 07:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:55:51 --> Email Class Initialized
INFO - 2017-08-14 07:55:51 --> Controller Class Initialized
INFO - 2017-08-14 07:55:51 --> Helper loaded: form_helper
INFO - 2017-08-14 07:55:51 --> Form Validation Class Initialized
INFO - 2017-08-14 07:55:51 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:55:51 --> Helper loaded: url_helper
INFO - 2017-08-14 07:55:51 --> Model Class Initialized
INFO - 2017-08-14 07:55:51 --> Model Class Initialized
INFO - 2017-08-14 11:25:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:25:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:25:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:25:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:25:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:25:51 --> Final output sent to browser
DEBUG - 2017-08-14 11:25:51 --> Total execution time: 0.0506
INFO - 2017-08-14 07:56:06 --> Config Class Initialized
INFO - 2017-08-14 07:56:06 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:56:06 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:56:06 --> Utf8 Class Initialized
INFO - 2017-08-14 07:56:06 --> URI Class Initialized
INFO - 2017-08-14 07:56:06 --> Router Class Initialized
INFO - 2017-08-14 07:56:06 --> Output Class Initialized
INFO - 2017-08-14 07:56:07 --> Security Class Initialized
DEBUG - 2017-08-14 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:56:07 --> Input Class Initialized
INFO - 2017-08-14 07:56:07 --> Language Class Initialized
INFO - 2017-08-14 07:56:07 --> Loader Class Initialized
INFO - 2017-08-14 07:56:07 --> Helper loaded: common_helper
INFO - 2017-08-14 07:56:07 --> Database Driver Class Initialized
INFO - 2017-08-14 07:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:56:07 --> Email Class Initialized
INFO - 2017-08-14 07:56:07 --> Controller Class Initialized
INFO - 2017-08-14 07:56:07 --> Helper loaded: form_helper
INFO - 2017-08-14 07:56:07 --> Form Validation Class Initialized
INFO - 2017-08-14 07:56:07 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:56:07 --> Helper loaded: url_helper
INFO - 2017-08-14 07:56:07 --> Model Class Initialized
INFO - 2017-08-14 07:56:07 --> Model Class Initialized
INFO - 2017-08-14 11:26:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:26:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:26:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:26:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:26:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:26:07 --> Final output sent to browser
DEBUG - 2017-08-14 11:26:07 --> Total execution time: 0.0947
INFO - 2017-08-14 07:57:12 --> Config Class Initialized
INFO - 2017-08-14 07:57:12 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:57:12 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:57:12 --> Utf8 Class Initialized
INFO - 2017-08-14 07:57:12 --> URI Class Initialized
INFO - 2017-08-14 07:57:12 --> Router Class Initialized
INFO - 2017-08-14 07:57:12 --> Output Class Initialized
INFO - 2017-08-14 07:57:12 --> Security Class Initialized
DEBUG - 2017-08-14 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:57:12 --> Input Class Initialized
INFO - 2017-08-14 07:57:12 --> Language Class Initialized
INFO - 2017-08-14 07:57:12 --> Loader Class Initialized
INFO - 2017-08-14 07:57:12 --> Helper loaded: common_helper
INFO - 2017-08-14 07:57:12 --> Database Driver Class Initialized
INFO - 2017-08-14 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:57:12 --> Email Class Initialized
INFO - 2017-08-14 07:57:12 --> Controller Class Initialized
INFO - 2017-08-14 07:57:12 --> Helper loaded: form_helper
INFO - 2017-08-14 07:57:12 --> Form Validation Class Initialized
INFO - 2017-08-14 07:57:12 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:57:12 --> Helper loaded: url_helper
INFO - 2017-08-14 07:57:12 --> Model Class Initialized
INFO - 2017-08-14 07:57:12 --> Model Class Initialized
INFO - 2017-08-14 11:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:27:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:27:12 --> Final output sent to browser
DEBUG - 2017-08-14 11:27:12 --> Total execution time: 0.0581
INFO - 2017-08-14 07:57:26 --> Config Class Initialized
INFO - 2017-08-14 07:57:26 --> Hooks Class Initialized
DEBUG - 2017-08-14 07:57:26 --> UTF-8 Support Enabled
INFO - 2017-08-14 07:57:26 --> Utf8 Class Initialized
INFO - 2017-08-14 07:57:26 --> URI Class Initialized
INFO - 2017-08-14 07:57:26 --> Router Class Initialized
INFO - 2017-08-14 07:57:26 --> Output Class Initialized
INFO - 2017-08-14 07:57:26 --> Security Class Initialized
DEBUG - 2017-08-14 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 07:57:26 --> Input Class Initialized
INFO - 2017-08-14 07:57:26 --> Language Class Initialized
INFO - 2017-08-14 07:57:26 --> Loader Class Initialized
INFO - 2017-08-14 07:57:26 --> Helper loaded: common_helper
INFO - 2017-08-14 07:57:26 --> Database Driver Class Initialized
INFO - 2017-08-14 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 07:57:26 --> Email Class Initialized
INFO - 2017-08-14 07:57:26 --> Controller Class Initialized
INFO - 2017-08-14 07:57:26 --> Helper loaded: form_helper
INFO - 2017-08-14 07:57:26 --> Form Validation Class Initialized
INFO - 2017-08-14 07:57:26 --> Helper loaded: email_helper
DEBUG - 2017-08-14 07:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 07:57:26 --> Helper loaded: url_helper
INFO - 2017-08-14 07:57:26 --> Model Class Initialized
INFO - 2017-08-14 07:57:26 --> Model Class Initialized
INFO - 2017-08-14 11:27:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:27:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:27:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-08-14 11:27:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:27:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:27:26 --> Final output sent to browser
DEBUG - 2017-08-14 11:27:26 --> Total execution time: 0.0699
INFO - 2017-08-14 08:18:45 --> Config Class Initialized
INFO - 2017-08-14 08:18:45 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:18:45 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:18:45 --> Utf8 Class Initialized
INFO - 2017-08-14 08:18:45 --> URI Class Initialized
INFO - 2017-08-14 08:18:45 --> Router Class Initialized
INFO - 2017-08-14 08:18:45 --> Output Class Initialized
INFO - 2017-08-14 08:18:45 --> Security Class Initialized
DEBUG - 2017-08-14 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:18:45 --> Input Class Initialized
INFO - 2017-08-14 08:18:45 --> Language Class Initialized
INFO - 2017-08-14 08:18:45 --> Loader Class Initialized
INFO - 2017-08-14 08:18:45 --> Helper loaded: common_helper
INFO - 2017-08-14 08:18:45 --> Database Driver Class Initialized
INFO - 2017-08-14 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:18:45 --> Email Class Initialized
INFO - 2017-08-14 08:18:45 --> Controller Class Initialized
INFO - 2017-08-14 08:18:45 --> Helper loaded: form_helper
INFO - 2017-08-14 08:18:45 --> Form Validation Class Initialized
INFO - 2017-08-14 08:18:45 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:18:45 --> Helper loaded: url_helper
INFO - 2017-08-14 08:18:45 --> Model Class Initialized
INFO - 2017-08-14 08:18:45 --> Model Class Initialized
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:48:45 --> Final output sent to browser
DEBUG - 2017-08-14 11:48:45 --> Total execution time: 0.0859
INFO - 2017-08-14 08:18:45 --> Config Class Initialized
INFO - 2017-08-14 08:18:45 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:18:45 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:18:45 --> Utf8 Class Initialized
INFO - 2017-08-14 08:18:45 --> URI Class Initialized
INFO - 2017-08-14 08:18:45 --> Router Class Initialized
INFO - 2017-08-14 08:18:45 --> Output Class Initialized
INFO - 2017-08-14 08:18:45 --> Security Class Initialized
DEBUG - 2017-08-14 08:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:18:45 --> Input Class Initialized
INFO - 2017-08-14 08:18:45 --> Language Class Initialized
INFO - 2017-08-14 08:18:45 --> Loader Class Initialized
INFO - 2017-08-14 08:18:45 --> Helper loaded: common_helper
INFO - 2017-08-14 08:18:45 --> Database Driver Class Initialized
INFO - 2017-08-14 08:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:18:45 --> Email Class Initialized
INFO - 2017-08-14 08:18:45 --> Controller Class Initialized
INFO - 2017-08-14 08:18:45 --> Helper loaded: form_helper
INFO - 2017-08-14 08:18:45 --> Form Validation Class Initialized
INFO - 2017-08-14 08:18:45 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:18:45 --> Helper loaded: url_helper
INFO - 2017-08-14 08:18:45 --> Model Class Initialized
INFO - 2017-08-14 08:18:45 --> Model Class Initialized
INFO - 2017-08-14 08:18:45 --> Model Class Initialized
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 11:48:45 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 11:48:45 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 11:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:48:45 --> Final output sent to browser
DEBUG - 2017-08-14 11:48:45 --> Total execution time: 0.2129
INFO - 2017-08-14 08:18:47 --> Config Class Initialized
INFO - 2017-08-14 08:18:47 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:18:47 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:18:47 --> Utf8 Class Initialized
INFO - 2017-08-14 08:18:47 --> URI Class Initialized
INFO - 2017-08-14 08:18:47 --> Router Class Initialized
INFO - 2017-08-14 08:18:47 --> Output Class Initialized
INFO - 2017-08-14 08:18:47 --> Security Class Initialized
DEBUG - 2017-08-14 08:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:18:47 --> Input Class Initialized
INFO - 2017-08-14 08:18:47 --> Language Class Initialized
INFO - 2017-08-14 08:18:47 --> Loader Class Initialized
INFO - 2017-08-14 08:18:47 --> Helper loaded: common_helper
INFO - 2017-08-14 08:18:47 --> Database Driver Class Initialized
INFO - 2017-08-14 08:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:18:47 --> Email Class Initialized
INFO - 2017-08-14 08:18:47 --> Controller Class Initialized
INFO - 2017-08-14 08:18:47 --> Helper loaded: form_helper
INFO - 2017-08-14 08:18:47 --> Form Validation Class Initialized
INFO - 2017-08-14 08:18:47 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:18:47 --> Helper loaded: url_helper
INFO - 2017-08-14 08:18:47 --> Model Class Initialized
INFO - 2017-08-14 08:18:47 --> Model Class Initialized
INFO - 2017-08-14 08:18:47 --> Model Class Initialized
INFO - 2017-08-14 11:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:48:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:48:47 --> Final output sent to browser
DEBUG - 2017-08-14 11:48:47 --> Total execution time: 0.0622
INFO - 2017-08-14 08:22:07 --> Config Class Initialized
INFO - 2017-08-14 08:22:07 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:22:07 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:22:07 --> Utf8 Class Initialized
INFO - 2017-08-14 08:22:07 --> URI Class Initialized
INFO - 2017-08-14 08:22:07 --> Router Class Initialized
INFO - 2017-08-14 08:22:07 --> Output Class Initialized
INFO - 2017-08-14 08:22:07 --> Security Class Initialized
DEBUG - 2017-08-14 08:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:22:07 --> Input Class Initialized
INFO - 2017-08-14 08:22:07 --> Language Class Initialized
INFO - 2017-08-14 08:22:07 --> Loader Class Initialized
INFO - 2017-08-14 08:22:07 --> Helper loaded: common_helper
INFO - 2017-08-14 08:22:07 --> Database Driver Class Initialized
INFO - 2017-08-14 08:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:22:07 --> Email Class Initialized
INFO - 2017-08-14 08:22:07 --> Controller Class Initialized
INFO - 2017-08-14 08:22:07 --> Helper loaded: form_helper
INFO - 2017-08-14 08:22:07 --> Form Validation Class Initialized
INFO - 2017-08-14 08:22:07 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:22:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:22:07 --> Helper loaded: url_helper
INFO - 2017-08-14 08:22:07 --> Model Class Initialized
INFO - 2017-08-14 08:22:07 --> Model Class Initialized
INFO - 2017-08-14 08:22:07 --> Model Class Initialized
INFO - 2017-08-14 11:52:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:52:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:52:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:52:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:52:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:52:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:52:07 --> Final output sent to browser
DEBUG - 2017-08-14 11:52:07 --> Total execution time: 0.0512
INFO - 2017-08-14 08:22:15 --> Config Class Initialized
INFO - 2017-08-14 08:22:15 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:22:15 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:22:15 --> Utf8 Class Initialized
INFO - 2017-08-14 08:22:15 --> URI Class Initialized
INFO - 2017-08-14 08:22:15 --> Router Class Initialized
INFO - 2017-08-14 08:22:15 --> Output Class Initialized
INFO - 2017-08-14 08:22:15 --> Security Class Initialized
DEBUG - 2017-08-14 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:22:15 --> Input Class Initialized
INFO - 2017-08-14 08:22:15 --> Language Class Initialized
INFO - 2017-08-14 08:22:15 --> Loader Class Initialized
INFO - 2017-08-14 08:22:15 --> Helper loaded: common_helper
INFO - 2017-08-14 08:22:15 --> Database Driver Class Initialized
INFO - 2017-08-14 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:22:15 --> Email Class Initialized
INFO - 2017-08-14 08:22:15 --> Controller Class Initialized
INFO - 2017-08-14 08:22:15 --> Helper loaded: form_helper
INFO - 2017-08-14 08:22:15 --> Form Validation Class Initialized
INFO - 2017-08-14 08:22:15 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:22:15 --> Helper loaded: url_helper
INFO - 2017-08-14 08:22:15 --> Model Class Initialized
INFO - 2017-08-14 08:22:15 --> Model Class Initialized
INFO - 2017-08-14 08:22:15 --> Model Class Initialized
INFO - 2017-08-14 11:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:52:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:52:15 --> Final output sent to browser
DEBUG - 2017-08-14 11:52:15 --> Total execution time: 0.0651
INFO - 2017-08-14 08:22:36 --> Config Class Initialized
INFO - 2017-08-14 08:22:36 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:22:36 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:22:36 --> Utf8 Class Initialized
INFO - 2017-08-14 08:22:36 --> URI Class Initialized
INFO - 2017-08-14 08:22:36 --> Router Class Initialized
INFO - 2017-08-14 08:22:36 --> Output Class Initialized
INFO - 2017-08-14 08:22:36 --> Security Class Initialized
DEBUG - 2017-08-14 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:22:36 --> Input Class Initialized
INFO - 2017-08-14 08:22:36 --> Language Class Initialized
INFO - 2017-08-14 08:22:36 --> Loader Class Initialized
INFO - 2017-08-14 08:22:36 --> Helper loaded: common_helper
INFO - 2017-08-14 08:22:36 --> Database Driver Class Initialized
INFO - 2017-08-14 08:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:22:36 --> Email Class Initialized
INFO - 2017-08-14 08:22:36 --> Controller Class Initialized
INFO - 2017-08-14 08:22:36 --> Helper loaded: form_helper
INFO - 2017-08-14 08:22:36 --> Form Validation Class Initialized
INFO - 2017-08-14 08:22:36 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:22:36 --> Helper loaded: url_helper
INFO - 2017-08-14 08:22:36 --> Model Class Initialized
INFO - 2017-08-14 08:22:36 --> Model Class Initialized
INFO - 2017-08-14 08:22:36 --> Model Class Initialized
INFO - 2017-08-14 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:52:36 --> Final output sent to browser
DEBUG - 2017-08-14 11:52:36 --> Total execution time: 0.0558
INFO - 2017-08-14 08:23:08 --> Config Class Initialized
INFO - 2017-08-14 08:23:08 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:23:08 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:23:08 --> Utf8 Class Initialized
INFO - 2017-08-14 08:23:08 --> URI Class Initialized
INFO - 2017-08-14 08:23:08 --> Router Class Initialized
INFO - 2017-08-14 08:23:08 --> Output Class Initialized
INFO - 2017-08-14 08:23:08 --> Security Class Initialized
DEBUG - 2017-08-14 08:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:23:08 --> Input Class Initialized
INFO - 2017-08-14 08:23:08 --> Language Class Initialized
INFO - 2017-08-14 08:23:08 --> Loader Class Initialized
INFO - 2017-08-14 08:23:08 --> Helper loaded: common_helper
INFO - 2017-08-14 08:23:08 --> Database Driver Class Initialized
INFO - 2017-08-14 08:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:23:08 --> Email Class Initialized
INFO - 2017-08-14 08:23:08 --> Controller Class Initialized
INFO - 2017-08-14 08:23:08 --> Helper loaded: form_helper
INFO - 2017-08-14 08:23:08 --> Form Validation Class Initialized
INFO - 2017-08-14 08:23:08 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:23:08 --> Helper loaded: url_helper
INFO - 2017-08-14 08:23:08 --> Model Class Initialized
INFO - 2017-08-14 08:23:08 --> Model Class Initialized
INFO - 2017-08-14 08:23:08 --> Model Class Initialized
INFO - 2017-08-14 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:53:08 --> Final output sent to browser
DEBUG - 2017-08-14 11:53:08 --> Total execution time: 0.0558
INFO - 2017-08-14 08:23:42 --> Config Class Initialized
INFO - 2017-08-14 08:23:42 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:23:42 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:23:42 --> Utf8 Class Initialized
INFO - 2017-08-14 08:23:42 --> URI Class Initialized
INFO - 2017-08-14 08:23:42 --> Router Class Initialized
INFO - 2017-08-14 08:23:42 --> Output Class Initialized
INFO - 2017-08-14 08:23:42 --> Security Class Initialized
DEBUG - 2017-08-14 08:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:23:42 --> Input Class Initialized
INFO - 2017-08-14 08:23:42 --> Language Class Initialized
INFO - 2017-08-14 08:23:42 --> Loader Class Initialized
INFO - 2017-08-14 08:23:42 --> Helper loaded: common_helper
INFO - 2017-08-14 08:23:42 --> Database Driver Class Initialized
INFO - 2017-08-14 08:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:23:42 --> Email Class Initialized
INFO - 2017-08-14 08:23:42 --> Controller Class Initialized
INFO - 2017-08-14 08:23:42 --> Helper loaded: form_helper
INFO - 2017-08-14 08:23:42 --> Form Validation Class Initialized
INFO - 2017-08-14 08:23:42 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:23:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:23:42 --> Helper loaded: url_helper
INFO - 2017-08-14 08:23:42 --> Model Class Initialized
INFO - 2017-08-14 08:23:42 --> Model Class Initialized
INFO - 2017-08-14 08:23:42 --> Model Class Initialized
INFO - 2017-08-14 11:53:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:53:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:53:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:53:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:53:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:53:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:53:42 --> Final output sent to browser
DEBUG - 2017-08-14 11:53:42 --> Total execution time: 0.0611
INFO - 2017-08-14 08:24:03 --> Config Class Initialized
INFO - 2017-08-14 08:24:03 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:24:03 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:24:03 --> Utf8 Class Initialized
INFO - 2017-08-14 08:24:03 --> URI Class Initialized
INFO - 2017-08-14 08:24:03 --> Router Class Initialized
INFO - 2017-08-14 08:24:03 --> Output Class Initialized
INFO - 2017-08-14 08:24:03 --> Security Class Initialized
DEBUG - 2017-08-14 08:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:24:03 --> Input Class Initialized
INFO - 2017-08-14 08:24:03 --> Language Class Initialized
INFO - 2017-08-14 08:24:03 --> Loader Class Initialized
INFO - 2017-08-14 08:24:03 --> Helper loaded: common_helper
INFO - 2017-08-14 08:24:03 --> Database Driver Class Initialized
INFO - 2017-08-14 08:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:24:03 --> Email Class Initialized
INFO - 2017-08-14 08:24:03 --> Controller Class Initialized
INFO - 2017-08-14 08:24:03 --> Helper loaded: form_helper
INFO - 2017-08-14 08:24:03 --> Form Validation Class Initialized
INFO - 2017-08-14 08:24:03 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:24:03 --> Helper loaded: url_helper
INFO - 2017-08-14 08:24:03 --> Model Class Initialized
INFO - 2017-08-14 08:24:03 --> Model Class Initialized
INFO - 2017-08-14 08:24:03 --> Model Class Initialized
INFO - 2017-08-14 11:54:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:54:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:54:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:54:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:54:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:54:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:54:03 --> Final output sent to browser
DEBUG - 2017-08-14 11:54:03 --> Total execution time: 0.0611
INFO - 2017-08-14 08:24:51 --> Config Class Initialized
INFO - 2017-08-14 08:24:51 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:24:51 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:24:51 --> Utf8 Class Initialized
INFO - 2017-08-14 08:24:51 --> URI Class Initialized
INFO - 2017-08-14 08:24:51 --> Router Class Initialized
INFO - 2017-08-14 08:24:51 --> Output Class Initialized
INFO - 2017-08-14 08:24:51 --> Security Class Initialized
DEBUG - 2017-08-14 08:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:24:51 --> Input Class Initialized
INFO - 2017-08-14 08:24:51 --> Language Class Initialized
INFO - 2017-08-14 08:24:51 --> Loader Class Initialized
INFO - 2017-08-14 08:24:51 --> Helper loaded: common_helper
INFO - 2017-08-14 08:24:51 --> Database Driver Class Initialized
INFO - 2017-08-14 08:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:24:51 --> Email Class Initialized
INFO - 2017-08-14 08:24:51 --> Controller Class Initialized
INFO - 2017-08-14 08:24:51 --> Helper loaded: form_helper
INFO - 2017-08-14 08:24:51 --> Form Validation Class Initialized
INFO - 2017-08-14 08:24:51 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:24:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:24:51 --> Helper loaded: url_helper
INFO - 2017-08-14 08:24:51 --> Model Class Initialized
INFO - 2017-08-14 08:24:51 --> Model Class Initialized
INFO - 2017-08-14 08:24:51 --> Model Class Initialized
INFO - 2017-08-14 11:54:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:54:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:54:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:54:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:54:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:54:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:54:51 --> Final output sent to browser
DEBUG - 2017-08-14 11:54:51 --> Total execution time: 0.0634
INFO - 2017-08-14 08:25:04 --> Config Class Initialized
INFO - 2017-08-14 08:25:04 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:25:04 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:25:04 --> Utf8 Class Initialized
INFO - 2017-08-14 08:25:04 --> URI Class Initialized
INFO - 2017-08-14 08:25:04 --> Router Class Initialized
INFO - 2017-08-14 08:25:04 --> Output Class Initialized
INFO - 2017-08-14 08:25:04 --> Security Class Initialized
DEBUG - 2017-08-14 08:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:25:04 --> Input Class Initialized
INFO - 2017-08-14 08:25:04 --> Language Class Initialized
INFO - 2017-08-14 08:25:04 --> Loader Class Initialized
INFO - 2017-08-14 08:25:04 --> Helper loaded: common_helper
INFO - 2017-08-14 08:25:04 --> Database Driver Class Initialized
INFO - 2017-08-14 08:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:25:04 --> Email Class Initialized
INFO - 2017-08-14 08:25:04 --> Controller Class Initialized
INFO - 2017-08-14 08:25:04 --> Helper loaded: form_helper
INFO - 2017-08-14 08:25:04 --> Form Validation Class Initialized
INFO - 2017-08-14 08:25:04 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:25:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:25:04 --> Helper loaded: url_helper
INFO - 2017-08-14 08:25:04 --> Model Class Initialized
INFO - 2017-08-14 08:25:04 --> Model Class Initialized
INFO - 2017-08-14 08:25:04 --> Model Class Initialized
INFO - 2017-08-14 11:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:55:04 --> Final output sent to browser
DEBUG - 2017-08-14 11:55:04 --> Total execution time: 0.0603
INFO - 2017-08-14 08:25:17 --> Config Class Initialized
INFO - 2017-08-14 08:25:17 --> Hooks Class Initialized
DEBUG - 2017-08-14 08:25:17 --> UTF-8 Support Enabled
INFO - 2017-08-14 08:25:17 --> Utf8 Class Initialized
INFO - 2017-08-14 08:25:17 --> URI Class Initialized
INFO - 2017-08-14 08:25:17 --> Router Class Initialized
INFO - 2017-08-14 08:25:17 --> Output Class Initialized
INFO - 2017-08-14 08:25:17 --> Security Class Initialized
DEBUG - 2017-08-14 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 08:25:17 --> Input Class Initialized
INFO - 2017-08-14 08:25:17 --> Language Class Initialized
INFO - 2017-08-14 08:25:17 --> Loader Class Initialized
INFO - 2017-08-14 08:25:17 --> Helper loaded: common_helper
INFO - 2017-08-14 08:25:17 --> Database Driver Class Initialized
INFO - 2017-08-14 08:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 08:25:17 --> Email Class Initialized
INFO - 2017-08-14 08:25:17 --> Controller Class Initialized
INFO - 2017-08-14 08:25:17 --> Helper loaded: form_helper
INFO - 2017-08-14 08:25:17 --> Form Validation Class Initialized
INFO - 2017-08-14 08:25:17 --> Helper loaded: email_helper
DEBUG - 2017-08-14 08:25:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 08:25:17 --> Helper loaded: url_helper
INFO - 2017-08-14 08:25:17 --> Model Class Initialized
INFO - 2017-08-14 08:25:17 --> Model Class Initialized
INFO - 2017-08-14 08:25:17 --> Model Class Initialized
INFO - 2017-08-14 11:55:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 11:55:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 11:55:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:55:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 11:55:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 11:55:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 11:55:17 --> Final output sent to browser
DEBUG - 2017-08-14 11:55:17 --> Total execution time: 0.0548
INFO - 2017-08-14 09:19:24 --> Config Class Initialized
INFO - 2017-08-14 09:19:24 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:19:24 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:19:24 --> Utf8 Class Initialized
INFO - 2017-08-14 09:19:24 --> URI Class Initialized
DEBUG - 2017-08-14 09:19:24 --> No URI present. Default controller set.
INFO - 2017-08-14 09:19:24 --> Router Class Initialized
INFO - 2017-08-14 09:19:24 --> Output Class Initialized
INFO - 2017-08-14 09:19:24 --> Security Class Initialized
DEBUG - 2017-08-14 09:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:19:24 --> Input Class Initialized
INFO - 2017-08-14 09:19:24 --> Language Class Initialized
INFO - 2017-08-14 09:19:24 --> Loader Class Initialized
INFO - 2017-08-14 09:19:24 --> Helper loaded: common_helper
INFO - 2017-08-14 09:19:24 --> Database Driver Class Initialized
INFO - 2017-08-14 09:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:19:24 --> Email Class Initialized
INFO - 2017-08-14 09:19:24 --> Controller Class Initialized
INFO - 2017-08-14 09:19:24 --> Helper loaded: form_helper
INFO - 2017-08-14 09:19:24 --> Form Validation Class Initialized
INFO - 2017-08-14 09:19:24 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:19:24 --> Helper loaded: url_helper
INFO - 2017-08-14 09:19:24 --> Model Class Initialized
INFO - 2017-08-14 09:19:24 --> Model Class Initialized
INFO - 2017-08-14 09:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-08-14 09:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 09:19:24 --> Final output sent to browser
DEBUG - 2017-08-14 09:19:24 --> Total execution time: 0.0473
INFO - 2017-08-14 09:19:25 --> Config Class Initialized
INFO - 2017-08-14 09:19:25 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:19:25 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:19:25 --> Utf8 Class Initialized
INFO - 2017-08-14 09:19:25 --> URI Class Initialized
DEBUG - 2017-08-14 09:19:25 --> No URI present. Default controller set.
INFO - 2017-08-14 09:19:25 --> Router Class Initialized
INFO - 2017-08-14 09:19:25 --> Output Class Initialized
INFO - 2017-08-14 09:19:25 --> Security Class Initialized
DEBUG - 2017-08-14 09:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:19:25 --> Input Class Initialized
INFO - 2017-08-14 09:19:25 --> Language Class Initialized
INFO - 2017-08-14 09:19:25 --> Loader Class Initialized
INFO - 2017-08-14 09:19:25 --> Helper loaded: common_helper
INFO - 2017-08-14 09:19:25 --> Database Driver Class Initialized
INFO - 2017-08-14 09:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:19:26 --> Email Class Initialized
INFO - 2017-08-14 09:19:26 --> Controller Class Initialized
INFO - 2017-08-14 09:19:26 --> Helper loaded: form_helper
INFO - 2017-08-14 09:19:26 --> Form Validation Class Initialized
INFO - 2017-08-14 09:19:26 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:19:26 --> Helper loaded: url_helper
INFO - 2017-08-14 09:19:26 --> Model Class Initialized
INFO - 2017-08-14 09:19:26 --> Model Class Initialized
DEBUG - 2017-08-14 09:19:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:19:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 09:19:26 --> Config Class Initialized
INFO - 2017-08-14 09:19:26 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:19:26 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:19:26 --> Utf8 Class Initialized
INFO - 2017-08-14 09:19:26 --> URI Class Initialized
INFO - 2017-08-14 09:19:26 --> Router Class Initialized
INFO - 2017-08-14 09:19:26 --> Output Class Initialized
INFO - 2017-08-14 09:19:26 --> Security Class Initialized
DEBUG - 2017-08-14 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:19:26 --> Input Class Initialized
INFO - 2017-08-14 09:19:26 --> Language Class Initialized
INFO - 2017-08-14 09:19:26 --> Loader Class Initialized
INFO - 2017-08-14 09:19:26 --> Helper loaded: common_helper
INFO - 2017-08-14 09:19:26 --> Database Driver Class Initialized
INFO - 2017-08-14 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:19:26 --> Email Class Initialized
INFO - 2017-08-14 09:19:26 --> Controller Class Initialized
INFO - 2017-08-14 09:19:26 --> Helper loaded: form_helper
INFO - 2017-08-14 09:19:26 --> Form Validation Class Initialized
INFO - 2017-08-14 09:19:26 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:19:26 --> Helper loaded: url_helper
INFO - 2017-08-14 09:19:26 --> Model Class Initialized
INFO - 2017-08-14 09:19:26 --> Model Class Initialized
INFO - 2017-08-14 09:19:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 09:19:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 09:19:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-08-14 09:19:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 09:19:26 --> Final output sent to browser
DEBUG - 2017-08-14 09:19:26 --> Total execution time: 0.1171
INFO - 2017-08-14 09:19:27 --> Config Class Initialized
INFO - 2017-08-14 09:19:27 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:19:27 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:19:27 --> Utf8 Class Initialized
INFO - 2017-08-14 09:19:27 --> URI Class Initialized
INFO - 2017-08-14 09:19:27 --> Router Class Initialized
INFO - 2017-08-14 09:19:27 --> Output Class Initialized
INFO - 2017-08-14 09:19:27 --> Security Class Initialized
DEBUG - 2017-08-14 09:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:19:27 --> Input Class Initialized
INFO - 2017-08-14 09:19:27 --> Language Class Initialized
INFO - 2017-08-14 09:19:27 --> Loader Class Initialized
INFO - 2017-08-14 09:19:27 --> Helper loaded: common_helper
INFO - 2017-08-14 09:19:27 --> Database Driver Class Initialized
INFO - 2017-08-14 09:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:19:27 --> Email Class Initialized
INFO - 2017-08-14 09:19:27 --> Controller Class Initialized
INFO - 2017-08-14 09:19:27 --> Helper loaded: form_helper
INFO - 2017-08-14 09:19:27 --> Form Validation Class Initialized
INFO - 2017-08-14 09:19:27 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:19:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:19:27 --> Helper loaded: url_helper
INFO - 2017-08-14 09:19:27 --> Model Class Initialized
INFO - 2017-08-14 09:19:27 --> Model Class Initialized
INFO - 2017-08-14 09:19:27 --> Model Class Initialized
INFO - 2017-08-14 12:49:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 12:49:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 12:49:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 12:49:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 12:49:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 12:49:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 12:49:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 12:49:28 --> Final output sent to browser
DEBUG - 2017-08-14 12:49:28 --> Total execution time: 0.3002
INFO - 2017-08-14 09:19:31 --> Config Class Initialized
INFO - 2017-08-14 09:19:31 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:19:31 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:19:31 --> Utf8 Class Initialized
INFO - 2017-08-14 09:19:31 --> URI Class Initialized
INFO - 2017-08-14 09:19:31 --> Router Class Initialized
INFO - 2017-08-14 09:19:31 --> Output Class Initialized
INFO - 2017-08-14 09:19:31 --> Security Class Initialized
DEBUG - 2017-08-14 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:19:31 --> Input Class Initialized
INFO - 2017-08-14 09:19:31 --> Language Class Initialized
INFO - 2017-08-14 09:19:31 --> Loader Class Initialized
INFO - 2017-08-14 09:19:31 --> Helper loaded: common_helper
INFO - 2017-08-14 09:19:31 --> Database Driver Class Initialized
INFO - 2017-08-14 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:19:31 --> Email Class Initialized
INFO - 2017-08-14 09:19:31 --> Controller Class Initialized
INFO - 2017-08-14 09:19:31 --> Helper loaded: form_helper
INFO - 2017-08-14 09:19:31 --> Form Validation Class Initialized
INFO - 2017-08-14 09:19:31 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:19:31 --> Helper loaded: url_helper
INFO - 2017-08-14 09:19:31 --> Model Class Initialized
INFO - 2017-08-14 09:19:31 --> Model Class Initialized
INFO - 2017-08-14 09:19:31 --> Model Class Initialized
INFO - 2017-08-14 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 12:49:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 12:49:31 --> Final output sent to browser
DEBUG - 2017-08-14 12:49:31 --> Total execution time: 0.0480
INFO - 2017-08-14 09:35:55 --> Config Class Initialized
INFO - 2017-08-14 09:35:55 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:35:55 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:35:55 --> Utf8 Class Initialized
INFO - 2017-08-14 09:35:55 --> URI Class Initialized
INFO - 2017-08-14 09:35:55 --> Router Class Initialized
INFO - 2017-08-14 09:35:55 --> Output Class Initialized
INFO - 2017-08-14 09:35:55 --> Security Class Initialized
DEBUG - 2017-08-14 09:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:35:55 --> Input Class Initialized
INFO - 2017-08-14 09:35:55 --> Language Class Initialized
INFO - 2017-08-14 09:35:55 --> Loader Class Initialized
INFO - 2017-08-14 09:35:55 --> Helper loaded: common_helper
INFO - 2017-08-14 09:35:55 --> Database Driver Class Initialized
INFO - 2017-08-14 09:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:35:55 --> Email Class Initialized
INFO - 2017-08-14 09:35:55 --> Controller Class Initialized
INFO - 2017-08-14 09:35:55 --> Helper loaded: form_helper
INFO - 2017-08-14 09:35:55 --> Form Validation Class Initialized
INFO - 2017-08-14 09:35:55 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:35:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:35:55 --> Helper loaded: url_helper
INFO - 2017-08-14 09:35:55 --> Model Class Initialized
INFO - 2017-08-14 09:35:55 --> Model Class Initialized
INFO - 2017-08-14 09:35:55 --> Model Class Initialized
INFO - 2017-08-14 13:05:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 13:05:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 13:05:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 13:05:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 13:05:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 13:05:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 13:05:55 --> Final output sent to browser
DEBUG - 2017-08-14 13:05:55 --> Total execution time: 0.0546
INFO - 2017-08-14 09:36:12 --> Config Class Initialized
INFO - 2017-08-14 09:36:12 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:36:12 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:36:12 --> Utf8 Class Initialized
INFO - 2017-08-14 09:36:12 --> URI Class Initialized
INFO - 2017-08-14 09:36:12 --> Router Class Initialized
INFO - 2017-08-14 09:36:12 --> Output Class Initialized
INFO - 2017-08-14 09:36:12 --> Security Class Initialized
DEBUG - 2017-08-14 09:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:36:12 --> Input Class Initialized
INFO - 2017-08-14 09:36:12 --> Language Class Initialized
INFO - 2017-08-14 09:36:12 --> Loader Class Initialized
INFO - 2017-08-14 09:36:12 --> Helper loaded: common_helper
INFO - 2017-08-14 09:36:12 --> Database Driver Class Initialized
INFO - 2017-08-14 09:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:36:12 --> Email Class Initialized
INFO - 2017-08-14 09:36:12 --> Controller Class Initialized
INFO - 2017-08-14 09:36:12 --> Helper loaded: form_helper
INFO - 2017-08-14 09:36:12 --> Form Validation Class Initialized
INFO - 2017-08-14 09:36:12 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:36:12 --> Helper loaded: url_helper
INFO - 2017-08-14 09:36:12 --> Model Class Initialized
INFO - 2017-08-14 09:36:12 --> Model Class Initialized
INFO - 2017-08-14 09:36:12 --> Model Class Initialized
DEBUG - 2017-08-14 13:06:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:06:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-14 13:06:13 --> file_get_contents(http://localhost/FlickNews/Webservices/News/?newsid=79): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found

ERROR - 2017-08-14 13:06:13 --> Severity: Warning --> file_get_contents(http://localhost/FlickNews/Webservices/News/?newsid=79): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 214
INFO - 2017-08-14 09:36:56 --> Config Class Initialized
INFO - 2017-08-14 09:36:56 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:36:56 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:36:56 --> Utf8 Class Initialized
INFO - 2017-08-14 09:36:56 --> URI Class Initialized
INFO - 2017-08-14 09:36:56 --> Router Class Initialized
INFO - 2017-08-14 09:36:56 --> Output Class Initialized
INFO - 2017-08-14 09:36:56 --> Security Class Initialized
DEBUG - 2017-08-14 09:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:36:56 --> Input Class Initialized
INFO - 2017-08-14 09:36:56 --> Language Class Initialized
INFO - 2017-08-14 09:36:56 --> Loader Class Initialized
INFO - 2017-08-14 09:36:56 --> Helper loaded: common_helper
INFO - 2017-08-14 09:36:56 --> Database Driver Class Initialized
INFO - 2017-08-14 09:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:36:56 --> Email Class Initialized
INFO - 2017-08-14 09:36:56 --> Controller Class Initialized
INFO - 2017-08-14 09:36:56 --> Helper loaded: form_helper
INFO - 2017-08-14 09:36:56 --> Form Validation Class Initialized
INFO - 2017-08-14 09:36:56 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:36:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:36:56 --> Helper loaded: url_helper
INFO - 2017-08-14 09:36:56 --> Model Class Initialized
INFO - 2017-08-14 09:36:56 --> Model Class Initialized
INFO - 2017-08-14 09:36:56 --> Model Class Initialized
DEBUG - 2017-08-14 13:06:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:06:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-14 13:06:56 --> file_get_contents(http://localhost/FlickNews/Webservices/News/sendNoti?newsid=80): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found

ERROR - 2017-08-14 13:06:56 --> Severity: Warning --> file_get_contents(http://localhost/FlickNews/Webservices/News/sendNoti?newsid=80): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 214
INFO - 2017-08-14 09:38:14 --> Config Class Initialized
INFO - 2017-08-14 09:38:14 --> Hooks Class Initialized
DEBUG - 2017-08-14 09:38:14 --> UTF-8 Support Enabled
INFO - 2017-08-14 09:38:14 --> Utf8 Class Initialized
INFO - 2017-08-14 09:38:14 --> URI Class Initialized
INFO - 2017-08-14 09:38:14 --> Router Class Initialized
INFO - 2017-08-14 09:38:14 --> Output Class Initialized
INFO - 2017-08-14 09:38:14 --> Security Class Initialized
DEBUG - 2017-08-14 09:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 09:38:14 --> Input Class Initialized
INFO - 2017-08-14 09:38:14 --> Language Class Initialized
INFO - 2017-08-14 09:38:14 --> Loader Class Initialized
INFO - 2017-08-14 09:38:14 --> Helper loaded: common_helper
INFO - 2017-08-14 09:38:14 --> Database Driver Class Initialized
INFO - 2017-08-14 09:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 09:38:14 --> Email Class Initialized
INFO - 2017-08-14 09:38:14 --> Controller Class Initialized
INFO - 2017-08-14 09:38:14 --> Helper loaded: form_helper
INFO - 2017-08-14 09:38:14 --> Form Validation Class Initialized
INFO - 2017-08-14 09:38:14 --> Helper loaded: email_helper
DEBUG - 2017-08-14 09:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 09:38:14 --> Helper loaded: url_helper
INFO - 2017-08-14 09:38:14 --> Model Class Initialized
INFO - 2017-08-14 09:38:14 --> Model Class Initialized
INFO - 2017-08-14 09:38:14 --> Model Class Initialized
DEBUG - 2017-08-14 13:08:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:08:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 10:03:51 --> Config Class Initialized
INFO - 2017-08-14 10:03:51 --> Hooks Class Initialized
DEBUG - 2017-08-14 10:03:51 --> UTF-8 Support Enabled
INFO - 2017-08-14 10:03:51 --> Utf8 Class Initialized
INFO - 2017-08-14 10:03:51 --> URI Class Initialized
INFO - 2017-08-14 10:03:51 --> Router Class Initialized
INFO - 2017-08-14 10:03:51 --> Output Class Initialized
INFO - 2017-08-14 10:03:51 --> Security Class Initialized
DEBUG - 2017-08-14 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 10:03:51 --> Input Class Initialized
INFO - 2017-08-14 10:03:51 --> Language Class Initialized
INFO - 2017-08-14 10:03:51 --> Loader Class Initialized
INFO - 2017-08-14 10:03:51 --> Helper loaded: common_helper
INFO - 2017-08-14 10:03:51 --> Database Driver Class Initialized
INFO - 2017-08-14 10:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 10:03:54 --> Email Class Initialized
INFO - 2017-08-14 10:03:54 --> Controller Class Initialized
INFO - 2017-08-14 10:03:54 --> Helper loaded: form_helper
INFO - 2017-08-14 10:03:54 --> Form Validation Class Initialized
INFO - 2017-08-14 10:03:54 --> Helper loaded: email_helper
DEBUG - 2017-08-14 10:03:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 10:03:54 --> Helper loaded: url_helper
INFO - 2017-08-14 10:03:54 --> Model Class Initialized
INFO - 2017-08-14 10:03:54 --> Model Class Initialized
INFO - 2017-08-14 10:03:54 --> Model Class Initialized
DEBUG - 2017-08-14 13:33:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:33:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-14 13:34:24 --> Maximum execution time of 30 seconds exceeded
ERROR - 2017-08-14 13:34:24 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\system\core\Common.php 595
INFO - 2017-08-14 10:04:30 --> Config Class Initialized
INFO - 2017-08-14 10:04:30 --> Hooks Class Initialized
DEBUG - 2017-08-14 10:04:30 --> UTF-8 Support Enabled
INFO - 2017-08-14 10:04:30 --> Utf8 Class Initialized
INFO - 2017-08-14 10:04:30 --> URI Class Initialized
INFO - 2017-08-14 10:04:30 --> Router Class Initialized
INFO - 2017-08-14 10:04:30 --> Output Class Initialized
INFO - 2017-08-14 10:04:30 --> Security Class Initialized
DEBUG - 2017-08-14 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 10:04:30 --> Input Class Initialized
INFO - 2017-08-14 10:04:30 --> Language Class Initialized
INFO - 2017-08-14 10:04:30 --> Loader Class Initialized
INFO - 2017-08-14 10:04:30 --> Helper loaded: common_helper
INFO - 2017-08-14 10:04:30 --> Database Driver Class Initialized
INFO - 2017-08-14 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 10:04:30 --> Email Class Initialized
INFO - 2017-08-14 10:04:30 --> Controller Class Initialized
INFO - 2017-08-14 10:04:30 --> Helper loaded: form_helper
INFO - 2017-08-14 10:04:30 --> Form Validation Class Initialized
INFO - 2017-08-14 10:04:30 --> Helper loaded: email_helper
DEBUG - 2017-08-14 10:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 10:04:30 --> Helper loaded: url_helper
INFO - 2017-08-14 10:04:30 --> Model Class Initialized
INFO - 2017-08-14 10:04:30 --> Model Class Initialized
INFO - 2017-08-14 10:04:30 --> Model Class Initialized
DEBUG - 2017-08-14 13:34:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:34:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 10:04:30 --> Config Class Initialized
INFO - 2017-08-14 10:04:30 --> Hooks Class Initialized
DEBUG - 2017-08-14 10:04:30 --> UTF-8 Support Enabled
INFO - 2017-08-14 10:04:30 --> Utf8 Class Initialized
INFO - 2017-08-14 10:04:30 --> URI Class Initialized
INFO - 2017-08-14 10:04:30 --> Router Class Initialized
INFO - 2017-08-14 10:04:30 --> Output Class Initialized
INFO - 2017-08-14 10:04:30 --> Security Class Initialized
DEBUG - 2017-08-14 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 10:04:30 --> Input Class Initialized
INFO - 2017-08-14 10:04:30 --> Language Class Initialized
INFO - 2017-08-14 10:04:30 --> Loader Class Initialized
INFO - 2017-08-14 10:04:30 --> Helper loaded: common_helper
INFO - 2017-08-14 10:04:30 --> Database Driver Class Initialized
INFO - 2017-08-14 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 10:04:30 --> Email Class Initialized
INFO - 2017-08-14 10:04:30 --> Controller Class Initialized
INFO - 2017-08-14 10:04:30 --> Helper loaded: form_helper
INFO - 2017-08-14 10:04:30 --> Form Validation Class Initialized
INFO - 2017-08-14 10:04:30 --> Helper loaded: email_helper
DEBUG - 2017-08-14 10:04:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 10:04:30 --> Helper loaded: url_helper
INFO - 2017-08-14 10:04:30 --> Model Class Initialized
INFO - 2017-08-14 10:04:30 --> Model Class Initialized
INFO - 2017-08-14 10:04:30 --> Model Class Initialized
INFO - 2017-08-14 13:34:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 13:34:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 13:34:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 13:34:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 13:34:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 13:34:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 13:34:30 --> Final output sent to browser
DEBUG - 2017-08-14 13:34:30 --> Total execution time: 0.0497
INFO - 2017-08-14 10:07:06 --> Config Class Initialized
INFO - 2017-08-14 10:07:06 --> Hooks Class Initialized
DEBUG - 2017-08-14 10:07:06 --> UTF-8 Support Enabled
INFO - 2017-08-14 10:07:06 --> Utf8 Class Initialized
INFO - 2017-08-14 10:07:06 --> URI Class Initialized
INFO - 2017-08-14 10:07:06 --> Router Class Initialized
INFO - 2017-08-14 10:07:06 --> Output Class Initialized
INFO - 2017-08-14 10:07:06 --> Security Class Initialized
DEBUG - 2017-08-14 10:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 10:07:06 --> Input Class Initialized
INFO - 2017-08-14 10:07:06 --> Language Class Initialized
INFO - 2017-08-14 10:07:06 --> Loader Class Initialized
INFO - 2017-08-14 10:07:06 --> Helper loaded: common_helper
INFO - 2017-08-14 10:07:06 --> Database Driver Class Initialized
INFO - 2017-08-14 10:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 10:07:06 --> Email Class Initialized
INFO - 2017-08-14 10:07:06 --> Controller Class Initialized
INFO - 2017-08-14 10:07:06 --> Helper loaded: form_helper
INFO - 2017-08-14 10:07:06 --> Form Validation Class Initialized
INFO - 2017-08-14 10:07:06 --> Helper loaded: email_helper
DEBUG - 2017-08-14 10:07:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 10:07:06 --> Helper loaded: url_helper
INFO - 2017-08-14 10:07:06 --> Model Class Initialized
INFO - 2017-08-14 10:07:06 --> Model Class Initialized
INFO - 2017-08-14 10:07:06 --> Model Class Initialized
INFO - 2017-08-14 13:37:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 13:37:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 13:37:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 13:37:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 13:37:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 13:37:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 13:37:06 --> Final output sent to browser
DEBUG - 2017-08-14 13:37:06 --> Total execution time: 0.0579
INFO - 2017-08-14 10:07:25 --> Config Class Initialized
INFO - 2017-08-14 10:07:25 --> Hooks Class Initialized
DEBUG - 2017-08-14 10:07:25 --> UTF-8 Support Enabled
INFO - 2017-08-14 10:07:25 --> Utf8 Class Initialized
INFO - 2017-08-14 10:07:25 --> URI Class Initialized
INFO - 2017-08-14 10:07:25 --> Router Class Initialized
INFO - 2017-08-14 10:07:25 --> Output Class Initialized
INFO - 2017-08-14 10:07:25 --> Security Class Initialized
DEBUG - 2017-08-14 10:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 10:07:25 --> Input Class Initialized
INFO - 2017-08-14 10:07:25 --> Language Class Initialized
INFO - 2017-08-14 10:07:25 --> Loader Class Initialized
INFO - 2017-08-14 10:07:25 --> Helper loaded: common_helper
INFO - 2017-08-14 10:07:25 --> Database Driver Class Initialized
INFO - 2017-08-14 10:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 10:07:25 --> Email Class Initialized
INFO - 2017-08-14 10:07:25 --> Controller Class Initialized
INFO - 2017-08-14 10:07:25 --> Helper loaded: form_helper
INFO - 2017-08-14 10:07:25 --> Form Validation Class Initialized
INFO - 2017-08-14 10:07:25 --> Helper loaded: email_helper
DEBUG - 2017-08-14 10:07:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 10:07:25 --> Helper loaded: url_helper
INFO - 2017-08-14 10:07:25 --> Model Class Initialized
INFO - 2017-08-14 10:07:25 --> Model Class Initialized
INFO - 2017-08-14 10:07:25 --> Model Class Initialized
DEBUG - 2017-08-14 13:37:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:37:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 12:58:27 --> Config Class Initialized
INFO - 2017-08-14 12:58:27 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:58:27 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:58:27 --> Utf8 Class Initialized
INFO - 2017-08-14 12:58:27 --> URI Class Initialized
DEBUG - 2017-08-14 12:58:27 --> No URI present. Default controller set.
INFO - 2017-08-14 12:58:27 --> Router Class Initialized
INFO - 2017-08-14 12:58:27 --> Output Class Initialized
INFO - 2017-08-14 12:58:27 --> Security Class Initialized
DEBUG - 2017-08-14 12:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:58:27 --> Input Class Initialized
INFO - 2017-08-14 12:58:27 --> Language Class Initialized
INFO - 2017-08-14 12:58:27 --> Loader Class Initialized
INFO - 2017-08-14 12:58:27 --> Helper loaded: common_helper
INFO - 2017-08-14 12:58:27 --> Database Driver Class Initialized
INFO - 2017-08-14 12:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:58:27 --> Email Class Initialized
INFO - 2017-08-14 12:58:27 --> Controller Class Initialized
INFO - 2017-08-14 12:58:27 --> Helper loaded: form_helper
INFO - 2017-08-14 12:58:27 --> Form Validation Class Initialized
INFO - 2017-08-14 12:58:27 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:58:27 --> Helper loaded: url_helper
INFO - 2017-08-14 12:58:27 --> Model Class Initialized
INFO - 2017-08-14 12:58:27 --> Model Class Initialized
INFO - 2017-08-14 12:58:27 --> Config Class Initialized
INFO - 2017-08-14 12:58:27 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:58:27 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:58:27 --> Utf8 Class Initialized
INFO - 2017-08-14 12:58:27 --> URI Class Initialized
INFO - 2017-08-14 12:58:27 --> Router Class Initialized
INFO - 2017-08-14 12:58:27 --> Output Class Initialized
INFO - 2017-08-14 12:58:27 --> Security Class Initialized
DEBUG - 2017-08-14 12:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:58:27 --> Input Class Initialized
INFO - 2017-08-14 12:58:27 --> Language Class Initialized
INFO - 2017-08-14 12:58:27 --> Loader Class Initialized
INFO - 2017-08-14 12:58:27 --> Helper loaded: common_helper
INFO - 2017-08-14 12:58:27 --> Database Driver Class Initialized
INFO - 2017-08-14 12:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:58:27 --> Email Class Initialized
INFO - 2017-08-14 12:58:27 --> Controller Class Initialized
INFO - 2017-08-14 12:58:27 --> Helper loaded: form_helper
INFO - 2017-08-14 12:58:27 --> Form Validation Class Initialized
INFO - 2017-08-14 12:58:27 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:58:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:58:27 --> Helper loaded: url_helper
INFO - 2017-08-14 12:58:27 --> Model Class Initialized
INFO - 2017-08-14 12:58:27 --> Model Class Initialized
INFO - 2017-08-14 12:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 12:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 12:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-08-14 12:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 12:58:27 --> Final output sent to browser
DEBUG - 2017-08-14 12:58:27 --> Total execution time: 0.0906
INFO - 2017-08-14 12:58:28 --> Config Class Initialized
INFO - 2017-08-14 12:58:28 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:58:28 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:58:28 --> Utf8 Class Initialized
INFO - 2017-08-14 12:58:28 --> URI Class Initialized
INFO - 2017-08-14 12:58:28 --> Router Class Initialized
INFO - 2017-08-14 12:58:28 --> Output Class Initialized
INFO - 2017-08-14 12:58:28 --> Security Class Initialized
DEBUG - 2017-08-14 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:58:28 --> Input Class Initialized
INFO - 2017-08-14 12:58:28 --> Language Class Initialized
INFO - 2017-08-14 12:58:28 --> Loader Class Initialized
INFO - 2017-08-14 12:58:28 --> Helper loaded: common_helper
INFO - 2017-08-14 12:58:28 --> Database Driver Class Initialized
INFO - 2017-08-14 12:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:58:28 --> Email Class Initialized
INFO - 2017-08-14 12:58:28 --> Controller Class Initialized
INFO - 2017-08-14 12:58:28 --> Helper loaded: form_helper
INFO - 2017-08-14 12:58:28 --> Form Validation Class Initialized
INFO - 2017-08-14 12:58:28 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:58:28 --> Helper loaded: url_helper
INFO - 2017-08-14 12:58:28 --> Model Class Initialized
INFO - 2017-08-14 12:58:28 --> Model Class Initialized
INFO - 2017-08-14 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-08-14 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:28:28 --> Final output sent to browser
DEBUG - 2017-08-14 16:28:28 --> Total execution time: 0.0774
INFO - 2017-08-14 12:58:29 --> Config Class Initialized
INFO - 2017-08-14 12:58:29 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:58:29 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:58:29 --> Utf8 Class Initialized
INFO - 2017-08-14 12:58:29 --> URI Class Initialized
INFO - 2017-08-14 12:58:29 --> Router Class Initialized
INFO - 2017-08-14 12:58:29 --> Output Class Initialized
INFO - 2017-08-14 12:58:29 --> Security Class Initialized
DEBUG - 2017-08-14 12:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:58:29 --> Input Class Initialized
INFO - 2017-08-14 12:58:29 --> Language Class Initialized
INFO - 2017-08-14 12:58:29 --> Loader Class Initialized
INFO - 2017-08-14 12:58:29 --> Helper loaded: common_helper
INFO - 2017-08-14 12:58:29 --> Database Driver Class Initialized
INFO - 2017-08-14 12:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:58:29 --> Email Class Initialized
INFO - 2017-08-14 12:58:29 --> Controller Class Initialized
INFO - 2017-08-14 12:58:29 --> Helper loaded: form_helper
INFO - 2017-08-14 12:58:29 --> Form Validation Class Initialized
INFO - 2017-08-14 12:58:29 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:58:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:58:29 --> Helper loaded: url_helper
INFO - 2017-08-14 12:58:29 --> Model Class Initialized
INFO - 2017-08-14 12:58:29 --> Model Class Initialized
INFO - 2017-08-14 12:58:29 --> Model Class Initialized
INFO - 2017-08-14 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:28:29 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:28:29 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:28:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:28:29 --> Final output sent to browser
DEBUG - 2017-08-14 16:28:29 --> Total execution time: 0.2003
INFO - 2017-08-14 12:58:34 --> Config Class Initialized
INFO - 2017-08-14 12:58:34 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:58:34 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:58:34 --> Utf8 Class Initialized
INFO - 2017-08-14 12:58:34 --> URI Class Initialized
INFO - 2017-08-14 12:58:34 --> Router Class Initialized
INFO - 2017-08-14 12:58:34 --> Output Class Initialized
INFO - 2017-08-14 12:58:34 --> Security Class Initialized
DEBUG - 2017-08-14 12:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:58:34 --> Input Class Initialized
INFO - 2017-08-14 12:58:34 --> Language Class Initialized
INFO - 2017-08-14 12:58:34 --> Loader Class Initialized
INFO - 2017-08-14 12:58:34 --> Helper loaded: common_helper
INFO - 2017-08-14 12:58:34 --> Database Driver Class Initialized
INFO - 2017-08-14 12:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:58:34 --> Email Class Initialized
INFO - 2017-08-14 12:58:34 --> Controller Class Initialized
INFO - 2017-08-14 12:58:34 --> Helper loaded: form_helper
INFO - 2017-08-14 12:58:34 --> Form Validation Class Initialized
INFO - 2017-08-14 12:58:34 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:58:34 --> Helper loaded: url_helper
INFO - 2017-08-14 12:58:34 --> Model Class Initialized
INFO - 2017-08-14 12:58:34 --> Model Class Initialized
INFO - 2017-08-14 12:58:34 --> Model Class Initialized
INFO - 2017-08-14 16:28:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:28:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:28:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:28:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:28:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:28:34 --> Final output sent to browser
DEBUG - 2017-08-14 16:28:34 --> Total execution time: 0.0646
INFO - 2017-08-14 12:59:17 --> Config Class Initialized
INFO - 2017-08-14 12:59:17 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:59:17 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:59:17 --> Utf8 Class Initialized
INFO - 2017-08-14 12:59:17 --> URI Class Initialized
INFO - 2017-08-14 12:59:17 --> Router Class Initialized
INFO - 2017-08-14 12:59:17 --> Output Class Initialized
INFO - 2017-08-14 12:59:17 --> Security Class Initialized
DEBUG - 2017-08-14 12:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:59:17 --> Input Class Initialized
INFO - 2017-08-14 12:59:17 --> Language Class Initialized
INFO - 2017-08-14 12:59:17 --> Loader Class Initialized
INFO - 2017-08-14 12:59:17 --> Helper loaded: common_helper
INFO - 2017-08-14 12:59:17 --> Database Driver Class Initialized
INFO - 2017-08-14 12:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:59:17 --> Email Class Initialized
INFO - 2017-08-14 12:59:17 --> Controller Class Initialized
INFO - 2017-08-14 12:59:17 --> Helper loaded: form_helper
INFO - 2017-08-14 12:59:17 --> Form Validation Class Initialized
INFO - 2017-08-14 12:59:17 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:59:17 --> Helper loaded: url_helper
INFO - 2017-08-14 12:59:17 --> Model Class Initialized
INFO - 2017-08-14 12:59:17 --> Model Class Initialized
INFO - 2017-08-14 12:59:17 --> Model Class Initialized
INFO - 2017-08-14 16:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:29:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:29:17 --> Final output sent to browser
DEBUG - 2017-08-14 16:29:17 --> Total execution time: 0.1647
INFO - 2017-08-14 12:59:20 --> Config Class Initialized
INFO - 2017-08-14 12:59:20 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:59:20 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:59:20 --> Utf8 Class Initialized
INFO - 2017-08-14 12:59:20 --> URI Class Initialized
INFO - 2017-08-14 12:59:20 --> Router Class Initialized
INFO - 2017-08-14 12:59:20 --> Output Class Initialized
INFO - 2017-08-14 12:59:20 --> Security Class Initialized
DEBUG - 2017-08-14 12:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:59:20 --> Input Class Initialized
INFO - 2017-08-14 12:59:20 --> Language Class Initialized
INFO - 2017-08-14 12:59:20 --> Loader Class Initialized
INFO - 2017-08-14 12:59:20 --> Helper loaded: common_helper
INFO - 2017-08-14 12:59:20 --> Database Driver Class Initialized
INFO - 2017-08-14 12:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:59:20 --> Email Class Initialized
INFO - 2017-08-14 12:59:20 --> Controller Class Initialized
INFO - 2017-08-14 12:59:20 --> Helper loaded: form_helper
INFO - 2017-08-14 12:59:20 --> Form Validation Class Initialized
INFO - 2017-08-14 12:59:20 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:59:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:59:20 --> Helper loaded: url_helper
INFO - 2017-08-14 12:59:20 --> Model Class Initialized
INFO - 2017-08-14 12:59:20 --> Model Class Initialized
INFO - 2017-08-14 12:59:20 --> Model Class Initialized
INFO - 2017-08-14 16:29:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:29:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:29:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:29:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:29:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:29:20 --> Final output sent to browser
DEBUG - 2017-08-14 16:29:20 --> Total execution time: 0.0527
INFO - 2017-08-14 12:59:36 --> Config Class Initialized
INFO - 2017-08-14 12:59:36 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:59:36 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:59:36 --> Utf8 Class Initialized
INFO - 2017-08-14 12:59:36 --> URI Class Initialized
INFO - 2017-08-14 12:59:36 --> Router Class Initialized
INFO - 2017-08-14 12:59:36 --> Output Class Initialized
INFO - 2017-08-14 12:59:36 --> Security Class Initialized
DEBUG - 2017-08-14 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:59:36 --> Input Class Initialized
INFO - 2017-08-14 12:59:36 --> Language Class Initialized
INFO - 2017-08-14 12:59:36 --> Loader Class Initialized
INFO - 2017-08-14 12:59:36 --> Helper loaded: common_helper
INFO - 2017-08-14 12:59:36 --> Database Driver Class Initialized
INFO - 2017-08-14 12:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:59:36 --> Email Class Initialized
INFO - 2017-08-14 12:59:36 --> Controller Class Initialized
INFO - 2017-08-14 12:59:36 --> Helper loaded: form_helper
INFO - 2017-08-14 12:59:36 --> Form Validation Class Initialized
INFO - 2017-08-14 12:59:36 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:59:36 --> Helper loaded: url_helper
INFO - 2017-08-14 12:59:36 --> Model Class Initialized
INFO - 2017-08-14 12:59:36 --> Model Class Initialized
INFO - 2017-08-14 12:59:36 --> Model Class Initialized
INFO - 2017-08-14 16:29:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:29:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:29:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:29:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:29:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:29:36 --> Final output sent to browser
DEBUG - 2017-08-14 16:29:36 --> Total execution time: 0.3339
INFO - 2017-08-14 12:59:40 --> Config Class Initialized
INFO - 2017-08-14 12:59:40 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:59:40 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:59:40 --> Utf8 Class Initialized
INFO - 2017-08-14 12:59:40 --> URI Class Initialized
INFO - 2017-08-14 12:59:40 --> Router Class Initialized
INFO - 2017-08-14 12:59:40 --> Output Class Initialized
INFO - 2017-08-14 12:59:40 --> Security Class Initialized
DEBUG - 2017-08-14 12:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:59:40 --> Input Class Initialized
INFO - 2017-08-14 12:59:40 --> Language Class Initialized
INFO - 2017-08-14 12:59:40 --> Loader Class Initialized
INFO - 2017-08-14 12:59:40 --> Helper loaded: common_helper
INFO - 2017-08-14 12:59:40 --> Database Driver Class Initialized
INFO - 2017-08-14 12:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:59:40 --> Email Class Initialized
INFO - 2017-08-14 12:59:40 --> Controller Class Initialized
INFO - 2017-08-14 12:59:40 --> Helper loaded: form_helper
INFO - 2017-08-14 12:59:40 --> Form Validation Class Initialized
INFO - 2017-08-14 12:59:40 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:59:40 --> Helper loaded: url_helper
INFO - 2017-08-14 12:59:40 --> Model Class Initialized
INFO - 2017-08-14 12:59:40 --> Model Class Initialized
INFO - 2017-08-14 12:59:40 --> Model Class Initialized
INFO - 2017-08-14 16:29:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:29:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:29:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:29:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:29:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:29:40 --> Final output sent to browser
DEBUG - 2017-08-14 16:29:40 --> Total execution time: 0.0521
INFO - 2017-08-14 12:59:49 --> Config Class Initialized
INFO - 2017-08-14 12:59:49 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:59:49 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:59:49 --> Utf8 Class Initialized
INFO - 2017-08-14 12:59:49 --> URI Class Initialized
INFO - 2017-08-14 12:59:49 --> Router Class Initialized
INFO - 2017-08-14 12:59:49 --> Output Class Initialized
INFO - 2017-08-14 12:59:49 --> Security Class Initialized
DEBUG - 2017-08-14 12:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:59:49 --> Input Class Initialized
INFO - 2017-08-14 12:59:49 --> Language Class Initialized
INFO - 2017-08-14 12:59:49 --> Loader Class Initialized
INFO - 2017-08-14 12:59:49 --> Helper loaded: common_helper
INFO - 2017-08-14 12:59:49 --> Database Driver Class Initialized
INFO - 2017-08-14 12:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:59:49 --> Email Class Initialized
INFO - 2017-08-14 12:59:49 --> Controller Class Initialized
INFO - 2017-08-14 12:59:49 --> Helper loaded: form_helper
INFO - 2017-08-14 12:59:49 --> Form Validation Class Initialized
INFO - 2017-08-14 12:59:49 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:59:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:59:49 --> Helper loaded: url_helper
INFO - 2017-08-14 12:59:49 --> Model Class Initialized
INFO - 2017-08-14 12:59:49 --> Model Class Initialized
INFO - 2017-08-14 12:59:49 --> Model Class Initialized
INFO - 2017-08-14 16:29:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:29:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:29:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:29:49 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:29:49 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:29:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:29:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:29:49 --> Final output sent to browser
DEBUG - 2017-08-14 16:29:49 --> Total execution time: 0.1719
INFO - 2017-08-14 12:59:55 --> Config Class Initialized
INFO - 2017-08-14 12:59:55 --> Hooks Class Initialized
DEBUG - 2017-08-14 12:59:55 --> UTF-8 Support Enabled
INFO - 2017-08-14 12:59:55 --> Utf8 Class Initialized
INFO - 2017-08-14 12:59:55 --> URI Class Initialized
INFO - 2017-08-14 12:59:55 --> Router Class Initialized
INFO - 2017-08-14 12:59:55 --> Output Class Initialized
INFO - 2017-08-14 12:59:55 --> Security Class Initialized
DEBUG - 2017-08-14 12:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 12:59:55 --> Input Class Initialized
INFO - 2017-08-14 12:59:55 --> Language Class Initialized
INFO - 2017-08-14 12:59:55 --> Loader Class Initialized
INFO - 2017-08-14 12:59:55 --> Helper loaded: common_helper
INFO - 2017-08-14 12:59:55 --> Database Driver Class Initialized
INFO - 2017-08-14 12:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 12:59:55 --> Email Class Initialized
INFO - 2017-08-14 12:59:55 --> Controller Class Initialized
INFO - 2017-08-14 12:59:55 --> Helper loaded: form_helper
INFO - 2017-08-14 12:59:55 --> Form Validation Class Initialized
INFO - 2017-08-14 12:59:55 --> Helper loaded: email_helper
DEBUG - 2017-08-14 12:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 12:59:55 --> Helper loaded: url_helper
INFO - 2017-08-14 12:59:55 --> Model Class Initialized
INFO - 2017-08-14 12:59:55 --> Model Class Initialized
INFO - 2017-08-14 12:59:55 --> Model Class Initialized
INFO - 2017-08-14 16:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:29:55 --> Final output sent to browser
DEBUG - 2017-08-14 16:29:55 --> Total execution time: 0.0507
INFO - 2017-08-14 13:00:04 --> Config Class Initialized
INFO - 2017-08-14 13:00:04 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:04 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:04 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:04 --> URI Class Initialized
INFO - 2017-08-14 13:00:04 --> Router Class Initialized
INFO - 2017-08-14 13:00:04 --> Output Class Initialized
INFO - 2017-08-14 13:00:04 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:04 --> Input Class Initialized
INFO - 2017-08-14 13:00:04 --> Language Class Initialized
INFO - 2017-08-14 13:00:04 --> Loader Class Initialized
INFO - 2017-08-14 13:00:04 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:04 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:04 --> Email Class Initialized
INFO - 2017-08-14 13:00:04 --> Controller Class Initialized
INFO - 2017-08-14 13:00:04 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:04 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:04 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:04 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:04 --> Model Class Initialized
INFO - 2017-08-14 13:00:04 --> Model Class Initialized
INFO - 2017-08-14 13:00:04 --> Model Class Initialized
INFO - 2017-08-14 16:30:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:04 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:04 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:30:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:30:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:04 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:04 --> Total execution time: 0.1724
INFO - 2017-08-14 13:00:09 --> Config Class Initialized
INFO - 2017-08-14 13:00:09 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:09 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:09 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:09 --> URI Class Initialized
INFO - 2017-08-14 13:00:09 --> Router Class Initialized
INFO - 2017-08-14 13:00:09 --> Output Class Initialized
INFO - 2017-08-14 13:00:09 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:09 --> Input Class Initialized
INFO - 2017-08-14 13:00:09 --> Language Class Initialized
INFO - 2017-08-14 13:00:09 --> Loader Class Initialized
INFO - 2017-08-14 13:00:09 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:09 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:09 --> Email Class Initialized
INFO - 2017-08-14 13:00:09 --> Controller Class Initialized
INFO - 2017-08-14 13:00:09 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:09 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:09 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:09 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:09 --> Model Class Initialized
INFO - 2017-08-14 13:00:09 --> Model Class Initialized
INFO - 2017-08-14 13:00:09 --> Model Class Initialized
INFO - 2017-08-14 16:30:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:30:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:30:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:09 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:09 --> Total execution time: 0.0541
INFO - 2017-08-14 13:00:18 --> Config Class Initialized
INFO - 2017-08-14 13:00:18 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:18 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:18 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:18 --> URI Class Initialized
INFO - 2017-08-14 13:00:18 --> Router Class Initialized
INFO - 2017-08-14 13:00:18 --> Output Class Initialized
INFO - 2017-08-14 13:00:18 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:18 --> Input Class Initialized
INFO - 2017-08-14 13:00:18 --> Language Class Initialized
INFO - 2017-08-14 13:00:18 --> Loader Class Initialized
INFO - 2017-08-14 13:00:18 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:18 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:18 --> Email Class Initialized
INFO - 2017-08-14 13:00:18 --> Controller Class Initialized
INFO - 2017-08-14 13:00:18 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:18 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:18 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:18 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:18 --> Model Class Initialized
INFO - 2017-08-14 13:00:18 --> Model Class Initialized
INFO - 2017-08-14 13:00:18 --> Model Class Initialized
INFO - 2017-08-14 16:30:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:18 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:18 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:30:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:30:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:18 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:18 --> Total execution time: 0.1695
INFO - 2017-08-14 13:00:24 --> Config Class Initialized
INFO - 2017-08-14 13:00:24 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:24 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:24 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:24 --> URI Class Initialized
INFO - 2017-08-14 13:00:24 --> Router Class Initialized
INFO - 2017-08-14 13:00:24 --> Output Class Initialized
INFO - 2017-08-14 13:00:24 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:24 --> Input Class Initialized
INFO - 2017-08-14 13:00:24 --> Language Class Initialized
INFO - 2017-08-14 13:00:24 --> Loader Class Initialized
INFO - 2017-08-14 13:00:24 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:24 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:24 --> Email Class Initialized
INFO - 2017-08-14 13:00:24 --> Controller Class Initialized
INFO - 2017-08-14 13:00:24 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:24 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:24 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:24 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:24 --> Model Class Initialized
INFO - 2017-08-14 13:00:24 --> Model Class Initialized
INFO - 2017-08-14 13:00:24 --> Model Class Initialized
INFO - 2017-08-14 16:30:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:30:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:30:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:24 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:24 --> Total execution time: 0.0523
INFO - 2017-08-14 13:00:30 --> Config Class Initialized
INFO - 2017-08-14 13:00:30 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:30 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:30 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:30 --> URI Class Initialized
INFO - 2017-08-14 13:00:30 --> Router Class Initialized
INFO - 2017-08-14 13:00:30 --> Output Class Initialized
INFO - 2017-08-14 13:00:30 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:30 --> Input Class Initialized
INFO - 2017-08-14 13:00:30 --> Language Class Initialized
INFO - 2017-08-14 13:00:30 --> Loader Class Initialized
INFO - 2017-08-14 13:00:30 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:30 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:30 --> Email Class Initialized
INFO - 2017-08-14 13:00:30 --> Controller Class Initialized
INFO - 2017-08-14 13:00:30 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:30 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:30 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:30 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:30 --> Model Class Initialized
INFO - 2017-08-14 13:00:30 --> Model Class Initialized
INFO - 2017-08-14 13:00:30 --> Model Class Initialized
INFO - 2017-08-14 16:30:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:30 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:30 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:30:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:30:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:30 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:30 --> Total execution time: 0.1786
INFO - 2017-08-14 13:00:34 --> Config Class Initialized
INFO - 2017-08-14 13:00:34 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:34 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:34 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:34 --> URI Class Initialized
INFO - 2017-08-14 13:00:34 --> Router Class Initialized
INFO - 2017-08-14 13:00:34 --> Output Class Initialized
INFO - 2017-08-14 13:00:34 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:34 --> Input Class Initialized
INFO - 2017-08-14 13:00:34 --> Language Class Initialized
INFO - 2017-08-14 13:00:34 --> Loader Class Initialized
INFO - 2017-08-14 13:00:34 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:34 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:34 --> Email Class Initialized
INFO - 2017-08-14 13:00:34 --> Controller Class Initialized
INFO - 2017-08-14 13:00:34 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:34 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:34 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:34 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:34 --> Model Class Initialized
INFO - 2017-08-14 13:00:34 --> Model Class Initialized
INFO - 2017-08-14 13:00:34 --> Model Class Initialized
INFO - 2017-08-14 16:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:34 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:34 --> Total execution time: 0.0506
INFO - 2017-08-14 13:00:41 --> Config Class Initialized
INFO - 2017-08-14 13:00:41 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:41 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:41 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:41 --> URI Class Initialized
INFO - 2017-08-14 13:00:41 --> Router Class Initialized
INFO - 2017-08-14 13:00:41 --> Output Class Initialized
INFO - 2017-08-14 13:00:41 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:41 --> Input Class Initialized
INFO - 2017-08-14 13:00:41 --> Language Class Initialized
INFO - 2017-08-14 13:00:41 --> Loader Class Initialized
INFO - 2017-08-14 13:00:41 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:41 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:41 --> Email Class Initialized
INFO - 2017-08-14 13:00:41 --> Controller Class Initialized
INFO - 2017-08-14 13:00:41 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:41 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:41 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:41 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:41 --> Model Class Initialized
INFO - 2017-08-14 13:00:41 --> Model Class Initialized
INFO - 2017-08-14 13:00:41 --> Model Class Initialized
INFO - 2017-08-14 16:30:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:30:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:30:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:30:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:30:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:41 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:41 --> Total execution time: 0.1626
INFO - 2017-08-14 13:00:50 --> Config Class Initialized
INFO - 2017-08-14 13:00:50 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:00:50 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:00:50 --> Utf8 Class Initialized
INFO - 2017-08-14 13:00:50 --> URI Class Initialized
INFO - 2017-08-14 13:00:50 --> Router Class Initialized
INFO - 2017-08-14 13:00:50 --> Output Class Initialized
INFO - 2017-08-14 13:00:50 --> Security Class Initialized
DEBUG - 2017-08-14 13:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:00:50 --> Input Class Initialized
INFO - 2017-08-14 13:00:50 --> Language Class Initialized
INFO - 2017-08-14 13:00:50 --> Loader Class Initialized
INFO - 2017-08-14 13:00:50 --> Helper loaded: common_helper
INFO - 2017-08-14 13:00:50 --> Database Driver Class Initialized
INFO - 2017-08-14 13:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:00:50 --> Email Class Initialized
INFO - 2017-08-14 13:00:50 --> Controller Class Initialized
INFO - 2017-08-14 13:00:50 --> Helper loaded: form_helper
INFO - 2017-08-14 13:00:50 --> Form Validation Class Initialized
INFO - 2017-08-14 13:00:50 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:00:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:00:50 --> Helper loaded: url_helper
INFO - 2017-08-14 13:00:50 --> Model Class Initialized
INFO - 2017-08-14 13:00:50 --> Model Class Initialized
INFO - 2017-08-14 13:00:50 --> Model Class Initialized
INFO - 2017-08-14 16:30:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:30:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:30:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2017-08-14 16:30:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:30:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:30:50 --> Final output sent to browser
DEBUG - 2017-08-14 16:30:50 --> Total execution time: 0.0509
INFO - 2017-08-14 13:03:11 --> Config Class Initialized
INFO - 2017-08-14 13:03:11 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:03:11 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:03:11 --> Utf8 Class Initialized
INFO - 2017-08-14 13:03:11 --> URI Class Initialized
INFO - 2017-08-14 13:03:11 --> Router Class Initialized
INFO - 2017-08-14 13:03:11 --> Output Class Initialized
INFO - 2017-08-14 13:03:11 --> Security Class Initialized
DEBUG - 2017-08-14 13:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:03:11 --> Input Class Initialized
INFO - 2017-08-14 13:03:11 --> Language Class Initialized
INFO - 2017-08-14 13:03:11 --> Loader Class Initialized
INFO - 2017-08-14 13:03:11 --> Helper loaded: common_helper
INFO - 2017-08-14 13:03:11 --> Database Driver Class Initialized
INFO - 2017-08-14 13:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:03:11 --> Email Class Initialized
INFO - 2017-08-14 13:03:11 --> Controller Class Initialized
INFO - 2017-08-14 13:03:11 --> Helper loaded: form_helper
INFO - 2017-08-14 13:03:11 --> Form Validation Class Initialized
INFO - 2017-08-14 13:03:11 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:03:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:03:11 --> Helper loaded: url_helper
INFO - 2017-08-14 13:03:11 --> Model Class Initialized
INFO - 2017-08-14 13:03:11 --> Model Class Initialized
INFO - 2017-08-14 13:03:11 --> Model Class Initialized
INFO - 2017-08-14 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:33:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:33:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:33:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:33:11 --> Final output sent to browser
DEBUG - 2017-08-14 16:33:11 --> Total execution time: 0.1671
INFO - 2017-08-14 13:03:13 --> Config Class Initialized
INFO - 2017-08-14 13:03:13 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:03:13 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:03:13 --> Utf8 Class Initialized
INFO - 2017-08-14 13:03:13 --> URI Class Initialized
INFO - 2017-08-14 13:03:13 --> Router Class Initialized
INFO - 2017-08-14 13:03:13 --> Output Class Initialized
INFO - 2017-08-14 13:03:13 --> Security Class Initialized
DEBUG - 2017-08-14 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:03:13 --> Input Class Initialized
INFO - 2017-08-14 13:03:13 --> Language Class Initialized
INFO - 2017-08-14 13:03:13 --> Loader Class Initialized
INFO - 2017-08-14 13:03:13 --> Helper loaded: common_helper
INFO - 2017-08-14 13:03:13 --> Database Driver Class Initialized
INFO - 2017-08-14 13:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:03:13 --> Email Class Initialized
INFO - 2017-08-14 13:03:13 --> Controller Class Initialized
INFO - 2017-08-14 13:03:13 --> Helper loaded: form_helper
INFO - 2017-08-14 13:03:13 --> Form Validation Class Initialized
INFO - 2017-08-14 13:03:13 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:03:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:03:13 --> Helper loaded: url_helper
INFO - 2017-08-14 13:03:13 --> Model Class Initialized
INFO - 2017-08-14 13:03:13 --> Model Class Initialized
INFO - 2017-08-14 13:03:13 --> Model Class Initialized
INFO - 2017-08-14 16:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 16:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:33:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:33:13 --> Final output sent to browser
DEBUG - 2017-08-14 16:33:13 --> Total execution time: 0.0567
INFO - 2017-08-14 13:03:30 --> Config Class Initialized
INFO - 2017-08-14 13:03:30 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:03:30 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:03:30 --> Utf8 Class Initialized
INFO - 2017-08-14 13:03:30 --> URI Class Initialized
INFO - 2017-08-14 13:03:30 --> Router Class Initialized
INFO - 2017-08-14 13:03:30 --> Output Class Initialized
INFO - 2017-08-14 13:03:30 --> Security Class Initialized
DEBUG - 2017-08-14 13:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:03:30 --> Input Class Initialized
INFO - 2017-08-14 13:03:30 --> Language Class Initialized
INFO - 2017-08-14 13:03:30 --> Loader Class Initialized
INFO - 2017-08-14 13:03:30 --> Helper loaded: common_helper
INFO - 2017-08-14 13:03:30 --> Database Driver Class Initialized
INFO - 2017-08-14 13:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:03:30 --> Email Class Initialized
INFO - 2017-08-14 13:03:30 --> Controller Class Initialized
INFO - 2017-08-14 13:03:30 --> Helper loaded: form_helper
INFO - 2017-08-14 13:03:30 --> Form Validation Class Initialized
INFO - 2017-08-14 13:03:30 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:03:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:03:30 --> Helper loaded: url_helper
INFO - 2017-08-14 13:03:30 --> Model Class Initialized
INFO - 2017-08-14 13:03:30 --> Model Class Initialized
INFO - 2017-08-14 13:03:30 --> Model Class Initialized
DEBUG - 2017-08-14 16:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 16:33:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-08-14 16:34:00 --> Maximum execution time of 30 seconds exceeded
ERROR - 2017-08-14 16:34:00 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\system\core\Common.php 595
INFO - 2017-08-14 13:04:22 --> Config Class Initialized
INFO - 2017-08-14 13:04:22 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:04:22 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:04:22 --> Utf8 Class Initialized
INFO - 2017-08-14 13:04:22 --> URI Class Initialized
INFO - 2017-08-14 13:04:22 --> Router Class Initialized
INFO - 2017-08-14 13:04:22 --> Output Class Initialized
INFO - 2017-08-14 13:04:22 --> Security Class Initialized
DEBUG - 2017-08-14 13:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:04:22 --> Input Class Initialized
INFO - 2017-08-14 13:04:22 --> Language Class Initialized
INFO - 2017-08-14 13:04:22 --> Loader Class Initialized
INFO - 2017-08-14 13:04:22 --> Helper loaded: common_helper
INFO - 2017-08-14 13:04:22 --> Database Driver Class Initialized
INFO - 2017-08-14 13:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:04:22 --> Email Class Initialized
INFO - 2017-08-14 13:04:22 --> Controller Class Initialized
INFO - 2017-08-14 13:04:22 --> Helper loaded: form_helper
INFO - 2017-08-14 13:04:22 --> Form Validation Class Initialized
INFO - 2017-08-14 13:04:22 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:04:22 --> Helper loaded: url_helper
INFO - 2017-08-14 13:04:22 --> Model Class Initialized
INFO - 2017-08-14 13:04:22 --> Model Class Initialized
INFO - 2017-08-14 13:04:22 --> Model Class Initialized
DEBUG - 2017-08-14 16:34:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 16:34:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 13:04:52 --> Config Class Initialized
INFO - 2017-08-14 13:04:52 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:04:52 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:04:52 --> Utf8 Class Initialized
INFO - 2017-08-14 13:04:52 --> URI Class Initialized
INFO - 2017-08-14 13:04:52 --> Router Class Initialized
INFO - 2017-08-14 13:04:52 --> Output Class Initialized
INFO - 2017-08-14 13:04:52 --> Security Class Initialized
DEBUG - 2017-08-14 13:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:04:52 --> Input Class Initialized
INFO - 2017-08-14 13:04:52 --> Language Class Initialized
INFO - 2017-08-14 13:04:52 --> Loader Class Initialized
INFO - 2017-08-14 13:04:52 --> Helper loaded: common_helper
INFO - 2017-08-14 13:04:52 --> Database Driver Class Initialized
INFO - 2017-08-14 13:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:04:52 --> Email Class Initialized
INFO - 2017-08-14 13:04:52 --> Controller Class Initialized
INFO - 2017-08-14 13:04:52 --> Helper loaded: form_helper
INFO - 2017-08-14 13:04:52 --> Form Validation Class Initialized
INFO - 2017-08-14 13:04:52 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:04:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:04:52 --> Helper loaded: url_helper
INFO - 2017-08-14 13:04:52 --> Model Class Initialized
INFO - 2017-08-14 13:04:52 --> Model Class Initialized
INFO - 2017-08-14 13:04:52 --> Model Class Initialized
INFO - 2017-08-14 16:34:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:34:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:34:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:34:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:34:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:34:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:34:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:34:52 --> Final output sent to browser
DEBUG - 2017-08-14 16:34:52 --> Total execution time: 0.1648
INFO - 2017-08-14 13:07:36 --> Config Class Initialized
INFO - 2017-08-14 13:07:36 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:07:36 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:07:36 --> Utf8 Class Initialized
INFO - 2017-08-14 13:07:36 --> URI Class Initialized
DEBUG - 2017-08-14 13:07:36 --> No URI present. Default controller set.
INFO - 2017-08-14 13:07:36 --> Router Class Initialized
INFO - 2017-08-14 13:07:36 --> Output Class Initialized
INFO - 2017-08-14 13:07:36 --> Security Class Initialized
DEBUG - 2017-08-14 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:07:36 --> Input Class Initialized
INFO - 2017-08-14 13:07:36 --> Language Class Initialized
INFO - 2017-08-14 13:07:36 --> Loader Class Initialized
INFO - 2017-08-14 13:07:36 --> Helper loaded: common_helper
INFO - 2017-08-14 13:07:36 --> Database Driver Class Initialized
INFO - 2017-08-14 13:07:43 --> Config Class Initialized
INFO - 2017-08-14 13:07:43 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:07:43 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:07:43 --> Utf8 Class Initialized
INFO - 2017-08-14 13:07:43 --> URI Class Initialized
INFO - 2017-08-14 13:07:43 --> Router Class Initialized
INFO - 2017-08-14 13:07:43 --> Output Class Initialized
INFO - 2017-08-14 13:07:43 --> Security Class Initialized
DEBUG - 2017-08-14 13:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:07:43 --> Input Class Initialized
INFO - 2017-08-14 13:07:43 --> Language Class Initialized
INFO - 2017-08-14 13:07:43 --> Loader Class Initialized
INFO - 2017-08-14 13:07:43 --> Helper loaded: common_helper
INFO - 2017-08-14 13:07:43 --> Database Driver Class Initialized
INFO - 2017-08-14 13:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:07:56 --> Email Class Initialized
INFO - 2017-08-14 13:07:56 --> Controller Class Initialized
INFO - 2017-08-14 13:07:56 --> Helper loaded: form_helper
INFO - 2017-08-14 13:07:56 --> Form Validation Class Initialized
INFO - 2017-08-14 13:07:56 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:07:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:07:56 --> Helper loaded: url_helper
INFO - 2017-08-14 13:07:56 --> Model Class Initialized
INFO - 2017-08-14 13:07:56 --> Model Class Initialized
INFO - 2017-08-14 13:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:08:10 --> Email Class Initialized
INFO - 2017-08-14 13:08:10 --> Controller Class Initialized
INFO - 2017-08-14 13:08:10 --> Helper loaded: form_helper
INFO - 2017-08-14 13:08:10 --> Form Validation Class Initialized
INFO - 2017-08-14 13:08:10 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:08:10 --> Helper loaded: url_helper
INFO - 2017-08-14 13:08:10 --> Model Class Initialized
INFO - 2017-08-14 13:08:10 --> Model Class Initialized
INFO - 2017-08-14 13:08:10 --> Model Class Initialized
INFO - 2017-08-14 16:38:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:38:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:38:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:38:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:38:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:38:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:38:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:38:10 --> Final output sent to browser
DEBUG - 2017-08-14 16:38:10 --> Total execution time: 26.3618
INFO - 2017-08-14 13:08:21 --> Config Class Initialized
INFO - 2017-08-14 13:08:21 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:08:21 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:08:21 --> Utf8 Class Initialized
INFO - 2017-08-14 13:08:21 --> URI Class Initialized
INFO - 2017-08-14 13:08:22 --> Router Class Initialized
INFO - 2017-08-14 13:08:22 --> Output Class Initialized
INFO - 2017-08-14 13:08:22 --> Security Class Initialized
DEBUG - 2017-08-14 13:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:08:22 --> Input Class Initialized
INFO - 2017-08-14 13:08:22 --> Language Class Initialized
INFO - 2017-08-14 13:08:22 --> Loader Class Initialized
INFO - 2017-08-14 13:08:22 --> Helper loaded: common_helper
INFO - 2017-08-14 13:08:22 --> Database Driver Class Initialized
INFO - 2017-08-14 13:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:08:22 --> Email Class Initialized
INFO - 2017-08-14 13:08:22 --> Controller Class Initialized
INFO - 2017-08-14 13:08:22 --> Helper loaded: form_helper
INFO - 2017-08-14 13:08:22 --> Form Validation Class Initialized
INFO - 2017-08-14 13:08:22 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:08:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:08:22 --> Helper loaded: url_helper
INFO - 2017-08-14 13:08:22 --> Model Class Initialized
INFO - 2017-08-14 13:08:22 --> Model Class Initialized
INFO - 2017-08-14 13:08:22 --> Model Class Initialized
INFO - 2017-08-14 16:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-08-14 16:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-08-14 16:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:38:22 --> Final output sent to browser
DEBUG - 2017-08-14 16:38:22 --> Total execution time: 0.0551
INFO - 2017-08-14 13:08:43 --> Config Class Initialized
INFO - 2017-08-14 13:08:43 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:08:43 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:08:43 --> Utf8 Class Initialized
INFO - 2017-08-14 13:08:43 --> URI Class Initialized
INFO - 2017-08-14 13:08:43 --> Router Class Initialized
INFO - 2017-08-14 13:08:43 --> Output Class Initialized
INFO - 2017-08-14 13:08:43 --> Security Class Initialized
DEBUG - 2017-08-14 13:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:08:43 --> Input Class Initialized
INFO - 2017-08-14 13:08:43 --> Language Class Initialized
INFO - 2017-08-14 13:08:43 --> Loader Class Initialized
INFO - 2017-08-14 13:08:43 --> Helper loaded: common_helper
INFO - 2017-08-14 13:08:43 --> Database Driver Class Initialized
INFO - 2017-08-14 13:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:08:43 --> Email Class Initialized
INFO - 2017-08-14 13:08:43 --> Controller Class Initialized
INFO - 2017-08-14 13:08:43 --> Helper loaded: form_helper
INFO - 2017-08-14 13:08:43 --> Form Validation Class Initialized
INFO - 2017-08-14 13:08:43 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:08:43 --> Helper loaded: url_helper
INFO - 2017-08-14 13:08:43 --> Model Class Initialized
INFO - 2017-08-14 13:08:43 --> Model Class Initialized
INFO - 2017-08-14 13:08:43 --> Model Class Initialized
DEBUG - 2017-08-14 16:38:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-08-14 16:38:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-08-14 13:09:13 --> Config Class Initialized
INFO - 2017-08-14 13:09:13 --> Hooks Class Initialized
DEBUG - 2017-08-14 13:09:13 --> UTF-8 Support Enabled
INFO - 2017-08-14 13:09:13 --> Utf8 Class Initialized
INFO - 2017-08-14 13:09:13 --> URI Class Initialized
INFO - 2017-08-14 13:09:13 --> Router Class Initialized
INFO - 2017-08-14 13:09:13 --> Output Class Initialized
INFO - 2017-08-14 13:09:13 --> Security Class Initialized
DEBUG - 2017-08-14 13:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-08-14 13:09:13 --> Input Class Initialized
INFO - 2017-08-14 13:09:13 --> Language Class Initialized
INFO - 2017-08-14 13:09:13 --> Loader Class Initialized
INFO - 2017-08-14 13:09:13 --> Helper loaded: common_helper
INFO - 2017-08-14 13:09:13 --> Database Driver Class Initialized
INFO - 2017-08-14 13:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-08-14 13:09:13 --> Email Class Initialized
INFO - 2017-08-14 13:09:13 --> Controller Class Initialized
INFO - 2017-08-14 13:09:13 --> Helper loaded: form_helper
INFO - 2017-08-14 13:09:13 --> Form Validation Class Initialized
INFO - 2017-08-14 13:09:13 --> Helper loaded: email_helper
DEBUG - 2017-08-14 13:09:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-08-14 13:09:13 --> Helper loaded: url_helper
INFO - 2017-08-14 13:09:13 --> Model Class Initialized
INFO - 2017-08-14 13:09:13 --> Model Class Initialized
INFO - 2017-08-14 13:09:13 --> Model Class Initialized
INFO - 2017-08-14 16:39:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-08-14 16:39:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-08-14 16:39:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
ERROR - 2017-08-14 16:39:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-08-14 16:39:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 68
INFO - 2017-08-14 16:39:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-08-14 16:39:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-08-14 16:39:13 --> Final output sent to browser
DEBUG - 2017-08-14 16:39:13 --> Total execution time: 0.1666
