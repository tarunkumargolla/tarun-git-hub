<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-09 07:21:12 --> Config Class Initialized
INFO - 2017-09-09 07:21:12 --> Hooks Class Initialized
DEBUG - 2017-09-09 07:21:12 --> UTF-8 Support Enabled
INFO - 2017-09-09 07:21:12 --> Utf8 Class Initialized
INFO - 2017-09-09 07:21:13 --> URI Class Initialized
INFO - 2017-09-09 07:21:13 --> Router Class Initialized
INFO - 2017-09-09 07:21:13 --> Output Class Initialized
INFO - 2017-09-09 07:21:13 --> Security Class Initialized
DEBUG - 2017-09-09 07:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 07:21:13 --> Input Class Initialized
INFO - 2017-09-09 07:21:13 --> Language Class Initialized
INFO - 2017-09-09 07:21:13 --> Loader Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: common_helper
INFO - 2017-09-09 07:21:13 --> Database Driver Class Initialized
INFO - 2017-09-09 07:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 07:21:13 --> Email Class Initialized
INFO - 2017-09-09 07:21:13 --> Controller Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: form_helper
INFO - 2017-09-09 07:21:13 --> Form Validation Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: email_helper
DEBUG - 2017-09-09 07:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 07:21:13 --> Helper loaded: url_helper
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> Config Class Initialized
INFO - 2017-09-09 07:21:13 --> Hooks Class Initialized
DEBUG - 2017-09-09 07:21:13 --> UTF-8 Support Enabled
INFO - 2017-09-09 07:21:13 --> Utf8 Class Initialized
INFO - 2017-09-09 07:21:13 --> URI Class Initialized
INFO - 2017-09-09 07:21:13 --> Router Class Initialized
INFO - 2017-09-09 07:21:13 --> Output Class Initialized
INFO - 2017-09-09 07:21:13 --> Security Class Initialized
DEBUG - 2017-09-09 07:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 07:21:13 --> Input Class Initialized
INFO - 2017-09-09 07:21:13 --> Language Class Initialized
INFO - 2017-09-09 07:21:13 --> Loader Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: common_helper
INFO - 2017-09-09 07:21:13 --> Database Driver Class Initialized
INFO - 2017-09-09 07:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 07:21:13 --> Email Class Initialized
INFO - 2017-09-09 07:21:13 --> Controller Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: form_helper
INFO - 2017-09-09 07:21:13 --> Form Validation Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: email_helper
DEBUG - 2017-09-09 07:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 07:21:13 --> Helper loaded: url_helper
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> Config Class Initialized
INFO - 2017-09-09 07:21:13 --> Hooks Class Initialized
DEBUG - 2017-09-09 07:21:13 --> UTF-8 Support Enabled
INFO - 2017-09-09 07:21:13 --> Utf8 Class Initialized
INFO - 2017-09-09 07:21:13 --> URI Class Initialized
DEBUG - 2017-09-09 07:21:13 --> No URI present. Default controller set.
INFO - 2017-09-09 07:21:13 --> Router Class Initialized
INFO - 2017-09-09 07:21:13 --> Output Class Initialized
INFO - 2017-09-09 07:21:13 --> Security Class Initialized
DEBUG - 2017-09-09 07:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 07:21:13 --> Input Class Initialized
INFO - 2017-09-09 07:21:13 --> Language Class Initialized
INFO - 2017-09-09 07:21:13 --> Loader Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: common_helper
INFO - 2017-09-09 07:21:13 --> Database Driver Class Initialized
INFO - 2017-09-09 07:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 07:21:13 --> Email Class Initialized
INFO - 2017-09-09 07:21:13 --> Controller Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: form_helper
INFO - 2017-09-09 07:21:13 --> Form Validation Class Initialized
INFO - 2017-09-09 07:21:13 --> Helper loaded: email_helper
DEBUG - 2017-09-09 07:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 07:21:13 --> Helper loaded: url_helper
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> Model Class Initialized
INFO - 2017-09-09 07:21:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-09-09 07:21:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-09 07:21:13 --> Final output sent to browser
DEBUG - 2017-09-09 07:21:13 --> Total execution time: 0.0948
INFO - 2017-09-09 12:08:15 --> Config Class Initialized
INFO - 2017-09-09 12:08:15 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:08:15 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:08:15 --> Utf8 Class Initialized
INFO - 2017-09-09 12:08:15 --> URI Class Initialized
DEBUG - 2017-09-09 12:08:15 --> No URI present. Default controller set.
INFO - 2017-09-09 12:08:15 --> Router Class Initialized
INFO - 2017-09-09 12:08:15 --> Output Class Initialized
INFO - 2017-09-09 12:08:15 --> Security Class Initialized
DEBUG - 2017-09-09 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:08:15 --> Input Class Initialized
INFO - 2017-09-09 12:08:15 --> Language Class Initialized
INFO - 2017-09-09 12:08:15 --> Loader Class Initialized
INFO - 2017-09-09 12:08:15 --> Helper loaded: common_helper
INFO - 2017-09-09 12:08:15 --> Database Driver Class Initialized
INFO - 2017-09-09 12:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:08:15 --> Email Class Initialized
INFO - 2017-09-09 12:08:15 --> Controller Class Initialized
INFO - 2017-09-09 12:08:15 --> Helper loaded: form_helper
INFO - 2017-09-09 12:08:15 --> Form Validation Class Initialized
INFO - 2017-09-09 12:08:15 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:08:15 --> Helper loaded: url_helper
INFO - 2017-09-09 12:08:15 --> Model Class Initialized
INFO - 2017-09-09 12:08:15 --> Model Class Initialized
INFO - 2017-09-09 12:08:15 --> Config Class Initialized
INFO - 2017-09-09 12:08:15 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:08:15 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:08:15 --> Utf8 Class Initialized
INFO - 2017-09-09 12:08:15 --> URI Class Initialized
INFO - 2017-09-09 12:08:15 --> Router Class Initialized
INFO - 2017-09-09 12:08:15 --> Output Class Initialized
INFO - 2017-09-09 12:08:15 --> Security Class Initialized
DEBUG - 2017-09-09 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:08:15 --> Input Class Initialized
INFO - 2017-09-09 12:08:15 --> Language Class Initialized
INFO - 2017-09-09 12:08:15 --> Loader Class Initialized
INFO - 2017-09-09 12:08:15 --> Helper loaded: common_helper
INFO - 2017-09-09 12:08:15 --> Database Driver Class Initialized
INFO - 2017-09-09 12:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:08:15 --> Email Class Initialized
INFO - 2017-09-09 12:08:15 --> Controller Class Initialized
INFO - 2017-09-09 12:08:15 --> Helper loaded: form_helper
INFO - 2017-09-09 12:08:15 --> Form Validation Class Initialized
INFO - 2017-09-09 12:08:15 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:08:15 --> Helper loaded: url_helper
INFO - 2017-09-09 12:08:15 --> Model Class Initialized
INFO - 2017-09-09 12:08:15 --> Model Class Initialized
INFO - 2017-09-09 12:08:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-09 12:08:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-09 12:08:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-09-09 12:08:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-09 12:08:16 --> Final output sent to browser
DEBUG - 2017-09-09 12:08:16 --> Total execution time: 0.2437
INFO - 2017-09-09 12:08:19 --> Config Class Initialized
INFO - 2017-09-09 12:08:19 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:08:19 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:08:19 --> Utf8 Class Initialized
INFO - 2017-09-09 12:08:19 --> URI Class Initialized
INFO - 2017-09-09 12:08:19 --> Router Class Initialized
INFO - 2017-09-09 12:08:19 --> Output Class Initialized
INFO - 2017-09-09 12:08:19 --> Security Class Initialized
DEBUG - 2017-09-09 12:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:08:19 --> Input Class Initialized
INFO - 2017-09-09 12:08:19 --> Language Class Initialized
INFO - 2017-09-09 12:08:19 --> Loader Class Initialized
INFO - 2017-09-09 12:08:19 --> Helper loaded: common_helper
INFO - 2017-09-09 12:08:19 --> Database Driver Class Initialized
INFO - 2017-09-09 12:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:08:19 --> Email Class Initialized
INFO - 2017-09-09 12:08:19 --> Controller Class Initialized
INFO - 2017-09-09 12:08:19 --> Helper loaded: form_helper
INFO - 2017-09-09 12:08:19 --> Form Validation Class Initialized
INFO - 2017-09-09 12:08:19 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:08:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:08:19 --> Helper loaded: url_helper
INFO - 2017-09-09 12:08:19 --> Model Class Initialized
INFO - 2017-09-09 12:08:19 --> Model Class Initialized
INFO - 2017-09-09 12:08:19 --> Model Class Initialized
INFO - 2017-09-09 15:38:19 --> Helper loaded: download_helper
INFO - 2017-09-09 15:38:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-09 15:38:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-09 15:38:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-09 15:38:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-09 15:38:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-09 15:38:19 --> Final output sent to browser
DEBUG - 2017-09-09 15:38:19 --> Total execution time: 0.1176
INFO - 2017-09-09 12:16:41 --> Config Class Initialized
INFO - 2017-09-09 12:16:41 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:16:41 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:16:41 --> Utf8 Class Initialized
INFO - 2017-09-09 12:16:41 --> URI Class Initialized
INFO - 2017-09-09 12:16:41 --> Router Class Initialized
INFO - 2017-09-09 12:16:41 --> Output Class Initialized
INFO - 2017-09-09 12:16:41 --> Security Class Initialized
DEBUG - 2017-09-09 12:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:16:41 --> Input Class Initialized
INFO - 2017-09-09 12:16:41 --> Language Class Initialized
ERROR - 2017-09-09 12:16:41 --> 404 Page Not Found: Usersdownload_excel/index
INFO - 2017-09-09 12:16:44 --> Config Class Initialized
INFO - 2017-09-09 12:16:44 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:16:44 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:16:44 --> Utf8 Class Initialized
INFO - 2017-09-09 12:16:44 --> URI Class Initialized
INFO - 2017-09-09 12:16:44 --> Router Class Initialized
INFO - 2017-09-09 12:16:44 --> Output Class Initialized
INFO - 2017-09-09 12:16:44 --> Security Class Initialized
DEBUG - 2017-09-09 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:16:44 --> Input Class Initialized
INFO - 2017-09-09 12:16:44 --> Language Class Initialized
ERROR - 2017-09-09 12:16:44 --> syntax error, unexpected '}'
ERROR - 2017-09-09 12:16:44 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 200
INFO - 2017-09-09 12:16:53 --> Config Class Initialized
INFO - 2017-09-09 12:16:53 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:16:53 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:16:53 --> Utf8 Class Initialized
INFO - 2017-09-09 12:16:53 --> URI Class Initialized
INFO - 2017-09-09 12:16:53 --> Router Class Initialized
INFO - 2017-09-09 12:16:53 --> Output Class Initialized
INFO - 2017-09-09 12:16:53 --> Security Class Initialized
DEBUG - 2017-09-09 12:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:16:53 --> Input Class Initialized
INFO - 2017-09-09 12:16:53 --> Language Class Initialized
INFO - 2017-09-09 12:16:53 --> Loader Class Initialized
INFO - 2017-09-09 12:16:53 --> Helper loaded: common_helper
INFO - 2017-09-09 12:16:53 --> Database Driver Class Initialized
INFO - 2017-09-09 12:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:16:53 --> Email Class Initialized
INFO - 2017-09-09 12:16:53 --> Controller Class Initialized
INFO - 2017-09-09 12:16:53 --> Helper loaded: form_helper
INFO - 2017-09-09 12:16:53 --> Form Validation Class Initialized
INFO - 2017-09-09 12:16:53 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:16:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:16:53 --> Helper loaded: url_helper
INFO - 2017-09-09 12:16:53 --> Model Class Initialized
INFO - 2017-09-09 12:16:53 --> Model Class Initialized
INFO - 2017-09-09 12:16:53 --> Model Class Initialized
INFO - 2017-09-09 15:46:53 --> Helper loaded: download_helper
ERROR - 2017-09-09 15:46:53 --> Exception: Unable to load template file: C:/xampp/htdocs/FlickNews/admin/downloadsMyexcel.xlsx
ERROR - 2017-09-09 15:46:53 --> Severity: error --> Exception: Unable to load template file: C:/xampp/htdocs/FlickNews/admin/downloadsMyexcel.xlsx C:\xampp\htdocs\FlickNews\admin\application\libraries\PHPReport\PHPReport.php 200
INFO - 2017-09-09 12:17:22 --> Config Class Initialized
INFO - 2017-09-09 12:17:22 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:17:22 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:17:22 --> Utf8 Class Initialized
INFO - 2017-09-09 12:17:22 --> URI Class Initialized
INFO - 2017-09-09 12:17:22 --> Router Class Initialized
INFO - 2017-09-09 12:17:22 --> Output Class Initialized
INFO - 2017-09-09 12:17:22 --> Security Class Initialized
DEBUG - 2017-09-09 12:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:17:22 --> Input Class Initialized
INFO - 2017-09-09 12:17:22 --> Language Class Initialized
INFO - 2017-09-09 12:17:22 --> Loader Class Initialized
INFO - 2017-09-09 12:17:22 --> Helper loaded: common_helper
INFO - 2017-09-09 12:17:22 --> Database Driver Class Initialized
INFO - 2017-09-09 12:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:17:22 --> Email Class Initialized
INFO - 2017-09-09 12:17:22 --> Controller Class Initialized
INFO - 2017-09-09 12:17:22 --> Helper loaded: form_helper
INFO - 2017-09-09 12:17:22 --> Form Validation Class Initialized
INFO - 2017-09-09 12:17:22 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:17:22 --> Helper loaded: url_helper
INFO - 2017-09-09 12:17:22 --> Model Class Initialized
INFO - 2017-09-09 12:17:22 --> Model Class Initialized
INFO - 2017-09-09 12:17:22 --> Model Class Initialized
INFO - 2017-09-09 15:47:22 --> Helper loaded: download_helper
INFO - 2017-09-09 15:47:22 --> Final output sent to browser
DEBUG - 2017-09-09 15:47:22 --> Total execution time: 0.2650
INFO - 2017-09-09 12:18:01 --> Config Class Initialized
INFO - 2017-09-09 12:18:01 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:18:01 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:18:01 --> Utf8 Class Initialized
INFO - 2017-09-09 12:18:01 --> URI Class Initialized
INFO - 2017-09-09 12:18:01 --> Router Class Initialized
INFO - 2017-09-09 12:18:01 --> Output Class Initialized
INFO - 2017-09-09 12:18:01 --> Security Class Initialized
DEBUG - 2017-09-09 12:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:18:01 --> Input Class Initialized
INFO - 2017-09-09 12:18:01 --> Language Class Initialized
INFO - 2017-09-09 12:18:01 --> Loader Class Initialized
INFO - 2017-09-09 12:18:01 --> Helper loaded: common_helper
INFO - 2017-09-09 12:18:01 --> Database Driver Class Initialized
INFO - 2017-09-09 12:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:18:01 --> Email Class Initialized
INFO - 2017-09-09 12:18:01 --> Controller Class Initialized
INFO - 2017-09-09 12:18:01 --> Helper loaded: form_helper
INFO - 2017-09-09 12:18:01 --> Form Validation Class Initialized
INFO - 2017-09-09 12:18:01 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:18:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:18:01 --> Helper loaded: url_helper
INFO - 2017-09-09 12:18:01 --> Model Class Initialized
INFO - 2017-09-09 12:18:01 --> Model Class Initialized
INFO - 2017-09-09 12:18:01 --> Model Class Initialized
INFO - 2017-09-09 15:48:01 --> Helper loaded: download_helper
INFO - 2017-09-09 12:18:03 --> Config Class Initialized
INFO - 2017-09-09 12:18:03 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:18:03 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:18:03 --> Utf8 Class Initialized
INFO - 2017-09-09 12:18:03 --> URI Class Initialized
INFO - 2017-09-09 12:18:03 --> Router Class Initialized
INFO - 2017-09-09 12:18:03 --> Output Class Initialized
INFO - 2017-09-09 12:18:03 --> Security Class Initialized
DEBUG - 2017-09-09 12:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:18:03 --> Input Class Initialized
INFO - 2017-09-09 12:18:03 --> Language Class Initialized
INFO - 2017-09-09 12:18:03 --> Loader Class Initialized
INFO - 2017-09-09 12:18:03 --> Helper loaded: common_helper
INFO - 2017-09-09 12:18:03 --> Database Driver Class Initialized
INFO - 2017-09-09 12:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:18:03 --> Email Class Initialized
INFO - 2017-09-09 12:18:03 --> Controller Class Initialized
INFO - 2017-09-09 12:18:03 --> Helper loaded: form_helper
INFO - 2017-09-09 12:18:03 --> Form Validation Class Initialized
INFO - 2017-09-09 12:18:03 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:18:03 --> Helper loaded: url_helper
INFO - 2017-09-09 12:18:03 --> Model Class Initialized
INFO - 2017-09-09 12:18:03 --> Model Class Initialized
INFO - 2017-09-09 12:18:03 --> Model Class Initialized
INFO - 2017-09-09 15:48:03 --> Helper loaded: download_helper
INFO - 2017-09-09 12:18:04 --> Config Class Initialized
INFO - 2017-09-09 12:18:04 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:18:04 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:18:04 --> Utf8 Class Initialized
INFO - 2017-09-09 12:18:04 --> URI Class Initialized
INFO - 2017-09-09 12:18:04 --> Router Class Initialized
INFO - 2017-09-09 12:18:04 --> Output Class Initialized
INFO - 2017-09-09 12:18:04 --> Security Class Initialized
DEBUG - 2017-09-09 12:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:18:04 --> Input Class Initialized
INFO - 2017-09-09 12:18:04 --> Language Class Initialized
INFO - 2017-09-09 12:18:04 --> Loader Class Initialized
INFO - 2017-09-09 12:18:04 --> Helper loaded: common_helper
INFO - 2017-09-09 12:18:04 --> Database Driver Class Initialized
INFO - 2017-09-09 12:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:18:04 --> Email Class Initialized
INFO - 2017-09-09 12:18:04 --> Controller Class Initialized
INFO - 2017-09-09 12:18:04 --> Helper loaded: form_helper
INFO - 2017-09-09 12:18:04 --> Form Validation Class Initialized
INFO - 2017-09-09 12:18:04 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:18:04 --> Helper loaded: url_helper
INFO - 2017-09-09 12:18:04 --> Model Class Initialized
INFO - 2017-09-09 12:18:04 --> Model Class Initialized
INFO - 2017-09-09 12:18:04 --> Model Class Initialized
INFO - 2017-09-09 15:48:04 --> Helper loaded: download_helper
INFO - 2017-09-09 12:18:17 --> Config Class Initialized
INFO - 2017-09-09 12:18:17 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:18:17 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:18:17 --> Utf8 Class Initialized
INFO - 2017-09-09 12:18:17 --> URI Class Initialized
INFO - 2017-09-09 12:18:17 --> Router Class Initialized
INFO - 2017-09-09 12:18:17 --> Output Class Initialized
INFO - 2017-09-09 12:18:18 --> Security Class Initialized
DEBUG - 2017-09-09 12:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:18:18 --> Input Class Initialized
INFO - 2017-09-09 12:18:18 --> Language Class Initialized
INFO - 2017-09-09 12:18:18 --> Loader Class Initialized
INFO - 2017-09-09 12:18:18 --> Helper loaded: common_helper
INFO - 2017-09-09 12:18:18 --> Database Driver Class Initialized
INFO - 2017-09-09 12:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:18:18 --> Email Class Initialized
INFO - 2017-09-09 12:18:18 --> Controller Class Initialized
INFO - 2017-09-09 12:18:18 --> Helper loaded: form_helper
INFO - 2017-09-09 12:18:18 --> Form Validation Class Initialized
INFO - 2017-09-09 12:18:18 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:18:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:18:18 --> Helper loaded: url_helper
INFO - 2017-09-09 12:18:18 --> Model Class Initialized
INFO - 2017-09-09 12:18:18 --> Model Class Initialized
INFO - 2017-09-09 12:18:18 --> Model Class Initialized
INFO - 2017-09-09 15:48:18 --> Helper loaded: download_helper
INFO - 2017-09-09 12:18:40 --> Config Class Initialized
INFO - 2017-09-09 12:18:40 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:18:40 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:18:40 --> Utf8 Class Initialized
INFO - 2017-09-09 12:18:40 --> URI Class Initialized
INFO - 2017-09-09 12:18:40 --> Router Class Initialized
INFO - 2017-09-09 12:18:40 --> Output Class Initialized
INFO - 2017-09-09 12:18:40 --> Security Class Initialized
DEBUG - 2017-09-09 12:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:18:40 --> Input Class Initialized
INFO - 2017-09-09 12:18:40 --> Language Class Initialized
INFO - 2017-09-09 12:18:40 --> Loader Class Initialized
INFO - 2017-09-09 12:18:40 --> Helper loaded: common_helper
INFO - 2017-09-09 12:18:40 --> Database Driver Class Initialized
INFO - 2017-09-09 12:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:18:40 --> Email Class Initialized
INFO - 2017-09-09 12:18:40 --> Controller Class Initialized
INFO - 2017-09-09 12:18:40 --> Helper loaded: form_helper
INFO - 2017-09-09 12:18:40 --> Form Validation Class Initialized
INFO - 2017-09-09 12:18:40 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:18:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:18:40 --> Helper loaded: url_helper
INFO - 2017-09-09 12:18:40 --> Model Class Initialized
INFO - 2017-09-09 12:18:40 --> Model Class Initialized
INFO - 2017-09-09 12:18:40 --> Model Class Initialized
INFO - 2017-09-09 15:48:40 --> Helper loaded: download_helper
INFO - 2017-09-09 12:19:19 --> Config Class Initialized
INFO - 2017-09-09 12:19:19 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:19:19 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:19:19 --> Utf8 Class Initialized
INFO - 2017-09-09 12:19:19 --> URI Class Initialized
INFO - 2017-09-09 12:19:19 --> Router Class Initialized
INFO - 2017-09-09 12:19:19 --> Output Class Initialized
INFO - 2017-09-09 12:19:19 --> Security Class Initialized
DEBUG - 2017-09-09 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:19:19 --> Input Class Initialized
INFO - 2017-09-09 12:19:19 --> Language Class Initialized
INFO - 2017-09-09 12:19:19 --> Loader Class Initialized
INFO - 2017-09-09 12:19:19 --> Helper loaded: common_helper
INFO - 2017-09-09 12:19:19 --> Database Driver Class Initialized
INFO - 2017-09-09 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:19:19 --> Email Class Initialized
INFO - 2017-09-09 12:19:19 --> Controller Class Initialized
INFO - 2017-09-09 12:19:19 --> Helper loaded: form_helper
INFO - 2017-09-09 12:19:19 --> Form Validation Class Initialized
INFO - 2017-09-09 12:19:19 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:19:19 --> Helper loaded: url_helper
INFO - 2017-09-09 12:19:19 --> Model Class Initialized
INFO - 2017-09-09 12:19:19 --> Model Class Initialized
INFO - 2017-09-09 12:19:19 --> Model Class Initialized
INFO - 2017-09-09 15:49:19 --> Helper loaded: download_helper
INFO - 2017-09-09 15:49:19 --> Final output sent to browser
DEBUG - 2017-09-09 15:49:19 --> Total execution time: 0.1300
INFO - 2017-09-09 12:21:03 --> Config Class Initialized
INFO - 2017-09-09 12:21:03 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:21:03 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:21:03 --> Utf8 Class Initialized
INFO - 2017-09-09 12:21:03 --> URI Class Initialized
INFO - 2017-09-09 12:21:03 --> Router Class Initialized
INFO - 2017-09-09 12:21:03 --> Output Class Initialized
INFO - 2017-09-09 12:21:03 --> Security Class Initialized
DEBUG - 2017-09-09 12:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:21:03 --> Input Class Initialized
INFO - 2017-09-09 12:21:03 --> Language Class Initialized
INFO - 2017-09-09 12:21:03 --> Loader Class Initialized
INFO - 2017-09-09 12:21:03 --> Helper loaded: common_helper
INFO - 2017-09-09 12:21:03 --> Database Driver Class Initialized
INFO - 2017-09-09 12:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:21:03 --> Email Class Initialized
INFO - 2017-09-09 12:21:03 --> Controller Class Initialized
INFO - 2017-09-09 12:21:03 --> Helper loaded: form_helper
INFO - 2017-09-09 12:21:03 --> Form Validation Class Initialized
INFO - 2017-09-09 12:21:03 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:21:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:21:03 --> Helper loaded: url_helper
INFO - 2017-09-09 12:21:03 --> Model Class Initialized
INFO - 2017-09-09 12:21:03 --> Model Class Initialized
INFO - 2017-09-09 12:21:03 --> Model Class Initialized
INFO - 2017-09-09 15:51:03 --> Helper loaded: download_helper
INFO - 2017-09-09 12:31:03 --> Config Class Initialized
INFO - 2017-09-09 12:31:03 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:31:03 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:31:03 --> Utf8 Class Initialized
INFO - 2017-09-09 12:31:03 --> URI Class Initialized
INFO - 2017-09-09 12:31:03 --> Router Class Initialized
INFO - 2017-09-09 12:31:03 --> Output Class Initialized
INFO - 2017-09-09 12:31:03 --> Security Class Initialized
DEBUG - 2017-09-09 12:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:31:03 --> Input Class Initialized
INFO - 2017-09-09 12:31:03 --> Language Class Initialized
INFO - 2017-09-09 12:31:03 --> Loader Class Initialized
INFO - 2017-09-09 12:31:03 --> Helper loaded: common_helper
INFO - 2017-09-09 12:31:03 --> Database Driver Class Initialized
INFO - 2017-09-09 12:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:31:03 --> Email Class Initialized
INFO - 2017-09-09 12:31:03 --> Controller Class Initialized
INFO - 2017-09-09 12:31:03 --> Helper loaded: form_helper
INFO - 2017-09-09 12:31:03 --> Form Validation Class Initialized
INFO - 2017-09-09 12:31:03 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:31:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:31:03 --> Helper loaded: url_helper
INFO - 2017-09-09 12:31:03 --> Model Class Initialized
INFO - 2017-09-09 12:31:03 --> Model Class Initialized
INFO - 2017-09-09 12:31:03 --> Model Class Initialized
INFO - 2017-09-09 16:01:03 --> Helper loaded: download_helper
INFO - 2017-09-09 12:44:05 --> Config Class Initialized
INFO - 2017-09-09 12:44:05 --> Hooks Class Initialized
DEBUG - 2017-09-09 12:44:05 --> UTF-8 Support Enabled
INFO - 2017-09-09 12:44:05 --> Utf8 Class Initialized
INFO - 2017-09-09 12:44:05 --> URI Class Initialized
INFO - 2017-09-09 12:44:05 --> Router Class Initialized
INFO - 2017-09-09 12:44:05 --> Output Class Initialized
INFO - 2017-09-09 12:44:05 --> Security Class Initialized
DEBUG - 2017-09-09 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-09 12:44:05 --> Input Class Initialized
INFO - 2017-09-09 12:44:05 --> Language Class Initialized
INFO - 2017-09-09 12:44:05 --> Loader Class Initialized
INFO - 2017-09-09 12:44:05 --> Helper loaded: common_helper
INFO - 2017-09-09 12:44:05 --> Database Driver Class Initialized
INFO - 2017-09-09 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-09 12:44:05 --> Email Class Initialized
INFO - 2017-09-09 12:44:05 --> Controller Class Initialized
INFO - 2017-09-09 12:44:05 --> Helper loaded: form_helper
INFO - 2017-09-09 12:44:05 --> Form Validation Class Initialized
INFO - 2017-09-09 12:44:05 --> Helper loaded: email_helper
DEBUG - 2017-09-09 12:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-09 12:44:05 --> Helper loaded: url_helper
INFO - 2017-09-09 12:44:05 --> Model Class Initialized
INFO - 2017-09-09 12:44:05 --> Model Class Initialized
INFO - 2017-09-09 12:44:05 --> Model Class Initialized
INFO - 2017-09-09 16:14:05 --> Helper loaded: download_helper
