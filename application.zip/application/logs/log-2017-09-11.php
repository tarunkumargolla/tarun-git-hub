<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-11 07:25:59 --> Config Class Initialized
INFO - 2017-09-11 07:25:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 07:25:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 07:25:59 --> Utf8 Class Initialized
INFO - 2017-09-11 07:25:59 --> URI Class Initialized
DEBUG - 2017-09-11 07:25:59 --> No URI present. Default controller set.
INFO - 2017-09-11 07:25:59 --> Router Class Initialized
INFO - 2017-09-11 07:25:59 --> Output Class Initialized
INFO - 2017-09-11 07:25:59 --> Security Class Initialized
DEBUG - 2017-09-11 07:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 07:25:59 --> Input Class Initialized
INFO - 2017-09-11 07:25:59 --> Language Class Initialized
INFO - 2017-09-11 07:25:59 --> Loader Class Initialized
INFO - 2017-09-11 07:25:59 --> Helper loaded: common_helper
INFO - 2017-09-11 07:25:59 --> Database Driver Class Initialized
INFO - 2017-09-11 07:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 07:25:59 --> Email Class Initialized
INFO - 2017-09-11 07:25:59 --> Controller Class Initialized
INFO - 2017-09-11 07:25:59 --> Helper loaded: form_helper
INFO - 2017-09-11 07:25:59 --> Form Validation Class Initialized
INFO - 2017-09-11 07:25:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 07:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 07:25:59 --> Helper loaded: url_helper
INFO - 2017-09-11 07:25:59 --> Model Class Initialized
INFO - 2017-09-11 07:25:59 --> Model Class Initialized
INFO - 2017-09-11 07:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-09-11 07:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 07:25:59 --> Final output sent to browser
DEBUG - 2017-09-11 07:25:59 --> Total execution time: 0.1199
INFO - 2017-09-11 07:26:14 --> Config Class Initialized
INFO - 2017-09-11 07:26:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 07:26:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 07:26:14 --> Utf8 Class Initialized
INFO - 2017-09-11 07:26:14 --> URI Class Initialized
INFO - 2017-09-11 07:26:14 --> Router Class Initialized
INFO - 2017-09-11 07:26:14 --> Output Class Initialized
INFO - 2017-09-11 07:26:14 --> Security Class Initialized
DEBUG - 2017-09-11 07:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 07:26:14 --> Input Class Initialized
INFO - 2017-09-11 07:26:14 --> Language Class Initialized
ERROR - 2017-09-11 07:26:14 --> 404 Page Not Found: Downloadxlsphp/index
INFO - 2017-09-11 07:26:27 --> Config Class Initialized
INFO - 2017-09-11 07:26:27 --> Hooks Class Initialized
DEBUG - 2017-09-11 07:26:27 --> UTF-8 Support Enabled
INFO - 2017-09-11 07:26:27 --> Utf8 Class Initialized
INFO - 2017-09-11 07:26:27 --> URI Class Initialized
INFO - 2017-09-11 07:26:27 --> Router Class Initialized
INFO - 2017-09-11 07:26:27 --> Output Class Initialized
INFO - 2017-09-11 07:26:27 --> Security Class Initialized
DEBUG - 2017-09-11 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 07:26:27 --> Input Class Initialized
INFO - 2017-09-11 07:26:27 --> Language Class Initialized
ERROR - 2017-09-11 07:26:27 --> 404 Page Not Found: Downloadxlsphp/index
INFO - 2017-09-11 07:28:41 --> Config Class Initialized
INFO - 2017-09-11 07:28:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 07:28:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 07:28:41 --> Utf8 Class Initialized
INFO - 2017-09-11 07:28:41 --> URI Class Initialized
INFO - 2017-09-11 07:28:41 --> Router Class Initialized
INFO - 2017-09-11 07:28:41 --> Output Class Initialized
INFO - 2017-09-11 07:28:41 --> Security Class Initialized
DEBUG - 2017-09-11 07:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 07:28:41 --> Input Class Initialized
INFO - 2017-09-11 07:28:41 --> Language Class Initialized
ERROR - 2017-09-11 07:28:41 --> 404 Page Not Found: Downloadxlsphp/index
INFO - 2017-09-11 08:38:22 --> Config Class Initialized
INFO - 2017-09-11 08:38:22 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:38:22 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:38:22 --> Utf8 Class Initialized
INFO - 2017-09-11 08:38:22 --> URI Class Initialized
DEBUG - 2017-09-11 08:38:22 --> No URI present. Default controller set.
INFO - 2017-09-11 08:38:22 --> Router Class Initialized
INFO - 2017-09-11 08:38:22 --> Output Class Initialized
INFO - 2017-09-11 08:38:22 --> Security Class Initialized
DEBUG - 2017-09-11 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:38:22 --> Input Class Initialized
INFO - 2017-09-11 08:38:22 --> Language Class Initialized
INFO - 2017-09-11 08:38:22 --> Loader Class Initialized
INFO - 2017-09-11 08:38:22 --> Helper loaded: common_helper
INFO - 2017-09-11 08:38:22 --> Database Driver Class Initialized
INFO - 2017-09-11 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:38:22 --> Email Class Initialized
INFO - 2017-09-11 08:38:22 --> Controller Class Initialized
INFO - 2017-09-11 08:38:22 --> Helper loaded: form_helper
INFO - 2017-09-11 08:38:22 --> Form Validation Class Initialized
INFO - 2017-09-11 08:38:22 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:38:22 --> Helper loaded: url_helper
INFO - 2017-09-11 08:38:22 --> Model Class Initialized
INFO - 2017-09-11 08:38:22 --> Model Class Initialized
INFO - 2017-09-11 08:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-09-11 08:38:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 08:38:22 --> Final output sent to browser
DEBUG - 2017-09-11 08:38:22 --> Total execution time: 0.0437
INFO - 2017-09-11 08:38:30 --> Config Class Initialized
INFO - 2017-09-11 08:38:30 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:38:30 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:38:30 --> Utf8 Class Initialized
INFO - 2017-09-11 08:38:30 --> URI Class Initialized
DEBUG - 2017-09-11 08:38:30 --> No URI present. Default controller set.
INFO - 2017-09-11 08:38:30 --> Router Class Initialized
INFO - 2017-09-11 08:38:30 --> Output Class Initialized
INFO - 2017-09-11 08:38:30 --> Security Class Initialized
DEBUG - 2017-09-11 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:38:30 --> Input Class Initialized
INFO - 2017-09-11 08:38:30 --> Language Class Initialized
INFO - 2017-09-11 08:38:30 --> Loader Class Initialized
INFO - 2017-09-11 08:38:30 --> Helper loaded: common_helper
INFO - 2017-09-11 08:38:30 --> Database Driver Class Initialized
INFO - 2017-09-11 08:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:38:30 --> Email Class Initialized
INFO - 2017-09-11 08:38:30 --> Controller Class Initialized
INFO - 2017-09-11 08:38:30 --> Helper loaded: form_helper
INFO - 2017-09-11 08:38:30 --> Form Validation Class Initialized
INFO - 2017-09-11 08:38:30 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:38:30 --> Helper loaded: url_helper
INFO - 2017-09-11 08:38:30 --> Model Class Initialized
INFO - 2017-09-11 08:38:30 --> Model Class Initialized
DEBUG - 2017-09-11 08:38:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:38:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 08:38:30 --> Config Class Initialized
INFO - 2017-09-11 08:38:30 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:38:30 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:38:30 --> Utf8 Class Initialized
INFO - 2017-09-11 08:38:30 --> URI Class Initialized
INFO - 2017-09-11 08:38:30 --> Router Class Initialized
INFO - 2017-09-11 08:38:30 --> Output Class Initialized
INFO - 2017-09-11 08:38:30 --> Security Class Initialized
DEBUG - 2017-09-11 08:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:38:30 --> Input Class Initialized
INFO - 2017-09-11 08:38:30 --> Language Class Initialized
INFO - 2017-09-11 08:38:30 --> Loader Class Initialized
INFO - 2017-09-11 08:38:30 --> Helper loaded: common_helper
INFO - 2017-09-11 08:38:31 --> Database Driver Class Initialized
INFO - 2017-09-11 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:38:31 --> Email Class Initialized
INFO - 2017-09-11 08:38:31 --> Controller Class Initialized
INFO - 2017-09-11 08:38:31 --> Helper loaded: form_helper
INFO - 2017-09-11 08:38:31 --> Form Validation Class Initialized
INFO - 2017-09-11 08:38:31 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:38:31 --> Helper loaded: url_helper
INFO - 2017-09-11 08:38:31 --> Model Class Initialized
INFO - 2017-09-11 08:38:31 --> Model Class Initialized
INFO - 2017-09-11 08:38:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 08:38:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 08:38:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-09-11 08:38:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 08:38:31 --> Final output sent to browser
DEBUG - 2017-09-11 08:38:31 --> Total execution time: 0.0597
INFO - 2017-09-11 08:38:38 --> Config Class Initialized
INFO - 2017-09-11 08:38:38 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:38:38 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:38:38 --> Utf8 Class Initialized
INFO - 2017-09-11 08:38:38 --> URI Class Initialized
INFO - 2017-09-11 08:38:38 --> Router Class Initialized
INFO - 2017-09-11 08:38:38 --> Output Class Initialized
INFO - 2017-09-11 08:38:38 --> Security Class Initialized
DEBUG - 2017-09-11 08:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:38:38 --> Input Class Initialized
INFO - 2017-09-11 08:38:38 --> Language Class Initialized
ERROR - 2017-09-11 08:38:38 --> syntax error, unexpected ':'
ERROR - 2017-09-11 08:38:38 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 166
INFO - 2017-09-11 08:38:49 --> Config Class Initialized
INFO - 2017-09-11 08:38:49 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:38:49 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:38:49 --> Utf8 Class Initialized
INFO - 2017-09-11 08:38:49 --> URI Class Initialized
INFO - 2017-09-11 08:38:49 --> Router Class Initialized
INFO - 2017-09-11 08:38:49 --> Output Class Initialized
INFO - 2017-09-11 08:38:49 --> Security Class Initialized
DEBUG - 2017-09-11 08:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:38:49 --> Input Class Initialized
INFO - 2017-09-11 08:38:49 --> Language Class Initialized
ERROR - 2017-09-11 08:38:49 --> syntax error, unexpected ''</td>  ' (T_CONSTANT_ENCAPSED_STRING)
ERROR - 2017-09-11 08:38:49 --> Severity: Parsing Error --> syntax error, unexpected ''</td>  ' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
INFO - 2017-09-11 08:39:21 --> Config Class Initialized
INFO - 2017-09-11 08:39:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:39:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:39:21 --> Utf8 Class Initialized
INFO - 2017-09-11 08:39:21 --> URI Class Initialized
INFO - 2017-09-11 08:39:21 --> Router Class Initialized
INFO - 2017-09-11 08:39:21 --> Output Class Initialized
INFO - 2017-09-11 08:39:21 --> Security Class Initialized
DEBUG - 2017-09-11 08:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:39:21 --> Input Class Initialized
INFO - 2017-09-11 08:39:21 --> Language Class Initialized
INFO - 2017-09-11 08:39:21 --> Loader Class Initialized
INFO - 2017-09-11 08:39:21 --> Helper loaded: common_helper
INFO - 2017-09-11 08:39:21 --> Database Driver Class Initialized
INFO - 2017-09-11 08:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:39:21 --> Email Class Initialized
INFO - 2017-09-11 08:39:21 --> Controller Class Initialized
INFO - 2017-09-11 08:39:21 --> Helper loaded: form_helper
INFO - 2017-09-11 08:39:21 --> Form Validation Class Initialized
INFO - 2017-09-11 08:39:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:39:21 --> Helper loaded: url_helper
INFO - 2017-09-11 08:39:21 --> Model Class Initialized
INFO - 2017-09-11 08:39:21 --> Model Class Initialized
INFO - 2017-09-11 08:39:21 --> Model Class Initialized
INFO - 2017-09-11 12:09:21 --> Helper loaded: download_helper
INFO - 2017-09-11 12:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:09:22 --> Final output sent to browser
DEBUG - 2017-09-11 12:09:22 --> Total execution time: 0.4532
INFO - 2017-09-11 08:39:54 --> Config Class Initialized
INFO - 2017-09-11 08:39:54 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:39:54 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:39:54 --> Utf8 Class Initialized
INFO - 2017-09-11 08:39:54 --> URI Class Initialized
INFO - 2017-09-11 08:39:54 --> Router Class Initialized
INFO - 2017-09-11 08:39:54 --> Output Class Initialized
INFO - 2017-09-11 08:39:54 --> Security Class Initialized
DEBUG - 2017-09-11 08:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:39:54 --> Input Class Initialized
INFO - 2017-09-11 08:39:54 --> Language Class Initialized
INFO - 2017-09-11 08:39:54 --> Loader Class Initialized
INFO - 2017-09-11 08:39:54 --> Helper loaded: common_helper
INFO - 2017-09-11 08:39:54 --> Database Driver Class Initialized
INFO - 2017-09-11 08:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:39:54 --> Email Class Initialized
INFO - 2017-09-11 08:39:54 --> Controller Class Initialized
INFO - 2017-09-11 08:39:54 --> Helper loaded: form_helper
INFO - 2017-09-11 08:39:54 --> Form Validation Class Initialized
INFO - 2017-09-11 08:39:54 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:39:54 --> Helper loaded: url_helper
INFO - 2017-09-11 08:39:54 --> Model Class Initialized
INFO - 2017-09-11 08:39:54 --> Model Class Initialized
INFO - 2017-09-11 08:39:54 --> Model Class Initialized
INFO - 2017-09-11 12:09:54 --> Helper loaded: download_helper
INFO - 2017-09-11 12:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:09:54 --> Final output sent to browser
DEBUG - 2017-09-11 12:09:54 --> Total execution time: 0.0876
INFO - 2017-09-11 08:40:06 --> Config Class Initialized
INFO - 2017-09-11 08:40:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:40:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:40:06 --> Utf8 Class Initialized
INFO - 2017-09-11 08:40:06 --> URI Class Initialized
INFO - 2017-09-11 08:40:06 --> Router Class Initialized
INFO - 2017-09-11 08:40:06 --> Output Class Initialized
INFO - 2017-09-11 08:40:06 --> Security Class Initialized
DEBUG - 2017-09-11 08:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:40:06 --> Input Class Initialized
INFO - 2017-09-11 08:40:06 --> Language Class Initialized
INFO - 2017-09-11 08:40:06 --> Loader Class Initialized
INFO - 2017-09-11 08:40:06 --> Helper loaded: common_helper
INFO - 2017-09-11 08:40:06 --> Database Driver Class Initialized
INFO - 2017-09-11 08:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:40:06 --> Email Class Initialized
INFO - 2017-09-11 08:40:06 --> Controller Class Initialized
INFO - 2017-09-11 08:40:06 --> Helper loaded: form_helper
INFO - 2017-09-11 08:40:06 --> Form Validation Class Initialized
INFO - 2017-09-11 08:40:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:40:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:40:06 --> Helper loaded: url_helper
INFO - 2017-09-11 08:40:06 --> Model Class Initialized
INFO - 2017-09-11 08:40:06 --> Model Class Initialized
INFO - 2017-09-11 08:40:06 --> Model Class Initialized
INFO - 2017-09-11 12:10:06 --> Helper loaded: download_helper
INFO - 2017-09-11 12:10:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:10:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:10:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:10:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:10:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:10:06 --> Final output sent to browser
DEBUG - 2017-09-11 12:10:06 --> Total execution time: 0.0839
INFO - 2017-09-11 08:41:12 --> Config Class Initialized
INFO - 2017-09-11 08:41:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:41:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:41:12 --> Utf8 Class Initialized
INFO - 2017-09-11 08:41:12 --> URI Class Initialized
INFO - 2017-09-11 08:41:12 --> Router Class Initialized
INFO - 2017-09-11 08:41:12 --> Output Class Initialized
INFO - 2017-09-11 08:41:12 --> Security Class Initialized
DEBUG - 2017-09-11 08:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:41:12 --> Input Class Initialized
INFO - 2017-09-11 08:41:12 --> Language Class Initialized
INFO - 2017-09-11 08:41:12 --> Loader Class Initialized
INFO - 2017-09-11 08:41:12 --> Helper loaded: common_helper
INFO - 2017-09-11 08:41:12 --> Database Driver Class Initialized
INFO - 2017-09-11 08:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:41:12 --> Email Class Initialized
INFO - 2017-09-11 08:41:12 --> Controller Class Initialized
INFO - 2017-09-11 08:41:12 --> Helper loaded: form_helper
INFO - 2017-09-11 08:41:12 --> Form Validation Class Initialized
INFO - 2017-09-11 08:41:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:41:12 --> Helper loaded: url_helper
INFO - 2017-09-11 08:41:12 --> Model Class Initialized
INFO - 2017-09-11 08:41:12 --> Model Class Initialized
INFO - 2017-09-11 08:41:12 --> Model Class Initialized
INFO - 2017-09-11 12:11:12 --> Helper loaded: download_helper
INFO - 2017-09-11 12:11:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:11:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:11:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:11:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:11:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:11:12 --> Final output sent to browser
DEBUG - 2017-09-11 12:11:12 --> Total execution time: 0.0851
INFO - 2017-09-11 08:41:13 --> Config Class Initialized
INFO - 2017-09-11 08:41:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:41:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:41:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:41:13 --> URI Class Initialized
INFO - 2017-09-11 08:41:13 --> Router Class Initialized
INFO - 2017-09-11 08:41:13 --> Output Class Initialized
INFO - 2017-09-11 08:41:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:41:13 --> Input Class Initialized
INFO - 2017-09-11 08:41:13 --> Language Class Initialized
INFO - 2017-09-11 08:41:13 --> Loader Class Initialized
INFO - 2017-09-11 08:41:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:41:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:41:13 --> Email Class Initialized
INFO - 2017-09-11 08:41:13 --> Controller Class Initialized
INFO - 2017-09-11 08:41:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:41:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:41:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:41:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:41:13 --> Model Class Initialized
INFO - 2017-09-11 08:41:13 --> Model Class Initialized
INFO - 2017-09-11 08:41:13 --> Model Class Initialized
INFO - 2017-09-11 12:11:13 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:11:13 --> Undefined variable: details
ERROR - 2017-09-11 12:11:13 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 165
INFO - 2017-09-11 08:41:41 --> Config Class Initialized
INFO - 2017-09-11 08:41:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:41:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:41:41 --> Utf8 Class Initialized
INFO - 2017-09-11 08:41:41 --> URI Class Initialized
INFO - 2017-09-11 08:41:41 --> Router Class Initialized
INFO - 2017-09-11 08:41:41 --> Output Class Initialized
INFO - 2017-09-11 08:41:41 --> Security Class Initialized
DEBUG - 2017-09-11 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:41:41 --> Input Class Initialized
INFO - 2017-09-11 08:41:41 --> Language Class Initialized
INFO - 2017-09-11 08:41:41 --> Loader Class Initialized
INFO - 2017-09-11 08:41:41 --> Helper loaded: common_helper
INFO - 2017-09-11 08:41:41 --> Database Driver Class Initialized
INFO - 2017-09-11 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:41:41 --> Email Class Initialized
INFO - 2017-09-11 08:41:41 --> Controller Class Initialized
INFO - 2017-09-11 08:41:41 --> Helper loaded: form_helper
INFO - 2017-09-11 08:41:41 --> Form Validation Class Initialized
INFO - 2017-09-11 08:41:41 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:41:41 --> Helper loaded: url_helper
INFO - 2017-09-11 08:41:41 --> Model Class Initialized
INFO - 2017-09-11 08:41:41 --> Model Class Initialized
INFO - 2017-09-11 08:41:41 --> Model Class Initialized
INFO - 2017-09-11 12:11:41 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:11:41 --> Undefined variable: details
ERROR - 2017-09-11 12:11:41 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 165
INFO - 2017-09-11 08:41:53 --> Config Class Initialized
INFO - 2017-09-11 08:41:53 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:41:53 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:41:53 --> Utf8 Class Initialized
INFO - 2017-09-11 08:41:53 --> URI Class Initialized
INFO - 2017-09-11 08:41:53 --> Router Class Initialized
INFO - 2017-09-11 08:41:53 --> Output Class Initialized
INFO - 2017-09-11 08:41:53 --> Security Class Initialized
DEBUG - 2017-09-11 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:41:53 --> Input Class Initialized
INFO - 2017-09-11 08:41:53 --> Language Class Initialized
INFO - 2017-09-11 08:41:53 --> Loader Class Initialized
INFO - 2017-09-11 08:41:53 --> Helper loaded: common_helper
INFO - 2017-09-11 08:41:53 --> Database Driver Class Initialized
INFO - 2017-09-11 08:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:41:53 --> Email Class Initialized
INFO - 2017-09-11 08:41:53 --> Controller Class Initialized
INFO - 2017-09-11 08:41:53 --> Helper loaded: form_helper
INFO - 2017-09-11 08:41:53 --> Form Validation Class Initialized
INFO - 2017-09-11 08:41:53 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:41:53 --> Helper loaded: url_helper
INFO - 2017-09-11 08:41:53 --> Model Class Initialized
INFO - 2017-09-11 08:41:53 --> Model Class Initialized
INFO - 2017-09-11 08:41:53 --> Model Class Initialized
INFO - 2017-09-11 12:11:53 --> Helper loaded: download_helper
INFO - 2017-09-11 08:42:05 --> Config Class Initialized
INFO - 2017-09-11 08:42:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:42:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:42:05 --> Utf8 Class Initialized
INFO - 2017-09-11 08:42:05 --> URI Class Initialized
INFO - 2017-09-11 08:42:05 --> Router Class Initialized
INFO - 2017-09-11 08:42:05 --> Output Class Initialized
INFO - 2017-09-11 08:42:05 --> Security Class Initialized
DEBUG - 2017-09-11 08:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:42:05 --> Input Class Initialized
INFO - 2017-09-11 08:42:05 --> Language Class Initialized
INFO - 2017-09-11 08:42:05 --> Loader Class Initialized
INFO - 2017-09-11 08:42:05 --> Helper loaded: common_helper
INFO - 2017-09-11 08:42:05 --> Database Driver Class Initialized
INFO - 2017-09-11 08:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:42:05 --> Email Class Initialized
INFO - 2017-09-11 08:42:05 --> Controller Class Initialized
INFO - 2017-09-11 08:42:05 --> Helper loaded: form_helper
INFO - 2017-09-11 08:42:05 --> Form Validation Class Initialized
INFO - 2017-09-11 08:42:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:42:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:42:05 --> Helper loaded: url_helper
INFO - 2017-09-11 08:42:05 --> Model Class Initialized
INFO - 2017-09-11 08:42:05 --> Model Class Initialized
INFO - 2017-09-11 08:42:05 --> Model Class Initialized
INFO - 2017-09-11 12:12:05 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:12:05 --> Undefined variable: deatils
ERROR - 2017-09-11 12:12:05 --> Severity: Notice --> Undefined variable: deatils C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 167
INFO - 2017-09-11 12:12:05 --> Final output sent to browser
DEBUG - 2017-09-11 12:12:05 --> Total execution time: 0.0813
INFO - 2017-09-11 08:42:16 --> Config Class Initialized
INFO - 2017-09-11 08:42:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:42:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:42:16 --> Utf8 Class Initialized
INFO - 2017-09-11 08:42:16 --> URI Class Initialized
INFO - 2017-09-11 08:42:16 --> Router Class Initialized
INFO - 2017-09-11 08:42:16 --> Output Class Initialized
INFO - 2017-09-11 08:42:16 --> Security Class Initialized
DEBUG - 2017-09-11 08:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:42:16 --> Input Class Initialized
INFO - 2017-09-11 08:42:16 --> Language Class Initialized
INFO - 2017-09-11 08:42:16 --> Loader Class Initialized
INFO - 2017-09-11 08:42:16 --> Helper loaded: common_helper
INFO - 2017-09-11 08:42:16 --> Database Driver Class Initialized
INFO - 2017-09-11 08:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:42:16 --> Email Class Initialized
INFO - 2017-09-11 08:42:16 --> Controller Class Initialized
INFO - 2017-09-11 08:42:16 --> Helper loaded: form_helper
INFO - 2017-09-11 08:42:16 --> Form Validation Class Initialized
INFO - 2017-09-11 08:42:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:42:16 --> Helper loaded: url_helper
INFO - 2017-09-11 08:42:16 --> Model Class Initialized
INFO - 2017-09-11 08:42:16 --> Model Class Initialized
INFO - 2017-09-11 08:42:16 --> Model Class Initialized
INFO - 2017-09-11 12:12:16 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:12:16 --> Undefined variable: deatils
ERROR - 2017-09-11 12:12:16 --> Severity: Notice --> Undefined variable: deatils C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 167
INFO - 2017-09-11 12:12:16 --> Final output sent to browser
DEBUG - 2017-09-11 12:12:16 --> Total execution time: 0.0796
INFO - 2017-09-11 08:42:59 --> Config Class Initialized
INFO - 2017-09-11 08:42:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:42:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:42:59 --> Utf8 Class Initialized
INFO - 2017-09-11 08:42:59 --> URI Class Initialized
INFO - 2017-09-11 08:42:59 --> Router Class Initialized
INFO - 2017-09-11 08:42:59 --> Output Class Initialized
INFO - 2017-09-11 08:42:59 --> Security Class Initialized
DEBUG - 2017-09-11 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:42:59 --> Input Class Initialized
INFO - 2017-09-11 08:42:59 --> Language Class Initialized
INFO - 2017-09-11 08:42:59 --> Loader Class Initialized
INFO - 2017-09-11 08:42:59 --> Helper loaded: common_helper
INFO - 2017-09-11 08:42:59 --> Database Driver Class Initialized
INFO - 2017-09-11 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:42:59 --> Email Class Initialized
INFO - 2017-09-11 08:42:59 --> Controller Class Initialized
INFO - 2017-09-11 08:42:59 --> Helper loaded: form_helper
INFO - 2017-09-11 08:42:59 --> Form Validation Class Initialized
INFO - 2017-09-11 08:42:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:42:59 --> Helper loaded: url_helper
INFO - 2017-09-11 08:42:59 --> Model Class Initialized
INFO - 2017-09-11 08:42:59 --> Model Class Initialized
INFO - 2017-09-11 08:42:59 --> Model Class Initialized
INFO - 2017-09-11 12:12:59 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:12:59 --> Undefined variable: deatils
ERROR - 2017-09-11 12:12:59 --> Severity: Notice --> Undefined variable: deatils C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 166
INFO - 2017-09-11 12:12:59 --> Final output sent to browser
DEBUG - 2017-09-11 12:12:59 --> Total execution time: 0.0466
INFO - 2017-09-11 08:46:52 --> Config Class Initialized
INFO - 2017-09-11 08:46:52 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:46:52 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:46:52 --> Utf8 Class Initialized
INFO - 2017-09-11 08:46:52 --> URI Class Initialized
INFO - 2017-09-11 08:46:52 --> Router Class Initialized
INFO - 2017-09-11 08:46:52 --> Output Class Initialized
INFO - 2017-09-11 08:46:52 --> Security Class Initialized
DEBUG - 2017-09-11 08:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:46:52 --> Input Class Initialized
INFO - 2017-09-11 08:46:52 --> Language Class Initialized
INFO - 2017-09-11 08:46:52 --> Loader Class Initialized
INFO - 2017-09-11 08:46:52 --> Helper loaded: common_helper
INFO - 2017-09-11 08:46:52 --> Database Driver Class Initialized
INFO - 2017-09-11 08:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:46:52 --> Email Class Initialized
INFO - 2017-09-11 08:46:52 --> Controller Class Initialized
INFO - 2017-09-11 08:46:52 --> Helper loaded: form_helper
INFO - 2017-09-11 08:46:52 --> Form Validation Class Initialized
INFO - 2017-09-11 08:46:52 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:46:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:46:52 --> Helper loaded: url_helper
INFO - 2017-09-11 08:46:52 --> Model Class Initialized
INFO - 2017-09-11 08:46:52 --> Model Class Initialized
INFO - 2017-09-11 08:46:52 --> Model Class Initialized
INFO - 2017-09-11 12:16:52 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:16:52 --> Undefined variable: deatils
ERROR - 2017-09-11 12:16:52 --> Severity: Notice --> Undefined variable: deatils C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 166
ERROR - 2017-09-11 12:16:52 --> syntax error, unexpected '*'
ERROR - 2017-09-11 12:16:52 --> Severity: Parsing Error --> syntax error, unexpected '*' C:\xampp\htdocs\FlickNews\admin\application\views\export.php 2
INFO - 2017-09-11 08:47:40 --> Config Class Initialized
INFO - 2017-09-11 08:47:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:47:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:47:40 --> Utf8 Class Initialized
INFO - 2017-09-11 08:47:40 --> URI Class Initialized
INFO - 2017-09-11 08:47:40 --> Router Class Initialized
INFO - 2017-09-11 08:47:40 --> Output Class Initialized
INFO - 2017-09-11 08:47:40 --> Security Class Initialized
DEBUG - 2017-09-11 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:47:40 --> Input Class Initialized
INFO - 2017-09-11 08:47:40 --> Language Class Initialized
INFO - 2017-09-11 08:47:40 --> Loader Class Initialized
INFO - 2017-09-11 08:47:40 --> Helper loaded: common_helper
INFO - 2017-09-11 08:47:40 --> Database Driver Class Initialized
INFO - 2017-09-11 08:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:47:40 --> Email Class Initialized
INFO - 2017-09-11 08:47:40 --> Controller Class Initialized
INFO - 2017-09-11 08:47:40 --> Helper loaded: form_helper
INFO - 2017-09-11 08:47:40 --> Form Validation Class Initialized
INFO - 2017-09-11 08:47:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:47:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:47:40 --> Helper loaded: url_helper
INFO - 2017-09-11 08:47:40 --> Model Class Initialized
INFO - 2017-09-11 08:47:40 --> Model Class Initialized
INFO - 2017-09-11 08:47:40 --> Model Class Initialized
INFO - 2017-09-11 12:17:40 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 179
ERROR - 2017-09-11 12:17:40 --> Trying to get property of non-object
ERROR - 2017-09-11 12:17:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:17:40 --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275)
ERROR - 2017-09-11 12:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 187
ERROR - 2017-09-11 12:17:40 --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275)
ERROR - 2017-09-11 12:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 188
INFO - 2017-09-11 12:17:40 --> Final output sent to browser
DEBUG - 2017-09-11 12:17:40 --> Total execution time: 0.1008
INFO - 2017-09-11 08:48:15 --> Config Class Initialized
INFO - 2017-09-11 08:48:15 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:48:15 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:48:15 --> Utf8 Class Initialized
INFO - 2017-09-11 08:48:15 --> URI Class Initialized
INFO - 2017-09-11 08:48:15 --> Router Class Initialized
INFO - 2017-09-11 08:48:15 --> Output Class Initialized
INFO - 2017-09-11 08:48:15 --> Security Class Initialized
DEBUG - 2017-09-11 08:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:48:15 --> Input Class Initialized
INFO - 2017-09-11 08:48:15 --> Language Class Initialized
INFO - 2017-09-11 08:48:15 --> Loader Class Initialized
INFO - 2017-09-11 08:48:15 --> Helper loaded: common_helper
INFO - 2017-09-11 08:48:15 --> Database Driver Class Initialized
INFO - 2017-09-11 08:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:48:15 --> Email Class Initialized
INFO - 2017-09-11 08:48:15 --> Controller Class Initialized
INFO - 2017-09-11 08:48:15 --> Helper loaded: form_helper
INFO - 2017-09-11 08:48:15 --> Form Validation Class Initialized
INFO - 2017-09-11 08:48:15 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:48:15 --> Helper loaded: url_helper
INFO - 2017-09-11 08:48:15 --> Model Class Initialized
INFO - 2017-09-11 08:48:15 --> Model Class Initialized
INFO - 2017-09-11 08:48:15 --> Model Class Initialized
INFO - 2017-09-11 12:18:15 --> Helper loaded: download_helper
INFO - 2017-09-11 08:48:28 --> Config Class Initialized
INFO - 2017-09-11 08:48:28 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:48:28 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:48:28 --> Utf8 Class Initialized
INFO - 2017-09-11 08:48:28 --> URI Class Initialized
INFO - 2017-09-11 08:48:28 --> Router Class Initialized
INFO - 2017-09-11 08:48:28 --> Output Class Initialized
INFO - 2017-09-11 08:48:28 --> Security Class Initialized
DEBUG - 2017-09-11 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:48:28 --> Input Class Initialized
INFO - 2017-09-11 08:48:28 --> Language Class Initialized
INFO - 2017-09-11 08:48:28 --> Loader Class Initialized
INFO - 2017-09-11 08:48:28 --> Helper loaded: common_helper
INFO - 2017-09-11 08:48:28 --> Database Driver Class Initialized
INFO - 2017-09-11 08:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:48:28 --> Email Class Initialized
INFO - 2017-09-11 08:48:28 --> Controller Class Initialized
INFO - 2017-09-11 08:48:28 --> Helper loaded: form_helper
INFO - 2017-09-11 08:48:28 --> Form Validation Class Initialized
INFO - 2017-09-11 08:48:28 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:48:28 --> Helper loaded: url_helper
INFO - 2017-09-11 08:48:28 --> Model Class Initialized
INFO - 2017-09-11 08:48:28 --> Model Class Initialized
INFO - 2017-09-11 08:48:28 --> Model Class Initialized
INFO - 2017-09-11 12:18:28 --> Helper loaded: download_helper
INFO - 2017-09-11 08:48:37 --> Config Class Initialized
INFO - 2017-09-11 08:48:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:48:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:48:37 --> Utf8 Class Initialized
INFO - 2017-09-11 08:48:37 --> URI Class Initialized
INFO - 2017-09-11 08:48:37 --> Router Class Initialized
INFO - 2017-09-11 08:48:37 --> Output Class Initialized
INFO - 2017-09-11 08:48:37 --> Security Class Initialized
DEBUG - 2017-09-11 08:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:48:37 --> Input Class Initialized
INFO - 2017-09-11 08:48:37 --> Language Class Initialized
INFO - 2017-09-11 08:48:37 --> Loader Class Initialized
INFO - 2017-09-11 08:48:37 --> Helper loaded: common_helper
INFO - 2017-09-11 08:48:37 --> Database Driver Class Initialized
INFO - 2017-09-11 08:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:48:37 --> Email Class Initialized
INFO - 2017-09-11 08:48:37 --> Controller Class Initialized
INFO - 2017-09-11 08:48:37 --> Helper loaded: form_helper
INFO - 2017-09-11 08:48:37 --> Form Validation Class Initialized
INFO - 2017-09-11 08:48:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:48:37 --> Helper loaded: url_helper
INFO - 2017-09-11 08:48:37 --> Model Class Initialized
INFO - 2017-09-11 08:48:37 --> Model Class Initialized
INFO - 2017-09-11 08:48:37 --> Model Class Initialized
INFO - 2017-09-11 12:18:37 --> Helper loaded: download_helper
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$name
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$name C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 178
ERROR - 2017-09-11 12:18:37 --> Undefined property: stdClass::$phoneNumber
ERROR - 2017-09-11 12:18:37 --> Severity: Notice --> Undefined property: stdClass::$phoneNumber C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 180
ERROR - 2017-09-11 12:18:37 --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275)
ERROR - 2017-09-11 12:18:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 187
ERROR - 2017-09-11 12:18:37 --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275)
ERROR - 2017-09-11 12:18:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\FlickNews\admin\system\core\Exceptions.php:275) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 188
INFO - 2017-09-11 12:18:37 --> Final output sent to browser
DEBUG - 2017-09-11 12:18:37 --> Total execution time: 0.0798
INFO - 2017-09-11 08:48:59 --> Config Class Initialized
INFO - 2017-09-11 08:48:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:48:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:48:59 --> Utf8 Class Initialized
INFO - 2017-09-11 08:48:59 --> URI Class Initialized
INFO - 2017-09-11 08:48:59 --> Router Class Initialized
INFO - 2017-09-11 08:48:59 --> Output Class Initialized
INFO - 2017-09-11 08:48:59 --> Security Class Initialized
DEBUG - 2017-09-11 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:48:59 --> Input Class Initialized
INFO - 2017-09-11 08:48:59 --> Language Class Initialized
INFO - 2017-09-11 08:48:59 --> Loader Class Initialized
INFO - 2017-09-11 08:48:59 --> Helper loaded: common_helper
INFO - 2017-09-11 08:48:59 --> Database Driver Class Initialized
INFO - 2017-09-11 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:48:59 --> Email Class Initialized
INFO - 2017-09-11 08:48:59 --> Controller Class Initialized
INFO - 2017-09-11 08:48:59 --> Helper loaded: form_helper
INFO - 2017-09-11 08:48:59 --> Form Validation Class Initialized
INFO - 2017-09-11 08:48:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:48:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:48:59 --> Helper loaded: url_helper
INFO - 2017-09-11 08:48:59 --> Model Class Initialized
INFO - 2017-09-11 08:48:59 --> Model Class Initialized
INFO - 2017-09-11 08:48:59 --> Model Class Initialized
INFO - 2017-09-11 12:18:59 --> Helper loaded: download_helper
INFO - 2017-09-11 08:49:13 --> Config Class Initialized
INFO - 2017-09-11 08:49:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:49:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:49:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:49:13 --> URI Class Initialized
INFO - 2017-09-11 08:49:13 --> Router Class Initialized
INFO - 2017-09-11 08:49:13 --> Output Class Initialized
INFO - 2017-09-11 08:49:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:49:13 --> Input Class Initialized
INFO - 2017-09-11 08:49:13 --> Language Class Initialized
INFO - 2017-09-11 08:49:13 --> Loader Class Initialized
INFO - 2017-09-11 08:49:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:49:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:49:13 --> Email Class Initialized
INFO - 2017-09-11 08:49:13 --> Controller Class Initialized
INFO - 2017-09-11 08:49:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:49:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:49:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:49:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:49:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:49:13 --> Model Class Initialized
INFO - 2017-09-11 08:49:13 --> Model Class Initialized
INFO - 2017-09-11 08:49:13 --> Model Class Initialized
INFO - 2017-09-11 12:19:13 --> Helper loaded: download_helper
INFO - 2017-09-11 12:19:13 --> Final output sent to browser
DEBUG - 2017-09-11 12:19:13 --> Total execution time: 0.0440
INFO - 2017-09-11 08:51:58 --> Config Class Initialized
INFO - 2017-09-11 08:51:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:51:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:51:58 --> Utf8 Class Initialized
INFO - 2017-09-11 08:51:58 --> URI Class Initialized
INFO - 2017-09-11 08:51:58 --> Router Class Initialized
INFO - 2017-09-11 08:51:58 --> Output Class Initialized
INFO - 2017-09-11 08:51:58 --> Security Class Initialized
DEBUG - 2017-09-11 08:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:51:58 --> Input Class Initialized
INFO - 2017-09-11 08:51:58 --> Language Class Initialized
INFO - 2017-09-11 08:51:58 --> Loader Class Initialized
INFO - 2017-09-11 08:51:58 --> Helper loaded: common_helper
INFO - 2017-09-11 08:51:58 --> Database Driver Class Initialized
INFO - 2017-09-11 08:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:51:58 --> Email Class Initialized
INFO - 2017-09-11 08:51:58 --> Controller Class Initialized
INFO - 2017-09-11 08:51:58 --> Helper loaded: form_helper
INFO - 2017-09-11 08:51:58 --> Form Validation Class Initialized
INFO - 2017-09-11 08:51:58 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:51:58 --> Helper loaded: url_helper
INFO - 2017-09-11 08:51:58 --> Model Class Initialized
INFO - 2017-09-11 08:51:58 --> Model Class Initialized
INFO - 2017-09-11 08:51:58 --> Model Class Initialized
INFO - 2017-09-11 12:21:58 --> Helper loaded: download_helper
INFO - 2017-09-11 12:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:21:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:21:58 --> Final output sent to browser
DEBUG - 2017-09-11 12:21:58 --> Total execution time: 0.0488
INFO - 2017-09-11 08:51:59 --> Config Class Initialized
INFO - 2017-09-11 08:51:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:51:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:51:59 --> Utf8 Class Initialized
INFO - 2017-09-11 08:51:59 --> URI Class Initialized
INFO - 2017-09-11 08:51:59 --> Router Class Initialized
INFO - 2017-09-11 08:51:59 --> Output Class Initialized
INFO - 2017-09-11 08:51:59 --> Security Class Initialized
DEBUG - 2017-09-11 08:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:51:59 --> Input Class Initialized
INFO - 2017-09-11 08:51:59 --> Language Class Initialized
INFO - 2017-09-11 08:51:59 --> Loader Class Initialized
INFO - 2017-09-11 08:51:59 --> Helper loaded: common_helper
INFO - 2017-09-11 08:51:59 --> Database Driver Class Initialized
INFO - 2017-09-11 08:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:51:59 --> Email Class Initialized
INFO - 2017-09-11 08:51:59 --> Controller Class Initialized
INFO - 2017-09-11 08:51:59 --> Helper loaded: form_helper
INFO - 2017-09-11 08:51:59 --> Form Validation Class Initialized
INFO - 2017-09-11 08:51:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:51:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:51:59 --> Helper loaded: url_helper
INFO - 2017-09-11 08:51:59 --> Model Class Initialized
INFO - 2017-09-11 08:51:59 --> Model Class Initialized
INFO - 2017-09-11 08:51:59 --> Model Class Initialized
INFO - 2017-09-11 12:21:59 --> Helper loaded: download_helper
INFO - 2017-09-11 12:21:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:21:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:21:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:21:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:21:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:21:59 --> Final output sent to browser
DEBUG - 2017-09-11 12:21:59 --> Total execution time: 0.0472
INFO - 2017-09-11 08:52:35 --> Config Class Initialized
INFO - 2017-09-11 08:52:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:52:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:52:35 --> Utf8 Class Initialized
INFO - 2017-09-11 08:52:35 --> URI Class Initialized
INFO - 2017-09-11 08:52:35 --> Router Class Initialized
INFO - 2017-09-11 08:52:35 --> Output Class Initialized
INFO - 2017-09-11 08:52:35 --> Security Class Initialized
DEBUG - 2017-09-11 08:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:52:35 --> Input Class Initialized
INFO - 2017-09-11 08:52:35 --> Language Class Initialized
INFO - 2017-09-11 08:52:35 --> Loader Class Initialized
INFO - 2017-09-11 08:52:35 --> Helper loaded: common_helper
INFO - 2017-09-11 08:52:35 --> Database Driver Class Initialized
INFO - 2017-09-11 08:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:52:35 --> Email Class Initialized
INFO - 2017-09-11 08:52:35 --> Controller Class Initialized
INFO - 2017-09-11 08:52:35 --> Helper loaded: form_helper
INFO - 2017-09-11 08:52:35 --> Form Validation Class Initialized
INFO - 2017-09-11 08:52:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:52:35 --> Helper loaded: url_helper
INFO - 2017-09-11 08:52:35 --> Model Class Initialized
INFO - 2017-09-11 08:52:35 --> Model Class Initialized
INFO - 2017-09-11 08:52:35 --> Model Class Initialized
INFO - 2017-09-11 12:22:35 --> Helper loaded: download_helper
INFO - 2017-09-11 12:22:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:22:36 --> syntax error, unexpected '?>'
ERROR - 2017-09-11 12:22:36 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\FlickNews\admin\application\views\users\users.php 23
INFO - 2017-09-11 08:52:45 --> Config Class Initialized
INFO - 2017-09-11 08:52:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:52:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:52:45 --> Utf8 Class Initialized
INFO - 2017-09-11 08:52:45 --> URI Class Initialized
INFO - 2017-09-11 08:52:45 --> Router Class Initialized
INFO - 2017-09-11 08:52:45 --> Output Class Initialized
INFO - 2017-09-11 08:52:45 --> Security Class Initialized
DEBUG - 2017-09-11 08:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:52:45 --> Input Class Initialized
INFO - 2017-09-11 08:52:45 --> Language Class Initialized
INFO - 2017-09-11 08:52:45 --> Loader Class Initialized
INFO - 2017-09-11 08:52:45 --> Helper loaded: common_helper
INFO - 2017-09-11 08:52:45 --> Database Driver Class Initialized
INFO - 2017-09-11 08:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:52:45 --> Email Class Initialized
INFO - 2017-09-11 08:52:45 --> Controller Class Initialized
INFO - 2017-09-11 08:52:45 --> Helper loaded: form_helper
INFO - 2017-09-11 08:52:45 --> Form Validation Class Initialized
INFO - 2017-09-11 08:52:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:52:45 --> Helper loaded: url_helper
INFO - 2017-09-11 08:52:45 --> Model Class Initialized
INFO - 2017-09-11 08:52:45 --> Model Class Initialized
INFO - 2017-09-11 08:52:45 --> Model Class Initialized
INFO - 2017-09-11 12:22:45 --> Helper loaded: download_helper
INFO - 2017-09-11 12:22:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:22:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:22:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:22:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:22:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:22:45 --> Final output sent to browser
DEBUG - 2017-09-11 12:22:45 --> Total execution time: 0.0476
INFO - 2017-09-11 08:52:46 --> Config Class Initialized
INFO - 2017-09-11 08:52:46 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:52:46 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:52:46 --> Utf8 Class Initialized
INFO - 2017-09-11 08:52:46 --> URI Class Initialized
INFO - 2017-09-11 08:52:46 --> Router Class Initialized
INFO - 2017-09-11 08:52:46 --> Output Class Initialized
INFO - 2017-09-11 08:52:46 --> Security Class Initialized
DEBUG - 2017-09-11 08:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:52:46 --> Input Class Initialized
INFO - 2017-09-11 08:52:46 --> Language Class Initialized
INFO - 2017-09-11 08:52:46 --> Loader Class Initialized
INFO - 2017-09-11 08:52:46 --> Helper loaded: common_helper
INFO - 2017-09-11 08:52:46 --> Database Driver Class Initialized
INFO - 2017-09-11 08:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:52:46 --> Email Class Initialized
INFO - 2017-09-11 08:52:46 --> Controller Class Initialized
INFO - 2017-09-11 08:52:46 --> Helper loaded: form_helper
INFO - 2017-09-11 08:52:46 --> Form Validation Class Initialized
INFO - 2017-09-11 08:52:46 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:52:46 --> Helper loaded: url_helper
INFO - 2017-09-11 08:52:46 --> Model Class Initialized
INFO - 2017-09-11 08:52:46 --> Model Class Initialized
INFO - 2017-09-11 08:52:46 --> Model Class Initialized
INFO - 2017-09-11 12:22:46 --> Helper loaded: download_helper
INFO - 2017-09-11 12:22:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:22:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:22:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:22:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:22:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:22:46 --> Final output sent to browser
DEBUG - 2017-09-11 12:22:46 --> Total execution time: 0.0522
INFO - 2017-09-11 08:52:47 --> Config Class Initialized
INFO - 2017-09-11 08:52:47 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:52:47 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:52:47 --> Utf8 Class Initialized
INFO - 2017-09-11 08:52:47 --> URI Class Initialized
INFO - 2017-09-11 08:52:47 --> Router Class Initialized
INFO - 2017-09-11 08:52:47 --> Output Class Initialized
INFO - 2017-09-11 08:52:47 --> Security Class Initialized
DEBUG - 2017-09-11 08:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:52:47 --> Input Class Initialized
INFO - 2017-09-11 08:52:47 --> Language Class Initialized
INFO - 2017-09-11 08:52:47 --> Loader Class Initialized
INFO - 2017-09-11 08:52:47 --> Helper loaded: common_helper
INFO - 2017-09-11 08:52:47 --> Database Driver Class Initialized
INFO - 2017-09-11 08:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:52:47 --> Email Class Initialized
INFO - 2017-09-11 08:52:47 --> Controller Class Initialized
INFO - 2017-09-11 08:52:47 --> Helper loaded: form_helper
INFO - 2017-09-11 08:52:47 --> Form Validation Class Initialized
INFO - 2017-09-11 08:52:47 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:52:47 --> Helper loaded: url_helper
INFO - 2017-09-11 08:52:47 --> Model Class Initialized
INFO - 2017-09-11 08:52:47 --> Model Class Initialized
INFO - 2017-09-11 08:52:47 --> Model Class Initialized
INFO - 2017-09-11 12:22:47 --> Helper loaded: download_helper
INFO - 2017-09-11 12:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:22:47 --> Final output sent to browser
DEBUG - 2017-09-11 12:22:47 --> Total execution time: 0.0462
INFO - 2017-09-11 08:53:06 --> Config Class Initialized
INFO - 2017-09-11 08:53:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:53:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:53:06 --> Utf8 Class Initialized
INFO - 2017-09-11 08:53:06 --> URI Class Initialized
INFO - 2017-09-11 08:53:06 --> Router Class Initialized
INFO - 2017-09-11 08:53:06 --> Output Class Initialized
INFO - 2017-09-11 08:53:06 --> Security Class Initialized
DEBUG - 2017-09-11 08:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:53:06 --> Input Class Initialized
INFO - 2017-09-11 08:53:06 --> Language Class Initialized
INFO - 2017-09-11 08:53:06 --> Loader Class Initialized
INFO - 2017-09-11 08:53:06 --> Helper loaded: common_helper
INFO - 2017-09-11 08:53:06 --> Database Driver Class Initialized
INFO - 2017-09-11 08:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:53:06 --> Email Class Initialized
INFO - 2017-09-11 08:53:06 --> Controller Class Initialized
INFO - 2017-09-11 08:53:06 --> Helper loaded: form_helper
INFO - 2017-09-11 08:53:06 --> Form Validation Class Initialized
INFO - 2017-09-11 08:53:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:53:06 --> Helper loaded: url_helper
INFO - 2017-09-11 08:53:06 --> Model Class Initialized
INFO - 2017-09-11 08:53:06 --> Model Class Initialized
INFO - 2017-09-11 08:53:06 --> Model Class Initialized
INFO - 2017-09-11 12:23:06 --> Helper loaded: download_helper
INFO - 2017-09-11 12:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:23:06 --> Final output sent to browser
DEBUG - 2017-09-11 12:23:06 --> Total execution time: 0.0487
INFO - 2017-09-11 08:53:56 --> Config Class Initialized
INFO - 2017-09-11 08:53:56 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:53:56 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:53:56 --> Utf8 Class Initialized
INFO - 2017-09-11 08:53:56 --> URI Class Initialized
INFO - 2017-09-11 08:53:56 --> Router Class Initialized
INFO - 2017-09-11 08:53:56 --> Output Class Initialized
INFO - 2017-09-11 08:53:56 --> Security Class Initialized
DEBUG - 2017-09-11 08:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:53:56 --> Input Class Initialized
INFO - 2017-09-11 08:53:56 --> Language Class Initialized
INFO - 2017-09-11 08:53:56 --> Loader Class Initialized
INFO - 2017-09-11 08:53:56 --> Helper loaded: common_helper
INFO - 2017-09-11 08:53:57 --> Database Driver Class Initialized
INFO - 2017-09-11 08:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:53:57 --> Email Class Initialized
INFO - 2017-09-11 08:53:57 --> Controller Class Initialized
INFO - 2017-09-11 08:53:57 --> Helper loaded: form_helper
INFO - 2017-09-11 08:53:57 --> Form Validation Class Initialized
INFO - 2017-09-11 08:53:57 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:53:57 --> Helper loaded: url_helper
INFO - 2017-09-11 08:53:57 --> Model Class Initialized
INFO - 2017-09-11 08:53:57 --> Model Class Initialized
INFO - 2017-09-11 08:53:57 --> Model Class Initialized
INFO - 2017-09-11 12:23:57 --> Helper loaded: download_helper
INFO - 2017-09-11 12:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:23:57 --> Final output sent to browser
DEBUG - 2017-09-11 12:23:57 --> Total execution time: 0.0485
INFO - 2017-09-11 08:53:58 --> Config Class Initialized
INFO - 2017-09-11 08:53:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:53:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:53:58 --> Utf8 Class Initialized
INFO - 2017-09-11 08:53:58 --> URI Class Initialized
INFO - 2017-09-11 08:53:58 --> Router Class Initialized
INFO - 2017-09-11 08:53:58 --> Output Class Initialized
INFO - 2017-09-11 08:53:58 --> Security Class Initialized
DEBUG - 2017-09-11 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:53:58 --> Input Class Initialized
INFO - 2017-09-11 08:53:58 --> Language Class Initialized
INFO - 2017-09-11 08:53:58 --> Loader Class Initialized
INFO - 2017-09-11 08:53:58 --> Helper loaded: common_helper
INFO - 2017-09-11 08:53:58 --> Database Driver Class Initialized
INFO - 2017-09-11 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:53:58 --> Email Class Initialized
INFO - 2017-09-11 08:53:58 --> Controller Class Initialized
INFO - 2017-09-11 08:53:58 --> Helper loaded: form_helper
INFO - 2017-09-11 08:53:58 --> Form Validation Class Initialized
INFO - 2017-09-11 08:53:58 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:53:58 --> Helper loaded: url_helper
INFO - 2017-09-11 08:53:58 --> Model Class Initialized
INFO - 2017-09-11 08:53:58 --> Model Class Initialized
INFO - 2017-09-11 08:53:58 --> Model Class Initialized
INFO - 2017-09-11 12:23:58 --> Helper loaded: download_helper
INFO - 2017-09-11 12:23:58 --> Final output sent to browser
DEBUG - 2017-09-11 12:23:58 --> Total execution time: 0.0444
INFO - 2017-09-11 08:54:11 --> Config Class Initialized
INFO - 2017-09-11 08:54:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:11 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:11 --> URI Class Initialized
INFO - 2017-09-11 08:54:11 --> Router Class Initialized
INFO - 2017-09-11 08:54:11 --> Output Class Initialized
INFO - 2017-09-11 08:54:11 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:11 --> Input Class Initialized
INFO - 2017-09-11 08:54:11 --> Language Class Initialized
INFO - 2017-09-11 08:54:11 --> Loader Class Initialized
INFO - 2017-09-11 08:54:11 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:11 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:11 --> Email Class Initialized
INFO - 2017-09-11 08:54:11 --> Controller Class Initialized
INFO - 2017-09-11 08:54:11 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:11 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:11 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:11 --> Model Class Initialized
INFO - 2017-09-11 08:54:11 --> Model Class Initialized
INFO - 2017-09-11 08:54:11 --> Model Class Initialized
INFO - 2017-09-11 12:24:11 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:24:11 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:11 --> Total execution time: 0.0483
INFO - 2017-09-11 08:54:12 --> Config Class Initialized
INFO - 2017-09-11 08:54:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:12 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:12 --> URI Class Initialized
INFO - 2017-09-11 08:54:12 --> Router Class Initialized
INFO - 2017-09-11 08:54:12 --> Output Class Initialized
INFO - 2017-09-11 08:54:12 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:12 --> Input Class Initialized
INFO - 2017-09-11 08:54:12 --> Language Class Initialized
INFO - 2017-09-11 08:54:12 --> Loader Class Initialized
INFO - 2017-09-11 08:54:12 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:12 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:12 --> Email Class Initialized
INFO - 2017-09-11 08:54:12 --> Controller Class Initialized
INFO - 2017-09-11 08:54:12 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:12 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:12 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:12 --> Model Class Initialized
INFO - 2017-09-11 08:54:12 --> Model Class Initialized
INFO - 2017-09-11 08:54:12 --> Model Class Initialized
INFO - 2017-09-11 12:24:12 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:12 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:12 --> Total execution time: 0.0419
INFO - 2017-09-11 08:54:13 --> Config Class Initialized
INFO - 2017-09-11 08:54:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:13 --> URI Class Initialized
INFO - 2017-09-11 08:54:13 --> Router Class Initialized
INFO - 2017-09-11 08:54:13 --> Output Class Initialized
INFO - 2017-09-11 08:54:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:13 --> Input Class Initialized
INFO - 2017-09-11 08:54:13 --> Language Class Initialized
INFO - 2017-09-11 08:54:13 --> Loader Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:13 --> Email Class Initialized
INFO - 2017-09-11 08:54:13 --> Controller Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 12:24:13 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:13 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:13 --> Total execution time: 0.0413
INFO - 2017-09-11 08:54:13 --> Config Class Initialized
INFO - 2017-09-11 08:54:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:13 --> URI Class Initialized
INFO - 2017-09-11 08:54:13 --> Router Class Initialized
INFO - 2017-09-11 08:54:13 --> Output Class Initialized
INFO - 2017-09-11 08:54:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:13 --> Input Class Initialized
INFO - 2017-09-11 08:54:13 --> Language Class Initialized
INFO - 2017-09-11 08:54:13 --> Loader Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:13 --> Email Class Initialized
INFO - 2017-09-11 08:54:13 --> Controller Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 12:24:13 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:13 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:13 --> Total execution time: 0.0416
INFO - 2017-09-11 08:54:13 --> Config Class Initialized
INFO - 2017-09-11 08:54:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:13 --> URI Class Initialized
INFO - 2017-09-11 08:54:13 --> Router Class Initialized
INFO - 2017-09-11 08:54:13 --> Output Class Initialized
INFO - 2017-09-11 08:54:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:13 --> Input Class Initialized
INFO - 2017-09-11 08:54:13 --> Language Class Initialized
INFO - 2017-09-11 08:54:13 --> Loader Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:13 --> Email Class Initialized
INFO - 2017-09-11 08:54:13 --> Controller Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 12:24:13 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:13 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:13 --> Total execution time: 0.0417
INFO - 2017-09-11 08:54:13 --> Config Class Initialized
INFO - 2017-09-11 08:54:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:13 --> URI Class Initialized
INFO - 2017-09-11 08:54:13 --> Router Class Initialized
INFO - 2017-09-11 08:54:13 --> Output Class Initialized
INFO - 2017-09-11 08:54:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:13 --> Input Class Initialized
INFO - 2017-09-11 08:54:13 --> Language Class Initialized
INFO - 2017-09-11 08:54:13 --> Loader Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:13 --> Email Class Initialized
INFO - 2017-09-11 08:54:13 --> Controller Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 12:24:13 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:13 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:13 --> Total execution time: 0.0415
INFO - 2017-09-11 08:54:13 --> Config Class Initialized
INFO - 2017-09-11 08:54:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:13 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:13 --> URI Class Initialized
INFO - 2017-09-11 08:54:13 --> Router Class Initialized
INFO - 2017-09-11 08:54:13 --> Output Class Initialized
INFO - 2017-09-11 08:54:13 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:13 --> Input Class Initialized
INFO - 2017-09-11 08:54:13 --> Language Class Initialized
INFO - 2017-09-11 08:54:13 --> Loader Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:13 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:13 --> Email Class Initialized
INFO - 2017-09-11 08:54:13 --> Controller Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:13 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:13 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 08:54:13 --> Model Class Initialized
INFO - 2017-09-11 12:24:13 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:13 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:13 --> Total execution time: 0.0422
INFO - 2017-09-11 08:54:14 --> Config Class Initialized
INFO - 2017-09-11 08:54:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:14 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:14 --> URI Class Initialized
INFO - 2017-09-11 08:54:14 --> Router Class Initialized
INFO - 2017-09-11 08:54:14 --> Output Class Initialized
INFO - 2017-09-11 08:54:14 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:14 --> Input Class Initialized
INFO - 2017-09-11 08:54:14 --> Language Class Initialized
INFO - 2017-09-11 08:54:14 --> Loader Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:14 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:14 --> Email Class Initialized
INFO - 2017-09-11 08:54:14 --> Controller Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:14 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:14 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 12:24:14 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:14 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:14 --> Total execution time: 0.0420
INFO - 2017-09-11 08:54:14 --> Config Class Initialized
INFO - 2017-09-11 08:54:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:14 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:14 --> URI Class Initialized
INFO - 2017-09-11 08:54:14 --> Router Class Initialized
INFO - 2017-09-11 08:54:14 --> Output Class Initialized
INFO - 2017-09-11 08:54:14 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:14 --> Input Class Initialized
INFO - 2017-09-11 08:54:14 --> Language Class Initialized
INFO - 2017-09-11 08:54:14 --> Loader Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:14 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:14 --> Email Class Initialized
INFO - 2017-09-11 08:54:14 --> Controller Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:14 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:14 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 12:24:14 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:14 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:14 --> Total execution time: 0.0413
INFO - 2017-09-11 08:54:14 --> Config Class Initialized
INFO - 2017-09-11 08:54:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:54:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:54:14 --> Utf8 Class Initialized
INFO - 2017-09-11 08:54:14 --> URI Class Initialized
INFO - 2017-09-11 08:54:14 --> Router Class Initialized
INFO - 2017-09-11 08:54:14 --> Output Class Initialized
INFO - 2017-09-11 08:54:14 --> Security Class Initialized
DEBUG - 2017-09-11 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:54:14 --> Input Class Initialized
INFO - 2017-09-11 08:54:14 --> Language Class Initialized
INFO - 2017-09-11 08:54:14 --> Loader Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: common_helper
INFO - 2017-09-11 08:54:14 --> Database Driver Class Initialized
INFO - 2017-09-11 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:54:14 --> Email Class Initialized
INFO - 2017-09-11 08:54:14 --> Controller Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: form_helper
INFO - 2017-09-11 08:54:14 --> Form Validation Class Initialized
INFO - 2017-09-11 08:54:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:54:14 --> Helper loaded: url_helper
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 08:54:14 --> Model Class Initialized
INFO - 2017-09-11 12:24:14 --> Helper loaded: download_helper
INFO - 2017-09-11 12:24:14 --> Final output sent to browser
DEBUG - 2017-09-11 12:24:14 --> Total execution time: 0.0418
INFO - 2017-09-11 08:55:37 --> Config Class Initialized
INFO - 2017-09-11 08:55:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:55:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:55:37 --> Utf8 Class Initialized
INFO - 2017-09-11 08:55:37 --> URI Class Initialized
INFO - 2017-09-11 08:55:37 --> Router Class Initialized
INFO - 2017-09-11 08:55:37 --> Output Class Initialized
INFO - 2017-09-11 08:55:37 --> Security Class Initialized
DEBUG - 2017-09-11 08:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:55:37 --> Input Class Initialized
INFO - 2017-09-11 08:55:37 --> Language Class Initialized
INFO - 2017-09-11 08:55:37 --> Loader Class Initialized
INFO - 2017-09-11 08:55:37 --> Helper loaded: common_helper
INFO - 2017-09-11 08:55:37 --> Database Driver Class Initialized
INFO - 2017-09-11 08:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:55:37 --> Email Class Initialized
INFO - 2017-09-11 08:55:37 --> Controller Class Initialized
INFO - 2017-09-11 08:55:37 --> Helper loaded: form_helper
INFO - 2017-09-11 08:55:37 --> Form Validation Class Initialized
INFO - 2017-09-11 08:55:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:55:37 --> Helper loaded: url_helper
INFO - 2017-09-11 08:55:37 --> Model Class Initialized
INFO - 2017-09-11 08:55:37 --> Model Class Initialized
INFO - 2017-09-11 08:55:37 --> Model Class Initialized
INFO - 2017-09-11 12:25:37 --> Helper loaded: download_helper
INFO - 2017-09-11 12:25:37 --> Final output sent to browser
DEBUG - 2017-09-11 12:25:37 --> Total execution time: 0.0422
INFO - 2017-09-11 08:56:39 --> Config Class Initialized
INFO - 2017-09-11 08:56:39 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:56:39 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:56:39 --> Utf8 Class Initialized
INFO - 2017-09-11 08:56:39 --> URI Class Initialized
INFO - 2017-09-11 08:56:39 --> Router Class Initialized
INFO - 2017-09-11 08:56:39 --> Output Class Initialized
INFO - 2017-09-11 08:56:39 --> Security Class Initialized
DEBUG - 2017-09-11 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:56:39 --> Input Class Initialized
INFO - 2017-09-11 08:56:39 --> Language Class Initialized
INFO - 2017-09-11 08:56:39 --> Loader Class Initialized
INFO - 2017-09-11 08:56:39 --> Helper loaded: common_helper
INFO - 2017-09-11 08:56:39 --> Database Driver Class Initialized
INFO - 2017-09-11 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:56:39 --> Email Class Initialized
INFO - 2017-09-11 08:56:39 --> Controller Class Initialized
INFO - 2017-09-11 08:56:39 --> Helper loaded: form_helper
INFO - 2017-09-11 08:56:39 --> Form Validation Class Initialized
INFO - 2017-09-11 08:56:39 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:56:39 --> Helper loaded: url_helper
INFO - 2017-09-11 08:56:39 --> Model Class Initialized
INFO - 2017-09-11 08:56:39 --> Model Class Initialized
INFO - 2017-09-11 08:56:39 --> Model Class Initialized
INFO - 2017-09-11 12:26:39 --> Helper loaded: download_helper
INFO - 2017-09-11 12:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:26:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:26:39 --> Final output sent to browser
DEBUG - 2017-09-11 12:26:39 --> Total execution time: 0.0586
INFO - 2017-09-11 08:56:41 --> Config Class Initialized
INFO - 2017-09-11 08:56:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:56:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:56:41 --> Utf8 Class Initialized
INFO - 2017-09-11 08:56:41 --> URI Class Initialized
INFO - 2017-09-11 08:56:41 --> Router Class Initialized
INFO - 2017-09-11 08:56:41 --> Output Class Initialized
INFO - 2017-09-11 08:56:41 --> Security Class Initialized
DEBUG - 2017-09-11 08:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:56:41 --> Input Class Initialized
INFO - 2017-09-11 08:56:41 --> Language Class Initialized
INFO - 2017-09-11 08:56:41 --> Loader Class Initialized
INFO - 2017-09-11 08:56:41 --> Helper loaded: common_helper
INFO - 2017-09-11 08:56:41 --> Database Driver Class Initialized
INFO - 2017-09-11 08:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:56:41 --> Email Class Initialized
INFO - 2017-09-11 08:56:41 --> Controller Class Initialized
INFO - 2017-09-11 08:56:41 --> Helper loaded: form_helper
INFO - 2017-09-11 08:56:41 --> Form Validation Class Initialized
INFO - 2017-09-11 08:56:41 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:56:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:56:41 --> Helper loaded: url_helper
INFO - 2017-09-11 08:56:41 --> Model Class Initialized
INFO - 2017-09-11 08:56:41 --> Model Class Initialized
INFO - 2017-09-11 08:56:41 --> Model Class Initialized
INFO - 2017-09-11 12:26:41 --> Helper loaded: download_helper
INFO - 2017-09-11 12:26:41 --> Final output sent to browser
DEBUG - 2017-09-11 12:26:41 --> Total execution time: 0.0550
INFO - 2017-09-11 08:57:14 --> Config Class Initialized
INFO - 2017-09-11 08:57:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:57:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:57:14 --> Utf8 Class Initialized
INFO - 2017-09-11 08:57:14 --> URI Class Initialized
INFO - 2017-09-11 08:57:14 --> Router Class Initialized
INFO - 2017-09-11 08:57:14 --> Output Class Initialized
INFO - 2017-09-11 08:57:14 --> Security Class Initialized
DEBUG - 2017-09-11 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:57:14 --> Input Class Initialized
INFO - 2017-09-11 08:57:14 --> Language Class Initialized
ERROR - 2017-09-11 08:57:14 --> 404 Page Not Found: Settings/index
INFO - 2017-09-11 08:57:32 --> Config Class Initialized
INFO - 2017-09-11 08:57:32 --> Hooks Class Initialized
DEBUG - 2017-09-11 08:57:32 --> UTF-8 Support Enabled
INFO - 2017-09-11 08:57:32 --> Utf8 Class Initialized
INFO - 2017-09-11 08:57:32 --> URI Class Initialized
INFO - 2017-09-11 08:57:32 --> Router Class Initialized
INFO - 2017-09-11 08:57:32 --> Output Class Initialized
INFO - 2017-09-11 08:57:32 --> Security Class Initialized
DEBUG - 2017-09-11 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 08:57:32 --> Input Class Initialized
INFO - 2017-09-11 08:57:32 --> Language Class Initialized
INFO - 2017-09-11 08:57:32 --> Loader Class Initialized
INFO - 2017-09-11 08:57:32 --> Helper loaded: common_helper
INFO - 2017-09-11 08:57:32 --> Database Driver Class Initialized
INFO - 2017-09-11 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 08:57:32 --> Email Class Initialized
INFO - 2017-09-11 08:57:32 --> Controller Class Initialized
INFO - 2017-09-11 08:57:32 --> Helper loaded: form_helper
INFO - 2017-09-11 08:57:32 --> Form Validation Class Initialized
INFO - 2017-09-11 08:57:32 --> Helper loaded: email_helper
DEBUG - 2017-09-11 08:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 08:57:32 --> Helper loaded: url_helper
INFO - 2017-09-11 08:57:32 --> Model Class Initialized
INFO - 2017-09-11 08:57:32 --> Model Class Initialized
INFO - 2017-09-11 12:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 12:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:27:32 --> Final output sent to browser
DEBUG - 2017-09-11 12:27:32 --> Total execution time: 0.0635
INFO - 2017-09-11 09:09:02 --> Config Class Initialized
INFO - 2017-09-11 09:09:02 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:02 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:02 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:02 --> URI Class Initialized
INFO - 2017-09-11 09:09:02 --> Router Class Initialized
INFO - 2017-09-11 09:09:02 --> Output Class Initialized
INFO - 2017-09-11 09:09:02 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:02 --> Input Class Initialized
INFO - 2017-09-11 09:09:02 --> Language Class Initialized
INFO - 2017-09-11 09:09:02 --> Loader Class Initialized
INFO - 2017-09-11 09:09:02 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:02 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:02 --> Email Class Initialized
INFO - 2017-09-11 09:09:02 --> Controller Class Initialized
INFO - 2017-09-11 09:09:02 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:02 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:02 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:02 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:02 --> Model Class Initialized
INFO - 2017-09-11 09:09:02 --> Model Class Initialized
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:02 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:02 --> Total execution time: 0.0763
INFO - 2017-09-11 09:09:02 --> Config Class Initialized
INFO - 2017-09-11 09:09:02 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:02 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:02 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:02 --> URI Class Initialized
INFO - 2017-09-11 09:09:02 --> Router Class Initialized
INFO - 2017-09-11 09:09:02 --> Output Class Initialized
INFO - 2017-09-11 09:09:02 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:02 --> Input Class Initialized
INFO - 2017-09-11 09:09:02 --> Language Class Initialized
INFO - 2017-09-11 09:09:02 --> Loader Class Initialized
INFO - 2017-09-11 09:09:02 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:02 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:02 --> Email Class Initialized
INFO - 2017-09-11 09:09:02 --> Controller Class Initialized
INFO - 2017-09-11 09:09:02 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:02 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:02 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:02 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:02 --> Model Class Initialized
INFO - 2017-09-11 09:09:02 --> Model Class Initialized
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-09-11 12:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:02 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:02 --> Total execution time: 0.0653
INFO - 2017-09-11 09:09:04 --> Config Class Initialized
INFO - 2017-09-11 09:09:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:04 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:04 --> URI Class Initialized
INFO - 2017-09-11 09:09:04 --> Router Class Initialized
INFO - 2017-09-11 09:09:04 --> Output Class Initialized
INFO - 2017-09-11 09:09:04 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:04 --> Input Class Initialized
INFO - 2017-09-11 09:09:04 --> Language Class Initialized
INFO - 2017-09-11 09:09:04 --> Loader Class Initialized
INFO - 2017-09-11 09:09:04 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:04 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:04 --> Email Class Initialized
INFO - 2017-09-11 09:09:04 --> Controller Class Initialized
INFO - 2017-09-11 09:09:04 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:04 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:04 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:04 --> Model Class Initialized
INFO - 2017-09-11 09:09:04 --> Model Class Initialized
INFO - 2017-09-11 12:39:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:39:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-09-11 12:39:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:04 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:04 --> Total execution time: 0.0706
INFO - 2017-09-11 09:09:06 --> Config Class Initialized
INFO - 2017-09-11 09:09:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:06 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:06 --> URI Class Initialized
INFO - 2017-09-11 09:09:06 --> Router Class Initialized
INFO - 2017-09-11 09:09:06 --> Output Class Initialized
INFO - 2017-09-11 09:09:06 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:06 --> Input Class Initialized
INFO - 2017-09-11 09:09:06 --> Language Class Initialized
INFO - 2017-09-11 09:09:06 --> Loader Class Initialized
INFO - 2017-09-11 09:09:06 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:06 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:06 --> Email Class Initialized
INFO - 2017-09-11 09:09:06 --> Controller Class Initialized
INFO - 2017-09-11 09:09:06 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:06 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:06 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:06 --> Model Class Initialized
INFO - 2017-09-11 09:09:06 --> Model Class Initialized
INFO - 2017-09-11 09:09:06 --> Model Class Initialized
INFO - 2017-09-11 12:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-09-11 12:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-09-11 12:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:06 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:06 --> Total execution time: 0.2140
INFO - 2017-09-11 09:09:08 --> Config Class Initialized
INFO - 2017-09-11 09:09:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:08 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:08 --> URI Class Initialized
INFO - 2017-09-11 09:09:08 --> Router Class Initialized
INFO - 2017-09-11 09:09:08 --> Output Class Initialized
INFO - 2017-09-11 09:09:08 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:08 --> Input Class Initialized
INFO - 2017-09-11 09:09:08 --> Language Class Initialized
INFO - 2017-09-11 09:09:08 --> Loader Class Initialized
INFO - 2017-09-11 09:09:08 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:08 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:08 --> Email Class Initialized
INFO - 2017-09-11 09:09:08 --> Controller Class Initialized
INFO - 2017-09-11 09:09:08 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:08 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:08 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:08 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:08 --> Model Class Initialized
INFO - 2017-09-11 09:09:08 --> Model Class Initialized
INFO - 2017-09-11 09:09:08 --> Model Class Initialized
INFO - 2017-09-11 12:39:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 12:39:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 12:39:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-09-11 12:39:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-09-11 12:39:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:08 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:08 --> Total execution time: 0.2231
INFO - 2017-09-11 09:09:09 --> Config Class Initialized
INFO - 2017-09-11 09:09:09 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:09 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:09 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:09 --> URI Class Initialized
INFO - 2017-09-11 09:09:09 --> Router Class Initialized
INFO - 2017-09-11 09:09:09 --> Output Class Initialized
INFO - 2017-09-11 09:09:09 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:09 --> Input Class Initialized
INFO - 2017-09-11 09:09:09 --> Language Class Initialized
INFO - 2017-09-11 09:09:09 --> Loader Class Initialized
INFO - 2017-09-11 09:09:09 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:09 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:09 --> Email Class Initialized
INFO - 2017-09-11 09:09:09 --> Controller Class Initialized
INFO - 2017-09-11 09:09:09 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:09 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:09 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:09 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:09 --> Model Class Initialized
INFO - 2017-09-11 09:09:09 --> Model Class Initialized
INFO - 2017-09-11 09:09:09 --> Model Class Initialized
INFO - 2017-09-11 12:39:09 --> Helper loaded: download_helper
INFO - 2017-09-11 12:39:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:39:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 12:39:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:09 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:09 --> Total execution time: 0.0467
INFO - 2017-09-11 09:09:10 --> Config Class Initialized
INFO - 2017-09-11 09:09:10 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:09:10 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:09:10 --> Utf8 Class Initialized
INFO - 2017-09-11 09:09:10 --> URI Class Initialized
INFO - 2017-09-11 09:09:10 --> Router Class Initialized
INFO - 2017-09-11 09:09:10 --> Output Class Initialized
INFO - 2017-09-11 09:09:10 --> Security Class Initialized
DEBUG - 2017-09-11 09:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:09:10 --> Input Class Initialized
INFO - 2017-09-11 09:09:10 --> Language Class Initialized
INFO - 2017-09-11 09:09:10 --> Loader Class Initialized
INFO - 2017-09-11 09:09:10 --> Helper loaded: common_helper
INFO - 2017-09-11 09:09:10 --> Database Driver Class Initialized
INFO - 2017-09-11 09:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:09:10 --> Email Class Initialized
INFO - 2017-09-11 09:09:10 --> Controller Class Initialized
INFO - 2017-09-11 09:09:10 --> Helper loaded: form_helper
INFO - 2017-09-11 09:09:10 --> Form Validation Class Initialized
INFO - 2017-09-11 09:09:10 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:09:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:09:10 --> Helper loaded: url_helper
INFO - 2017-09-11 09:09:10 --> Model Class Initialized
INFO - 2017-09-11 09:09:10 --> Model Class Initialized
INFO - 2017-09-11 12:39:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:39:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:39:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:39:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-09-11 12:39:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:39:10 --> Final output sent to browser
DEBUG - 2017-09-11 12:39:10 --> Total execution time: 0.0502
INFO - 2017-09-11 09:17:12 --> Config Class Initialized
INFO - 2017-09-11 09:17:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:17:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:17:12 --> Utf8 Class Initialized
INFO - 2017-09-11 09:17:12 --> URI Class Initialized
INFO - 2017-09-11 09:17:12 --> Router Class Initialized
INFO - 2017-09-11 09:17:12 --> Output Class Initialized
INFO - 2017-09-11 09:17:12 --> Security Class Initialized
DEBUG - 2017-09-11 09:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:17:12 --> Input Class Initialized
INFO - 2017-09-11 09:17:12 --> Language Class Initialized
INFO - 2017-09-11 09:17:12 --> Loader Class Initialized
INFO - 2017-09-11 09:17:12 --> Helper loaded: common_helper
INFO - 2017-09-11 09:17:12 --> Database Driver Class Initialized
INFO - 2017-09-11 09:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:17:12 --> Email Class Initialized
INFO - 2017-09-11 09:17:12 --> Controller Class Initialized
INFO - 2017-09-11 09:17:12 --> Helper loaded: form_helper
INFO - 2017-09-11 09:17:12 --> Form Validation Class Initialized
INFO - 2017-09-11 09:17:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:17:12 --> Helper loaded: url_helper
INFO - 2017-09-11 09:17:12 --> Model Class Initialized
INFO - 2017-09-11 09:17:12 --> Model Class Initialized
INFO - 2017-09-11 12:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-09-11 12:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:47:12 --> Final output sent to browser
DEBUG - 2017-09-11 12:47:12 --> Total execution time: 0.0465
INFO - 2017-09-11 09:18:04 --> Config Class Initialized
INFO - 2017-09-11 09:18:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:18:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:18:04 --> Utf8 Class Initialized
INFO - 2017-09-11 09:18:04 --> URI Class Initialized
INFO - 2017-09-11 09:18:04 --> Router Class Initialized
INFO - 2017-09-11 09:18:04 --> Output Class Initialized
INFO - 2017-09-11 09:18:04 --> Security Class Initialized
DEBUG - 2017-09-11 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:18:04 --> Input Class Initialized
INFO - 2017-09-11 09:18:04 --> Language Class Initialized
INFO - 2017-09-11 09:18:04 --> Loader Class Initialized
INFO - 2017-09-11 09:18:04 --> Helper loaded: common_helper
INFO - 2017-09-11 09:18:04 --> Database Driver Class Initialized
INFO - 2017-09-11 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:18:04 --> Email Class Initialized
INFO - 2017-09-11 09:18:04 --> Controller Class Initialized
INFO - 2017-09-11 09:18:04 --> Helper loaded: form_helper
INFO - 2017-09-11 09:18:04 --> Form Validation Class Initialized
INFO - 2017-09-11 09:18:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:18:04 --> Helper loaded: url_helper
INFO - 2017-09-11 09:18:04 --> Model Class Initialized
INFO - 2017-09-11 09:18:04 --> Model Class Initialized
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:48:04 --> Undefined variable: data
ERROR - 2017-09-11 12:48:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:48:04 --> Undefined variable: settings
ERROR - 2017-09-11 12:48:04 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 49
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:48:04 --> Final output sent to browser
DEBUG - 2017-09-11 12:48:04 --> Total execution time: 0.0570
INFO - 2017-09-11 09:18:04 --> Config Class Initialized
INFO - 2017-09-11 09:18:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:18:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:18:04 --> Utf8 Class Initialized
INFO - 2017-09-11 09:18:04 --> URI Class Initialized
INFO - 2017-09-11 09:18:04 --> Router Class Initialized
INFO - 2017-09-11 09:18:04 --> Output Class Initialized
INFO - 2017-09-11 09:18:04 --> Security Class Initialized
DEBUG - 2017-09-11 09:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:18:04 --> Input Class Initialized
INFO - 2017-09-11 09:18:04 --> Language Class Initialized
INFO - 2017-09-11 09:18:04 --> Loader Class Initialized
INFO - 2017-09-11 09:18:04 --> Helper loaded: common_helper
INFO - 2017-09-11 09:18:04 --> Database Driver Class Initialized
INFO - 2017-09-11 09:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:18:04 --> Email Class Initialized
INFO - 2017-09-11 09:18:04 --> Controller Class Initialized
INFO - 2017-09-11 09:18:04 --> Helper loaded: form_helper
INFO - 2017-09-11 09:18:04 --> Form Validation Class Initialized
INFO - 2017-09-11 09:18:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:18:04 --> Helper loaded: url_helper
INFO - 2017-09-11 09:18:04 --> Model Class Initialized
INFO - 2017-09-11 09:18:04 --> Model Class Initialized
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:48:04 --> Undefined variable: data
ERROR - 2017-09-11 12:48:04 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:48:04 --> Undefined variable: settings
ERROR - 2017-09-11 12:48:04 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 49
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:48:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:48:04 --> Final output sent to browser
DEBUG - 2017-09-11 12:48:04 --> Total execution time: 0.0601
INFO - 2017-09-11 09:18:09 --> Config Class Initialized
INFO - 2017-09-11 09:18:09 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:18:09 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:18:09 --> Utf8 Class Initialized
INFO - 2017-09-11 09:18:09 --> URI Class Initialized
INFO - 2017-09-11 09:18:09 --> Router Class Initialized
INFO - 2017-09-11 09:18:09 --> Output Class Initialized
INFO - 2017-09-11 09:18:09 --> Security Class Initialized
DEBUG - 2017-09-11 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:18:09 --> Input Class Initialized
INFO - 2017-09-11 09:18:09 --> Language Class Initialized
INFO - 2017-09-11 09:18:09 --> Loader Class Initialized
INFO - 2017-09-11 09:18:09 --> Helper loaded: common_helper
INFO - 2017-09-11 09:18:09 --> Database Driver Class Initialized
INFO - 2017-09-11 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:18:09 --> Email Class Initialized
INFO - 2017-09-11 09:18:09 --> Controller Class Initialized
INFO - 2017-09-11 09:18:09 --> Helper loaded: form_helper
INFO - 2017-09-11 09:18:09 --> Form Validation Class Initialized
INFO - 2017-09-11 09:18:09 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:18:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:18:09 --> Helper loaded: url_helper
INFO - 2017-09-11 09:18:09 --> Model Class Initialized
INFO - 2017-09-11 09:18:09 --> Model Class Initialized
INFO - 2017-09-11 12:48:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:48:09 --> Undefined variable: data
ERROR - 2017-09-11 12:48:09 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:48:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:48:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:48:09 --> Undefined variable: settings
ERROR - 2017-09-11 12:48:09 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 49
INFO - 2017-09-11 12:48:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:48:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:48:09 --> Final output sent to browser
DEBUG - 2017-09-11 12:48:09 --> Total execution time: 0.0579
INFO - 2017-09-11 09:18:39 --> Config Class Initialized
INFO - 2017-09-11 09:18:39 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:18:39 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:18:39 --> Utf8 Class Initialized
INFO - 2017-09-11 09:18:39 --> URI Class Initialized
INFO - 2017-09-11 09:18:39 --> Router Class Initialized
INFO - 2017-09-11 09:18:39 --> Output Class Initialized
INFO - 2017-09-11 09:18:39 --> Security Class Initialized
DEBUG - 2017-09-11 09:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:18:39 --> Input Class Initialized
INFO - 2017-09-11 09:18:39 --> Language Class Initialized
INFO - 2017-09-11 09:18:39 --> Loader Class Initialized
INFO - 2017-09-11 09:18:39 --> Helper loaded: common_helper
INFO - 2017-09-11 09:18:39 --> Database Driver Class Initialized
INFO - 2017-09-11 09:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:18:39 --> Email Class Initialized
INFO - 2017-09-11 09:18:39 --> Controller Class Initialized
INFO - 2017-09-11 09:18:39 --> Helper loaded: form_helper
INFO - 2017-09-11 09:18:39 --> Form Validation Class Initialized
INFO - 2017-09-11 09:18:39 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:18:39 --> Helper loaded: url_helper
INFO - 2017-09-11 09:18:39 --> Model Class Initialized
INFO - 2017-09-11 09:18:39 --> Model Class Initialized
INFO - 2017-09-11 12:48:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:48:39 --> Undefined variable: data
ERROR - 2017-09-11 12:48:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:48:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:48:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:48:39 --> Undefined variable: settings
ERROR - 2017-09-11 12:48:39 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 46
INFO - 2017-09-11 12:48:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:48:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:48:39 --> Final output sent to browser
DEBUG - 2017-09-11 12:48:39 --> Total execution time: 0.0716
INFO - 2017-09-11 09:19:35 --> Config Class Initialized
INFO - 2017-09-11 09:19:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:19:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:19:35 --> Utf8 Class Initialized
INFO - 2017-09-11 09:19:35 --> URI Class Initialized
INFO - 2017-09-11 09:19:35 --> Router Class Initialized
INFO - 2017-09-11 09:19:35 --> Output Class Initialized
INFO - 2017-09-11 09:19:35 --> Security Class Initialized
DEBUG - 2017-09-11 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:19:35 --> Input Class Initialized
INFO - 2017-09-11 09:19:35 --> Language Class Initialized
INFO - 2017-09-11 09:19:35 --> Loader Class Initialized
INFO - 2017-09-11 09:19:35 --> Helper loaded: common_helper
INFO - 2017-09-11 09:19:35 --> Database Driver Class Initialized
INFO - 2017-09-11 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:19:35 --> Email Class Initialized
INFO - 2017-09-11 09:19:35 --> Controller Class Initialized
INFO - 2017-09-11 09:19:35 --> Helper loaded: form_helper
INFO - 2017-09-11 09:19:35 --> Form Validation Class Initialized
INFO - 2017-09-11 09:19:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:19:35 --> Helper loaded: url_helper
INFO - 2017-09-11 09:19:35 --> Model Class Initialized
INFO - 2017-09-11 09:19:35 --> Model Class Initialized
INFO - 2017-09-11 12:49:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:49:35 --> Undefined variable: data
ERROR - 2017-09-11 12:49:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:49:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:49:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:49:35 --> Undefined variable: settings
ERROR - 2017-09-11 12:49:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 46
INFO - 2017-09-11 12:49:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:49:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:49:35 --> Final output sent to browser
DEBUG - 2017-09-11 12:49:35 --> Total execution time: 0.0498
INFO - 2017-09-11 09:20:35 --> Config Class Initialized
INFO - 2017-09-11 09:20:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:20:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:20:35 --> Utf8 Class Initialized
INFO - 2017-09-11 09:20:35 --> URI Class Initialized
INFO - 2017-09-11 09:20:35 --> Router Class Initialized
INFO - 2017-09-11 09:20:35 --> Output Class Initialized
INFO - 2017-09-11 09:20:35 --> Security Class Initialized
DEBUG - 2017-09-11 09:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:20:35 --> Input Class Initialized
INFO - 2017-09-11 09:20:35 --> Language Class Initialized
INFO - 2017-09-11 09:20:35 --> Loader Class Initialized
INFO - 2017-09-11 09:20:35 --> Helper loaded: common_helper
INFO - 2017-09-11 09:20:35 --> Database Driver Class Initialized
INFO - 2017-09-11 09:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:20:35 --> Email Class Initialized
INFO - 2017-09-11 09:20:35 --> Controller Class Initialized
INFO - 2017-09-11 09:20:35 --> Helper loaded: form_helper
INFO - 2017-09-11 09:20:35 --> Form Validation Class Initialized
INFO - 2017-09-11 09:20:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:20:35 --> Helper loaded: url_helper
INFO - 2017-09-11 09:20:35 --> Model Class Initialized
INFO - 2017-09-11 09:20:35 --> Model Class Initialized
INFO - 2017-09-11 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:50:35 --> Undefined variable: data
ERROR - 2017-09-11 12:50:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:50:35 --> Undefined variable: settings
ERROR - 2017-09-11 12:50:35 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 46
INFO - 2017-09-11 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:50:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:50:35 --> Final output sent to browser
DEBUG - 2017-09-11 12:50:35 --> Total execution time: 0.0692
INFO - 2017-09-11 09:22:01 --> Config Class Initialized
INFO - 2017-09-11 09:22:01 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:22:01 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:22:01 --> Utf8 Class Initialized
INFO - 2017-09-11 09:22:01 --> URI Class Initialized
INFO - 2017-09-11 09:22:01 --> Router Class Initialized
INFO - 2017-09-11 09:22:01 --> Output Class Initialized
INFO - 2017-09-11 09:22:01 --> Security Class Initialized
DEBUG - 2017-09-11 09:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:22:01 --> Input Class Initialized
INFO - 2017-09-11 09:22:01 --> Language Class Initialized
INFO - 2017-09-11 09:22:01 --> Loader Class Initialized
INFO - 2017-09-11 09:22:01 --> Helper loaded: common_helper
INFO - 2017-09-11 09:22:01 --> Database Driver Class Initialized
INFO - 2017-09-11 09:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:22:01 --> Email Class Initialized
INFO - 2017-09-11 09:22:01 --> Controller Class Initialized
INFO - 2017-09-11 09:22:01 --> Helper loaded: form_helper
INFO - 2017-09-11 09:22:01 --> Form Validation Class Initialized
INFO - 2017-09-11 09:22:01 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:22:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:22:01 --> Helper loaded: url_helper
INFO - 2017-09-11 09:22:01 --> Model Class Initialized
INFO - 2017-09-11 09:22:01 --> Model Class Initialized
INFO - 2017-09-11 12:52:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2017-09-11 12:52:01 --> Undefined variable: data
ERROR - 2017-09-11 12:52:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Settings.php 38
INFO - 2017-09-11 12:52:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:52:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 12:52:01 --> Undefined variable: settings
ERROR - 2017-09-11 12:52:01 --> Severity: Notice --> Undefined variable: settings C:\xampp\htdocs\FlickNews\admin\application\views\Settings\settings.php 46
INFO - 2017-09-11 12:52:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:52:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:52:01 --> Final output sent to browser
DEBUG - 2017-09-11 12:52:01 --> Total execution time: 0.0493
INFO - 2017-09-11 09:22:51 --> Config Class Initialized
INFO - 2017-09-11 09:22:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:22:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:22:51 --> Utf8 Class Initialized
INFO - 2017-09-11 09:22:51 --> URI Class Initialized
INFO - 2017-09-11 09:22:51 --> Router Class Initialized
INFO - 2017-09-11 09:22:51 --> Output Class Initialized
INFO - 2017-09-11 09:22:51 --> Security Class Initialized
DEBUG - 2017-09-11 09:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:22:51 --> Input Class Initialized
INFO - 2017-09-11 09:22:51 --> Language Class Initialized
INFO - 2017-09-11 09:22:51 --> Loader Class Initialized
INFO - 2017-09-11 09:22:51 --> Helper loaded: common_helper
INFO - 2017-09-11 09:22:51 --> Database Driver Class Initialized
INFO - 2017-09-11 09:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:22:51 --> Email Class Initialized
INFO - 2017-09-11 09:22:51 --> Controller Class Initialized
INFO - 2017-09-11 09:22:51 --> Helper loaded: form_helper
INFO - 2017-09-11 09:22:51 --> Form Validation Class Initialized
INFO - 2017-09-11 09:22:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:22:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:22:51 --> Helper loaded: url_helper
INFO - 2017-09-11 09:22:51 --> Model Class Initialized
INFO - 2017-09-11 09:22:51 --> Model Class Initialized
INFO - 2017-09-11 12:52:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:52:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:52:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:52:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:52:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:52:51 --> Final output sent to browser
DEBUG - 2017-09-11 12:52:51 --> Total execution time: 0.0450
INFO - 2017-09-11 09:23:06 --> Config Class Initialized
INFO - 2017-09-11 09:23:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:23:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:23:06 --> Utf8 Class Initialized
INFO - 2017-09-11 09:23:06 --> URI Class Initialized
INFO - 2017-09-11 09:23:06 --> Router Class Initialized
INFO - 2017-09-11 09:23:06 --> Output Class Initialized
INFO - 2017-09-11 09:23:06 --> Security Class Initialized
DEBUG - 2017-09-11 09:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:23:06 --> Input Class Initialized
INFO - 2017-09-11 09:23:06 --> Language Class Initialized
INFO - 2017-09-11 09:23:06 --> Loader Class Initialized
INFO - 2017-09-11 09:23:06 --> Helper loaded: common_helper
INFO - 2017-09-11 09:23:06 --> Database Driver Class Initialized
INFO - 2017-09-11 09:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:23:06 --> Email Class Initialized
INFO - 2017-09-11 09:23:06 --> Controller Class Initialized
INFO - 2017-09-11 09:23:06 --> Helper loaded: form_helper
INFO - 2017-09-11 09:23:06 --> Form Validation Class Initialized
INFO - 2017-09-11 09:23:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:23:06 --> Helper loaded: url_helper
INFO - 2017-09-11 09:23:06 --> Model Class Initialized
INFO - 2017-09-11 09:23:06 --> Model Class Initialized
INFO - 2017-09-11 12:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 12:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 12:53:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:53:06 --> Final output sent to browser
DEBUG - 2017-09-11 12:53:06 --> Total execution time: 0.0469
INFO - 2017-09-11 09:23:07 --> Config Class Initialized
INFO - 2017-09-11 09:23:07 --> Hooks Class Initialized
DEBUG - 2017-09-11 09:23:07 --> UTF-8 Support Enabled
INFO - 2017-09-11 09:23:07 --> Utf8 Class Initialized
INFO - 2017-09-11 09:23:07 --> URI Class Initialized
INFO - 2017-09-11 09:23:07 --> Router Class Initialized
INFO - 2017-09-11 09:23:07 --> Output Class Initialized
INFO - 2017-09-11 09:23:07 --> Security Class Initialized
DEBUG - 2017-09-11 09:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 09:23:07 --> Input Class Initialized
INFO - 2017-09-11 09:23:07 --> Language Class Initialized
INFO - 2017-09-11 09:23:07 --> Loader Class Initialized
INFO - 2017-09-11 09:23:07 --> Helper loaded: common_helper
INFO - 2017-09-11 09:23:07 --> Database Driver Class Initialized
INFO - 2017-09-11 09:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 09:23:07 --> Email Class Initialized
INFO - 2017-09-11 09:23:07 --> Controller Class Initialized
INFO - 2017-09-11 09:23:07 --> Helper loaded: form_helper
INFO - 2017-09-11 09:23:07 --> Form Validation Class Initialized
INFO - 2017-09-11 09:23:07 --> Helper loaded: email_helper
DEBUG - 2017-09-11 09:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 09:23:07 --> Helper loaded: url_helper
INFO - 2017-09-11 09:23:07 --> Model Class Initialized
INFO - 2017-09-11 09:23:07 --> Model Class Initialized
INFO - 2017-09-11 12:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 12:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 12:53:07 --> Trying to get property of non-object
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 12:53:07 --> Trying to get property of non-object
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 12:53:07 --> Trying to get property of non-object
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 12:53:07 --> Trying to get property of non-object
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 12:53:07 --> Trying to get property of non-object
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 12:53:07 --> Undefined variable: details
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 12:53:07 --> Trying to get property of non-object
ERROR - 2017-09-11 12:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-09-11 12:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 12:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 12:53:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 12:53:07 --> Final output sent to browser
DEBUG - 2017-09-11 12:53:07 --> Total execution time: 0.0773
INFO - 2017-09-11 10:06:17 --> Config Class Initialized
INFO - 2017-09-11 10:06:17 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:06:17 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:06:17 --> Utf8 Class Initialized
INFO - 2017-09-11 10:06:17 --> URI Class Initialized
INFO - 2017-09-11 10:06:17 --> Router Class Initialized
INFO - 2017-09-11 10:06:17 --> Output Class Initialized
INFO - 2017-09-11 10:06:17 --> Security Class Initialized
DEBUG - 2017-09-11 10:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:06:17 --> Input Class Initialized
INFO - 2017-09-11 10:06:17 --> Language Class Initialized
INFO - 2017-09-11 10:06:17 --> Loader Class Initialized
INFO - 2017-09-11 10:06:17 --> Helper loaded: common_helper
INFO - 2017-09-11 10:06:17 --> Database Driver Class Initialized
INFO - 2017-09-11 10:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:06:17 --> Email Class Initialized
INFO - 2017-09-11 10:06:17 --> Controller Class Initialized
INFO - 2017-09-11 10:06:17 --> Helper loaded: form_helper
INFO - 2017-09-11 10:06:17 --> Form Validation Class Initialized
INFO - 2017-09-11 10:06:17 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:06:17 --> Helper loaded: url_helper
INFO - 2017-09-11 10:06:17 --> Model Class Initialized
INFO - 2017-09-11 10:06:17 --> Model Class Initialized
INFO - 2017-09-11 13:36:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:36:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:36:17 --> Trying to get property of non-object
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:36:17 --> Trying to get property of non-object
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:36:17 --> Trying to get property of non-object
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:36:17 --> Trying to get property of non-object
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:36:17 --> Trying to get property of non-object
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:36:17 --> Undefined variable: details
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:36:17 --> Trying to get property of non-object
ERROR - 2017-09-11 13:36:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-09-11 13:36:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 13:36:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:36:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:36:17 --> Final output sent to browser
DEBUG - 2017-09-11 13:36:17 --> Total execution time: 0.0619
INFO - 2017-09-11 10:07:19 --> Config Class Initialized
INFO - 2017-09-11 10:07:19 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:19 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:19 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:19 --> URI Class Initialized
INFO - 2017-09-11 10:07:19 --> Router Class Initialized
INFO - 2017-09-11 10:07:19 --> Output Class Initialized
INFO - 2017-09-11 10:07:19 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:19 --> Input Class Initialized
INFO - 2017-09-11 10:07:19 --> Language Class Initialized
INFO - 2017-09-11 10:07:19 --> Loader Class Initialized
INFO - 2017-09-11 10:07:19 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:19 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:19 --> Email Class Initialized
INFO - 2017-09-11 10:07:19 --> Controller Class Initialized
INFO - 2017-09-11 10:07:19 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:19 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:19 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:19 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:19 --> Model Class Initialized
INFO - 2017-09-11 10:07:19 --> Model Class Initialized
INFO - 2017-09-11 13:37:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:37:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:19 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:19 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:19 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:19 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:19 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:19 --> Undefined variable: details
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:19 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-09-11 13:37:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 13:37:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:37:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:37:19 --> Final output sent to browser
DEBUG - 2017-09-11 13:37:19 --> Total execution time: 0.0589
INFO - 2017-09-11 10:07:21 --> Config Class Initialized
INFO - 2017-09-11 10:07:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:21 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:21 --> URI Class Initialized
INFO - 2017-09-11 10:07:21 --> Router Class Initialized
INFO - 2017-09-11 10:07:21 --> Output Class Initialized
INFO - 2017-09-11 10:07:21 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:21 --> Input Class Initialized
INFO - 2017-09-11 10:07:21 --> Language Class Initialized
INFO - 2017-09-11 10:07:21 --> Loader Class Initialized
INFO - 2017-09-11 10:07:21 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:21 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:21 --> Email Class Initialized
INFO - 2017-09-11 10:07:21 --> Controller Class Initialized
INFO - 2017-09-11 10:07:21 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:21 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:21 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:21 --> Model Class Initialized
INFO - 2017-09-11 10:07:21 --> Model Class Initialized
INFO - 2017-09-11 13:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:21 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:21 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:21 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:21 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:21 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:21 --> Undefined variable: details
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:21 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-09-11 13:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 13:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:37:21 --> Final output sent to browser
DEBUG - 2017-09-11 13:37:21 --> Total execution time: 0.0589
INFO - 2017-09-11 10:07:23 --> Config Class Initialized
INFO - 2017-09-11 10:07:23 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:23 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:23 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:23 --> URI Class Initialized
INFO - 2017-09-11 10:07:23 --> Router Class Initialized
INFO - 2017-09-11 10:07:23 --> Output Class Initialized
INFO - 2017-09-11 10:07:23 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:23 --> Input Class Initialized
INFO - 2017-09-11 10:07:23 --> Language Class Initialized
INFO - 2017-09-11 10:07:23 --> Loader Class Initialized
INFO - 2017-09-11 10:07:23 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:23 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:23 --> Email Class Initialized
INFO - 2017-09-11 10:07:23 --> Controller Class Initialized
INFO - 2017-09-11 10:07:23 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:23 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:23 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:23 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:23 --> Model Class Initialized
INFO - 2017-09-11 10:07:23 --> Model Class Initialized
INFO - 2017-09-11 13:37:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:37:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:23 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:23 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:23 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:23 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:23 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:23 --> Undefined variable: details
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:23 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-09-11 13:37:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 13:37:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:37:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:37:23 --> Final output sent to browser
DEBUG - 2017-09-11 13:37:23 --> Total execution time: 0.0711
INFO - 2017-09-11 10:07:27 --> Config Class Initialized
INFO - 2017-09-11 10:07:27 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:27 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:27 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:27 --> URI Class Initialized
INFO - 2017-09-11 10:07:27 --> Router Class Initialized
INFO - 2017-09-11 10:07:27 --> Output Class Initialized
INFO - 2017-09-11 10:07:27 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:27 --> Input Class Initialized
INFO - 2017-09-11 10:07:27 --> Language Class Initialized
INFO - 2017-09-11 10:07:27 --> Loader Class Initialized
INFO - 2017-09-11 10:07:27 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:27 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:27 --> Email Class Initialized
INFO - 2017-09-11 10:07:27 --> Controller Class Initialized
INFO - 2017-09-11 10:07:27 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:27 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:27 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:27 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:27 --> Model Class Initialized
INFO - 2017-09-11 10:07:27 --> Model Class Initialized
INFO - 2017-09-11 13:37:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:37:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 53
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:27 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:27 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:27 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 57
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 70
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:27 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:27 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:27 --> Undefined variable: details
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Undefined variable: details C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
ERROR - 2017-09-11 13:37:27 --> Trying to get property of non-object
ERROR - 2017-09-11 13:37:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Chats\addChats.php 74
INFO - 2017-09-11 13:37:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 13:37:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:37:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:37:27 --> Final output sent to browser
DEBUG - 2017-09-11 13:37:27 --> Total execution time: 0.0607
INFO - 2017-09-11 10:07:29 --> Config Class Initialized
INFO - 2017-09-11 10:07:29 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:29 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:29 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:29 --> URI Class Initialized
INFO - 2017-09-11 10:07:29 --> Router Class Initialized
INFO - 2017-09-11 10:07:29 --> Output Class Initialized
INFO - 2017-09-11 10:07:29 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:29 --> Input Class Initialized
INFO - 2017-09-11 10:07:29 --> Language Class Initialized
INFO - 2017-09-11 10:07:29 --> Loader Class Initialized
INFO - 2017-09-11 10:07:29 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:29 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:29 --> Email Class Initialized
INFO - 2017-09-11 10:07:29 --> Controller Class Initialized
INFO - 2017-09-11 10:07:29 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:29 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:29 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:29 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:29 --> Model Class Initialized
INFO - 2017-09-11 10:07:29 --> Model Class Initialized
INFO - 2017-09-11 13:37:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:37:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:37:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:37:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:37:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:37:29 --> Final output sent to browser
DEBUG - 2017-09-11 13:37:29 --> Total execution time: 0.0459
INFO - 2017-09-11 10:07:30 --> Config Class Initialized
INFO - 2017-09-11 10:07:30 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:30 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:30 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:30 --> URI Class Initialized
INFO - 2017-09-11 10:07:30 --> Router Class Initialized
INFO - 2017-09-11 10:07:30 --> Output Class Initialized
INFO - 2017-09-11 10:07:30 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:30 --> Input Class Initialized
INFO - 2017-09-11 10:07:30 --> Language Class Initialized
INFO - 2017-09-11 10:07:30 --> Loader Class Initialized
INFO - 2017-09-11 10:07:30 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:30 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:30 --> Email Class Initialized
INFO - 2017-09-11 10:07:30 --> Controller Class Initialized
INFO - 2017-09-11 10:07:30 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:30 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:30 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:30 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:30 --> Model Class Initialized
INFO - 2017-09-11 10:07:30 --> Model Class Initialized
INFO - 2017-09-11 13:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:37:30 --> Final output sent to browser
DEBUG - 2017-09-11 13:37:30 --> Total execution time: 0.0509
INFO - 2017-09-11 10:07:45 --> Config Class Initialized
INFO - 2017-09-11 10:07:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:07:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:07:45 --> Utf8 Class Initialized
INFO - 2017-09-11 10:07:45 --> URI Class Initialized
INFO - 2017-09-11 10:07:45 --> Router Class Initialized
INFO - 2017-09-11 10:07:45 --> Output Class Initialized
INFO - 2017-09-11 10:07:45 --> Security Class Initialized
DEBUG - 2017-09-11 10:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:07:45 --> Input Class Initialized
INFO - 2017-09-11 10:07:45 --> Language Class Initialized
INFO - 2017-09-11 10:07:45 --> Loader Class Initialized
INFO - 2017-09-11 10:07:45 --> Helper loaded: common_helper
INFO - 2017-09-11 10:07:45 --> Database Driver Class Initialized
INFO - 2017-09-11 10:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:07:45 --> Email Class Initialized
INFO - 2017-09-11 10:07:45 --> Controller Class Initialized
INFO - 2017-09-11 10:07:45 --> Helper loaded: form_helper
INFO - 2017-09-11 10:07:45 --> Form Validation Class Initialized
INFO - 2017-09-11 10:07:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:07:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:07:45 --> Helper loaded: url_helper
INFO - 2017-09-11 10:07:45 --> Model Class Initialized
INFO - 2017-09-11 10:07:45 --> Model Class Initialized
ERROR - 2017-09-11 13:37:45 --> Query error: Unknown column 'is_active' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `is_active` = 1
ERROR - 2017-09-11 13:37:45 --> Call to a member function result() on a non-object
ERROR - 2017-09-11 13:37:45 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 75
INFO - 2017-09-11 10:09:34 --> Config Class Initialized
INFO - 2017-09-11 10:09:34 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:09:34 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:09:34 --> Utf8 Class Initialized
INFO - 2017-09-11 10:09:34 --> URI Class Initialized
INFO - 2017-09-11 10:09:34 --> Router Class Initialized
INFO - 2017-09-11 10:09:34 --> Output Class Initialized
INFO - 2017-09-11 10:09:34 --> Security Class Initialized
DEBUG - 2017-09-11 10:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:09:34 --> Input Class Initialized
INFO - 2017-09-11 10:09:34 --> Language Class Initialized
INFO - 2017-09-11 10:09:34 --> Loader Class Initialized
INFO - 2017-09-11 10:09:34 --> Helper loaded: common_helper
INFO - 2017-09-11 10:09:34 --> Database Driver Class Initialized
INFO - 2017-09-11 10:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:09:34 --> Email Class Initialized
INFO - 2017-09-11 10:09:34 --> Controller Class Initialized
INFO - 2017-09-11 10:09:34 --> Helper loaded: form_helper
INFO - 2017-09-11 10:09:34 --> Form Validation Class Initialized
INFO - 2017-09-11 10:09:34 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:09:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:09:34 --> Helper loaded: url_helper
INFO - 2017-09-11 10:09:34 --> Model Class Initialized
INFO - 2017-09-11 10:09:34 --> Model Class Initialized
ERROR - 2017-09-11 13:39:34 --> Query error: Unknown column 'is_active' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `is_active` = 1
ERROR - 2017-09-11 13:39:34 --> Call to a member function result() on a non-object
ERROR - 2017-09-11 13:39:34 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 75
INFO - 2017-09-11 10:10:09 --> Config Class Initialized
INFO - 2017-09-11 10:10:09 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:10:09 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:10:09 --> Utf8 Class Initialized
INFO - 2017-09-11 10:10:09 --> URI Class Initialized
INFO - 2017-09-11 10:10:09 --> Router Class Initialized
INFO - 2017-09-11 10:10:09 --> Output Class Initialized
INFO - 2017-09-11 10:10:09 --> Security Class Initialized
DEBUG - 2017-09-11 10:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:10:09 --> Input Class Initialized
INFO - 2017-09-11 10:10:09 --> Language Class Initialized
INFO - 2017-09-11 10:10:09 --> Loader Class Initialized
INFO - 2017-09-11 10:10:09 --> Helper loaded: common_helper
INFO - 2017-09-11 10:10:09 --> Database Driver Class Initialized
INFO - 2017-09-11 10:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:10:09 --> Email Class Initialized
INFO - 2017-09-11 10:10:09 --> Controller Class Initialized
INFO - 2017-09-11 10:10:09 --> Helper loaded: form_helper
INFO - 2017-09-11 10:10:09 --> Form Validation Class Initialized
INFO - 2017-09-11 10:10:09 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:10:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:10:09 --> Helper loaded: url_helper
INFO - 2017-09-11 10:10:09 --> Model Class Initialized
INFO - 2017-09-11 10:10:09 --> Model Class Initialized
INFO - 2017-09-11 13:40:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:40:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:40:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:40:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:40:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:40:09 --> Final output sent to browser
DEBUG - 2017-09-11 13:40:09 --> Total execution time: 0.0454
INFO - 2017-09-11 10:11:04 --> Config Class Initialized
INFO - 2017-09-11 10:11:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:11:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:11:04 --> Utf8 Class Initialized
INFO - 2017-09-11 10:11:04 --> URI Class Initialized
INFO - 2017-09-11 10:11:04 --> Router Class Initialized
INFO - 2017-09-11 10:11:04 --> Output Class Initialized
INFO - 2017-09-11 10:11:04 --> Security Class Initialized
DEBUG - 2017-09-11 10:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:11:04 --> Input Class Initialized
INFO - 2017-09-11 10:11:04 --> Language Class Initialized
INFO - 2017-09-11 10:11:04 --> Loader Class Initialized
INFO - 2017-09-11 10:11:04 --> Helper loaded: common_helper
INFO - 2017-09-11 10:11:04 --> Database Driver Class Initialized
INFO - 2017-09-11 10:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:11:04 --> Email Class Initialized
INFO - 2017-09-11 10:11:04 --> Controller Class Initialized
INFO - 2017-09-11 10:11:04 --> Helper loaded: form_helper
INFO - 2017-09-11 10:11:04 --> Form Validation Class Initialized
INFO - 2017-09-11 10:11:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:11:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:11:04 --> Helper loaded: url_helper
INFO - 2017-09-11 10:11:04 --> Model Class Initialized
INFO - 2017-09-11 10:11:04 --> Model Class Initialized
INFO - 2017-09-11 13:41:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:41:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:41:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:41:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:41:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:41:04 --> Final output sent to browser
DEBUG - 2017-09-11 13:41:04 --> Total execution time: 0.0456
INFO - 2017-09-11 10:12:05 --> Config Class Initialized
INFO - 2017-09-11 10:12:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:12:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:12:05 --> Utf8 Class Initialized
INFO - 2017-09-11 10:12:05 --> URI Class Initialized
INFO - 2017-09-11 10:12:05 --> Router Class Initialized
INFO - 2017-09-11 10:12:05 --> Output Class Initialized
INFO - 2017-09-11 10:12:05 --> Security Class Initialized
DEBUG - 2017-09-11 10:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:12:05 --> Input Class Initialized
INFO - 2017-09-11 10:12:05 --> Language Class Initialized
INFO - 2017-09-11 10:12:05 --> Loader Class Initialized
INFO - 2017-09-11 10:12:05 --> Helper loaded: common_helper
INFO - 2017-09-11 10:12:05 --> Database Driver Class Initialized
INFO - 2017-09-11 10:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:12:05 --> Email Class Initialized
INFO - 2017-09-11 10:12:05 --> Controller Class Initialized
INFO - 2017-09-11 10:12:05 --> Helper loaded: form_helper
INFO - 2017-09-11 10:12:05 --> Form Validation Class Initialized
INFO - 2017-09-11 10:12:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:12:05 --> Helper loaded: url_helper
INFO - 2017-09-11 10:12:05 --> Model Class Initialized
INFO - 2017-09-11 10:12:05 --> Model Class Initialized
INFO - 2017-09-11 13:42:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:42:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:42:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:42:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:42:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:42:05 --> Final output sent to browser
DEBUG - 2017-09-11 13:42:05 --> Total execution time: 0.0481
INFO - 2017-09-11 10:12:19 --> Config Class Initialized
INFO - 2017-09-11 10:12:19 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:12:19 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:12:19 --> Utf8 Class Initialized
INFO - 2017-09-11 10:12:19 --> URI Class Initialized
INFO - 2017-09-11 10:12:19 --> Router Class Initialized
INFO - 2017-09-11 10:12:19 --> Output Class Initialized
INFO - 2017-09-11 10:12:19 --> Security Class Initialized
DEBUG - 2017-09-11 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:12:19 --> Input Class Initialized
INFO - 2017-09-11 10:12:19 --> Language Class Initialized
INFO - 2017-09-11 10:12:19 --> Loader Class Initialized
INFO - 2017-09-11 10:12:19 --> Helper loaded: common_helper
INFO - 2017-09-11 10:12:19 --> Database Driver Class Initialized
INFO - 2017-09-11 10:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:12:19 --> Email Class Initialized
INFO - 2017-09-11 10:12:19 --> Controller Class Initialized
INFO - 2017-09-11 10:12:19 --> Helper loaded: form_helper
INFO - 2017-09-11 10:12:19 --> Form Validation Class Initialized
INFO - 2017-09-11 10:12:19 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:12:19 --> Helper loaded: url_helper
INFO - 2017-09-11 10:12:19 --> Model Class Initialized
INFO - 2017-09-11 10:12:19 --> Model Class Initialized
DEBUG - 2017-09-11 13:42:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:42:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:12:19 --> Config Class Initialized
INFO - 2017-09-11 10:12:19 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:12:19 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:12:19 --> Utf8 Class Initialized
INFO - 2017-09-11 10:12:19 --> URI Class Initialized
INFO - 2017-09-11 10:12:19 --> Router Class Initialized
INFO - 2017-09-11 10:12:19 --> Output Class Initialized
INFO - 2017-09-11 10:12:19 --> Security Class Initialized
DEBUG - 2017-09-11 10:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:12:19 --> Input Class Initialized
INFO - 2017-09-11 10:12:19 --> Language Class Initialized
INFO - 2017-09-11 10:12:19 --> Loader Class Initialized
INFO - 2017-09-11 10:12:19 --> Helper loaded: common_helper
INFO - 2017-09-11 10:12:19 --> Database Driver Class Initialized
INFO - 2017-09-11 10:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:12:19 --> Email Class Initialized
INFO - 2017-09-11 10:12:19 --> Controller Class Initialized
INFO - 2017-09-11 10:12:19 --> Helper loaded: form_helper
INFO - 2017-09-11 10:12:19 --> Form Validation Class Initialized
INFO - 2017-09-11 10:12:19 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:12:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:12:19 --> Helper loaded: url_helper
INFO - 2017-09-11 10:12:19 --> Model Class Initialized
INFO - 2017-09-11 10:12:19 --> Model Class Initialized
INFO - 2017-09-11 13:42:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:42:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:42:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:42:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:42:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:42:19 --> Final output sent to browser
DEBUG - 2017-09-11 13:42:19 --> Total execution time: 0.0496
INFO - 2017-09-11 10:12:57 --> Config Class Initialized
INFO - 2017-09-11 10:12:57 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:12:57 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:12:57 --> Utf8 Class Initialized
INFO - 2017-09-11 10:12:57 --> URI Class Initialized
INFO - 2017-09-11 10:12:57 --> Router Class Initialized
INFO - 2017-09-11 10:12:57 --> Output Class Initialized
INFO - 2017-09-11 10:12:57 --> Security Class Initialized
DEBUG - 2017-09-11 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:12:57 --> Input Class Initialized
INFO - 2017-09-11 10:12:57 --> Language Class Initialized
INFO - 2017-09-11 10:12:57 --> Loader Class Initialized
INFO - 2017-09-11 10:12:57 --> Helper loaded: common_helper
INFO - 2017-09-11 10:12:57 --> Database Driver Class Initialized
INFO - 2017-09-11 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:12:57 --> Email Class Initialized
INFO - 2017-09-11 10:12:57 --> Controller Class Initialized
INFO - 2017-09-11 10:12:57 --> Helper loaded: form_helper
INFO - 2017-09-11 10:12:57 --> Form Validation Class Initialized
INFO - 2017-09-11 10:12:57 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:12:57 --> Helper loaded: url_helper
INFO - 2017-09-11 10:12:57 --> Model Class Initialized
INFO - 2017-09-11 10:12:57 --> Model Class Initialized
INFO - 2017-09-11 13:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:42:57 --> Final output sent to browser
DEBUG - 2017-09-11 13:42:57 --> Total execution time: 0.0456
INFO - 2017-09-11 10:13:00 --> Config Class Initialized
INFO - 2017-09-11 10:13:00 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:13:00 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:13:00 --> Utf8 Class Initialized
INFO - 2017-09-11 10:13:00 --> URI Class Initialized
INFO - 2017-09-11 10:13:00 --> Router Class Initialized
INFO - 2017-09-11 10:13:00 --> Output Class Initialized
INFO - 2017-09-11 10:13:00 --> Security Class Initialized
DEBUG - 2017-09-11 10:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:13:00 --> Input Class Initialized
INFO - 2017-09-11 10:13:00 --> Language Class Initialized
INFO - 2017-09-11 10:13:00 --> Loader Class Initialized
INFO - 2017-09-11 10:13:00 --> Helper loaded: common_helper
INFO - 2017-09-11 10:13:00 --> Database Driver Class Initialized
INFO - 2017-09-11 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:13:00 --> Email Class Initialized
INFO - 2017-09-11 10:13:00 --> Controller Class Initialized
INFO - 2017-09-11 10:13:00 --> Helper loaded: form_helper
INFO - 2017-09-11 10:13:00 --> Form Validation Class Initialized
INFO - 2017-09-11 10:13:00 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:13:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:13:00 --> Helper loaded: url_helper
INFO - 2017-09-11 10:13:00 --> Model Class Initialized
INFO - 2017-09-11 10:13:00 --> Model Class Initialized
DEBUG - 2017-09-11 13:43:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:43:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:43:00 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `name` = 'sas'
AND `id` = ''
ERROR - 2017-09-11 13:43:00 --> Call to a member function result() on a non-object
ERROR - 2017-09-11 13:43:00 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 75
INFO - 2017-09-11 10:14:50 --> Config Class Initialized
INFO - 2017-09-11 10:14:50 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:14:50 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:14:50 --> Utf8 Class Initialized
INFO - 2017-09-11 10:14:50 --> URI Class Initialized
INFO - 2017-09-11 10:14:50 --> Router Class Initialized
INFO - 2017-09-11 10:14:50 --> Output Class Initialized
INFO - 2017-09-11 10:14:50 --> Security Class Initialized
DEBUG - 2017-09-11 10:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:14:50 --> Input Class Initialized
INFO - 2017-09-11 10:14:50 --> Language Class Initialized
INFO - 2017-09-11 10:14:50 --> Loader Class Initialized
INFO - 2017-09-11 10:14:50 --> Helper loaded: common_helper
INFO - 2017-09-11 10:14:50 --> Database Driver Class Initialized
INFO - 2017-09-11 10:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:14:50 --> Email Class Initialized
INFO - 2017-09-11 10:14:50 --> Controller Class Initialized
INFO - 2017-09-11 10:14:50 --> Helper loaded: form_helper
INFO - 2017-09-11 10:14:50 --> Form Validation Class Initialized
INFO - 2017-09-11 10:14:50 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:14:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:14:50 --> Helper loaded: url_helper
INFO - 2017-09-11 10:14:50 --> Model Class Initialized
INFO - 2017-09-11 10:14:50 --> Model Class Initialized
DEBUG - 2017-09-11 13:44:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:44:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:44:50 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT *
FROM `settings`
WHERE `name` = 'sas'
AND `id` = ''
ERROR - 2017-09-11 13:44:50 --> Call to a member function result() on a non-object
ERROR - 2017-09-11 13:44:50 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 75
INFO - 2017-09-11 10:15:11 --> Config Class Initialized
INFO - 2017-09-11 10:15:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:15:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:15:11 --> Utf8 Class Initialized
INFO - 2017-09-11 10:15:11 --> URI Class Initialized
INFO - 2017-09-11 10:15:11 --> Router Class Initialized
INFO - 2017-09-11 10:15:11 --> Output Class Initialized
INFO - 2017-09-11 10:15:11 --> Security Class Initialized
DEBUG - 2017-09-11 10:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:15:11 --> Input Class Initialized
INFO - 2017-09-11 10:15:11 --> Language Class Initialized
INFO - 2017-09-11 10:15:11 --> Loader Class Initialized
INFO - 2017-09-11 10:15:11 --> Helper loaded: common_helper
INFO - 2017-09-11 10:15:11 --> Database Driver Class Initialized
INFO - 2017-09-11 10:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:15:11 --> Email Class Initialized
INFO - 2017-09-11 10:15:11 --> Controller Class Initialized
INFO - 2017-09-11 10:15:11 --> Helper loaded: form_helper
INFO - 2017-09-11 10:15:11 --> Form Validation Class Initialized
INFO - 2017-09-11 10:15:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:15:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:15:11 --> Helper loaded: url_helper
INFO - 2017-09-11 10:15:11 --> Model Class Initialized
INFO - 2017-09-11 10:15:11 --> Model Class Initialized
DEBUG - 2017-09-11 13:45:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:45:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:15:23 --> Config Class Initialized
INFO - 2017-09-11 10:15:23 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:15:23 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:15:23 --> Utf8 Class Initialized
INFO - 2017-09-11 10:15:23 --> URI Class Initialized
INFO - 2017-09-11 10:15:23 --> Router Class Initialized
INFO - 2017-09-11 10:15:23 --> Output Class Initialized
INFO - 2017-09-11 10:15:23 --> Security Class Initialized
DEBUG - 2017-09-11 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:15:23 --> Input Class Initialized
INFO - 2017-09-11 10:15:23 --> Language Class Initialized
INFO - 2017-09-11 10:15:23 --> Loader Class Initialized
INFO - 2017-09-11 10:15:23 --> Helper loaded: common_helper
INFO - 2017-09-11 10:15:23 --> Database Driver Class Initialized
INFO - 2017-09-11 10:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:15:23 --> Email Class Initialized
INFO - 2017-09-11 10:15:23 --> Controller Class Initialized
INFO - 2017-09-11 10:15:23 --> Helper loaded: form_helper
INFO - 2017-09-11 10:15:23 --> Form Validation Class Initialized
INFO - 2017-09-11 10:15:23 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:15:23 --> Helper loaded: url_helper
INFO - 2017-09-11 10:15:23 --> Model Class Initialized
INFO - 2017-09-11 10:15:23 --> Model Class Initialized
DEBUG - 2017-09-11 13:45:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:45:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:45:23 --> Query error: Unknown column 'value' in 'field list' - Invalid query: INSERT INTO `settings` (`SettingName`, `value`, `createdTime`) VALUES ('sas', '12', '17-09-11 01:45:23')
INFO - 2017-09-11 10:15:23 --> Config Class Initialized
INFO - 2017-09-11 10:15:23 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:15:23 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:15:23 --> Utf8 Class Initialized
INFO - 2017-09-11 10:15:23 --> URI Class Initialized
INFO - 2017-09-11 10:15:23 --> Router Class Initialized
INFO - 2017-09-11 10:15:23 --> Output Class Initialized
INFO - 2017-09-11 10:15:23 --> Security Class Initialized
DEBUG - 2017-09-11 10:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:15:23 --> Input Class Initialized
INFO - 2017-09-11 10:15:23 --> Language Class Initialized
INFO - 2017-09-11 10:15:23 --> Loader Class Initialized
INFO - 2017-09-11 10:15:23 --> Helper loaded: common_helper
INFO - 2017-09-11 10:15:23 --> Database Driver Class Initialized
INFO - 2017-09-11 10:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:15:23 --> Email Class Initialized
INFO - 2017-09-11 10:15:23 --> Controller Class Initialized
INFO - 2017-09-11 10:15:23 --> Helper loaded: form_helper
INFO - 2017-09-11 10:15:23 --> Form Validation Class Initialized
INFO - 2017-09-11 10:15:23 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:15:23 --> Helper loaded: url_helper
INFO - 2017-09-11 10:15:23 --> Model Class Initialized
INFO - 2017-09-11 10:15:23 --> Model Class Initialized
INFO - 2017-09-11 13:45:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:45:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:45:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:45:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:45:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:45:23 --> Final output sent to browser
DEBUG - 2017-09-11 13:45:23 --> Total execution time: 0.0464
INFO - 2017-09-11 10:15:53 --> Config Class Initialized
INFO - 2017-09-11 10:15:53 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:15:53 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:15:53 --> Utf8 Class Initialized
INFO - 2017-09-11 10:15:53 --> URI Class Initialized
INFO - 2017-09-11 10:15:53 --> Router Class Initialized
INFO - 2017-09-11 10:15:53 --> Output Class Initialized
INFO - 2017-09-11 10:15:53 --> Security Class Initialized
DEBUG - 2017-09-11 10:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:15:53 --> Input Class Initialized
INFO - 2017-09-11 10:15:53 --> Language Class Initialized
INFO - 2017-09-11 10:15:53 --> Loader Class Initialized
INFO - 2017-09-11 10:15:53 --> Helper loaded: common_helper
INFO - 2017-09-11 10:15:53 --> Database Driver Class Initialized
INFO - 2017-09-11 10:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:15:53 --> Email Class Initialized
INFO - 2017-09-11 10:15:53 --> Controller Class Initialized
INFO - 2017-09-11 10:15:53 --> Helper loaded: form_helper
INFO - 2017-09-11 10:15:53 --> Form Validation Class Initialized
INFO - 2017-09-11 10:15:53 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:15:53 --> Helper loaded: url_helper
INFO - 2017-09-11 10:15:53 --> Model Class Initialized
INFO - 2017-09-11 10:15:53 --> Model Class Initialized
DEBUG - 2017-09-11 13:45:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:45:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:45:53 --> Query error: Unknown column 'value' in 'field list' - Invalid query: INSERT INTO `settings` (`SettingName`, `value`, `createdTime`) VALUES ('offset', '12', '17-09-11 01:45:53')
INFO - 2017-09-11 10:16:45 --> Config Class Initialized
INFO - 2017-09-11 10:16:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:16:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:16:45 --> Utf8 Class Initialized
INFO - 2017-09-11 10:16:45 --> URI Class Initialized
INFO - 2017-09-11 10:16:45 --> Router Class Initialized
INFO - 2017-09-11 10:16:45 --> Output Class Initialized
INFO - 2017-09-11 10:16:45 --> Security Class Initialized
DEBUG - 2017-09-11 10:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:16:45 --> Input Class Initialized
INFO - 2017-09-11 10:16:45 --> Language Class Initialized
INFO - 2017-09-11 10:16:45 --> Loader Class Initialized
INFO - 2017-09-11 10:16:45 --> Helper loaded: common_helper
INFO - 2017-09-11 10:16:45 --> Database Driver Class Initialized
INFO - 2017-09-11 10:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:16:45 --> Email Class Initialized
INFO - 2017-09-11 10:16:45 --> Controller Class Initialized
INFO - 2017-09-11 10:16:45 --> Helper loaded: form_helper
INFO - 2017-09-11 10:16:45 --> Form Validation Class Initialized
INFO - 2017-09-11 10:16:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:16:45 --> Helper loaded: url_helper
INFO - 2017-09-11 10:16:45 --> Model Class Initialized
INFO - 2017-09-11 10:16:45 --> Model Class Initialized
DEBUG - 2017-09-11 13:46:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:46:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:16:45 --> Config Class Initialized
INFO - 2017-09-11 10:16:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:16:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:16:45 --> Utf8 Class Initialized
INFO - 2017-09-11 10:16:45 --> URI Class Initialized
INFO - 2017-09-11 10:16:45 --> Router Class Initialized
INFO - 2017-09-11 10:16:45 --> Output Class Initialized
INFO - 2017-09-11 10:16:45 --> Security Class Initialized
DEBUG - 2017-09-11 10:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:16:45 --> Input Class Initialized
INFO - 2017-09-11 10:16:45 --> Language Class Initialized
INFO - 2017-09-11 10:16:45 --> Loader Class Initialized
INFO - 2017-09-11 10:16:45 --> Helper loaded: common_helper
INFO - 2017-09-11 10:16:45 --> Database Driver Class Initialized
INFO - 2017-09-11 10:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:16:45 --> Email Class Initialized
INFO - 2017-09-11 10:16:45 --> Controller Class Initialized
INFO - 2017-09-11 10:16:45 --> Helper loaded: form_helper
INFO - 2017-09-11 10:16:45 --> Form Validation Class Initialized
INFO - 2017-09-11 10:16:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:16:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:16:45 --> Helper loaded: url_helper
INFO - 2017-09-11 10:16:45 --> Model Class Initialized
INFO - 2017-09-11 10:16:45 --> Model Class Initialized
INFO - 2017-09-11 13:46:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:46:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:46:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:46:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 13:46:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:46:45 --> Final output sent to browser
DEBUG - 2017-09-11 13:46:45 --> Total execution time: 0.1146
INFO - 2017-09-11 10:17:05 --> Config Class Initialized
INFO - 2017-09-11 10:17:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:05 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:05 --> URI Class Initialized
INFO - 2017-09-11 10:17:05 --> Router Class Initialized
INFO - 2017-09-11 10:17:05 --> Output Class Initialized
INFO - 2017-09-11 10:17:05 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:05 --> Input Class Initialized
INFO - 2017-09-11 10:17:05 --> Language Class Initialized
INFO - 2017-09-11 10:17:05 --> Loader Class Initialized
INFO - 2017-09-11 10:17:05 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:05 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:05 --> Email Class Initialized
INFO - 2017-09-11 10:17:05 --> Controller Class Initialized
INFO - 2017-09-11 10:17:05 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:05 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:05 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:05 --> Model Class Initialized
INFO - 2017-09-11 10:17:05 --> Model Class Initialized
INFO - 2017-09-11 13:47:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 13:47:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:05 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:05 --> Total execution time: 0.0483
INFO - 2017-09-11 10:17:06 --> Config Class Initialized
INFO - 2017-09-11 10:17:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:06 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:06 --> URI Class Initialized
INFO - 2017-09-11 10:17:06 --> Router Class Initialized
INFO - 2017-09-11 10:17:06 --> Output Class Initialized
INFO - 2017-09-11 10:17:06 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:06 --> Input Class Initialized
INFO - 2017-09-11 10:17:06 --> Language Class Initialized
INFO - 2017-09-11 10:17:06 --> Loader Class Initialized
INFO - 2017-09-11 10:17:06 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:06 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:06 --> Email Class Initialized
INFO - 2017-09-11 10:17:06 --> Controller Class Initialized
INFO - 2017-09-11 10:17:06 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:06 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:06 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:06 --> Model Class Initialized
INFO - 2017-09-11 10:17:06 --> Model Class Initialized
INFO - 2017-09-11 13:47:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:47:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:06 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:06 --> Total execution time: 0.0493
INFO - 2017-09-11 10:17:08 --> Config Class Initialized
INFO - 2017-09-11 10:17:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:08 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:08 --> URI Class Initialized
INFO - 2017-09-11 10:17:08 --> Router Class Initialized
INFO - 2017-09-11 10:17:08 --> Output Class Initialized
INFO - 2017-09-11 10:17:08 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:08 --> Input Class Initialized
INFO - 2017-09-11 10:17:08 --> Language Class Initialized
INFO - 2017-09-11 10:17:08 --> Loader Class Initialized
INFO - 2017-09-11 10:17:08 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:08 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:08 --> Email Class Initialized
INFO - 2017-09-11 10:17:08 --> Controller Class Initialized
INFO - 2017-09-11 10:17:08 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:08 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:08 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:08 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:08 --> Model Class Initialized
INFO - 2017-09-11 10:17:08 --> Model Class Initialized
DEBUG - 2017-09-11 13:47:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:47:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:17:08 --> Config Class Initialized
INFO - 2017-09-11 10:17:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:08 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:08 --> URI Class Initialized
INFO - 2017-09-11 10:17:08 --> Router Class Initialized
INFO - 2017-09-11 10:17:08 --> Output Class Initialized
INFO - 2017-09-11 10:17:08 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:08 --> Input Class Initialized
INFO - 2017-09-11 10:17:08 --> Language Class Initialized
INFO - 2017-09-11 10:17:08 --> Loader Class Initialized
INFO - 2017-09-11 10:17:08 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:08 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:08 --> Email Class Initialized
INFO - 2017-09-11 10:17:08 --> Controller Class Initialized
INFO - 2017-09-11 10:17:08 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:08 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:08 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:08 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:08 --> Model Class Initialized
INFO - 2017-09-11 10:17:08 --> Model Class Initialized
INFO - 2017-09-11 13:47:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:47:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:08 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:08 --> Total execution time: 0.0498
INFO - 2017-09-11 10:17:42 --> Config Class Initialized
INFO - 2017-09-11 10:17:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:42 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:42 --> URI Class Initialized
INFO - 2017-09-11 10:17:42 --> Router Class Initialized
INFO - 2017-09-11 10:17:42 --> Output Class Initialized
INFO - 2017-09-11 10:17:42 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:42 --> Input Class Initialized
INFO - 2017-09-11 10:17:42 --> Language Class Initialized
INFO - 2017-09-11 10:17:42 --> Loader Class Initialized
INFO - 2017-09-11 10:17:42 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:42 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:42 --> Email Class Initialized
INFO - 2017-09-11 10:17:42 --> Controller Class Initialized
INFO - 2017-09-11 10:17:42 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:42 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:42 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:42 --> Model Class Initialized
INFO - 2017-09-11 10:17:42 --> Model Class Initialized
INFO - 2017-09-11 13:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:42 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:42 --> Total execution time: 0.0479
INFO - 2017-09-11 10:17:43 --> Config Class Initialized
INFO - 2017-09-11 10:17:43 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:43 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:43 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:43 --> URI Class Initialized
INFO - 2017-09-11 10:17:43 --> Router Class Initialized
INFO - 2017-09-11 10:17:43 --> Output Class Initialized
INFO - 2017-09-11 10:17:43 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:43 --> Input Class Initialized
INFO - 2017-09-11 10:17:43 --> Language Class Initialized
INFO - 2017-09-11 10:17:43 --> Loader Class Initialized
INFO - 2017-09-11 10:17:43 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:43 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:43 --> Email Class Initialized
INFO - 2017-09-11 10:17:43 --> Controller Class Initialized
INFO - 2017-09-11 10:17:43 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:43 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:43 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:43 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:43 --> Model Class Initialized
INFO - 2017-09-11 10:17:43 --> Model Class Initialized
INFO - 2017-09-11 13:47:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:47:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:43 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:43 --> Total execution time: 0.0560
INFO - 2017-09-11 10:17:49 --> Config Class Initialized
INFO - 2017-09-11 10:17:49 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:49 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:49 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:49 --> URI Class Initialized
INFO - 2017-09-11 10:17:49 --> Router Class Initialized
INFO - 2017-09-11 10:17:49 --> Output Class Initialized
INFO - 2017-09-11 10:17:49 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:49 --> Input Class Initialized
INFO - 2017-09-11 10:17:49 --> Language Class Initialized
INFO - 2017-09-11 10:17:49 --> Loader Class Initialized
INFO - 2017-09-11 10:17:49 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:49 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:49 --> Email Class Initialized
INFO - 2017-09-11 10:17:49 --> Controller Class Initialized
INFO - 2017-09-11 10:17:49 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:49 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:49 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:49 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:49 --> Model Class Initialized
INFO - 2017-09-11 10:17:49 --> Model Class Initialized
DEBUG - 2017-09-11 13:47:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:47:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:17:50 --> Config Class Initialized
INFO - 2017-09-11 10:17:50 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:50 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:50 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:50 --> URI Class Initialized
INFO - 2017-09-11 10:17:50 --> Router Class Initialized
INFO - 2017-09-11 10:17:50 --> Output Class Initialized
INFO - 2017-09-11 10:17:50 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:50 --> Input Class Initialized
INFO - 2017-09-11 10:17:50 --> Language Class Initialized
INFO - 2017-09-11 10:17:50 --> Loader Class Initialized
INFO - 2017-09-11 10:17:50 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:50 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:50 --> Email Class Initialized
INFO - 2017-09-11 10:17:50 --> Controller Class Initialized
INFO - 2017-09-11 10:17:50 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:50 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:50 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:50 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:50 --> Model Class Initialized
INFO - 2017-09-11 10:17:50 --> Model Class Initialized
INFO - 2017-09-11 13:47:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:47:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:50 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:50 --> Total execution time: 0.0498
INFO - 2017-09-11 10:17:58 --> Config Class Initialized
INFO - 2017-09-11 10:17:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:17:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:17:58 --> Utf8 Class Initialized
INFO - 2017-09-11 10:17:58 --> URI Class Initialized
INFO - 2017-09-11 10:17:58 --> Router Class Initialized
INFO - 2017-09-11 10:17:58 --> Output Class Initialized
INFO - 2017-09-11 10:17:58 --> Security Class Initialized
DEBUG - 2017-09-11 10:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:17:58 --> Input Class Initialized
INFO - 2017-09-11 10:17:58 --> Language Class Initialized
INFO - 2017-09-11 10:17:58 --> Loader Class Initialized
INFO - 2017-09-11 10:17:58 --> Helper loaded: common_helper
INFO - 2017-09-11 10:17:58 --> Database Driver Class Initialized
INFO - 2017-09-11 10:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:17:58 --> Email Class Initialized
INFO - 2017-09-11 10:17:58 --> Controller Class Initialized
INFO - 2017-09-11 10:17:58 --> Helper loaded: form_helper
INFO - 2017-09-11 10:17:58 --> Form Validation Class Initialized
INFO - 2017-09-11 10:17:58 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:17:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:17:58 --> Helper loaded: url_helper
INFO - 2017-09-11 10:17:58 --> Model Class Initialized
INFO - 2017-09-11 10:17:58 --> Model Class Initialized
INFO - 2017-09-11 13:47:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:47:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:47:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:47:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:47:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:47:58 --> Final output sent to browser
DEBUG - 2017-09-11 13:47:58 --> Total execution time: 0.0579
INFO - 2017-09-11 10:18:16 --> Config Class Initialized
INFO - 2017-09-11 10:18:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:18:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:18:16 --> Utf8 Class Initialized
INFO - 2017-09-11 10:18:16 --> URI Class Initialized
INFO - 2017-09-11 10:18:16 --> Router Class Initialized
INFO - 2017-09-11 10:18:16 --> Output Class Initialized
INFO - 2017-09-11 10:18:16 --> Security Class Initialized
DEBUG - 2017-09-11 10:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:18:16 --> Input Class Initialized
INFO - 2017-09-11 10:18:16 --> Language Class Initialized
INFO - 2017-09-11 10:18:16 --> Loader Class Initialized
INFO - 2017-09-11 10:18:16 --> Helper loaded: common_helper
INFO - 2017-09-11 10:18:16 --> Database Driver Class Initialized
INFO - 2017-09-11 10:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:18:16 --> Email Class Initialized
INFO - 2017-09-11 10:18:16 --> Controller Class Initialized
INFO - 2017-09-11 10:18:16 --> Helper loaded: form_helper
INFO - 2017-09-11 10:18:16 --> Form Validation Class Initialized
INFO - 2017-09-11 10:18:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:18:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:18:16 --> Helper loaded: url_helper
INFO - 2017-09-11 10:18:16 --> Model Class Initialized
INFO - 2017-09-11 10:18:16 --> Model Class Initialized
INFO - 2017-09-11 13:48:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:48:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:48:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:48:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:48:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:48:16 --> Final output sent to browser
DEBUG - 2017-09-11 13:48:16 --> Total execution time: 0.0465
INFO - 2017-09-11 10:18:33 --> Config Class Initialized
INFO - 2017-09-11 10:18:33 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:18:33 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:18:33 --> Utf8 Class Initialized
INFO - 2017-09-11 10:18:33 --> URI Class Initialized
INFO - 2017-09-11 10:18:33 --> Router Class Initialized
INFO - 2017-09-11 10:18:33 --> Output Class Initialized
INFO - 2017-09-11 10:18:33 --> Security Class Initialized
DEBUG - 2017-09-11 10:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:18:33 --> Input Class Initialized
INFO - 2017-09-11 10:18:33 --> Language Class Initialized
INFO - 2017-09-11 10:18:33 --> Loader Class Initialized
INFO - 2017-09-11 10:18:33 --> Helper loaded: common_helper
INFO - 2017-09-11 10:18:33 --> Database Driver Class Initialized
INFO - 2017-09-11 10:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:18:33 --> Email Class Initialized
INFO - 2017-09-11 10:18:33 --> Controller Class Initialized
INFO - 2017-09-11 10:18:33 --> Helper loaded: form_helper
INFO - 2017-09-11 10:18:33 --> Form Validation Class Initialized
INFO - 2017-09-11 10:18:33 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:18:33 --> Helper loaded: url_helper
INFO - 2017-09-11 10:18:33 --> Model Class Initialized
INFO - 2017-09-11 10:18:33 --> Model Class Initialized
INFO - 2017-09-11 13:48:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:48:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:48:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:48:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:48:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:48:33 --> Final output sent to browser
DEBUG - 2017-09-11 13:48:33 --> Total execution time: 0.0531
INFO - 2017-09-11 10:18:42 --> Config Class Initialized
INFO - 2017-09-11 10:18:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:18:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:18:42 --> Utf8 Class Initialized
INFO - 2017-09-11 10:18:42 --> URI Class Initialized
INFO - 2017-09-11 10:18:42 --> Router Class Initialized
INFO - 2017-09-11 10:18:42 --> Output Class Initialized
INFO - 2017-09-11 10:18:42 --> Security Class Initialized
DEBUG - 2017-09-11 10:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:18:42 --> Input Class Initialized
INFO - 2017-09-11 10:18:42 --> Language Class Initialized
INFO - 2017-09-11 10:18:42 --> Loader Class Initialized
INFO - 2017-09-11 10:18:42 --> Helper loaded: common_helper
INFO - 2017-09-11 10:18:42 --> Database Driver Class Initialized
INFO - 2017-09-11 10:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:18:42 --> Email Class Initialized
INFO - 2017-09-11 10:18:42 --> Controller Class Initialized
INFO - 2017-09-11 10:18:42 --> Helper loaded: form_helper
INFO - 2017-09-11 10:18:42 --> Form Validation Class Initialized
INFO - 2017-09-11 10:18:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:18:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:18:42 --> Helper loaded: url_helper
INFO - 2017-09-11 10:18:42 --> Model Class Initialized
INFO - 2017-09-11 10:18:42 --> Model Class Initialized
INFO - 2017-09-11 13:48:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:48:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:48:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:48:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:48:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:48:42 --> Final output sent to browser
DEBUG - 2017-09-11 13:48:42 --> Total execution time: 0.0487
INFO - 2017-09-11 10:25:40 --> Config Class Initialized
INFO - 2017-09-11 10:25:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:25:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:25:40 --> Utf8 Class Initialized
INFO - 2017-09-11 10:25:40 --> URI Class Initialized
INFO - 2017-09-11 10:25:40 --> Router Class Initialized
INFO - 2017-09-11 10:25:40 --> Output Class Initialized
INFO - 2017-09-11 10:25:40 --> Security Class Initialized
DEBUG - 2017-09-11 10:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:25:40 --> Input Class Initialized
INFO - 2017-09-11 10:25:40 --> Language Class Initialized
INFO - 2017-09-11 10:25:40 --> Loader Class Initialized
INFO - 2017-09-11 10:25:40 --> Helper loaded: common_helper
INFO - 2017-09-11 10:25:40 --> Database Driver Class Initialized
INFO - 2017-09-11 10:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:25:40 --> Email Class Initialized
INFO - 2017-09-11 10:25:40 --> Controller Class Initialized
INFO - 2017-09-11 10:25:40 --> Helper loaded: form_helper
INFO - 2017-09-11 10:25:40 --> Form Validation Class Initialized
INFO - 2017-09-11 10:25:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:25:40 --> Helper loaded: url_helper
INFO - 2017-09-11 10:25:40 --> Model Class Initialized
INFO - 2017-09-11 10:25:40 --> Model Class Initialized
INFO - 2017-09-11 13:55:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:55:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:55:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:55:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:55:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:55:40 --> Final output sent to browser
DEBUG - 2017-09-11 13:55:40 --> Total execution time: 0.0475
INFO - 2017-09-11 10:25:47 --> Config Class Initialized
INFO - 2017-09-11 10:25:47 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:25:47 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:25:47 --> Utf8 Class Initialized
INFO - 2017-09-11 10:25:47 --> URI Class Initialized
INFO - 2017-09-11 10:25:47 --> Router Class Initialized
INFO - 2017-09-11 10:25:47 --> Output Class Initialized
INFO - 2017-09-11 10:25:47 --> Security Class Initialized
DEBUG - 2017-09-11 10:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:25:47 --> Input Class Initialized
INFO - 2017-09-11 10:25:47 --> Language Class Initialized
INFO - 2017-09-11 10:25:47 --> Loader Class Initialized
INFO - 2017-09-11 10:25:47 --> Helper loaded: common_helper
INFO - 2017-09-11 10:25:47 --> Database Driver Class Initialized
INFO - 2017-09-11 10:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:25:47 --> Email Class Initialized
INFO - 2017-09-11 10:25:47 --> Controller Class Initialized
INFO - 2017-09-11 10:25:47 --> Helper loaded: form_helper
INFO - 2017-09-11 10:25:47 --> Form Validation Class Initialized
INFO - 2017-09-11 10:25:47 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:25:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:25:47 --> Helper loaded: url_helper
INFO - 2017-09-11 10:25:47 --> Model Class Initialized
INFO - 2017-09-11 10:25:47 --> Model Class Initialized
DEBUG - 2017-09-11 13:55:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:55:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:55:47 --> Query error: Unknown column 'offset' in 'field list' - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE `idName` != 'id'
ERROR - 2017-09-11 13:55:47 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:55:47 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:26:26 --> Config Class Initialized
INFO - 2017-09-11 10:26:26 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:26:26 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:26:26 --> Utf8 Class Initialized
INFO - 2017-09-11 10:26:26 --> URI Class Initialized
INFO - 2017-09-11 10:26:26 --> Router Class Initialized
INFO - 2017-09-11 10:26:26 --> Output Class Initialized
INFO - 2017-09-11 10:26:26 --> Security Class Initialized
DEBUG - 2017-09-11 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:26:26 --> Input Class Initialized
INFO - 2017-09-11 10:26:26 --> Language Class Initialized
INFO - 2017-09-11 10:26:26 --> Loader Class Initialized
INFO - 2017-09-11 10:26:26 --> Helper loaded: common_helper
INFO - 2017-09-11 10:26:26 --> Database Driver Class Initialized
INFO - 2017-09-11 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:26:26 --> Email Class Initialized
INFO - 2017-09-11 10:26:26 --> Controller Class Initialized
INFO - 2017-09-11 10:26:26 --> Helper loaded: form_helper
INFO - 2017-09-11 10:26:26 --> Form Validation Class Initialized
INFO - 2017-09-11 10:26:26 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:26:26 --> Helper loaded: url_helper
INFO - 2017-09-11 10:26:26 --> Model Class Initialized
INFO - 2017-09-11 10:26:26 --> Model Class Initialized
DEBUG - 2017-09-11 13:56:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:56:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:56:26 --> Query error: Unknown column 'offset' in 'field list' - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE `idName` != 'id'
ERROR - 2017-09-11 13:56:26 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:56:26 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:27:11 --> Config Class Initialized
INFO - 2017-09-11 10:27:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:27:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:27:11 --> Utf8 Class Initialized
INFO - 2017-09-11 10:27:11 --> URI Class Initialized
INFO - 2017-09-11 10:27:11 --> Router Class Initialized
INFO - 2017-09-11 10:27:11 --> Output Class Initialized
INFO - 2017-09-11 10:27:11 --> Security Class Initialized
DEBUG - 2017-09-11 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:27:11 --> Input Class Initialized
INFO - 2017-09-11 10:27:11 --> Language Class Initialized
INFO - 2017-09-11 10:27:11 --> Loader Class Initialized
INFO - 2017-09-11 10:27:11 --> Helper loaded: common_helper
INFO - 2017-09-11 10:27:11 --> Database Driver Class Initialized
INFO - 2017-09-11 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:27:11 --> Email Class Initialized
INFO - 2017-09-11 10:27:11 --> Controller Class Initialized
INFO - 2017-09-11 10:27:11 --> Helper loaded: form_helper
INFO - 2017-09-11 10:27:11 --> Form Validation Class Initialized
INFO - 2017-09-11 10:27:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:27:11 --> Helper loaded: url_helper
INFO - 2017-09-11 10:27:11 --> Model Class Initialized
INFO - 2017-09-11 10:27:11 --> Model Class Initialized
DEBUG - 2017-09-11 13:57:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:57:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:57:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
ERROR - 2017-09-11 13:57:11 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:57:11 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:27:11 --> Config Class Initialized
INFO - 2017-09-11 10:27:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:27:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:27:12 --> Utf8 Class Initialized
INFO - 2017-09-11 10:27:12 --> URI Class Initialized
INFO - 2017-09-11 10:27:12 --> Router Class Initialized
INFO - 2017-09-11 10:27:12 --> Output Class Initialized
INFO - 2017-09-11 10:27:12 --> Security Class Initialized
DEBUG - 2017-09-11 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:27:12 --> Input Class Initialized
INFO - 2017-09-11 10:27:12 --> Language Class Initialized
INFO - 2017-09-11 10:27:12 --> Loader Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: common_helper
INFO - 2017-09-11 10:27:12 --> Database Driver Class Initialized
INFO - 2017-09-11 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:27:12 --> Email Class Initialized
INFO - 2017-09-11 10:27:12 --> Controller Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: form_helper
INFO - 2017-09-11 10:27:12 --> Form Validation Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:27:12 --> Helper loaded: url_helper
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
DEBUG - 2017-09-11 13:57:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:57:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
ERROR - 2017-09-11 13:57:12 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:57:12 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:27:12 --> Config Class Initialized
INFO - 2017-09-11 10:27:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:27:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:27:12 --> Utf8 Class Initialized
INFO - 2017-09-11 10:27:12 --> URI Class Initialized
INFO - 2017-09-11 10:27:12 --> Router Class Initialized
INFO - 2017-09-11 10:27:12 --> Output Class Initialized
INFO - 2017-09-11 10:27:12 --> Security Class Initialized
DEBUG - 2017-09-11 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:27:12 --> Input Class Initialized
INFO - 2017-09-11 10:27:12 --> Language Class Initialized
INFO - 2017-09-11 10:27:12 --> Loader Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: common_helper
INFO - 2017-09-11 10:27:12 --> Database Driver Class Initialized
INFO - 2017-09-11 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:27:12 --> Email Class Initialized
INFO - 2017-09-11 10:27:12 --> Controller Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: form_helper
INFO - 2017-09-11 10:27:12 --> Form Validation Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:27:12 --> Helper loaded: url_helper
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
DEBUG - 2017-09-11 13:57:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:57:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
ERROR - 2017-09-11 13:57:12 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:57:12 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:27:12 --> Config Class Initialized
INFO - 2017-09-11 10:27:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:27:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:27:12 --> Utf8 Class Initialized
INFO - 2017-09-11 10:27:12 --> URI Class Initialized
INFO - 2017-09-11 10:27:12 --> Router Class Initialized
INFO - 2017-09-11 10:27:12 --> Output Class Initialized
INFO - 2017-09-11 10:27:12 --> Security Class Initialized
DEBUG - 2017-09-11 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:27:12 --> Input Class Initialized
INFO - 2017-09-11 10:27:12 --> Language Class Initialized
INFO - 2017-09-11 10:27:12 --> Loader Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: common_helper
INFO - 2017-09-11 10:27:12 --> Database Driver Class Initialized
INFO - 2017-09-11 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:27:12 --> Email Class Initialized
INFO - 2017-09-11 10:27:12 --> Controller Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: form_helper
INFO - 2017-09-11 10:27:12 --> Form Validation Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:27:12 --> Helper loaded: url_helper
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
DEBUG - 2017-09-11 13:57:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:57:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
ERROR - 2017-09-11 13:57:12 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:57:12 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:27:12 --> Config Class Initialized
INFO - 2017-09-11 10:27:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:27:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:27:12 --> Utf8 Class Initialized
INFO - 2017-09-11 10:27:12 --> URI Class Initialized
INFO - 2017-09-11 10:27:12 --> Router Class Initialized
INFO - 2017-09-11 10:27:12 --> Output Class Initialized
INFO - 2017-09-11 10:27:12 --> Security Class Initialized
DEBUG - 2017-09-11 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:27:12 --> Input Class Initialized
INFO - 2017-09-11 10:27:12 --> Language Class Initialized
INFO - 2017-09-11 10:27:12 --> Loader Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: common_helper
INFO - 2017-09-11 10:27:12 --> Database Driver Class Initialized
INFO - 2017-09-11 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:27:12 --> Email Class Initialized
INFO - 2017-09-11 10:27:12 --> Controller Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: form_helper
INFO - 2017-09-11 10:27:12 --> Form Validation Class Initialized
INFO - 2017-09-11 10:27:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:27:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:27:12 --> Helper loaded: url_helper
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
INFO - 2017-09-11 10:27:12 --> Model Class Initialized
DEBUG - 2017-09-11 13:57:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:57:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:57:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
ERROR - 2017-09-11 13:57:12 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:57:12 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 117
INFO - 2017-09-11 10:27:30 --> Config Class Initialized
INFO - 2017-09-11 10:27:30 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:27:30 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:27:30 --> Utf8 Class Initialized
INFO - 2017-09-11 10:27:30 --> URI Class Initialized
INFO - 2017-09-11 10:27:30 --> Router Class Initialized
INFO - 2017-09-11 10:27:30 --> Output Class Initialized
INFO - 2017-09-11 10:27:30 --> Security Class Initialized
DEBUG - 2017-09-11 10:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:27:30 --> Input Class Initialized
INFO - 2017-09-11 10:27:30 --> Language Class Initialized
INFO - 2017-09-11 10:27:30 --> Loader Class Initialized
INFO - 2017-09-11 10:27:30 --> Helper loaded: common_helper
INFO - 2017-09-11 10:27:30 --> Database Driver Class Initialized
INFO - 2017-09-11 10:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:27:30 --> Email Class Initialized
INFO - 2017-09-11 10:27:30 --> Controller Class Initialized
INFO - 2017-09-11 10:27:30 --> Helper loaded: form_helper
INFO - 2017-09-11 10:27:30 --> Form Validation Class Initialized
INFO - 2017-09-11 10:27:30 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:27:30 --> Helper loaded: url_helper
INFO - 2017-09-11 10:27:30 --> Model Class Initialized
INFO - 2017-09-11 10:27:30 --> Model Class Initialized
DEBUG - 2017-09-11 13:57:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:57:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:57:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
INFO - 2017-09-11 10:28:12 --> Config Class Initialized
INFO - 2017-09-11 10:28:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:28:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:28:12 --> Utf8 Class Initialized
INFO - 2017-09-11 10:28:12 --> URI Class Initialized
INFO - 2017-09-11 10:28:12 --> Router Class Initialized
INFO - 2017-09-11 10:28:12 --> Output Class Initialized
INFO - 2017-09-11 10:28:12 --> Security Class Initialized
DEBUG - 2017-09-11 10:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:28:12 --> Input Class Initialized
INFO - 2017-09-11 10:28:12 --> Language Class Initialized
INFO - 2017-09-11 10:28:12 --> Loader Class Initialized
INFO - 2017-09-11 10:28:12 --> Helper loaded: common_helper
INFO - 2017-09-11 10:28:12 --> Database Driver Class Initialized
INFO - 2017-09-11 10:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:28:12 --> Email Class Initialized
INFO - 2017-09-11 10:28:12 --> Controller Class Initialized
INFO - 2017-09-11 10:28:12 --> Helper loaded: form_helper
INFO - 2017-09-11 10:28:12 --> Form Validation Class Initialized
INFO - 2017-09-11 10:28:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:28:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:28:12 --> Helper loaded: url_helper
INFO - 2017-09-11 10:28:12 --> Model Class Initialized
INFO - 2017-09-11 10:28:12 --> Model Class Initialized
DEBUG - 2017-09-11 13:58:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:58:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:58:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
INFO - 2017-09-11 10:28:20 --> Config Class Initialized
INFO - 2017-09-11 10:28:20 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:28:20 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:28:20 --> Utf8 Class Initialized
INFO - 2017-09-11 10:28:20 --> URI Class Initialized
INFO - 2017-09-11 10:28:20 --> Router Class Initialized
INFO - 2017-09-11 10:28:20 --> Output Class Initialized
INFO - 2017-09-11 10:28:20 --> Security Class Initialized
DEBUG - 2017-09-11 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:28:20 --> Input Class Initialized
INFO - 2017-09-11 10:28:20 --> Language Class Initialized
INFO - 2017-09-11 10:28:20 --> Loader Class Initialized
INFO - 2017-09-11 10:28:20 --> Helper loaded: common_helper
INFO - 2017-09-11 10:28:20 --> Database Driver Class Initialized
INFO - 2017-09-11 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:28:20 --> Email Class Initialized
INFO - 2017-09-11 10:28:20 --> Controller Class Initialized
INFO - 2017-09-11 10:28:20 --> Helper loaded: form_helper
INFO - 2017-09-11 10:28:20 --> Form Validation Class Initialized
INFO - 2017-09-11 10:28:20 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:28:20 --> Helper loaded: url_helper
INFO - 2017-09-11 10:28:20 --> Model Class Initialized
INFO - 2017-09-11 10:28:20 --> Model Class Initialized
DEBUG - 2017-09-11 13:58:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:58:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-11 13:58:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '* != 'id'' at line 3 - Invalid query: SELECT `offset`, 1
FROM `settings`
WHERE * != 'id'
ERROR - 2017-09-11 13:58:20 --> Call to a member function row() on a non-object
ERROR - 2017-09-11 13:58:20 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 119
INFO - 2017-09-11 10:28:56 --> Config Class Initialized
INFO - 2017-09-11 10:28:56 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:28:56 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:28:56 --> Utf8 Class Initialized
INFO - 2017-09-11 10:28:56 --> URI Class Initialized
INFO - 2017-09-11 10:28:56 --> Router Class Initialized
INFO - 2017-09-11 10:28:56 --> Output Class Initialized
INFO - 2017-09-11 10:28:56 --> Security Class Initialized
DEBUG - 2017-09-11 10:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:28:56 --> Input Class Initialized
INFO - 2017-09-11 10:28:56 --> Language Class Initialized
INFO - 2017-09-11 10:28:56 --> Loader Class Initialized
INFO - 2017-09-11 10:28:56 --> Helper loaded: common_helper
INFO - 2017-09-11 10:28:56 --> Database Driver Class Initialized
INFO - 2017-09-11 10:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:28:56 --> Email Class Initialized
INFO - 2017-09-11 10:28:56 --> Controller Class Initialized
INFO - 2017-09-11 10:28:56 --> Helper loaded: form_helper
INFO - 2017-09-11 10:28:56 --> Form Validation Class Initialized
INFO - 2017-09-11 10:28:56 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:28:56 --> Helper loaded: url_helper
INFO - 2017-09-11 10:28:56 --> Model Class Initialized
INFO - 2017-09-11 10:28:56 --> Model Class Initialized
DEBUG - 2017-09-11 13:58:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:58:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:29:20 --> Config Class Initialized
INFO - 2017-09-11 10:29:20 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:20 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:20 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:20 --> URI Class Initialized
INFO - 2017-09-11 10:29:20 --> Router Class Initialized
INFO - 2017-09-11 10:29:20 --> Output Class Initialized
INFO - 2017-09-11 10:29:20 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:20 --> Input Class Initialized
INFO - 2017-09-11 10:29:20 --> Language Class Initialized
INFO - 2017-09-11 10:29:20 --> Loader Class Initialized
INFO - 2017-09-11 10:29:20 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:20 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:20 --> Email Class Initialized
INFO - 2017-09-11 10:29:20 --> Controller Class Initialized
INFO - 2017-09-11 10:29:20 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:20 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:20 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:20 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:20 --> Model Class Initialized
INFO - 2017-09-11 10:29:20 --> Model Class Initialized
DEBUG - 2017-09-11 13:59:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:59:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:29:29 --> Config Class Initialized
INFO - 2017-09-11 10:29:29 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:29 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:29 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:29 --> URI Class Initialized
INFO - 2017-09-11 10:29:29 --> Router Class Initialized
INFO - 2017-09-11 10:29:29 --> Output Class Initialized
INFO - 2017-09-11 10:29:29 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:29 --> Input Class Initialized
INFO - 2017-09-11 10:29:29 --> Language Class Initialized
INFO - 2017-09-11 10:29:29 --> Loader Class Initialized
INFO - 2017-09-11 10:29:29 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:29 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:29 --> Email Class Initialized
INFO - 2017-09-11 10:29:29 --> Controller Class Initialized
INFO - 2017-09-11 10:29:29 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:29 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:29 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:29 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:29 --> Model Class Initialized
INFO - 2017-09-11 10:29:29 --> Model Class Initialized
DEBUG - 2017-09-11 13:59:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:59:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:29:30 --> Config Class Initialized
INFO - 2017-09-11 10:29:30 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:30 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:30 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:30 --> URI Class Initialized
INFO - 2017-09-11 10:29:30 --> Router Class Initialized
INFO - 2017-09-11 10:29:30 --> Output Class Initialized
INFO - 2017-09-11 10:29:30 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:30 --> Input Class Initialized
INFO - 2017-09-11 10:29:30 --> Language Class Initialized
INFO - 2017-09-11 10:29:30 --> Loader Class Initialized
INFO - 2017-09-11 10:29:30 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:30 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:30 --> Email Class Initialized
INFO - 2017-09-11 10:29:30 --> Controller Class Initialized
INFO - 2017-09-11 10:29:30 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:30 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:30 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:30 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:30 --> Model Class Initialized
INFO - 2017-09-11 10:29:30 --> Model Class Initialized
INFO - 2017-09-11 13:59:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:59:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:59:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:59:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:59:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:59:30 --> Final output sent to browser
DEBUG - 2017-09-11 13:59:30 --> Total execution time: 0.0635
INFO - 2017-09-11 10:29:32 --> Config Class Initialized
INFO - 2017-09-11 10:29:32 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:32 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:32 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:32 --> URI Class Initialized
INFO - 2017-09-11 10:29:32 --> Router Class Initialized
INFO - 2017-09-11 10:29:32 --> Output Class Initialized
INFO - 2017-09-11 10:29:32 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:32 --> Input Class Initialized
INFO - 2017-09-11 10:29:32 --> Language Class Initialized
INFO - 2017-09-11 10:29:32 --> Loader Class Initialized
INFO - 2017-09-11 10:29:32 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:32 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:32 --> Email Class Initialized
INFO - 2017-09-11 10:29:32 --> Controller Class Initialized
INFO - 2017-09-11 10:29:32 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:32 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:32 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:32 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:32 --> Model Class Initialized
INFO - 2017-09-11 10:29:32 --> Model Class Initialized
INFO - 2017-09-11 13:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:59:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:59:32 --> Final output sent to browser
DEBUG - 2017-09-11 13:59:32 --> Total execution time: 0.0487
INFO - 2017-09-11 10:29:37 --> Config Class Initialized
INFO - 2017-09-11 10:29:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:37 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:37 --> URI Class Initialized
INFO - 2017-09-11 10:29:37 --> Router Class Initialized
INFO - 2017-09-11 10:29:37 --> Output Class Initialized
INFO - 2017-09-11 10:29:37 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:37 --> Input Class Initialized
INFO - 2017-09-11 10:29:37 --> Language Class Initialized
INFO - 2017-09-11 10:29:37 --> Loader Class Initialized
INFO - 2017-09-11 10:29:37 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:37 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:37 --> Email Class Initialized
INFO - 2017-09-11 10:29:37 --> Controller Class Initialized
INFO - 2017-09-11 10:29:37 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:37 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:37 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:37 --> Model Class Initialized
INFO - 2017-09-11 10:29:37 --> Model Class Initialized
DEBUG - 2017-09-11 13:59:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:59:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:29:37 --> Config Class Initialized
INFO - 2017-09-11 10:29:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:37 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:37 --> URI Class Initialized
INFO - 2017-09-11 10:29:37 --> Router Class Initialized
INFO - 2017-09-11 10:29:37 --> Output Class Initialized
INFO - 2017-09-11 10:29:37 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:37 --> Input Class Initialized
INFO - 2017-09-11 10:29:37 --> Language Class Initialized
INFO - 2017-09-11 10:29:37 --> Loader Class Initialized
INFO - 2017-09-11 10:29:37 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:37 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:37 --> Email Class Initialized
INFO - 2017-09-11 10:29:37 --> Controller Class Initialized
INFO - 2017-09-11 10:29:37 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:37 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:37 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:37 --> Model Class Initialized
INFO - 2017-09-11 10:29:37 --> Model Class Initialized
INFO - 2017-09-11 13:59:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:59:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:59:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:59:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 13:59:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:59:37 --> Final output sent to browser
DEBUG - 2017-09-11 13:59:37 --> Total execution time: 0.0551
INFO - 2017-09-11 10:29:40 --> Config Class Initialized
INFO - 2017-09-11 10:29:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:40 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:40 --> URI Class Initialized
INFO - 2017-09-11 10:29:40 --> Router Class Initialized
INFO - 2017-09-11 10:29:40 --> Output Class Initialized
INFO - 2017-09-11 10:29:40 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:40 --> Input Class Initialized
INFO - 2017-09-11 10:29:40 --> Language Class Initialized
INFO - 2017-09-11 10:29:40 --> Loader Class Initialized
INFO - 2017-09-11 10:29:40 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:40 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:40 --> Email Class Initialized
INFO - 2017-09-11 10:29:40 --> Controller Class Initialized
INFO - 2017-09-11 10:29:40 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:40 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:40 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:40 --> Model Class Initialized
INFO - 2017-09-11 10:29:40 --> Model Class Initialized
INFO - 2017-09-11 13:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 13:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:59:40 --> Final output sent to browser
DEBUG - 2017-09-11 13:59:40 --> Total execution time: 0.0450
INFO - 2017-09-11 10:29:42 --> Config Class Initialized
INFO - 2017-09-11 10:29:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:42 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:42 --> URI Class Initialized
INFO - 2017-09-11 10:29:42 --> Router Class Initialized
INFO - 2017-09-11 10:29:42 --> Output Class Initialized
INFO - 2017-09-11 10:29:42 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:42 --> Input Class Initialized
INFO - 2017-09-11 10:29:42 --> Language Class Initialized
INFO - 2017-09-11 10:29:42 --> Loader Class Initialized
INFO - 2017-09-11 10:29:42 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:42 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:42 --> Email Class Initialized
INFO - 2017-09-11 10:29:42 --> Controller Class Initialized
INFO - 2017-09-11 10:29:42 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:42 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:42 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:42 --> Model Class Initialized
INFO - 2017-09-11 10:29:42 --> Model Class Initialized
DEBUG - 2017-09-11 13:59:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:59:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:29:42 --> Config Class Initialized
INFO - 2017-09-11 10:29:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:29:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:29:42 --> Utf8 Class Initialized
INFO - 2017-09-11 10:29:42 --> URI Class Initialized
INFO - 2017-09-11 10:29:42 --> Router Class Initialized
INFO - 2017-09-11 10:29:42 --> Output Class Initialized
INFO - 2017-09-11 10:29:42 --> Security Class Initialized
DEBUG - 2017-09-11 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:29:42 --> Input Class Initialized
INFO - 2017-09-11 10:29:42 --> Language Class Initialized
INFO - 2017-09-11 10:29:42 --> Loader Class Initialized
INFO - 2017-09-11 10:29:42 --> Helper loaded: common_helper
INFO - 2017-09-11 10:29:42 --> Database Driver Class Initialized
INFO - 2017-09-11 10:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:29:42 --> Email Class Initialized
INFO - 2017-09-11 10:29:42 --> Controller Class Initialized
INFO - 2017-09-11 10:29:42 --> Helper loaded: form_helper
INFO - 2017-09-11 10:29:42 --> Form Validation Class Initialized
INFO - 2017-09-11 10:29:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:29:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:29:42 --> Helper loaded: url_helper
INFO - 2017-09-11 10:29:42 --> Model Class Initialized
INFO - 2017-09-11 10:29:42 --> Model Class Initialized
INFO - 2017-09-11 13:59:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 13:59:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 13:59:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addChats.php
INFO - 2017-09-11 13:59:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 13:59:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 13:59:42 --> Final output sent to browser
DEBUG - 2017-09-11 13:59:42 --> Total execution time: 0.0895
INFO - 2017-09-11 10:30:05 --> Config Class Initialized
INFO - 2017-09-11 10:30:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:05 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:05 --> URI Class Initialized
INFO - 2017-09-11 10:30:05 --> Router Class Initialized
INFO - 2017-09-11 10:30:05 --> Output Class Initialized
INFO - 2017-09-11 10:30:05 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:05 --> Input Class Initialized
INFO - 2017-09-11 10:30:05 --> Language Class Initialized
INFO - 2017-09-11 10:30:05 --> Loader Class Initialized
INFO - 2017-09-11 10:30:05 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:05 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:05 --> Email Class Initialized
INFO - 2017-09-11 10:30:05 --> Controller Class Initialized
INFO - 2017-09-11 10:30:05 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:05 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:05 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:05 --> Model Class Initialized
INFO - 2017-09-11 10:30:05 --> Model Class Initialized
INFO - 2017-09-11 14:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:00:05 --> Final output sent to browser
DEBUG - 2017-09-11 14:00:05 --> Total execution time: 0.0462
INFO - 2017-09-11 10:30:07 --> Config Class Initialized
INFO - 2017-09-11 10:30:07 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:07 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:07 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:07 --> URI Class Initialized
INFO - 2017-09-11 10:30:07 --> Router Class Initialized
INFO - 2017-09-11 10:30:07 --> Output Class Initialized
INFO - 2017-09-11 10:30:07 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:07 --> Input Class Initialized
INFO - 2017-09-11 10:30:07 --> Language Class Initialized
INFO - 2017-09-11 10:30:07 --> Loader Class Initialized
INFO - 2017-09-11 10:30:07 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:07 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:07 --> Email Class Initialized
INFO - 2017-09-11 10:30:07 --> Controller Class Initialized
INFO - 2017-09-11 10:30:07 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:07 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:07 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:07 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:07 --> Model Class Initialized
INFO - 2017-09-11 10:30:07 --> Model Class Initialized
DEBUG - 2017-09-11 14:00:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:00:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:30:07 --> Config Class Initialized
INFO - 2017-09-11 10:30:07 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:07 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:07 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:07 --> URI Class Initialized
INFO - 2017-09-11 10:30:07 --> Router Class Initialized
INFO - 2017-09-11 10:30:07 --> Output Class Initialized
INFO - 2017-09-11 10:30:07 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:07 --> Input Class Initialized
INFO - 2017-09-11 10:30:07 --> Language Class Initialized
INFO - 2017-09-11 10:30:07 --> Loader Class Initialized
INFO - 2017-09-11 10:30:07 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:07 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:07 --> Email Class Initialized
INFO - 2017-09-11 10:30:07 --> Controller Class Initialized
INFO - 2017-09-11 10:30:07 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:07 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:07 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:07 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:07 --> Model Class Initialized
INFO - 2017-09-11 10:30:07 --> Model Class Initialized
INFO - 2017-09-11 14:00:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:00:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:00:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:00:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:00:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:00:07 --> Final output sent to browser
DEBUG - 2017-09-11 14:00:07 --> Total execution time: 0.0494
INFO - 2017-09-11 10:30:09 --> Config Class Initialized
INFO - 2017-09-11 10:30:09 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:09 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:09 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:09 --> URI Class Initialized
INFO - 2017-09-11 10:30:09 --> Router Class Initialized
INFO - 2017-09-11 10:30:09 --> Output Class Initialized
INFO - 2017-09-11 10:30:09 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:09 --> Input Class Initialized
INFO - 2017-09-11 10:30:09 --> Language Class Initialized
INFO - 2017-09-11 10:30:09 --> Loader Class Initialized
INFO - 2017-09-11 10:30:09 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:09 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:09 --> Email Class Initialized
INFO - 2017-09-11 10:30:09 --> Controller Class Initialized
INFO - 2017-09-11 10:30:09 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:09 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:09 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:09 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:09 --> Model Class Initialized
INFO - 2017-09-11 10:30:09 --> Model Class Initialized
DEBUG - 2017-09-11 14:00:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:00:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:30:09 --> Config Class Initialized
INFO - 2017-09-11 10:30:09 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:09 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:09 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:09 --> URI Class Initialized
INFO - 2017-09-11 10:30:09 --> Router Class Initialized
INFO - 2017-09-11 10:30:09 --> Output Class Initialized
INFO - 2017-09-11 10:30:09 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:09 --> Input Class Initialized
INFO - 2017-09-11 10:30:09 --> Language Class Initialized
INFO - 2017-09-11 10:30:09 --> Loader Class Initialized
INFO - 2017-09-11 10:30:09 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:09 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:09 --> Email Class Initialized
INFO - 2017-09-11 10:30:09 --> Controller Class Initialized
INFO - 2017-09-11 10:30:09 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:09 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:09 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:09 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:09 --> Model Class Initialized
INFO - 2017-09-11 10:30:09 --> Model Class Initialized
INFO - 2017-09-11 14:00:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:00:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:00:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:00:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:00:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:00:09 --> Final output sent to browser
DEBUG - 2017-09-11 14:00:10 --> Total execution time: 0.0542
INFO - 2017-09-11 10:30:13 --> Config Class Initialized
INFO - 2017-09-11 10:30:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:13 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:13 --> URI Class Initialized
INFO - 2017-09-11 10:30:13 --> Router Class Initialized
INFO - 2017-09-11 10:30:13 --> Output Class Initialized
INFO - 2017-09-11 10:30:13 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:13 --> Input Class Initialized
INFO - 2017-09-11 10:30:13 --> Language Class Initialized
INFO - 2017-09-11 10:30:13 --> Loader Class Initialized
INFO - 2017-09-11 10:30:13 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:13 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:13 --> Email Class Initialized
INFO - 2017-09-11 10:30:13 --> Controller Class Initialized
INFO - 2017-09-11 10:30:13 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:13 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:13 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:13 --> Model Class Initialized
INFO - 2017-09-11 10:30:13 --> Model Class Initialized
DEBUG - 2017-09-11 14:00:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:00:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:30:13 --> Config Class Initialized
INFO - 2017-09-11 10:30:13 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:13 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:13 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:13 --> URI Class Initialized
INFO - 2017-09-11 10:30:13 --> Router Class Initialized
INFO - 2017-09-11 10:30:13 --> Output Class Initialized
INFO - 2017-09-11 10:30:13 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:13 --> Input Class Initialized
INFO - 2017-09-11 10:30:13 --> Language Class Initialized
INFO - 2017-09-11 10:30:13 --> Loader Class Initialized
INFO - 2017-09-11 10:30:13 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:13 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:13 --> Email Class Initialized
INFO - 2017-09-11 10:30:13 --> Controller Class Initialized
INFO - 2017-09-11 10:30:13 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:13 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:13 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:13 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:13 --> Model Class Initialized
INFO - 2017-09-11 10:30:13 --> Model Class Initialized
INFO - 2017-09-11 14:00:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:00:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:00:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:00:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:00:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:00:13 --> Final output sent to browser
DEBUG - 2017-09-11 14:00:13 --> Total execution time: 0.0499
INFO - 2017-09-11 10:30:16 --> Config Class Initialized
INFO - 2017-09-11 10:30:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:30:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:30:16 --> Utf8 Class Initialized
INFO - 2017-09-11 10:30:16 --> URI Class Initialized
INFO - 2017-09-11 10:30:16 --> Router Class Initialized
INFO - 2017-09-11 10:30:16 --> Output Class Initialized
INFO - 2017-09-11 10:30:16 --> Security Class Initialized
DEBUG - 2017-09-11 10:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:30:16 --> Input Class Initialized
INFO - 2017-09-11 10:30:16 --> Language Class Initialized
INFO - 2017-09-11 10:30:16 --> Loader Class Initialized
INFO - 2017-09-11 10:30:16 --> Helper loaded: common_helper
INFO - 2017-09-11 10:30:16 --> Database Driver Class Initialized
INFO - 2017-09-11 10:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:30:16 --> Email Class Initialized
INFO - 2017-09-11 10:30:16 --> Controller Class Initialized
INFO - 2017-09-11 10:30:16 --> Helper loaded: form_helper
INFO - 2017-09-11 10:30:16 --> Form Validation Class Initialized
INFO - 2017-09-11 10:30:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:30:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:30:16 --> Helper loaded: url_helper
INFO - 2017-09-11 10:30:16 --> Model Class Initialized
INFO - 2017-09-11 10:30:16 --> Model Class Initialized
INFO - 2017-09-11 14:00:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:00:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:00:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:00:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:00:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:00:16 --> Final output sent to browser
DEBUG - 2017-09-11 14:00:16 --> Total execution time: 0.0458
INFO - 2017-09-11 10:32:02 --> Config Class Initialized
INFO - 2017-09-11 10:32:02 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:32:02 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:32:02 --> Utf8 Class Initialized
INFO - 2017-09-11 10:32:02 --> URI Class Initialized
INFO - 2017-09-11 10:32:02 --> Router Class Initialized
INFO - 2017-09-11 10:32:02 --> Output Class Initialized
INFO - 2017-09-11 10:32:02 --> Security Class Initialized
DEBUG - 2017-09-11 10:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:32:02 --> Input Class Initialized
INFO - 2017-09-11 10:32:02 --> Language Class Initialized
INFO - 2017-09-11 10:32:02 --> Loader Class Initialized
INFO - 2017-09-11 10:32:02 --> Helper loaded: common_helper
INFO - 2017-09-11 10:32:02 --> Database Driver Class Initialized
INFO - 2017-09-11 10:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:32:02 --> Email Class Initialized
INFO - 2017-09-11 10:32:02 --> Controller Class Initialized
INFO - 2017-09-11 10:32:02 --> Helper loaded: form_helper
INFO - 2017-09-11 10:32:02 --> Form Validation Class Initialized
INFO - 2017-09-11 10:32:02 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:32:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:32:02 --> Helper loaded: url_helper
INFO - 2017-09-11 10:32:02 --> Model Class Initialized
INFO - 2017-09-11 10:32:02 --> Model Class Initialized
INFO - 2017-09-11 14:02:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:02:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:02:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:02:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:02:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:02:02 --> Final output sent to browser
DEBUG - 2017-09-11 14:02:02 --> Total execution time: 0.0479
INFO - 2017-09-11 10:32:04 --> Config Class Initialized
INFO - 2017-09-11 10:32:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:32:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:32:04 --> Utf8 Class Initialized
INFO - 2017-09-11 10:32:04 --> URI Class Initialized
INFO - 2017-09-11 10:32:04 --> Router Class Initialized
INFO - 2017-09-11 10:32:04 --> Output Class Initialized
INFO - 2017-09-11 10:32:04 --> Security Class Initialized
DEBUG - 2017-09-11 10:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:32:04 --> Input Class Initialized
INFO - 2017-09-11 10:32:04 --> Language Class Initialized
INFO - 2017-09-11 10:32:04 --> Loader Class Initialized
INFO - 2017-09-11 10:32:04 --> Helper loaded: common_helper
INFO - 2017-09-11 10:32:04 --> Database Driver Class Initialized
INFO - 2017-09-11 10:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:32:04 --> Email Class Initialized
INFO - 2017-09-11 10:32:04 --> Controller Class Initialized
INFO - 2017-09-11 10:32:04 --> Helper loaded: form_helper
INFO - 2017-09-11 10:32:04 --> Form Validation Class Initialized
INFO - 2017-09-11 10:32:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:32:04 --> Helper loaded: url_helper
INFO - 2017-09-11 10:32:04 --> Model Class Initialized
INFO - 2017-09-11 10:32:04 --> Model Class Initialized
DEBUG - 2017-09-11 14:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:02:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:33:52 --> Config Class Initialized
INFO - 2017-09-11 10:33:52 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:33:52 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:33:52 --> Utf8 Class Initialized
INFO - 2017-09-11 10:33:52 --> URI Class Initialized
INFO - 2017-09-11 10:33:52 --> Router Class Initialized
INFO - 2017-09-11 10:33:52 --> Output Class Initialized
INFO - 2017-09-11 10:33:52 --> Security Class Initialized
DEBUG - 2017-09-11 10:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:33:52 --> Input Class Initialized
INFO - 2017-09-11 10:33:52 --> Language Class Initialized
INFO - 2017-09-11 10:33:52 --> Loader Class Initialized
INFO - 2017-09-11 10:33:52 --> Helper loaded: common_helper
INFO - 2017-09-11 10:33:52 --> Database Driver Class Initialized
INFO - 2017-09-11 10:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:33:52 --> Email Class Initialized
INFO - 2017-09-11 10:33:52 --> Controller Class Initialized
INFO - 2017-09-11 10:33:52 --> Helper loaded: form_helper
INFO - 2017-09-11 10:33:52 --> Form Validation Class Initialized
INFO - 2017-09-11 10:33:52 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:33:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:33:52 --> Helper loaded: url_helper
INFO - 2017-09-11 10:33:52 --> Model Class Initialized
INFO - 2017-09-11 10:33:52 --> Model Class Initialized
DEBUG - 2017-09-11 14:03:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:03:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:01 --> Config Class Initialized
INFO - 2017-09-11 10:34:01 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:01 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:01 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:01 --> URI Class Initialized
INFO - 2017-09-11 10:34:01 --> Router Class Initialized
INFO - 2017-09-11 10:34:01 --> Output Class Initialized
INFO - 2017-09-11 10:34:01 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:01 --> Input Class Initialized
INFO - 2017-09-11 10:34:01 --> Language Class Initialized
INFO - 2017-09-11 10:34:01 --> Loader Class Initialized
INFO - 2017-09-11 10:34:01 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:01 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:01 --> Email Class Initialized
INFO - 2017-09-11 10:34:01 --> Controller Class Initialized
INFO - 2017-09-11 10:34:01 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:01 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:01 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:01 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:01 --> Model Class Initialized
INFO - 2017-09-11 10:34:01 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:01 --> Config Class Initialized
INFO - 2017-09-11 10:34:01 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:01 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:01 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:01 --> URI Class Initialized
INFO - 2017-09-11 10:34:01 --> Router Class Initialized
INFO - 2017-09-11 10:34:01 --> Output Class Initialized
INFO - 2017-09-11 10:34:01 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:01 --> Input Class Initialized
INFO - 2017-09-11 10:34:01 --> Language Class Initialized
INFO - 2017-09-11 10:34:01 --> Loader Class Initialized
INFO - 2017-09-11 10:34:01 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:01 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:01 --> Email Class Initialized
INFO - 2017-09-11 10:34:01 --> Controller Class Initialized
INFO - 2017-09-11 10:34:01 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:01 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:01 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:01 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:01 --> Model Class Initialized
INFO - 2017-09-11 10:34:01 --> Model Class Initialized
INFO - 2017-09-11 14:04:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:01 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:01 --> Total execution time: 0.0720
INFO - 2017-09-11 10:34:03 --> Config Class Initialized
INFO - 2017-09-11 10:34:03 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:03 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:03 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:03 --> URI Class Initialized
INFO - 2017-09-11 10:34:03 --> Router Class Initialized
INFO - 2017-09-11 10:34:03 --> Output Class Initialized
INFO - 2017-09-11 10:34:03 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:03 --> Input Class Initialized
INFO - 2017-09-11 10:34:03 --> Language Class Initialized
INFO - 2017-09-11 10:34:03 --> Loader Class Initialized
INFO - 2017-09-11 10:34:03 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:03 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:03 --> Email Class Initialized
INFO - 2017-09-11 10:34:03 --> Controller Class Initialized
INFO - 2017-09-11 10:34:03 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:03 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:03 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:03 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:03 --> Model Class Initialized
INFO - 2017-09-11 10:34:03 --> Model Class Initialized
INFO - 2017-09-11 14:04:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:03 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:03 --> Total execution time: 0.0479
INFO - 2017-09-11 10:34:05 --> Config Class Initialized
INFO - 2017-09-11 10:34:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:05 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:05 --> URI Class Initialized
INFO - 2017-09-11 10:34:05 --> Router Class Initialized
INFO - 2017-09-11 10:34:05 --> Output Class Initialized
INFO - 2017-09-11 10:34:05 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:05 --> Input Class Initialized
INFO - 2017-09-11 10:34:05 --> Language Class Initialized
INFO - 2017-09-11 10:34:05 --> Loader Class Initialized
INFO - 2017-09-11 10:34:05 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:05 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:05 --> Email Class Initialized
INFO - 2017-09-11 10:34:05 --> Controller Class Initialized
INFO - 2017-09-11 10:34:05 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:05 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:05 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:05 --> Model Class Initialized
INFO - 2017-09-11 10:34:05 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:05 --> Config Class Initialized
INFO - 2017-09-11 10:34:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:05 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:05 --> URI Class Initialized
INFO - 2017-09-11 10:34:05 --> Router Class Initialized
INFO - 2017-09-11 10:34:05 --> Output Class Initialized
INFO - 2017-09-11 10:34:05 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:05 --> Input Class Initialized
INFO - 2017-09-11 10:34:05 --> Language Class Initialized
INFO - 2017-09-11 10:34:05 --> Loader Class Initialized
INFO - 2017-09-11 10:34:05 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:05 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:05 --> Email Class Initialized
INFO - 2017-09-11 10:34:05 --> Controller Class Initialized
INFO - 2017-09-11 10:34:05 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:05 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:05 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:05 --> Model Class Initialized
INFO - 2017-09-11 10:34:05 --> Model Class Initialized
INFO - 2017-09-11 14:04:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:05 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:05 --> Total execution time: 0.0547
INFO - 2017-09-11 10:34:06 --> Config Class Initialized
INFO - 2017-09-11 10:34:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:06 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:06 --> URI Class Initialized
INFO - 2017-09-11 10:34:06 --> Router Class Initialized
INFO - 2017-09-11 10:34:06 --> Output Class Initialized
INFO - 2017-09-11 10:34:06 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:06 --> Input Class Initialized
INFO - 2017-09-11 10:34:06 --> Language Class Initialized
INFO - 2017-09-11 10:34:06 --> Loader Class Initialized
INFO - 2017-09-11 10:34:06 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:06 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:06 --> Email Class Initialized
INFO - 2017-09-11 10:34:06 --> Controller Class Initialized
INFO - 2017-09-11 10:34:06 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:06 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:06 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:06 --> Model Class Initialized
INFO - 2017-09-11 10:34:06 --> Model Class Initialized
INFO - 2017-09-11 14:04:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:06 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:06 --> Total execution time: 0.0476
INFO - 2017-09-11 10:34:11 --> Config Class Initialized
INFO - 2017-09-11 10:34:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:11 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:11 --> URI Class Initialized
INFO - 2017-09-11 10:34:11 --> Router Class Initialized
INFO - 2017-09-11 10:34:11 --> Output Class Initialized
INFO - 2017-09-11 10:34:11 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:11 --> Input Class Initialized
INFO - 2017-09-11 10:34:11 --> Language Class Initialized
INFO - 2017-09-11 10:34:11 --> Loader Class Initialized
INFO - 2017-09-11 10:34:11 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:11 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:11 --> Email Class Initialized
INFO - 2017-09-11 10:34:11 --> Controller Class Initialized
INFO - 2017-09-11 10:34:11 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:11 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:11 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:11 --> Model Class Initialized
INFO - 2017-09-11 10:34:11 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:11 --> Config Class Initialized
INFO - 2017-09-11 10:34:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:11 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:11 --> URI Class Initialized
INFO - 2017-09-11 10:34:11 --> Router Class Initialized
INFO - 2017-09-11 10:34:11 --> Output Class Initialized
INFO - 2017-09-11 10:34:11 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:11 --> Input Class Initialized
INFO - 2017-09-11 10:34:11 --> Language Class Initialized
INFO - 2017-09-11 10:34:11 --> Loader Class Initialized
INFO - 2017-09-11 10:34:11 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:11 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:11 --> Email Class Initialized
INFO - 2017-09-11 10:34:11 --> Controller Class Initialized
INFO - 2017-09-11 10:34:11 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:11 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:11 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:11 --> Model Class Initialized
INFO - 2017-09-11 10:34:11 --> Model Class Initialized
INFO - 2017-09-11 14:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:11 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:11 --> Total execution time: 0.0481
INFO - 2017-09-11 10:34:14 --> Config Class Initialized
INFO - 2017-09-11 10:34:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:14 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:14 --> URI Class Initialized
INFO - 2017-09-11 10:34:14 --> Router Class Initialized
INFO - 2017-09-11 10:34:14 --> Output Class Initialized
INFO - 2017-09-11 10:34:14 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:14 --> Input Class Initialized
INFO - 2017-09-11 10:34:14 --> Language Class Initialized
INFO - 2017-09-11 10:34:14 --> Loader Class Initialized
INFO - 2017-09-11 10:34:14 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:14 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:14 --> Email Class Initialized
INFO - 2017-09-11 10:34:14 --> Controller Class Initialized
INFO - 2017-09-11 10:34:14 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:14 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:14 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:14 --> Model Class Initialized
INFO - 2017-09-11 10:34:14 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:14 --> Config Class Initialized
INFO - 2017-09-11 10:34:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:14 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:14 --> URI Class Initialized
INFO - 2017-09-11 10:34:14 --> Router Class Initialized
INFO - 2017-09-11 10:34:14 --> Output Class Initialized
INFO - 2017-09-11 10:34:14 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:14 --> Input Class Initialized
INFO - 2017-09-11 10:34:14 --> Language Class Initialized
INFO - 2017-09-11 10:34:14 --> Loader Class Initialized
INFO - 2017-09-11 10:34:14 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:14 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:14 --> Email Class Initialized
INFO - 2017-09-11 10:34:14 --> Controller Class Initialized
INFO - 2017-09-11 10:34:14 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:14 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:14 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:14 --> Model Class Initialized
INFO - 2017-09-11 10:34:14 --> Model Class Initialized
INFO - 2017-09-11 14:04:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:14 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:14 --> Total execution time: 0.0560
INFO - 2017-09-11 10:34:16 --> Config Class Initialized
INFO - 2017-09-11 10:34:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:16 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:16 --> URI Class Initialized
INFO - 2017-09-11 10:34:16 --> Router Class Initialized
INFO - 2017-09-11 10:34:16 --> Output Class Initialized
INFO - 2017-09-11 10:34:16 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:16 --> Input Class Initialized
INFO - 2017-09-11 10:34:16 --> Language Class Initialized
INFO - 2017-09-11 10:34:16 --> Loader Class Initialized
INFO - 2017-09-11 10:34:16 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:16 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:16 --> Email Class Initialized
INFO - 2017-09-11 10:34:16 --> Controller Class Initialized
INFO - 2017-09-11 10:34:16 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:16 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:16 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:16 --> Model Class Initialized
INFO - 2017-09-11 10:34:16 --> Model Class Initialized
INFO - 2017-09-11 14:04:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:16 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:16 --> Total execution time: 0.0483
INFO - 2017-09-11 10:34:19 --> Config Class Initialized
INFO - 2017-09-11 10:34:19 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:19 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:19 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:19 --> URI Class Initialized
INFO - 2017-09-11 10:34:19 --> Router Class Initialized
INFO - 2017-09-11 10:34:19 --> Output Class Initialized
INFO - 2017-09-11 10:34:19 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:19 --> Input Class Initialized
INFO - 2017-09-11 10:34:19 --> Language Class Initialized
INFO - 2017-09-11 10:34:19 --> Loader Class Initialized
INFO - 2017-09-11 10:34:19 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:19 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:19 --> Email Class Initialized
INFO - 2017-09-11 10:34:19 --> Controller Class Initialized
INFO - 2017-09-11 10:34:19 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:19 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:19 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:19 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:19 --> Model Class Initialized
INFO - 2017-09-11 10:34:19 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:19 --> Config Class Initialized
INFO - 2017-09-11 10:34:19 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:19 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:19 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:19 --> URI Class Initialized
INFO - 2017-09-11 10:34:19 --> Router Class Initialized
INFO - 2017-09-11 10:34:19 --> Output Class Initialized
INFO - 2017-09-11 10:34:19 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:19 --> Input Class Initialized
INFO - 2017-09-11 10:34:19 --> Language Class Initialized
INFO - 2017-09-11 10:34:19 --> Loader Class Initialized
INFO - 2017-09-11 10:34:19 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:19 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:19 --> Email Class Initialized
INFO - 2017-09-11 10:34:19 --> Controller Class Initialized
INFO - 2017-09-11 10:34:19 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:19 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:19 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:19 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:19 --> Model Class Initialized
INFO - 2017-09-11 10:34:19 --> Model Class Initialized
INFO - 2017-09-11 14:04:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:19 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:19 --> Total execution time: 0.0482
INFO - 2017-09-11 10:34:20 --> Config Class Initialized
INFO - 2017-09-11 10:34:20 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:20 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:20 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:20 --> URI Class Initialized
INFO - 2017-09-11 10:34:20 --> Router Class Initialized
INFO - 2017-09-11 10:34:20 --> Output Class Initialized
INFO - 2017-09-11 10:34:20 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:20 --> Input Class Initialized
INFO - 2017-09-11 10:34:20 --> Language Class Initialized
INFO - 2017-09-11 10:34:20 --> Loader Class Initialized
INFO - 2017-09-11 10:34:20 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:20 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:20 --> Email Class Initialized
INFO - 2017-09-11 10:34:20 --> Controller Class Initialized
INFO - 2017-09-11 10:34:20 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:20 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:20 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:20 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:20 --> Model Class Initialized
INFO - 2017-09-11 10:34:20 --> Model Class Initialized
INFO - 2017-09-11 14:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:20 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:20 --> Total execution time: 0.0501
INFO - 2017-09-11 10:34:22 --> Config Class Initialized
INFO - 2017-09-11 10:34:22 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:22 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:22 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:22 --> URI Class Initialized
INFO - 2017-09-11 10:34:22 --> Router Class Initialized
INFO - 2017-09-11 10:34:22 --> Output Class Initialized
INFO - 2017-09-11 10:34:22 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:22 --> Input Class Initialized
INFO - 2017-09-11 10:34:22 --> Language Class Initialized
INFO - 2017-09-11 10:34:22 --> Loader Class Initialized
INFO - 2017-09-11 10:34:22 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:22 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:22 --> Email Class Initialized
INFO - 2017-09-11 10:34:22 --> Controller Class Initialized
INFO - 2017-09-11 10:34:22 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:22 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:22 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:22 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:22 --> Model Class Initialized
INFO - 2017-09-11 10:34:22 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:22 --> Config Class Initialized
INFO - 2017-09-11 10:34:22 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:22 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:22 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:22 --> URI Class Initialized
INFO - 2017-09-11 10:34:22 --> Router Class Initialized
INFO - 2017-09-11 10:34:22 --> Output Class Initialized
INFO - 2017-09-11 10:34:22 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:22 --> Input Class Initialized
INFO - 2017-09-11 10:34:22 --> Language Class Initialized
INFO - 2017-09-11 10:34:22 --> Loader Class Initialized
INFO - 2017-09-11 10:34:22 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:22 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:22 --> Email Class Initialized
INFO - 2017-09-11 10:34:22 --> Controller Class Initialized
INFO - 2017-09-11 10:34:22 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:22 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:22 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:22 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:22 --> Model Class Initialized
INFO - 2017-09-11 10:34:22 --> Model Class Initialized
INFO - 2017-09-11 14:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:22 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:22 --> Total execution time: 0.0525
INFO - 2017-09-11 10:34:41 --> Config Class Initialized
INFO - 2017-09-11 10:34:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:41 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:41 --> URI Class Initialized
INFO - 2017-09-11 10:34:41 --> Router Class Initialized
INFO - 2017-09-11 10:34:41 --> Output Class Initialized
INFO - 2017-09-11 10:34:41 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:41 --> Input Class Initialized
INFO - 2017-09-11 10:34:41 --> Language Class Initialized
INFO - 2017-09-11 10:34:41 --> Loader Class Initialized
INFO - 2017-09-11 10:34:41 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:41 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:41 --> Email Class Initialized
INFO - 2017-09-11 10:34:41 --> Controller Class Initialized
INFO - 2017-09-11 10:34:41 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:41 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:41 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:41 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:41 --> Model Class Initialized
INFO - 2017-09-11 10:34:41 --> Model Class Initialized
INFO - 2017-09-11 14:04:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:41 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:41 --> Total execution time: 0.0474
INFO - 2017-09-11 10:34:43 --> Config Class Initialized
INFO - 2017-09-11 10:34:43 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:43 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:43 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:43 --> URI Class Initialized
INFO - 2017-09-11 10:34:43 --> Router Class Initialized
INFO - 2017-09-11 10:34:43 --> Output Class Initialized
INFO - 2017-09-11 10:34:43 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:43 --> Input Class Initialized
INFO - 2017-09-11 10:34:43 --> Language Class Initialized
INFO - 2017-09-11 10:34:43 --> Loader Class Initialized
INFO - 2017-09-11 10:34:43 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:43 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:43 --> Email Class Initialized
INFO - 2017-09-11 10:34:43 --> Controller Class Initialized
INFO - 2017-09-11 10:34:43 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:43 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:43 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:43 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:43 --> Model Class Initialized
INFO - 2017-09-11 10:34:43 --> Model Class Initialized
INFO - 2017-09-11 14:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:43 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:43 --> Total execution time: 0.0477
INFO - 2017-09-11 10:34:45 --> Config Class Initialized
INFO - 2017-09-11 10:34:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:45 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:45 --> URI Class Initialized
INFO - 2017-09-11 10:34:45 --> Router Class Initialized
INFO - 2017-09-11 10:34:45 --> Output Class Initialized
INFO - 2017-09-11 10:34:45 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:45 --> Input Class Initialized
INFO - 2017-09-11 10:34:45 --> Language Class Initialized
INFO - 2017-09-11 10:34:45 --> Loader Class Initialized
INFO - 2017-09-11 10:34:45 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:45 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:45 --> Email Class Initialized
INFO - 2017-09-11 10:34:45 --> Controller Class Initialized
INFO - 2017-09-11 10:34:45 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:45 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:45 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:45 --> Model Class Initialized
INFO - 2017-09-11 10:34:45 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:45 --> Config Class Initialized
INFO - 2017-09-11 10:34:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:45 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:45 --> URI Class Initialized
INFO - 2017-09-11 10:34:45 --> Router Class Initialized
INFO - 2017-09-11 10:34:45 --> Output Class Initialized
INFO - 2017-09-11 10:34:45 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:45 --> Input Class Initialized
INFO - 2017-09-11 10:34:45 --> Language Class Initialized
INFO - 2017-09-11 10:34:45 --> Loader Class Initialized
INFO - 2017-09-11 10:34:45 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:45 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:45 --> Email Class Initialized
INFO - 2017-09-11 10:34:45 --> Controller Class Initialized
INFO - 2017-09-11 10:34:45 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:45 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:45 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:45 --> Model Class Initialized
INFO - 2017-09-11 10:34:45 --> Model Class Initialized
INFO - 2017-09-11 14:04:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:45 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:45 --> Total execution time: 0.0475
INFO - 2017-09-11 10:34:47 --> Config Class Initialized
INFO - 2017-09-11 10:34:47 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:47 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:47 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:47 --> URI Class Initialized
INFO - 2017-09-11 10:34:47 --> Router Class Initialized
INFO - 2017-09-11 10:34:47 --> Output Class Initialized
INFO - 2017-09-11 10:34:47 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:47 --> Input Class Initialized
INFO - 2017-09-11 10:34:47 --> Language Class Initialized
INFO - 2017-09-11 10:34:47 --> Loader Class Initialized
INFO - 2017-09-11 10:34:47 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:47 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:47 --> Email Class Initialized
INFO - 2017-09-11 10:34:47 --> Controller Class Initialized
INFO - 2017-09-11 10:34:47 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:47 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:47 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:47 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:47 --> Model Class Initialized
INFO - 2017-09-11 10:34:47 --> Model Class Initialized
INFO - 2017-09-11 14:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 14:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:47 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:47 --> Total execution time: 0.0494
INFO - 2017-09-11 10:34:49 --> Config Class Initialized
INFO - 2017-09-11 10:34:49 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:49 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:49 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:49 --> URI Class Initialized
INFO - 2017-09-11 10:34:49 --> Router Class Initialized
INFO - 2017-09-11 10:34:49 --> Output Class Initialized
INFO - 2017-09-11 10:34:49 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:49 --> Input Class Initialized
INFO - 2017-09-11 10:34:49 --> Language Class Initialized
INFO - 2017-09-11 10:34:49 --> Loader Class Initialized
INFO - 2017-09-11 10:34:49 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:49 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:49 --> Email Class Initialized
INFO - 2017-09-11 10:34:49 --> Controller Class Initialized
INFO - 2017-09-11 10:34:49 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:49 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:49 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:49 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:49 --> Model Class Initialized
INFO - 2017-09-11 10:34:49 --> Model Class Initialized
DEBUG - 2017-09-11 14:04:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:04:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 10:34:49 --> Config Class Initialized
INFO - 2017-09-11 10:34:49 --> Hooks Class Initialized
DEBUG - 2017-09-11 10:34:49 --> UTF-8 Support Enabled
INFO - 2017-09-11 10:34:49 --> Utf8 Class Initialized
INFO - 2017-09-11 10:34:49 --> URI Class Initialized
INFO - 2017-09-11 10:34:49 --> Router Class Initialized
INFO - 2017-09-11 10:34:49 --> Output Class Initialized
INFO - 2017-09-11 10:34:49 --> Security Class Initialized
DEBUG - 2017-09-11 10:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 10:34:49 --> Input Class Initialized
INFO - 2017-09-11 10:34:49 --> Language Class Initialized
INFO - 2017-09-11 10:34:49 --> Loader Class Initialized
INFO - 2017-09-11 10:34:49 --> Helper loaded: common_helper
INFO - 2017-09-11 10:34:49 --> Database Driver Class Initialized
INFO - 2017-09-11 10:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 10:34:49 --> Email Class Initialized
INFO - 2017-09-11 10:34:49 --> Controller Class Initialized
INFO - 2017-09-11 10:34:49 --> Helper loaded: form_helper
INFO - 2017-09-11 10:34:49 --> Form Validation Class Initialized
INFO - 2017-09-11 10:34:49 --> Helper loaded: email_helper
DEBUG - 2017-09-11 10:34:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 10:34:49 --> Helper loaded: url_helper
INFO - 2017-09-11 10:34:49 --> Model Class Initialized
INFO - 2017-09-11 10:34:49 --> Model Class Initialized
INFO - 2017-09-11 14:04:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:04:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:04:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:04:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:04:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:04:49 --> Final output sent to browser
DEBUG - 2017-09-11 14:04:49 --> Total execution time: 0.0500
INFO - 2017-09-11 11:20:37 --> Config Class Initialized
INFO - 2017-09-11 11:20:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:20:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:20:37 --> Utf8 Class Initialized
INFO - 2017-09-11 11:20:37 --> URI Class Initialized
INFO - 2017-09-11 11:20:37 --> Router Class Initialized
INFO - 2017-09-11 11:20:37 --> Output Class Initialized
INFO - 2017-09-11 11:20:37 --> Security Class Initialized
DEBUG - 2017-09-11 11:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:20:37 --> Input Class Initialized
INFO - 2017-09-11 11:20:37 --> Language Class Initialized
INFO - 2017-09-11 11:20:37 --> Loader Class Initialized
INFO - 2017-09-11 11:20:37 --> Helper loaded: common_helper
INFO - 2017-09-11 11:20:37 --> Database Driver Class Initialized
INFO - 2017-09-11 11:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:20:37 --> Email Class Initialized
INFO - 2017-09-11 11:20:37 --> Controller Class Initialized
INFO - 2017-09-11 11:20:37 --> Helper loaded: form_helper
INFO - 2017-09-11 11:20:37 --> Form Validation Class Initialized
INFO - 2017-09-11 11:20:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:20:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:20:37 --> Helper loaded: url_helper
INFO - 2017-09-11 14:50:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:50:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:50:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:50:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:50:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:50:37 --> Final output sent to browser
DEBUG - 2017-09-11 14:50:37 --> Total execution time: 0.0471
INFO - 2017-09-11 11:21:16 --> Config Class Initialized
INFO - 2017-09-11 11:21:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:21:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:21:16 --> Utf8 Class Initialized
INFO - 2017-09-11 11:21:16 --> URI Class Initialized
INFO - 2017-09-11 11:21:16 --> Router Class Initialized
INFO - 2017-09-11 11:21:16 --> Output Class Initialized
INFO - 2017-09-11 11:21:16 --> Security Class Initialized
DEBUG - 2017-09-11 11:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:21:16 --> Input Class Initialized
INFO - 2017-09-11 11:21:16 --> Language Class Initialized
INFO - 2017-09-11 11:21:16 --> Loader Class Initialized
INFO - 2017-09-11 11:21:16 --> Helper loaded: common_helper
INFO - 2017-09-11 11:21:16 --> Database Driver Class Initialized
INFO - 2017-09-11 11:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:21:16 --> Email Class Initialized
INFO - 2017-09-11 11:21:16 --> Controller Class Initialized
INFO - 2017-09-11 11:21:16 --> Helper loaded: form_helper
INFO - 2017-09-11 11:21:16 --> Form Validation Class Initialized
INFO - 2017-09-11 11:21:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:21:16 --> Helper loaded: url_helper
INFO - 2017-09-11 11:21:16 --> Model Class Initialized
INFO - 2017-09-11 11:21:16 --> Model Class Initialized
INFO - 2017-09-11 11:21:16 --> Model Class Initialized
INFO - 2017-09-11 14:51:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:51:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:51:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:16 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:16 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-11 14:51:17 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-11 14:51:17 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-09-11 14:51:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-09-11 14:51:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:51:17 --> Final output sent to browser
DEBUG - 2017-09-11 14:51:17 --> Total execution time: 0.2242
INFO - 2017-09-11 11:21:18 --> Config Class Initialized
INFO - 2017-09-11 11:21:18 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:21:18 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:21:18 --> Utf8 Class Initialized
INFO - 2017-09-11 11:21:18 --> URI Class Initialized
INFO - 2017-09-11 11:21:18 --> Router Class Initialized
INFO - 2017-09-11 11:21:18 --> Output Class Initialized
INFO - 2017-09-11 11:21:18 --> Security Class Initialized
DEBUG - 2017-09-11 11:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:21:18 --> Input Class Initialized
INFO - 2017-09-11 11:21:18 --> Language Class Initialized
INFO - 2017-09-11 11:21:18 --> Loader Class Initialized
INFO - 2017-09-11 11:21:18 --> Helper loaded: common_helper
INFO - 2017-09-11 11:21:18 --> Database Driver Class Initialized
INFO - 2017-09-11 11:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:21:18 --> Email Class Initialized
INFO - 2017-09-11 11:21:18 --> Controller Class Initialized
INFO - 2017-09-11 11:21:18 --> Helper loaded: form_helper
INFO - 2017-09-11 11:21:18 --> Form Validation Class Initialized
INFO - 2017-09-11 11:21:18 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:21:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:21:18 --> Helper loaded: url_helper
INFO - 2017-09-11 14:51:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:51:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:51:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 14:51:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 14:51:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:51:18 --> Final output sent to browser
DEBUG - 2017-09-11 14:51:18 --> Total execution time: 0.0497
INFO - 2017-09-11 11:32:08 --> Config Class Initialized
INFO - 2017-09-11 11:32:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:32:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:32:08 --> Utf8 Class Initialized
INFO - 2017-09-11 11:32:08 --> URI Class Initialized
INFO - 2017-09-11 11:32:08 --> Router Class Initialized
INFO - 2017-09-11 11:32:08 --> Output Class Initialized
INFO - 2017-09-11 11:32:08 --> Security Class Initialized
DEBUG - 2017-09-11 11:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:32:08 --> Input Class Initialized
INFO - 2017-09-11 11:32:08 --> Language Class Initialized
INFO - 2017-09-11 11:32:08 --> Loader Class Initialized
INFO - 2017-09-11 11:32:08 --> Helper loaded: common_helper
INFO - 2017-09-11 11:32:08 --> Database Driver Class Initialized
INFO - 2017-09-11 11:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:32:08 --> Email Class Initialized
INFO - 2017-09-11 11:32:08 --> Controller Class Initialized
INFO - 2017-09-11 11:32:08 --> Helper loaded: form_helper
INFO - 2017-09-11 11:32:08 --> Form Validation Class Initialized
INFO - 2017-09-11 11:32:08 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:32:08 --> Helper loaded: url_helper
INFO - 2017-09-11 15:02:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 15:02:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 15:02:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 15:02:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 15:02:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 15:02:08 --> Final output sent to browser
DEBUG - 2017-09-11 15:02:08 --> Total execution time: 0.0483
INFO - 2017-09-11 11:32:11 --> Config Class Initialized
INFO - 2017-09-11 11:32:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:32:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:32:11 --> Utf8 Class Initialized
INFO - 2017-09-11 11:32:11 --> URI Class Initialized
INFO - 2017-09-11 11:32:11 --> Router Class Initialized
INFO - 2017-09-11 11:32:11 --> Output Class Initialized
INFO - 2017-09-11 11:32:11 --> Security Class Initialized
DEBUG - 2017-09-11 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:32:11 --> Input Class Initialized
INFO - 2017-09-11 11:32:11 --> Language Class Initialized
INFO - 2017-09-11 11:32:11 --> Loader Class Initialized
INFO - 2017-09-11 11:32:11 --> Helper loaded: common_helper
INFO - 2017-09-11 11:32:11 --> Database Driver Class Initialized
INFO - 2017-09-11 11:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:32:11 --> Email Class Initialized
INFO - 2017-09-11 11:32:11 --> Controller Class Initialized
INFO - 2017-09-11 11:32:11 --> Helper loaded: form_helper
INFO - 2017-09-11 11:32:11 --> Form Validation Class Initialized
INFO - 2017-09-11 11:32:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:32:11 --> Helper loaded: url_helper
DEBUG - 2017-09-11 15:02:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:02:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-11 11:32:11 --> Config Class Initialized
INFO - 2017-09-11 11:32:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:32:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:32:11 --> Utf8 Class Initialized
INFO - 2017-09-11 11:32:11 --> URI Class Initialized
INFO - 2017-09-11 11:32:11 --> Router Class Initialized
INFO - 2017-09-11 11:32:11 --> Output Class Initialized
INFO - 2017-09-11 11:32:11 --> Security Class Initialized
DEBUG - 2017-09-11 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:32:11 --> Input Class Initialized
INFO - 2017-09-11 11:32:11 --> Language Class Initialized
INFO - 2017-09-11 11:32:11 --> Loader Class Initialized
INFO - 2017-09-11 11:32:11 --> Helper loaded: common_helper
INFO - 2017-09-11 11:32:11 --> Database Driver Class Initialized
INFO - 2017-09-11 11:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:32:11 --> Email Class Initialized
INFO - 2017-09-11 11:32:11 --> Controller Class Initialized
INFO - 2017-09-11 11:32:11 --> Helper loaded: form_helper
INFO - 2017-09-11 11:32:11 --> Form Validation Class Initialized
INFO - 2017-09-11 11:32:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:32:11 --> Helper loaded: url_helper
INFO - 2017-09-11 15:02:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 15:02:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 15:02:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 15:02:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-09-11 15:02:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 15:02:11 --> Final output sent to browser
DEBUG - 2017-09-11 15:02:11 --> Total execution time: 0.0479
INFO - 2017-09-11 11:36:12 --> Config Class Initialized
INFO - 2017-09-11 11:36:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 11:36:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 11:36:12 --> Utf8 Class Initialized
INFO - 2017-09-11 11:36:12 --> URI Class Initialized
INFO - 2017-09-11 11:36:12 --> Router Class Initialized
INFO - 2017-09-11 11:36:12 --> Output Class Initialized
INFO - 2017-09-11 11:36:12 --> Security Class Initialized
DEBUG - 2017-09-11 11:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 11:36:12 --> Input Class Initialized
INFO - 2017-09-11 11:36:12 --> Language Class Initialized
INFO - 2017-09-11 11:36:12 --> Loader Class Initialized
INFO - 2017-09-11 11:36:12 --> Helper loaded: common_helper
INFO - 2017-09-11 11:36:12 --> Database Driver Class Initialized
INFO - 2017-09-11 11:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 11:36:12 --> Email Class Initialized
INFO - 2017-09-11 11:36:12 --> Controller Class Initialized
INFO - 2017-09-11 11:36:12 --> Helper loaded: form_helper
INFO - 2017-09-11 11:36:12 --> Form Validation Class Initialized
INFO - 2017-09-11 11:36:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 11:36:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 11:36:12 --> Helper loaded: url_helper
INFO - 2017-09-11 15:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 15:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 15:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 15:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 15:06:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 15:06:12 --> Final output sent to browser
DEBUG - 2017-09-11 15:06:12 --> Total execution time: 0.0462
INFO - 2017-09-11 12:06:58 --> Config Class Initialized
INFO - 2017-09-11 12:06:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:06:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:06:58 --> Utf8 Class Initialized
INFO - 2017-09-11 12:06:58 --> URI Class Initialized
INFO - 2017-09-11 12:06:58 --> Router Class Initialized
INFO - 2017-09-11 12:06:58 --> Output Class Initialized
INFO - 2017-09-11 12:06:58 --> Security Class Initialized
DEBUG - 2017-09-11 12:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:06:58 --> Input Class Initialized
INFO - 2017-09-11 12:06:58 --> Language Class Initialized
INFO - 2017-09-11 12:06:58 --> Loader Class Initialized
INFO - 2017-09-11 12:06:58 --> Helper loaded: common_helper
INFO - 2017-09-11 12:06:58 --> Database Driver Class Initialized
INFO - 2017-09-11 12:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:06:58 --> Email Class Initialized
INFO - 2017-09-11 12:06:58 --> Controller Class Initialized
INFO - 2017-09-11 12:06:58 --> Helper loaded: form_helper
INFO - 2017-09-11 12:06:58 --> Form Validation Class Initialized
INFO - 2017-09-11 12:06:58 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:06:58 --> Helper loaded: url_helper
INFO - 2017-09-11 15:36:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 15:36:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 15:36:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 15:36:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 15:36:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 15:36:58 --> Final output sent to browser
DEBUG - 2017-09-11 15:36:58 --> Total execution time: 0.0536
INFO - 2017-09-11 12:12:57 --> Config Class Initialized
INFO - 2017-09-11 12:12:57 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:12:57 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:12:57 --> Utf8 Class Initialized
INFO - 2017-09-11 12:12:57 --> URI Class Initialized
INFO - 2017-09-11 12:12:57 --> Router Class Initialized
INFO - 2017-09-11 12:12:57 --> Output Class Initialized
INFO - 2017-09-11 12:12:57 --> Security Class Initialized
DEBUG - 2017-09-11 12:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:12:57 --> Input Class Initialized
INFO - 2017-09-11 12:12:57 --> Language Class Initialized
INFO - 2017-09-11 12:12:57 --> Loader Class Initialized
INFO - 2017-09-11 12:12:57 --> Helper loaded: common_helper
INFO - 2017-09-11 12:12:57 --> Database Driver Class Initialized
INFO - 2017-09-11 12:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:12:57 --> Email Class Initialized
INFO - 2017-09-11 12:12:57 --> Controller Class Initialized
INFO - 2017-09-11 12:12:57 --> Helper loaded: form_helper
INFO - 2017-09-11 12:12:57 --> Form Validation Class Initialized
INFO - 2017-09-11 12:12:57 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:12:57 --> Helper loaded: url_helper
INFO - 2017-09-11 12:12:57 --> Model Class Initialized
INFO - 2017-09-11 12:12:57 --> Model Class Initialized
INFO - 2017-09-11 12:12:57 --> Model Class Initialized
INFO - 2017-09-11 15:42:57 --> Helper loaded: download_helper
INFO - 2017-09-11 15:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 15:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 15:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 15:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 15:42:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 15:42:57 --> Final output sent to browser
DEBUG - 2017-09-11 15:42:57 --> Total execution time: 0.0612
INFO - 2017-09-11 12:12:58 --> Config Class Initialized
INFO - 2017-09-11 12:12:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:12:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:12:58 --> Utf8 Class Initialized
INFO - 2017-09-11 12:12:58 --> URI Class Initialized
INFO - 2017-09-11 12:12:58 --> Router Class Initialized
INFO - 2017-09-11 12:12:58 --> Output Class Initialized
INFO - 2017-09-11 12:12:58 --> Security Class Initialized
DEBUG - 2017-09-11 12:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:12:58 --> Input Class Initialized
INFO - 2017-09-11 12:12:58 --> Language Class Initialized
INFO - 2017-09-11 12:12:58 --> Loader Class Initialized
INFO - 2017-09-11 12:12:58 --> Helper loaded: common_helper
INFO - 2017-09-11 12:12:58 --> Database Driver Class Initialized
INFO - 2017-09-11 12:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:12:58 --> Email Class Initialized
INFO - 2017-09-11 12:12:58 --> Controller Class Initialized
INFO - 2017-09-11 12:12:58 --> Helper loaded: form_helper
INFO - 2017-09-11 12:12:58 --> Form Validation Class Initialized
INFO - 2017-09-11 12:12:58 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:12:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:12:58 --> Helper loaded: url_helper
INFO - 2017-09-11 12:12:58 --> Model Class Initialized
INFO - 2017-09-11 12:12:58 --> Model Class Initialized
INFO - 2017-09-11 12:12:58 --> Model Class Initialized
INFO - 2017-09-11 15:42:58 --> Helper loaded: download_helper
INFO - 2017-09-11 15:42:58 --> Final output sent to browser
DEBUG - 2017-09-11 15:42:58 --> Total execution time: 0.0516
INFO - 2017-09-11 12:16:49 --> Config Class Initialized
INFO - 2017-09-11 12:16:49 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:16:49 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:16:49 --> Utf8 Class Initialized
INFO - 2017-09-11 12:16:49 --> URI Class Initialized
INFO - 2017-09-11 12:16:49 --> Router Class Initialized
INFO - 2017-09-11 12:16:49 --> Output Class Initialized
INFO - 2017-09-11 12:16:49 --> Security Class Initialized
DEBUG - 2017-09-11 12:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:16:49 --> Input Class Initialized
INFO - 2017-09-11 12:16:49 --> Language Class Initialized
INFO - 2017-09-11 12:16:49 --> Loader Class Initialized
INFO - 2017-09-11 12:16:49 --> Helper loaded: common_helper
INFO - 2017-09-11 12:16:49 --> Database Driver Class Initialized
INFO - 2017-09-11 12:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:16:49 --> Email Class Initialized
INFO - 2017-09-11 12:16:49 --> Controller Class Initialized
INFO - 2017-09-11 12:16:49 --> Helper loaded: form_helper
INFO - 2017-09-11 12:16:49 --> Form Validation Class Initialized
INFO - 2017-09-11 12:16:49 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:16:49 --> Helper loaded: url_helper
INFO - 2017-09-11 12:16:49 --> Model Class Initialized
INFO - 2017-09-11 12:16:49 --> Model Class Initialized
INFO - 2017-09-11 12:16:49 --> Model Class Initialized
INFO - 2017-09-11 15:46:49 --> Helper loaded: download_helper
INFO - 2017-09-11 15:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 15:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 15:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 15:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 15:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 15:46:49 --> Final output sent to browser
DEBUG - 2017-09-11 15:46:49 --> Total execution time: 0.0583
INFO - 2017-09-11 12:54:06 --> Config Class Initialized
INFO - 2017-09-11 12:54:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:54:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:54:06 --> Utf8 Class Initialized
INFO - 2017-09-11 12:54:06 --> URI Class Initialized
INFO - 2017-09-11 12:54:06 --> Router Class Initialized
INFO - 2017-09-11 12:54:06 --> Output Class Initialized
INFO - 2017-09-11 12:54:06 --> Security Class Initialized
DEBUG - 2017-09-11 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:54:06 --> Input Class Initialized
INFO - 2017-09-11 12:54:06 --> Language Class Initialized
INFO - 2017-09-11 12:54:06 --> Loader Class Initialized
INFO - 2017-09-11 12:54:06 --> Helper loaded: common_helper
INFO - 2017-09-11 12:54:06 --> Database Driver Class Initialized
INFO - 2017-09-11 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:54:06 --> Email Class Initialized
INFO - 2017-09-11 12:54:06 --> Controller Class Initialized
INFO - 2017-09-11 12:54:06 --> Helper loaded: form_helper
INFO - 2017-09-11 12:54:06 --> Form Validation Class Initialized
INFO - 2017-09-11 12:54:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:54:06 --> Helper loaded: url_helper
INFO - 2017-09-11 12:54:06 --> Model Class Initialized
INFO - 2017-09-11 12:54:06 --> Model Class Initialized
INFO - 2017-09-11 12:54:06 --> Model Class Initialized
INFO - 2017-09-11 16:24:06 --> Helper loaded: download_helper
INFO - 2017-09-11 16:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 16:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 16:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 16:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 16:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 16:24:06 --> Final output sent to browser
DEBUG - 2017-09-11 16:24:06 --> Total execution time: 0.0552
INFO - 2017-09-11 12:54:07 --> Config Class Initialized
INFO - 2017-09-11 12:54:07 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:54:07 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:54:07 --> Utf8 Class Initialized
INFO - 2017-09-11 12:54:07 --> URI Class Initialized
INFO - 2017-09-11 12:54:07 --> Router Class Initialized
INFO - 2017-09-11 12:54:07 --> Output Class Initialized
INFO - 2017-09-11 12:54:07 --> Security Class Initialized
DEBUG - 2017-09-11 12:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:54:07 --> Input Class Initialized
INFO - 2017-09-11 12:54:07 --> Language Class Initialized
INFO - 2017-09-11 12:54:07 --> Loader Class Initialized
INFO - 2017-09-11 12:54:07 --> Helper loaded: common_helper
INFO - 2017-09-11 12:54:07 --> Database Driver Class Initialized
INFO - 2017-09-11 12:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:54:07 --> Email Class Initialized
INFO - 2017-09-11 12:54:07 --> Controller Class Initialized
INFO - 2017-09-11 12:54:07 --> Helper loaded: form_helper
INFO - 2017-09-11 12:54:07 --> Form Validation Class Initialized
INFO - 2017-09-11 12:54:07 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:54:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:54:07 --> Helper loaded: url_helper
INFO - 2017-09-11 12:54:07 --> Model Class Initialized
INFO - 2017-09-11 12:54:07 --> Model Class Initialized
INFO - 2017-09-11 12:54:07 --> Model Class Initialized
INFO - 2017-09-11 16:24:07 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:24:07 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-09-11 16:24:07 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 195
INFO - 2017-09-11 16:24:07 --> Final output sent to browser
DEBUG - 2017-09-11 16:24:07 --> Total execution time: 0.0490
INFO - 2017-09-11 12:54:36 --> Config Class Initialized
INFO - 2017-09-11 12:54:36 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:54:36 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:54:36 --> Utf8 Class Initialized
INFO - 2017-09-11 12:54:36 --> URI Class Initialized
INFO - 2017-09-11 12:54:36 --> Router Class Initialized
INFO - 2017-09-11 12:54:36 --> Output Class Initialized
INFO - 2017-09-11 12:54:36 --> Security Class Initialized
DEBUG - 2017-09-11 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:54:36 --> Input Class Initialized
INFO - 2017-09-11 12:54:36 --> Language Class Initialized
INFO - 2017-09-11 12:54:36 --> Loader Class Initialized
INFO - 2017-09-11 12:54:36 --> Helper loaded: common_helper
INFO - 2017-09-11 12:54:36 --> Database Driver Class Initialized
INFO - 2017-09-11 12:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:54:36 --> Email Class Initialized
INFO - 2017-09-11 12:54:36 --> Controller Class Initialized
INFO - 2017-09-11 12:54:36 --> Helper loaded: form_helper
INFO - 2017-09-11 12:54:36 --> Form Validation Class Initialized
INFO - 2017-09-11 12:54:36 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:54:36 --> Helper loaded: url_helper
INFO - 2017-09-11 12:54:36 --> Model Class Initialized
INFO - 2017-09-11 12:54:36 --> Model Class Initialized
INFO - 2017-09-11 12:54:36 --> Model Class Initialized
INFO - 2017-09-11 16:24:36 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:24:36 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead
ERROR - 2017-09-11 16:24:36 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 192
ERROR - 2017-09-11 16:24:36 --> Use of undefined constant DB_NAME - assumed 'DB_NAME'
ERROR - 2017-09-11 16:24:36 --> Severity: Notice --> Use of undefined constant DB_NAME - assumed 'DB_NAME' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
INFO - 2017-09-11 12:54:51 --> Config Class Initialized
INFO - 2017-09-11 12:54:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:54:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:54:51 --> Utf8 Class Initialized
INFO - 2017-09-11 12:54:51 --> URI Class Initialized
INFO - 2017-09-11 12:54:51 --> Router Class Initialized
INFO - 2017-09-11 12:54:51 --> Output Class Initialized
INFO - 2017-09-11 12:54:51 --> Security Class Initialized
DEBUG - 2017-09-11 12:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:54:51 --> Input Class Initialized
INFO - 2017-09-11 12:54:51 --> Language Class Initialized
INFO - 2017-09-11 12:54:51 --> Loader Class Initialized
INFO - 2017-09-11 12:54:51 --> Helper loaded: common_helper
INFO - 2017-09-11 12:54:51 --> Database Driver Class Initialized
INFO - 2017-09-11 12:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:54:51 --> Email Class Initialized
INFO - 2017-09-11 12:54:51 --> Controller Class Initialized
INFO - 2017-09-11 12:54:51 --> Helper loaded: form_helper
INFO - 2017-09-11 12:54:51 --> Form Validation Class Initialized
INFO - 2017-09-11 12:54:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:54:51 --> Helper loaded: url_helper
INFO - 2017-09-11 12:54:51 --> Model Class Initialized
INFO - 2017-09-11 12:54:51 --> Model Class Initialized
INFO - 2017-09-11 12:54:51 --> Model Class Initialized
INFO - 2017-09-11 16:24:51 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:24:51 --> Use of undefined constant DB_NAME - assumed 'DB_NAME'
ERROR - 2017-09-11 16:24:51 --> Severity: Notice --> Use of undefined constant DB_NAME - assumed 'DB_NAME' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
ERROR - 2017-09-11 16:24:51 --> mysqli_select_db() expects parameter 1 to be mysqli, string given
ERROR - 2017-09-11 16:24:51 --> Severity: Warning --> mysqli_select_db() expects parameter 1 to be mysqli, string given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
INFO - 2017-09-11 12:55:06 --> Config Class Initialized
INFO - 2017-09-11 12:55:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:55:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:55:06 --> Utf8 Class Initialized
INFO - 2017-09-11 12:55:06 --> URI Class Initialized
INFO - 2017-09-11 12:55:06 --> Router Class Initialized
INFO - 2017-09-11 12:55:06 --> Output Class Initialized
INFO - 2017-09-11 12:55:06 --> Security Class Initialized
DEBUG - 2017-09-11 12:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:55:06 --> Input Class Initialized
INFO - 2017-09-11 12:55:06 --> Language Class Initialized
INFO - 2017-09-11 12:55:06 --> Loader Class Initialized
INFO - 2017-09-11 12:55:06 --> Helper loaded: common_helper
INFO - 2017-09-11 12:55:06 --> Database Driver Class Initialized
INFO - 2017-09-11 12:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:55:06 --> Email Class Initialized
INFO - 2017-09-11 12:55:06 --> Controller Class Initialized
INFO - 2017-09-11 12:55:06 --> Helper loaded: form_helper
INFO - 2017-09-11 12:55:06 --> Form Validation Class Initialized
INFO - 2017-09-11 12:55:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:55:06 --> Helper loaded: url_helper
INFO - 2017-09-11 12:55:06 --> Model Class Initialized
INFO - 2017-09-11 12:55:06 --> Model Class Initialized
INFO - 2017-09-11 12:55:06 --> Model Class Initialized
INFO - 2017-09-11 16:25:06 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:25:06 --> mysqli_select_db() expects parameter 1 to be mysqli, string given
ERROR - 2017-09-11 16:25:06 --> Severity: Warning --> mysqli_select_db() expects parameter 1 to be mysqli, string given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
INFO - 2017-09-11 12:55:20 --> Config Class Initialized
INFO - 2017-09-11 12:55:20 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:55:20 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:55:20 --> Utf8 Class Initialized
INFO - 2017-09-11 12:55:20 --> URI Class Initialized
INFO - 2017-09-11 12:55:20 --> Router Class Initialized
INFO - 2017-09-11 12:55:20 --> Output Class Initialized
INFO - 2017-09-11 12:55:20 --> Security Class Initialized
DEBUG - 2017-09-11 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:55:20 --> Input Class Initialized
INFO - 2017-09-11 12:55:20 --> Language Class Initialized
INFO - 2017-09-11 12:55:20 --> Loader Class Initialized
INFO - 2017-09-11 12:55:20 --> Helper loaded: common_helper
INFO - 2017-09-11 12:55:20 --> Database Driver Class Initialized
INFO - 2017-09-11 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:55:20 --> Email Class Initialized
INFO - 2017-09-11 12:55:20 --> Controller Class Initialized
INFO - 2017-09-11 12:55:20 --> Helper loaded: form_helper
INFO - 2017-09-11 12:55:20 --> Form Validation Class Initialized
INFO - 2017-09-11 12:55:20 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:55:20 --> Helper loaded: url_helper
INFO - 2017-09-11 12:55:20 --> Model Class Initialized
INFO - 2017-09-11 12:55:20 --> Model Class Initialized
INFO - 2017-09-11 12:55:20 --> Model Class Initialized
INFO - 2017-09-11 16:25:20 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:25:20 --> mysqli_select_db() expects parameter 1 to be mysqli, string given
ERROR - 2017-09-11 16:25:20 --> Severity: Warning --> mysqli_select_db() expects parameter 1 to be mysqli, string given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
INFO - 2017-09-11 12:55:22 --> Config Class Initialized
INFO - 2017-09-11 12:55:22 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:55:22 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:55:22 --> Utf8 Class Initialized
INFO - 2017-09-11 12:55:22 --> URI Class Initialized
INFO - 2017-09-11 12:55:22 --> Router Class Initialized
INFO - 2017-09-11 12:55:22 --> Output Class Initialized
INFO - 2017-09-11 12:55:22 --> Security Class Initialized
DEBUG - 2017-09-11 12:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:55:22 --> Input Class Initialized
INFO - 2017-09-11 12:55:22 --> Language Class Initialized
INFO - 2017-09-11 12:55:22 --> Loader Class Initialized
INFO - 2017-09-11 12:55:22 --> Helper loaded: common_helper
INFO - 2017-09-11 12:55:22 --> Database Driver Class Initialized
INFO - 2017-09-11 12:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:55:22 --> Email Class Initialized
INFO - 2017-09-11 12:55:22 --> Controller Class Initialized
INFO - 2017-09-11 12:55:22 --> Helper loaded: form_helper
INFO - 2017-09-11 12:55:22 --> Form Validation Class Initialized
INFO - 2017-09-11 12:55:22 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:55:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:55:22 --> Helper loaded: url_helper
INFO - 2017-09-11 12:55:22 --> Model Class Initialized
INFO - 2017-09-11 12:55:22 --> Model Class Initialized
INFO - 2017-09-11 12:55:22 --> Model Class Initialized
INFO - 2017-09-11 16:25:22 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:25:22 --> mysqli_select_db() expects parameter 1 to be mysqli, string given
ERROR - 2017-09-11 16:25:22 --> Severity: Warning --> mysqli_select_db() expects parameter 1 to be mysqli, string given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
INFO - 2017-09-11 12:55:37 --> Config Class Initialized
INFO - 2017-09-11 12:55:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:55:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:55:37 --> Utf8 Class Initialized
INFO - 2017-09-11 12:55:37 --> URI Class Initialized
INFO - 2017-09-11 12:55:37 --> Router Class Initialized
INFO - 2017-09-11 12:55:37 --> Output Class Initialized
INFO - 2017-09-11 12:55:37 --> Security Class Initialized
DEBUG - 2017-09-11 12:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:55:37 --> Input Class Initialized
INFO - 2017-09-11 12:55:37 --> Language Class Initialized
INFO - 2017-09-11 12:55:37 --> Loader Class Initialized
INFO - 2017-09-11 12:55:37 --> Helper loaded: common_helper
INFO - 2017-09-11 12:55:37 --> Database Driver Class Initialized
INFO - 2017-09-11 12:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:55:37 --> Email Class Initialized
INFO - 2017-09-11 12:55:37 --> Controller Class Initialized
INFO - 2017-09-11 12:55:37 --> Helper loaded: form_helper
INFO - 2017-09-11 12:55:37 --> Form Validation Class Initialized
INFO - 2017-09-11 12:55:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:55:37 --> Helper loaded: url_helper
INFO - 2017-09-11 12:55:37 --> Model Class Initialized
INFO - 2017-09-11 12:55:37 --> Model Class Initialized
INFO - 2017-09-11 12:55:37 --> Model Class Initialized
INFO - 2017-09-11 16:25:37 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:25:37 --> mysqli_select_db() expects parameter 1 to be mysqli, string given
ERROR - 2017-09-11 16:25:37 --> Severity: Warning --> mysqli_select_db() expects parameter 1 to be mysqli, string given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 193
INFO - 2017-09-11 12:55:59 --> Config Class Initialized
INFO - 2017-09-11 12:55:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:55:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:55:59 --> Utf8 Class Initialized
INFO - 2017-09-11 12:55:59 --> URI Class Initialized
INFO - 2017-09-11 12:55:59 --> Router Class Initialized
INFO - 2017-09-11 12:55:59 --> Output Class Initialized
INFO - 2017-09-11 12:55:59 --> Security Class Initialized
DEBUG - 2017-09-11 12:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:55:59 --> Input Class Initialized
INFO - 2017-09-11 12:55:59 --> Language Class Initialized
INFO - 2017-09-11 12:55:59 --> Loader Class Initialized
INFO - 2017-09-11 12:55:59 --> Helper loaded: common_helper
INFO - 2017-09-11 12:55:59 --> Database Driver Class Initialized
INFO - 2017-09-11 12:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:55:59 --> Email Class Initialized
INFO - 2017-09-11 12:55:59 --> Controller Class Initialized
INFO - 2017-09-11 12:55:59 --> Helper loaded: form_helper
INFO - 2017-09-11 12:55:59 --> Form Validation Class Initialized
INFO - 2017-09-11 12:55:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:55:59 --> Helper loaded: url_helper
INFO - 2017-09-11 12:55:59 --> Model Class Initialized
INFO - 2017-09-11 12:55:59 --> Model Class Initialized
INFO - 2017-09-11 12:55:59 --> Model Class Initialized
INFO - 2017-09-11 16:25:59 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:25:59 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 202
ERROR - 2017-09-11 16:25:59 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 204
ERROR - 2017-09-11 16:25:59 --> mysql_fetch_row() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysql_fetch_row() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 208
ERROR - 2017-09-11 16:25:59 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 228
INFO - 2017-09-11 16:25:59 --> Final output sent to browser
DEBUG - 2017-09-11 16:25:59 --> Total execution time: 0.0515
INFO - 2017-09-11 12:55:59 --> Config Class Initialized
INFO - 2017-09-11 12:55:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:55:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:55:59 --> Utf8 Class Initialized
INFO - 2017-09-11 12:55:59 --> URI Class Initialized
INFO - 2017-09-11 12:55:59 --> Router Class Initialized
INFO - 2017-09-11 12:55:59 --> Output Class Initialized
INFO - 2017-09-11 12:55:59 --> Security Class Initialized
DEBUG - 2017-09-11 12:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:55:59 --> Input Class Initialized
INFO - 2017-09-11 12:55:59 --> Language Class Initialized
INFO - 2017-09-11 12:55:59 --> Loader Class Initialized
INFO - 2017-09-11 12:55:59 --> Helper loaded: common_helper
INFO - 2017-09-11 12:55:59 --> Database Driver Class Initialized
INFO - 2017-09-11 12:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:55:59 --> Email Class Initialized
INFO - 2017-09-11 12:55:59 --> Controller Class Initialized
INFO - 2017-09-11 12:55:59 --> Helper loaded: form_helper
INFO - 2017-09-11 12:55:59 --> Form Validation Class Initialized
INFO - 2017-09-11 12:55:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:55:59 --> Helper loaded: url_helper
INFO - 2017-09-11 12:55:59 --> Model Class Initialized
INFO - 2017-09-11 12:55:59 --> Model Class Initialized
INFO - 2017-09-11 12:55:59 --> Model Class Initialized
INFO - 2017-09-11 16:25:59 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:25:59 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 202
ERROR - 2017-09-11 16:25:59 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 204
ERROR - 2017-09-11 16:25:59 --> mysql_fetch_row() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysql_fetch_row() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 208
ERROR - 2017-09-11 16:25:59 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:25:59 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 228
INFO - 2017-09-11 16:25:59 --> Final output sent to browser
DEBUG - 2017-09-11 16:25:59 --> Total execution time: 0.0688
INFO - 2017-09-11 12:56:04 --> Config Class Initialized
INFO - 2017-09-11 12:56:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:56:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:56:04 --> Utf8 Class Initialized
INFO - 2017-09-11 12:56:04 --> URI Class Initialized
INFO - 2017-09-11 12:56:04 --> Router Class Initialized
INFO - 2017-09-11 12:56:04 --> Output Class Initialized
INFO - 2017-09-11 12:56:04 --> Security Class Initialized
DEBUG - 2017-09-11 12:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:56:04 --> Input Class Initialized
INFO - 2017-09-11 12:56:04 --> Language Class Initialized
INFO - 2017-09-11 12:56:04 --> Loader Class Initialized
INFO - 2017-09-11 12:56:04 --> Helper loaded: common_helper
INFO - 2017-09-11 12:56:04 --> Database Driver Class Initialized
INFO - 2017-09-11 12:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:56:04 --> Email Class Initialized
INFO - 2017-09-11 12:56:04 --> Controller Class Initialized
INFO - 2017-09-11 12:56:04 --> Helper loaded: form_helper
INFO - 2017-09-11 12:56:04 --> Form Validation Class Initialized
INFO - 2017-09-11 12:56:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:56:04 --> Helper loaded: url_helper
INFO - 2017-09-11 12:56:04 --> Model Class Initialized
INFO - 2017-09-11 12:56:04 --> Model Class Initialized
INFO - 2017-09-11 12:56:04 --> Model Class Initialized
INFO - 2017-09-11 16:26:04 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:26:04 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:26:04 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 202
ERROR - 2017-09-11 16:26:04 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:26:04 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 204
ERROR - 2017-09-11 16:26:04 --> mysql_fetch_row() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:26:04 --> Severity: Warning --> mysql_fetch_row() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 208
ERROR - 2017-09-11 16:26:04 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:26:04 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 228
INFO - 2017-09-11 16:26:04 --> Final output sent to browser
DEBUG - 2017-09-11 16:26:04 --> Total execution time: 0.0732
INFO - 2017-09-11 12:57:28 --> Config Class Initialized
INFO - 2017-09-11 12:57:28 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:57:28 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:57:28 --> Utf8 Class Initialized
INFO - 2017-09-11 12:57:28 --> URI Class Initialized
INFO - 2017-09-11 12:57:28 --> Router Class Initialized
INFO - 2017-09-11 12:57:28 --> Output Class Initialized
INFO - 2017-09-11 12:57:28 --> Security Class Initialized
DEBUG - 2017-09-11 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:57:28 --> Input Class Initialized
INFO - 2017-09-11 12:57:28 --> Language Class Initialized
INFO - 2017-09-11 12:57:28 --> Loader Class Initialized
INFO - 2017-09-11 12:57:28 --> Helper loaded: common_helper
INFO - 2017-09-11 12:57:28 --> Database Driver Class Initialized
INFO - 2017-09-11 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:57:28 --> Email Class Initialized
INFO - 2017-09-11 12:57:28 --> Controller Class Initialized
INFO - 2017-09-11 12:57:28 --> Helper loaded: form_helper
INFO - 2017-09-11 12:57:28 --> Form Validation Class Initialized
INFO - 2017-09-11 12:57:28 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:57:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:57:28 --> Helper loaded: url_helper
INFO - 2017-09-11 12:57:28 --> Model Class Initialized
INFO - 2017-09-11 12:57:28 --> Model Class Initialized
INFO - 2017-09-11 12:57:28 --> Model Class Initialized
INFO - 2017-09-11 16:27:28 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:27:28 --> mysqli_connect(): (HY000/1049): Unknown database 'flciknews'
ERROR - 2017-09-11 16:27:28 --> Severity: Warning --> mysqli_connect(): (HY000/1049): Unknown database 'flciknews' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 198
INFO - 2017-09-11 12:57:42 --> Config Class Initialized
INFO - 2017-09-11 12:57:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:57:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:57:42 --> Utf8 Class Initialized
INFO - 2017-09-11 12:57:42 --> URI Class Initialized
INFO - 2017-09-11 12:57:42 --> Router Class Initialized
INFO - 2017-09-11 12:57:42 --> Output Class Initialized
INFO - 2017-09-11 12:57:42 --> Security Class Initialized
DEBUG - 2017-09-11 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:57:42 --> Input Class Initialized
INFO - 2017-09-11 12:57:42 --> Language Class Initialized
INFO - 2017-09-11 12:57:42 --> Loader Class Initialized
INFO - 2017-09-11 12:57:42 --> Helper loaded: common_helper
INFO - 2017-09-11 12:57:42 --> Database Driver Class Initialized
INFO - 2017-09-11 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:57:42 --> Email Class Initialized
INFO - 2017-09-11 12:57:42 --> Controller Class Initialized
INFO - 2017-09-11 12:57:42 --> Helper loaded: form_helper
INFO - 2017-09-11 12:57:42 --> Form Validation Class Initialized
INFO - 2017-09-11 12:57:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:57:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:57:42 --> Helper loaded: url_helper
INFO - 2017-09-11 12:57:42 --> Model Class Initialized
INFO - 2017-09-11 12:57:42 --> Model Class Initialized
INFO - 2017-09-11 12:57:42 --> Model Class Initialized
INFO - 2017-09-11 16:27:42 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:27:42 --> mysqli_connect(): (HY000/1049): Unknown database 'flciknews'
ERROR - 2017-09-11 16:27:42 --> Severity: Warning --> mysqli_connect(): (HY000/1049): Unknown database 'flciknews' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 198
INFO - 2017-09-11 12:57:51 --> Config Class Initialized
INFO - 2017-09-11 12:57:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:57:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:57:51 --> Utf8 Class Initialized
INFO - 2017-09-11 12:57:51 --> URI Class Initialized
INFO - 2017-09-11 12:57:51 --> Router Class Initialized
INFO - 2017-09-11 12:57:51 --> Output Class Initialized
INFO - 2017-09-11 12:57:51 --> Security Class Initialized
DEBUG - 2017-09-11 12:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:57:51 --> Input Class Initialized
INFO - 2017-09-11 12:57:51 --> Language Class Initialized
INFO - 2017-09-11 12:57:51 --> Loader Class Initialized
INFO - 2017-09-11 12:57:51 --> Helper loaded: common_helper
INFO - 2017-09-11 12:57:51 --> Database Driver Class Initialized
INFO - 2017-09-11 12:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:57:51 --> Email Class Initialized
INFO - 2017-09-11 12:57:51 --> Controller Class Initialized
INFO - 2017-09-11 12:57:51 --> Helper loaded: form_helper
INFO - 2017-09-11 12:57:51 --> Form Validation Class Initialized
INFO - 2017-09-11 12:57:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:57:51 --> Helper loaded: url_helper
INFO - 2017-09-11 12:57:51 --> Model Class Initialized
INFO - 2017-09-11 12:57:51 --> Model Class Initialized
INFO - 2017-09-11 12:57:51 --> Model Class Initialized
INFO - 2017-09-11 16:27:51 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:27:51 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 212
ERROR - 2017-09-11 16:27:51 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 214
ERROR - 2017-09-11 16:27:51 --> mysql_fetch_row() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysql_fetch_row() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 218
ERROR - 2017-09-11 16:27:51 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 238
INFO - 2017-09-11 16:27:51 --> Final output sent to browser
DEBUG - 2017-09-11 16:27:51 --> Total execution time: 0.0500
INFO - 2017-09-11 12:57:51 --> Config Class Initialized
INFO - 2017-09-11 12:57:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:57:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:57:51 --> Utf8 Class Initialized
INFO - 2017-09-11 12:57:51 --> URI Class Initialized
INFO - 2017-09-11 12:57:51 --> Router Class Initialized
INFO - 2017-09-11 12:57:51 --> Output Class Initialized
INFO - 2017-09-11 12:57:51 --> Security Class Initialized
DEBUG - 2017-09-11 12:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:57:51 --> Input Class Initialized
INFO - 2017-09-11 12:57:51 --> Language Class Initialized
INFO - 2017-09-11 12:57:51 --> Loader Class Initialized
INFO - 2017-09-11 12:57:51 --> Helper loaded: common_helper
INFO - 2017-09-11 12:57:51 --> Database Driver Class Initialized
INFO - 2017-09-11 12:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:57:51 --> Email Class Initialized
INFO - 2017-09-11 12:57:51 --> Controller Class Initialized
INFO - 2017-09-11 12:57:51 --> Helper loaded: form_helper
INFO - 2017-09-11 12:57:51 --> Form Validation Class Initialized
INFO - 2017-09-11 12:57:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:57:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:57:51 --> Helper loaded: url_helper
INFO - 2017-09-11 12:57:51 --> Model Class Initialized
INFO - 2017-09-11 12:57:51 --> Model Class Initialized
INFO - 2017-09-11 12:57:51 --> Model Class Initialized
INFO - 2017-09-11 16:27:51 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:27:51 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 212
ERROR - 2017-09-11 16:27:51 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 214
ERROR - 2017-09-11 16:27:51 --> mysql_fetch_row() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysql_fetch_row() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 218
ERROR - 2017-09-11 16:27:51 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:51 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 238
INFO - 2017-09-11 16:27:51 --> Final output sent to browser
DEBUG - 2017-09-11 16:27:51 --> Total execution time: 0.0609
INFO - 2017-09-11 12:57:56 --> Config Class Initialized
INFO - 2017-09-11 12:57:56 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:57:56 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:57:56 --> Utf8 Class Initialized
INFO - 2017-09-11 12:57:56 --> URI Class Initialized
INFO - 2017-09-11 12:57:56 --> Router Class Initialized
INFO - 2017-09-11 12:57:56 --> Output Class Initialized
INFO - 2017-09-11 12:57:56 --> Security Class Initialized
DEBUG - 2017-09-11 12:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:57:56 --> Input Class Initialized
INFO - 2017-09-11 12:57:56 --> Language Class Initialized
INFO - 2017-09-11 12:57:56 --> Loader Class Initialized
INFO - 2017-09-11 12:57:56 --> Helper loaded: common_helper
INFO - 2017-09-11 12:57:56 --> Database Driver Class Initialized
INFO - 2017-09-11 12:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:57:56 --> Email Class Initialized
INFO - 2017-09-11 12:57:56 --> Controller Class Initialized
INFO - 2017-09-11 12:57:56 --> Helper loaded: form_helper
INFO - 2017-09-11 12:57:56 --> Form Validation Class Initialized
INFO - 2017-09-11 12:57:56 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:57:56 --> Helper loaded: url_helper
INFO - 2017-09-11 12:57:56 --> Model Class Initialized
INFO - 2017-09-11 12:57:56 --> Model Class Initialized
INFO - 2017-09-11 12:57:56 --> Model Class Initialized
INFO - 2017-09-11 16:27:56 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:27:56 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:27:56 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 211
ERROR - 2017-09-11 16:27:56 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:56 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:27:56 --> mysql_fetch_row() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:56 --> Severity: Warning --> mysql_fetch_row() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 217
ERROR - 2017-09-11 16:27:56 --> mysql_num_fields() expects parameter 1 to be resource, null given
ERROR - 2017-09-11 16:27:56 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, null given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 237
INFO - 2017-09-11 16:27:56 --> Final output sent to browser
DEBUG - 2017-09-11 16:27:56 --> Total execution time: 0.0656
INFO - 2017-09-11 12:58:15 --> Config Class Initialized
INFO - 2017-09-11 12:58:15 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:58:15 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:58:15 --> Utf8 Class Initialized
INFO - 2017-09-11 12:58:15 --> URI Class Initialized
INFO - 2017-09-11 12:58:15 --> Router Class Initialized
INFO - 2017-09-11 12:58:15 --> Output Class Initialized
INFO - 2017-09-11 12:58:15 --> Security Class Initialized
DEBUG - 2017-09-11 12:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:58:15 --> Input Class Initialized
INFO - 2017-09-11 12:58:15 --> Language Class Initialized
INFO - 2017-09-11 12:58:15 --> Loader Class Initialized
INFO - 2017-09-11 12:58:15 --> Helper loaded: common_helper
INFO - 2017-09-11 12:58:15 --> Database Driver Class Initialized
INFO - 2017-09-11 12:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:58:15 --> Email Class Initialized
INFO - 2017-09-11 12:58:15 --> Controller Class Initialized
INFO - 2017-09-11 12:58:15 --> Helper loaded: form_helper
INFO - 2017-09-11 12:58:15 --> Form Validation Class Initialized
INFO - 2017-09-11 12:58:15 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:58:15 --> Helper loaded: url_helper
INFO - 2017-09-11 12:58:15 --> Model Class Initialized
INFO - 2017-09-11 12:58:15 --> Model Class Initialized
INFO - 2017-09-11 12:58:15 --> Model Class Initialized
INFO - 2017-09-11 16:28:15 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:28:15 --> mysqli_query() expects at least 2 parameters, 1 given
ERROR - 2017-09-11 16:28:15 --> Severity: Warning --> mysqli_query() expects at least 2 parameters, 1 given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 209
INFO - 2017-09-11 12:58:39 --> Config Class Initialized
INFO - 2017-09-11 12:58:39 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:58:39 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:58:39 --> Utf8 Class Initialized
INFO - 2017-09-11 12:58:39 --> URI Class Initialized
INFO - 2017-09-11 12:58:39 --> Router Class Initialized
INFO - 2017-09-11 12:58:39 --> Output Class Initialized
INFO - 2017-09-11 12:58:39 --> Security Class Initialized
DEBUG - 2017-09-11 12:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:58:39 --> Input Class Initialized
INFO - 2017-09-11 12:58:39 --> Language Class Initialized
INFO - 2017-09-11 12:58:39 --> Loader Class Initialized
INFO - 2017-09-11 12:58:39 --> Helper loaded: common_helper
INFO - 2017-09-11 12:58:39 --> Database Driver Class Initialized
INFO - 2017-09-11 12:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:58:39 --> Email Class Initialized
INFO - 2017-09-11 12:58:39 --> Controller Class Initialized
INFO - 2017-09-11 12:58:39 --> Helper loaded: form_helper
INFO - 2017-09-11 12:58:39 --> Form Validation Class Initialized
INFO - 2017-09-11 12:58:39 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:58:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:58:39 --> Helper loaded: url_helper
INFO - 2017-09-11 12:58:39 --> Model Class Initialized
INFO - 2017-09-11 12:58:39 --> Model Class Initialized
INFO - 2017-09-11 12:58:39 --> Model Class Initialized
INFO - 2017-09-11 16:28:39 --> Helper loaded: download_helper
INFO - 2017-09-11 12:58:56 --> Config Class Initialized
INFO - 2017-09-11 12:58:56 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:58:56 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:58:56 --> Utf8 Class Initialized
INFO - 2017-09-11 12:58:56 --> URI Class Initialized
INFO - 2017-09-11 12:58:56 --> Router Class Initialized
INFO - 2017-09-11 12:58:56 --> Output Class Initialized
INFO - 2017-09-11 12:58:56 --> Security Class Initialized
DEBUG - 2017-09-11 12:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:58:56 --> Input Class Initialized
INFO - 2017-09-11 12:58:56 --> Language Class Initialized
INFO - 2017-09-11 12:58:56 --> Loader Class Initialized
INFO - 2017-09-11 12:58:56 --> Helper loaded: common_helper
INFO - 2017-09-11 12:58:56 --> Database Driver Class Initialized
INFO - 2017-09-11 12:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:58:56 --> Email Class Initialized
INFO - 2017-09-11 12:58:56 --> Controller Class Initialized
INFO - 2017-09-11 12:58:56 --> Helper loaded: form_helper
INFO - 2017-09-11 12:58:56 --> Form Validation Class Initialized
INFO - 2017-09-11 12:58:56 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:58:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:58:56 --> Helper loaded: url_helper
INFO - 2017-09-11 12:58:56 --> Model Class Initialized
INFO - 2017-09-11 12:58:56 --> Model Class Initialized
INFO - 2017-09-11 12:58:56 --> Model Class Initialized
INFO - 2017-09-11 16:28:56 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:28:56 --> mysql_num_fields() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:28:56 --> Severity: Warning --> mysql_num_fields() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 211
INFO - 2017-09-11 12:59:06 --> Config Class Initialized
INFO - 2017-09-11 12:59:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:59:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:59:06 --> Utf8 Class Initialized
INFO - 2017-09-11 12:59:06 --> URI Class Initialized
INFO - 2017-09-11 12:59:06 --> Router Class Initialized
INFO - 2017-09-11 12:59:06 --> Output Class Initialized
INFO - 2017-09-11 12:59:06 --> Security Class Initialized
DEBUG - 2017-09-11 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:59:06 --> Input Class Initialized
INFO - 2017-09-11 12:59:06 --> Language Class Initialized
INFO - 2017-09-11 12:59:06 --> Loader Class Initialized
INFO - 2017-09-11 12:59:06 --> Helper loaded: common_helper
INFO - 2017-09-11 12:59:06 --> Database Driver Class Initialized
INFO - 2017-09-11 12:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:59:06 --> Email Class Initialized
INFO - 2017-09-11 12:59:06 --> Controller Class Initialized
INFO - 2017-09-11 12:59:06 --> Helper loaded: form_helper
INFO - 2017-09-11 12:59:06 --> Form Validation Class Initialized
INFO - 2017-09-11 12:59:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:59:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:59:06 --> Helper loaded: url_helper
INFO - 2017-09-11 12:59:06 --> Model Class Initialized
INFO - 2017-09-11 12:59:06 --> Model Class Initialized
INFO - 2017-09-11 12:59:06 --> Model Class Initialized
INFO - 2017-09-11 16:29:06 --> Helper loaded: download_helper
INFO - 2017-09-11 12:59:36 --> Config Class Initialized
INFO - 2017-09-11 12:59:36 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:59:36 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:59:36 --> Utf8 Class Initialized
INFO - 2017-09-11 12:59:36 --> URI Class Initialized
INFO - 2017-09-11 12:59:36 --> Router Class Initialized
INFO - 2017-09-11 12:59:36 --> Output Class Initialized
INFO - 2017-09-11 12:59:36 --> Security Class Initialized
DEBUG - 2017-09-11 12:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:59:36 --> Input Class Initialized
INFO - 2017-09-11 12:59:36 --> Language Class Initialized
INFO - 2017-09-11 12:59:36 --> Loader Class Initialized
INFO - 2017-09-11 12:59:36 --> Helper loaded: common_helper
INFO - 2017-09-11 12:59:36 --> Database Driver Class Initialized
INFO - 2017-09-11 12:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:59:36 --> Email Class Initialized
INFO - 2017-09-11 12:59:36 --> Controller Class Initialized
INFO - 2017-09-11 12:59:36 --> Helper loaded: form_helper
INFO - 2017-09-11 12:59:36 --> Form Validation Class Initialized
INFO - 2017-09-11 12:59:36 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:59:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:59:36 --> Helper loaded: url_helper
INFO - 2017-09-11 12:59:36 --> Model Class Initialized
INFO - 2017-09-11 12:59:36 --> Model Class Initialized
INFO - 2017-09-11 12:59:36 --> Model Class Initialized
INFO - 2017-09-11 16:29:36 --> Helper loaded: download_helper
INFO - 2017-09-11 12:59:52 --> Config Class Initialized
INFO - 2017-09-11 12:59:52 --> Hooks Class Initialized
DEBUG - 2017-09-11 12:59:52 --> UTF-8 Support Enabled
INFO - 2017-09-11 12:59:52 --> Utf8 Class Initialized
INFO - 2017-09-11 12:59:52 --> URI Class Initialized
INFO - 2017-09-11 12:59:52 --> Router Class Initialized
INFO - 2017-09-11 12:59:52 --> Output Class Initialized
INFO - 2017-09-11 12:59:52 --> Security Class Initialized
DEBUG - 2017-09-11 12:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 12:59:52 --> Input Class Initialized
INFO - 2017-09-11 12:59:52 --> Language Class Initialized
INFO - 2017-09-11 12:59:52 --> Loader Class Initialized
INFO - 2017-09-11 12:59:52 --> Helper loaded: common_helper
INFO - 2017-09-11 12:59:52 --> Database Driver Class Initialized
INFO - 2017-09-11 12:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 12:59:52 --> Email Class Initialized
INFO - 2017-09-11 12:59:52 --> Controller Class Initialized
INFO - 2017-09-11 12:59:52 --> Helper loaded: form_helper
INFO - 2017-09-11 12:59:52 --> Form Validation Class Initialized
INFO - 2017-09-11 12:59:52 --> Helper loaded: email_helper
DEBUG - 2017-09-11 12:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 12:59:52 --> Helper loaded: url_helper
INFO - 2017-09-11 12:59:52 --> Model Class Initialized
INFO - 2017-09-11 12:59:52 --> Model Class Initialized
INFO - 2017-09-11 12:59:52 --> Model Class Initialized
INFO - 2017-09-11 16:29:52 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:29:52 --> Call to undefined function mysqli_field_name()
ERROR - 2017-09-11 16:29:52 --> Severity: Error --> Call to undefined function mysqli_field_name() C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
INFO - 2017-09-11 13:00:40 --> Config Class Initialized
INFO - 2017-09-11 13:00:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:00:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:00:40 --> Utf8 Class Initialized
INFO - 2017-09-11 13:00:40 --> URI Class Initialized
INFO - 2017-09-11 13:00:40 --> Router Class Initialized
INFO - 2017-09-11 13:00:40 --> Output Class Initialized
INFO - 2017-09-11 13:00:40 --> Security Class Initialized
DEBUG - 2017-09-11 13:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:00:40 --> Input Class Initialized
INFO - 2017-09-11 13:00:40 --> Language Class Initialized
INFO - 2017-09-11 13:00:40 --> Loader Class Initialized
INFO - 2017-09-11 13:00:40 --> Helper loaded: common_helper
INFO - 2017-09-11 13:00:40 --> Database Driver Class Initialized
INFO - 2017-09-11 13:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:00:40 --> Email Class Initialized
INFO - 2017-09-11 13:00:40 --> Controller Class Initialized
INFO - 2017-09-11 13:00:40 --> Helper loaded: form_helper
INFO - 2017-09-11 13:00:40 --> Form Validation Class Initialized
INFO - 2017-09-11 13:00:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:00:40 --> Helper loaded: url_helper
INFO - 2017-09-11 13:00:40 --> Model Class Initialized
INFO - 2017-09-11 13:00:40 --> Model Class Initialized
INFO - 2017-09-11 13:00:40 --> Model Class Initialized
INFO - 2017-09-11 16:30:40 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:30:40 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:30:40 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
INFO - 2017-09-11 16:30:40 --> Final output sent to browser
DEBUG - 2017-09-11 16:30:40 --> Total execution time: 0.0587
INFO - 2017-09-11 13:04:29 --> Config Class Initialized
INFO - 2017-09-11 13:04:29 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:04:29 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:04:29 --> Utf8 Class Initialized
INFO - 2017-09-11 13:04:29 --> URI Class Initialized
INFO - 2017-09-11 13:04:29 --> Router Class Initialized
INFO - 2017-09-11 13:04:29 --> Output Class Initialized
INFO - 2017-09-11 13:04:29 --> Security Class Initialized
DEBUG - 2017-09-11 13:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:04:29 --> Input Class Initialized
INFO - 2017-09-11 13:04:29 --> Language Class Initialized
ERROR - 2017-09-11 13:04:29 --> syntax error, unexpected ';'
ERROR - 2017-09-11 13:04:29 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 244
INFO - 2017-09-11 13:04:31 --> Config Class Initialized
INFO - 2017-09-11 13:04:31 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:04:31 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:04:31 --> Utf8 Class Initialized
INFO - 2017-09-11 13:04:31 --> URI Class Initialized
INFO - 2017-09-11 13:04:31 --> Router Class Initialized
INFO - 2017-09-11 13:04:31 --> Output Class Initialized
INFO - 2017-09-11 13:04:31 --> Security Class Initialized
DEBUG - 2017-09-11 13:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:04:31 --> Input Class Initialized
INFO - 2017-09-11 13:04:31 --> Language Class Initialized
ERROR - 2017-09-11 13:04:31 --> syntax error, unexpected ';'
ERROR - 2017-09-11 13:04:31 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 244
INFO - 2017-09-11 13:04:42 --> Config Class Initialized
INFO - 2017-09-11 13:04:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:04:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:04:42 --> Utf8 Class Initialized
INFO - 2017-09-11 13:04:42 --> URI Class Initialized
INFO - 2017-09-11 13:04:42 --> Router Class Initialized
INFO - 2017-09-11 13:04:42 --> Output Class Initialized
INFO - 2017-09-11 13:04:42 --> Security Class Initialized
DEBUG - 2017-09-11 13:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:04:42 --> Input Class Initialized
INFO - 2017-09-11 13:04:42 --> Language Class Initialized
INFO - 2017-09-11 13:04:42 --> Loader Class Initialized
INFO - 2017-09-11 13:04:42 --> Helper loaded: common_helper
INFO - 2017-09-11 13:04:42 --> Database Driver Class Initialized
INFO - 2017-09-11 13:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:04:42 --> Email Class Initialized
INFO - 2017-09-11 13:04:42 --> Controller Class Initialized
INFO - 2017-09-11 13:04:42 --> Helper loaded: form_helper
INFO - 2017-09-11 13:04:42 --> Form Validation Class Initialized
INFO - 2017-09-11 13:04:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:04:42 --> Helper loaded: url_helper
INFO - 2017-09-11 13:04:42 --> Model Class Initialized
INFO - 2017-09-11 13:04:42 --> Model Class Initialized
INFO - 2017-09-11 13:04:42 --> Model Class Initialized
INFO - 2017-09-11 16:34:42 --> Helper loaded: download_helper
INFO - 2017-09-11 16:34:42 --> Final output sent to browser
DEBUG - 2017-09-11 16:34:42 --> Total execution time: 0.0626
INFO - 2017-09-11 13:04:42 --> Config Class Initialized
INFO - 2017-09-11 13:04:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:04:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:04:42 --> Utf8 Class Initialized
INFO - 2017-09-11 13:04:42 --> URI Class Initialized
INFO - 2017-09-11 13:04:42 --> Router Class Initialized
INFO - 2017-09-11 13:04:42 --> Output Class Initialized
INFO - 2017-09-11 13:04:42 --> Security Class Initialized
DEBUG - 2017-09-11 13:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:04:42 --> Input Class Initialized
INFO - 2017-09-11 13:04:42 --> Language Class Initialized
INFO - 2017-09-11 13:04:42 --> Loader Class Initialized
INFO - 2017-09-11 13:04:42 --> Helper loaded: common_helper
INFO - 2017-09-11 13:04:42 --> Database Driver Class Initialized
INFO - 2017-09-11 13:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:04:42 --> Email Class Initialized
INFO - 2017-09-11 13:04:42 --> Controller Class Initialized
INFO - 2017-09-11 13:04:42 --> Helper loaded: form_helper
INFO - 2017-09-11 13:04:42 --> Form Validation Class Initialized
INFO - 2017-09-11 13:04:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:04:42 --> Helper loaded: url_helper
INFO - 2017-09-11 13:04:42 --> Model Class Initialized
INFO - 2017-09-11 13:04:42 --> Model Class Initialized
INFO - 2017-09-11 13:04:42 --> Model Class Initialized
INFO - 2017-09-11 16:34:42 --> Helper loaded: download_helper
INFO - 2017-09-11 16:34:42 --> Final output sent to browser
DEBUG - 2017-09-11 16:34:42 --> Total execution time: 0.0625
INFO - 2017-09-11 13:04:47 --> Config Class Initialized
INFO - 2017-09-11 13:04:47 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:04:47 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:04:47 --> Utf8 Class Initialized
INFO - 2017-09-11 13:04:47 --> URI Class Initialized
INFO - 2017-09-11 13:04:47 --> Router Class Initialized
INFO - 2017-09-11 13:04:47 --> Output Class Initialized
INFO - 2017-09-11 13:04:47 --> Security Class Initialized
DEBUG - 2017-09-11 13:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:04:47 --> Input Class Initialized
INFO - 2017-09-11 13:04:47 --> Language Class Initialized
INFO - 2017-09-11 13:04:47 --> Loader Class Initialized
INFO - 2017-09-11 13:04:47 --> Helper loaded: common_helper
INFO - 2017-09-11 13:04:47 --> Database Driver Class Initialized
INFO - 2017-09-11 13:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:04:47 --> Email Class Initialized
INFO - 2017-09-11 13:04:47 --> Controller Class Initialized
INFO - 2017-09-11 13:04:47 --> Helper loaded: form_helper
INFO - 2017-09-11 13:04:47 --> Form Validation Class Initialized
INFO - 2017-09-11 13:04:47 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:04:47 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:04:47 --> Helper loaded: url_helper
INFO - 2017-09-11 13:04:47 --> Model Class Initialized
INFO - 2017-09-11 13:04:47 --> Model Class Initialized
INFO - 2017-09-11 13:04:47 --> Model Class Initialized
INFO - 2017-09-11 16:34:47 --> Helper loaded: download_helper
INFO - 2017-09-11 16:34:47 --> Final output sent to browser
DEBUG - 2017-09-11 16:34:47 --> Total execution time: 0.0619
INFO - 2017-09-11 13:05:01 --> Config Class Initialized
INFO - 2017-09-11 13:05:01 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:01 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:01 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:01 --> URI Class Initialized
INFO - 2017-09-11 13:05:01 --> Router Class Initialized
INFO - 2017-09-11 13:05:01 --> Output Class Initialized
INFO - 2017-09-11 13:05:01 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:01 --> Input Class Initialized
INFO - 2017-09-11 13:05:01 --> Language Class Initialized
INFO - 2017-09-11 13:05:01 --> Loader Class Initialized
INFO - 2017-09-11 13:05:01 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:01 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:01 --> Email Class Initialized
INFO - 2017-09-11 13:05:01 --> Controller Class Initialized
INFO - 2017-09-11 13:05:01 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:01 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:01 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:01 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:01 --> Model Class Initialized
INFO - 2017-09-11 13:05:01 --> Model Class Initialized
INFO - 2017-09-11 13:05:01 --> Model Class Initialized
INFO - 2017-09-11 16:35:01 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:35:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:35:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
INFO - 2017-09-11 16:35:01 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:01 --> Total execution time: 0.0593
INFO - 2017-09-11 13:05:11 --> Config Class Initialized
INFO - 2017-09-11 13:05:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:11 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:11 --> URI Class Initialized
INFO - 2017-09-11 13:05:11 --> Router Class Initialized
INFO - 2017-09-11 13:05:11 --> Output Class Initialized
INFO - 2017-09-11 13:05:11 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:11 --> Input Class Initialized
INFO - 2017-09-11 13:05:11 --> Language Class Initialized
INFO - 2017-09-11 13:05:11 --> Loader Class Initialized
INFO - 2017-09-11 13:05:11 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:11 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:11 --> Email Class Initialized
INFO - 2017-09-11 13:05:11 --> Controller Class Initialized
INFO - 2017-09-11 13:05:11 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:11 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:11 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:11 --> Model Class Initialized
INFO - 2017-09-11 13:05:11 --> Model Class Initialized
INFO - 2017-09-11 13:05:11 --> Model Class Initialized
INFO - 2017-09-11 16:35:11 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:11 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:11 --> Total execution time: 0.0457
INFO - 2017-09-11 13:05:12 --> Config Class Initialized
INFO - 2017-09-11 13:05:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:12 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:12 --> URI Class Initialized
INFO - 2017-09-11 13:05:12 --> Router Class Initialized
INFO - 2017-09-11 13:05:12 --> Output Class Initialized
INFO - 2017-09-11 13:05:12 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:12 --> Input Class Initialized
INFO - 2017-09-11 13:05:12 --> Language Class Initialized
INFO - 2017-09-11 13:05:12 --> Loader Class Initialized
INFO - 2017-09-11 13:05:12 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:12 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:12 --> Email Class Initialized
INFO - 2017-09-11 13:05:12 --> Controller Class Initialized
INFO - 2017-09-11 13:05:12 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:12 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:12 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:12 --> Model Class Initialized
INFO - 2017-09-11 13:05:12 --> Model Class Initialized
INFO - 2017-09-11 13:05:12 --> Model Class Initialized
INFO - 2017-09-11 16:35:12 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:12 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:12 --> Total execution time: 0.0452
INFO - 2017-09-11 13:05:20 --> Config Class Initialized
INFO - 2017-09-11 13:05:20 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:20 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:20 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:20 --> URI Class Initialized
INFO - 2017-09-11 13:05:20 --> Router Class Initialized
INFO - 2017-09-11 13:05:20 --> Output Class Initialized
INFO - 2017-09-11 13:05:20 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:20 --> Input Class Initialized
INFO - 2017-09-11 13:05:20 --> Language Class Initialized
INFO - 2017-09-11 13:05:20 --> Loader Class Initialized
INFO - 2017-09-11 13:05:20 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:20 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:20 --> Email Class Initialized
INFO - 2017-09-11 13:05:20 --> Controller Class Initialized
INFO - 2017-09-11 13:05:20 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:20 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:20 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:20 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:20 --> Model Class Initialized
INFO - 2017-09-11 13:05:20 --> Model Class Initialized
INFO - 2017-09-11 13:05:20 --> Model Class Initialized
INFO - 2017-09-11 16:35:20 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:20 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:20 --> Total execution time: 0.0457
INFO - 2017-09-11 13:05:21 --> Config Class Initialized
INFO - 2017-09-11 13:05:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:21 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:21 --> URI Class Initialized
INFO - 2017-09-11 13:05:21 --> Router Class Initialized
INFO - 2017-09-11 13:05:21 --> Output Class Initialized
INFO - 2017-09-11 13:05:21 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:21 --> Input Class Initialized
INFO - 2017-09-11 13:05:21 --> Language Class Initialized
INFO - 2017-09-11 13:05:21 --> Loader Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:21 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:21 --> Email Class Initialized
INFO - 2017-09-11 13:05:21 --> Controller Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:21 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:21 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 16:35:21 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:21 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:21 --> Total execution time: 0.0458
INFO - 2017-09-11 13:05:21 --> Config Class Initialized
INFO - 2017-09-11 13:05:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:21 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:21 --> URI Class Initialized
INFO - 2017-09-11 13:05:21 --> Router Class Initialized
INFO - 2017-09-11 13:05:21 --> Output Class Initialized
INFO - 2017-09-11 13:05:21 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:21 --> Input Class Initialized
INFO - 2017-09-11 13:05:21 --> Language Class Initialized
INFO - 2017-09-11 13:05:21 --> Loader Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:21 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:21 --> Email Class Initialized
INFO - 2017-09-11 13:05:21 --> Controller Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:21 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:21 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 16:35:21 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:21 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:21 --> Total execution time: 0.0457
INFO - 2017-09-11 13:05:21 --> Config Class Initialized
INFO - 2017-09-11 13:05:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:21 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:21 --> URI Class Initialized
INFO - 2017-09-11 13:05:21 --> Router Class Initialized
INFO - 2017-09-11 13:05:21 --> Output Class Initialized
INFO - 2017-09-11 13:05:21 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:21 --> Input Class Initialized
INFO - 2017-09-11 13:05:21 --> Language Class Initialized
INFO - 2017-09-11 13:05:21 --> Loader Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:21 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:21 --> Email Class Initialized
INFO - 2017-09-11 13:05:21 --> Controller Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:21 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:21 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 13:05:21 --> Model Class Initialized
INFO - 2017-09-11 16:35:21 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:21 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:21 --> Total execution time: 0.0477
INFO - 2017-09-11 13:05:22 --> Config Class Initialized
INFO - 2017-09-11 13:05:22 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:22 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:22 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:22 --> URI Class Initialized
INFO - 2017-09-11 13:05:22 --> Router Class Initialized
INFO - 2017-09-11 13:05:22 --> Output Class Initialized
INFO - 2017-09-11 13:05:22 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:22 --> Input Class Initialized
INFO - 2017-09-11 13:05:22 --> Language Class Initialized
INFO - 2017-09-11 13:05:22 --> Loader Class Initialized
INFO - 2017-09-11 13:05:22 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:22 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:22 --> Email Class Initialized
INFO - 2017-09-11 13:05:22 --> Controller Class Initialized
INFO - 2017-09-11 13:05:22 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:22 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:22 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:22 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:22 --> Model Class Initialized
INFO - 2017-09-11 13:05:22 --> Model Class Initialized
INFO - 2017-09-11 13:05:22 --> Model Class Initialized
INFO - 2017-09-11 16:35:22 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:22 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:22 --> Total execution time: 0.0473
INFO - 2017-09-11 13:05:22 --> Config Class Initialized
INFO - 2017-09-11 13:05:22 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:22 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:22 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:22 --> URI Class Initialized
INFO - 2017-09-11 13:05:22 --> Router Class Initialized
INFO - 2017-09-11 13:05:22 --> Output Class Initialized
INFO - 2017-09-11 13:05:22 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:22 --> Input Class Initialized
INFO - 2017-09-11 13:05:22 --> Language Class Initialized
INFO - 2017-09-11 13:05:22 --> Loader Class Initialized
INFO - 2017-09-11 13:05:22 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:22 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:22 --> Email Class Initialized
INFO - 2017-09-11 13:05:22 --> Controller Class Initialized
INFO - 2017-09-11 13:05:22 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:22 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:22 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:22 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:22 --> Model Class Initialized
INFO - 2017-09-11 13:05:22 --> Model Class Initialized
INFO - 2017-09-11 13:05:22 --> Model Class Initialized
INFO - 2017-09-11 16:35:22 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:22 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:22 --> Total execution time: 0.0475
INFO - 2017-09-11 13:05:52 --> Config Class Initialized
INFO - 2017-09-11 13:05:52 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:05:52 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:05:52 --> Utf8 Class Initialized
INFO - 2017-09-11 13:05:52 --> URI Class Initialized
INFO - 2017-09-11 13:05:52 --> Router Class Initialized
INFO - 2017-09-11 13:05:52 --> Output Class Initialized
INFO - 2017-09-11 13:05:52 --> Security Class Initialized
DEBUG - 2017-09-11 13:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:05:52 --> Input Class Initialized
INFO - 2017-09-11 13:05:52 --> Language Class Initialized
INFO - 2017-09-11 13:05:52 --> Loader Class Initialized
INFO - 2017-09-11 13:05:52 --> Helper loaded: common_helper
INFO - 2017-09-11 13:05:52 --> Database Driver Class Initialized
INFO - 2017-09-11 13:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:05:52 --> Email Class Initialized
INFO - 2017-09-11 13:05:52 --> Controller Class Initialized
INFO - 2017-09-11 13:05:52 --> Helper loaded: form_helper
INFO - 2017-09-11 13:05:52 --> Form Validation Class Initialized
INFO - 2017-09-11 13:05:52 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:05:52 --> Helper loaded: url_helper
INFO - 2017-09-11 13:05:52 --> Model Class Initialized
INFO - 2017-09-11 13:05:52 --> Model Class Initialized
INFO - 2017-09-11 13:05:52 --> Model Class Initialized
INFO - 2017-09-11 16:35:52 --> Helper loaded: download_helper
INFO - 2017-09-11 16:35:52 --> Final output sent to browser
DEBUG - 2017-09-11 16:35:52 --> Total execution time: 0.0714
INFO - 2017-09-11 13:06:15 --> Config Class Initialized
INFO - 2017-09-11 13:06:15 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:15 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:15 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:15 --> URI Class Initialized
INFO - 2017-09-11 13:06:15 --> Router Class Initialized
INFO - 2017-09-11 13:06:15 --> Output Class Initialized
INFO - 2017-09-11 13:06:15 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:15 --> Input Class Initialized
INFO - 2017-09-11 13:06:15 --> Language Class Initialized
INFO - 2017-09-11 13:06:15 --> Loader Class Initialized
INFO - 2017-09-11 13:06:15 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:15 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:15 --> Email Class Initialized
INFO - 2017-09-11 13:06:15 --> Controller Class Initialized
INFO - 2017-09-11 13:06:15 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:15 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:15 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:15 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:15 --> Model Class Initialized
INFO - 2017-09-11 13:06:15 --> Model Class Initialized
INFO - 2017-09-11 13:06:15 --> Model Class Initialized
INFO - 2017-09-11 16:36:15 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:15 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:15 --> Total execution time: 0.0464
INFO - 2017-09-11 13:06:16 --> Config Class Initialized
INFO - 2017-09-11 13:06:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:16 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:16 --> URI Class Initialized
INFO - 2017-09-11 13:06:16 --> Router Class Initialized
INFO - 2017-09-11 13:06:16 --> Output Class Initialized
INFO - 2017-09-11 13:06:16 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:16 --> Input Class Initialized
INFO - 2017-09-11 13:06:16 --> Language Class Initialized
INFO - 2017-09-11 13:06:16 --> Loader Class Initialized
INFO - 2017-09-11 13:06:16 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:16 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:16 --> Email Class Initialized
INFO - 2017-09-11 13:06:16 --> Controller Class Initialized
INFO - 2017-09-11 13:06:16 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:16 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:16 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:16 --> Model Class Initialized
INFO - 2017-09-11 13:06:16 --> Model Class Initialized
INFO - 2017-09-11 13:06:16 --> Model Class Initialized
INFO - 2017-09-11 16:36:16 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:16 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:16 --> Total execution time: 0.0553
INFO - 2017-09-11 13:06:16 --> Config Class Initialized
INFO - 2017-09-11 13:06:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:16 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:16 --> URI Class Initialized
INFO - 2017-09-11 13:06:16 --> Router Class Initialized
INFO - 2017-09-11 13:06:16 --> Output Class Initialized
INFO - 2017-09-11 13:06:16 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:16 --> Input Class Initialized
INFO - 2017-09-11 13:06:16 --> Language Class Initialized
INFO - 2017-09-11 13:06:16 --> Loader Class Initialized
INFO - 2017-09-11 13:06:16 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:16 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:17 --> Email Class Initialized
INFO - 2017-09-11 13:06:17 --> Controller Class Initialized
INFO - 2017-09-11 13:06:17 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:17 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:17 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:17 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:17 --> Model Class Initialized
INFO - 2017-09-11 13:06:17 --> Model Class Initialized
INFO - 2017-09-11 13:06:17 --> Model Class Initialized
INFO - 2017-09-11 16:36:17 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:17 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:17 --> Total execution time: 0.0510
INFO - 2017-09-11 13:06:17 --> Config Class Initialized
INFO - 2017-09-11 13:06:17 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:17 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:17 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:17 --> URI Class Initialized
INFO - 2017-09-11 13:06:17 --> Router Class Initialized
INFO - 2017-09-11 13:06:17 --> Output Class Initialized
INFO - 2017-09-11 13:06:17 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:17 --> Input Class Initialized
INFO - 2017-09-11 13:06:17 --> Language Class Initialized
INFO - 2017-09-11 13:06:17 --> Loader Class Initialized
INFO - 2017-09-11 13:06:17 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:17 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:17 --> Email Class Initialized
INFO - 2017-09-11 13:06:17 --> Controller Class Initialized
INFO - 2017-09-11 13:06:17 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:17 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:17 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:17 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:17 --> Model Class Initialized
INFO - 2017-09-11 13:06:17 --> Model Class Initialized
INFO - 2017-09-11 13:06:17 --> Model Class Initialized
INFO - 2017-09-11 16:36:17 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:17 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:17 --> Total execution time: 0.0466
INFO - 2017-09-11 13:06:50 --> Config Class Initialized
INFO - 2017-09-11 13:06:50 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:50 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:50 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:50 --> URI Class Initialized
INFO - 2017-09-11 13:06:50 --> Router Class Initialized
INFO - 2017-09-11 13:06:50 --> Output Class Initialized
INFO - 2017-09-11 13:06:50 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:50 --> Input Class Initialized
INFO - 2017-09-11 13:06:50 --> Language Class Initialized
INFO - 2017-09-11 13:06:50 --> Loader Class Initialized
INFO - 2017-09-11 13:06:50 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:50 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:50 --> Email Class Initialized
INFO - 2017-09-11 13:06:50 --> Controller Class Initialized
INFO - 2017-09-11 13:06:50 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:50 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:50 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:50 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:50 --> Model Class Initialized
INFO - 2017-09-11 13:06:50 --> Model Class Initialized
INFO - 2017-09-11 13:06:50 --> Model Class Initialized
INFO - 2017-09-11 16:36:50 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:50 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:50 --> Total execution time: 0.0466
INFO - 2017-09-11 13:06:51 --> Config Class Initialized
INFO - 2017-09-11 13:06:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:51 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:51 --> URI Class Initialized
INFO - 2017-09-11 13:06:51 --> Router Class Initialized
INFO - 2017-09-11 13:06:51 --> Output Class Initialized
INFO - 2017-09-11 13:06:51 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:51 --> Input Class Initialized
INFO - 2017-09-11 13:06:51 --> Language Class Initialized
INFO - 2017-09-11 13:06:51 --> Loader Class Initialized
INFO - 2017-09-11 13:06:51 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:51 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:51 --> Email Class Initialized
INFO - 2017-09-11 13:06:51 --> Controller Class Initialized
INFO - 2017-09-11 13:06:51 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:51 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:51 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:51 --> Model Class Initialized
INFO - 2017-09-11 13:06:51 --> Model Class Initialized
INFO - 2017-09-11 13:06:51 --> Model Class Initialized
INFO - 2017-09-11 16:36:51 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:51 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:51 --> Total execution time: 0.0475
INFO - 2017-09-11 13:06:53 --> Config Class Initialized
INFO - 2017-09-11 13:06:53 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:06:53 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:06:53 --> Utf8 Class Initialized
INFO - 2017-09-11 13:06:53 --> URI Class Initialized
INFO - 2017-09-11 13:06:53 --> Router Class Initialized
INFO - 2017-09-11 13:06:53 --> Output Class Initialized
INFO - 2017-09-11 13:06:53 --> Security Class Initialized
DEBUG - 2017-09-11 13:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:06:53 --> Input Class Initialized
INFO - 2017-09-11 13:06:53 --> Language Class Initialized
INFO - 2017-09-11 13:06:53 --> Loader Class Initialized
INFO - 2017-09-11 13:06:53 --> Helper loaded: common_helper
INFO - 2017-09-11 13:06:53 --> Database Driver Class Initialized
INFO - 2017-09-11 13:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:06:53 --> Email Class Initialized
INFO - 2017-09-11 13:06:53 --> Controller Class Initialized
INFO - 2017-09-11 13:06:53 --> Helper loaded: form_helper
INFO - 2017-09-11 13:06:53 --> Form Validation Class Initialized
INFO - 2017-09-11 13:06:53 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:06:53 --> Helper loaded: url_helper
INFO - 2017-09-11 13:06:53 --> Model Class Initialized
INFO - 2017-09-11 13:06:53 --> Model Class Initialized
INFO - 2017-09-11 13:06:53 --> Model Class Initialized
INFO - 2017-09-11 16:36:53 --> Helper loaded: download_helper
INFO - 2017-09-11 16:36:53 --> Final output sent to browser
DEBUG - 2017-09-11 16:36:53 --> Total execution time: 0.0473
INFO - 2017-09-11 13:07:01 --> Config Class Initialized
INFO - 2017-09-11 13:07:01 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:01 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:01 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:01 --> URI Class Initialized
INFO - 2017-09-11 13:07:01 --> Router Class Initialized
INFO - 2017-09-11 13:07:01 --> Output Class Initialized
INFO - 2017-09-11 13:07:01 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:01 --> Input Class Initialized
INFO - 2017-09-11 13:07:01 --> Language Class Initialized
INFO - 2017-09-11 13:07:01 --> Loader Class Initialized
INFO - 2017-09-11 13:07:01 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:01 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:01 --> Email Class Initialized
INFO - 2017-09-11 13:07:01 --> Controller Class Initialized
INFO - 2017-09-11 13:07:01 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:01 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:01 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:01 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:01 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:01 --> Model Class Initialized
INFO - 2017-09-11 13:07:01 --> Model Class Initialized
INFO - 2017-09-11 13:07:01 --> Model Class Initialized
INFO - 2017-09-11 16:37:01 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
ERROR - 2017-09-11 16:37:01 --> mysql_field_name() expects parameter 1 to be resource, object given
ERROR - 2017-09-11 16:37:01 --> Severity: Warning --> mysql_field_name() expects parameter 1 to be resource, object given C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
INFO - 2017-09-11 16:37:01 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:01 --> Total execution time: 0.0609
INFO - 2017-09-11 13:07:33 --> Config Class Initialized
INFO - 2017-09-11 13:07:33 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:33 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:33 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:33 --> URI Class Initialized
INFO - 2017-09-11 13:07:33 --> Router Class Initialized
INFO - 2017-09-11 13:07:33 --> Output Class Initialized
INFO - 2017-09-11 13:07:33 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:33 --> Input Class Initialized
INFO - 2017-09-11 13:07:33 --> Language Class Initialized
INFO - 2017-09-11 13:07:33 --> Loader Class Initialized
INFO - 2017-09-11 13:07:33 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:33 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:33 --> Email Class Initialized
INFO - 2017-09-11 13:07:33 --> Controller Class Initialized
INFO - 2017-09-11 13:07:33 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:33 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:33 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:33 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:33 --> Model Class Initialized
INFO - 2017-09-11 13:07:33 --> Model Class Initialized
INFO - 2017-09-11 13:07:33 --> Model Class Initialized
INFO - 2017-09-11 16:37:33 --> Helper loaded: download_helper
INFO - 2017-09-11 16:37:33 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:33 --> Total execution time: 0.0559
INFO - 2017-09-11 13:07:34 --> Config Class Initialized
INFO - 2017-09-11 13:07:34 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:34 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:34 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:34 --> URI Class Initialized
INFO - 2017-09-11 13:07:34 --> Router Class Initialized
INFO - 2017-09-11 13:07:34 --> Output Class Initialized
INFO - 2017-09-11 13:07:34 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:34 --> Input Class Initialized
INFO - 2017-09-11 13:07:34 --> Language Class Initialized
INFO - 2017-09-11 13:07:34 --> Loader Class Initialized
INFO - 2017-09-11 13:07:34 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:34 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:34 --> Email Class Initialized
INFO - 2017-09-11 13:07:34 --> Controller Class Initialized
INFO - 2017-09-11 13:07:34 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:34 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:34 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:34 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:34 --> Model Class Initialized
INFO - 2017-09-11 13:07:34 --> Model Class Initialized
INFO - 2017-09-11 13:07:34 --> Model Class Initialized
INFO - 2017-09-11 16:37:34 --> Helper loaded: download_helper
INFO - 2017-09-11 16:37:34 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:34 --> Total execution time: 0.0547
INFO - 2017-09-11 13:07:35 --> Config Class Initialized
INFO - 2017-09-11 13:07:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:35 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:35 --> URI Class Initialized
INFO - 2017-09-11 13:07:35 --> Router Class Initialized
INFO - 2017-09-11 13:07:35 --> Output Class Initialized
INFO - 2017-09-11 13:07:35 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:35 --> Input Class Initialized
INFO - 2017-09-11 13:07:35 --> Language Class Initialized
INFO - 2017-09-11 13:07:35 --> Loader Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:35 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:35 --> Email Class Initialized
INFO - 2017-09-11 13:07:35 --> Controller Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:35 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:35 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 16:37:35 --> Helper loaded: download_helper
INFO - 2017-09-11 16:37:35 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:35 --> Total execution time: 0.0546
INFO - 2017-09-11 13:07:35 --> Config Class Initialized
INFO - 2017-09-11 13:07:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:35 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:35 --> URI Class Initialized
INFO - 2017-09-11 13:07:35 --> Router Class Initialized
INFO - 2017-09-11 13:07:35 --> Output Class Initialized
INFO - 2017-09-11 13:07:35 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:35 --> Input Class Initialized
INFO - 2017-09-11 13:07:35 --> Language Class Initialized
INFO - 2017-09-11 13:07:35 --> Loader Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:35 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:35 --> Email Class Initialized
INFO - 2017-09-11 13:07:35 --> Controller Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:35 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:35 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 16:37:35 --> Helper loaded: download_helper
INFO - 2017-09-11 16:37:35 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:35 --> Total execution time: 0.0459
INFO - 2017-09-11 13:07:35 --> Config Class Initialized
INFO - 2017-09-11 13:07:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:35 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:35 --> URI Class Initialized
INFO - 2017-09-11 13:07:35 --> Router Class Initialized
INFO - 2017-09-11 13:07:35 --> Output Class Initialized
INFO - 2017-09-11 13:07:35 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:35 --> Input Class Initialized
INFO - 2017-09-11 13:07:35 --> Language Class Initialized
INFO - 2017-09-11 13:07:35 --> Loader Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:35 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:35 --> Email Class Initialized
INFO - 2017-09-11 13:07:35 --> Controller Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:35 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:35 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 16:37:35 --> Helper loaded: download_helper
INFO - 2017-09-11 16:37:35 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:35 --> Total execution time: 0.0473
INFO - 2017-09-11 13:07:35 --> Config Class Initialized
INFO - 2017-09-11 13:07:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:07:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:07:35 --> Utf8 Class Initialized
INFO - 2017-09-11 13:07:35 --> URI Class Initialized
INFO - 2017-09-11 13:07:35 --> Router Class Initialized
INFO - 2017-09-11 13:07:35 --> Output Class Initialized
INFO - 2017-09-11 13:07:35 --> Security Class Initialized
DEBUG - 2017-09-11 13:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:07:35 --> Input Class Initialized
INFO - 2017-09-11 13:07:35 --> Language Class Initialized
INFO - 2017-09-11 13:07:35 --> Loader Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: common_helper
INFO - 2017-09-11 13:07:35 --> Database Driver Class Initialized
INFO - 2017-09-11 13:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:07:35 --> Email Class Initialized
INFO - 2017-09-11 13:07:35 --> Controller Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: form_helper
INFO - 2017-09-11 13:07:35 --> Form Validation Class Initialized
INFO - 2017-09-11 13:07:35 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:07:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:07:35 --> Helper loaded: url_helper
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 13:07:35 --> Model Class Initialized
INFO - 2017-09-11 16:37:35 --> Helper loaded: download_helper
INFO - 2017-09-11 16:37:35 --> Final output sent to browser
DEBUG - 2017-09-11 16:37:35 --> Total execution time: 0.0478
INFO - 2017-09-11 13:08:35 --> Config Class Initialized
INFO - 2017-09-11 13:08:35 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:08:35 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:08:35 --> Utf8 Class Initialized
INFO - 2017-09-11 13:08:35 --> URI Class Initialized
INFO - 2017-09-11 13:08:35 --> Router Class Initialized
INFO - 2017-09-11 13:08:35 --> Output Class Initialized
INFO - 2017-09-11 13:08:35 --> Security Class Initialized
DEBUG - 2017-09-11 13:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:08:35 --> Input Class Initialized
INFO - 2017-09-11 13:08:35 --> Language Class Initialized
ERROR - 2017-09-11 13:08:35 --> syntax error, unexpected 'for' (T_FOR)
ERROR - 2017-09-11 13:08:35 --> Severity: Parsing Error --> syntax error, unexpected 'for' (T_FOR) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 213
INFO - 2017-09-11 13:08:48 --> Config Class Initialized
INFO - 2017-09-11 13:08:48 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:08:48 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:08:48 --> Utf8 Class Initialized
INFO - 2017-09-11 13:08:48 --> URI Class Initialized
INFO - 2017-09-11 13:08:48 --> Router Class Initialized
INFO - 2017-09-11 13:08:48 --> Output Class Initialized
INFO - 2017-09-11 13:08:48 --> Security Class Initialized
DEBUG - 2017-09-11 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:08:48 --> Input Class Initialized
INFO - 2017-09-11 13:08:48 --> Language Class Initialized
INFO - 2017-09-11 13:08:48 --> Loader Class Initialized
INFO - 2017-09-11 13:08:48 --> Helper loaded: common_helper
INFO - 2017-09-11 13:08:48 --> Database Driver Class Initialized
INFO - 2017-09-11 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:08:48 --> Email Class Initialized
INFO - 2017-09-11 13:08:48 --> Controller Class Initialized
INFO - 2017-09-11 13:08:48 --> Helper loaded: form_helper
INFO - 2017-09-11 13:08:48 --> Form Validation Class Initialized
INFO - 2017-09-11 13:08:48 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:08:48 --> Helper loaded: url_helper
INFO - 2017-09-11 13:08:48 --> Model Class Initialized
INFO - 2017-09-11 13:08:48 --> Model Class Initialized
INFO - 2017-09-11 13:08:48 --> Model Class Initialized
INFO - 2017-09-11 16:38:48 --> Helper loaded: download_helper
INFO - 2017-09-11 13:20:00 --> Config Class Initialized
INFO - 2017-09-11 13:20:00 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:20:00 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:20:00 --> Utf8 Class Initialized
INFO - 2017-09-11 13:20:00 --> URI Class Initialized
INFO - 2017-09-11 13:20:00 --> Router Class Initialized
INFO - 2017-09-11 13:20:00 --> Output Class Initialized
INFO - 2017-09-11 13:20:00 --> Security Class Initialized
DEBUG - 2017-09-11 13:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:20:00 --> Input Class Initialized
INFO - 2017-09-11 13:20:00 --> Language Class Initialized
INFO - 2017-09-11 13:20:00 --> Loader Class Initialized
INFO - 2017-09-11 13:20:00 --> Helper loaded: common_helper
INFO - 2017-09-11 13:20:00 --> Database Driver Class Initialized
INFO - 2017-09-11 13:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:20:00 --> Email Class Initialized
INFO - 2017-09-11 13:20:00 --> Controller Class Initialized
INFO - 2017-09-11 13:20:00 --> Helper loaded: form_helper
INFO - 2017-09-11 13:20:00 --> Form Validation Class Initialized
INFO - 2017-09-11 13:20:00 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:20:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:20:00 --> Helper loaded: url_helper
INFO - 2017-09-11 13:20:00 --> Model Class Initialized
INFO - 2017-09-11 13:20:00 --> Model Class Initialized
INFO - 2017-09-11 13:20:00 --> Model Class Initialized
INFO - 2017-09-11 16:50:00 --> Helper loaded: download_helper
INFO - 2017-09-11 13:20:27 --> Config Class Initialized
INFO - 2017-09-11 13:20:27 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:20:27 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:20:27 --> Utf8 Class Initialized
INFO - 2017-09-11 13:20:27 --> URI Class Initialized
INFO - 2017-09-11 13:20:27 --> Router Class Initialized
INFO - 2017-09-11 13:20:27 --> Output Class Initialized
INFO - 2017-09-11 13:20:27 --> Security Class Initialized
DEBUG - 2017-09-11 13:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:20:27 --> Input Class Initialized
INFO - 2017-09-11 13:20:27 --> Language Class Initialized
INFO - 2017-09-11 13:20:27 --> Loader Class Initialized
INFO - 2017-09-11 13:20:27 --> Helper loaded: common_helper
INFO - 2017-09-11 13:20:27 --> Database Driver Class Initialized
INFO - 2017-09-11 13:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:20:27 --> Email Class Initialized
INFO - 2017-09-11 13:20:27 --> Controller Class Initialized
INFO - 2017-09-11 13:20:27 --> Helper loaded: form_helper
INFO - 2017-09-11 13:20:27 --> Form Validation Class Initialized
INFO - 2017-09-11 13:20:27 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:20:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:20:27 --> Helper loaded: url_helper
INFO - 2017-09-11 13:20:27 --> Model Class Initialized
INFO - 2017-09-11 13:20:27 --> Model Class Initialized
INFO - 2017-09-11 13:20:27 --> Model Class Initialized
INFO - 2017-09-11 16:50:27 --> Helper loaded: download_helper
INFO - 2017-09-11 13:22:15 --> Config Class Initialized
INFO - 2017-09-11 13:22:15 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:22:15 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:22:15 --> Utf8 Class Initialized
INFO - 2017-09-11 13:22:15 --> URI Class Initialized
INFO - 2017-09-11 13:22:15 --> Router Class Initialized
INFO - 2017-09-11 13:22:15 --> Output Class Initialized
INFO - 2017-09-11 13:22:15 --> Security Class Initialized
DEBUG - 2017-09-11 13:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:22:15 --> Input Class Initialized
INFO - 2017-09-11 13:22:15 --> Language Class Initialized
INFO - 2017-09-11 13:22:15 --> Loader Class Initialized
INFO - 2017-09-11 13:22:15 --> Helper loaded: common_helper
INFO - 2017-09-11 13:22:15 --> Database Driver Class Initialized
INFO - 2017-09-11 13:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:22:15 --> Email Class Initialized
INFO - 2017-09-11 13:22:15 --> Controller Class Initialized
INFO - 2017-09-11 13:22:15 --> Helper loaded: form_helper
INFO - 2017-09-11 13:22:15 --> Form Validation Class Initialized
INFO - 2017-09-11 13:22:15 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:22:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:22:15 --> Helper loaded: url_helper
INFO - 2017-09-11 13:22:15 --> Model Class Initialized
INFO - 2017-09-11 13:22:15 --> Model Class Initialized
INFO - 2017-09-11 13:22:15 --> Model Class Initialized
INFO - 2017-09-11 16:52:15 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:52:15 --> Exception: Unable to load template file: C:\xampp\htdocs\FlickNews\admin\application\controllersMyexcel.xlsx
ERROR - 2017-09-11 16:52:15 --> Severity: error --> Exception: Unable to load template file: C:\xampp\htdocs\FlickNews\admin\application\controllersMyexcel.xlsx C:\xampp\htdocs\FlickNews\admin\application\libraries\PHPReport\PHPReport.php 200
INFO - 2017-09-11 13:22:33 --> Config Class Initialized
INFO - 2017-09-11 13:22:33 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:22:33 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:22:33 --> Utf8 Class Initialized
INFO - 2017-09-11 13:22:33 --> URI Class Initialized
INFO - 2017-09-11 13:22:33 --> Router Class Initialized
INFO - 2017-09-11 13:22:33 --> Output Class Initialized
INFO - 2017-09-11 13:22:33 --> Security Class Initialized
DEBUG - 2017-09-11 13:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:22:33 --> Input Class Initialized
INFO - 2017-09-11 13:22:33 --> Language Class Initialized
INFO - 2017-09-11 13:22:33 --> Loader Class Initialized
INFO - 2017-09-11 13:22:33 --> Helper loaded: common_helper
INFO - 2017-09-11 13:22:33 --> Database Driver Class Initialized
INFO - 2017-09-11 13:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:22:33 --> Email Class Initialized
INFO - 2017-09-11 13:22:33 --> Controller Class Initialized
INFO - 2017-09-11 13:22:33 --> Helper loaded: form_helper
INFO - 2017-09-11 13:22:33 --> Form Validation Class Initialized
INFO - 2017-09-11 13:22:33 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:22:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:22:33 --> Helper loaded: url_helper
INFO - 2017-09-11 13:22:33 --> Model Class Initialized
INFO - 2017-09-11 13:22:33 --> Model Class Initialized
INFO - 2017-09-11 13:22:33 --> Model Class Initialized
INFO - 2017-09-11 16:52:33 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:52:33 --> Undefined variable: data
ERROR - 2017-09-11 16:52:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 184
ERROR - 2017-09-11 16:52:33 --> Exception: Could not load a non-array data!
ERROR - 2017-09-11 16:52:33 --> Severity: error --> Exception: Could not load a non-array data! C:\xampp\htdocs\FlickNews\admin\application\libraries\PHPReport\PHPReport.php 269
INFO - 2017-09-11 13:22:42 --> Config Class Initialized
INFO - 2017-09-11 13:22:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:22:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:22:42 --> Utf8 Class Initialized
INFO - 2017-09-11 13:22:42 --> URI Class Initialized
INFO - 2017-09-11 13:22:42 --> Router Class Initialized
INFO - 2017-09-11 13:22:42 --> Output Class Initialized
INFO - 2017-09-11 13:22:42 --> Security Class Initialized
DEBUG - 2017-09-11 13:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:22:42 --> Input Class Initialized
INFO - 2017-09-11 13:22:42 --> Language Class Initialized
ERROR - 2017-09-11 13:22:42 --> syntax error, unexpected 'template' (T_STRING)
ERROR - 2017-09-11 13:22:42 --> Severity: Parsing Error --> syntax error, unexpected 'template' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 172
INFO - 2017-09-11 13:23:11 --> Config Class Initialized
INFO - 2017-09-11 13:23:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:23:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:23:11 --> Utf8 Class Initialized
INFO - 2017-09-11 13:23:11 --> URI Class Initialized
INFO - 2017-09-11 13:23:11 --> Router Class Initialized
INFO - 2017-09-11 13:23:11 --> Output Class Initialized
INFO - 2017-09-11 13:23:11 --> Security Class Initialized
DEBUG - 2017-09-11 13:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:23:11 --> Input Class Initialized
INFO - 2017-09-11 13:23:11 --> Language Class Initialized
INFO - 2017-09-11 13:23:11 --> Loader Class Initialized
INFO - 2017-09-11 13:23:11 --> Helper loaded: common_helper
INFO - 2017-09-11 13:23:11 --> Database Driver Class Initialized
INFO - 2017-09-11 13:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:23:11 --> Email Class Initialized
INFO - 2017-09-11 13:23:11 --> Controller Class Initialized
INFO - 2017-09-11 13:23:11 --> Helper loaded: form_helper
INFO - 2017-09-11 13:23:11 --> Form Validation Class Initialized
INFO - 2017-09-11 13:23:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:23:11 --> Helper loaded: url_helper
INFO - 2017-09-11 13:23:11 --> Model Class Initialized
INFO - 2017-09-11 13:23:11 --> Model Class Initialized
INFO - 2017-09-11 13:23:11 --> Model Class Initialized
INFO - 2017-09-11 16:53:11 --> Helper loaded: download_helper
INFO - 2017-09-11 13:24:18 --> Config Class Initialized
INFO - 2017-09-11 13:24:18 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:24:18 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:24:18 --> Utf8 Class Initialized
INFO - 2017-09-11 13:24:18 --> URI Class Initialized
INFO - 2017-09-11 13:24:18 --> Router Class Initialized
INFO - 2017-09-11 13:24:18 --> Output Class Initialized
INFO - 2017-09-11 13:24:18 --> Security Class Initialized
DEBUG - 2017-09-11 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:24:18 --> Input Class Initialized
INFO - 2017-09-11 13:24:18 --> Language Class Initialized
INFO - 2017-09-11 13:24:18 --> Loader Class Initialized
INFO - 2017-09-11 13:24:18 --> Helper loaded: common_helper
INFO - 2017-09-11 13:24:18 --> Database Driver Class Initialized
INFO - 2017-09-11 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:24:18 --> Email Class Initialized
INFO - 2017-09-11 13:24:18 --> Controller Class Initialized
INFO - 2017-09-11 13:24:18 --> Helper loaded: form_helper
INFO - 2017-09-11 13:24:18 --> Form Validation Class Initialized
INFO - 2017-09-11 13:24:18 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:24:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:24:18 --> Helper loaded: url_helper
INFO - 2017-09-11 13:24:18 --> Model Class Initialized
INFO - 2017-09-11 13:24:18 --> Model Class Initialized
INFO - 2017-09-11 13:24:18 --> Model Class Initialized
INFO - 2017-09-11 16:54:18 --> Helper loaded: download_helper
INFO - 2017-09-11 13:24:46 --> Config Class Initialized
INFO - 2017-09-11 13:24:46 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:24:46 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:24:46 --> Utf8 Class Initialized
INFO - 2017-09-11 13:24:46 --> URI Class Initialized
INFO - 2017-09-11 13:24:46 --> Router Class Initialized
INFO - 2017-09-11 13:24:46 --> Output Class Initialized
INFO - 2017-09-11 13:24:46 --> Security Class Initialized
DEBUG - 2017-09-11 13:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:24:46 --> Input Class Initialized
INFO - 2017-09-11 13:24:46 --> Language Class Initialized
ERROR - 2017-09-11 13:24:46 --> syntax error, unexpected '"'
ERROR - 2017-09-11 13:24:46 --> Severity: Parsing Error --> syntax error, unexpected '"' C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 188
INFO - 2017-09-11 13:25:02 --> Config Class Initialized
INFO - 2017-09-11 13:25:02 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:25:02 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:25:02 --> Utf8 Class Initialized
INFO - 2017-09-11 13:25:02 --> URI Class Initialized
INFO - 2017-09-11 13:25:02 --> Router Class Initialized
INFO - 2017-09-11 13:25:02 --> Output Class Initialized
INFO - 2017-09-11 13:25:02 --> Security Class Initialized
DEBUG - 2017-09-11 13:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:25:02 --> Input Class Initialized
INFO - 2017-09-11 13:25:02 --> Language Class Initialized
INFO - 2017-09-11 13:25:02 --> Loader Class Initialized
INFO - 2017-09-11 13:25:02 --> Helper loaded: common_helper
INFO - 2017-09-11 13:25:02 --> Database Driver Class Initialized
INFO - 2017-09-11 13:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:25:02 --> Email Class Initialized
INFO - 2017-09-11 13:25:02 --> Controller Class Initialized
INFO - 2017-09-11 13:25:02 --> Helper loaded: form_helper
INFO - 2017-09-11 13:25:02 --> Form Validation Class Initialized
INFO - 2017-09-11 13:25:02 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:25:02 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:25:02 --> Helper loaded: url_helper
INFO - 2017-09-11 13:25:02 --> Model Class Initialized
INFO - 2017-09-11 13:25:02 --> Model Class Initialized
INFO - 2017-09-11 13:25:02 --> Model Class Initialized
INFO - 2017-09-11 16:55:02 --> Helper loaded: download_helper
ERROR - 2017-09-11 16:55:03 --> Undefined variable: data
ERROR - 2017-09-11 16:55:03 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 184
ERROR - 2017-09-11 16:55:03 --> Exception: Could not load a non-array data!
ERROR - 2017-09-11 16:55:03 --> Severity: error --> Exception: Could not load a non-array data! C:\xampp\htdocs\FlickNews\admin\application\libraries\PHPReport\PHPReport.php 269
INFO - 2017-09-11 13:25:37 --> Config Class Initialized
INFO - 2017-09-11 13:25:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:25:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:25:37 --> Utf8 Class Initialized
INFO - 2017-09-11 13:25:37 --> URI Class Initialized
INFO - 2017-09-11 13:25:37 --> Router Class Initialized
INFO - 2017-09-11 13:25:37 --> Output Class Initialized
INFO - 2017-09-11 13:25:37 --> Security Class Initialized
DEBUG - 2017-09-11 13:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:25:37 --> Input Class Initialized
INFO - 2017-09-11 13:25:37 --> Language Class Initialized
INFO - 2017-09-11 13:25:37 --> Loader Class Initialized
INFO - 2017-09-11 13:25:37 --> Helper loaded: common_helper
INFO - 2017-09-11 13:25:37 --> Database Driver Class Initialized
INFO - 2017-09-11 13:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:25:37 --> Email Class Initialized
INFO - 2017-09-11 13:25:37 --> Controller Class Initialized
INFO - 2017-09-11 13:25:37 --> Helper loaded: form_helper
INFO - 2017-09-11 13:25:37 --> Form Validation Class Initialized
INFO - 2017-09-11 13:25:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:25:37 --> Helper loaded: url_helper
INFO - 2017-09-11 13:25:37 --> Model Class Initialized
INFO - 2017-09-11 13:25:37 --> Model Class Initialized
INFO - 2017-09-11 13:25:37 --> Model Class Initialized
INFO - 2017-09-11 16:55:37 --> Helper loaded: download_helper
INFO - 2017-09-11 13:27:16 --> Config Class Initialized
INFO - 2017-09-11 13:27:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:27:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:27:16 --> Utf8 Class Initialized
INFO - 2017-09-11 13:27:16 --> URI Class Initialized
INFO - 2017-09-11 13:27:16 --> Router Class Initialized
INFO - 2017-09-11 13:27:16 --> Output Class Initialized
INFO - 2017-09-11 13:27:16 --> Security Class Initialized
DEBUG - 2017-09-11 13:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:27:16 --> Input Class Initialized
INFO - 2017-09-11 13:27:16 --> Language Class Initialized
INFO - 2017-09-11 13:27:16 --> Loader Class Initialized
INFO - 2017-09-11 13:27:16 --> Helper loaded: common_helper
INFO - 2017-09-11 13:27:16 --> Database Driver Class Initialized
INFO - 2017-09-11 13:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:27:16 --> Email Class Initialized
INFO - 2017-09-11 13:27:16 --> Controller Class Initialized
INFO - 2017-09-11 13:27:16 --> Helper loaded: form_helper
INFO - 2017-09-11 13:27:16 --> Form Validation Class Initialized
INFO - 2017-09-11 13:27:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:27:16 --> Helper loaded: url_helper
INFO - 2017-09-11 13:27:16 --> Model Class Initialized
INFO - 2017-09-11 13:27:16 --> Model Class Initialized
INFO - 2017-09-11 13:27:16 --> Model Class Initialized
INFO - 2017-09-11 16:57:16 --> Helper loaded: download_helper
INFO - 2017-09-11 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 16:57:16 --> Final output sent to browser
DEBUG - 2017-09-11 16:57:16 --> Total execution time: 0.0517
INFO - 2017-09-11 13:27:17 --> Config Class Initialized
INFO - 2017-09-11 13:27:17 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:27:17 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:27:17 --> Utf8 Class Initialized
INFO - 2017-09-11 13:27:17 --> URI Class Initialized
INFO - 2017-09-11 13:27:17 --> Router Class Initialized
INFO - 2017-09-11 13:27:17 --> Output Class Initialized
INFO - 2017-09-11 13:27:17 --> Security Class Initialized
DEBUG - 2017-09-11 13:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:27:17 --> Input Class Initialized
INFO - 2017-09-11 13:27:17 --> Language Class Initialized
INFO - 2017-09-11 13:27:17 --> Loader Class Initialized
INFO - 2017-09-11 13:27:17 --> Helper loaded: common_helper
INFO - 2017-09-11 13:27:17 --> Database Driver Class Initialized
INFO - 2017-09-11 13:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:27:17 --> Email Class Initialized
INFO - 2017-09-11 13:27:17 --> Controller Class Initialized
INFO - 2017-09-11 13:27:17 --> Helper loaded: form_helper
INFO - 2017-09-11 13:27:17 --> Form Validation Class Initialized
INFO - 2017-09-11 13:27:17 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:27:17 --> Helper loaded: url_helper
INFO - 2017-09-11 13:27:17 --> Model Class Initialized
INFO - 2017-09-11 13:27:17 --> Model Class Initialized
INFO - 2017-09-11 13:27:17 --> Model Class Initialized
INFO - 2017-09-11 16:57:17 --> Helper loaded: download_helper
INFO - 2017-09-11 13:32:58 --> Config Class Initialized
INFO - 2017-09-11 13:32:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:32:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:32:58 --> Utf8 Class Initialized
INFO - 2017-09-11 13:32:58 --> URI Class Initialized
INFO - 2017-09-11 13:32:58 --> Router Class Initialized
INFO - 2017-09-11 13:32:58 --> Output Class Initialized
INFO - 2017-09-11 13:32:58 --> Security Class Initialized
DEBUG - 2017-09-11 13:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:32:58 --> Input Class Initialized
INFO - 2017-09-11 13:32:58 --> Language Class Initialized
INFO - 2017-09-11 13:32:58 --> Loader Class Initialized
INFO - 2017-09-11 13:32:58 --> Helper loaded: common_helper
INFO - 2017-09-11 13:32:58 --> Database Driver Class Initialized
INFO - 2017-09-11 13:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:32:58 --> Email Class Initialized
INFO - 2017-09-11 13:32:58 --> Controller Class Initialized
INFO - 2017-09-11 13:32:58 --> Helper loaded: form_helper
INFO - 2017-09-11 13:32:58 --> Form Validation Class Initialized
INFO - 2017-09-11 13:32:58 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:32:58 --> Helper loaded: url_helper
INFO - 2017-09-11 13:32:58 --> Model Class Initialized
INFO - 2017-09-11 13:32:58 --> Model Class Initialized
INFO - 2017-09-11 13:32:58 --> Model Class Initialized
INFO - 2017-09-11 17:02:58 --> Helper loaded: download_helper
INFO - 2017-09-11 17:02:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:02:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:02:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:02:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:02:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:02:58 --> Final output sent to browser
DEBUG - 2017-09-11 17:02:58 --> Total execution time: 0.0565
INFO - 2017-09-11 13:32:59 --> Config Class Initialized
INFO - 2017-09-11 13:32:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:32:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:32:59 --> Utf8 Class Initialized
INFO - 2017-09-11 13:32:59 --> URI Class Initialized
INFO - 2017-09-11 13:32:59 --> Router Class Initialized
INFO - 2017-09-11 13:32:59 --> Output Class Initialized
INFO - 2017-09-11 13:32:59 --> Security Class Initialized
DEBUG - 2017-09-11 13:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:32:59 --> Input Class Initialized
INFO - 2017-09-11 13:32:59 --> Language Class Initialized
INFO - 2017-09-11 13:32:59 --> Loader Class Initialized
INFO - 2017-09-11 13:32:59 --> Helper loaded: common_helper
INFO - 2017-09-11 13:32:59 --> Database Driver Class Initialized
INFO - 2017-09-11 13:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:32:59 --> Email Class Initialized
INFO - 2017-09-11 13:32:59 --> Controller Class Initialized
INFO - 2017-09-11 13:32:59 --> Helper loaded: form_helper
INFO - 2017-09-11 13:32:59 --> Form Validation Class Initialized
INFO - 2017-09-11 13:32:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:32:59 --> Helper loaded: url_helper
INFO - 2017-09-11 13:32:59 --> Model Class Initialized
INFO - 2017-09-11 13:32:59 --> Model Class Initialized
INFO - 2017-09-11 13:32:59 --> Model Class Initialized
INFO - 2017-09-11 17:02:59 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:02:59 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:35:28 --> Config Class Initialized
INFO - 2017-09-11 13:35:28 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:28 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:28 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:28 --> URI Class Initialized
INFO - 2017-09-11 13:35:28 --> Router Class Initialized
INFO - 2017-09-11 13:35:28 --> Output Class Initialized
INFO - 2017-09-11 13:35:28 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:28 --> Input Class Initialized
INFO - 2017-09-11 13:35:28 --> Language Class Initialized
INFO - 2017-09-11 13:35:28 --> Loader Class Initialized
INFO - 2017-09-11 13:35:28 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:28 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:28 --> Email Class Initialized
INFO - 2017-09-11 13:35:28 --> Controller Class Initialized
INFO - 2017-09-11 13:35:28 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:28 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:28 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:28 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:28 --> Model Class Initialized
INFO - 2017-09-11 13:35:28 --> Model Class Initialized
INFO - 2017-09-11 13:35:28 --> Model Class Initialized
INFO - 2017-09-11 17:05:28 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:05:28 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:35:31 --> Config Class Initialized
INFO - 2017-09-11 13:35:31 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:31 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:31 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:31 --> URI Class Initialized
INFO - 2017-09-11 13:35:31 --> Router Class Initialized
INFO - 2017-09-11 13:35:31 --> Output Class Initialized
INFO - 2017-09-11 13:35:31 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:31 --> Input Class Initialized
INFO - 2017-09-11 13:35:31 --> Language Class Initialized
INFO - 2017-09-11 13:35:31 --> Loader Class Initialized
INFO - 2017-09-11 13:35:31 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:31 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:31 --> Email Class Initialized
INFO - 2017-09-11 13:35:31 --> Controller Class Initialized
INFO - 2017-09-11 13:35:31 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:31 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:31 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:31 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:31 --> Model Class Initialized
INFO - 2017-09-11 13:35:31 --> Model Class Initialized
INFO - 2017-09-11 13:35:31 --> Model Class Initialized
INFO - 2017-09-11 17:05:31 --> Helper loaded: download_helper
INFO - 2017-09-11 17:05:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:05:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:05:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:05:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:05:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:05:31 --> Final output sent to browser
DEBUG - 2017-09-11 17:05:31 --> Total execution time: 0.0510
INFO - 2017-09-11 13:35:32 --> Config Class Initialized
INFO - 2017-09-11 13:35:32 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:32 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:32 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:32 --> URI Class Initialized
INFO - 2017-09-11 13:35:32 --> Router Class Initialized
INFO - 2017-09-11 13:35:32 --> Output Class Initialized
INFO - 2017-09-11 13:35:32 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:32 --> Input Class Initialized
INFO - 2017-09-11 13:35:32 --> Language Class Initialized
INFO - 2017-09-11 13:35:32 --> Loader Class Initialized
INFO - 2017-09-11 13:35:32 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:32 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:32 --> Email Class Initialized
INFO - 2017-09-11 13:35:32 --> Controller Class Initialized
INFO - 2017-09-11 13:35:32 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:32 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:32 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:32 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:32 --> Model Class Initialized
INFO - 2017-09-11 13:35:32 --> Model Class Initialized
INFO - 2017-09-11 13:35:32 --> Model Class Initialized
INFO - 2017-09-11 17:05:32 --> Helper loaded: download_helper
INFO - 2017-09-11 17:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:05:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:05:32 --> Final output sent to browser
DEBUG - 2017-09-11 17:05:32 --> Total execution time: 0.0492
INFO - 2017-09-11 13:35:34 --> Config Class Initialized
INFO - 2017-09-11 13:35:34 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:34 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:34 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:34 --> URI Class Initialized
INFO - 2017-09-11 13:35:34 --> Router Class Initialized
INFO - 2017-09-11 13:35:34 --> Output Class Initialized
INFO - 2017-09-11 13:35:34 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:34 --> Input Class Initialized
INFO - 2017-09-11 13:35:34 --> Language Class Initialized
INFO - 2017-09-11 13:35:34 --> Loader Class Initialized
INFO - 2017-09-11 13:35:34 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:34 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:34 --> Email Class Initialized
INFO - 2017-09-11 13:35:34 --> Controller Class Initialized
INFO - 2017-09-11 13:35:34 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:34 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:34 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:34 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:34 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:34 --> Model Class Initialized
INFO - 2017-09-11 13:35:34 --> Model Class Initialized
INFO - 2017-09-11 13:35:34 --> Model Class Initialized
INFO - 2017-09-11 17:05:34 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:05:34 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:35:48 --> Config Class Initialized
INFO - 2017-09-11 13:35:48 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:48 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:48 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:48 --> URI Class Initialized
INFO - 2017-09-11 13:35:48 --> Router Class Initialized
INFO - 2017-09-11 13:35:48 --> Output Class Initialized
INFO - 2017-09-11 13:35:48 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:48 --> Input Class Initialized
INFO - 2017-09-11 13:35:48 --> Language Class Initialized
INFO - 2017-09-11 13:35:48 --> Loader Class Initialized
INFO - 2017-09-11 13:35:48 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:48 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:48 --> Email Class Initialized
INFO - 2017-09-11 13:35:48 --> Controller Class Initialized
INFO - 2017-09-11 13:35:48 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:48 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:48 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:48 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:48 --> Model Class Initialized
INFO - 2017-09-11 13:35:48 --> Model Class Initialized
INFO - 2017-09-11 13:35:48 --> Model Class Initialized
INFO - 2017-09-11 17:05:48 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:05:48 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:35:50 --> Config Class Initialized
INFO - 2017-09-11 13:35:50 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:50 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:50 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:50 --> URI Class Initialized
INFO - 2017-09-11 13:35:50 --> Router Class Initialized
INFO - 2017-09-11 13:35:50 --> Output Class Initialized
INFO - 2017-09-11 13:35:50 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:50 --> Input Class Initialized
INFO - 2017-09-11 13:35:50 --> Language Class Initialized
INFO - 2017-09-11 13:35:50 --> Loader Class Initialized
INFO - 2017-09-11 13:35:50 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:50 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:50 --> Email Class Initialized
INFO - 2017-09-11 13:35:50 --> Controller Class Initialized
INFO - 2017-09-11 13:35:50 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:50 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:50 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:50 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:50 --> Model Class Initialized
INFO - 2017-09-11 13:35:50 --> Model Class Initialized
INFO - 2017-09-11 13:35:50 --> Model Class Initialized
INFO - 2017-09-11 17:05:50 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:05:50 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:35:51 --> Config Class Initialized
INFO - 2017-09-11 13:35:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:51 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:51 --> URI Class Initialized
INFO - 2017-09-11 13:35:51 --> Router Class Initialized
INFO - 2017-09-11 13:35:51 --> Output Class Initialized
INFO - 2017-09-11 13:35:51 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:51 --> Input Class Initialized
INFO - 2017-09-11 13:35:51 --> Language Class Initialized
INFO - 2017-09-11 13:35:51 --> Loader Class Initialized
INFO - 2017-09-11 13:35:51 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:51 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:51 --> Email Class Initialized
INFO - 2017-09-11 13:35:51 --> Controller Class Initialized
INFO - 2017-09-11 13:35:51 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:51 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:51 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:51 --> Model Class Initialized
INFO - 2017-09-11 13:35:51 --> Model Class Initialized
INFO - 2017-09-11 13:35:51 --> Model Class Initialized
INFO - 2017-09-11 17:05:51 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:05:51 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:35:52 --> Config Class Initialized
INFO - 2017-09-11 13:35:52 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:35:52 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:35:52 --> Utf8 Class Initialized
INFO - 2017-09-11 13:35:52 --> URI Class Initialized
INFO - 2017-09-11 13:35:52 --> Router Class Initialized
INFO - 2017-09-11 13:35:52 --> Output Class Initialized
INFO - 2017-09-11 13:35:52 --> Security Class Initialized
DEBUG - 2017-09-11 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:35:52 --> Input Class Initialized
INFO - 2017-09-11 13:35:52 --> Language Class Initialized
INFO - 2017-09-11 13:35:52 --> Loader Class Initialized
INFO - 2017-09-11 13:35:52 --> Helper loaded: common_helper
INFO - 2017-09-11 13:35:52 --> Database Driver Class Initialized
INFO - 2017-09-11 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:35:52 --> Email Class Initialized
INFO - 2017-09-11 13:35:52 --> Controller Class Initialized
INFO - 2017-09-11 13:35:52 --> Helper loaded: form_helper
INFO - 2017-09-11 13:35:52 --> Form Validation Class Initialized
INFO - 2017-09-11 13:35:52 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:35:52 --> Helper loaded: url_helper
INFO - 2017-09-11 13:35:52 --> Model Class Initialized
INFO - 2017-09-11 13:35:52 --> Model Class Initialized
INFO - 2017-09-11 13:35:52 --> Model Class Initialized
INFO - 2017-09-11 17:05:52 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:05:52 --> Unable to load the requested class: PHPExcel
INFO - 2017-09-11 13:38:18 --> Config Class Initialized
INFO - 2017-09-11 13:38:18 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:38:18 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:38:18 --> Utf8 Class Initialized
INFO - 2017-09-11 13:38:18 --> URI Class Initialized
INFO - 2017-09-11 13:38:18 --> Router Class Initialized
INFO - 2017-09-11 13:38:18 --> Output Class Initialized
INFO - 2017-09-11 13:38:18 --> Security Class Initialized
DEBUG - 2017-09-11 13:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:38:18 --> Input Class Initialized
INFO - 2017-09-11 13:38:18 --> Language Class Initialized
INFO - 2017-09-11 13:38:18 --> Loader Class Initialized
INFO - 2017-09-11 13:38:18 --> Helper loaded: common_helper
INFO - 2017-09-11 13:38:18 --> Database Driver Class Initialized
INFO - 2017-09-11 13:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:38:18 --> Email Class Initialized
INFO - 2017-09-11 13:38:18 --> Controller Class Initialized
INFO - 2017-09-11 13:38:18 --> Helper loaded: form_helper
INFO - 2017-09-11 13:38:18 --> Form Validation Class Initialized
INFO - 2017-09-11 13:38:18 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:38:18 --> Helper loaded: url_helper
INFO - 2017-09-11 13:38:18 --> Model Class Initialized
INFO - 2017-09-11 13:38:18 --> Model Class Initialized
INFO - 2017-09-11 13:38:18 --> Model Class Initialized
INFO - 2017-09-11 17:08:18 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:08:18 --> Class 'IOFactory' not found
ERROR - 2017-09-11 17:08:18 --> Severity: Error --> Class 'IOFactory' not found C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 194
INFO - 2017-09-11 13:39:39 --> Config Class Initialized
INFO - 2017-09-11 13:39:39 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:39:39 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:39:39 --> Utf8 Class Initialized
INFO - 2017-09-11 13:39:39 --> URI Class Initialized
INFO - 2017-09-11 13:39:39 --> Router Class Initialized
INFO - 2017-09-11 13:39:39 --> Output Class Initialized
INFO - 2017-09-11 13:39:39 --> Security Class Initialized
DEBUG - 2017-09-11 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:39:39 --> Input Class Initialized
INFO - 2017-09-11 13:39:39 --> Language Class Initialized
ERROR - 2017-09-11 13:39:39 --> syntax error, unexpected 'header' (T_STRING)
ERROR - 2017-09-11 13:39:39 --> Severity: Parsing Error --> syntax error, unexpected 'header' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 197
INFO - 2017-09-11 13:39:48 --> Config Class Initialized
INFO - 2017-09-11 13:39:48 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:39:48 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:39:48 --> Utf8 Class Initialized
INFO - 2017-09-11 13:39:48 --> URI Class Initialized
INFO - 2017-09-11 13:39:48 --> Router Class Initialized
INFO - 2017-09-11 13:39:48 --> Output Class Initialized
INFO - 2017-09-11 13:39:48 --> Security Class Initialized
DEBUG - 2017-09-11 13:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:39:48 --> Input Class Initialized
INFO - 2017-09-11 13:39:48 --> Language Class Initialized
INFO - 2017-09-11 13:39:48 --> Loader Class Initialized
INFO - 2017-09-11 13:39:48 --> Helper loaded: common_helper
INFO - 2017-09-11 13:39:48 --> Database Driver Class Initialized
INFO - 2017-09-11 13:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:39:48 --> Email Class Initialized
INFO - 2017-09-11 13:39:48 --> Controller Class Initialized
INFO - 2017-09-11 13:39:48 --> Helper loaded: form_helper
INFO - 2017-09-11 13:39:48 --> Form Validation Class Initialized
INFO - 2017-09-11 13:39:48 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:39:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:39:48 --> Helper loaded: url_helper
INFO - 2017-09-11 13:39:48 --> Model Class Initialized
INFO - 2017-09-11 13:39:48 --> Model Class Initialized
INFO - 2017-09-11 13:39:48 --> Model Class Initialized
INFO - 2017-09-11 17:09:48 --> Helper loaded: download_helper
ERROR - 2017-09-11 17:09:48 --> Undefined property: Users::$Excel
ERROR - 2017-09-11 17:09:48 --> Severity: Notice --> Undefined property: Users::$Excel C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 194
ERROR - 2017-09-11 17:09:48 --> Call to a member function createReader() on a non-object
ERROR - 2017-09-11 17:09:48 --> Severity: Error --> Call to a member function createReader() on a non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 194
INFO - 2017-09-11 13:41:19 --> Config Class Initialized
INFO - 2017-09-11 13:41:19 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:41:19 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:41:19 --> Utf8 Class Initialized
INFO - 2017-09-11 13:41:19 --> URI Class Initialized
INFO - 2017-09-11 13:41:19 --> Router Class Initialized
INFO - 2017-09-11 13:41:19 --> Output Class Initialized
INFO - 2017-09-11 13:41:19 --> Security Class Initialized
DEBUG - 2017-09-11 13:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:41:19 --> Input Class Initialized
INFO - 2017-09-11 13:41:19 --> Language Class Initialized
ERROR - 2017-09-11 13:41:19 --> syntax error, unexpected '$objWriter' (T_VARIABLE)
ERROR - 2017-09-11 13:41:19 --> Severity: Parsing Error --> syntax error, unexpected '$objWriter' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 195
INFO - 2017-09-11 13:41:30 --> Config Class Initialized
INFO - 2017-09-11 13:41:30 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:41:30 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:41:30 --> Utf8 Class Initialized
INFO - 2017-09-11 13:41:30 --> URI Class Initialized
INFO - 2017-09-11 13:41:30 --> Router Class Initialized
INFO - 2017-09-11 13:41:30 --> Output Class Initialized
INFO - 2017-09-11 13:41:30 --> Security Class Initialized
DEBUG - 2017-09-11 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:41:30 --> Input Class Initialized
INFO - 2017-09-11 13:41:30 --> Language Class Initialized
INFO - 2017-09-11 13:41:30 --> Loader Class Initialized
INFO - 2017-09-11 13:41:30 --> Helper loaded: common_helper
INFO - 2017-09-11 13:41:30 --> Database Driver Class Initialized
INFO - 2017-09-11 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:41:30 --> Email Class Initialized
INFO - 2017-09-11 13:41:30 --> Controller Class Initialized
INFO - 2017-09-11 13:41:30 --> Helper loaded: form_helper
INFO - 2017-09-11 13:41:30 --> Form Validation Class Initialized
INFO - 2017-09-11 13:41:30 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:41:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:41:30 --> Helper loaded: url_helper
INFO - 2017-09-11 13:41:30 --> Model Class Initialized
INFO - 2017-09-11 13:41:30 --> Model Class Initialized
INFO - 2017-09-11 13:41:30 --> Model Class Initialized
INFO - 2017-09-11 17:11:30 --> Helper loaded: download_helper
INFO - 2017-09-11 17:11:30 --> Final output sent to browser
DEBUG - 2017-09-11 17:11:30 --> Total execution time: 0.1413
INFO - 2017-09-11 13:41:48 --> Config Class Initialized
INFO - 2017-09-11 13:41:48 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:41:48 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:41:48 --> Utf8 Class Initialized
INFO - 2017-09-11 13:41:48 --> URI Class Initialized
INFO - 2017-09-11 13:41:48 --> Router Class Initialized
INFO - 2017-09-11 13:41:48 --> Output Class Initialized
INFO - 2017-09-11 13:41:48 --> Security Class Initialized
DEBUG - 2017-09-11 13:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:41:48 --> Input Class Initialized
INFO - 2017-09-11 13:41:48 --> Language Class Initialized
INFO - 2017-09-11 13:41:48 --> Loader Class Initialized
INFO - 2017-09-11 13:41:48 --> Helper loaded: common_helper
INFO - 2017-09-11 13:41:48 --> Database Driver Class Initialized
INFO - 2017-09-11 13:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:41:48 --> Email Class Initialized
INFO - 2017-09-11 13:41:48 --> Controller Class Initialized
INFO - 2017-09-11 13:41:48 --> Helper loaded: form_helper
INFO - 2017-09-11 13:41:48 --> Form Validation Class Initialized
INFO - 2017-09-11 13:41:48 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:41:48 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:41:48 --> Helper loaded: url_helper
INFO - 2017-09-11 13:41:48 --> Model Class Initialized
INFO - 2017-09-11 13:41:48 --> Model Class Initialized
INFO - 2017-09-11 13:41:48 --> Model Class Initialized
INFO - 2017-09-11 17:11:48 --> Helper loaded: download_helper
INFO - 2017-09-11 17:11:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:11:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:11:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:11:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:11:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:11:48 --> Final output sent to browser
DEBUG - 2017-09-11 17:11:48 --> Total execution time: 0.0492
INFO - 2017-09-11 13:41:49 --> Config Class Initialized
INFO - 2017-09-11 13:41:49 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:41:49 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:41:49 --> Utf8 Class Initialized
INFO - 2017-09-11 13:41:49 --> URI Class Initialized
INFO - 2017-09-11 13:41:49 --> Router Class Initialized
INFO - 2017-09-11 13:41:49 --> Output Class Initialized
INFO - 2017-09-11 13:41:49 --> Security Class Initialized
DEBUG - 2017-09-11 13:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:41:49 --> Input Class Initialized
INFO - 2017-09-11 13:41:49 --> Language Class Initialized
INFO - 2017-09-11 13:41:49 --> Loader Class Initialized
INFO - 2017-09-11 13:41:49 --> Helper loaded: common_helper
INFO - 2017-09-11 13:41:49 --> Database Driver Class Initialized
INFO - 2017-09-11 13:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:41:49 --> Email Class Initialized
INFO - 2017-09-11 13:41:49 --> Controller Class Initialized
INFO - 2017-09-11 13:41:49 --> Helper loaded: form_helper
INFO - 2017-09-11 13:41:49 --> Form Validation Class Initialized
INFO - 2017-09-11 13:41:49 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:41:49 --> Helper loaded: url_helper
INFO - 2017-09-11 13:41:49 --> Model Class Initialized
INFO - 2017-09-11 13:41:49 --> Model Class Initialized
INFO - 2017-09-11 13:41:49 --> Model Class Initialized
INFO - 2017-09-11 17:11:49 --> Helper loaded: download_helper
INFO - 2017-09-11 17:11:49 --> Final output sent to browser
DEBUG - 2017-09-11 17:11:49 --> Total execution time: 0.1329
INFO - 2017-09-11 13:54:29 --> Config Class Initialized
INFO - 2017-09-11 13:54:29 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:54:29 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:54:29 --> Utf8 Class Initialized
INFO - 2017-09-11 13:54:29 --> URI Class Initialized
INFO - 2017-09-11 13:54:29 --> Router Class Initialized
INFO - 2017-09-11 13:54:29 --> Output Class Initialized
INFO - 2017-09-11 13:54:29 --> Security Class Initialized
DEBUG - 2017-09-11 13:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:54:29 --> Input Class Initialized
INFO - 2017-09-11 13:54:29 --> Language Class Initialized
INFO - 2017-09-11 13:54:29 --> Loader Class Initialized
INFO - 2017-09-11 13:54:29 --> Helper loaded: common_helper
INFO - 2017-09-11 13:54:29 --> Database Driver Class Initialized
INFO - 2017-09-11 13:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:54:29 --> Email Class Initialized
INFO - 2017-09-11 13:54:29 --> Controller Class Initialized
INFO - 2017-09-11 13:54:29 --> Helper loaded: form_helper
INFO - 2017-09-11 13:54:29 --> Form Validation Class Initialized
INFO - 2017-09-11 13:54:29 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:54:29 --> Helper loaded: url_helper
INFO - 2017-09-11 13:54:29 --> Model Class Initialized
INFO - 2017-09-11 13:54:29 --> Model Class Initialized
INFO - 2017-09-11 13:54:29 --> Model Class Initialized
INFO - 2017-09-11 17:24:29 --> Helper loaded: download_helper
INFO - 2017-09-11 17:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:24:29 --> Final output sent to browser
DEBUG - 2017-09-11 17:24:29 --> Total execution time: 0.0565
INFO - 2017-09-11 13:54:31 --> Config Class Initialized
INFO - 2017-09-11 13:54:31 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:54:31 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:54:31 --> Utf8 Class Initialized
INFO - 2017-09-11 13:54:31 --> URI Class Initialized
INFO - 2017-09-11 13:54:31 --> Router Class Initialized
INFO - 2017-09-11 13:54:31 --> Output Class Initialized
INFO - 2017-09-11 13:54:31 --> Security Class Initialized
DEBUG - 2017-09-11 13:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:54:31 --> Input Class Initialized
INFO - 2017-09-11 13:54:31 --> Language Class Initialized
INFO - 2017-09-11 13:54:31 --> Loader Class Initialized
INFO - 2017-09-11 13:54:31 --> Helper loaded: common_helper
INFO - 2017-09-11 13:54:31 --> Database Driver Class Initialized
INFO - 2017-09-11 13:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:54:31 --> Email Class Initialized
INFO - 2017-09-11 13:54:31 --> Controller Class Initialized
INFO - 2017-09-11 13:54:31 --> Helper loaded: form_helper
INFO - 2017-09-11 13:54:31 --> Form Validation Class Initialized
INFO - 2017-09-11 13:54:31 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:54:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:54:31 --> Helper loaded: url_helper
INFO - 2017-09-11 13:54:31 --> Model Class Initialized
INFO - 2017-09-11 13:54:31 --> Model Class Initialized
INFO - 2017-09-11 13:54:31 --> Model Class Initialized
INFO - 2017-09-11 17:24:31 --> Helper loaded: download_helper
INFO - 2017-09-11 17:24:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:24:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:24:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:24:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:24:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:24:31 --> Final output sent to browser
DEBUG - 2017-09-11 17:24:31 --> Total execution time: 0.0660
INFO - 2017-09-11 13:54:32 --> Config Class Initialized
INFO - 2017-09-11 13:54:32 --> Hooks Class Initialized
DEBUG - 2017-09-11 13:54:32 --> UTF-8 Support Enabled
INFO - 2017-09-11 13:54:32 --> Utf8 Class Initialized
INFO - 2017-09-11 13:54:32 --> URI Class Initialized
INFO - 2017-09-11 13:54:32 --> Router Class Initialized
INFO - 2017-09-11 13:54:32 --> Output Class Initialized
INFO - 2017-09-11 13:54:32 --> Security Class Initialized
DEBUG - 2017-09-11 13:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 13:54:32 --> Input Class Initialized
INFO - 2017-09-11 13:54:32 --> Language Class Initialized
INFO - 2017-09-11 13:54:32 --> Loader Class Initialized
INFO - 2017-09-11 13:54:32 --> Helper loaded: common_helper
INFO - 2017-09-11 13:54:32 --> Database Driver Class Initialized
INFO - 2017-09-11 13:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 13:54:32 --> Email Class Initialized
INFO - 2017-09-11 13:54:32 --> Controller Class Initialized
INFO - 2017-09-11 13:54:32 --> Helper loaded: form_helper
INFO - 2017-09-11 13:54:32 --> Form Validation Class Initialized
INFO - 2017-09-11 13:54:32 --> Helper loaded: email_helper
DEBUG - 2017-09-11 13:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 13:54:32 --> Helper loaded: url_helper
INFO - 2017-09-11 13:54:32 --> Model Class Initialized
INFO - 2017-09-11 13:54:32 --> Model Class Initialized
INFO - 2017-09-11 13:54:32 --> Model Class Initialized
INFO - 2017-09-11 17:24:32 --> Helper loaded: download_helper
INFO - 2017-09-11 17:24:32 --> Final output sent to browser
DEBUG - 2017-09-11 17:24:32 --> Total execution time: 0.1360
INFO - 2017-09-11 14:01:39 --> Config Class Initialized
INFO - 2017-09-11 14:01:39 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:01:39 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:01:39 --> Utf8 Class Initialized
INFO - 2017-09-11 14:01:39 --> URI Class Initialized
INFO - 2017-09-11 14:01:39 --> Router Class Initialized
INFO - 2017-09-11 14:01:39 --> Output Class Initialized
INFO - 2017-09-11 14:01:39 --> Security Class Initialized
DEBUG - 2017-09-11 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:01:39 --> Input Class Initialized
INFO - 2017-09-11 14:01:39 --> Language Class Initialized
INFO - 2017-09-11 14:01:39 --> Loader Class Initialized
INFO - 2017-09-11 14:01:39 --> Helper loaded: common_helper
INFO - 2017-09-11 14:01:39 --> Database Driver Class Initialized
INFO - 2017-09-11 14:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:01:39 --> Email Class Initialized
INFO - 2017-09-11 14:01:39 --> Controller Class Initialized
INFO - 2017-09-11 14:01:39 --> Helper loaded: form_helper
INFO - 2017-09-11 14:01:39 --> Form Validation Class Initialized
INFO - 2017-09-11 14:01:39 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:01:39 --> Helper loaded: url_helper
INFO - 2017-09-11 14:01:39 --> Model Class Initialized
INFO - 2017-09-11 14:01:39 --> Model Class Initialized
INFO - 2017-09-11 14:01:39 --> Model Class Initialized
INFO - 2017-09-11 17:31:39 --> Helper loaded: download_helper
INFO - 2017-09-11 17:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:31:39 --> Final output sent to browser
DEBUG - 2017-09-11 17:31:39 --> Total execution time: 0.0527
INFO - 2017-09-11 14:01:40 --> Config Class Initialized
INFO - 2017-09-11 14:01:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:01:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:01:40 --> Utf8 Class Initialized
INFO - 2017-09-11 14:01:40 --> URI Class Initialized
INFO - 2017-09-11 14:01:40 --> Router Class Initialized
INFO - 2017-09-11 14:01:40 --> Output Class Initialized
INFO - 2017-09-11 14:01:40 --> Security Class Initialized
DEBUG - 2017-09-11 14:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:01:40 --> Input Class Initialized
INFO - 2017-09-11 14:01:40 --> Language Class Initialized
INFO - 2017-09-11 14:01:40 --> Loader Class Initialized
INFO - 2017-09-11 14:01:40 --> Helper loaded: common_helper
INFO - 2017-09-11 14:01:40 --> Database Driver Class Initialized
INFO - 2017-09-11 14:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:01:40 --> Email Class Initialized
INFO - 2017-09-11 14:01:40 --> Controller Class Initialized
INFO - 2017-09-11 14:01:40 --> Helper loaded: form_helper
INFO - 2017-09-11 14:01:40 --> Form Validation Class Initialized
INFO - 2017-09-11 14:01:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:01:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:01:40 --> Helper loaded: url_helper
INFO - 2017-09-11 14:01:40 --> Model Class Initialized
INFO - 2017-09-11 14:01:40 --> Model Class Initialized
INFO - 2017-09-11 14:01:40 --> Model Class Initialized
INFO - 2017-09-11 17:31:40 --> Helper loaded: download_helper
INFO - 2017-09-11 17:31:40 --> Final output sent to browser
DEBUG - 2017-09-11 17:31:40 --> Total execution time: 0.1387
INFO - 2017-09-11 14:03:41 --> Config Class Initialized
INFO - 2017-09-11 14:03:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:03:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:03:41 --> Utf8 Class Initialized
INFO - 2017-09-11 14:03:41 --> URI Class Initialized
INFO - 2017-09-11 14:03:41 --> Router Class Initialized
INFO - 2017-09-11 14:03:41 --> Output Class Initialized
INFO - 2017-09-11 14:03:41 --> Security Class Initialized
DEBUG - 2017-09-11 14:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:03:41 --> Input Class Initialized
INFO - 2017-09-11 14:03:41 --> Language Class Initialized
INFO - 2017-09-11 14:03:41 --> Loader Class Initialized
INFO - 2017-09-11 14:03:41 --> Helper loaded: common_helper
INFO - 2017-09-11 14:03:41 --> Database Driver Class Initialized
INFO - 2017-09-11 14:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:03:41 --> Email Class Initialized
INFO - 2017-09-11 14:03:41 --> Controller Class Initialized
INFO - 2017-09-11 14:03:41 --> Helper loaded: form_helper
INFO - 2017-09-11 14:03:41 --> Form Validation Class Initialized
INFO - 2017-09-11 14:03:41 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:03:41 --> Helper loaded: url_helper
INFO - 2017-09-11 14:03:41 --> Model Class Initialized
INFO - 2017-09-11 14:03:41 --> Model Class Initialized
INFO - 2017-09-11 14:03:41 --> Model Class Initialized
INFO - 2017-09-11 17:33:41 --> Helper loaded: download_helper
INFO - 2017-09-11 17:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:33:41 --> Final output sent to browser
DEBUG - 2017-09-11 17:33:41 --> Total execution time: 0.0547
INFO - 2017-09-11 14:03:42 --> Config Class Initialized
INFO - 2017-09-11 14:03:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:03:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:03:42 --> Utf8 Class Initialized
INFO - 2017-09-11 14:03:42 --> URI Class Initialized
INFO - 2017-09-11 14:03:42 --> Router Class Initialized
INFO - 2017-09-11 14:03:42 --> Output Class Initialized
INFO - 2017-09-11 14:03:42 --> Security Class Initialized
DEBUG - 2017-09-11 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:03:42 --> Input Class Initialized
INFO - 2017-09-11 14:03:42 --> Language Class Initialized
INFO - 2017-09-11 14:03:42 --> Loader Class Initialized
INFO - 2017-09-11 14:03:42 --> Helper loaded: common_helper
INFO - 2017-09-11 14:03:42 --> Database Driver Class Initialized
INFO - 2017-09-11 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:03:42 --> Email Class Initialized
INFO - 2017-09-11 14:03:42 --> Controller Class Initialized
INFO - 2017-09-11 14:03:42 --> Helper loaded: form_helper
INFO - 2017-09-11 14:03:42 --> Form Validation Class Initialized
INFO - 2017-09-11 14:03:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:03:42 --> Helper loaded: url_helper
INFO - 2017-09-11 14:03:42 --> Model Class Initialized
INFO - 2017-09-11 14:03:42 --> Model Class Initialized
INFO - 2017-09-11 14:03:42 --> Model Class Initialized
INFO - 2017-09-11 17:33:42 --> Helper loaded: download_helper
INFO - 2017-09-11 14:05:04 --> Config Class Initialized
INFO - 2017-09-11 14:05:04 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:05:04 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:05:04 --> Utf8 Class Initialized
INFO - 2017-09-11 14:05:04 --> URI Class Initialized
INFO - 2017-09-11 14:05:04 --> Router Class Initialized
INFO - 2017-09-11 14:05:04 --> Output Class Initialized
INFO - 2017-09-11 14:05:04 --> Security Class Initialized
DEBUG - 2017-09-11 14:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:05:04 --> Input Class Initialized
INFO - 2017-09-11 14:05:04 --> Language Class Initialized
INFO - 2017-09-11 14:05:04 --> Loader Class Initialized
INFO - 2017-09-11 14:05:04 --> Helper loaded: common_helper
INFO - 2017-09-11 14:05:04 --> Database Driver Class Initialized
INFO - 2017-09-11 14:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:05:04 --> Email Class Initialized
INFO - 2017-09-11 14:05:04 --> Controller Class Initialized
INFO - 2017-09-11 14:05:04 --> Helper loaded: form_helper
INFO - 2017-09-11 14:05:04 --> Form Validation Class Initialized
INFO - 2017-09-11 14:05:04 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:05:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:05:04 --> Helper loaded: url_helper
INFO - 2017-09-11 14:05:04 --> Model Class Initialized
INFO - 2017-09-11 14:05:04 --> Model Class Initialized
INFO - 2017-09-11 14:05:04 --> Model Class Initialized
INFO - 2017-09-11 17:35:04 --> Helper loaded: download_helper
INFO - 2017-09-11 17:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:35:04 --> Final output sent to browser
DEBUG - 2017-09-11 17:35:04 --> Total execution time: 0.0495
INFO - 2017-09-11 14:05:06 --> Config Class Initialized
INFO - 2017-09-11 14:05:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:05:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:05:06 --> Utf8 Class Initialized
INFO - 2017-09-11 14:05:06 --> URI Class Initialized
INFO - 2017-09-11 14:05:06 --> Router Class Initialized
INFO - 2017-09-11 14:05:06 --> Output Class Initialized
INFO - 2017-09-11 14:05:06 --> Security Class Initialized
DEBUG - 2017-09-11 14:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:05:06 --> Input Class Initialized
INFO - 2017-09-11 14:05:06 --> Language Class Initialized
INFO - 2017-09-11 14:05:06 --> Loader Class Initialized
INFO - 2017-09-11 14:05:06 --> Helper loaded: common_helper
INFO - 2017-09-11 14:05:06 --> Database Driver Class Initialized
INFO - 2017-09-11 14:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:05:06 --> Email Class Initialized
INFO - 2017-09-11 14:05:06 --> Controller Class Initialized
INFO - 2017-09-11 14:05:06 --> Helper loaded: form_helper
INFO - 2017-09-11 14:05:06 --> Form Validation Class Initialized
INFO - 2017-09-11 14:05:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:05:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:05:06 --> Helper loaded: url_helper
INFO - 2017-09-11 14:05:06 --> Model Class Initialized
INFO - 2017-09-11 14:05:06 --> Model Class Initialized
INFO - 2017-09-11 14:05:06 --> Model Class Initialized
INFO - 2017-09-11 17:35:06 --> Helper loaded: download_helper
INFO - 2017-09-11 17:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:35:06 --> Final output sent to browser
DEBUG - 2017-09-11 17:35:06 --> Total execution time: 0.0561
INFO - 2017-09-11 14:05:07 --> Config Class Initialized
INFO - 2017-09-11 14:05:07 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:05:07 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:05:07 --> Utf8 Class Initialized
INFO - 2017-09-11 14:05:07 --> URI Class Initialized
INFO - 2017-09-11 14:05:07 --> Router Class Initialized
INFO - 2017-09-11 14:05:07 --> Output Class Initialized
INFO - 2017-09-11 14:05:07 --> Security Class Initialized
DEBUG - 2017-09-11 14:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:05:07 --> Input Class Initialized
INFO - 2017-09-11 14:05:07 --> Language Class Initialized
INFO - 2017-09-11 14:05:07 --> Loader Class Initialized
INFO - 2017-09-11 14:05:07 --> Helper loaded: common_helper
INFO - 2017-09-11 14:05:07 --> Database Driver Class Initialized
INFO - 2017-09-11 14:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:05:07 --> Email Class Initialized
INFO - 2017-09-11 14:05:07 --> Controller Class Initialized
INFO - 2017-09-11 14:05:07 --> Helper loaded: form_helper
INFO - 2017-09-11 14:05:07 --> Form Validation Class Initialized
INFO - 2017-09-11 14:05:07 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:05:07 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:05:07 --> Helper loaded: url_helper
INFO - 2017-09-11 14:05:07 --> Model Class Initialized
INFO - 2017-09-11 14:05:07 --> Model Class Initialized
INFO - 2017-09-11 14:05:07 --> Model Class Initialized
INFO - 2017-09-11 17:35:07 --> Helper loaded: download_helper
INFO - 2017-09-11 17:35:07 --> Final output sent to browser
DEBUG - 2017-09-11 17:35:07 --> Total execution time: 0.1255
INFO - 2017-09-11 14:05:53 --> Config Class Initialized
INFO - 2017-09-11 14:05:53 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:05:53 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:05:53 --> Utf8 Class Initialized
INFO - 2017-09-11 14:05:53 --> URI Class Initialized
INFO - 2017-09-11 14:05:53 --> Router Class Initialized
INFO - 2017-09-11 14:05:53 --> Output Class Initialized
INFO - 2017-09-11 14:05:53 --> Security Class Initialized
DEBUG - 2017-09-11 14:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:05:53 --> Input Class Initialized
INFO - 2017-09-11 14:05:53 --> Language Class Initialized
INFO - 2017-09-11 14:05:53 --> Loader Class Initialized
INFO - 2017-09-11 14:05:53 --> Helper loaded: common_helper
INFO - 2017-09-11 14:05:53 --> Database Driver Class Initialized
INFO - 2017-09-11 14:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:05:53 --> Email Class Initialized
INFO - 2017-09-11 14:05:53 --> Controller Class Initialized
INFO - 2017-09-11 14:05:53 --> Helper loaded: form_helper
INFO - 2017-09-11 14:05:53 --> Form Validation Class Initialized
INFO - 2017-09-11 14:05:53 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:05:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:05:53 --> Helper loaded: url_helper
INFO - 2017-09-11 14:05:53 --> Model Class Initialized
INFO - 2017-09-11 14:05:53 --> Model Class Initialized
INFO - 2017-09-11 14:05:53 --> Model Class Initialized
INFO - 2017-09-11 17:35:53 --> Helper loaded: download_helper
INFO - 2017-09-11 17:35:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:35:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:35:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:35:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:35:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:35:53 --> Final output sent to browser
DEBUG - 2017-09-11 17:35:53 --> Total execution time: 0.0557
INFO - 2017-09-11 14:06:31 --> Config Class Initialized
INFO - 2017-09-11 14:06:31 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:06:31 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:06:31 --> Utf8 Class Initialized
INFO - 2017-09-11 14:06:31 --> URI Class Initialized
INFO - 2017-09-11 14:06:31 --> Router Class Initialized
INFO - 2017-09-11 14:06:31 --> Output Class Initialized
INFO - 2017-09-11 14:06:31 --> Security Class Initialized
DEBUG - 2017-09-11 14:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:06:31 --> Input Class Initialized
INFO - 2017-09-11 14:06:31 --> Language Class Initialized
INFO - 2017-09-11 14:06:31 --> Loader Class Initialized
INFO - 2017-09-11 14:06:31 --> Helper loaded: common_helper
INFO - 2017-09-11 14:06:31 --> Database Driver Class Initialized
INFO - 2017-09-11 14:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:06:31 --> Email Class Initialized
INFO - 2017-09-11 14:06:31 --> Controller Class Initialized
INFO - 2017-09-11 14:06:31 --> Helper loaded: form_helper
INFO - 2017-09-11 14:06:31 --> Form Validation Class Initialized
INFO - 2017-09-11 14:06:31 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:06:31 --> Helper loaded: url_helper
INFO - 2017-09-11 14:06:31 --> Model Class Initialized
INFO - 2017-09-11 14:06:31 --> Model Class Initialized
INFO - 2017-09-11 14:06:31 --> Model Class Initialized
INFO - 2017-09-11 17:36:31 --> Helper loaded: download_helper
INFO - 2017-09-11 17:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:36:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:36:31 --> Final output sent to browser
DEBUG - 2017-09-11 17:36:31 --> Total execution time: 0.0619
INFO - 2017-09-11 14:06:32 --> Config Class Initialized
INFO - 2017-09-11 14:06:32 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:06:32 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:06:32 --> Utf8 Class Initialized
INFO - 2017-09-11 14:06:32 --> URI Class Initialized
INFO - 2017-09-11 14:06:32 --> Router Class Initialized
INFO - 2017-09-11 14:06:32 --> Output Class Initialized
INFO - 2017-09-11 14:06:32 --> Security Class Initialized
DEBUG - 2017-09-11 14:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:06:32 --> Input Class Initialized
INFO - 2017-09-11 14:06:32 --> Language Class Initialized
INFO - 2017-09-11 14:06:32 --> Loader Class Initialized
INFO - 2017-09-11 14:06:32 --> Helper loaded: common_helper
INFO - 2017-09-11 14:06:32 --> Database Driver Class Initialized
INFO - 2017-09-11 14:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:06:32 --> Email Class Initialized
INFO - 2017-09-11 14:06:32 --> Controller Class Initialized
INFO - 2017-09-11 14:06:32 --> Helper loaded: form_helper
INFO - 2017-09-11 14:06:32 --> Form Validation Class Initialized
INFO - 2017-09-11 14:06:32 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:06:32 --> Helper loaded: url_helper
INFO - 2017-09-11 14:06:32 --> Model Class Initialized
INFO - 2017-09-11 14:06:32 --> Model Class Initialized
INFO - 2017-09-11 14:06:32 --> Model Class Initialized
INFO - 2017-09-11 17:36:32 --> Helper loaded: download_helper
INFO - 2017-09-11 17:36:33 --> Final output sent to browser
DEBUG - 2017-09-11 17:36:33 --> Total execution time: 0.1246
INFO - 2017-09-11 14:08:11 --> Config Class Initialized
INFO - 2017-09-11 14:08:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:08:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:08:11 --> Utf8 Class Initialized
INFO - 2017-09-11 14:08:11 --> URI Class Initialized
INFO - 2017-09-11 14:08:11 --> Router Class Initialized
INFO - 2017-09-11 14:08:11 --> Output Class Initialized
INFO - 2017-09-11 14:08:11 --> Security Class Initialized
DEBUG - 2017-09-11 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:08:11 --> Input Class Initialized
INFO - 2017-09-11 14:08:11 --> Language Class Initialized
INFO - 2017-09-11 14:08:11 --> Loader Class Initialized
INFO - 2017-09-11 14:08:11 --> Helper loaded: common_helper
INFO - 2017-09-11 14:08:11 --> Database Driver Class Initialized
INFO - 2017-09-11 14:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:08:11 --> Email Class Initialized
INFO - 2017-09-11 14:08:11 --> Controller Class Initialized
INFO - 2017-09-11 14:08:11 --> Helper loaded: form_helper
INFO - 2017-09-11 14:08:11 --> Form Validation Class Initialized
INFO - 2017-09-11 14:08:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:08:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:08:11 --> Helper loaded: url_helper
INFO - 2017-09-11 14:08:11 --> Model Class Initialized
INFO - 2017-09-11 14:08:11 --> Model Class Initialized
INFO - 2017-09-11 14:08:11 --> Model Class Initialized
INFO - 2017-09-11 17:38:11 --> Helper loaded: download_helper
INFO - 2017-09-11 17:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:38:11 --> Final output sent to browser
DEBUG - 2017-09-11 17:38:11 --> Total execution time: 0.0556
INFO - 2017-09-11 14:08:12 --> Config Class Initialized
INFO - 2017-09-11 14:08:12 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:08:12 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:08:12 --> Utf8 Class Initialized
INFO - 2017-09-11 14:08:12 --> URI Class Initialized
INFO - 2017-09-11 14:08:12 --> Router Class Initialized
INFO - 2017-09-11 14:08:12 --> Output Class Initialized
INFO - 2017-09-11 14:08:12 --> Security Class Initialized
DEBUG - 2017-09-11 14:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:08:12 --> Input Class Initialized
INFO - 2017-09-11 14:08:12 --> Language Class Initialized
INFO - 2017-09-11 14:08:12 --> Loader Class Initialized
INFO - 2017-09-11 14:08:12 --> Helper loaded: common_helper
INFO - 2017-09-11 14:08:12 --> Database Driver Class Initialized
INFO - 2017-09-11 14:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:08:12 --> Email Class Initialized
INFO - 2017-09-11 14:08:12 --> Controller Class Initialized
INFO - 2017-09-11 14:08:12 --> Helper loaded: form_helper
INFO - 2017-09-11 14:08:12 --> Form Validation Class Initialized
INFO - 2017-09-11 14:08:12 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:08:12 --> Helper loaded: url_helper
INFO - 2017-09-11 14:08:12 --> Model Class Initialized
INFO - 2017-09-11 14:08:12 --> Model Class Initialized
INFO - 2017-09-11 14:08:12 --> Model Class Initialized
INFO - 2017-09-11 17:38:12 --> Helper loaded: download_helper
INFO - 2017-09-11 17:38:12 --> Final output sent to browser
DEBUG - 2017-09-11 17:38:12 --> Total execution time: 0.1347
INFO - 2017-09-11 14:08:37 --> Config Class Initialized
INFO - 2017-09-11 14:08:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:08:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:08:37 --> Utf8 Class Initialized
INFO - 2017-09-11 14:08:37 --> URI Class Initialized
INFO - 2017-09-11 14:08:37 --> Router Class Initialized
INFO - 2017-09-11 14:08:37 --> Output Class Initialized
INFO - 2017-09-11 14:08:37 --> Security Class Initialized
DEBUG - 2017-09-11 14:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:08:37 --> Input Class Initialized
INFO - 2017-09-11 14:08:37 --> Language Class Initialized
INFO - 2017-09-11 14:08:37 --> Loader Class Initialized
INFO - 2017-09-11 14:08:37 --> Helper loaded: common_helper
INFO - 2017-09-11 14:08:37 --> Database Driver Class Initialized
INFO - 2017-09-11 14:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:08:37 --> Email Class Initialized
INFO - 2017-09-11 14:08:37 --> Controller Class Initialized
INFO - 2017-09-11 14:08:37 --> Helper loaded: form_helper
INFO - 2017-09-11 14:08:37 --> Form Validation Class Initialized
INFO - 2017-09-11 14:08:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:08:37 --> Helper loaded: url_helper
INFO - 2017-09-11 14:08:37 --> Model Class Initialized
INFO - 2017-09-11 14:08:37 --> Model Class Initialized
INFO - 2017-09-11 14:08:37 --> Model Class Initialized
INFO - 2017-09-11 17:38:37 --> Helper loaded: download_helper
INFO - 2017-09-11 17:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:38:37 --> Final output sent to browser
DEBUG - 2017-09-11 17:38:37 --> Total execution time: 0.0531
INFO - 2017-09-11 14:08:37 --> Config Class Initialized
INFO - 2017-09-11 14:08:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:08:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:08:37 --> Utf8 Class Initialized
INFO - 2017-09-11 14:08:37 --> URI Class Initialized
INFO - 2017-09-11 14:08:37 --> Router Class Initialized
INFO - 2017-09-11 14:08:37 --> Output Class Initialized
INFO - 2017-09-11 14:08:37 --> Security Class Initialized
DEBUG - 2017-09-11 14:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:08:37 --> Input Class Initialized
INFO - 2017-09-11 14:08:37 --> Language Class Initialized
INFO - 2017-09-11 14:08:37 --> Loader Class Initialized
INFO - 2017-09-11 14:08:37 --> Helper loaded: common_helper
INFO - 2017-09-11 14:08:37 --> Database Driver Class Initialized
INFO - 2017-09-11 14:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:08:37 --> Email Class Initialized
INFO - 2017-09-11 14:08:37 --> Controller Class Initialized
INFO - 2017-09-11 14:08:37 --> Helper loaded: form_helper
INFO - 2017-09-11 14:08:37 --> Form Validation Class Initialized
INFO - 2017-09-11 14:08:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:08:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:08:37 --> Helper loaded: url_helper
INFO - 2017-09-11 14:08:37 --> Model Class Initialized
INFO - 2017-09-11 14:08:37 --> Model Class Initialized
INFO - 2017-09-11 14:08:37 --> Model Class Initialized
INFO - 2017-09-11 17:38:37 --> Helper loaded: download_helper
INFO - 2017-09-11 17:38:37 --> Final output sent to browser
DEBUG - 2017-09-11 17:38:37 --> Total execution time: 0.1335
INFO - 2017-09-11 14:14:16 --> Config Class Initialized
INFO - 2017-09-11 14:14:16 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:14:16 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:14:16 --> Utf8 Class Initialized
INFO - 2017-09-11 14:14:16 --> URI Class Initialized
INFO - 2017-09-11 14:14:16 --> Router Class Initialized
INFO - 2017-09-11 14:14:16 --> Output Class Initialized
INFO - 2017-09-11 14:14:16 --> Security Class Initialized
DEBUG - 2017-09-11 14:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:14:16 --> Input Class Initialized
INFO - 2017-09-11 14:14:16 --> Language Class Initialized
INFO - 2017-09-11 14:14:16 --> Loader Class Initialized
INFO - 2017-09-11 14:14:16 --> Helper loaded: common_helper
INFO - 2017-09-11 14:14:16 --> Database Driver Class Initialized
INFO - 2017-09-11 14:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:14:16 --> Email Class Initialized
INFO - 2017-09-11 14:14:16 --> Controller Class Initialized
INFO - 2017-09-11 14:14:16 --> Helper loaded: form_helper
INFO - 2017-09-11 14:14:16 --> Form Validation Class Initialized
INFO - 2017-09-11 14:14:16 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:14:16 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:14:16 --> Helper loaded: url_helper
INFO - 2017-09-11 14:14:16 --> Model Class Initialized
INFO - 2017-09-11 14:14:16 --> Model Class Initialized
INFO - 2017-09-11 14:14:16 --> Model Class Initialized
INFO - 2017-09-11 17:44:16 --> Helper loaded: download_helper
INFO - 2017-09-11 17:44:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 17:44:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 17:44:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 17:44:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 17:44:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 17:44:16 --> Final output sent to browser
DEBUG - 2017-09-11 17:44:16 --> Total execution time: 0.0546
INFO - 2017-09-11 14:14:17 --> Config Class Initialized
INFO - 2017-09-11 14:14:17 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:14:17 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:14:17 --> Utf8 Class Initialized
INFO - 2017-09-11 14:14:17 --> URI Class Initialized
INFO - 2017-09-11 14:14:17 --> Router Class Initialized
INFO - 2017-09-11 14:14:17 --> Output Class Initialized
INFO - 2017-09-11 14:14:17 --> Security Class Initialized
DEBUG - 2017-09-11 14:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:14:17 --> Input Class Initialized
INFO - 2017-09-11 14:14:17 --> Language Class Initialized
INFO - 2017-09-11 14:14:17 --> Loader Class Initialized
INFO - 2017-09-11 14:14:17 --> Helper loaded: common_helper
INFO - 2017-09-11 14:14:17 --> Database Driver Class Initialized
INFO - 2017-09-11 14:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:14:17 --> Email Class Initialized
INFO - 2017-09-11 14:14:17 --> Controller Class Initialized
INFO - 2017-09-11 14:14:17 --> Helper loaded: form_helper
INFO - 2017-09-11 14:14:17 --> Form Validation Class Initialized
INFO - 2017-09-11 14:14:17 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:14:17 --> Helper loaded: url_helper
INFO - 2017-09-11 14:14:17 --> Model Class Initialized
INFO - 2017-09-11 14:14:17 --> Model Class Initialized
INFO - 2017-09-11 14:14:17 --> Model Class Initialized
INFO - 2017-09-11 17:44:17 --> Helper loaded: download_helper
INFO - 2017-09-11 17:44:17 --> Final output sent to browser
DEBUG - 2017-09-11 17:44:17 --> Total execution time: 0.1266
INFO - 2017-09-11 14:29:26 --> Config Class Initialized
INFO - 2017-09-11 14:29:26 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:26 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:26 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:26 --> URI Class Initialized
INFO - 2017-09-11 14:29:27 --> Router Class Initialized
INFO - 2017-09-11 14:29:27 --> Output Class Initialized
INFO - 2017-09-11 14:29:27 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:27 --> Input Class Initialized
INFO - 2017-09-11 14:29:27 --> Language Class Initialized
ERROR - 2017-09-11 14:29:27 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:27 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:55 --> Config Class Initialized
INFO - 2017-09-11 14:29:55 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:55 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:55 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:55 --> URI Class Initialized
INFO - 2017-09-11 14:29:55 --> Router Class Initialized
INFO - 2017-09-11 14:29:55 --> Output Class Initialized
INFO - 2017-09-11 14:29:55 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:55 --> Input Class Initialized
INFO - 2017-09-11 14:29:55 --> Language Class Initialized
ERROR - 2017-09-11 14:29:55 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:56 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:57 --> Config Class Initialized
INFO - 2017-09-11 14:29:57 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:57 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:57 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:57 --> URI Class Initialized
INFO - 2017-09-11 14:29:57 --> Router Class Initialized
INFO - 2017-09-11 14:29:57 --> Output Class Initialized
INFO - 2017-09-11 14:29:57 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:57 --> Input Class Initialized
INFO - 2017-09-11 14:29:57 --> Language Class Initialized
ERROR - 2017-09-11 14:29:57 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:57 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:57 --> Config Class Initialized
INFO - 2017-09-11 14:29:57 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:57 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:57 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:57 --> URI Class Initialized
INFO - 2017-09-11 14:29:57 --> Router Class Initialized
INFO - 2017-09-11 14:29:57 --> Output Class Initialized
INFO - 2017-09-11 14:29:57 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:57 --> Input Class Initialized
INFO - 2017-09-11 14:29:57 --> Language Class Initialized
ERROR - 2017-09-11 14:29:57 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:57 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:57 --> Config Class Initialized
INFO - 2017-09-11 14:29:57 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:57 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:57 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:57 --> URI Class Initialized
INFO - 2017-09-11 14:29:57 --> Router Class Initialized
INFO - 2017-09-11 14:29:57 --> Output Class Initialized
INFO - 2017-09-11 14:29:57 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:57 --> Input Class Initialized
INFO - 2017-09-11 14:29:57 --> Language Class Initialized
ERROR - 2017-09-11 14:29:57 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:57 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:58 --> Config Class Initialized
INFO - 2017-09-11 14:29:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:58 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:58 --> URI Class Initialized
INFO - 2017-09-11 14:29:58 --> Router Class Initialized
INFO - 2017-09-11 14:29:58 --> Output Class Initialized
INFO - 2017-09-11 14:29:58 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:58 --> Input Class Initialized
INFO - 2017-09-11 14:29:58 --> Language Class Initialized
ERROR - 2017-09-11 14:29:58 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:58 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:58 --> Config Class Initialized
INFO - 2017-09-11 14:29:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:58 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:58 --> URI Class Initialized
INFO - 2017-09-11 14:29:58 --> Router Class Initialized
INFO - 2017-09-11 14:29:58 --> Output Class Initialized
INFO - 2017-09-11 14:29:58 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:58 --> Input Class Initialized
INFO - 2017-09-11 14:29:58 --> Language Class Initialized
ERROR - 2017-09-11 14:29:58 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:58 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:29:58 --> Config Class Initialized
INFO - 2017-09-11 14:29:58 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:29:58 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:29:58 --> Utf8 Class Initialized
INFO - 2017-09-11 14:29:58 --> URI Class Initialized
INFO - 2017-09-11 14:29:58 --> Router Class Initialized
INFO - 2017-09-11 14:29:58 --> Output Class Initialized
INFO - 2017-09-11 14:29:58 --> Security Class Initialized
DEBUG - 2017-09-11 14:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:29:58 --> Input Class Initialized
INFO - 2017-09-11 14:29:58 --> Language Class Initialized
ERROR - 2017-09-11 14:29:58 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:29:58 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:30:07 --> Config Class Initialized
INFO - 2017-09-11 14:30:07 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:30:07 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:30:07 --> Utf8 Class Initialized
INFO - 2017-09-11 14:30:07 --> URI Class Initialized
INFO - 2017-09-11 14:30:07 --> Router Class Initialized
INFO - 2017-09-11 14:30:07 --> Output Class Initialized
INFO - 2017-09-11 14:30:07 --> Security Class Initialized
DEBUG - 2017-09-11 14:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:30:07 --> Input Class Initialized
INFO - 2017-09-11 14:30:07 --> Language Class Initialized
ERROR - 2017-09-11 14:30:07 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:30:07 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:30:08 --> Config Class Initialized
INFO - 2017-09-11 14:30:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:30:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:30:08 --> Utf8 Class Initialized
INFO - 2017-09-11 14:30:08 --> URI Class Initialized
INFO - 2017-09-11 14:30:08 --> Router Class Initialized
INFO - 2017-09-11 14:30:08 --> Output Class Initialized
INFO - 2017-09-11 14:30:08 --> Security Class Initialized
DEBUG - 2017-09-11 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:30:08 --> Input Class Initialized
INFO - 2017-09-11 14:30:08 --> Language Class Initialized
ERROR - 2017-09-11 14:30:08 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:30:08 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:30:08 --> Config Class Initialized
INFO - 2017-09-11 14:30:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:30:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:30:08 --> Utf8 Class Initialized
INFO - 2017-09-11 14:30:08 --> URI Class Initialized
INFO - 2017-09-11 14:30:08 --> Router Class Initialized
INFO - 2017-09-11 14:30:08 --> Output Class Initialized
INFO - 2017-09-11 14:30:08 --> Security Class Initialized
DEBUG - 2017-09-11 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:30:08 --> Input Class Initialized
INFO - 2017-09-11 14:30:08 --> Language Class Initialized
ERROR - 2017-09-11 14:30:08 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:30:08 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:30:08 --> Config Class Initialized
INFO - 2017-09-11 14:30:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:30:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:30:08 --> Utf8 Class Initialized
INFO - 2017-09-11 14:30:08 --> URI Class Initialized
INFO - 2017-09-11 14:30:08 --> Router Class Initialized
INFO - 2017-09-11 14:30:08 --> Output Class Initialized
INFO - 2017-09-11 14:30:08 --> Security Class Initialized
DEBUG - 2017-09-11 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:30:08 --> Input Class Initialized
INFO - 2017-09-11 14:30:08 --> Language Class Initialized
ERROR - 2017-09-11 14:30:08 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:30:08 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:30:08 --> Config Class Initialized
INFO - 2017-09-11 14:30:08 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:30:08 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:30:08 --> Utf8 Class Initialized
INFO - 2017-09-11 14:30:08 --> URI Class Initialized
INFO - 2017-09-11 14:30:08 --> Router Class Initialized
INFO - 2017-09-11 14:30:08 --> Output Class Initialized
INFO - 2017-09-11 14:30:08 --> Security Class Initialized
DEBUG - 2017-09-11 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:30:08 --> Input Class Initialized
INFO - 2017-09-11 14:30:08 --> Language Class Initialized
ERROR - 2017-09-11 14:30:08 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:30:08 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:33:40 --> Config Class Initialized
INFO - 2017-09-11 14:33:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:33:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:33:40 --> Utf8 Class Initialized
INFO - 2017-09-11 14:33:40 --> URI Class Initialized
INFO - 2017-09-11 14:33:40 --> Router Class Initialized
INFO - 2017-09-11 14:33:40 --> Output Class Initialized
INFO - 2017-09-11 14:33:40 --> Security Class Initialized
DEBUG - 2017-09-11 14:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:33:40 --> Input Class Initialized
INFO - 2017-09-11 14:33:40 --> Language Class Initialized
INFO - 2017-09-11 14:33:40 --> Loader Class Initialized
INFO - 2017-09-11 14:33:40 --> Helper loaded: common_helper
INFO - 2017-09-11 14:33:40 --> Database Driver Class Initialized
INFO - 2017-09-11 14:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:33:40 --> Email Class Initialized
INFO - 2017-09-11 14:33:40 --> Controller Class Initialized
INFO - 2017-09-11 14:33:40 --> Helper loaded: form_helper
INFO - 2017-09-11 14:33:40 --> Form Validation Class Initialized
INFO - 2017-09-11 14:33:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:33:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:33:40 --> Helper loaded: url_helper
INFO - 2017-09-11 18:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/addSettings.php
INFO - 2017-09-11 18:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:03:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:03:40 --> Final output sent to browser
DEBUG - 2017-09-11 18:03:40 --> Total execution time: 0.0472
INFO - 2017-09-11 14:37:21 --> Config Class Initialized
INFO - 2017-09-11 14:37:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:37:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:37:21 --> Utf8 Class Initialized
INFO - 2017-09-11 14:37:21 --> URI Class Initialized
DEBUG - 2017-09-11 14:37:21 --> No URI present. Default controller set.
INFO - 2017-09-11 14:37:21 --> Router Class Initialized
INFO - 2017-09-11 14:37:21 --> Output Class Initialized
INFO - 2017-09-11 14:37:21 --> Security Class Initialized
DEBUG - 2017-09-11 14:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:37:21 --> Input Class Initialized
INFO - 2017-09-11 14:37:21 --> Language Class Initialized
INFO - 2017-09-11 14:37:21 --> Loader Class Initialized
INFO - 2017-09-11 14:37:21 --> Helper loaded: common_helper
INFO - 2017-09-11 14:37:21 --> Database Driver Class Initialized
INFO - 2017-09-11 14:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:37:21 --> Email Class Initialized
INFO - 2017-09-11 14:37:21 --> Controller Class Initialized
INFO - 2017-09-11 14:37:21 --> Helper loaded: form_helper
INFO - 2017-09-11 14:37:21 --> Form Validation Class Initialized
INFO - 2017-09-11 14:37:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:37:21 --> Helper loaded: url_helper
INFO - 2017-09-11 14:37:21 --> Model Class Initialized
INFO - 2017-09-11 14:37:21 --> Model Class Initialized
INFO - 2017-09-11 14:37:21 --> Config Class Initialized
INFO - 2017-09-11 14:37:21 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:37:21 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:37:21 --> Utf8 Class Initialized
INFO - 2017-09-11 14:37:21 --> URI Class Initialized
INFO - 2017-09-11 14:37:21 --> Router Class Initialized
INFO - 2017-09-11 14:37:21 --> Output Class Initialized
INFO - 2017-09-11 14:37:21 --> Security Class Initialized
DEBUG - 2017-09-11 14:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:37:21 --> Input Class Initialized
INFO - 2017-09-11 14:37:21 --> Language Class Initialized
INFO - 2017-09-11 14:37:21 --> Loader Class Initialized
INFO - 2017-09-11 14:37:21 --> Helper loaded: common_helper
INFO - 2017-09-11 14:37:21 --> Database Driver Class Initialized
INFO - 2017-09-11 14:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:37:21 --> Email Class Initialized
INFO - 2017-09-11 14:37:21 --> Controller Class Initialized
INFO - 2017-09-11 14:37:21 --> Helper loaded: form_helper
INFO - 2017-09-11 14:37:21 --> Form Validation Class Initialized
INFO - 2017-09-11 14:37:21 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:37:21 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:37:21 --> Helper loaded: url_helper
INFO - 2017-09-11 14:37:21 --> Model Class Initialized
INFO - 2017-09-11 14:37:21 --> Model Class Initialized
INFO - 2017-09-11 14:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 14:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 14:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-09-11 14:37:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 14:37:21 --> Final output sent to browser
DEBUG - 2017-09-11 14:37:21 --> Total execution time: 0.0578
INFO - 2017-09-11 14:37:23 --> Config Class Initialized
INFO - 2017-09-11 14:37:23 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:37:23 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:37:23 --> Utf8 Class Initialized
INFO - 2017-09-11 14:37:23 --> URI Class Initialized
INFO - 2017-09-11 14:37:23 --> Router Class Initialized
INFO - 2017-09-11 14:37:23 --> Output Class Initialized
INFO - 2017-09-11 14:37:23 --> Security Class Initialized
DEBUG - 2017-09-11 14:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:37:23 --> Input Class Initialized
INFO - 2017-09-11 14:37:23 --> Language Class Initialized
ERROR - 2017-09-11 14:37:23 --> syntax error, unexpected 'column' (T_STRING)
ERROR - 2017-09-11 14:37:23 --> Severity: Parsing Error --> syntax error, unexpected 'column' (T_STRING) C:\xampp\htdocs\FlickNews\admin\application\controllers\Users.php 181
INFO - 2017-09-11 14:37:46 --> Config Class Initialized
INFO - 2017-09-11 14:37:46 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:37:46 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:37:46 --> Utf8 Class Initialized
INFO - 2017-09-11 14:37:46 --> URI Class Initialized
INFO - 2017-09-11 14:37:46 --> Router Class Initialized
INFO - 2017-09-11 14:37:46 --> Output Class Initialized
INFO - 2017-09-11 14:37:46 --> Security Class Initialized
DEBUG - 2017-09-11 14:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:37:46 --> Input Class Initialized
INFO - 2017-09-11 14:37:46 --> Language Class Initialized
INFO - 2017-09-11 14:37:46 --> Loader Class Initialized
INFO - 2017-09-11 14:37:46 --> Helper loaded: common_helper
INFO - 2017-09-11 14:37:46 --> Database Driver Class Initialized
INFO - 2017-09-11 14:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:37:46 --> Email Class Initialized
INFO - 2017-09-11 14:37:46 --> Controller Class Initialized
INFO - 2017-09-11 14:37:46 --> Helper loaded: form_helper
INFO - 2017-09-11 14:37:46 --> Form Validation Class Initialized
INFO - 2017-09-11 14:37:46 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:37:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:37:46 --> Helper loaded: url_helper
INFO - 2017-09-11 14:37:46 --> Model Class Initialized
INFO - 2017-09-11 14:37:46 --> Model Class Initialized
INFO - 2017-09-11 14:37:46 --> Model Class Initialized
INFO - 2017-09-11 18:07:46 --> Helper loaded: download_helper
INFO - 2017-09-11 18:07:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:07:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:07:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:07:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:07:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:07:46 --> Final output sent to browser
DEBUG - 2017-09-11 18:07:46 --> Total execution time: 0.0513
INFO - 2017-09-11 14:38:06 --> Config Class Initialized
INFO - 2017-09-11 14:38:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 14:38:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 14:38:06 --> Utf8 Class Initialized
INFO - 2017-09-11 14:38:06 --> URI Class Initialized
INFO - 2017-09-11 14:38:06 --> Router Class Initialized
INFO - 2017-09-11 14:38:06 --> Output Class Initialized
INFO - 2017-09-11 14:38:06 --> Security Class Initialized
DEBUG - 2017-09-11 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 14:38:06 --> Input Class Initialized
INFO - 2017-09-11 14:38:06 --> Language Class Initialized
INFO - 2017-09-11 14:38:06 --> Loader Class Initialized
INFO - 2017-09-11 14:38:06 --> Helper loaded: common_helper
INFO - 2017-09-11 14:38:06 --> Database Driver Class Initialized
INFO - 2017-09-11 14:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 14:38:06 --> Email Class Initialized
INFO - 2017-09-11 14:38:06 --> Controller Class Initialized
INFO - 2017-09-11 14:38:06 --> Helper loaded: form_helper
INFO - 2017-09-11 14:38:06 --> Form Validation Class Initialized
INFO - 2017-09-11 14:38:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 14:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 14:38:06 --> Helper loaded: url_helper
INFO - 2017-09-11 14:38:06 --> Model Class Initialized
INFO - 2017-09-11 14:38:06 --> Model Class Initialized
INFO - 2017-09-11 14:38:06 --> Model Class Initialized
INFO - 2017-09-11 18:08:06 --> Helper loaded: download_helper
INFO - 2017-09-11 18:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:08:06 --> Final output sent to browser
DEBUG - 2017-09-11 18:08:06 --> Total execution time: 0.0510
INFO - 2017-09-11 15:11:37 --> Config Class Initialized
INFO - 2017-09-11 15:11:37 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:11:37 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:11:37 --> Utf8 Class Initialized
INFO - 2017-09-11 15:11:37 --> URI Class Initialized
INFO - 2017-09-11 15:11:37 --> Router Class Initialized
INFO - 2017-09-11 15:11:37 --> Output Class Initialized
INFO - 2017-09-11 15:11:37 --> Security Class Initialized
DEBUG - 2017-09-11 15:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:11:37 --> Input Class Initialized
INFO - 2017-09-11 15:11:37 --> Language Class Initialized
INFO - 2017-09-11 15:11:37 --> Loader Class Initialized
INFO - 2017-09-11 15:11:37 --> Helper loaded: common_helper
INFO - 2017-09-11 15:11:37 --> Database Driver Class Initialized
INFO - 2017-09-11 15:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:11:37 --> Email Class Initialized
INFO - 2017-09-11 15:11:37 --> Controller Class Initialized
INFO - 2017-09-11 15:11:37 --> Helper loaded: form_helper
INFO - 2017-09-11 15:11:37 --> Form Validation Class Initialized
INFO - 2017-09-11 15:11:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:11:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:11:37 --> Helper loaded: url_helper
INFO - 2017-09-11 15:11:37 --> Model Class Initialized
INFO - 2017-09-11 15:11:37 --> Model Class Initialized
INFO - 2017-09-11 15:11:37 --> Model Class Initialized
INFO - 2017-09-11 18:41:37 --> Helper loaded: download_helper
INFO - 2017-09-11 18:41:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:41:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:41:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:41:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:41:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:41:37 --> Final output sent to browser
DEBUG - 2017-09-11 18:41:37 --> Total execution time: 0.0524
INFO - 2017-09-11 15:11:56 --> Config Class Initialized
INFO - 2017-09-11 15:11:56 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:11:56 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:11:56 --> Utf8 Class Initialized
INFO - 2017-09-11 15:11:56 --> URI Class Initialized
INFO - 2017-09-11 15:11:56 --> Router Class Initialized
INFO - 2017-09-11 15:11:56 --> Output Class Initialized
INFO - 2017-09-11 15:11:56 --> Security Class Initialized
DEBUG - 2017-09-11 15:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:11:56 --> Input Class Initialized
INFO - 2017-09-11 15:11:56 --> Language Class Initialized
INFO - 2017-09-11 15:11:56 --> Loader Class Initialized
INFO - 2017-09-11 15:11:56 --> Helper loaded: common_helper
INFO - 2017-09-11 15:11:56 --> Database Driver Class Initialized
INFO - 2017-09-11 15:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:11:56 --> Email Class Initialized
INFO - 2017-09-11 15:11:56 --> Controller Class Initialized
INFO - 2017-09-11 15:11:56 --> Helper loaded: form_helper
INFO - 2017-09-11 15:11:56 --> Form Validation Class Initialized
INFO - 2017-09-11 15:11:56 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:11:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:11:56 --> Helper loaded: url_helper
INFO - 2017-09-11 15:11:56 --> Model Class Initialized
INFO - 2017-09-11 15:11:56 --> Model Class Initialized
INFO - 2017-09-11 15:11:56 --> Model Class Initialized
INFO - 2017-09-11 18:41:56 --> Helper loaded: download_helper
INFO - 2017-09-11 18:41:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:41:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:41:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:41:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:41:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:41:56 --> Final output sent to browser
DEBUG - 2017-09-11 18:41:56 --> Total execution time: 0.0481
INFO - 2017-09-11 15:12:00 --> Config Class Initialized
INFO - 2017-09-11 15:12:00 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:12:00 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:12:00 --> Utf8 Class Initialized
INFO - 2017-09-11 15:12:00 --> URI Class Initialized
INFO - 2017-09-11 15:12:00 --> Router Class Initialized
INFO - 2017-09-11 15:12:00 --> Output Class Initialized
INFO - 2017-09-11 15:12:00 --> Security Class Initialized
DEBUG - 2017-09-11 15:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:12:00 --> Input Class Initialized
INFO - 2017-09-11 15:12:00 --> Language Class Initialized
INFO - 2017-09-11 15:12:00 --> Loader Class Initialized
INFO - 2017-09-11 15:12:00 --> Helper loaded: common_helper
INFO - 2017-09-11 15:12:00 --> Database Driver Class Initialized
INFO - 2017-09-11 15:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:12:00 --> Email Class Initialized
INFO - 2017-09-11 15:12:00 --> Controller Class Initialized
INFO - 2017-09-11 15:12:00 --> Helper loaded: form_helper
INFO - 2017-09-11 15:12:00 --> Form Validation Class Initialized
INFO - 2017-09-11 15:12:00 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:12:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:12:00 --> Helper loaded: url_helper
INFO - 2017-09-11 15:12:00 --> Model Class Initialized
INFO - 2017-09-11 15:12:00 --> Model Class Initialized
INFO - 2017-09-11 15:12:00 --> Model Class Initialized
INFO - 2017-09-11 18:42:00 --> Helper loaded: download_helper
INFO - 2017-09-11 18:42:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:42:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:42:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:42:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:42:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:42:00 --> Final output sent to browser
DEBUG - 2017-09-11 18:42:00 --> Total execution time: 0.0492
INFO - 2017-09-11 15:14:23 --> Config Class Initialized
INFO - 2017-09-11 15:14:23 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:14:23 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:14:23 --> Utf8 Class Initialized
INFO - 2017-09-11 15:14:23 --> URI Class Initialized
INFO - 2017-09-11 15:14:23 --> Router Class Initialized
INFO - 2017-09-11 15:14:23 --> Output Class Initialized
INFO - 2017-09-11 15:14:23 --> Security Class Initialized
DEBUG - 2017-09-11 15:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:14:23 --> Input Class Initialized
INFO - 2017-09-11 15:14:23 --> Language Class Initialized
INFO - 2017-09-11 15:14:23 --> Loader Class Initialized
INFO - 2017-09-11 15:14:23 --> Helper loaded: common_helper
INFO - 2017-09-11 15:14:23 --> Database Driver Class Initialized
INFO - 2017-09-11 15:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:14:23 --> Email Class Initialized
INFO - 2017-09-11 15:14:23 --> Controller Class Initialized
INFO - 2017-09-11 15:14:23 --> Helper loaded: form_helper
INFO - 2017-09-11 15:14:23 --> Form Validation Class Initialized
INFO - 2017-09-11 15:14:23 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:14:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:14:23 --> Helper loaded: url_helper
INFO - 2017-09-11 15:14:23 --> Model Class Initialized
INFO - 2017-09-11 15:14:23 --> Model Class Initialized
INFO - 2017-09-11 15:14:23 --> Model Class Initialized
INFO - 2017-09-11 18:44:23 --> Helper loaded: download_helper
INFO - 2017-09-11 18:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:44:23 --> Final output sent to browser
DEBUG - 2017-09-11 18:44:23 --> Total execution time: 0.0499
INFO - 2017-09-11 15:14:41 --> Config Class Initialized
INFO - 2017-09-11 15:14:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:14:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:14:41 --> Utf8 Class Initialized
INFO - 2017-09-11 15:14:41 --> URI Class Initialized
INFO - 2017-09-11 15:14:41 --> Router Class Initialized
INFO - 2017-09-11 15:14:41 --> Output Class Initialized
INFO - 2017-09-11 15:14:41 --> Security Class Initialized
DEBUG - 2017-09-11 15:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:14:41 --> Input Class Initialized
INFO - 2017-09-11 15:14:41 --> Language Class Initialized
INFO - 2017-09-11 15:14:41 --> Loader Class Initialized
INFO - 2017-09-11 15:14:41 --> Helper loaded: common_helper
INFO - 2017-09-11 15:14:41 --> Database Driver Class Initialized
INFO - 2017-09-11 15:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:14:41 --> Email Class Initialized
INFO - 2017-09-11 15:14:41 --> Controller Class Initialized
INFO - 2017-09-11 15:14:41 --> Helper loaded: form_helper
INFO - 2017-09-11 15:14:41 --> Form Validation Class Initialized
INFO - 2017-09-11 15:14:41 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:14:41 --> Helper loaded: url_helper
INFO - 2017-09-11 15:14:41 --> Model Class Initialized
INFO - 2017-09-11 15:14:41 --> Model Class Initialized
INFO - 2017-09-11 15:14:41 --> Model Class Initialized
INFO - 2017-09-11 18:44:41 --> Helper loaded: download_helper
INFO - 2017-09-11 18:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:44:41 --> Final output sent to browser
DEBUG - 2017-09-11 18:44:41 --> Total execution time: 0.0496
INFO - 2017-09-11 15:14:53 --> Config Class Initialized
INFO - 2017-09-11 15:14:53 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:14:53 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:14:53 --> Utf8 Class Initialized
INFO - 2017-09-11 15:14:53 --> URI Class Initialized
INFO - 2017-09-11 15:14:53 --> Router Class Initialized
INFO - 2017-09-11 15:14:53 --> Output Class Initialized
INFO - 2017-09-11 15:14:53 --> Security Class Initialized
DEBUG - 2017-09-11 15:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:14:53 --> Input Class Initialized
INFO - 2017-09-11 15:14:53 --> Language Class Initialized
INFO - 2017-09-11 15:14:53 --> Loader Class Initialized
INFO - 2017-09-11 15:14:53 --> Helper loaded: common_helper
INFO - 2017-09-11 15:14:53 --> Database Driver Class Initialized
INFO - 2017-09-11 15:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:14:53 --> Email Class Initialized
INFO - 2017-09-11 15:14:53 --> Controller Class Initialized
INFO - 2017-09-11 15:14:53 --> Helper loaded: form_helper
INFO - 2017-09-11 15:14:53 --> Form Validation Class Initialized
INFO - 2017-09-11 15:14:53 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:14:53 --> Helper loaded: url_helper
INFO - 2017-09-11 15:14:53 --> Model Class Initialized
INFO - 2017-09-11 15:14:53 --> Model Class Initialized
INFO - 2017-09-11 15:14:53 --> Model Class Initialized
INFO - 2017-09-11 18:44:53 --> Helper loaded: download_helper
INFO - 2017-09-11 18:44:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:44:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:44:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:44:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:44:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:44:53 --> Final output sent to browser
DEBUG - 2017-09-11 18:44:53 --> Total execution time: 0.0499
INFO - 2017-09-11 15:18:43 --> Config Class Initialized
INFO - 2017-09-11 15:18:43 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:18:43 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:18:43 --> Utf8 Class Initialized
INFO - 2017-09-11 15:18:43 --> URI Class Initialized
INFO - 2017-09-11 15:18:43 --> Router Class Initialized
INFO - 2017-09-11 15:18:43 --> Output Class Initialized
INFO - 2017-09-11 15:18:43 --> Security Class Initialized
DEBUG - 2017-09-11 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:18:43 --> Input Class Initialized
INFO - 2017-09-11 15:18:43 --> Language Class Initialized
INFO - 2017-09-11 15:18:43 --> Loader Class Initialized
INFO - 2017-09-11 15:18:43 --> Helper loaded: common_helper
INFO - 2017-09-11 15:18:43 --> Database Driver Class Initialized
INFO - 2017-09-11 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:18:43 --> Email Class Initialized
INFO - 2017-09-11 15:18:43 --> Controller Class Initialized
INFO - 2017-09-11 15:18:43 --> Helper loaded: form_helper
INFO - 2017-09-11 15:18:43 --> Form Validation Class Initialized
INFO - 2017-09-11 15:18:43 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:18:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:18:43 --> Helper loaded: url_helper
INFO - 2017-09-11 15:18:43 --> Model Class Initialized
INFO - 2017-09-11 15:18:43 --> Model Class Initialized
INFO - 2017-09-11 15:18:43 --> Model Class Initialized
INFO - 2017-09-11 18:48:43 --> Helper loaded: download_helper
INFO - 2017-09-11 18:48:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:48:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:48:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:48:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:48:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:48:43 --> Final output sent to browser
DEBUG - 2017-09-11 18:48:43 --> Total execution time: 0.0642
INFO - 2017-09-11 15:18:45 --> Config Class Initialized
INFO - 2017-09-11 15:18:45 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:18:45 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:18:45 --> Utf8 Class Initialized
INFO - 2017-09-11 15:18:45 --> URI Class Initialized
INFO - 2017-09-11 15:18:45 --> Router Class Initialized
INFO - 2017-09-11 15:18:45 --> Output Class Initialized
INFO - 2017-09-11 15:18:45 --> Security Class Initialized
DEBUG - 2017-09-11 15:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:18:45 --> Input Class Initialized
INFO - 2017-09-11 15:18:45 --> Language Class Initialized
INFO - 2017-09-11 15:18:45 --> Loader Class Initialized
INFO - 2017-09-11 15:18:45 --> Helper loaded: common_helper
INFO - 2017-09-11 15:18:45 --> Database Driver Class Initialized
INFO - 2017-09-11 15:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:18:45 --> Email Class Initialized
INFO - 2017-09-11 15:18:45 --> Controller Class Initialized
INFO - 2017-09-11 15:18:45 --> Helper loaded: form_helper
INFO - 2017-09-11 15:18:45 --> Form Validation Class Initialized
INFO - 2017-09-11 15:18:45 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:18:45 --> Helper loaded: url_helper
INFO - 2017-09-11 15:18:45 --> Model Class Initialized
INFO - 2017-09-11 15:18:45 --> Model Class Initialized
INFO - 2017-09-11 15:18:45 --> Model Class Initialized
INFO - 2017-09-11 18:48:45 --> Helper loaded: download_helper
INFO - 2017-09-11 18:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-09-11 18:48:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:48:45 --> Final output sent to browser
DEBUG - 2017-09-11 18:48:45 --> Total execution time: 0.0597
INFO - 2017-09-11 15:26:05 --> Config Class Initialized
INFO - 2017-09-11 15:26:05 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:26:05 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:26:05 --> Utf8 Class Initialized
INFO - 2017-09-11 15:26:05 --> URI Class Initialized
INFO - 2017-09-11 15:26:05 --> Router Class Initialized
INFO - 2017-09-11 15:26:05 --> Output Class Initialized
INFO - 2017-09-11 15:26:05 --> Security Class Initialized
DEBUG - 2017-09-11 15:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:26:05 --> Input Class Initialized
INFO - 2017-09-11 15:26:05 --> Language Class Initialized
INFO - 2017-09-11 15:26:05 --> Loader Class Initialized
INFO - 2017-09-11 15:26:05 --> Helper loaded: common_helper
INFO - 2017-09-11 15:26:05 --> Database Driver Class Initialized
INFO - 2017-09-11 15:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:26:05 --> Email Class Initialized
INFO - 2017-09-11 15:26:05 --> Controller Class Initialized
INFO - 2017-09-11 15:26:05 --> Helper loaded: form_helper
INFO - 2017-09-11 15:26:05 --> Form Validation Class Initialized
INFO - 2017-09-11 15:26:05 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:26:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:26:05 --> Helper loaded: url_helper
INFO - 2017-09-11 15:26:05 --> Model Class Initialized
INFO - 2017-09-11 15:26:05 --> Model Class Initialized
INFO - 2017-09-11 18:56:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:56:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:56:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:56:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:56:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:56:05 --> Final output sent to browser
DEBUG - 2017-09-11 18:56:05 --> Total execution time: 0.0709
INFO - 2017-09-11 15:26:14 --> Config Class Initialized
INFO - 2017-09-11 15:26:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:26:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:26:14 --> Utf8 Class Initialized
INFO - 2017-09-11 15:26:14 --> URI Class Initialized
INFO - 2017-09-11 15:26:14 --> Router Class Initialized
INFO - 2017-09-11 15:26:14 --> Output Class Initialized
INFO - 2017-09-11 15:26:14 --> Security Class Initialized
DEBUG - 2017-09-11 15:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:26:14 --> Input Class Initialized
INFO - 2017-09-11 15:26:14 --> Language Class Initialized
INFO - 2017-09-11 15:26:14 --> Loader Class Initialized
INFO - 2017-09-11 15:26:14 --> Helper loaded: common_helper
INFO - 2017-09-11 15:26:14 --> Database Driver Class Initialized
INFO - 2017-09-11 15:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:26:14 --> Email Class Initialized
INFO - 2017-09-11 15:26:14 --> Controller Class Initialized
INFO - 2017-09-11 15:26:14 --> Helper loaded: form_helper
INFO - 2017-09-11 15:26:14 --> Form Validation Class Initialized
INFO - 2017-09-11 15:26:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:26:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:26:14 --> Helper loaded: url_helper
INFO - 2017-09-11 15:26:14 --> Model Class Initialized
INFO - 2017-09-11 15:26:14 --> Model Class Initialized
INFO - 2017-09-11 18:56:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:56:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:56:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:56:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:56:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:56:14 --> Final output sent to browser
DEBUG - 2017-09-11 18:56:14 --> Total execution time: 0.0696
INFO - 2017-09-11 15:26:24 --> Config Class Initialized
INFO - 2017-09-11 15:26:24 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:26:24 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:26:24 --> Utf8 Class Initialized
INFO - 2017-09-11 15:26:24 --> URI Class Initialized
INFO - 2017-09-11 15:26:24 --> Router Class Initialized
INFO - 2017-09-11 15:26:24 --> Output Class Initialized
INFO - 2017-09-11 15:26:24 --> Security Class Initialized
DEBUG - 2017-09-11 15:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:26:24 --> Input Class Initialized
INFO - 2017-09-11 15:26:24 --> Language Class Initialized
INFO - 2017-09-11 15:26:24 --> Loader Class Initialized
INFO - 2017-09-11 15:26:24 --> Helper loaded: common_helper
INFO - 2017-09-11 15:26:24 --> Database Driver Class Initialized
INFO - 2017-09-11 15:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:26:24 --> Email Class Initialized
INFO - 2017-09-11 15:26:24 --> Controller Class Initialized
INFO - 2017-09-11 15:26:24 --> Helper loaded: form_helper
INFO - 2017-09-11 15:26:24 --> Form Validation Class Initialized
INFO - 2017-09-11 15:26:24 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:26:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:26:24 --> Helper loaded: url_helper
INFO - 2017-09-11 15:26:24 --> Model Class Initialized
INFO - 2017-09-11 15:26:24 --> Model Class Initialized
INFO - 2017-09-11 18:56:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:56:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:56:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:56:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:56:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:56:24 --> Final output sent to browser
DEBUG - 2017-09-11 18:56:24 --> Total execution time: 0.0591
INFO - 2017-09-11 15:26:27 --> Config Class Initialized
INFO - 2017-09-11 15:26:27 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:26:27 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:26:27 --> Utf8 Class Initialized
INFO - 2017-09-11 15:26:27 --> URI Class Initialized
INFO - 2017-09-11 15:26:27 --> Router Class Initialized
INFO - 2017-09-11 15:26:27 --> Output Class Initialized
INFO - 2017-09-11 15:26:27 --> Security Class Initialized
DEBUG - 2017-09-11 15:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:26:27 --> Input Class Initialized
INFO - 2017-09-11 15:26:27 --> Language Class Initialized
INFO - 2017-09-11 15:26:27 --> Loader Class Initialized
INFO - 2017-09-11 15:26:27 --> Helper loaded: common_helper
INFO - 2017-09-11 15:26:27 --> Database Driver Class Initialized
INFO - 2017-09-11 15:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:26:27 --> Email Class Initialized
INFO - 2017-09-11 15:26:27 --> Controller Class Initialized
INFO - 2017-09-11 15:26:27 --> Helper loaded: form_helper
INFO - 2017-09-11 15:26:27 --> Form Validation Class Initialized
INFO - 2017-09-11 15:26:27 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:26:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:26:27 --> Helper loaded: url_helper
INFO - 2017-09-11 15:26:27 --> Model Class Initialized
INFO - 2017-09-11 15:26:27 --> Model Class Initialized
INFO - 2017-09-11 18:56:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:56:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:56:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:56:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:56:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:56:27 --> Final output sent to browser
DEBUG - 2017-09-11 18:56:27 --> Total execution time: 0.0705
INFO - 2017-09-11 15:27:06 --> Config Class Initialized
INFO - 2017-09-11 15:27:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:27:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:27:06 --> Utf8 Class Initialized
INFO - 2017-09-11 15:27:06 --> URI Class Initialized
INFO - 2017-09-11 15:27:06 --> Router Class Initialized
INFO - 2017-09-11 15:27:06 --> Output Class Initialized
INFO - 2017-09-11 15:27:06 --> Security Class Initialized
DEBUG - 2017-09-11 15:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:27:06 --> Input Class Initialized
INFO - 2017-09-11 15:27:06 --> Language Class Initialized
INFO - 2017-09-11 15:27:06 --> Loader Class Initialized
INFO - 2017-09-11 15:27:06 --> Helper loaded: common_helper
INFO - 2017-09-11 15:27:06 --> Database Driver Class Initialized
INFO - 2017-09-11 15:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:27:06 --> Email Class Initialized
INFO - 2017-09-11 15:27:06 --> Controller Class Initialized
INFO - 2017-09-11 15:27:06 --> Helper loaded: form_helper
INFO - 2017-09-11 15:27:06 --> Form Validation Class Initialized
INFO - 2017-09-11 15:27:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:27:06 --> Helper loaded: url_helper
INFO - 2017-09-11 15:27:06 --> Model Class Initialized
INFO - 2017-09-11 15:27:06 --> Model Class Initialized
INFO - 2017-09-11 18:57:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:57:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:57:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:57:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:57:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:57:06 --> Final output sent to browser
DEBUG - 2017-09-11 18:57:06 --> Total execution time: 0.0631
INFO - 2017-09-11 15:27:23 --> Config Class Initialized
INFO - 2017-09-11 15:27:23 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:27:23 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:27:23 --> Utf8 Class Initialized
INFO - 2017-09-11 15:27:23 --> URI Class Initialized
INFO - 2017-09-11 15:27:23 --> Router Class Initialized
INFO - 2017-09-11 15:27:23 --> Output Class Initialized
INFO - 2017-09-11 15:27:23 --> Security Class Initialized
DEBUG - 2017-09-11 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:27:23 --> Input Class Initialized
INFO - 2017-09-11 15:27:23 --> Language Class Initialized
INFO - 2017-09-11 15:27:23 --> Loader Class Initialized
INFO - 2017-09-11 15:27:23 --> Helper loaded: common_helper
INFO - 2017-09-11 15:27:23 --> Database Driver Class Initialized
INFO - 2017-09-11 15:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:27:23 --> Email Class Initialized
INFO - 2017-09-11 15:27:23 --> Controller Class Initialized
INFO - 2017-09-11 15:27:23 --> Helper loaded: form_helper
INFO - 2017-09-11 15:27:23 --> Form Validation Class Initialized
INFO - 2017-09-11 15:27:23 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:27:23 --> Helper loaded: url_helper
INFO - 2017-09-11 15:27:23 --> Model Class Initialized
INFO - 2017-09-11 15:27:23 --> Model Class Initialized
INFO - 2017-09-11 18:57:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:57:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:57:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:57:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:57:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:57:23 --> Final output sent to browser
DEBUG - 2017-09-11 18:57:23 --> Total execution time: 0.0647
INFO - 2017-09-11 15:27:25 --> Config Class Initialized
INFO - 2017-09-11 15:27:25 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:27:25 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:27:25 --> Utf8 Class Initialized
INFO - 2017-09-11 15:27:25 --> URI Class Initialized
INFO - 2017-09-11 15:27:25 --> Router Class Initialized
INFO - 2017-09-11 15:27:25 --> Output Class Initialized
INFO - 2017-09-11 15:27:25 --> Security Class Initialized
DEBUG - 2017-09-11 15:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:27:25 --> Input Class Initialized
INFO - 2017-09-11 15:27:25 --> Language Class Initialized
INFO - 2017-09-11 15:27:25 --> Loader Class Initialized
INFO - 2017-09-11 15:27:25 --> Helper loaded: common_helper
INFO - 2017-09-11 15:27:25 --> Database Driver Class Initialized
INFO - 2017-09-11 15:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:27:25 --> Email Class Initialized
INFO - 2017-09-11 15:27:25 --> Controller Class Initialized
INFO - 2017-09-11 15:27:25 --> Helper loaded: form_helper
INFO - 2017-09-11 15:27:25 --> Form Validation Class Initialized
INFO - 2017-09-11 15:27:25 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:27:25 --> Helper loaded: url_helper
INFO - 2017-09-11 15:27:25 --> Model Class Initialized
INFO - 2017-09-11 15:27:25 --> Model Class Initialized
INFO - 2017-09-11 18:57:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:57:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:57:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:57:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:57:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:57:25 --> Final output sent to browser
DEBUG - 2017-09-11 18:57:25 --> Total execution time: 0.0858
INFO - 2017-09-11 15:27:36 --> Config Class Initialized
INFO - 2017-09-11 15:27:36 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:27:36 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:27:36 --> Utf8 Class Initialized
INFO - 2017-09-11 15:27:36 --> URI Class Initialized
INFO - 2017-09-11 15:27:36 --> Router Class Initialized
INFO - 2017-09-11 15:27:36 --> Output Class Initialized
INFO - 2017-09-11 15:27:36 --> Security Class Initialized
DEBUG - 2017-09-11 15:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:27:36 --> Input Class Initialized
INFO - 2017-09-11 15:27:36 --> Language Class Initialized
INFO - 2017-09-11 15:27:36 --> Loader Class Initialized
INFO - 2017-09-11 15:27:36 --> Helper loaded: common_helper
INFO - 2017-09-11 15:27:36 --> Database Driver Class Initialized
INFO - 2017-09-11 15:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:27:36 --> Email Class Initialized
INFO - 2017-09-11 15:27:36 --> Controller Class Initialized
INFO - 2017-09-11 15:27:37 --> Helper loaded: form_helper
INFO - 2017-09-11 15:27:37 --> Form Validation Class Initialized
INFO - 2017-09-11 15:27:37 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:27:37 --> Helper loaded: url_helper
INFO - 2017-09-11 15:27:37 --> Model Class Initialized
INFO - 2017-09-11 15:27:37 --> Model Class Initialized
INFO - 2017-09-11 18:57:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:57:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:57:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:57:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:57:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:57:37 --> Final output sent to browser
DEBUG - 2017-09-11 18:57:37 --> Total execution time: 0.0636
INFO - 2017-09-11 15:27:51 --> Config Class Initialized
INFO - 2017-09-11 15:27:51 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:27:51 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:27:51 --> Utf8 Class Initialized
INFO - 2017-09-11 15:27:51 --> URI Class Initialized
INFO - 2017-09-11 15:27:51 --> Router Class Initialized
INFO - 2017-09-11 15:27:51 --> Output Class Initialized
INFO - 2017-09-11 15:27:51 --> Security Class Initialized
DEBUG - 2017-09-11 15:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:27:51 --> Input Class Initialized
INFO - 2017-09-11 15:27:51 --> Language Class Initialized
INFO - 2017-09-11 15:27:51 --> Loader Class Initialized
INFO - 2017-09-11 15:27:51 --> Helper loaded: common_helper
INFO - 2017-09-11 15:27:51 --> Database Driver Class Initialized
INFO - 2017-09-11 15:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:27:51 --> Email Class Initialized
INFO - 2017-09-11 15:27:51 --> Controller Class Initialized
INFO - 2017-09-11 15:27:51 --> Helper loaded: form_helper
INFO - 2017-09-11 15:27:51 --> Form Validation Class Initialized
INFO - 2017-09-11 15:27:51 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:27:51 --> Helper loaded: url_helper
INFO - 2017-09-11 15:27:51 --> Model Class Initialized
INFO - 2017-09-11 15:27:51 --> Model Class Initialized
INFO - 2017-09-11 18:57:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:57:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:57:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:57:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:57:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:57:51 --> Final output sent to browser
DEBUG - 2017-09-11 18:57:51 --> Total execution time: 0.0603
INFO - 2017-09-11 15:28:03 --> Config Class Initialized
INFO - 2017-09-11 15:28:03 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:28:03 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:28:03 --> Utf8 Class Initialized
INFO - 2017-09-11 15:28:03 --> URI Class Initialized
INFO - 2017-09-11 15:28:03 --> Router Class Initialized
INFO - 2017-09-11 15:28:03 --> Output Class Initialized
INFO - 2017-09-11 15:28:03 --> Security Class Initialized
DEBUG - 2017-09-11 15:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:28:03 --> Input Class Initialized
INFO - 2017-09-11 15:28:03 --> Language Class Initialized
INFO - 2017-09-11 15:28:03 --> Loader Class Initialized
INFO - 2017-09-11 15:28:03 --> Helper loaded: common_helper
INFO - 2017-09-11 15:28:03 --> Database Driver Class Initialized
INFO - 2017-09-11 15:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:28:03 --> Email Class Initialized
INFO - 2017-09-11 15:28:03 --> Controller Class Initialized
INFO - 2017-09-11 15:28:03 --> Helper loaded: form_helper
INFO - 2017-09-11 15:28:03 --> Form Validation Class Initialized
INFO - 2017-09-11 15:28:03 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:28:03 --> Helper loaded: url_helper
INFO - 2017-09-11 15:28:03 --> Model Class Initialized
INFO - 2017-09-11 15:28:03 --> Model Class Initialized
INFO - 2017-09-11 18:58:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:58:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:58:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:58:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:58:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:58:03 --> Final output sent to browser
DEBUG - 2017-09-11 18:58:03 --> Total execution time: 0.0648
INFO - 2017-09-11 15:28:11 --> Config Class Initialized
INFO - 2017-09-11 15:28:11 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:28:11 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:28:11 --> Utf8 Class Initialized
INFO - 2017-09-11 15:28:11 --> URI Class Initialized
INFO - 2017-09-11 15:28:11 --> Router Class Initialized
INFO - 2017-09-11 15:28:11 --> Output Class Initialized
INFO - 2017-09-11 15:28:11 --> Security Class Initialized
DEBUG - 2017-09-11 15:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:28:11 --> Input Class Initialized
INFO - 2017-09-11 15:28:11 --> Language Class Initialized
INFO - 2017-09-11 15:28:11 --> Loader Class Initialized
INFO - 2017-09-11 15:28:11 --> Helper loaded: common_helper
INFO - 2017-09-11 15:28:11 --> Database Driver Class Initialized
INFO - 2017-09-11 15:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:28:11 --> Email Class Initialized
INFO - 2017-09-11 15:28:11 --> Controller Class Initialized
INFO - 2017-09-11 15:28:11 --> Helper loaded: form_helper
INFO - 2017-09-11 15:28:11 --> Form Validation Class Initialized
INFO - 2017-09-11 15:28:11 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:28:11 --> Helper loaded: url_helper
INFO - 2017-09-11 15:28:11 --> Model Class Initialized
INFO - 2017-09-11 15:28:11 --> Model Class Initialized
INFO - 2017-09-11 18:58:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:58:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:58:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:58:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:58:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:58:11 --> Final output sent to browser
DEBUG - 2017-09-11 18:58:11 --> Total execution time: 0.0691
INFO - 2017-09-11 15:28:20 --> Config Class Initialized
INFO - 2017-09-11 15:28:20 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:28:20 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:28:20 --> Utf8 Class Initialized
INFO - 2017-09-11 15:28:20 --> URI Class Initialized
INFO - 2017-09-11 15:28:20 --> Router Class Initialized
INFO - 2017-09-11 15:28:20 --> Output Class Initialized
INFO - 2017-09-11 15:28:20 --> Security Class Initialized
DEBUG - 2017-09-11 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:28:20 --> Input Class Initialized
INFO - 2017-09-11 15:28:20 --> Language Class Initialized
INFO - 2017-09-11 15:28:20 --> Loader Class Initialized
INFO - 2017-09-11 15:28:20 --> Helper loaded: common_helper
INFO - 2017-09-11 15:28:20 --> Database Driver Class Initialized
INFO - 2017-09-11 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:28:20 --> Email Class Initialized
INFO - 2017-09-11 15:28:20 --> Controller Class Initialized
INFO - 2017-09-11 15:28:20 --> Helper loaded: form_helper
INFO - 2017-09-11 15:28:20 --> Form Validation Class Initialized
INFO - 2017-09-11 15:28:20 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:28:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:28:20 --> Helper loaded: url_helper
INFO - 2017-09-11 15:28:20 --> Model Class Initialized
INFO - 2017-09-11 15:28:20 --> Model Class Initialized
INFO - 2017-09-11 18:58:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:58:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:58:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:58:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:58:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:58:20 --> Final output sent to browser
DEBUG - 2017-09-11 18:58:20 --> Total execution time: 0.0611
INFO - 2017-09-11 15:28:42 --> Config Class Initialized
INFO - 2017-09-11 15:28:42 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:28:42 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:28:42 --> Utf8 Class Initialized
INFO - 2017-09-11 15:28:42 --> URI Class Initialized
INFO - 2017-09-11 15:28:42 --> Router Class Initialized
INFO - 2017-09-11 15:28:42 --> Output Class Initialized
INFO - 2017-09-11 15:28:42 --> Security Class Initialized
DEBUG - 2017-09-11 15:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:28:42 --> Input Class Initialized
INFO - 2017-09-11 15:28:42 --> Language Class Initialized
INFO - 2017-09-11 15:28:42 --> Loader Class Initialized
INFO - 2017-09-11 15:28:42 --> Helper loaded: common_helper
INFO - 2017-09-11 15:28:42 --> Database Driver Class Initialized
INFO - 2017-09-11 15:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:28:42 --> Email Class Initialized
INFO - 2017-09-11 15:28:42 --> Controller Class Initialized
INFO - 2017-09-11 15:28:42 --> Helper loaded: form_helper
INFO - 2017-09-11 15:28:42 --> Form Validation Class Initialized
INFO - 2017-09-11 15:28:42 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:28:42 --> Helper loaded: url_helper
INFO - 2017-09-11 15:28:42 --> Model Class Initialized
INFO - 2017-09-11 15:28:42 --> Model Class Initialized
INFO - 2017-09-11 18:58:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:58:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:58:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:58:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:58:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:58:42 --> Final output sent to browser
DEBUG - 2017-09-11 18:58:42 --> Total execution time: 0.0603
INFO - 2017-09-11 15:28:43 --> Config Class Initialized
INFO - 2017-09-11 15:28:43 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:28:43 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:28:43 --> Utf8 Class Initialized
INFO - 2017-09-11 15:28:43 --> URI Class Initialized
INFO - 2017-09-11 15:28:43 --> Router Class Initialized
INFO - 2017-09-11 15:28:43 --> Output Class Initialized
INFO - 2017-09-11 15:28:43 --> Security Class Initialized
DEBUG - 2017-09-11 15:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:28:43 --> Input Class Initialized
INFO - 2017-09-11 15:28:43 --> Language Class Initialized
INFO - 2017-09-11 15:28:43 --> Loader Class Initialized
INFO - 2017-09-11 15:28:43 --> Helper loaded: common_helper
INFO - 2017-09-11 15:28:43 --> Database Driver Class Initialized
INFO - 2017-09-11 15:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:28:43 --> Email Class Initialized
INFO - 2017-09-11 15:28:43 --> Controller Class Initialized
INFO - 2017-09-11 15:28:43 --> Helper loaded: form_helper
INFO - 2017-09-11 15:28:43 --> Form Validation Class Initialized
INFO - 2017-09-11 15:28:43 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:28:43 --> Helper loaded: url_helper
INFO - 2017-09-11 15:28:43 --> Model Class Initialized
INFO - 2017-09-11 15:28:43 --> Model Class Initialized
INFO - 2017-09-11 18:58:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:58:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:58:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:58:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:58:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:58:43 --> Final output sent to browser
DEBUG - 2017-09-11 18:58:43 --> Total execution time: 0.0568
INFO - 2017-09-11 15:28:59 --> Config Class Initialized
INFO - 2017-09-11 15:28:59 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:28:59 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:28:59 --> Utf8 Class Initialized
INFO - 2017-09-11 15:28:59 --> URI Class Initialized
INFO - 2017-09-11 15:28:59 --> Router Class Initialized
INFO - 2017-09-11 15:28:59 --> Output Class Initialized
INFO - 2017-09-11 15:28:59 --> Security Class Initialized
DEBUG - 2017-09-11 15:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:28:59 --> Input Class Initialized
INFO - 2017-09-11 15:28:59 --> Language Class Initialized
INFO - 2017-09-11 15:28:59 --> Loader Class Initialized
INFO - 2017-09-11 15:28:59 --> Helper loaded: common_helper
INFO - 2017-09-11 15:28:59 --> Database Driver Class Initialized
INFO - 2017-09-11 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:28:59 --> Email Class Initialized
INFO - 2017-09-11 15:28:59 --> Controller Class Initialized
INFO - 2017-09-11 15:28:59 --> Helper loaded: form_helper
INFO - 2017-09-11 15:28:59 --> Form Validation Class Initialized
INFO - 2017-09-11 15:28:59 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:28:59 --> Helper loaded: url_helper
INFO - 2017-09-11 15:28:59 --> Model Class Initialized
INFO - 2017-09-11 15:28:59 --> Model Class Initialized
INFO - 2017-09-11 18:58:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:58:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:58:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:58:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:58:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:58:59 --> Final output sent to browser
DEBUG - 2017-09-11 18:58:59 --> Total execution time: 0.0581
INFO - 2017-09-11 15:29:06 --> Config Class Initialized
INFO - 2017-09-11 15:29:06 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:06 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:06 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:06 --> URI Class Initialized
INFO - 2017-09-11 15:29:06 --> Router Class Initialized
INFO - 2017-09-11 15:29:06 --> Output Class Initialized
INFO - 2017-09-11 15:29:06 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:06 --> Input Class Initialized
INFO - 2017-09-11 15:29:06 --> Language Class Initialized
INFO - 2017-09-11 15:29:06 --> Loader Class Initialized
INFO - 2017-09-11 15:29:06 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:06 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:06 --> Email Class Initialized
INFO - 2017-09-11 15:29:06 --> Controller Class Initialized
INFO - 2017-09-11 15:29:06 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:06 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:06 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:06 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:06 --> Model Class Initialized
INFO - 2017-09-11 15:29:06 --> Model Class Initialized
INFO - 2017-09-11 18:59:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:59:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:59:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:59:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:59:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:59:06 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:06 --> Total execution time: 0.0634
INFO - 2017-09-11 15:29:14 --> Config Class Initialized
INFO - 2017-09-11 15:29:14 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:14 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:14 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:14 --> URI Class Initialized
INFO - 2017-09-11 15:29:14 --> Router Class Initialized
INFO - 2017-09-11 15:29:14 --> Output Class Initialized
INFO - 2017-09-11 15:29:14 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:14 --> Input Class Initialized
INFO - 2017-09-11 15:29:14 --> Language Class Initialized
INFO - 2017-09-11 15:29:14 --> Loader Class Initialized
INFO - 2017-09-11 15:29:14 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:14 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:14 --> Email Class Initialized
INFO - 2017-09-11 15:29:14 --> Controller Class Initialized
INFO - 2017-09-11 15:29:14 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:14 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:14 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:14 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:14 --> Model Class Initialized
INFO - 2017-09-11 15:29:14 --> Model Class Initialized
INFO - 2017-09-11 18:59:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:59:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:59:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:59:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:59:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:59:14 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:14 --> Total execution time: 0.0656
INFO - 2017-09-11 15:29:24 --> Config Class Initialized
INFO - 2017-09-11 15:29:24 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:24 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:24 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:24 --> URI Class Initialized
INFO - 2017-09-11 15:29:24 --> Router Class Initialized
INFO - 2017-09-11 15:29:24 --> Output Class Initialized
INFO - 2017-09-11 15:29:24 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:24 --> Input Class Initialized
INFO - 2017-09-11 15:29:24 --> Language Class Initialized
INFO - 2017-09-11 15:29:24 --> Loader Class Initialized
INFO - 2017-09-11 15:29:24 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:24 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:24 --> Email Class Initialized
INFO - 2017-09-11 15:29:24 --> Controller Class Initialized
INFO - 2017-09-11 15:29:24 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:24 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:24 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:24 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:24 --> Model Class Initialized
INFO - 2017-09-11 15:29:24 --> Model Class Initialized
INFO - 2017-09-11 18:59:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:59:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:59:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:59:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:59:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:59:24 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:24 --> Total execution time: 0.0657
INFO - 2017-09-11 15:29:33 --> Config Class Initialized
INFO - 2017-09-11 15:29:33 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:33 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:33 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:33 --> URI Class Initialized
INFO - 2017-09-11 15:29:33 --> Router Class Initialized
INFO - 2017-09-11 15:29:33 --> Output Class Initialized
INFO - 2017-09-11 15:29:33 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:33 --> Input Class Initialized
INFO - 2017-09-11 15:29:33 --> Language Class Initialized
INFO - 2017-09-11 15:29:33 --> Loader Class Initialized
INFO - 2017-09-11 15:29:33 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:33 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:33 --> Email Class Initialized
INFO - 2017-09-11 15:29:33 --> Controller Class Initialized
INFO - 2017-09-11 15:29:33 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:33 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:33 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:33 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:33 --> Model Class Initialized
INFO - 2017-09-11 15:29:33 --> Model Class Initialized
INFO - 2017-09-11 18:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-11 18:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-11 18:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-11 18:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-11 18:59:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-11 18:59:33 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:33 --> Total execution time: 0.0595
INFO - 2017-09-11 15:29:36 --> Config Class Initialized
INFO - 2017-09-11 15:29:36 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:36 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:36 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:36 --> URI Class Initialized
INFO - 2017-09-11 15:29:36 --> Router Class Initialized
INFO - 2017-09-11 15:29:36 --> Output Class Initialized
INFO - 2017-09-11 15:29:36 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:36 --> Input Class Initialized
INFO - 2017-09-11 15:29:36 --> Language Class Initialized
INFO - 2017-09-11 15:29:36 --> Loader Class Initialized
INFO - 2017-09-11 15:29:36 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:36 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:36 --> Email Class Initialized
INFO - 2017-09-11 15:29:36 --> Controller Class Initialized
INFO - 2017-09-11 15:29:36 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:36 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:36 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:36 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:36 --> Model Class Initialized
INFO - 2017-09-11 15:29:36 --> Model Class Initialized
INFO - 2017-09-11 18:59:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-09-11 18:59:36 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:36 --> Total execution time: 0.0540
INFO - 2017-09-11 15:29:39 --> Config Class Initialized
INFO - 2017-09-11 15:29:39 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:39 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:39 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:39 --> URI Class Initialized
INFO - 2017-09-11 15:29:39 --> Router Class Initialized
INFO - 2017-09-11 15:29:39 --> Output Class Initialized
INFO - 2017-09-11 15:29:39 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:39 --> Input Class Initialized
INFO - 2017-09-11 15:29:39 --> Language Class Initialized
INFO - 2017-09-11 15:29:39 --> Loader Class Initialized
INFO - 2017-09-11 15:29:39 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:39 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:39 --> Email Class Initialized
INFO - 2017-09-11 15:29:39 --> Controller Class Initialized
INFO - 2017-09-11 15:29:39 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:39 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:39 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:39 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:39 --> Model Class Initialized
INFO - 2017-09-11 15:29:39 --> Model Class Initialized
INFO - 2017-09-11 18:59:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-09-11 18:59:39 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:39 --> Total execution time: 0.0466
INFO - 2017-09-11 15:29:40 --> Config Class Initialized
INFO - 2017-09-11 15:29:40 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:40 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:40 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:40 --> URI Class Initialized
INFO - 2017-09-11 15:29:40 --> Router Class Initialized
INFO - 2017-09-11 15:29:40 --> Output Class Initialized
INFO - 2017-09-11 15:29:40 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:40 --> Input Class Initialized
INFO - 2017-09-11 15:29:40 --> Language Class Initialized
INFO - 2017-09-11 15:29:40 --> Loader Class Initialized
INFO - 2017-09-11 15:29:40 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:40 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:40 --> Email Class Initialized
INFO - 2017-09-11 15:29:40 --> Controller Class Initialized
INFO - 2017-09-11 15:29:40 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:40 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:40 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:40 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:40 --> Model Class Initialized
INFO - 2017-09-11 15:29:40 --> Model Class Initialized
INFO - 2017-09-11 18:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-09-11 18:59:40 --> Final output sent to browser
DEBUG - 2017-09-11 18:59:40 --> Total execution time: 0.0450
INFO - 2017-09-11 15:29:41 --> Config Class Initialized
INFO - 2017-09-11 15:29:41 --> Hooks Class Initialized
DEBUG - 2017-09-11 15:29:41 --> UTF-8 Support Enabled
INFO - 2017-09-11 15:29:41 --> Utf8 Class Initialized
INFO - 2017-09-11 15:29:41 --> URI Class Initialized
INFO - 2017-09-11 15:29:41 --> Router Class Initialized
INFO - 2017-09-11 15:29:41 --> Output Class Initialized
INFO - 2017-09-11 15:29:41 --> Security Class Initialized
DEBUG - 2017-09-11 15:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-11 15:29:41 --> Input Class Initialized
INFO - 2017-09-11 15:29:41 --> Language Class Initialized
INFO - 2017-09-11 15:29:41 --> Loader Class Initialized
INFO - 2017-09-11 15:29:41 --> Helper loaded: common_helper
INFO - 2017-09-11 15:29:41 --> Database Driver Class Initialized
INFO - 2017-09-11 15:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-11 15:29:41 --> Email Class Initialized
INFO - 2017-09-11 15:29:41 --> Controller Class Initialized
INFO - 2017-09-11 15:29:41 --> Helper loaded: form_helper
INFO - 2017-09-11 15:29:41 --> Form Validation Class Initialized
INFO - 2017-09-11 15:29:41 --> Helper loaded: email_helper
DEBUG - 2017-09-11 15:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-11 15:29:41 --> Helper loaded: url_helper
INFO - 2017-09-11 15:29:41 --> Model Class Initialized
INFO - 2017-09-11 15:29:41 --> Model Class Initialized
