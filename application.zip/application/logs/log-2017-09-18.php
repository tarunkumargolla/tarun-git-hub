<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-09-18 08:35:02 --> Config Class Initialized
INFO - 2017-09-18 08:35:02 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:02 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:02 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:02 --> URI Class Initialized
DEBUG - 2017-09-18 08:35:02 --> No URI present. Default controller set.
INFO - 2017-09-18 08:35:02 --> Router Class Initialized
INFO - 2017-09-18 08:35:02 --> Output Class Initialized
INFO - 2017-09-18 08:35:02 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:02 --> Input Class Initialized
INFO - 2017-09-18 08:35:02 --> Language Class Initialized
INFO - 2017-09-18 08:35:02 --> Loader Class Initialized
INFO - 2017-09-18 08:35:02 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:02 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:03 --> Email Class Initialized
INFO - 2017-09-18 08:35:03 --> Controller Class Initialized
INFO - 2017-09-18 08:35:03 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:03 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:03 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:03 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:03 --> Model Class Initialized
INFO - 2017-09-18 08:35:03 --> Model Class Initialized
INFO - 2017-09-18 08:35:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-09-18 08:35:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 08:35:03 --> Final output sent to browser
DEBUG - 2017-09-18 08:35:03 --> Total execution time: 1.1973
INFO - 2017-09-18 08:35:04 --> Config Class Initialized
INFO - 2017-09-18 08:35:04 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:04 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:04 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:04 --> URI Class Initialized
DEBUG - 2017-09-18 08:35:04 --> No URI present. Default controller set.
INFO - 2017-09-18 08:35:04 --> Router Class Initialized
INFO - 2017-09-18 08:35:04 --> Output Class Initialized
INFO - 2017-09-18 08:35:04 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:04 --> Input Class Initialized
INFO - 2017-09-18 08:35:04 --> Language Class Initialized
INFO - 2017-09-18 08:35:04 --> Loader Class Initialized
INFO - 2017-09-18 08:35:04 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:04 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:04 --> Email Class Initialized
INFO - 2017-09-18 08:35:04 --> Controller Class Initialized
INFO - 2017-09-18 08:35:04 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:04 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:04 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:04 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:04 --> Model Class Initialized
INFO - 2017-09-18 08:35:04 --> Model Class Initialized
DEBUG - 2017-09-18 08:35:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 08:35:04 --> Config Class Initialized
INFO - 2017-09-18 08:35:04 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:04 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:04 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:04 --> URI Class Initialized
INFO - 2017-09-18 08:35:04 --> Router Class Initialized
INFO - 2017-09-18 08:35:04 --> Output Class Initialized
INFO - 2017-09-18 08:35:04 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:04 --> Input Class Initialized
INFO - 2017-09-18 08:35:04 --> Language Class Initialized
INFO - 2017-09-18 08:35:04 --> Loader Class Initialized
INFO - 2017-09-18 08:35:04 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:04 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:04 --> Email Class Initialized
INFO - 2017-09-18 08:35:04 --> Controller Class Initialized
INFO - 2017-09-18 08:35:04 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:04 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:04 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:04 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:04 --> Model Class Initialized
INFO - 2017-09-18 08:35:04 --> Model Class Initialized
INFO - 2017-09-18 08:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 08:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 08:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-09-18 08:35:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 08:35:04 --> Final output sent to browser
DEBUG - 2017-09-18 08:35:04 --> Total execution time: 0.1096
INFO - 2017-09-18 08:35:06 --> Config Class Initialized
INFO - 2017-09-18 08:35:06 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:06 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:06 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:06 --> URI Class Initialized
INFO - 2017-09-18 08:35:06 --> Router Class Initialized
INFO - 2017-09-18 08:35:06 --> Output Class Initialized
INFO - 2017-09-18 08:35:06 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:06 --> Input Class Initialized
INFO - 2017-09-18 08:35:06 --> Language Class Initialized
INFO - 2017-09-18 08:35:06 --> Loader Class Initialized
INFO - 2017-09-18 08:35:06 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:06 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:06 --> Email Class Initialized
INFO - 2017-09-18 08:35:06 --> Controller Class Initialized
INFO - 2017-09-18 08:35:06 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:06 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:06 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:06 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:06 --> Model Class Initialized
INFO - 2017-09-18 08:35:06 --> Model Class Initialized
INFO - 2017-09-18 08:35:06 --> Model Class Initialized
INFO - 2017-09-18 12:05:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:05:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:05:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 12:05:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 12:05:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-09-18 12:05:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-09-18 12:05:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:05:06 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:06 --> Total execution time: 0.3890
INFO - 2017-09-18 08:35:08 --> Config Class Initialized
INFO - 2017-09-18 08:35:08 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:08 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:08 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:08 --> URI Class Initialized
INFO - 2017-09-18 08:35:08 --> Router Class Initialized
INFO - 2017-09-18 08:35:08 --> Output Class Initialized
INFO - 2017-09-18 08:35:08 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:08 --> Input Class Initialized
INFO - 2017-09-18 08:35:08 --> Language Class Initialized
INFO - 2017-09-18 08:35:08 --> Loader Class Initialized
INFO - 2017-09-18 08:35:08 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:08 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:08 --> Email Class Initialized
INFO - 2017-09-18 08:35:08 --> Controller Class Initialized
INFO - 2017-09-18 08:35:08 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:08 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:08 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:08 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:08 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:08 --> Model Class Initialized
INFO - 2017-09-18 08:35:08 --> Model Class Initialized
INFO - 2017-09-18 12:05:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:05:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:05:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 12:05:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-18 12:05:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:05:08 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:08 --> Total execution time: 0.1003
INFO - 2017-09-18 08:35:10 --> Config Class Initialized
INFO - 2017-09-18 08:35:10 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:10 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:10 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:10 --> URI Class Initialized
INFO - 2017-09-18 08:35:10 --> Router Class Initialized
INFO - 2017-09-18 08:35:10 --> Output Class Initialized
INFO - 2017-09-18 08:35:10 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:10 --> Input Class Initialized
INFO - 2017-09-18 08:35:10 --> Language Class Initialized
INFO - 2017-09-18 08:35:10 --> Loader Class Initialized
INFO - 2017-09-18 08:35:10 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:10 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:10 --> Email Class Initialized
INFO - 2017-09-18 08:35:10 --> Controller Class Initialized
INFO - 2017-09-18 08:35:10 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:10 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:10 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:10 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:10 --> Model Class Initialized
INFO - 2017-09-18 08:35:10 --> Model Class Initialized
INFO - 2017-09-18 12:05:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-09-18 12:05:10 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:10 --> Total execution time: 0.0736
INFO - 2017-09-18 08:35:14 --> Config Class Initialized
INFO - 2017-09-18 08:35:14 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:14 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:14 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:14 --> URI Class Initialized
INFO - 2017-09-18 08:35:14 --> Router Class Initialized
INFO - 2017-09-18 08:35:14 --> Output Class Initialized
INFO - 2017-09-18 08:35:14 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:14 --> Input Class Initialized
INFO - 2017-09-18 08:35:14 --> Language Class Initialized
INFO - 2017-09-18 08:35:14 --> Loader Class Initialized
INFO - 2017-09-18 08:35:14 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:14 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:14 --> Email Class Initialized
INFO - 2017-09-18 08:35:14 --> Controller Class Initialized
INFO - 2017-09-18 08:35:14 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:14 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:14 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:14 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:14 --> Model Class Initialized
INFO - 2017-09-18 08:35:14 --> Model Class Initialized
INFO - 2017-09-18 12:05:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:05:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:05:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-09-18 12:05:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 12:05:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:05:14 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:14 --> Total execution time: 0.0715
INFO - 2017-09-18 08:35:15 --> Config Class Initialized
INFO - 2017-09-18 08:35:15 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:15 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:15 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:15 --> URI Class Initialized
INFO - 2017-09-18 08:35:15 --> Router Class Initialized
INFO - 2017-09-18 08:35:15 --> Output Class Initialized
INFO - 2017-09-18 08:35:15 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:15 --> Input Class Initialized
INFO - 2017-09-18 08:35:15 --> Language Class Initialized
INFO - 2017-09-18 08:35:15 --> Loader Class Initialized
INFO - 2017-09-18 08:35:15 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:15 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:15 --> Email Class Initialized
INFO - 2017-09-18 08:35:15 --> Controller Class Initialized
INFO - 2017-09-18 08:35:15 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:15 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:15 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:15 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:15 --> Model Class Initialized
INFO - 2017-09-18 08:35:15 --> Model Class Initialized
INFO - 2017-09-18 12:05:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:05:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:05:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 12:05:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-18 12:05:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:05:15 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:15 --> Total execution time: 0.0521
INFO - 2017-09-18 08:35:18 --> Config Class Initialized
INFO - 2017-09-18 08:35:18 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:18 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:18 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:18 --> URI Class Initialized
INFO - 2017-09-18 08:35:18 --> Router Class Initialized
INFO - 2017-09-18 08:35:18 --> Output Class Initialized
INFO - 2017-09-18 08:35:18 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:18 --> Input Class Initialized
INFO - 2017-09-18 08:35:18 --> Language Class Initialized
INFO - 2017-09-18 08:35:18 --> Loader Class Initialized
INFO - 2017-09-18 08:35:18 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:18 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:18 --> Email Class Initialized
INFO - 2017-09-18 08:35:18 --> Controller Class Initialized
INFO - 2017-09-18 08:35:18 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:18 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:18 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:18 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:18 --> Model Class Initialized
INFO - 2017-09-18 08:35:18 --> Model Class Initialized
INFO - 2017-09-18 12:05:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-09-18 12:05:18 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:18 --> Total execution time: 0.0480
INFO - 2017-09-18 08:35:20 --> Config Class Initialized
INFO - 2017-09-18 08:35:20 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:20 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:20 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:20 --> URI Class Initialized
INFO - 2017-09-18 08:35:20 --> Router Class Initialized
INFO - 2017-09-18 08:35:20 --> Output Class Initialized
INFO - 2017-09-18 08:35:20 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:20 --> Input Class Initialized
INFO - 2017-09-18 08:35:20 --> Language Class Initialized
INFO - 2017-09-18 08:35:20 --> Loader Class Initialized
INFO - 2017-09-18 08:35:20 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:20 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:20 --> Email Class Initialized
INFO - 2017-09-18 08:35:20 --> Controller Class Initialized
INFO - 2017-09-18 08:35:20 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:20 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:20 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:20 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:20 --> Model Class Initialized
INFO - 2017-09-18 08:35:20 --> Model Class Initialized
INFO - 2017-09-18 12:05:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-09-18 12:05:20 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:20 --> Total execution time: 0.0465
INFO - 2017-09-18 08:35:22 --> Config Class Initialized
INFO - 2017-09-18 08:35:22 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:35:22 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:35:22 --> Utf8 Class Initialized
INFO - 2017-09-18 08:35:22 --> URI Class Initialized
INFO - 2017-09-18 08:35:22 --> Router Class Initialized
INFO - 2017-09-18 08:35:22 --> Output Class Initialized
INFO - 2017-09-18 08:35:22 --> Security Class Initialized
DEBUG - 2017-09-18 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:35:22 --> Input Class Initialized
INFO - 2017-09-18 08:35:22 --> Language Class Initialized
INFO - 2017-09-18 08:35:22 --> Loader Class Initialized
INFO - 2017-09-18 08:35:22 --> Helper loaded: common_helper
INFO - 2017-09-18 08:35:22 --> Database Driver Class Initialized
INFO - 2017-09-18 08:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:35:22 --> Email Class Initialized
INFO - 2017-09-18 08:35:22 --> Controller Class Initialized
INFO - 2017-09-18 08:35:22 --> Helper loaded: form_helper
INFO - 2017-09-18 08:35:22 --> Form Validation Class Initialized
INFO - 2017-09-18 08:35:22 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:35:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:35:22 --> Helper loaded: url_helper
INFO - 2017-09-18 08:35:22 --> Model Class Initialized
INFO - 2017-09-18 08:35:22 --> Model Class Initialized
INFO - 2017-09-18 12:05:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:05:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:05:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-09-18 12:05:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 12:05:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:05:22 --> Final output sent to browser
DEBUG - 2017-09-18 12:05:22 --> Total execution time: 0.0553
INFO - 2017-09-18 08:37:29 --> Config Class Initialized
INFO - 2017-09-18 08:37:29 --> Hooks Class Initialized
DEBUG - 2017-09-18 08:37:29 --> UTF-8 Support Enabled
INFO - 2017-09-18 08:37:29 --> Utf8 Class Initialized
INFO - 2017-09-18 08:37:29 --> URI Class Initialized
INFO - 2017-09-18 08:37:29 --> Router Class Initialized
INFO - 2017-09-18 08:37:29 --> Output Class Initialized
INFO - 2017-09-18 08:37:29 --> Security Class Initialized
DEBUG - 2017-09-18 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 08:37:29 --> Input Class Initialized
INFO - 2017-09-18 08:37:29 --> Language Class Initialized
INFO - 2017-09-18 08:37:29 --> Loader Class Initialized
INFO - 2017-09-18 08:37:29 --> Helper loaded: common_helper
INFO - 2017-09-18 08:37:29 --> Database Driver Class Initialized
INFO - 2017-09-18 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 08:37:29 --> Email Class Initialized
INFO - 2017-09-18 08:37:29 --> Controller Class Initialized
INFO - 2017-09-18 08:37:29 --> Helper loaded: form_helper
INFO - 2017-09-18 08:37:29 --> Form Validation Class Initialized
INFO - 2017-09-18 08:37:29 --> Helper loaded: email_helper
DEBUG - 2017-09-18 08:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 08:37:29 --> Helper loaded: url_helper
INFO - 2017-09-18 08:37:29 --> Model Class Initialized
INFO - 2017-09-18 08:37:29 --> Model Class Initialized
INFO - 2017-09-18 12:07:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:07:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:07:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 12:07:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-09-18 12:07:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:07:29 --> Final output sent to browser
DEBUG - 2017-09-18 12:07:29 --> Total execution time: 0.0545
INFO - 2017-09-18 12:20:20 --> Config Class Initialized
INFO - 2017-09-18 12:20:20 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:20:20 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:20:20 --> Utf8 Class Initialized
INFO - 2017-09-18 12:20:20 --> URI Class Initialized
DEBUG - 2017-09-18 12:20:20 --> No URI present. Default controller set.
INFO - 2017-09-18 12:20:20 --> Router Class Initialized
INFO - 2017-09-18 12:20:20 --> Output Class Initialized
INFO - 2017-09-18 12:20:20 --> Security Class Initialized
DEBUG - 2017-09-18 12:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:20:20 --> Input Class Initialized
INFO - 2017-09-18 12:20:20 --> Language Class Initialized
INFO - 2017-09-18 12:20:20 --> Loader Class Initialized
INFO - 2017-09-18 12:20:20 --> Helper loaded: common_helper
INFO - 2017-09-18 12:20:20 --> Database Driver Class Initialized
INFO - 2017-09-18 12:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:20:20 --> Email Class Initialized
INFO - 2017-09-18 12:20:20 --> Controller Class Initialized
INFO - 2017-09-18 12:20:20 --> Helper loaded: form_helper
INFO - 2017-09-18 12:20:20 --> Form Validation Class Initialized
INFO - 2017-09-18 12:20:20 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:20 --> Helper loaded: url_helper
INFO - 2017-09-18 12:20:20 --> Model Class Initialized
INFO - 2017-09-18 12:20:20 --> Model Class Initialized
INFO - 2017-09-18 12:20:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-09-18 12:20:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:20:20 --> Final output sent to browser
DEBUG - 2017-09-18 12:20:20 --> Total execution time: 0.0503
INFO - 2017-09-18 12:20:22 --> Config Class Initialized
INFO - 2017-09-18 12:20:22 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:20:22 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:20:22 --> Utf8 Class Initialized
INFO - 2017-09-18 12:20:22 --> URI Class Initialized
DEBUG - 2017-09-18 12:20:22 --> No URI present. Default controller set.
INFO - 2017-09-18 12:20:22 --> Router Class Initialized
INFO - 2017-09-18 12:20:22 --> Output Class Initialized
INFO - 2017-09-18 12:20:22 --> Security Class Initialized
DEBUG - 2017-09-18 12:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:20:22 --> Input Class Initialized
INFO - 2017-09-18 12:20:22 --> Language Class Initialized
INFO - 2017-09-18 12:20:22 --> Loader Class Initialized
INFO - 2017-09-18 12:20:22 --> Helper loaded: common_helper
INFO - 2017-09-18 12:20:22 --> Database Driver Class Initialized
INFO - 2017-09-18 12:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:20:22 --> Email Class Initialized
INFO - 2017-09-18 12:20:22 --> Controller Class Initialized
INFO - 2017-09-18 12:20:22 --> Helper loaded: form_helper
INFO - 2017-09-18 12:20:22 --> Form Validation Class Initialized
INFO - 2017-09-18 12:20:22 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:22 --> Helper loaded: url_helper
INFO - 2017-09-18 12:20:22 --> Model Class Initialized
INFO - 2017-09-18 12:20:22 --> Model Class Initialized
DEBUG - 2017-09-18 12:20:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:20:22 --> Config Class Initialized
INFO - 2017-09-18 12:20:22 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:20:22 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:20:22 --> Utf8 Class Initialized
INFO - 2017-09-18 12:20:22 --> URI Class Initialized
INFO - 2017-09-18 12:20:22 --> Router Class Initialized
INFO - 2017-09-18 12:20:22 --> Output Class Initialized
INFO - 2017-09-18 12:20:22 --> Security Class Initialized
DEBUG - 2017-09-18 12:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:20:22 --> Input Class Initialized
INFO - 2017-09-18 12:20:22 --> Language Class Initialized
INFO - 2017-09-18 12:20:22 --> Loader Class Initialized
INFO - 2017-09-18 12:20:22 --> Helper loaded: common_helper
INFO - 2017-09-18 12:20:22 --> Database Driver Class Initialized
INFO - 2017-09-18 12:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:20:22 --> Email Class Initialized
INFO - 2017-09-18 12:20:22 --> Controller Class Initialized
INFO - 2017-09-18 12:20:22 --> Helper loaded: form_helper
INFO - 2017-09-18 12:20:22 --> Form Validation Class Initialized
INFO - 2017-09-18 12:20:22 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:20:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:22 --> Helper loaded: url_helper
INFO - 2017-09-18 12:20:22 --> Model Class Initialized
INFO - 2017-09-18 12:20:22 --> Model Class Initialized
INFO - 2017-09-18 12:20:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 12:20:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 12:20:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-09-18 12:20:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 12:20:22 --> Final output sent to browser
DEBUG - 2017-09-18 12:20:22 --> Total execution time: 0.0537
INFO - 2017-09-18 12:20:24 --> Config Class Initialized
INFO - 2017-09-18 12:20:24 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:20:24 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:20:24 --> Utf8 Class Initialized
INFO - 2017-09-18 12:20:24 --> URI Class Initialized
INFO - 2017-09-18 12:20:24 --> Router Class Initialized
INFO - 2017-09-18 12:20:24 --> Output Class Initialized
INFO - 2017-09-18 12:20:24 --> Security Class Initialized
DEBUG - 2017-09-18 12:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:20:24 --> Input Class Initialized
INFO - 2017-09-18 12:20:24 --> Language Class Initialized
INFO - 2017-09-18 12:20:24 --> Loader Class Initialized
INFO - 2017-09-18 12:20:24 --> Helper loaded: common_helper
INFO - 2017-09-18 12:20:24 --> Database Driver Class Initialized
INFO - 2017-09-18 12:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:20:24 --> Email Class Initialized
INFO - 2017-09-18 12:20:24 --> Controller Class Initialized
INFO - 2017-09-18 12:20:24 --> Helper loaded: form_helper
INFO - 2017-09-18 12:20:24 --> Form Validation Class Initialized
INFO - 2017-09-18 12:20:24 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:24 --> Helper loaded: url_helper
INFO - 2017-09-18 12:20:24 --> Model Class Initialized
INFO - 2017-09-18 12:20:24 --> Model Class Initialized
INFO - 2017-09-18 12:20:24 --> Model Class Initialized
INFO - 2017-09-18 15:50:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:50:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:50:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 15:50:24 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 15:50:24 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-09-18 15:50:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-09-18 15:50:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:50:24 --> Final output sent to browser
DEBUG - 2017-09-18 15:50:24 --> Total execution time: 0.2683
INFO - 2017-09-18 12:20:25 --> Config Class Initialized
INFO - 2017-09-18 12:20:25 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:20:25 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:20:25 --> Utf8 Class Initialized
INFO - 2017-09-18 12:20:25 --> URI Class Initialized
INFO - 2017-09-18 12:20:25 --> Router Class Initialized
INFO - 2017-09-18 12:20:25 --> Output Class Initialized
INFO - 2017-09-18 12:20:25 --> Security Class Initialized
DEBUG - 2017-09-18 12:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:20:25 --> Input Class Initialized
INFO - 2017-09-18 12:20:25 --> Language Class Initialized
INFO - 2017-09-18 12:20:25 --> Loader Class Initialized
INFO - 2017-09-18 12:20:25 --> Helper loaded: common_helper
INFO - 2017-09-18 12:20:25 --> Database Driver Class Initialized
INFO - 2017-09-18 12:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:20:25 --> Email Class Initialized
INFO - 2017-09-18 12:20:25 --> Controller Class Initialized
INFO - 2017-09-18 12:20:25 --> Helper loaded: form_helper
INFO - 2017-09-18 12:20:25 --> Form Validation Class Initialized
INFO - 2017-09-18 12:20:25 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:20:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:25 --> Helper loaded: url_helper
INFO - 2017-09-18 12:20:25 --> Model Class Initialized
INFO - 2017-09-18 12:20:25 --> Model Class Initialized
INFO - 2017-09-18 12:20:25 --> Model Class Initialized
INFO - 2017-09-18 15:50:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:50:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:50:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:50:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 15:50:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:50:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:50:25 --> Final output sent to browser
DEBUG - 2017-09-18 15:50:25 --> Total execution time: 0.0558
INFO - 2017-09-18 12:20:39 --> Config Class Initialized
INFO - 2017-09-18 12:20:39 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:20:39 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:20:39 --> Utf8 Class Initialized
INFO - 2017-09-18 12:20:39 --> URI Class Initialized
INFO - 2017-09-18 12:20:39 --> Router Class Initialized
INFO - 2017-09-18 12:20:39 --> Output Class Initialized
INFO - 2017-09-18 12:20:39 --> Security Class Initialized
DEBUG - 2017-09-18 12:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:20:39 --> Input Class Initialized
INFO - 2017-09-18 12:20:39 --> Language Class Initialized
INFO - 2017-09-18 12:20:39 --> Loader Class Initialized
INFO - 2017-09-18 12:20:39 --> Helper loaded: common_helper
INFO - 2017-09-18 12:20:39 --> Database Driver Class Initialized
INFO - 2017-09-18 12:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:20:39 --> Email Class Initialized
INFO - 2017-09-18 12:20:39 --> Controller Class Initialized
INFO - 2017-09-18 12:20:39 --> Helper loaded: form_helper
INFO - 2017-09-18 12:20:39 --> Form Validation Class Initialized
INFO - 2017-09-18 12:20:39 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:20:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:20:39 --> Helper loaded: url_helper
INFO - 2017-09-18 12:20:39 --> Model Class Initialized
INFO - 2017-09-18 12:20:39 --> Model Class Initialized
INFO - 2017-09-18 12:20:39 --> Model Class Initialized
DEBUG - 2017-09-18 15:50:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 15:50:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:23:13 --> Config Class Initialized
INFO - 2017-09-18 12:23:13 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:23:13 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:23:13 --> Utf8 Class Initialized
INFO - 2017-09-18 12:23:13 --> URI Class Initialized
INFO - 2017-09-18 12:23:13 --> Router Class Initialized
INFO - 2017-09-18 12:23:13 --> Output Class Initialized
INFO - 2017-09-18 12:23:13 --> Security Class Initialized
DEBUG - 2017-09-18 12:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:23:13 --> Input Class Initialized
INFO - 2017-09-18 12:23:13 --> Language Class Initialized
INFO - 2017-09-18 12:23:13 --> Loader Class Initialized
INFO - 2017-09-18 12:23:13 --> Helper loaded: common_helper
INFO - 2017-09-18 12:23:13 --> Database Driver Class Initialized
INFO - 2017-09-18 12:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:23:13 --> Email Class Initialized
INFO - 2017-09-18 12:23:13 --> Controller Class Initialized
INFO - 2017-09-18 12:23:13 --> Helper loaded: form_helper
INFO - 2017-09-18 12:23:13 --> Form Validation Class Initialized
INFO - 2017-09-18 12:23:13 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:23:13 --> Helper loaded: url_helper
INFO - 2017-09-18 12:23:13 --> Model Class Initialized
INFO - 2017-09-18 12:23:13 --> Model Class Initialized
INFO - 2017-09-18 12:23:13 --> Model Class Initialized
INFO - 2017-09-18 15:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 15:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:53:13 --> Final output sent to browser
DEBUG - 2017-09-18 15:53:13 --> Total execution time: 0.0546
INFO - 2017-09-18 12:23:17 --> Config Class Initialized
INFO - 2017-09-18 12:23:17 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:23:17 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:23:17 --> Utf8 Class Initialized
INFO - 2017-09-18 12:23:17 --> URI Class Initialized
INFO - 2017-09-18 12:23:17 --> Router Class Initialized
INFO - 2017-09-18 12:23:17 --> Output Class Initialized
INFO - 2017-09-18 12:23:17 --> Security Class Initialized
DEBUG - 2017-09-18 12:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:23:17 --> Input Class Initialized
INFO - 2017-09-18 12:23:17 --> Language Class Initialized
INFO - 2017-09-18 12:23:17 --> Loader Class Initialized
INFO - 2017-09-18 12:23:17 --> Helper loaded: common_helper
INFO - 2017-09-18 12:23:17 --> Database Driver Class Initialized
INFO - 2017-09-18 12:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:23:17 --> Email Class Initialized
INFO - 2017-09-18 12:23:17 --> Controller Class Initialized
INFO - 2017-09-18 12:23:17 --> Helper loaded: form_helper
INFO - 2017-09-18 12:23:17 --> Form Validation Class Initialized
INFO - 2017-09-18 12:23:17 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:23:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:23:17 --> Helper loaded: url_helper
INFO - 2017-09-18 12:23:17 --> Model Class Initialized
INFO - 2017-09-18 12:23:17 --> Model Class Initialized
INFO - 2017-09-18 12:23:17 --> Model Class Initialized
INFO - 2017-09-18 15:53:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:53:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:53:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:53:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 15:53:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:53:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:53:17 --> Final output sent to browser
DEBUG - 2017-09-18 15:53:17 --> Total execution time: 0.0508
INFO - 2017-09-18 12:23:30 --> Config Class Initialized
INFO - 2017-09-18 12:23:30 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:23:30 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:23:30 --> Utf8 Class Initialized
INFO - 2017-09-18 12:23:30 --> URI Class Initialized
INFO - 2017-09-18 12:23:30 --> Router Class Initialized
INFO - 2017-09-18 12:23:30 --> Output Class Initialized
INFO - 2017-09-18 12:23:30 --> Security Class Initialized
DEBUG - 2017-09-18 12:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:23:30 --> Input Class Initialized
INFO - 2017-09-18 12:23:30 --> Language Class Initialized
INFO - 2017-09-18 12:23:30 --> Loader Class Initialized
INFO - 2017-09-18 12:23:30 --> Helper loaded: common_helper
INFO - 2017-09-18 12:23:30 --> Database Driver Class Initialized
INFO - 2017-09-18 12:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:23:30 --> Email Class Initialized
INFO - 2017-09-18 12:23:30 --> Controller Class Initialized
INFO - 2017-09-18 12:23:30 --> Helper loaded: form_helper
INFO - 2017-09-18 12:23:30 --> Form Validation Class Initialized
INFO - 2017-09-18 12:23:30 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:23:30 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:23:30 --> Helper loaded: url_helper
INFO - 2017-09-18 12:23:30 --> Model Class Initialized
INFO - 2017-09-18 12:23:30 --> Model Class Initialized
INFO - 2017-09-18 12:23:30 --> Model Class Initialized
DEBUG - 2017-09-18 15:53:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 15:53:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-18 15:53:30 --> Undefined variable: last_id
ERROR - 2017-09-18 15:53:30 --> Severity: Notice --> Undefined variable: last_id C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 274
INFO - 2017-09-18 12:23:40 --> Config Class Initialized
INFO - 2017-09-18 12:23:40 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:23:40 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:23:40 --> Utf8 Class Initialized
INFO - 2017-09-18 12:23:40 --> URI Class Initialized
INFO - 2017-09-18 12:23:40 --> Router Class Initialized
INFO - 2017-09-18 12:23:40 --> Output Class Initialized
INFO - 2017-09-18 12:23:40 --> Security Class Initialized
DEBUG - 2017-09-18 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:23:40 --> Input Class Initialized
INFO - 2017-09-18 12:23:40 --> Language Class Initialized
INFO - 2017-09-18 12:23:40 --> Loader Class Initialized
INFO - 2017-09-18 12:23:40 --> Helper loaded: common_helper
INFO - 2017-09-18 12:23:40 --> Database Driver Class Initialized
INFO - 2017-09-18 12:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:23:40 --> Email Class Initialized
INFO - 2017-09-18 12:23:40 --> Controller Class Initialized
INFO - 2017-09-18 12:23:40 --> Helper loaded: form_helper
INFO - 2017-09-18 12:23:40 --> Form Validation Class Initialized
INFO - 2017-09-18 12:23:40 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:23:40 --> Helper loaded: url_helper
INFO - 2017-09-18 12:23:40 --> Model Class Initialized
INFO - 2017-09-18 12:23:40 --> Model Class Initialized
INFO - 2017-09-18 12:23:40 --> Model Class Initialized
DEBUG - 2017-09-18 15:53:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 15:53:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:23:40 --> Config Class Initialized
INFO - 2017-09-18 12:23:40 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:23:40 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:23:40 --> Utf8 Class Initialized
INFO - 2017-09-18 12:23:40 --> URI Class Initialized
INFO - 2017-09-18 12:23:40 --> Router Class Initialized
INFO - 2017-09-18 12:23:40 --> Output Class Initialized
INFO - 2017-09-18 12:23:40 --> Security Class Initialized
DEBUG - 2017-09-18 12:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:23:40 --> Input Class Initialized
INFO - 2017-09-18 12:23:40 --> Language Class Initialized
INFO - 2017-09-18 12:23:40 --> Loader Class Initialized
INFO - 2017-09-18 12:23:40 --> Helper loaded: common_helper
INFO - 2017-09-18 12:23:40 --> Database Driver Class Initialized
INFO - 2017-09-18 12:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:23:40 --> Email Class Initialized
INFO - 2017-09-18 12:23:40 --> Controller Class Initialized
INFO - 2017-09-18 12:23:40 --> Helper loaded: form_helper
INFO - 2017-09-18 12:23:40 --> Form Validation Class Initialized
INFO - 2017-09-18 12:23:40 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:23:40 --> Helper loaded: url_helper
INFO - 2017-09-18 12:23:40 --> Model Class Initialized
INFO - 2017-09-18 12:23:40 --> Model Class Initialized
INFO - 2017-09-18 12:23:40 --> Model Class Initialized
INFO - 2017-09-18 15:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 15:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:53:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:53:40 --> Final output sent to browser
DEBUG - 2017-09-18 15:53:40 --> Total execution time: 0.0550
INFO - 2017-09-18 12:23:55 --> Config Class Initialized
INFO - 2017-09-18 12:23:55 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:23:55 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:23:55 --> Utf8 Class Initialized
INFO - 2017-09-18 12:23:55 --> URI Class Initialized
INFO - 2017-09-18 12:23:55 --> Router Class Initialized
INFO - 2017-09-18 12:23:55 --> Output Class Initialized
INFO - 2017-09-18 12:23:55 --> Security Class Initialized
DEBUG - 2017-09-18 12:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:23:55 --> Input Class Initialized
INFO - 2017-09-18 12:23:55 --> Language Class Initialized
INFO - 2017-09-18 12:23:55 --> Loader Class Initialized
INFO - 2017-09-18 12:23:55 --> Helper loaded: common_helper
INFO - 2017-09-18 12:23:55 --> Database Driver Class Initialized
INFO - 2017-09-18 12:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:23:55 --> Email Class Initialized
INFO - 2017-09-18 12:23:55 --> Controller Class Initialized
INFO - 2017-09-18 12:23:55 --> Helper loaded: form_helper
INFO - 2017-09-18 12:23:55 --> Form Validation Class Initialized
INFO - 2017-09-18 12:23:55 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:23:55 --> Helper loaded: url_helper
INFO - 2017-09-18 12:23:55 --> Model Class Initialized
INFO - 2017-09-18 12:23:55 --> Model Class Initialized
INFO - 2017-09-18 12:23:55 --> Model Class Initialized
DEBUG - 2017-09-18 15:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 15:53:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:26:46 --> Config Class Initialized
INFO - 2017-09-18 12:26:46 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:26:46 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:26:46 --> Utf8 Class Initialized
INFO - 2017-09-18 12:26:46 --> URI Class Initialized
INFO - 2017-09-18 12:26:46 --> Router Class Initialized
INFO - 2017-09-18 12:26:46 --> Output Class Initialized
INFO - 2017-09-18 12:26:46 --> Security Class Initialized
DEBUG - 2017-09-18 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:26:46 --> Input Class Initialized
INFO - 2017-09-18 12:26:46 --> Language Class Initialized
INFO - 2017-09-18 12:26:46 --> Loader Class Initialized
INFO - 2017-09-18 12:26:46 --> Helper loaded: common_helper
INFO - 2017-09-18 12:26:46 --> Database Driver Class Initialized
INFO - 2017-09-18 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:26:46 --> Email Class Initialized
INFO - 2017-09-18 12:26:46 --> Controller Class Initialized
INFO - 2017-09-18 12:26:46 --> Helper loaded: form_helper
INFO - 2017-09-18 12:26:46 --> Form Validation Class Initialized
INFO - 2017-09-18 12:26:46 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:26:46 --> Helper loaded: url_helper
INFO - 2017-09-18 12:26:46 --> Model Class Initialized
INFO - 2017-09-18 12:26:46 --> Model Class Initialized
INFO - 2017-09-18 12:26:46 --> Model Class Initialized
DEBUG - 2017-09-18 15:56:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 15:56:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:26:46 --> Config Class Initialized
INFO - 2017-09-18 12:26:46 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:26:46 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:26:46 --> Utf8 Class Initialized
INFO - 2017-09-18 12:26:46 --> URI Class Initialized
INFO - 2017-09-18 12:26:46 --> Router Class Initialized
INFO - 2017-09-18 12:26:46 --> Output Class Initialized
INFO - 2017-09-18 12:26:46 --> Security Class Initialized
DEBUG - 2017-09-18 12:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:26:46 --> Input Class Initialized
INFO - 2017-09-18 12:26:46 --> Language Class Initialized
INFO - 2017-09-18 12:26:46 --> Loader Class Initialized
INFO - 2017-09-18 12:26:46 --> Helper loaded: common_helper
INFO - 2017-09-18 12:26:46 --> Database Driver Class Initialized
INFO - 2017-09-18 12:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:26:46 --> Email Class Initialized
INFO - 2017-09-18 12:26:46 --> Controller Class Initialized
INFO - 2017-09-18 12:26:46 --> Helper loaded: form_helper
INFO - 2017-09-18 12:26:46 --> Form Validation Class Initialized
INFO - 2017-09-18 12:26:46 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:26:46 --> Helper loaded: url_helper
INFO - 2017-09-18 12:26:46 --> Model Class Initialized
INFO - 2017-09-18 12:26:46 --> Model Class Initialized
INFO - 2017-09-18 12:26:46 --> Model Class Initialized
INFO - 2017-09-18 15:56:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:56:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:56:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:56:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 15:56:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:56:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:56:46 --> Final output sent to browser
DEBUG - 2017-09-18 15:56:46 --> Total execution time: 0.0571
INFO - 2017-09-18 12:26:53 --> Config Class Initialized
INFO - 2017-09-18 12:26:53 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:26:53 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:26:53 --> Utf8 Class Initialized
INFO - 2017-09-18 12:26:53 --> URI Class Initialized
INFO - 2017-09-18 12:26:53 --> Router Class Initialized
INFO - 2017-09-18 12:26:53 --> Output Class Initialized
INFO - 2017-09-18 12:26:53 --> Security Class Initialized
DEBUG - 2017-09-18 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:26:53 --> Input Class Initialized
INFO - 2017-09-18 12:26:53 --> Language Class Initialized
INFO - 2017-09-18 12:26:53 --> Loader Class Initialized
INFO - 2017-09-18 12:26:53 --> Helper loaded: common_helper
INFO - 2017-09-18 12:26:53 --> Database Driver Class Initialized
INFO - 2017-09-18 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:26:53 --> Email Class Initialized
INFO - 2017-09-18 12:26:53 --> Controller Class Initialized
INFO - 2017-09-18 12:26:53 --> Helper loaded: form_helper
INFO - 2017-09-18 12:26:53 --> Form Validation Class Initialized
INFO - 2017-09-18 12:26:53 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:26:53 --> Helper loaded: url_helper
INFO - 2017-09-18 12:26:53 --> Model Class Initialized
INFO - 2017-09-18 12:26:53 --> Model Class Initialized
INFO - 2017-09-18 12:26:53 --> Model Class Initialized
INFO - 2017-09-18 15:56:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 15:56:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 15:56:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:56:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 15:56:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 15:56:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 15:56:53 --> Final output sent to browser
DEBUG - 2017-09-18 15:56:53 --> Total execution time: 0.0572
INFO - 2017-09-18 12:27:10 --> Config Class Initialized
INFO - 2017-09-18 12:27:10 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:27:10 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:27:10 --> Utf8 Class Initialized
INFO - 2017-09-18 12:27:10 --> URI Class Initialized
INFO - 2017-09-18 12:27:10 --> Router Class Initialized
INFO - 2017-09-18 12:27:10 --> Output Class Initialized
INFO - 2017-09-18 12:27:10 --> Security Class Initialized
DEBUG - 2017-09-18 12:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:27:10 --> Input Class Initialized
INFO - 2017-09-18 12:27:10 --> Language Class Initialized
INFO - 2017-09-18 12:27:10 --> Loader Class Initialized
INFO - 2017-09-18 12:27:10 --> Helper loaded: common_helper
INFO - 2017-09-18 12:27:10 --> Database Driver Class Initialized
INFO - 2017-09-18 12:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:27:10 --> Email Class Initialized
INFO - 2017-09-18 12:27:10 --> Controller Class Initialized
INFO - 2017-09-18 12:27:10 --> Helper loaded: form_helper
INFO - 2017-09-18 12:27:10 --> Form Validation Class Initialized
INFO - 2017-09-18 12:27:10 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:27:10 --> Helper loaded: url_helper
INFO - 2017-09-18 12:27:10 --> Model Class Initialized
INFO - 2017-09-18 12:27:10 --> Model Class Initialized
INFO - 2017-09-18 12:27:10 --> Model Class Initialized
DEBUG - 2017-09-18 15:57:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 15:57:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:30:03 --> Config Class Initialized
INFO - 2017-09-18 12:30:03 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:30:03 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:30:03 --> Utf8 Class Initialized
INFO - 2017-09-18 12:30:03 --> URI Class Initialized
INFO - 2017-09-18 12:30:03 --> Router Class Initialized
INFO - 2017-09-18 12:30:03 --> Output Class Initialized
INFO - 2017-09-18 12:30:03 --> Security Class Initialized
DEBUG - 2017-09-18 12:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:30:03 --> Input Class Initialized
INFO - 2017-09-18 12:30:03 --> Language Class Initialized
INFO - 2017-09-18 12:30:03 --> Loader Class Initialized
INFO - 2017-09-18 12:30:03 --> Helper loaded: common_helper
INFO - 2017-09-18 12:30:03 --> Database Driver Class Initialized
INFO - 2017-09-18 12:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:30:03 --> Email Class Initialized
INFO - 2017-09-18 12:30:03 --> Controller Class Initialized
INFO - 2017-09-18 12:30:03 --> Helper loaded: form_helper
INFO - 2017-09-18 12:30:03 --> Form Validation Class Initialized
INFO - 2017-09-18 12:30:03 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:30:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:30:03 --> Helper loaded: url_helper
INFO - 2017-09-18 12:30:03 --> Model Class Initialized
INFO - 2017-09-18 12:30:03 --> Model Class Initialized
INFO - 2017-09-18 12:30:03 --> Model Class Initialized
INFO - 2017-09-18 16:00:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:00:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:00:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:00:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:00:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:00:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:00:03 --> Final output sent to browser
DEBUG - 2017-09-18 16:00:03 --> Total execution time: 0.0555
INFO - 2017-09-18 12:30:05 --> Config Class Initialized
INFO - 2017-09-18 12:30:05 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:30:05 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:30:05 --> Utf8 Class Initialized
INFO - 2017-09-18 12:30:05 --> URI Class Initialized
INFO - 2017-09-18 12:30:05 --> Router Class Initialized
INFO - 2017-09-18 12:30:05 --> Output Class Initialized
INFO - 2017-09-18 12:30:05 --> Security Class Initialized
DEBUG - 2017-09-18 12:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:30:05 --> Input Class Initialized
INFO - 2017-09-18 12:30:05 --> Language Class Initialized
INFO - 2017-09-18 12:30:05 --> Loader Class Initialized
INFO - 2017-09-18 12:30:05 --> Helper loaded: common_helper
INFO - 2017-09-18 12:30:05 --> Database Driver Class Initialized
INFO - 2017-09-18 12:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:30:05 --> Email Class Initialized
INFO - 2017-09-18 12:30:05 --> Controller Class Initialized
INFO - 2017-09-18 12:30:05 --> Helper loaded: form_helper
INFO - 2017-09-18 12:30:05 --> Form Validation Class Initialized
INFO - 2017-09-18 12:30:05 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:30:05 --> Helper loaded: url_helper
INFO - 2017-09-18 12:30:05 --> Model Class Initialized
INFO - 2017-09-18 12:30:05 --> Model Class Initialized
INFO - 2017-09-18 12:30:05 --> Model Class Initialized
INFO - 2017-09-18 16:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:00:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:00:05 --> Final output sent to browser
DEBUG - 2017-09-18 16:00:05 --> Total execution time: 0.0525
INFO - 2017-09-18 12:30:22 --> Config Class Initialized
INFO - 2017-09-18 12:30:22 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:30:22 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:30:22 --> Utf8 Class Initialized
INFO - 2017-09-18 12:30:22 --> URI Class Initialized
INFO - 2017-09-18 12:30:22 --> Router Class Initialized
INFO - 2017-09-18 12:30:22 --> Output Class Initialized
INFO - 2017-09-18 12:30:22 --> Security Class Initialized
DEBUG - 2017-09-18 12:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:30:22 --> Input Class Initialized
INFO - 2017-09-18 12:30:22 --> Language Class Initialized
INFO - 2017-09-18 12:30:22 --> Loader Class Initialized
INFO - 2017-09-18 12:30:22 --> Helper loaded: common_helper
INFO - 2017-09-18 12:30:22 --> Database Driver Class Initialized
INFO - 2017-09-18 12:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:30:22 --> Email Class Initialized
INFO - 2017-09-18 12:30:22 --> Controller Class Initialized
INFO - 2017-09-18 12:30:22 --> Helper loaded: form_helper
INFO - 2017-09-18 12:30:22 --> Form Validation Class Initialized
INFO - 2017-09-18 12:30:22 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:30:22 --> Helper loaded: url_helper
INFO - 2017-09-18 12:30:22 --> Model Class Initialized
INFO - 2017-09-18 12:30:22 --> Model Class Initialized
INFO - 2017-09-18 12:30:22 --> Model Class Initialized
DEBUG - 2017-09-18 16:00:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:00:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-18 16:00:22 --> Call to undefined method News::getRecords()
ERROR - 2017-09-18 16:00:22 --> Severity: Error --> Call to undefined method News::getRecords() C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 304
INFO - 2017-09-18 12:31:22 --> Config Class Initialized
INFO - 2017-09-18 12:31:22 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:31:22 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:31:22 --> Utf8 Class Initialized
INFO - 2017-09-18 12:31:22 --> URI Class Initialized
INFO - 2017-09-18 12:31:22 --> Router Class Initialized
INFO - 2017-09-18 12:31:22 --> Output Class Initialized
INFO - 2017-09-18 12:31:22 --> Security Class Initialized
DEBUG - 2017-09-18 12:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:31:22 --> Input Class Initialized
INFO - 2017-09-18 12:31:22 --> Language Class Initialized
INFO - 2017-09-18 12:31:22 --> Loader Class Initialized
INFO - 2017-09-18 12:31:22 --> Helper loaded: common_helper
INFO - 2017-09-18 12:31:22 --> Database Driver Class Initialized
INFO - 2017-09-18 12:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:31:22 --> Email Class Initialized
INFO - 2017-09-18 12:31:22 --> Controller Class Initialized
INFO - 2017-09-18 12:31:22 --> Helper loaded: form_helper
INFO - 2017-09-18 12:31:22 --> Form Validation Class Initialized
INFO - 2017-09-18 12:31:22 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:31:22 --> Helper loaded: url_helper
INFO - 2017-09-18 12:31:22 --> Model Class Initialized
INFO - 2017-09-18 12:31:22 --> Model Class Initialized
INFO - 2017-09-18 12:31:22 --> Model Class Initialized
DEBUG - 2017-09-18 16:01:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:01:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:31:22 --> Config Class Initialized
INFO - 2017-09-18 12:31:22 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:31:22 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:31:22 --> Utf8 Class Initialized
INFO - 2017-09-18 12:31:22 --> URI Class Initialized
INFO - 2017-09-18 12:31:22 --> Router Class Initialized
INFO - 2017-09-18 12:31:22 --> Output Class Initialized
INFO - 2017-09-18 12:31:22 --> Security Class Initialized
DEBUG - 2017-09-18 12:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:31:22 --> Input Class Initialized
INFO - 2017-09-18 12:31:22 --> Language Class Initialized
INFO - 2017-09-18 12:31:22 --> Loader Class Initialized
INFO - 2017-09-18 12:31:22 --> Helper loaded: common_helper
INFO - 2017-09-18 12:31:22 --> Database Driver Class Initialized
INFO - 2017-09-18 12:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:31:22 --> Email Class Initialized
INFO - 2017-09-18 12:31:22 --> Controller Class Initialized
INFO - 2017-09-18 12:31:22 --> Helper loaded: form_helper
INFO - 2017-09-18 12:31:22 --> Form Validation Class Initialized
INFO - 2017-09-18 12:31:22 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:31:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:31:22 --> Helper loaded: url_helper
INFO - 2017-09-18 12:31:22 --> Model Class Initialized
INFO - 2017-09-18 12:31:22 --> Model Class Initialized
INFO - 2017-09-18 12:31:22 --> Model Class Initialized
INFO - 2017-09-18 16:01:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:01:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:01:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:01:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:01:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:01:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:01:22 --> Final output sent to browser
DEBUG - 2017-09-18 16:01:22 --> Total execution time: 0.0568
INFO - 2017-09-18 12:31:27 --> Config Class Initialized
INFO - 2017-09-18 12:31:27 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:31:27 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:31:27 --> Utf8 Class Initialized
INFO - 2017-09-18 12:31:27 --> URI Class Initialized
INFO - 2017-09-18 12:31:27 --> Router Class Initialized
INFO - 2017-09-18 12:31:27 --> Output Class Initialized
INFO - 2017-09-18 12:31:27 --> Security Class Initialized
DEBUG - 2017-09-18 12:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:31:27 --> Input Class Initialized
INFO - 2017-09-18 12:31:27 --> Language Class Initialized
INFO - 2017-09-18 12:31:27 --> Loader Class Initialized
INFO - 2017-09-18 12:31:27 --> Helper loaded: common_helper
INFO - 2017-09-18 12:31:27 --> Database Driver Class Initialized
INFO - 2017-09-18 12:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:31:27 --> Email Class Initialized
INFO - 2017-09-18 12:31:27 --> Controller Class Initialized
INFO - 2017-09-18 12:31:27 --> Helper loaded: form_helper
INFO - 2017-09-18 12:31:27 --> Form Validation Class Initialized
INFO - 2017-09-18 12:31:27 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:31:27 --> Helper loaded: url_helper
INFO - 2017-09-18 12:31:27 --> Model Class Initialized
INFO - 2017-09-18 12:31:27 --> Model Class Initialized
INFO - 2017-09-18 12:31:27 --> Model Class Initialized
INFO - 2017-09-18 16:01:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:01:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:01:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:01:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:01:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:01:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:01:27 --> Final output sent to browser
DEBUG - 2017-09-18 16:01:27 --> Total execution time: 0.0534
INFO - 2017-09-18 12:31:40 --> Config Class Initialized
INFO - 2017-09-18 12:31:40 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:31:40 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:31:40 --> Utf8 Class Initialized
INFO - 2017-09-18 12:31:40 --> URI Class Initialized
INFO - 2017-09-18 12:31:40 --> Router Class Initialized
INFO - 2017-09-18 12:31:40 --> Output Class Initialized
INFO - 2017-09-18 12:31:40 --> Security Class Initialized
DEBUG - 2017-09-18 12:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:31:40 --> Input Class Initialized
INFO - 2017-09-18 12:31:40 --> Language Class Initialized
INFO - 2017-09-18 12:31:40 --> Loader Class Initialized
INFO - 2017-09-18 12:31:40 --> Helper loaded: common_helper
INFO - 2017-09-18 12:31:40 --> Database Driver Class Initialized
INFO - 2017-09-18 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:31:40 --> Email Class Initialized
INFO - 2017-09-18 12:31:40 --> Controller Class Initialized
INFO - 2017-09-18 12:31:40 --> Helper loaded: form_helper
INFO - 2017-09-18 12:31:40 --> Form Validation Class Initialized
INFO - 2017-09-18 12:31:40 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:31:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:31:40 --> Helper loaded: url_helper
INFO - 2017-09-18 12:31:40 --> Model Class Initialized
INFO - 2017-09-18 12:31:40 --> Model Class Initialized
INFO - 2017-09-18 12:31:40 --> Model Class Initialized
DEBUG - 2017-09-18 16:01:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:01:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-18 16:01:40 --> Use of undefined constant TBL_FCM_TOKENS - assumed 'TBL_FCM_TOKENS'
ERROR - 2017-09-18 16:01:40 --> Severity: Notice --> Use of undefined constant TBL_FCM_TOKENS - assumed 'TBL_FCM_TOKENS' C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 304
ERROR - 2017-09-18 16:01:41 --> Query error: Table 'flicknews.tbl_fcm_tokens' doesn't exist - Invalid query: SELECT `fcm_token`
FROM `TBL_FCM_TOKENS`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-09-18 16:01:41 --> Call to a member function result() on a non-object
ERROR - 2017-09-18 16:01:41 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 75
INFO - 2017-09-18 12:32:44 --> Config Class Initialized
INFO - 2017-09-18 12:32:44 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:32:44 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:32:44 --> Utf8 Class Initialized
INFO - 2017-09-18 12:32:44 --> URI Class Initialized
INFO - 2017-09-18 12:32:44 --> Router Class Initialized
INFO - 2017-09-18 12:32:44 --> Output Class Initialized
INFO - 2017-09-18 12:32:44 --> Security Class Initialized
DEBUG - 2017-09-18 12:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:32:44 --> Input Class Initialized
INFO - 2017-09-18 12:32:44 --> Language Class Initialized
INFO - 2017-09-18 12:32:44 --> Loader Class Initialized
INFO - 2017-09-18 12:32:44 --> Helper loaded: common_helper
INFO - 2017-09-18 12:32:44 --> Database Driver Class Initialized
INFO - 2017-09-18 12:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:32:44 --> Email Class Initialized
INFO - 2017-09-18 12:32:44 --> Controller Class Initialized
INFO - 2017-09-18 12:32:44 --> Helper loaded: form_helper
INFO - 2017-09-18 12:32:44 --> Form Validation Class Initialized
INFO - 2017-09-18 12:32:44 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:32:44 --> Helper loaded: url_helper
INFO - 2017-09-18 12:32:44 --> Model Class Initialized
INFO - 2017-09-18 12:32:44 --> Model Class Initialized
INFO - 2017-09-18 12:32:44 --> Model Class Initialized
DEBUG - 2017-09-18 16:02:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:02:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:32:44 --> Config Class Initialized
INFO - 2017-09-18 12:32:44 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:32:44 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:32:44 --> Utf8 Class Initialized
INFO - 2017-09-18 12:32:44 --> URI Class Initialized
INFO - 2017-09-18 12:32:44 --> Router Class Initialized
INFO - 2017-09-18 12:32:44 --> Output Class Initialized
INFO - 2017-09-18 12:32:44 --> Security Class Initialized
DEBUG - 2017-09-18 12:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:32:44 --> Input Class Initialized
INFO - 2017-09-18 12:32:44 --> Language Class Initialized
INFO - 2017-09-18 12:32:44 --> Loader Class Initialized
INFO - 2017-09-18 12:32:44 --> Helper loaded: common_helper
INFO - 2017-09-18 12:32:44 --> Database Driver Class Initialized
INFO - 2017-09-18 12:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:32:44 --> Email Class Initialized
INFO - 2017-09-18 12:32:44 --> Controller Class Initialized
INFO - 2017-09-18 12:32:44 --> Helper loaded: form_helper
INFO - 2017-09-18 12:32:44 --> Form Validation Class Initialized
INFO - 2017-09-18 12:32:44 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:32:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:32:44 --> Helper loaded: url_helper
INFO - 2017-09-18 12:32:44 --> Model Class Initialized
INFO - 2017-09-18 12:32:44 --> Model Class Initialized
INFO - 2017-09-18 12:32:44 --> Model Class Initialized
INFO - 2017-09-18 16:02:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:02:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:02:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:02:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:02:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:02:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:02:44 --> Final output sent to browser
DEBUG - 2017-09-18 16:02:44 --> Total execution time: 0.0542
INFO - 2017-09-18 12:32:46 --> Config Class Initialized
INFO - 2017-09-18 12:32:46 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:32:46 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:32:46 --> Utf8 Class Initialized
INFO - 2017-09-18 12:32:46 --> URI Class Initialized
INFO - 2017-09-18 12:32:46 --> Router Class Initialized
INFO - 2017-09-18 12:32:46 --> Output Class Initialized
INFO - 2017-09-18 12:32:46 --> Security Class Initialized
DEBUG - 2017-09-18 12:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:32:46 --> Input Class Initialized
INFO - 2017-09-18 12:32:46 --> Language Class Initialized
INFO - 2017-09-18 12:32:46 --> Loader Class Initialized
INFO - 2017-09-18 12:32:46 --> Helper loaded: common_helper
INFO - 2017-09-18 12:32:46 --> Database Driver Class Initialized
INFO - 2017-09-18 12:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:32:46 --> Email Class Initialized
INFO - 2017-09-18 12:32:46 --> Controller Class Initialized
INFO - 2017-09-18 12:32:46 --> Helper loaded: form_helper
INFO - 2017-09-18 12:32:46 --> Form Validation Class Initialized
INFO - 2017-09-18 12:32:46 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:32:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:32:46 --> Helper loaded: url_helper
INFO - 2017-09-18 12:32:46 --> Model Class Initialized
INFO - 2017-09-18 12:32:46 --> Model Class Initialized
INFO - 2017-09-18 12:32:46 --> Model Class Initialized
INFO - 2017-09-18 16:02:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:02:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:02:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:02:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:02:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:02:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:02:46 --> Final output sent to browser
DEBUG - 2017-09-18 16:02:46 --> Total execution time: 0.0592
INFO - 2017-09-18 12:33:03 --> Config Class Initialized
INFO - 2017-09-18 12:33:03 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:33:03 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:33:03 --> Utf8 Class Initialized
INFO - 2017-09-18 12:33:03 --> URI Class Initialized
INFO - 2017-09-18 12:33:03 --> Router Class Initialized
INFO - 2017-09-18 12:33:03 --> Output Class Initialized
INFO - 2017-09-18 12:33:03 --> Security Class Initialized
DEBUG - 2017-09-18 12:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:33:03 --> Input Class Initialized
INFO - 2017-09-18 12:33:03 --> Language Class Initialized
INFO - 2017-09-18 12:33:03 --> Loader Class Initialized
INFO - 2017-09-18 12:33:03 --> Helper loaded: common_helper
INFO - 2017-09-18 12:33:03 --> Database Driver Class Initialized
INFO - 2017-09-18 12:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:33:03 --> Email Class Initialized
INFO - 2017-09-18 12:33:03 --> Controller Class Initialized
INFO - 2017-09-18 12:33:03 --> Helper loaded: form_helper
INFO - 2017-09-18 12:33:03 --> Form Validation Class Initialized
INFO - 2017-09-18 12:33:03 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:33:03 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:33:03 --> Helper loaded: url_helper
INFO - 2017-09-18 12:33:03 --> Model Class Initialized
INFO - 2017-09-18 12:33:03 --> Model Class Initialized
INFO - 2017-09-18 12:33:03 --> Model Class Initialized
DEBUG - 2017-09-18 16:03:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:03:03 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2017-09-18 16:03:03 --> Use of undefined constant TBL_FCM_TOKENS - assumed 'TBL_FCM_TOKENS'
ERROR - 2017-09-18 16:03:03 --> Severity: Notice --> Use of undefined constant TBL_FCM_TOKENS - assumed 'TBL_FCM_TOKENS' C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 304
ERROR - 2017-09-18 16:03:03 --> Query error: Table 'flicknews.tbl_fcm_tokens' doesn't exist - Invalid query: SELECT `fcm_token`
FROM `TBL_FCM_TOKENS`
WHERE `isActive` = 1
AND `isDeleted` =0
ERROR - 2017-09-18 16:03:03 --> Call to a member function result() on a non-object
ERROR - 2017-09-18 16:03:03 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\FlickNews\admin\application\core\Healthcontroller.php 75
INFO - 2017-09-18 12:34:23 --> Config Class Initialized
INFO - 2017-09-18 12:34:23 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:34:23 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:34:23 --> Utf8 Class Initialized
INFO - 2017-09-18 12:34:23 --> URI Class Initialized
INFO - 2017-09-18 12:34:23 --> Router Class Initialized
INFO - 2017-09-18 12:34:23 --> Output Class Initialized
INFO - 2017-09-18 12:34:23 --> Security Class Initialized
DEBUG - 2017-09-18 12:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:34:23 --> Input Class Initialized
INFO - 2017-09-18 12:34:23 --> Language Class Initialized
INFO - 2017-09-18 12:34:23 --> Loader Class Initialized
INFO - 2017-09-18 12:34:23 --> Helper loaded: common_helper
INFO - 2017-09-18 12:34:23 --> Database Driver Class Initialized
INFO - 2017-09-18 12:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:34:23 --> Email Class Initialized
INFO - 2017-09-18 12:34:23 --> Controller Class Initialized
INFO - 2017-09-18 12:34:23 --> Helper loaded: form_helper
INFO - 2017-09-18 12:34:23 --> Form Validation Class Initialized
INFO - 2017-09-18 12:34:23 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:34:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:34:23 --> Helper loaded: url_helper
INFO - 2017-09-18 12:34:23 --> Model Class Initialized
INFO - 2017-09-18 12:34:23 --> Model Class Initialized
INFO - 2017-09-18 12:34:23 --> Model Class Initialized
DEBUG - 2017-09-18 16:04:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:04:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:34:42 --> Config Class Initialized
INFO - 2017-09-18 12:34:42 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:34:42 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:34:42 --> Utf8 Class Initialized
INFO - 2017-09-18 12:34:42 --> URI Class Initialized
INFO - 2017-09-18 12:34:42 --> Router Class Initialized
INFO - 2017-09-18 12:34:42 --> Output Class Initialized
INFO - 2017-09-18 12:34:42 --> Security Class Initialized
DEBUG - 2017-09-18 12:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:34:42 --> Input Class Initialized
INFO - 2017-09-18 12:34:42 --> Language Class Initialized
INFO - 2017-09-18 12:34:42 --> Loader Class Initialized
INFO - 2017-09-18 12:34:42 --> Helper loaded: common_helper
INFO - 2017-09-18 12:34:42 --> Database Driver Class Initialized
INFO - 2017-09-18 12:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:34:42 --> Email Class Initialized
INFO - 2017-09-18 12:34:42 --> Controller Class Initialized
INFO - 2017-09-18 12:34:42 --> Helper loaded: form_helper
INFO - 2017-09-18 12:34:42 --> Form Validation Class Initialized
INFO - 2017-09-18 12:34:42 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:34:42 --> Helper loaded: url_helper
INFO - 2017-09-18 12:34:42 --> Model Class Initialized
INFO - 2017-09-18 12:34:42 --> Model Class Initialized
INFO - 2017-09-18 12:34:42 --> Model Class Initialized
INFO - 2017-09-18 16:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:04:42 --> Final output sent to browser
DEBUG - 2017-09-18 16:04:42 --> Total execution time: 0.0517
INFO - 2017-09-18 12:34:43 --> Config Class Initialized
INFO - 2017-09-18 12:34:43 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:34:43 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:34:43 --> Utf8 Class Initialized
INFO - 2017-09-18 12:34:43 --> URI Class Initialized
INFO - 2017-09-18 12:34:43 --> Router Class Initialized
INFO - 2017-09-18 12:34:43 --> Output Class Initialized
INFO - 2017-09-18 12:34:43 --> Security Class Initialized
DEBUG - 2017-09-18 12:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:34:43 --> Input Class Initialized
INFO - 2017-09-18 12:34:43 --> Language Class Initialized
INFO - 2017-09-18 12:34:43 --> Loader Class Initialized
INFO - 2017-09-18 12:34:43 --> Helper loaded: common_helper
INFO - 2017-09-18 12:34:43 --> Database Driver Class Initialized
INFO - 2017-09-18 12:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:34:43 --> Email Class Initialized
INFO - 2017-09-18 12:34:43 --> Controller Class Initialized
INFO - 2017-09-18 12:34:43 --> Helper loaded: form_helper
INFO - 2017-09-18 12:34:43 --> Form Validation Class Initialized
INFO - 2017-09-18 12:34:43 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:34:43 --> Helper loaded: url_helper
INFO - 2017-09-18 12:34:43 --> Model Class Initialized
INFO - 2017-09-18 12:34:43 --> Model Class Initialized
INFO - 2017-09-18 12:34:43 --> Model Class Initialized
INFO - 2017-09-18 16:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:04:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:04:43 --> Final output sent to browser
DEBUG - 2017-09-18 16:04:44 --> Total execution time: 0.0496
INFO - 2017-09-18 12:34:56 --> Config Class Initialized
INFO - 2017-09-18 12:34:56 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:34:56 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:34:56 --> Utf8 Class Initialized
INFO - 2017-09-18 12:34:56 --> URI Class Initialized
INFO - 2017-09-18 12:34:56 --> Router Class Initialized
INFO - 2017-09-18 12:34:56 --> Output Class Initialized
INFO - 2017-09-18 12:34:56 --> Security Class Initialized
DEBUG - 2017-09-18 12:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:34:56 --> Input Class Initialized
INFO - 2017-09-18 12:34:56 --> Language Class Initialized
INFO - 2017-09-18 12:34:56 --> Loader Class Initialized
INFO - 2017-09-18 12:34:56 --> Helper loaded: common_helper
INFO - 2017-09-18 12:34:56 --> Database Driver Class Initialized
INFO - 2017-09-18 12:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:34:56 --> Email Class Initialized
INFO - 2017-09-18 12:34:56 --> Controller Class Initialized
INFO - 2017-09-18 12:34:56 --> Helper loaded: form_helper
INFO - 2017-09-18 12:34:56 --> Form Validation Class Initialized
INFO - 2017-09-18 12:34:56 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:34:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:34:56 --> Helper loaded: url_helper
INFO - 2017-09-18 12:34:56 --> Model Class Initialized
INFO - 2017-09-18 12:34:56 --> Model Class Initialized
INFO - 2017-09-18 12:34:56 --> Model Class Initialized
DEBUG - 2017-09-18 16:04:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:04:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:35:36 --> Config Class Initialized
INFO - 2017-09-18 12:35:36 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:35:36 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:35:36 --> Utf8 Class Initialized
INFO - 2017-09-18 12:35:36 --> URI Class Initialized
INFO - 2017-09-18 12:35:36 --> Router Class Initialized
INFO - 2017-09-18 12:35:36 --> Output Class Initialized
INFO - 2017-09-18 12:35:36 --> Security Class Initialized
DEBUG - 2017-09-18 12:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:35:36 --> Input Class Initialized
INFO - 2017-09-18 12:35:36 --> Language Class Initialized
INFO - 2017-09-18 12:35:36 --> Loader Class Initialized
INFO - 2017-09-18 12:35:36 --> Helper loaded: common_helper
INFO - 2017-09-18 12:35:36 --> Database Driver Class Initialized
INFO - 2017-09-18 12:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:35:36 --> Email Class Initialized
INFO - 2017-09-18 12:35:36 --> Controller Class Initialized
INFO - 2017-09-18 12:35:36 --> Helper loaded: form_helper
INFO - 2017-09-18 12:35:36 --> Form Validation Class Initialized
INFO - 2017-09-18 12:35:36 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:35:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:35:36 --> Helper loaded: url_helper
INFO - 2017-09-18 12:35:36 --> Model Class Initialized
INFO - 2017-09-18 12:35:36 --> Model Class Initialized
INFO - 2017-09-18 12:35:36 --> Model Class Initialized
DEBUG - 2017-09-18 16:05:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:05:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:35:41 --> Config Class Initialized
INFO - 2017-09-18 12:35:41 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:35:41 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:35:41 --> Utf8 Class Initialized
INFO - 2017-09-18 12:35:41 --> URI Class Initialized
INFO - 2017-09-18 12:35:41 --> Router Class Initialized
INFO - 2017-09-18 12:35:41 --> Output Class Initialized
INFO - 2017-09-18 12:35:41 --> Security Class Initialized
DEBUG - 2017-09-18 12:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:35:41 --> Input Class Initialized
INFO - 2017-09-18 12:35:41 --> Language Class Initialized
INFO - 2017-09-18 12:35:41 --> Loader Class Initialized
INFO - 2017-09-18 12:35:41 --> Helper loaded: common_helper
INFO - 2017-09-18 12:35:41 --> Database Driver Class Initialized
INFO - 2017-09-18 12:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:35:41 --> Email Class Initialized
INFO - 2017-09-18 12:35:41 --> Controller Class Initialized
INFO - 2017-09-18 12:35:41 --> Helper loaded: form_helper
INFO - 2017-09-18 12:35:41 --> Form Validation Class Initialized
INFO - 2017-09-18 12:35:41 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:35:41 --> Helper loaded: url_helper
INFO - 2017-09-18 12:35:41 --> Model Class Initialized
INFO - 2017-09-18 12:35:41 --> Model Class Initialized
INFO - 2017-09-18 12:35:41 --> Model Class Initialized
DEBUG - 2017-09-18 16:05:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:05:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:35:44 --> Config Class Initialized
INFO - 2017-09-18 12:35:44 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:35:44 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:35:44 --> Utf8 Class Initialized
INFO - 2017-09-18 12:35:44 --> URI Class Initialized
INFO - 2017-09-18 12:35:44 --> Router Class Initialized
INFO - 2017-09-18 12:35:44 --> Output Class Initialized
INFO - 2017-09-18 12:35:44 --> Security Class Initialized
DEBUG - 2017-09-18 12:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:35:44 --> Input Class Initialized
INFO - 2017-09-18 12:35:44 --> Language Class Initialized
INFO - 2017-09-18 12:35:44 --> Loader Class Initialized
INFO - 2017-09-18 12:35:44 --> Helper loaded: common_helper
INFO - 2017-09-18 12:35:44 --> Database Driver Class Initialized
INFO - 2017-09-18 12:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:35:44 --> Email Class Initialized
INFO - 2017-09-18 12:35:44 --> Controller Class Initialized
INFO - 2017-09-18 12:35:44 --> Helper loaded: form_helper
INFO - 2017-09-18 12:35:44 --> Form Validation Class Initialized
INFO - 2017-09-18 12:35:44 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:35:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:35:44 --> Helper loaded: url_helper
INFO - 2017-09-18 12:35:44 --> Model Class Initialized
INFO - 2017-09-18 12:35:44 --> Model Class Initialized
INFO - 2017-09-18 12:35:44 --> Model Class Initialized
INFO - 2017-09-18 16:05:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:05:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:05:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:05:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:05:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:05:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:05:44 --> Final output sent to browser
DEBUG - 2017-09-18 16:05:44 --> Total execution time: 0.0514
INFO - 2017-09-18 12:36:10 --> Config Class Initialized
INFO - 2017-09-18 12:36:10 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:36:10 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:36:10 --> Utf8 Class Initialized
INFO - 2017-09-18 12:36:10 --> URI Class Initialized
INFO - 2017-09-18 12:36:10 --> Router Class Initialized
INFO - 2017-09-18 12:36:10 --> Output Class Initialized
INFO - 2017-09-18 12:36:10 --> Security Class Initialized
DEBUG - 2017-09-18 12:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:36:10 --> Input Class Initialized
INFO - 2017-09-18 12:36:10 --> Language Class Initialized
INFO - 2017-09-18 12:36:10 --> Loader Class Initialized
INFO - 2017-09-18 12:36:10 --> Helper loaded: common_helper
INFO - 2017-09-18 12:36:10 --> Database Driver Class Initialized
INFO - 2017-09-18 12:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:36:10 --> Email Class Initialized
INFO - 2017-09-18 12:36:10 --> Controller Class Initialized
INFO - 2017-09-18 12:36:10 --> Helper loaded: form_helper
INFO - 2017-09-18 12:36:10 --> Form Validation Class Initialized
INFO - 2017-09-18 12:36:10 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:36:10 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:36:10 --> Helper loaded: url_helper
INFO - 2017-09-18 12:36:10 --> Model Class Initialized
INFO - 2017-09-18 12:36:10 --> Model Class Initialized
INFO - 2017-09-18 12:36:10 --> Model Class Initialized
INFO - 2017-09-18 16:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:06:10 --> Final output sent to browser
DEBUG - 2017-09-18 16:06:10 --> Total execution time: 0.0514
INFO - 2017-09-18 12:36:25 --> Config Class Initialized
INFO - 2017-09-18 12:36:25 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:36:25 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:36:25 --> Utf8 Class Initialized
INFO - 2017-09-18 12:36:25 --> URI Class Initialized
INFO - 2017-09-18 12:36:25 --> Router Class Initialized
INFO - 2017-09-18 12:36:25 --> Output Class Initialized
INFO - 2017-09-18 12:36:25 --> Security Class Initialized
DEBUG - 2017-09-18 12:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:36:25 --> Input Class Initialized
INFO - 2017-09-18 12:36:25 --> Language Class Initialized
INFO - 2017-09-18 12:36:25 --> Loader Class Initialized
INFO - 2017-09-18 12:36:25 --> Helper loaded: common_helper
INFO - 2017-09-18 12:36:25 --> Database Driver Class Initialized
INFO - 2017-09-18 12:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:36:25 --> Email Class Initialized
INFO - 2017-09-18 12:36:25 --> Controller Class Initialized
INFO - 2017-09-18 12:36:25 --> Helper loaded: form_helper
INFO - 2017-09-18 12:36:25 --> Form Validation Class Initialized
INFO - 2017-09-18 12:36:25 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:36:25 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:36:25 --> Helper loaded: url_helper
INFO - 2017-09-18 12:36:25 --> Model Class Initialized
INFO - 2017-09-18 12:36:25 --> Model Class Initialized
INFO - 2017-09-18 12:36:25 --> Model Class Initialized
DEBUG - 2017-09-18 16:06:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:06:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:37:37 --> Config Class Initialized
INFO - 2017-09-18 12:37:37 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:37:37 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:37:37 --> Utf8 Class Initialized
INFO - 2017-09-18 12:37:37 --> URI Class Initialized
INFO - 2017-09-18 12:37:37 --> Router Class Initialized
INFO - 2017-09-18 12:37:37 --> Output Class Initialized
INFO - 2017-09-18 12:37:37 --> Security Class Initialized
DEBUG - 2017-09-18 12:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:37:37 --> Input Class Initialized
INFO - 2017-09-18 12:37:37 --> Language Class Initialized
INFO - 2017-09-18 12:37:37 --> Loader Class Initialized
INFO - 2017-09-18 12:37:37 --> Helper loaded: common_helper
INFO - 2017-09-18 12:37:37 --> Database Driver Class Initialized
INFO - 2017-09-18 12:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:37:37 --> Email Class Initialized
INFO - 2017-09-18 12:37:37 --> Controller Class Initialized
INFO - 2017-09-18 12:37:37 --> Helper loaded: form_helper
INFO - 2017-09-18 12:37:37 --> Form Validation Class Initialized
INFO - 2017-09-18 12:37:37 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:37:37 --> Helper loaded: url_helper
INFO - 2017-09-18 12:37:37 --> Model Class Initialized
INFO - 2017-09-18 12:37:37 --> Model Class Initialized
INFO - 2017-09-18 12:37:37 --> Model Class Initialized
INFO - 2017-09-18 16:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:07:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:07:37 --> Final output sent to browser
DEBUG - 2017-09-18 16:07:37 --> Total execution time: 0.0529
INFO - 2017-09-18 12:37:50 --> Config Class Initialized
INFO - 2017-09-18 12:37:50 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:37:50 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:37:50 --> Utf8 Class Initialized
INFO - 2017-09-18 12:37:50 --> URI Class Initialized
INFO - 2017-09-18 12:37:50 --> Router Class Initialized
INFO - 2017-09-18 12:37:50 --> Output Class Initialized
INFO - 2017-09-18 12:37:50 --> Security Class Initialized
DEBUG - 2017-09-18 12:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:37:50 --> Input Class Initialized
INFO - 2017-09-18 12:37:50 --> Language Class Initialized
INFO - 2017-09-18 12:37:50 --> Loader Class Initialized
INFO - 2017-09-18 12:37:50 --> Helper loaded: common_helper
INFO - 2017-09-18 12:37:50 --> Database Driver Class Initialized
INFO - 2017-09-18 12:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:37:50 --> Email Class Initialized
INFO - 2017-09-18 12:37:50 --> Controller Class Initialized
INFO - 2017-09-18 12:37:50 --> Helper loaded: form_helper
INFO - 2017-09-18 12:37:50 --> Form Validation Class Initialized
INFO - 2017-09-18 12:37:50 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:37:50 --> Helper loaded: url_helper
INFO - 2017-09-18 12:37:50 --> Model Class Initialized
INFO - 2017-09-18 12:37:50 --> Model Class Initialized
INFO - 2017-09-18 12:37:50 --> Model Class Initialized
DEBUG - 2017-09-18 16:07:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:07:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:41:06 --> Config Class Initialized
INFO - 2017-09-18 12:41:06 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:41:06 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:41:06 --> Utf8 Class Initialized
INFO - 2017-09-18 12:41:06 --> URI Class Initialized
INFO - 2017-09-18 12:41:06 --> Router Class Initialized
INFO - 2017-09-18 12:41:06 --> Output Class Initialized
INFO - 2017-09-18 12:41:06 --> Security Class Initialized
DEBUG - 2017-09-18 12:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:41:06 --> Input Class Initialized
INFO - 2017-09-18 12:41:06 --> Language Class Initialized
INFO - 2017-09-18 12:41:06 --> Loader Class Initialized
INFO - 2017-09-18 12:41:06 --> Helper loaded: common_helper
INFO - 2017-09-18 12:41:06 --> Database Driver Class Initialized
INFO - 2017-09-18 12:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:41:06 --> Email Class Initialized
INFO - 2017-09-18 12:41:06 --> Controller Class Initialized
INFO - 2017-09-18 12:41:06 --> Helper loaded: form_helper
INFO - 2017-09-18 12:41:06 --> Form Validation Class Initialized
INFO - 2017-09-18 12:41:06 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:41:06 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:41:06 --> Helper loaded: url_helper
INFO - 2017-09-18 12:41:06 --> Model Class Initialized
INFO - 2017-09-18 12:41:06 --> Model Class Initialized
INFO - 2017-09-18 12:41:06 --> Model Class Initialized
INFO - 2017-09-18 16:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:11:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:11:06 --> Final output sent to browser
DEBUG - 2017-09-18 16:11:06 --> Total execution time: 0.0517
INFO - 2017-09-18 12:41:19 --> Config Class Initialized
INFO - 2017-09-18 12:41:19 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:41:19 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:41:19 --> Utf8 Class Initialized
INFO - 2017-09-18 12:41:19 --> URI Class Initialized
INFO - 2017-09-18 12:41:19 --> Router Class Initialized
INFO - 2017-09-18 12:41:19 --> Output Class Initialized
INFO - 2017-09-18 12:41:19 --> Security Class Initialized
DEBUG - 2017-09-18 12:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:41:19 --> Input Class Initialized
INFO - 2017-09-18 12:41:19 --> Language Class Initialized
INFO - 2017-09-18 12:41:19 --> Loader Class Initialized
INFO - 2017-09-18 12:41:19 --> Helper loaded: common_helper
INFO - 2017-09-18 12:41:19 --> Database Driver Class Initialized
INFO - 2017-09-18 12:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:41:19 --> Email Class Initialized
INFO - 2017-09-18 12:41:19 --> Controller Class Initialized
INFO - 2017-09-18 12:41:19 --> Helper loaded: form_helper
INFO - 2017-09-18 12:41:19 --> Form Validation Class Initialized
INFO - 2017-09-18 12:41:19 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:41:19 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:41:19 --> Helper loaded: url_helper
INFO - 2017-09-18 12:41:19 --> Model Class Initialized
INFO - 2017-09-18 12:41:19 --> Model Class Initialized
INFO - 2017-09-18 12:41:19 --> Model Class Initialized
DEBUG - 2017-09-18 16:11:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:11:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:41:46 --> Config Class Initialized
INFO - 2017-09-18 12:41:46 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:41:46 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:41:46 --> Utf8 Class Initialized
INFO - 2017-09-18 12:41:46 --> URI Class Initialized
INFO - 2017-09-18 12:41:46 --> Router Class Initialized
INFO - 2017-09-18 12:41:46 --> Output Class Initialized
INFO - 2017-09-18 12:41:46 --> Security Class Initialized
DEBUG - 2017-09-18 12:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:41:46 --> Input Class Initialized
INFO - 2017-09-18 12:41:46 --> Language Class Initialized
INFO - 2017-09-18 12:41:46 --> Loader Class Initialized
INFO - 2017-09-18 12:41:46 --> Helper loaded: common_helper
INFO - 2017-09-18 12:41:46 --> Database Driver Class Initialized
INFO - 2017-09-18 12:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:41:46 --> Email Class Initialized
INFO - 2017-09-18 12:41:46 --> Controller Class Initialized
INFO - 2017-09-18 12:41:46 --> Helper loaded: form_helper
INFO - 2017-09-18 12:41:46 --> Form Validation Class Initialized
INFO - 2017-09-18 12:41:46 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:41:46 --> Helper loaded: url_helper
INFO - 2017-09-18 12:41:46 --> Model Class Initialized
INFO - 2017-09-18 12:41:46 --> Model Class Initialized
INFO - 2017-09-18 12:41:46 --> Model Class Initialized
INFO - 2017-09-18 16:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:11:46 --> Final output sent to browser
DEBUG - 2017-09-18 16:11:46 --> Total execution time: 0.0549
INFO - 2017-09-18 12:42:23 --> Config Class Initialized
INFO - 2017-09-18 12:42:23 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:42:23 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:42:23 --> Utf8 Class Initialized
INFO - 2017-09-18 12:42:23 --> URI Class Initialized
INFO - 2017-09-18 12:42:23 --> Router Class Initialized
INFO - 2017-09-18 12:42:23 --> Output Class Initialized
INFO - 2017-09-18 12:42:23 --> Security Class Initialized
DEBUG - 2017-09-18 12:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:42:23 --> Input Class Initialized
INFO - 2017-09-18 12:42:23 --> Language Class Initialized
INFO - 2017-09-18 12:42:23 --> Loader Class Initialized
INFO - 2017-09-18 12:42:23 --> Helper loaded: common_helper
INFO - 2017-09-18 12:42:23 --> Database Driver Class Initialized
INFO - 2017-09-18 12:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:42:23 --> Email Class Initialized
INFO - 2017-09-18 12:42:23 --> Controller Class Initialized
INFO - 2017-09-18 12:42:23 --> Helper loaded: form_helper
INFO - 2017-09-18 12:42:23 --> Form Validation Class Initialized
INFO - 2017-09-18 12:42:23 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:42:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:42:23 --> Helper loaded: url_helper
INFO - 2017-09-18 12:42:23 --> Model Class Initialized
INFO - 2017-09-18 12:42:23 --> Model Class Initialized
INFO - 2017-09-18 12:42:23 --> Model Class Initialized
INFO - 2017-09-18 16:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 16:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 16:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 16:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 16:12:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 16:12:23 --> Final output sent to browser
DEBUG - 2017-09-18 16:12:23 --> Total execution time: 0.0515
INFO - 2017-09-18 12:42:33 --> Config Class Initialized
INFO - 2017-09-18 12:42:33 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:42:33 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:42:33 --> Utf8 Class Initialized
INFO - 2017-09-18 12:42:33 --> URI Class Initialized
INFO - 2017-09-18 12:42:33 --> Router Class Initialized
INFO - 2017-09-18 12:42:33 --> Output Class Initialized
INFO - 2017-09-18 12:42:33 --> Security Class Initialized
DEBUG - 2017-09-18 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:42:33 --> Input Class Initialized
INFO - 2017-09-18 12:42:33 --> Language Class Initialized
INFO - 2017-09-18 12:42:33 --> Loader Class Initialized
INFO - 2017-09-18 12:42:33 --> Helper loaded: common_helper
INFO - 2017-09-18 12:42:33 --> Database Driver Class Initialized
INFO - 2017-09-18 12:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:42:33 --> Email Class Initialized
INFO - 2017-09-18 12:42:33 --> Controller Class Initialized
INFO - 2017-09-18 12:42:33 --> Helper loaded: form_helper
INFO - 2017-09-18 12:42:33 --> Form Validation Class Initialized
INFO - 2017-09-18 12:42:33 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:42:33 --> Helper loaded: url_helper
INFO - 2017-09-18 12:42:33 --> Model Class Initialized
INFO - 2017-09-18 12:42:33 --> Model Class Initialized
INFO - 2017-09-18 12:42:33 --> Model Class Initialized
DEBUG - 2017-09-18 16:12:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:12:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 12:43:13 --> Config Class Initialized
INFO - 2017-09-18 12:43:13 --> Hooks Class Initialized
DEBUG - 2017-09-18 12:43:13 --> UTF-8 Support Enabled
INFO - 2017-09-18 12:43:13 --> Utf8 Class Initialized
INFO - 2017-09-18 12:43:13 --> URI Class Initialized
INFO - 2017-09-18 12:43:13 --> Router Class Initialized
INFO - 2017-09-18 12:43:13 --> Output Class Initialized
INFO - 2017-09-18 12:43:13 --> Security Class Initialized
DEBUG - 2017-09-18 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 12:43:13 --> Input Class Initialized
INFO - 2017-09-18 12:43:13 --> Language Class Initialized
INFO - 2017-09-18 12:43:13 --> Loader Class Initialized
INFO - 2017-09-18 12:43:13 --> Helper loaded: common_helper
INFO - 2017-09-18 12:43:13 --> Database Driver Class Initialized
INFO - 2017-09-18 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 12:43:13 --> Email Class Initialized
INFO - 2017-09-18 12:43:13 --> Controller Class Initialized
INFO - 2017-09-18 12:43:13 --> Helper loaded: form_helper
INFO - 2017-09-18 12:43:13 --> Form Validation Class Initialized
INFO - 2017-09-18 12:43:13 --> Helper loaded: email_helper
DEBUG - 2017-09-18 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 12:43:13 --> Helper loaded: url_helper
INFO - 2017-09-18 12:43:13 --> Model Class Initialized
INFO - 2017-09-18 12:43:13 --> Model Class Initialized
INFO - 2017-09-18 12:43:13 --> Model Class Initialized
DEBUG - 2017-09-18 16:13:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 16:13:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 14:42:39 --> Config Class Initialized
INFO - 2017-09-18 14:42:39 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:39 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:39 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:39 --> URI Class Initialized
INFO - 2017-09-18 14:42:39 --> Router Class Initialized
INFO - 2017-09-18 14:42:39 --> Output Class Initialized
INFO - 2017-09-18 14:42:39 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:39 --> Input Class Initialized
INFO - 2017-09-18 14:42:39 --> Language Class Initialized
INFO - 2017-09-18 14:42:39 --> Loader Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:39 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:39 --> Email Class Initialized
INFO - 2017-09-18 14:42:39 --> Controller Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:39 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:39 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> Config Class Initialized
INFO - 2017-09-18 14:42:39 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:39 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:39 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:39 --> URI Class Initialized
INFO - 2017-09-18 14:42:39 --> Router Class Initialized
INFO - 2017-09-18 14:42:39 --> Output Class Initialized
INFO - 2017-09-18 14:42:39 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:39 --> Input Class Initialized
INFO - 2017-09-18 14:42:39 --> Language Class Initialized
INFO - 2017-09-18 14:42:39 --> Loader Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:39 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:39 --> Email Class Initialized
INFO - 2017-09-18 14:42:39 --> Controller Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:39 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:39 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> Config Class Initialized
INFO - 2017-09-18 14:42:39 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:39 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:39 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:39 --> URI Class Initialized
DEBUG - 2017-09-18 14:42:39 --> No URI present. Default controller set.
INFO - 2017-09-18 14:42:39 --> Router Class Initialized
INFO - 2017-09-18 14:42:39 --> Output Class Initialized
INFO - 2017-09-18 14:42:39 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:39 --> Input Class Initialized
INFO - 2017-09-18 14:42:39 --> Language Class Initialized
INFO - 2017-09-18 14:42:39 --> Loader Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:39 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:39 --> Email Class Initialized
INFO - 2017-09-18 14:42:39 --> Controller Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:39 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:39 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:39 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:39 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> Model Class Initialized
INFO - 2017-09-18 14:42:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2017-09-18 14:42:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 14:42:39 --> Final output sent to browser
DEBUG - 2017-09-18 14:42:39 --> Total execution time: 0.0437
INFO - 2017-09-18 14:42:41 --> Config Class Initialized
INFO - 2017-09-18 14:42:41 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:41 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:41 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:41 --> URI Class Initialized
DEBUG - 2017-09-18 14:42:41 --> No URI present. Default controller set.
INFO - 2017-09-18 14:42:41 --> Router Class Initialized
INFO - 2017-09-18 14:42:41 --> Output Class Initialized
INFO - 2017-09-18 14:42:41 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:41 --> Input Class Initialized
INFO - 2017-09-18 14:42:41 --> Language Class Initialized
INFO - 2017-09-18 14:42:41 --> Loader Class Initialized
INFO - 2017-09-18 14:42:41 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:41 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:41 --> Email Class Initialized
INFO - 2017-09-18 14:42:41 --> Controller Class Initialized
INFO - 2017-09-18 14:42:41 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:41 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:41 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:41 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:41 --> Model Class Initialized
INFO - 2017-09-18 14:42:41 --> Model Class Initialized
DEBUG - 2017-09-18 14:42:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2017-09-18 14:42:41 --> Config Class Initialized
INFO - 2017-09-18 14:42:41 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:41 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:41 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:41 --> URI Class Initialized
INFO - 2017-09-18 14:42:41 --> Router Class Initialized
INFO - 2017-09-18 14:42:41 --> Output Class Initialized
INFO - 2017-09-18 14:42:41 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:41 --> Input Class Initialized
INFO - 2017-09-18 14:42:41 --> Language Class Initialized
INFO - 2017-09-18 14:42:41 --> Loader Class Initialized
INFO - 2017-09-18 14:42:41 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:41 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:41 --> Email Class Initialized
INFO - 2017-09-18 14:42:41 --> Controller Class Initialized
INFO - 2017-09-18 14:42:41 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:41 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:41 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:41 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:41 --> Model Class Initialized
INFO - 2017-09-18 14:42:41 --> Model Class Initialized
INFO - 2017-09-18 14:42:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 14:42:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 14:42:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-09-18 14:42:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 14:42:41 --> Final output sent to browser
DEBUG - 2017-09-18 14:42:41 --> Total execution time: 0.0543
INFO - 2017-09-18 14:42:51 --> Config Class Initialized
INFO - 2017-09-18 14:42:51 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:51 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:51 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:51 --> URI Class Initialized
INFO - 2017-09-18 14:42:51 --> Router Class Initialized
INFO - 2017-09-18 14:42:51 --> Output Class Initialized
INFO - 2017-09-18 14:42:51 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:51 --> Input Class Initialized
INFO - 2017-09-18 14:42:51 --> Language Class Initialized
INFO - 2017-09-18 14:42:51 --> Loader Class Initialized
INFO - 2017-09-18 14:42:51 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:51 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:51 --> Email Class Initialized
INFO - 2017-09-18 14:42:51 --> Controller Class Initialized
INFO - 2017-09-18 14:42:51 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:51 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:51 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:51 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:51 --> Model Class Initialized
INFO - 2017-09-18 14:42:51 --> Model Class Initialized
INFO - 2017-09-18 14:42:51 --> Model Class Initialized
INFO - 2017-09-18 18:12:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 18:12:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 18:12:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-09-18 18:12:51 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-09-18 18:12:51 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-09-18 18:12:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-09-18 18:12:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 18:12:51 --> Final output sent to browser
DEBUG - 2017-09-18 18:12:51 --> Total execution time: 0.2558
INFO - 2017-09-18 14:42:52 --> Config Class Initialized
INFO - 2017-09-18 14:42:52 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:42:52 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:42:52 --> Utf8 Class Initialized
INFO - 2017-09-18 14:42:52 --> URI Class Initialized
INFO - 2017-09-18 14:42:52 --> Router Class Initialized
INFO - 2017-09-18 14:42:52 --> Output Class Initialized
INFO - 2017-09-18 14:42:52 --> Security Class Initialized
DEBUG - 2017-09-18 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:42:52 --> Input Class Initialized
INFO - 2017-09-18 14:42:52 --> Language Class Initialized
INFO - 2017-09-18 14:42:52 --> Loader Class Initialized
INFO - 2017-09-18 14:42:52 --> Helper loaded: common_helper
INFO - 2017-09-18 14:42:52 --> Database Driver Class Initialized
INFO - 2017-09-18 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:42:52 --> Email Class Initialized
INFO - 2017-09-18 14:42:52 --> Controller Class Initialized
INFO - 2017-09-18 14:42:52 --> Helper loaded: form_helper
INFO - 2017-09-18 14:42:52 --> Form Validation Class Initialized
INFO - 2017-09-18 14:42:52 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:42:52 --> Helper loaded: url_helper
INFO - 2017-09-18 14:42:52 --> Model Class Initialized
INFO - 2017-09-18 14:42:52 --> Model Class Initialized
INFO - 2017-09-18 14:42:52 --> Model Class Initialized
INFO - 2017-09-18 18:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-09-18 18:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-09-18 18:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 18:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2017-09-18 18:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-09-18 18:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-09-18 18:12:52 --> Final output sent to browser
DEBUG - 2017-09-18 18:12:52 --> Total execution time: 0.0534
INFO - 2017-09-18 14:43:12 --> Config Class Initialized
INFO - 2017-09-18 14:43:12 --> Hooks Class Initialized
DEBUG - 2017-09-18 14:43:12 --> UTF-8 Support Enabled
INFO - 2017-09-18 14:43:12 --> Utf8 Class Initialized
INFO - 2017-09-18 14:43:12 --> URI Class Initialized
INFO - 2017-09-18 14:43:12 --> Router Class Initialized
INFO - 2017-09-18 14:43:12 --> Output Class Initialized
INFO - 2017-09-18 14:43:12 --> Security Class Initialized
DEBUG - 2017-09-18 14:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-09-18 14:43:12 --> Input Class Initialized
INFO - 2017-09-18 14:43:12 --> Language Class Initialized
INFO - 2017-09-18 14:43:12 --> Loader Class Initialized
INFO - 2017-09-18 14:43:12 --> Helper loaded: common_helper
INFO - 2017-09-18 14:43:12 --> Database Driver Class Initialized
INFO - 2017-09-18 14:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-09-18 14:43:12 --> Email Class Initialized
INFO - 2017-09-18 14:43:12 --> Controller Class Initialized
INFO - 2017-09-18 14:43:12 --> Helper loaded: form_helper
INFO - 2017-09-18 14:43:12 --> Form Validation Class Initialized
INFO - 2017-09-18 14:43:12 --> Helper loaded: email_helper
DEBUG - 2017-09-18 14:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-09-18 14:43:12 --> Helper loaded: url_helper
INFO - 2017-09-18 14:43:12 --> Model Class Initialized
INFO - 2017-09-18 14:43:12 --> Model Class Initialized
INFO - 2017-09-18 14:43:12 --> Model Class Initialized
DEBUG - 2017-09-18 18:13:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2017-09-18 18:13:12 --> Language file loaded: language/english/form_validation_lang.php
