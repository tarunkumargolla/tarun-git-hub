<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2017-11-15 08:42:21 --> Config Class Initialized
INFO - 2017-11-15 08:42:21 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:21 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:21 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:21 --> URI Class Initialized
DEBUG - 2017-11-15 08:42:21 --> No URI present. Default controller set.
INFO - 2017-11-15 08:42:21 --> Router Class Initialized
INFO - 2017-11-15 08:42:21 --> Output Class Initialized
INFO - 2017-11-15 08:42:21 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:21 --> Input Class Initialized
INFO - 2017-11-15 08:42:21 --> Language Class Initialized
INFO - 2017-11-15 08:42:22 --> Loader Class Initialized
INFO - 2017-11-15 08:42:22 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:22 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:22 --> Email Class Initialized
INFO - 2017-11-15 08:42:22 --> Controller Class Initialized
INFO - 2017-11-15 08:42:22 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:22 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:22 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:22 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:22 --> Model Class Initialized
INFO - 2017-11-15 08:42:22 --> Model Class Initialized
INFO - 2017-11-15 08:42:22 --> Config Class Initialized
INFO - 2017-11-15 08:42:22 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:22 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:22 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:22 --> URI Class Initialized
INFO - 2017-11-15 08:42:22 --> Router Class Initialized
INFO - 2017-11-15 08:42:22 --> Output Class Initialized
INFO - 2017-11-15 08:42:22 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:22 --> Input Class Initialized
INFO - 2017-11-15 08:42:22 --> Language Class Initialized
INFO - 2017-11-15 08:42:22 --> Loader Class Initialized
INFO - 2017-11-15 08:42:22 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:22 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:22 --> Email Class Initialized
INFO - 2017-11-15 08:42:22 --> Controller Class Initialized
INFO - 2017-11-15 08:42:22 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:22 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:22 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:22 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:22 --> Model Class Initialized
INFO - 2017-11-15 08:42:22 --> Model Class Initialized
INFO - 2017-11-15 08:42:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 08:42:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 08:42:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2017-11-15 08:42:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 08:42:23 --> Final output sent to browser
DEBUG - 2017-11-15 08:42:23 --> Total execution time: 0.4274
INFO - 2017-11-15 08:42:32 --> Config Class Initialized
INFO - 2017-11-15 08:42:32 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:32 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:32 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:32 --> URI Class Initialized
INFO - 2017-11-15 08:42:32 --> Router Class Initialized
INFO - 2017-11-15 08:42:32 --> Output Class Initialized
INFO - 2017-11-15 08:42:32 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:32 --> Input Class Initialized
INFO - 2017-11-15 08:42:32 --> Language Class Initialized
INFO - 2017-11-15 08:42:32 --> Loader Class Initialized
INFO - 2017-11-15 08:42:32 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:32 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:32 --> Email Class Initialized
INFO - 2017-11-15 08:42:32 --> Controller Class Initialized
INFO - 2017-11-15 08:42:32 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:32 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:32 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:32 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:32 --> Model Class Initialized
INFO - 2017-11-15 08:42:32 --> Model Class Initialized
INFO - 2017-11-15 08:42:32 --> Model Class Initialized
INFO - 2017-11-15 13:12:32 --> Helper loaded: download_helper
INFO - 2017-11-15 13:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:33 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:33 --> Total execution time: 0.1658
INFO - 2017-11-15 08:42:33 --> Config Class Initialized
INFO - 2017-11-15 08:42:33 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:33 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:33 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:33 --> URI Class Initialized
INFO - 2017-11-15 08:42:33 --> Router Class Initialized
INFO - 2017-11-15 08:42:33 --> Output Class Initialized
INFO - 2017-11-15 08:42:33 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:33 --> Input Class Initialized
INFO - 2017-11-15 08:42:33 --> Language Class Initialized
INFO - 2017-11-15 08:42:33 --> Loader Class Initialized
INFO - 2017-11-15 08:42:33 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:33 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:33 --> Email Class Initialized
INFO - 2017-11-15 08:42:33 --> Controller Class Initialized
INFO - 2017-11-15 08:42:33 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:33 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:33 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:33 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:33 --> Model Class Initialized
INFO - 2017-11-15 08:42:33 --> Model Class Initialized
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-11-15 13:12:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:33 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:33 --> Total execution time: 0.1249
INFO - 2017-11-15 08:42:35 --> Config Class Initialized
INFO - 2017-11-15 08:42:35 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:35 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:35 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:35 --> URI Class Initialized
INFO - 2017-11-15 08:42:35 --> Router Class Initialized
INFO - 2017-11-15 08:42:35 --> Output Class Initialized
INFO - 2017-11-15 08:42:35 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:35 --> Input Class Initialized
INFO - 2017-11-15 08:42:35 --> Language Class Initialized
INFO - 2017-11-15 08:42:35 --> Loader Class Initialized
INFO - 2017-11-15 08:42:35 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:35 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:35 --> Email Class Initialized
INFO - 2017-11-15 08:42:35 --> Controller Class Initialized
INFO - 2017-11-15 08:42:35 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:35 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:35 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:35 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:35 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:35 --> Model Class Initialized
INFO - 2017-11-15 08:42:35 --> Model Class Initialized
INFO - 2017-11-15 08:42:35 --> Model Class Initialized
INFO - 2017-11-15 13:12:35 --> Helper loaded: download_helper
INFO - 2017-11-15 13:12:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-11-15 13:12:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:35 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:35 --> Total execution time: 0.0588
INFO - 2017-11-15 08:42:36 --> Config Class Initialized
INFO - 2017-11-15 08:42:36 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:36 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:36 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:36 --> URI Class Initialized
INFO - 2017-11-15 08:42:36 --> Router Class Initialized
INFO - 2017-11-15 08:42:36 --> Output Class Initialized
INFO - 2017-11-15 08:42:36 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:36 --> Input Class Initialized
INFO - 2017-11-15 08:42:36 --> Language Class Initialized
INFO - 2017-11-15 08:42:36 --> Loader Class Initialized
INFO - 2017-11-15 08:42:36 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:36 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:36 --> Email Class Initialized
INFO - 2017-11-15 08:42:36 --> Controller Class Initialized
INFO - 2017-11-15 08:42:36 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:36 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:36 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:36 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:36 --> Model Class Initialized
INFO - 2017-11-15 08:42:36 --> Model Class Initialized
INFO - 2017-11-15 13:12:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-11-15 13:12:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:36 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:36 --> Total execution time: 0.0638
INFO - 2017-11-15 08:42:36 --> Config Class Initialized
INFO - 2017-11-15 08:42:36 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:36 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:36 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:36 --> URI Class Initialized
INFO - 2017-11-15 08:42:36 --> Router Class Initialized
INFO - 2017-11-15 08:42:36 --> Output Class Initialized
INFO - 2017-11-15 08:42:36 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:36 --> Input Class Initialized
INFO - 2017-11-15 08:42:36 --> Language Class Initialized
INFO - 2017-11-15 08:42:37 --> Loader Class Initialized
INFO - 2017-11-15 08:42:37 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:37 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:37 --> Email Class Initialized
INFO - 2017-11-15 08:42:37 --> Controller Class Initialized
INFO - 2017-11-15 08:42:37 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:37 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:37 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:37 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:37 --> Model Class Initialized
INFO - 2017-11-15 08:42:37 --> Model Class Initialized
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:37 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:37 --> Total execution time: 0.0910
INFO - 2017-11-15 08:42:37 --> Config Class Initialized
INFO - 2017-11-15 08:42:37 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:37 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:37 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:37 --> URI Class Initialized
INFO - 2017-11-15 08:42:37 --> Router Class Initialized
INFO - 2017-11-15 08:42:37 --> Output Class Initialized
INFO - 2017-11-15 08:42:37 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:37 --> Input Class Initialized
INFO - 2017-11-15 08:42:37 --> Language Class Initialized
INFO - 2017-11-15 08:42:37 --> Loader Class Initialized
INFO - 2017-11-15 08:42:37 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:37 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:37 --> Email Class Initialized
INFO - 2017-11-15 08:42:37 --> Controller Class Initialized
INFO - 2017-11-15 08:42:37 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:37 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:37 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:37 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:37 --> Model Class Initialized
INFO - 2017-11-15 08:42:37 --> Model Class Initialized
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-11-15 13:12:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:37 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:37 --> Total execution time: 0.0884
INFO - 2017-11-15 08:42:40 --> Config Class Initialized
INFO - 2017-11-15 08:42:40 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:40 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:40 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:40 --> URI Class Initialized
INFO - 2017-11-15 08:42:40 --> Router Class Initialized
INFO - 2017-11-15 08:42:40 --> Output Class Initialized
INFO - 2017-11-15 08:42:40 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:40 --> Input Class Initialized
INFO - 2017-11-15 08:42:40 --> Language Class Initialized
INFO - 2017-11-15 08:42:40 --> Loader Class Initialized
INFO - 2017-11-15 08:42:40 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:40 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:40 --> Email Class Initialized
INFO - 2017-11-15 08:42:40 --> Controller Class Initialized
INFO - 2017-11-15 08:42:40 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:40 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:40 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:40 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:40 --> Model Class Initialized
INFO - 2017-11-15 08:42:40 --> Model Class Initialized
INFO - 2017-11-15 13:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-11-15 13:12:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:40 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:40 --> Total execution time: 0.0501
INFO - 2017-11-15 08:42:40 --> Config Class Initialized
INFO - 2017-11-15 08:42:40 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:40 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:40 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:40 --> URI Class Initialized
INFO - 2017-11-15 08:42:40 --> Router Class Initialized
INFO - 2017-11-15 08:42:40 --> Output Class Initialized
INFO - 2017-11-15 08:42:40 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:40 --> Input Class Initialized
INFO - 2017-11-15 08:42:40 --> Language Class Initialized
INFO - 2017-11-15 08:42:41 --> Loader Class Initialized
INFO - 2017-11-15 08:42:41 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:41 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:41 --> Email Class Initialized
INFO - 2017-11-15 08:42:41 --> Controller Class Initialized
INFO - 2017-11-15 08:42:41 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:41 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:41 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:41 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:41 --> Model Class Initialized
INFO - 2017-11-15 08:42:41 --> Model Class Initialized
INFO - 2017-11-15 08:42:41 --> Model Class Initialized
INFO - 2017-11-15 13:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:12:41 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:12:41 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-11-15 13:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-11-15 13:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:41 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:41 --> Total execution time: 0.4119
INFO - 2017-11-15 08:42:43 --> Config Class Initialized
INFO - 2017-11-15 08:42:43 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:43 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:43 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:43 --> URI Class Initialized
INFO - 2017-11-15 08:42:43 --> Router Class Initialized
INFO - 2017-11-15 08:42:43 --> Output Class Initialized
INFO - 2017-11-15 08:42:43 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:43 --> Input Class Initialized
INFO - 2017-11-15 08:42:43 --> Language Class Initialized
INFO - 2017-11-15 08:42:43 --> Loader Class Initialized
INFO - 2017-11-15 08:42:43 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:43 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:43 --> Email Class Initialized
INFO - 2017-11-15 08:42:43 --> Controller Class Initialized
INFO - 2017-11-15 08:42:43 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:43 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:43 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:43 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:43 --> Model Class Initialized
INFO - 2017-11-15 08:42:43 --> Model Class Initialized
INFO - 2017-11-15 13:12:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:12:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:43 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:43 --> Total execution time: 0.2269
INFO - 2017-11-15 08:42:50 --> Config Class Initialized
INFO - 2017-11-15 08:42:50 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:50 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:50 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:50 --> URI Class Initialized
INFO - 2017-11-15 08:42:50 --> Router Class Initialized
INFO - 2017-11-15 08:42:50 --> Output Class Initialized
INFO - 2017-11-15 08:42:50 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:50 --> Input Class Initialized
INFO - 2017-11-15 08:42:50 --> Language Class Initialized
INFO - 2017-11-15 08:42:50 --> Loader Class Initialized
INFO - 2017-11-15 08:42:50 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:50 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:50 --> Email Class Initialized
INFO - 2017-11-15 08:42:50 --> Controller Class Initialized
INFO - 2017-11-15 08:42:50 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:50 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:50 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:50 --> Helper loaded: url_helper
INFO - 2017-11-15 13:12:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-11-15 13:12:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:50 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:50 --> Total execution time: 0.1916
INFO - 2017-11-15 08:42:52 --> Config Class Initialized
INFO - 2017-11-15 08:42:52 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:52 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:52 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:52 --> URI Class Initialized
INFO - 2017-11-15 08:42:52 --> Router Class Initialized
INFO - 2017-11-15 08:42:52 --> Output Class Initialized
INFO - 2017-11-15 08:42:52 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:52 --> Input Class Initialized
INFO - 2017-11-15 08:42:52 --> Language Class Initialized
INFO - 2017-11-15 08:42:52 --> Loader Class Initialized
INFO - 2017-11-15 08:42:52 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:52 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:52 --> Email Class Initialized
INFO - 2017-11-15 08:42:52 --> Controller Class Initialized
INFO - 2017-11-15 08:42:52 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:52 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:52 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:52 --> Helper loaded: url_helper
INFO - 2017-11-15 08:42:52 --> Model Class Initialized
INFO - 2017-11-15 08:42:52 --> Model Class Initialized
INFO - 2017-11-15 13:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:12:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:52 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:52 --> Total execution time: 0.0537
INFO - 2017-11-15 08:42:55 --> Config Class Initialized
INFO - 2017-11-15 08:42:55 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:42:55 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:42:55 --> Utf8 Class Initialized
INFO - 2017-11-15 08:42:55 --> URI Class Initialized
INFO - 2017-11-15 08:42:55 --> Router Class Initialized
INFO - 2017-11-15 08:42:55 --> Output Class Initialized
INFO - 2017-11-15 08:42:55 --> Security Class Initialized
DEBUG - 2017-11-15 08:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:42:55 --> Input Class Initialized
INFO - 2017-11-15 08:42:55 --> Language Class Initialized
INFO - 2017-11-15 08:42:55 --> Loader Class Initialized
INFO - 2017-11-15 08:42:55 --> Helper loaded: common_helper
INFO - 2017-11-15 08:42:55 --> Database Driver Class Initialized
INFO - 2017-11-15 08:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:42:55 --> Email Class Initialized
INFO - 2017-11-15 08:42:55 --> Controller Class Initialized
INFO - 2017-11-15 08:42:55 --> Helper loaded: form_helper
INFO - 2017-11-15 08:42:55 --> Form Validation Class Initialized
INFO - 2017-11-15 08:42:55 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:42:55 --> Helper loaded: url_helper
INFO - 2017-11-15 13:12:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:12:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:12:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:12:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-11-15 13:12:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:12:55 --> Final output sent to browser
DEBUG - 2017-11-15 13:12:55 --> Total execution time: 0.0526
INFO - 2017-11-15 08:43:11 --> Config Class Initialized
INFO - 2017-11-15 08:43:11 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:11 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:11 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:11 --> URI Class Initialized
INFO - 2017-11-15 08:43:11 --> Router Class Initialized
INFO - 2017-11-15 08:43:11 --> Output Class Initialized
INFO - 2017-11-15 08:43:11 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:11 --> Input Class Initialized
INFO - 2017-11-15 08:43:11 --> Language Class Initialized
INFO - 2017-11-15 08:43:11 --> Loader Class Initialized
INFO - 2017-11-15 08:43:11 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:11 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:11 --> Email Class Initialized
INFO - 2017-11-15 08:43:11 --> Controller Class Initialized
INFO - 2017-11-15 08:43:11 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:11 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:11 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:11 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:11 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:11 --> Model Class Initialized
INFO - 2017-11-15 08:43:11 --> Model Class Initialized
INFO - 2017-11-15 13:13:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:13:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:11 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:11 --> Total execution time: 0.0551
INFO - 2017-11-15 08:43:12 --> Config Class Initialized
INFO - 2017-11-15 08:43:12 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:12 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:12 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:12 --> URI Class Initialized
INFO - 2017-11-15 08:43:12 --> Router Class Initialized
INFO - 2017-11-15 08:43:12 --> Output Class Initialized
INFO - 2017-11-15 08:43:12 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:12 --> Input Class Initialized
INFO - 2017-11-15 08:43:12 --> Language Class Initialized
INFO - 2017-11-15 08:43:12 --> Loader Class Initialized
INFO - 2017-11-15 08:43:12 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:12 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:12 --> Email Class Initialized
INFO - 2017-11-15 08:43:12 --> Controller Class Initialized
INFO - 2017-11-15 08:43:12 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:12 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:12 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:12 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:12 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:12 --> Model Class Initialized
INFO - 2017-11-15 08:43:12 --> Model Class Initialized
INFO - 2017-11-15 08:43:12 --> Model Class Initialized
INFO - 2017-11-15 13:13:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-11-15 13:13:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-11-15 13:13:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:12 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:12 --> Total execution time: 0.2651
INFO - 2017-11-15 08:43:13 --> Config Class Initialized
INFO - 2017-11-15 08:43:13 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:13 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:13 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:13 --> URI Class Initialized
INFO - 2017-11-15 08:43:13 --> Router Class Initialized
INFO - 2017-11-15 08:43:13 --> Output Class Initialized
INFO - 2017-11-15 08:43:13 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:13 --> Input Class Initialized
INFO - 2017-11-15 08:43:13 --> Language Class Initialized
INFO - 2017-11-15 08:43:13 --> Loader Class Initialized
INFO - 2017-11-15 08:43:13 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:13 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:13 --> Email Class Initialized
INFO - 2017-11-15 08:43:13 --> Controller Class Initialized
INFO - 2017-11-15 08:43:13 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:13 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:13 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:13 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:13 --> Model Class Initialized
INFO - 2017-11-15 08:43:13 --> Model Class Initialized
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:13 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:13 --> Total execution time: 0.0603
INFO - 2017-11-15 08:43:13 --> Config Class Initialized
INFO - 2017-11-15 08:43:13 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:13 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:13 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:13 --> URI Class Initialized
INFO - 2017-11-15 08:43:13 --> Router Class Initialized
INFO - 2017-11-15 08:43:13 --> Output Class Initialized
INFO - 2017-11-15 08:43:13 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:13 --> Input Class Initialized
INFO - 2017-11-15 08:43:13 --> Language Class Initialized
INFO - 2017-11-15 08:43:13 --> Loader Class Initialized
INFO - 2017-11-15 08:43:13 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:13 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:13 --> Email Class Initialized
INFO - 2017-11-15 08:43:13 --> Controller Class Initialized
INFO - 2017-11-15 08:43:13 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:13 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:13 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:13 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:13 --> Model Class Initialized
INFO - 2017-11-15 08:43:13 --> Model Class Initialized
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2017-11-15 13:13:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:13 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:13 --> Total execution time: 0.0554
INFO - 2017-11-15 08:43:14 --> Config Class Initialized
INFO - 2017-11-15 08:43:14 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:14 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:14 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:14 --> URI Class Initialized
INFO - 2017-11-15 08:43:14 --> Router Class Initialized
INFO - 2017-11-15 08:43:14 --> Output Class Initialized
INFO - 2017-11-15 08:43:14 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:14 --> Input Class Initialized
INFO - 2017-11-15 08:43:14 --> Language Class Initialized
INFO - 2017-11-15 08:43:14 --> Loader Class Initialized
INFO - 2017-11-15 08:43:14 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:14 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:14 --> Email Class Initialized
INFO - 2017-11-15 08:43:14 --> Controller Class Initialized
INFO - 2017-11-15 08:43:14 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:14 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:14 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:14 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:14 --> Model Class Initialized
INFO - 2017-11-15 08:43:14 --> Model Class Initialized
INFO - 2017-11-15 08:43:14 --> Model Class Initialized
INFO - 2017-11-15 13:13:14 --> Helper loaded: download_helper
INFO - 2017-11-15 13:13:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2017-11-15 13:13:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:14 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:14 --> Total execution time: 0.0573
INFO - 2017-11-15 08:43:42 --> Config Class Initialized
INFO - 2017-11-15 08:43:42 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:42 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:42 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:42 --> URI Class Initialized
INFO - 2017-11-15 08:43:42 --> Router Class Initialized
INFO - 2017-11-15 08:43:42 --> Output Class Initialized
INFO - 2017-11-15 08:43:42 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:42 --> Input Class Initialized
INFO - 2017-11-15 08:43:42 --> Language Class Initialized
INFO - 2017-11-15 08:43:42 --> Loader Class Initialized
INFO - 2017-11-15 08:43:42 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:42 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:42 --> Email Class Initialized
INFO - 2017-11-15 08:43:42 --> Controller Class Initialized
INFO - 2017-11-15 08:43:42 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:42 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:42 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:42 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:42 --> Model Class Initialized
INFO - 2017-11-15 08:43:42 --> Model Class Initialized
INFO - 2017-11-15 13:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:13:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:42 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:42 --> Total execution time: 0.0610
INFO - 2017-11-15 08:43:43 --> Config Class Initialized
INFO - 2017-11-15 08:43:43 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:43 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:43 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:43 --> URI Class Initialized
INFO - 2017-11-15 08:43:43 --> Router Class Initialized
INFO - 2017-11-15 08:43:43 --> Output Class Initialized
INFO - 2017-11-15 08:43:43 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:43 --> Input Class Initialized
INFO - 2017-11-15 08:43:43 --> Language Class Initialized
INFO - 2017-11-15 08:43:43 --> Loader Class Initialized
INFO - 2017-11-15 08:43:43 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:43 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:43 --> Email Class Initialized
INFO - 2017-11-15 08:43:43 --> Controller Class Initialized
INFO - 2017-11-15 08:43:43 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:43 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:43 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:43 --> Helper loaded: url_helper
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:43 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:43 --> Total execution time: 0.0469
INFO - 2017-11-15 08:43:43 --> Config Class Initialized
INFO - 2017-11-15 08:43:43 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:43 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:43 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:43 --> URI Class Initialized
INFO - 2017-11-15 08:43:43 --> Router Class Initialized
INFO - 2017-11-15 08:43:43 --> Output Class Initialized
INFO - 2017-11-15 08:43:43 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:43 --> Input Class Initialized
INFO - 2017-11-15 08:43:43 --> Language Class Initialized
INFO - 2017-11-15 08:43:43 --> Loader Class Initialized
INFO - 2017-11-15 08:43:43 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:43 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:43 --> Email Class Initialized
INFO - 2017-11-15 08:43:43 --> Controller Class Initialized
INFO - 2017-11-15 08:43:43 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:43 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:43 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:43 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:43 --> Model Class Initialized
INFO - 2017-11-15 08:43:43 --> Model Class Initialized
INFO - 2017-11-15 08:43:43 --> Model Class Initialized
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-11-15 13:13:43 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:43 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:43 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:44 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:44 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:44 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:44 --> Total execution time: 0.2762
INFO - 2017-11-15 08:43:44 --> Config Class Initialized
INFO - 2017-11-15 08:43:44 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:44 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:44 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:44 --> URI Class Initialized
INFO - 2017-11-15 08:43:44 --> Router Class Initialized
INFO - 2017-11-15 08:43:44 --> Output Class Initialized
INFO - 2017-11-15 08:43:44 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:44 --> Input Class Initialized
INFO - 2017-11-15 08:43:44 --> Language Class Initialized
INFO - 2017-11-15 08:43:44 --> Loader Class Initialized
INFO - 2017-11-15 08:43:44 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:44 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:44 --> Email Class Initialized
INFO - 2017-11-15 08:43:44 --> Controller Class Initialized
INFO - 2017-11-15 08:43:44 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:44 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:44 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:44 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:44 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:44 --> Model Class Initialized
INFO - 2017-11-15 08:43:44 --> Model Class Initialized
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-11-15 13:13:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:44 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:44 --> Total execution time: 0.0598
INFO - 2017-11-15 08:43:51 --> Config Class Initialized
INFO - 2017-11-15 08:43:51 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:51 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:51 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:51 --> URI Class Initialized
INFO - 2017-11-15 08:43:51 --> Router Class Initialized
INFO - 2017-11-15 08:43:51 --> Output Class Initialized
INFO - 2017-11-15 08:43:51 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:51 --> Input Class Initialized
INFO - 2017-11-15 08:43:51 --> Language Class Initialized
INFO - 2017-11-15 08:43:51 --> Loader Class Initialized
INFO - 2017-11-15 08:43:51 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:51 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:51 --> Email Class Initialized
INFO - 2017-11-15 08:43:51 --> Controller Class Initialized
INFO - 2017-11-15 08:43:51 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:51 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:51 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:51 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:51 --> Model Class Initialized
INFO - 2017-11-15 08:43:51 --> Model Class Initialized
INFO - 2017-11-15 13:13:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:13:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:51 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:51 --> Total execution time: 0.0557
INFO - 2017-11-15 08:43:52 --> Config Class Initialized
INFO - 2017-11-15 08:43:52 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:52 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:52 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:52 --> URI Class Initialized
INFO - 2017-11-15 08:43:52 --> Router Class Initialized
INFO - 2017-11-15 08:43:52 --> Output Class Initialized
INFO - 2017-11-15 08:43:52 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:52 --> Input Class Initialized
INFO - 2017-11-15 08:43:52 --> Language Class Initialized
INFO - 2017-11-15 08:43:52 --> Loader Class Initialized
INFO - 2017-11-15 08:43:52 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:52 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:52 --> Email Class Initialized
INFO - 2017-11-15 08:43:52 --> Controller Class Initialized
INFO - 2017-11-15 08:43:52 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:52 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:52 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:52 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:52 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:52 --> Model Class Initialized
INFO - 2017-11-15 08:43:52 --> Model Class Initialized
INFO - 2017-11-15 08:43:52 --> Model Class Initialized
INFO - 2017-11-15 13:13:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:52 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:52 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-11-15 13:13:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-11-15 13:13:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:52 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:52 --> Total execution time: 0.2530
INFO - 2017-11-15 08:43:53 --> Config Class Initialized
INFO - 2017-11-15 08:43:53 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:53 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:53 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:53 --> URI Class Initialized
INFO - 2017-11-15 08:43:53 --> Router Class Initialized
INFO - 2017-11-15 08:43:53 --> Output Class Initialized
INFO - 2017-11-15 08:43:53 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:53 --> Input Class Initialized
INFO - 2017-11-15 08:43:53 --> Language Class Initialized
INFO - 2017-11-15 08:43:53 --> Loader Class Initialized
INFO - 2017-11-15 08:43:53 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:53 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:53 --> Email Class Initialized
INFO - 2017-11-15 08:43:53 --> Controller Class Initialized
INFO - 2017-11-15 08:43:53 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:53 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:53 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:53 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:53 --> Model Class Initialized
INFO - 2017-11-15 08:43:53 --> Model Class Initialized
INFO - 2017-11-15 13:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-11-15 13:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:53 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:53 --> Total execution time: 0.0538
INFO - 2017-11-15 08:43:54 --> Config Class Initialized
INFO - 2017-11-15 08:43:54 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:54 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:54 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:54 --> URI Class Initialized
INFO - 2017-11-15 08:43:54 --> Router Class Initialized
INFO - 2017-11-15 08:43:54 --> Output Class Initialized
INFO - 2017-11-15 08:43:54 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:54 --> Input Class Initialized
INFO - 2017-11-15 08:43:54 --> Language Class Initialized
INFO - 2017-11-15 08:43:54 --> Loader Class Initialized
INFO - 2017-11-15 08:43:54 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:54 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:54 --> Email Class Initialized
INFO - 2017-11-15 08:43:54 --> Controller Class Initialized
INFO - 2017-11-15 08:43:54 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:54 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:54 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:54 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:54 --> Model Class Initialized
INFO - 2017-11-15 08:43:54 --> Model Class Initialized
INFO - 2017-11-15 13:13:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:13:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:54 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:54 --> Total execution time: 0.0555
INFO - 2017-11-15 08:43:56 --> Config Class Initialized
INFO - 2017-11-15 08:43:56 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:56 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:56 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:56 --> URI Class Initialized
INFO - 2017-11-15 08:43:56 --> Router Class Initialized
INFO - 2017-11-15 08:43:56 --> Output Class Initialized
INFO - 2017-11-15 08:43:56 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:56 --> Input Class Initialized
INFO - 2017-11-15 08:43:56 --> Language Class Initialized
INFO - 2017-11-15 08:43:56 --> Loader Class Initialized
INFO - 2017-11-15 08:43:56 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:56 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:56 --> Email Class Initialized
INFO - 2017-11-15 08:43:56 --> Controller Class Initialized
INFO - 2017-11-15 08:43:56 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:56 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:56 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:56 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:56 --> Model Class Initialized
INFO - 2017-11-15 08:43:56 --> Model Class Initialized
INFO - 2017-11-15 08:43:56 --> Model Class Initialized
INFO - 2017-11-15 13:13:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2017-11-15 13:13:56 --> Undefined property: stdClass::$hospitalImage
ERROR - 2017-11-15 13:13:56 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2017-11-15 13:13:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2017-11-15 13:13:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:56 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:56 --> Total execution time: 0.3046
INFO - 2017-11-15 08:43:56 --> Config Class Initialized
INFO - 2017-11-15 08:43:56 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:56 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:56 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:56 --> URI Class Initialized
INFO - 2017-11-15 08:43:56 --> Router Class Initialized
INFO - 2017-11-15 08:43:56 --> Output Class Initialized
INFO - 2017-11-15 08:43:56 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:56 --> Input Class Initialized
INFO - 2017-11-15 08:43:56 --> Language Class Initialized
INFO - 2017-11-15 08:43:56 --> Loader Class Initialized
INFO - 2017-11-15 08:43:56 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:57 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:57 --> Email Class Initialized
INFO - 2017-11-15 08:43:57 --> Controller Class Initialized
INFO - 2017-11-15 08:43:57 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:57 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:57 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:57 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:57 --> Model Class Initialized
INFO - 2017-11-15 08:43:57 --> Model Class Initialized
INFO - 2017-11-15 13:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2017-11-15 13:13:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:57 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:57 --> Total execution time: 0.0577
INFO - 2017-11-15 08:43:58 --> Config Class Initialized
INFO - 2017-11-15 08:43:58 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:43:58 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:43:58 --> Utf8 Class Initialized
INFO - 2017-11-15 08:43:58 --> URI Class Initialized
INFO - 2017-11-15 08:43:58 --> Router Class Initialized
INFO - 2017-11-15 08:43:58 --> Output Class Initialized
INFO - 2017-11-15 08:43:58 --> Security Class Initialized
DEBUG - 2017-11-15 08:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:43:58 --> Input Class Initialized
INFO - 2017-11-15 08:43:58 --> Language Class Initialized
INFO - 2017-11-15 08:43:58 --> Loader Class Initialized
INFO - 2017-11-15 08:43:58 --> Helper loaded: common_helper
INFO - 2017-11-15 08:43:58 --> Database Driver Class Initialized
INFO - 2017-11-15 08:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:43:58 --> Email Class Initialized
INFO - 2017-11-15 08:43:58 --> Controller Class Initialized
INFO - 2017-11-15 08:43:58 --> Helper loaded: form_helper
INFO - 2017-11-15 08:43:58 --> Form Validation Class Initialized
INFO - 2017-11-15 08:43:58 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:43:58 --> Helper loaded: url_helper
INFO - 2017-11-15 08:43:58 --> Model Class Initialized
INFO - 2017-11-15 08:43:58 --> Model Class Initialized
INFO - 2017-11-15 13:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:13:58 --> Final output sent to browser
DEBUG - 2017-11-15 13:13:58 --> Total execution time: 0.0544
INFO - 2017-11-15 08:44:00 --> Config Class Initialized
INFO - 2017-11-15 08:44:00 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:00 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:00 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:00 --> URI Class Initialized
INFO - 2017-11-15 08:44:00 --> Router Class Initialized
INFO - 2017-11-15 08:44:00 --> Output Class Initialized
INFO - 2017-11-15 08:44:00 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:00 --> Input Class Initialized
INFO - 2017-11-15 08:44:00 --> Language Class Initialized
INFO - 2017-11-15 08:44:00 --> Loader Class Initialized
INFO - 2017-11-15 08:44:00 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:00 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:00 --> Email Class Initialized
INFO - 2017-11-15 08:44:00 --> Controller Class Initialized
INFO - 2017-11-15 08:44:00 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:00 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:00 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:00 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:00 --> Model Class Initialized
INFO - 2017-11-15 08:44:00 --> Model Class Initialized
INFO - 2017-11-15 13:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:14:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:14:00 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:00 --> Total execution time: 0.0582
INFO - 2017-11-15 08:44:13 --> Config Class Initialized
INFO - 2017-11-15 08:44:13 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:13 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:13 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:13 --> URI Class Initialized
INFO - 2017-11-15 08:44:13 --> Router Class Initialized
INFO - 2017-11-15 08:44:13 --> Output Class Initialized
INFO - 2017-11-15 08:44:13 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:13 --> Input Class Initialized
INFO - 2017-11-15 08:44:13 --> Language Class Initialized
INFO - 2017-11-15 08:44:13 --> Loader Class Initialized
INFO - 2017-11-15 08:44:13 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:13 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:13 --> Email Class Initialized
INFO - 2017-11-15 08:44:13 --> Controller Class Initialized
INFO - 2017-11-15 08:44:13 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:13 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:13 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:13 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:13 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:13 --> Model Class Initialized
INFO - 2017-11-15 08:44:13 --> Model Class Initialized
INFO - 2017-11-15 13:14:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-11-15 13:14:13 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:13 --> Total execution time: 0.0749
INFO - 2017-11-15 08:44:15 --> Config Class Initialized
INFO - 2017-11-15 08:44:15 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:15 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:15 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:15 --> URI Class Initialized
INFO - 2017-11-15 08:44:15 --> Router Class Initialized
INFO - 2017-11-15 08:44:15 --> Output Class Initialized
INFO - 2017-11-15 08:44:15 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:15 --> Input Class Initialized
INFO - 2017-11-15 08:44:15 --> Language Class Initialized
INFO - 2017-11-15 08:44:15 --> Loader Class Initialized
INFO - 2017-11-15 08:44:15 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:15 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:15 --> Email Class Initialized
INFO - 2017-11-15 08:44:15 --> Controller Class Initialized
INFO - 2017-11-15 08:44:15 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:15 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:15 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:15 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:15 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:15 --> Model Class Initialized
INFO - 2017-11-15 08:44:15 --> Model Class Initialized
INFO - 2017-11-15 13:14:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chat_members_ajax.php
INFO - 2017-11-15 13:14:15 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:15 --> Total execution time: 0.0490
INFO - 2017-11-15 08:44:17 --> Config Class Initialized
INFO - 2017-11-15 08:44:17 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:17 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:17 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:17 --> URI Class Initialized
INFO - 2017-11-15 08:44:17 --> Router Class Initialized
INFO - 2017-11-15 08:44:17 --> Output Class Initialized
INFO - 2017-11-15 08:44:17 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:17 --> Input Class Initialized
INFO - 2017-11-15 08:44:17 --> Language Class Initialized
INFO - 2017-11-15 08:44:17 --> Loader Class Initialized
INFO - 2017-11-15 08:44:17 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:17 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:17 --> Email Class Initialized
INFO - 2017-11-15 08:44:17 --> Controller Class Initialized
INFO - 2017-11-15 08:44:17 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:17 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:17 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:17 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:17 --> Model Class Initialized
INFO - 2017-11-15 08:44:17 --> Model Class Initialized
INFO - 2017-11-15 08:44:23 --> Config Class Initialized
INFO - 2017-11-15 08:44:23 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:23 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:23 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:23 --> URI Class Initialized
INFO - 2017-11-15 08:44:23 --> Router Class Initialized
INFO - 2017-11-15 08:44:23 --> Output Class Initialized
INFO - 2017-11-15 08:44:23 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:23 --> Input Class Initialized
INFO - 2017-11-15 08:44:23 --> Language Class Initialized
INFO - 2017-11-15 08:44:23 --> Loader Class Initialized
INFO - 2017-11-15 08:44:23 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:23 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:23 --> Email Class Initialized
INFO - 2017-11-15 08:44:23 --> Controller Class Initialized
INFO - 2017-11-15 08:44:23 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:23 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:23 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:23 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:23 --> Model Class Initialized
INFO - 2017-11-15 08:44:23 --> Model Class Initialized
INFO - 2017-11-15 13:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:14:23 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:23 --> Total execution time: 0.0638
INFO - 2017-11-15 08:44:32 --> Config Class Initialized
INFO - 2017-11-15 08:44:32 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:32 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:32 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:32 --> URI Class Initialized
INFO - 2017-11-15 08:44:32 --> Router Class Initialized
INFO - 2017-11-15 08:44:32 --> Output Class Initialized
INFO - 2017-11-15 08:44:32 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:32 --> Input Class Initialized
INFO - 2017-11-15 08:44:32 --> Language Class Initialized
INFO - 2017-11-15 08:44:32 --> Loader Class Initialized
INFO - 2017-11-15 08:44:32 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:32 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:32 --> Email Class Initialized
INFO - 2017-11-15 08:44:32 --> Controller Class Initialized
INFO - 2017-11-15 08:44:32 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:32 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:32 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:32 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:32 --> Model Class Initialized
INFO - 2017-11-15 08:44:32 --> Model Class Initialized
INFO - 2017-11-15 13:14:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:14:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:14:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:14:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:14:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:14:32 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:32 --> Total execution time: 0.0578
INFO - 2017-11-15 08:44:37 --> Config Class Initialized
INFO - 2017-11-15 08:44:37 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:37 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:37 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:37 --> URI Class Initialized
INFO - 2017-11-15 08:44:37 --> Router Class Initialized
INFO - 2017-11-15 08:44:37 --> Output Class Initialized
INFO - 2017-11-15 08:44:37 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:37 --> Input Class Initialized
INFO - 2017-11-15 08:44:37 --> Language Class Initialized
INFO - 2017-11-15 08:44:37 --> Loader Class Initialized
INFO - 2017-11-15 08:44:37 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:37 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:37 --> Email Class Initialized
INFO - 2017-11-15 08:44:37 --> Controller Class Initialized
INFO - 2017-11-15 08:44:37 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:37 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:37 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:37 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:37 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:37 --> Model Class Initialized
INFO - 2017-11-15 08:44:37 --> Model Class Initialized
INFO - 2017-11-15 13:14:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:14:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:14:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/addPieChartValues.php
INFO - 2017-11-15 13:14:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:14:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:14:37 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:37 --> Total execution time: 0.1973
INFO - 2017-11-15 08:44:41 --> Config Class Initialized
INFO - 2017-11-15 08:44:41 --> Hooks Class Initialized
DEBUG - 2017-11-15 08:44:41 --> UTF-8 Support Enabled
INFO - 2017-11-15 08:44:41 --> Utf8 Class Initialized
INFO - 2017-11-15 08:44:41 --> URI Class Initialized
INFO - 2017-11-15 08:44:41 --> Router Class Initialized
INFO - 2017-11-15 08:44:41 --> Output Class Initialized
INFO - 2017-11-15 08:44:41 --> Security Class Initialized
DEBUG - 2017-11-15 08:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2017-11-15 08:44:41 --> Input Class Initialized
INFO - 2017-11-15 08:44:41 --> Language Class Initialized
INFO - 2017-11-15 08:44:41 --> Loader Class Initialized
INFO - 2017-11-15 08:44:41 --> Helper loaded: common_helper
INFO - 2017-11-15 08:44:41 --> Database Driver Class Initialized
INFO - 2017-11-15 08:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2017-11-15 08:44:41 --> Email Class Initialized
INFO - 2017-11-15 08:44:41 --> Controller Class Initialized
INFO - 2017-11-15 08:44:41 --> Helper loaded: form_helper
INFO - 2017-11-15 08:44:41 --> Form Validation Class Initialized
INFO - 2017-11-15 08:44:41 --> Helper loaded: email_helper
DEBUG - 2017-11-15 08:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2017-11-15 08:44:41 --> Helper loaded: url_helper
INFO - 2017-11-15 08:44:41 --> Model Class Initialized
INFO - 2017-11-15 08:44:41 --> Model Class Initialized
INFO - 2017-11-15 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2017-11-15 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2017-11-15 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2017-11-15 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2017-11-15 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2017-11-15 13:14:41 --> Final output sent to browser
DEBUG - 2017-11-15 13:14:41 --> Total execution time: 0.0551
