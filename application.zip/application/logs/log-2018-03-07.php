<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-07 14:38:36 --> Config Class Initialized
INFO - 2018-03-07 14:38:36 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:38:36 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:38:36 --> Utf8 Class Initialized
INFO - 2018-03-07 14:38:36 --> URI Class Initialized
DEBUG - 2018-03-07 14:38:36 --> No URI present. Default controller set.
INFO - 2018-03-07 14:38:36 --> Router Class Initialized
INFO - 2018-03-07 14:38:36 --> Output Class Initialized
INFO - 2018-03-07 14:38:36 --> Security Class Initialized
DEBUG - 2018-03-07 14:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:38:36 --> Input Class Initialized
INFO - 2018-03-07 14:38:36 --> Language Class Initialized
INFO - 2018-03-07 14:38:36 --> Loader Class Initialized
INFO - 2018-03-07 14:38:36 --> Helper loaded: common_helper
INFO - 2018-03-07 14:38:36 --> Database Driver Class Initialized
INFO - 2018-03-07 14:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:38:36 --> Email Class Initialized
INFO - 2018-03-07 14:38:36 --> Controller Class Initialized
INFO - 2018-03-07 14:38:36 --> Helper loaded: form_helper
INFO - 2018-03-07 14:38:36 --> Form Validation Class Initialized
INFO - 2018-03-07 14:38:37 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:38:37 --> Helper loaded: url_helper
INFO - 2018-03-07 14:38:37 --> Model Class Initialized
INFO - 2018-03-07 14:38:37 --> Model Class Initialized
INFO - 2018-03-07 14:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-07 14:38:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 14:38:37 --> Final output sent to browser
DEBUG - 2018-03-07 14:38:37 --> Total execution time: 0.8777
INFO - 2018-03-07 14:38:51 --> Config Class Initialized
INFO - 2018-03-07 14:38:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:38:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:38:51 --> Utf8 Class Initialized
INFO - 2018-03-07 14:38:51 --> URI Class Initialized
DEBUG - 2018-03-07 14:38:51 --> No URI present. Default controller set.
INFO - 2018-03-07 14:38:51 --> Router Class Initialized
INFO - 2018-03-07 14:38:51 --> Output Class Initialized
INFO - 2018-03-07 14:38:51 --> Security Class Initialized
DEBUG - 2018-03-07 14:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:38:51 --> Input Class Initialized
INFO - 2018-03-07 14:38:51 --> Language Class Initialized
INFO - 2018-03-07 14:38:51 --> Loader Class Initialized
INFO - 2018-03-07 14:38:51 --> Helper loaded: common_helper
INFO - 2018-03-07 14:38:51 --> Database Driver Class Initialized
INFO - 2018-03-07 14:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:38:51 --> Email Class Initialized
INFO - 2018-03-07 14:38:51 --> Controller Class Initialized
INFO - 2018-03-07 14:38:51 --> Helper loaded: form_helper
INFO - 2018-03-07 14:38:51 --> Form Validation Class Initialized
INFO - 2018-03-07 14:38:51 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:38:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:38:51 --> Helper loaded: url_helper
INFO - 2018-03-07 14:38:51 --> Model Class Initialized
INFO - 2018-03-07 14:38:51 --> Model Class Initialized
DEBUG - 2018-03-07 14:38:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:38:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 14:38:51 --> Config Class Initialized
INFO - 2018-03-07 14:38:51 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:38:51 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:38:51 --> Utf8 Class Initialized
INFO - 2018-03-07 14:38:51 --> URI Class Initialized
INFO - 2018-03-07 14:38:51 --> Router Class Initialized
INFO - 2018-03-07 14:38:51 --> Output Class Initialized
INFO - 2018-03-07 14:38:51 --> Security Class Initialized
DEBUG - 2018-03-07 14:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:38:51 --> Input Class Initialized
INFO - 2018-03-07 14:38:51 --> Language Class Initialized
INFO - 2018-03-07 14:38:52 --> Loader Class Initialized
INFO - 2018-03-07 14:38:52 --> Helper loaded: common_helper
INFO - 2018-03-07 14:38:52 --> Database Driver Class Initialized
INFO - 2018-03-07 14:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:38:52 --> Email Class Initialized
INFO - 2018-03-07 14:38:52 --> Controller Class Initialized
INFO - 2018-03-07 14:38:52 --> Helper loaded: form_helper
INFO - 2018-03-07 14:38:52 --> Form Validation Class Initialized
INFO - 2018-03-07 14:38:52 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:38:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:38:52 --> Helper loaded: url_helper
INFO - 2018-03-07 14:38:52 --> Model Class Initialized
INFO - 2018-03-07 14:38:52 --> Model Class Initialized
INFO - 2018-03-07 14:38:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 14:38:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 14:38:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-07 14:38:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 14:38:52 --> Final output sent to browser
DEBUG - 2018-03-07 14:38:52 --> Total execution time: 0.1719
INFO - 2018-03-07 14:38:54 --> Config Class Initialized
INFO - 2018-03-07 14:38:54 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:38:54 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:38:54 --> Utf8 Class Initialized
INFO - 2018-03-07 14:38:54 --> URI Class Initialized
INFO - 2018-03-07 14:38:54 --> Router Class Initialized
INFO - 2018-03-07 14:38:54 --> Output Class Initialized
INFO - 2018-03-07 14:38:54 --> Security Class Initialized
DEBUG - 2018-03-07 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:38:54 --> Input Class Initialized
INFO - 2018-03-07 14:38:54 --> Language Class Initialized
INFO - 2018-03-07 14:38:54 --> Loader Class Initialized
INFO - 2018-03-07 14:38:54 --> Helper loaded: common_helper
INFO - 2018-03-07 14:38:54 --> Database Driver Class Initialized
INFO - 2018-03-07 14:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:38:54 --> Email Class Initialized
INFO - 2018-03-07 14:38:54 --> Controller Class Initialized
INFO - 2018-03-07 14:38:54 --> Helper loaded: form_helper
INFO - 2018-03-07 14:38:54 --> Form Validation Class Initialized
INFO - 2018-03-07 14:38:54 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:38:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:38:54 --> Helper loaded: url_helper
INFO - 2018-03-07 14:38:54 --> Model Class Initialized
INFO - 2018-03-07 14:38:54 --> Model Class Initialized
INFO - 2018-03-07 14:38:54 --> Model Class Initialized
INFO - 2018-03-07 19:08:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 19:08:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 19:08:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:08:54 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:08:54 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-07 19:08:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-07 19:08:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 19:08:54 --> Final output sent to browser
DEBUG - 2018-03-07 19:08:54 --> Total execution time: 0.2880
INFO - 2018-03-07 14:39:07 --> Config Class Initialized
INFO - 2018-03-07 14:39:07 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:39:07 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:39:07 --> Utf8 Class Initialized
INFO - 2018-03-07 14:39:07 --> URI Class Initialized
INFO - 2018-03-07 14:39:07 --> Router Class Initialized
INFO - 2018-03-07 14:39:07 --> Output Class Initialized
INFO - 2018-03-07 14:39:07 --> Security Class Initialized
DEBUG - 2018-03-07 14:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:39:07 --> Input Class Initialized
INFO - 2018-03-07 14:39:07 --> Language Class Initialized
INFO - 2018-03-07 14:39:07 --> Loader Class Initialized
INFO - 2018-03-07 14:39:07 --> Helper loaded: common_helper
INFO - 2018-03-07 14:39:07 --> Database Driver Class Initialized
INFO - 2018-03-07 14:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:39:07 --> Email Class Initialized
INFO - 2018-03-07 14:39:07 --> Controller Class Initialized
INFO - 2018-03-07 14:39:07 --> Helper loaded: form_helper
INFO - 2018-03-07 14:39:07 --> Form Validation Class Initialized
INFO - 2018-03-07 14:39:07 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:39:07 --> Helper loaded: url_helper
INFO - 2018-03-07 14:39:07 --> Model Class Initialized
INFO - 2018-03-07 14:39:07 --> Model Class Initialized
INFO - 2018-03-07 14:39:07 --> Model Class Initialized
INFO - 2018-03-07 19:09:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 19:09:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 19:09:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-07 19:09:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 19:09:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 19:09:07 --> Final output sent to browser
DEBUG - 2018-03-07 19:09:07 --> Total execution time: 0.1545
INFO - 2018-03-07 14:39:13 --> Config Class Initialized
INFO - 2018-03-07 14:39:13 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:39:13 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:39:13 --> Utf8 Class Initialized
INFO - 2018-03-07 14:39:13 --> URI Class Initialized
INFO - 2018-03-07 14:39:13 --> Router Class Initialized
INFO - 2018-03-07 14:39:13 --> Output Class Initialized
INFO - 2018-03-07 14:39:13 --> Security Class Initialized
DEBUG - 2018-03-07 14:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:39:13 --> Input Class Initialized
INFO - 2018-03-07 14:39:13 --> Language Class Initialized
INFO - 2018-03-07 14:39:13 --> Loader Class Initialized
INFO - 2018-03-07 14:39:13 --> Helper loaded: common_helper
INFO - 2018-03-07 14:39:13 --> Database Driver Class Initialized
INFO - 2018-03-07 14:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:39:13 --> Email Class Initialized
INFO - 2018-03-07 14:39:13 --> Controller Class Initialized
INFO - 2018-03-07 14:39:13 --> Helper loaded: form_helper
INFO - 2018-03-07 14:39:13 --> Form Validation Class Initialized
INFO - 2018-03-07 14:39:13 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:39:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:39:13 --> Helper loaded: url_helper
INFO - 2018-03-07 14:39:13 --> Model Class Initialized
INFO - 2018-03-07 14:39:13 --> Model Class Initialized
INFO - 2018-03-07 14:39:13 --> Model Class Initialized
INFO - 2018-03-07 19:09:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 19:09:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 19:09:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 19:09:13 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 19:09:13 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-07 19:09:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-07 19:09:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 19:09:13 --> Final output sent to browser
DEBUG - 2018-03-07 19:09:13 --> Total execution time: 0.0796
INFO - 2018-03-07 14:39:14 --> Config Class Initialized
INFO - 2018-03-07 14:39:14 --> Hooks Class Initialized
DEBUG - 2018-03-07 14:39:14 --> UTF-8 Support Enabled
INFO - 2018-03-07 14:39:14 --> Utf8 Class Initialized
INFO - 2018-03-07 14:39:14 --> URI Class Initialized
INFO - 2018-03-07 14:39:14 --> Router Class Initialized
INFO - 2018-03-07 14:39:14 --> Output Class Initialized
INFO - 2018-03-07 14:39:14 --> Security Class Initialized
DEBUG - 2018-03-07 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 14:39:14 --> Input Class Initialized
INFO - 2018-03-07 14:39:14 --> Language Class Initialized
INFO - 2018-03-07 14:39:14 --> Loader Class Initialized
INFO - 2018-03-07 14:39:14 --> Helper loaded: common_helper
INFO - 2018-03-07 14:39:14 --> Database Driver Class Initialized
INFO - 2018-03-07 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 14:39:14 --> Email Class Initialized
INFO - 2018-03-07 14:39:14 --> Controller Class Initialized
INFO - 2018-03-07 14:39:14 --> Helper loaded: form_helper
INFO - 2018-03-07 14:39:14 --> Form Validation Class Initialized
INFO - 2018-03-07 14:39:14 --> Helper loaded: email_helper
DEBUG - 2018-03-07 14:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 14:39:14 --> Helper loaded: url_helper
INFO - 2018-03-07 14:39:14 --> Model Class Initialized
INFO - 2018-03-07 14:39:14 --> Model Class Initialized
INFO - 2018-03-07 14:39:14 --> Model Class Initialized
INFO - 2018-03-07 19:09:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 19:09:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 19:09:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 19:09:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-07 19:09:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 19:09:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 19:09:14 --> Final output sent to browser
DEBUG - 2018-03-07 19:09:14 --> Total execution time: 0.0700
INFO - 2018-03-07 15:48:01 --> Config Class Initialized
INFO - 2018-03-07 15:48:01 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:48:01 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:48:01 --> Utf8 Class Initialized
INFO - 2018-03-07 15:48:01 --> URI Class Initialized
DEBUG - 2018-03-07 15:48:01 --> No URI present. Default controller set.
INFO - 2018-03-07 15:48:01 --> Router Class Initialized
INFO - 2018-03-07 15:48:01 --> Output Class Initialized
INFO - 2018-03-07 15:48:01 --> Security Class Initialized
DEBUG - 2018-03-07 15:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:48:01 --> Input Class Initialized
INFO - 2018-03-07 15:48:01 --> Language Class Initialized
INFO - 2018-03-07 15:48:01 --> Loader Class Initialized
INFO - 2018-03-07 15:48:01 --> Helper loaded: common_helper
INFO - 2018-03-07 15:48:01 --> Database Driver Class Initialized
INFO - 2018-03-07 15:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:48:02 --> Email Class Initialized
INFO - 2018-03-07 15:48:02 --> Controller Class Initialized
INFO - 2018-03-07 15:48:02 --> Helper loaded: form_helper
INFO - 2018-03-07 15:48:02 --> Form Validation Class Initialized
INFO - 2018-03-07 15:48:02 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:02 --> Helper loaded: url_helper
INFO - 2018-03-07 15:48:02 --> Model Class Initialized
INFO - 2018-03-07 15:48:02 --> Model Class Initialized
INFO - 2018-03-07 15:48:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-07 15:48:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 15:48:02 --> Final output sent to browser
DEBUG - 2018-03-07 15:48:02 --> Total execution time: 1.2481
INFO - 2018-03-07 15:48:19 --> Config Class Initialized
INFO - 2018-03-07 15:48:19 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:48:19 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:48:19 --> Utf8 Class Initialized
INFO - 2018-03-07 15:48:19 --> URI Class Initialized
DEBUG - 2018-03-07 15:48:19 --> No URI present. Default controller set.
INFO - 2018-03-07 15:48:19 --> Router Class Initialized
INFO - 2018-03-07 15:48:19 --> Output Class Initialized
INFO - 2018-03-07 15:48:19 --> Security Class Initialized
DEBUG - 2018-03-07 15:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:48:20 --> Input Class Initialized
INFO - 2018-03-07 15:48:20 --> Language Class Initialized
INFO - 2018-03-07 15:48:20 --> Loader Class Initialized
INFO - 2018-03-07 15:48:20 --> Helper loaded: common_helper
INFO - 2018-03-07 15:48:20 --> Database Driver Class Initialized
INFO - 2018-03-07 15:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:48:20 --> Email Class Initialized
INFO - 2018-03-07 15:48:20 --> Controller Class Initialized
INFO - 2018-03-07 15:48:20 --> Helper loaded: form_helper
INFO - 2018-03-07 15:48:20 --> Form Validation Class Initialized
INFO - 2018-03-07 15:48:20 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:20 --> Helper loaded: url_helper
INFO - 2018-03-07 15:48:20 --> Model Class Initialized
INFO - 2018-03-07 15:48:20 --> Model Class Initialized
DEBUG - 2018-03-07 15:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 15:48:20 --> Config Class Initialized
INFO - 2018-03-07 15:48:20 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:48:20 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:48:20 --> Utf8 Class Initialized
INFO - 2018-03-07 15:48:20 --> URI Class Initialized
DEBUG - 2018-03-07 15:48:20 --> No URI present. Default controller set.
INFO - 2018-03-07 15:48:20 --> Router Class Initialized
INFO - 2018-03-07 15:48:20 --> Output Class Initialized
INFO - 2018-03-07 15:48:20 --> Security Class Initialized
DEBUG - 2018-03-07 15:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:48:20 --> Input Class Initialized
INFO - 2018-03-07 15:48:20 --> Language Class Initialized
INFO - 2018-03-07 15:48:20 --> Loader Class Initialized
INFO - 2018-03-07 15:48:20 --> Helper loaded: common_helper
INFO - 2018-03-07 15:48:20 --> Database Driver Class Initialized
INFO - 2018-03-07 15:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:48:20 --> Email Class Initialized
INFO - 2018-03-07 15:48:20 --> Controller Class Initialized
INFO - 2018-03-07 15:48:20 --> Helper loaded: form_helper
INFO - 2018-03-07 15:48:20 --> Form Validation Class Initialized
INFO - 2018-03-07 15:48:20 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:20 --> Helper loaded: url_helper
INFO - 2018-03-07 15:48:20 --> Model Class Initialized
INFO - 2018-03-07 15:48:20 --> Model Class Initialized
INFO - 2018-03-07 15:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-07 15:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 15:48:20 --> Final output sent to browser
DEBUG - 2018-03-07 15:48:20 --> Total execution time: 0.1520
INFO - 2018-03-07 15:48:32 --> Config Class Initialized
INFO - 2018-03-07 15:48:32 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:48:32 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:48:32 --> Utf8 Class Initialized
INFO - 2018-03-07 15:48:32 --> URI Class Initialized
DEBUG - 2018-03-07 15:48:32 --> No URI present. Default controller set.
INFO - 2018-03-07 15:48:32 --> Router Class Initialized
INFO - 2018-03-07 15:48:32 --> Output Class Initialized
INFO - 2018-03-07 15:48:32 --> Security Class Initialized
DEBUG - 2018-03-07 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:48:32 --> Input Class Initialized
INFO - 2018-03-07 15:48:32 --> Language Class Initialized
INFO - 2018-03-07 15:48:32 --> Loader Class Initialized
INFO - 2018-03-07 15:48:32 --> Helper loaded: common_helper
INFO - 2018-03-07 15:48:32 --> Database Driver Class Initialized
INFO - 2018-03-07 15:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:48:33 --> Email Class Initialized
INFO - 2018-03-07 15:48:33 --> Controller Class Initialized
INFO - 2018-03-07 15:48:33 --> Helper loaded: form_helper
INFO - 2018-03-07 15:48:33 --> Form Validation Class Initialized
INFO - 2018-03-07 15:48:33 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:33 --> Helper loaded: url_helper
INFO - 2018-03-07 15:48:33 --> Model Class Initialized
INFO - 2018-03-07 15:48:33 --> Model Class Initialized
DEBUG - 2018-03-07 15:48:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 15:48:33 --> Config Class Initialized
INFO - 2018-03-07 15:48:33 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:48:33 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:48:33 --> Utf8 Class Initialized
INFO - 2018-03-07 15:48:33 --> URI Class Initialized
INFO - 2018-03-07 15:48:33 --> Router Class Initialized
INFO - 2018-03-07 15:48:33 --> Output Class Initialized
INFO - 2018-03-07 15:48:33 --> Security Class Initialized
DEBUG - 2018-03-07 15:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:48:33 --> Input Class Initialized
INFO - 2018-03-07 15:48:33 --> Language Class Initialized
INFO - 2018-03-07 15:48:33 --> Loader Class Initialized
INFO - 2018-03-07 15:48:33 --> Helper loaded: common_helper
INFO - 2018-03-07 15:48:33 --> Database Driver Class Initialized
INFO - 2018-03-07 15:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:48:33 --> Email Class Initialized
INFO - 2018-03-07 15:48:33 --> Controller Class Initialized
INFO - 2018-03-07 15:48:33 --> Helper loaded: form_helper
INFO - 2018-03-07 15:48:33 --> Form Validation Class Initialized
INFO - 2018-03-07 15:48:33 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:33 --> Helper loaded: url_helper
INFO - 2018-03-07 15:48:33 --> Model Class Initialized
INFO - 2018-03-07 15:48:33 --> Model Class Initialized
INFO - 2018-03-07 15:48:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 15:48:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 15:48:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-07 15:48:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 15:48:34 --> Final output sent to browser
DEBUG - 2018-03-07 15:48:34 --> Total execution time: 0.9371
INFO - 2018-03-07 15:48:45 --> Config Class Initialized
INFO - 2018-03-07 15:48:45 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:48:45 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:48:45 --> Utf8 Class Initialized
INFO - 2018-03-07 15:48:45 --> URI Class Initialized
INFO - 2018-03-07 15:48:45 --> Router Class Initialized
INFO - 2018-03-07 15:48:45 --> Output Class Initialized
INFO - 2018-03-07 15:48:45 --> Security Class Initialized
DEBUG - 2018-03-07 15:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:48:45 --> Input Class Initialized
INFO - 2018-03-07 15:48:45 --> Language Class Initialized
INFO - 2018-03-07 15:48:45 --> Loader Class Initialized
INFO - 2018-03-07 15:48:45 --> Helper loaded: common_helper
INFO - 2018-03-07 15:48:45 --> Database Driver Class Initialized
INFO - 2018-03-07 15:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:48:45 --> Email Class Initialized
INFO - 2018-03-07 15:48:45 --> Controller Class Initialized
INFO - 2018-03-07 15:48:45 --> Helper loaded: form_helper
INFO - 2018-03-07 15:48:45 --> Form Validation Class Initialized
INFO - 2018-03-07 15:48:45 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:48:45 --> Helper loaded: url_helper
INFO - 2018-03-07 15:48:45 --> Model Class Initialized
INFO - 2018-03-07 15:48:45 --> Model Class Initialized
INFO - 2018-03-07 15:48:45 --> Model Class Initialized
INFO - 2018-03-07 20:18:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:18:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:18:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 20:18:46 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 20:18:46 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-07 20:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-07 20:18:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:18:46 --> Final output sent to browser
DEBUG - 2018-03-07 20:18:46 --> Total execution time: 0.3430
INFO - 2018-03-07 15:49:11 --> Config Class Initialized
INFO - 2018-03-07 15:49:11 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:49:11 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:49:11 --> Utf8 Class Initialized
INFO - 2018-03-07 15:49:11 --> URI Class Initialized
INFO - 2018-03-07 15:49:11 --> Router Class Initialized
INFO - 2018-03-07 15:49:11 --> Output Class Initialized
INFO - 2018-03-07 15:49:11 --> Security Class Initialized
DEBUG - 2018-03-07 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:49:11 --> Input Class Initialized
INFO - 2018-03-07 15:49:11 --> Language Class Initialized
INFO - 2018-03-07 15:49:11 --> Loader Class Initialized
INFO - 2018-03-07 15:49:12 --> Helper loaded: common_helper
INFO - 2018-03-07 15:49:12 --> Database Driver Class Initialized
INFO - 2018-03-07 15:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:49:12 --> Email Class Initialized
INFO - 2018-03-07 15:49:12 --> Controller Class Initialized
INFO - 2018-03-07 15:49:12 --> Helper loaded: form_helper
INFO - 2018-03-07 15:49:12 --> Form Validation Class Initialized
INFO - 2018-03-07 15:49:12 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:49:12 --> Helper loaded: url_helper
INFO - 2018-03-07 15:49:12 --> Model Class Initialized
INFO - 2018-03-07 15:49:12 --> Model Class Initialized
INFO - 2018-03-07 15:49:12 --> Model Class Initialized
INFO - 2018-03-07 20:19:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:19:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:19:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:19:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-07 20:19:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:19:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:19:12 --> Final output sent to browser
DEBUG - 2018-03-07 20:19:12 --> Total execution time: 0.1480
INFO - 2018-03-07 15:52:04 --> Config Class Initialized
INFO - 2018-03-07 15:52:04 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:52:04 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:52:04 --> Utf8 Class Initialized
INFO - 2018-03-07 15:52:04 --> URI Class Initialized
INFO - 2018-03-07 15:52:04 --> Router Class Initialized
INFO - 2018-03-07 15:52:04 --> Output Class Initialized
INFO - 2018-03-07 15:52:04 --> Security Class Initialized
DEBUG - 2018-03-07 15:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:52:04 --> Input Class Initialized
INFO - 2018-03-07 15:52:04 --> Language Class Initialized
INFO - 2018-03-07 15:52:04 --> Loader Class Initialized
INFO - 2018-03-07 15:52:04 --> Helper loaded: common_helper
INFO - 2018-03-07 15:52:04 --> Database Driver Class Initialized
INFO - 2018-03-07 15:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:52:04 --> Email Class Initialized
INFO - 2018-03-07 15:52:04 --> Controller Class Initialized
INFO - 2018-03-07 15:52:04 --> Helper loaded: form_helper
INFO - 2018-03-07 15:52:04 --> Form Validation Class Initialized
INFO - 2018-03-07 15:52:04 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:52:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:52:04 --> Helper loaded: url_helper
INFO - 2018-03-07 20:22:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:22:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:22:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:22:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2018-03-07 20:22:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:22:05 --> Final output sent to browser
DEBUG - 2018-03-07 20:22:05 --> Total execution time: 0.3470
INFO - 2018-03-07 15:52:16 --> Config Class Initialized
INFO - 2018-03-07 15:52:16 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:52:16 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:52:16 --> Utf8 Class Initialized
INFO - 2018-03-07 15:52:16 --> URI Class Initialized
INFO - 2018-03-07 15:52:16 --> Router Class Initialized
INFO - 2018-03-07 15:52:16 --> Output Class Initialized
INFO - 2018-03-07 15:52:16 --> Security Class Initialized
DEBUG - 2018-03-07 15:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:52:16 --> Input Class Initialized
INFO - 2018-03-07 15:52:16 --> Language Class Initialized
INFO - 2018-03-07 15:52:16 --> Loader Class Initialized
INFO - 2018-03-07 15:52:16 --> Helper loaded: common_helper
INFO - 2018-03-07 15:52:16 --> Database Driver Class Initialized
INFO - 2018-03-07 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:52:16 --> Email Class Initialized
INFO - 2018-03-07 15:52:16 --> Controller Class Initialized
INFO - 2018-03-07 15:52:16 --> Helper loaded: form_helper
INFO - 2018-03-07 15:52:16 --> Form Validation Class Initialized
INFO - 2018-03-07 15:52:16 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:52:16 --> Helper loaded: url_helper
INFO - 2018-03-07 15:52:16 --> Model Class Initialized
INFO - 2018-03-07 15:52:16 --> Model Class Initialized
INFO - 2018-03-07 15:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 15:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 15:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-07 15:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 15:52:16 --> Final output sent to browser
DEBUG - 2018-03-07 15:52:16 --> Total execution time: 0.1360
INFO - 2018-03-07 15:52:23 --> Config Class Initialized
INFO - 2018-03-07 15:52:23 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:52:23 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:52:23 --> Utf8 Class Initialized
INFO - 2018-03-07 15:52:23 --> URI Class Initialized
INFO - 2018-03-07 15:52:23 --> Router Class Initialized
INFO - 2018-03-07 15:52:23 --> Output Class Initialized
INFO - 2018-03-07 15:52:23 --> Security Class Initialized
DEBUG - 2018-03-07 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:52:23 --> Input Class Initialized
INFO - 2018-03-07 15:52:23 --> Language Class Initialized
INFO - 2018-03-07 15:52:23 --> Loader Class Initialized
INFO - 2018-03-07 15:52:23 --> Helper loaded: common_helper
INFO - 2018-03-07 15:52:23 --> Database Driver Class Initialized
INFO - 2018-03-07 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:52:23 --> Email Class Initialized
INFO - 2018-03-07 15:52:23 --> Controller Class Initialized
INFO - 2018-03-07 15:52:23 --> Helper loaded: form_helper
INFO - 2018-03-07 15:52:23 --> Form Validation Class Initialized
INFO - 2018-03-07 15:52:23 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:52:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:52:23 --> Helper loaded: url_helper
INFO - 2018-03-07 15:52:23 --> Model Class Initialized
INFO - 2018-03-07 15:52:23 --> Model Class Initialized
INFO - 2018-03-07 20:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2018-03-07 20:22:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:22:23 --> Final output sent to browser
DEBUG - 2018-03-07 20:22:23 --> Total execution time: 0.1610
INFO - 2018-03-07 15:52:47 --> Config Class Initialized
INFO - 2018-03-07 15:52:47 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:52:47 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:52:47 --> Utf8 Class Initialized
INFO - 2018-03-07 15:52:47 --> URI Class Initialized
INFO - 2018-03-07 15:52:47 --> Router Class Initialized
INFO - 2018-03-07 15:52:47 --> Output Class Initialized
INFO - 2018-03-07 15:52:47 --> Security Class Initialized
DEBUG - 2018-03-07 15:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:52:47 --> Input Class Initialized
INFO - 2018-03-07 15:52:47 --> Language Class Initialized
INFO - 2018-03-07 15:52:47 --> Loader Class Initialized
INFO - 2018-03-07 15:52:47 --> Helper loaded: common_helper
INFO - 2018-03-07 15:52:47 --> Database Driver Class Initialized
INFO - 2018-03-07 15:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:52:47 --> Email Class Initialized
INFO - 2018-03-07 15:52:47 --> Controller Class Initialized
INFO - 2018-03-07 15:52:47 --> Helper loaded: form_helper
INFO - 2018-03-07 15:52:47 --> Form Validation Class Initialized
INFO - 2018-03-07 15:52:47 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:52:47 --> Helper loaded: url_helper
INFO - 2018-03-07 15:52:47 --> Model Class Initialized
INFO - 2018-03-07 15:52:47 --> Model Class Initialized
INFO - 2018-03-07 20:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2018-03-07 20:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:22:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:22:47 --> Final output sent to browser
DEBUG - 2018-03-07 20:22:47 --> Total execution time: 0.2090
INFO - 2018-03-07 15:53:04 --> Config Class Initialized
INFO - 2018-03-07 15:53:04 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:53:04 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:53:04 --> Utf8 Class Initialized
INFO - 2018-03-07 15:53:04 --> URI Class Initialized
INFO - 2018-03-07 15:53:04 --> Router Class Initialized
INFO - 2018-03-07 15:53:04 --> Output Class Initialized
INFO - 2018-03-07 15:53:04 --> Security Class Initialized
DEBUG - 2018-03-07 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:53:04 --> Input Class Initialized
INFO - 2018-03-07 15:53:04 --> Language Class Initialized
INFO - 2018-03-07 15:53:04 --> Loader Class Initialized
INFO - 2018-03-07 15:53:04 --> Helper loaded: common_helper
INFO - 2018-03-07 15:53:04 --> Database Driver Class Initialized
INFO - 2018-03-07 15:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:53:04 --> Email Class Initialized
INFO - 2018-03-07 15:53:04 --> Controller Class Initialized
INFO - 2018-03-07 15:53:04 --> Helper loaded: form_helper
INFO - 2018-03-07 15:53:04 --> Form Validation Class Initialized
INFO - 2018-03-07 15:53:04 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:53:04 --> Helper loaded: url_helper
INFO - 2018-03-07 15:53:04 --> Model Class Initialized
INFO - 2018-03-07 15:53:05 --> Model Class Initialized
DEBUG - 2018-03-07 20:23:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 20:23:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 15:53:05 --> Config Class Initialized
INFO - 2018-03-07 15:53:05 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:53:05 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:53:05 --> Utf8 Class Initialized
INFO - 2018-03-07 15:53:05 --> URI Class Initialized
INFO - 2018-03-07 15:53:05 --> Router Class Initialized
INFO - 2018-03-07 15:53:05 --> Output Class Initialized
INFO - 2018-03-07 15:53:05 --> Security Class Initialized
DEBUG - 2018-03-07 15:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:53:05 --> Input Class Initialized
INFO - 2018-03-07 15:53:05 --> Language Class Initialized
INFO - 2018-03-07 15:53:05 --> Loader Class Initialized
INFO - 2018-03-07 15:53:05 --> Helper loaded: common_helper
INFO - 2018-03-07 15:53:05 --> Database Driver Class Initialized
INFO - 2018-03-07 15:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:53:05 --> Email Class Initialized
INFO - 2018-03-07 15:53:05 --> Controller Class Initialized
INFO - 2018-03-07 15:53:05 --> Helper loaded: form_helper
INFO - 2018-03-07 15:53:05 --> Form Validation Class Initialized
INFO - 2018-03-07 15:53:05 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:53:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:53:05 --> Helper loaded: url_helper
INFO - 2018-03-07 15:53:05 --> Model Class Initialized
INFO - 2018-03-07 15:53:05 --> Model Class Initialized
INFO - 2018-03-07 20:23:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:23:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:23:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:23:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2018-03-07 20:23:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:23:05 --> Final output sent to browser
DEBUG - 2018-03-07 20:23:05 --> Total execution time: 0.1340
INFO - 2018-03-07 15:53:16 --> Config Class Initialized
INFO - 2018-03-07 15:53:16 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:53:16 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:53:16 --> Utf8 Class Initialized
INFO - 2018-03-07 15:53:16 --> URI Class Initialized
INFO - 2018-03-07 15:53:16 --> Router Class Initialized
INFO - 2018-03-07 15:53:16 --> Output Class Initialized
INFO - 2018-03-07 15:53:16 --> Security Class Initialized
DEBUG - 2018-03-07 15:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:53:16 --> Input Class Initialized
INFO - 2018-03-07 15:53:16 --> Language Class Initialized
INFO - 2018-03-07 15:53:16 --> Loader Class Initialized
INFO - 2018-03-07 15:53:16 --> Helper loaded: common_helper
INFO - 2018-03-07 15:53:16 --> Database Driver Class Initialized
INFO - 2018-03-07 15:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:53:16 --> Email Class Initialized
INFO - 2018-03-07 15:53:16 --> Controller Class Initialized
INFO - 2018-03-07 15:53:16 --> Helper loaded: form_helper
INFO - 2018-03-07 15:53:16 --> Form Validation Class Initialized
INFO - 2018-03-07 15:53:16 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:53:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:53:16 --> Helper loaded: url_helper
INFO - 2018-03-07 15:53:16 --> Model Class Initialized
INFO - 2018-03-07 15:53:16 --> Model Class Initialized
INFO - 2018-03-07 20:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2018-03-07 20:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:23:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:23:16 --> Final output sent to browser
DEBUG - 2018-03-07 20:23:16 --> Total execution time: 0.1230
INFO - 2018-03-07 15:53:58 --> Config Class Initialized
INFO - 2018-03-07 15:53:58 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:53:58 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:53:58 --> Utf8 Class Initialized
INFO - 2018-03-07 15:53:58 --> URI Class Initialized
INFO - 2018-03-07 15:53:58 --> Router Class Initialized
INFO - 2018-03-07 15:53:58 --> Output Class Initialized
INFO - 2018-03-07 15:53:58 --> Security Class Initialized
DEBUG - 2018-03-07 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:53:58 --> Input Class Initialized
INFO - 2018-03-07 15:53:58 --> Language Class Initialized
INFO - 2018-03-07 15:53:58 --> Loader Class Initialized
INFO - 2018-03-07 15:53:58 --> Helper loaded: common_helper
INFO - 2018-03-07 15:53:58 --> Database Driver Class Initialized
INFO - 2018-03-07 15:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:53:58 --> Email Class Initialized
INFO - 2018-03-07 15:53:58 --> Controller Class Initialized
INFO - 2018-03-07 15:53:58 --> Helper loaded: form_helper
INFO - 2018-03-07 15:53:58 --> Form Validation Class Initialized
INFO - 2018-03-07 15:53:58 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:53:58 --> Helper loaded: url_helper
INFO - 2018-03-07 15:53:58 --> Model Class Initialized
INFO - 2018-03-07 15:53:58 --> Model Class Initialized
DEBUG - 2018-03-07 20:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 20:23:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 15:53:58 --> Config Class Initialized
INFO - 2018-03-07 15:53:58 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:53:58 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:53:58 --> Utf8 Class Initialized
INFO - 2018-03-07 15:53:58 --> URI Class Initialized
INFO - 2018-03-07 15:53:58 --> Router Class Initialized
INFO - 2018-03-07 15:53:58 --> Output Class Initialized
INFO - 2018-03-07 15:53:58 --> Security Class Initialized
DEBUG - 2018-03-07 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:53:58 --> Input Class Initialized
INFO - 2018-03-07 15:53:58 --> Language Class Initialized
INFO - 2018-03-07 15:53:58 --> Loader Class Initialized
INFO - 2018-03-07 15:53:58 --> Helper loaded: common_helper
INFO - 2018-03-07 15:53:59 --> Database Driver Class Initialized
INFO - 2018-03-07 15:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:53:59 --> Email Class Initialized
INFO - 2018-03-07 15:53:59 --> Controller Class Initialized
INFO - 2018-03-07 15:53:59 --> Helper loaded: form_helper
INFO - 2018-03-07 15:53:59 --> Form Validation Class Initialized
INFO - 2018-03-07 15:53:59 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:53:59 --> Helper loaded: url_helper
INFO - 2018-03-07 15:53:59 --> Model Class Initialized
INFO - 2018-03-07 15:53:59 --> Model Class Initialized
INFO - 2018-03-07 20:23:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:23:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:23:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:23:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2018-03-07 20:23:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:23:59 --> Final output sent to browser
DEBUG - 2018-03-07 20:23:59 --> Total execution time: 0.1450
INFO - 2018-03-07 15:54:14 --> Config Class Initialized
INFO - 2018-03-07 15:54:14 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:54:14 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:54:14 --> Utf8 Class Initialized
INFO - 2018-03-07 15:54:14 --> URI Class Initialized
INFO - 2018-03-07 15:54:14 --> Router Class Initialized
INFO - 2018-03-07 15:54:14 --> Output Class Initialized
INFO - 2018-03-07 15:54:14 --> Security Class Initialized
DEBUG - 2018-03-07 15:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:54:14 --> Input Class Initialized
INFO - 2018-03-07 15:54:14 --> Language Class Initialized
INFO - 2018-03-07 15:54:14 --> Loader Class Initialized
INFO - 2018-03-07 15:54:14 --> Helper loaded: common_helper
INFO - 2018-03-07 15:54:14 --> Database Driver Class Initialized
INFO - 2018-03-07 15:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:54:14 --> Email Class Initialized
INFO - 2018-03-07 15:54:14 --> Controller Class Initialized
INFO - 2018-03-07 15:54:14 --> Helper loaded: form_helper
INFO - 2018-03-07 15:54:14 --> Form Validation Class Initialized
INFO - 2018-03-07 15:54:14 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:54:14 --> Helper loaded: url_helper
INFO - 2018-03-07 15:54:14 --> Model Class Initialized
INFO - 2018-03-07 15:54:14 --> Model Class Initialized
INFO - 2018-03-07 20:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2018-03-07 20:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:24:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:24:14 --> Final output sent to browser
DEBUG - 2018-03-07 20:24:14 --> Total execution time: 0.1240
INFO - 2018-03-07 15:54:27 --> Config Class Initialized
INFO - 2018-03-07 15:54:27 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:54:27 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:54:27 --> Utf8 Class Initialized
INFO - 2018-03-07 15:54:27 --> URI Class Initialized
INFO - 2018-03-07 15:54:27 --> Router Class Initialized
INFO - 2018-03-07 15:54:27 --> Output Class Initialized
INFO - 2018-03-07 15:54:27 --> Security Class Initialized
DEBUG - 2018-03-07 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:54:27 --> Input Class Initialized
INFO - 2018-03-07 15:54:27 --> Language Class Initialized
INFO - 2018-03-07 15:54:27 --> Loader Class Initialized
INFO - 2018-03-07 15:54:27 --> Helper loaded: common_helper
INFO - 2018-03-07 15:54:27 --> Database Driver Class Initialized
INFO - 2018-03-07 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:54:27 --> Email Class Initialized
INFO - 2018-03-07 15:54:27 --> Controller Class Initialized
INFO - 2018-03-07 15:54:27 --> Helper loaded: form_helper
INFO - 2018-03-07 15:54:27 --> Form Validation Class Initialized
INFO - 2018-03-07 15:54:27 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:54:27 --> Helper loaded: url_helper
INFO - 2018-03-07 15:54:27 --> Model Class Initialized
INFO - 2018-03-07 15:54:27 --> Model Class Initialized
DEBUG - 2018-03-07 20:24:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 20:24:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 15:54:27 --> Config Class Initialized
INFO - 2018-03-07 15:54:27 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:54:27 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:54:27 --> Utf8 Class Initialized
INFO - 2018-03-07 15:54:27 --> URI Class Initialized
INFO - 2018-03-07 15:54:27 --> Router Class Initialized
INFO - 2018-03-07 15:54:27 --> Output Class Initialized
INFO - 2018-03-07 15:54:27 --> Security Class Initialized
DEBUG - 2018-03-07 15:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:54:27 --> Input Class Initialized
INFO - 2018-03-07 15:54:27 --> Language Class Initialized
INFO - 2018-03-07 15:54:27 --> Loader Class Initialized
INFO - 2018-03-07 15:54:27 --> Helper loaded: common_helper
INFO - 2018-03-07 15:54:27 --> Database Driver Class Initialized
INFO - 2018-03-07 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:54:27 --> Email Class Initialized
INFO - 2018-03-07 15:54:27 --> Controller Class Initialized
INFO - 2018-03-07 15:54:27 --> Helper loaded: form_helper
INFO - 2018-03-07 15:54:27 --> Form Validation Class Initialized
INFO - 2018-03-07 15:54:27 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:54:27 --> Helper loaded: url_helper
INFO - 2018-03-07 15:54:27 --> Model Class Initialized
INFO - 2018-03-07 15:54:27 --> Model Class Initialized
INFO - 2018-03-07 20:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2018-03-07 20:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:24:27 --> Final output sent to browser
DEBUG - 2018-03-07 20:24:27 --> Total execution time: 0.1230
INFO - 2018-03-07 15:54:36 --> Config Class Initialized
INFO - 2018-03-07 15:54:36 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:54:36 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:54:36 --> Utf8 Class Initialized
INFO - 2018-03-07 15:54:36 --> URI Class Initialized
INFO - 2018-03-07 15:54:36 --> Router Class Initialized
INFO - 2018-03-07 15:54:36 --> Output Class Initialized
INFO - 2018-03-07 15:54:36 --> Security Class Initialized
DEBUG - 2018-03-07 15:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:54:36 --> Input Class Initialized
INFO - 2018-03-07 15:54:36 --> Language Class Initialized
INFO - 2018-03-07 15:54:36 --> Loader Class Initialized
INFO - 2018-03-07 15:54:36 --> Helper loaded: common_helper
INFO - 2018-03-07 15:54:36 --> Database Driver Class Initialized
INFO - 2018-03-07 15:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:54:36 --> Email Class Initialized
INFO - 2018-03-07 15:54:36 --> Controller Class Initialized
INFO - 2018-03-07 15:54:36 --> Helper loaded: form_helper
INFO - 2018-03-07 15:54:36 --> Form Validation Class Initialized
INFO - 2018-03-07 15:54:36 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:54:36 --> Helper loaded: url_helper
INFO - 2018-03-07 15:54:36 --> Model Class Initialized
INFO - 2018-03-07 15:54:36 --> Model Class Initialized
INFO - 2018-03-07 20:24:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:24:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:24:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/addCategory.php
INFO - 2018-03-07 20:24:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:24:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:24:36 --> Final output sent to browser
DEBUG - 2018-03-07 20:24:36 --> Total execution time: 0.1450
INFO - 2018-03-07 15:54:49 --> Config Class Initialized
INFO - 2018-03-07 15:54:49 --> Hooks Class Initialized
DEBUG - 2018-03-07 15:54:49 --> UTF-8 Support Enabled
INFO - 2018-03-07 15:54:49 --> Utf8 Class Initialized
INFO - 2018-03-07 15:54:49 --> URI Class Initialized
INFO - 2018-03-07 15:54:49 --> Router Class Initialized
INFO - 2018-03-07 15:54:49 --> Output Class Initialized
INFO - 2018-03-07 15:54:49 --> Security Class Initialized
DEBUG - 2018-03-07 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 15:54:49 --> Input Class Initialized
INFO - 2018-03-07 15:54:49 --> Language Class Initialized
INFO - 2018-03-07 15:54:49 --> Loader Class Initialized
INFO - 2018-03-07 15:54:49 --> Helper loaded: common_helper
INFO - 2018-03-07 15:54:49 --> Database Driver Class Initialized
INFO - 2018-03-07 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 15:54:49 --> Email Class Initialized
INFO - 2018-03-07 15:54:49 --> Controller Class Initialized
INFO - 2018-03-07 15:54:49 --> Helper loaded: form_helper
INFO - 2018-03-07 15:54:49 --> Form Validation Class Initialized
INFO - 2018-03-07 15:54:49 --> Helper loaded: email_helper
DEBUG - 2018-03-07 15:54:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 15:54:49 --> Helper loaded: url_helper
INFO - 2018-03-07 15:54:49 --> Model Class Initialized
INFO - 2018-03-07 15:54:49 --> Model Class Initialized
INFO - 2018-03-07 20:24:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 20:24:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 20:24:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 20:24:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2018-03-07 20:24:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 20:24:49 --> Final output sent to browser
DEBUG - 2018-03-07 20:24:49 --> Total execution time: 0.1690
INFO - 2018-03-07 18:13:57 --> Config Class Initialized
INFO - 2018-03-07 18:13:57 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:13:57 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:13:57 --> Utf8 Class Initialized
INFO - 2018-03-07 18:13:57 --> URI Class Initialized
INFO - 2018-03-07 18:13:57 --> Router Class Initialized
INFO - 2018-03-07 18:13:57 --> Output Class Initialized
INFO - 2018-03-07 18:13:57 --> Security Class Initialized
DEBUG - 2018-03-07 18:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:13:57 --> Input Class Initialized
INFO - 2018-03-07 18:13:57 --> Language Class Initialized
INFO - 2018-03-07 18:13:57 --> Loader Class Initialized
INFO - 2018-03-07 18:13:57 --> Helper loaded: common_helper
INFO - 2018-03-07 18:13:57 --> Database Driver Class Initialized
INFO - 2018-03-07 18:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:13:58 --> Email Class Initialized
INFO - 2018-03-07 18:13:58 --> Controller Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: form_helper
INFO - 2018-03-07 18:13:58 --> Form Validation Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:13:58 --> Helper loaded: url_helper
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> Config Class Initialized
INFO - 2018-03-07 18:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:13:58 --> Utf8 Class Initialized
INFO - 2018-03-07 18:13:58 --> URI Class Initialized
INFO - 2018-03-07 18:13:58 --> Router Class Initialized
INFO - 2018-03-07 18:13:58 --> Output Class Initialized
INFO - 2018-03-07 18:13:58 --> Security Class Initialized
DEBUG - 2018-03-07 18:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:13:58 --> Input Class Initialized
INFO - 2018-03-07 18:13:58 --> Language Class Initialized
INFO - 2018-03-07 18:13:58 --> Loader Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: common_helper
INFO - 2018-03-07 18:13:58 --> Database Driver Class Initialized
INFO - 2018-03-07 18:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:13:58 --> Email Class Initialized
INFO - 2018-03-07 18:13:58 --> Controller Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: form_helper
INFO - 2018-03-07 18:13:58 --> Form Validation Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:13:58 --> Helper loaded: url_helper
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> Config Class Initialized
INFO - 2018-03-07 18:13:58 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:13:58 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:13:58 --> Utf8 Class Initialized
INFO - 2018-03-07 18:13:58 --> URI Class Initialized
DEBUG - 2018-03-07 18:13:58 --> No URI present. Default controller set.
INFO - 2018-03-07 18:13:58 --> Router Class Initialized
INFO - 2018-03-07 18:13:58 --> Output Class Initialized
INFO - 2018-03-07 18:13:58 --> Security Class Initialized
DEBUG - 2018-03-07 18:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:13:58 --> Input Class Initialized
INFO - 2018-03-07 18:13:58 --> Language Class Initialized
INFO - 2018-03-07 18:13:58 --> Loader Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: common_helper
INFO - 2018-03-07 18:13:58 --> Database Driver Class Initialized
INFO - 2018-03-07 18:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:13:58 --> Email Class Initialized
INFO - 2018-03-07 18:13:58 --> Controller Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: form_helper
INFO - 2018-03-07 18:13:58 --> Form Validation Class Initialized
INFO - 2018-03-07 18:13:58 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:13:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:13:58 --> Helper loaded: url_helper
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> Model Class Initialized
INFO - 2018-03-07 18:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-07 18:13:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 18:13:58 --> Final output sent to browser
DEBUG - 2018-03-07 18:13:58 --> Total execution time: 0.2890
INFO - 2018-03-07 18:14:04 --> Config Class Initialized
INFO - 2018-03-07 18:14:04 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:14:04 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:14:04 --> Utf8 Class Initialized
INFO - 2018-03-07 18:14:04 --> URI Class Initialized
DEBUG - 2018-03-07 18:14:04 --> No URI present. Default controller set.
INFO - 2018-03-07 18:14:04 --> Router Class Initialized
INFO - 2018-03-07 18:14:04 --> Output Class Initialized
INFO - 2018-03-07 18:14:04 --> Security Class Initialized
DEBUG - 2018-03-07 18:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:14:04 --> Input Class Initialized
INFO - 2018-03-07 18:14:04 --> Language Class Initialized
INFO - 2018-03-07 18:14:04 --> Loader Class Initialized
INFO - 2018-03-07 18:14:04 --> Helper loaded: common_helper
INFO - 2018-03-07 18:14:04 --> Database Driver Class Initialized
INFO - 2018-03-07 18:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:14:04 --> Email Class Initialized
INFO - 2018-03-07 18:14:04 --> Controller Class Initialized
INFO - 2018-03-07 18:14:04 --> Helper loaded: form_helper
INFO - 2018-03-07 18:14:04 --> Form Validation Class Initialized
INFO - 2018-03-07 18:14:04 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:04 --> Helper loaded: url_helper
INFO - 2018-03-07 18:14:04 --> Model Class Initialized
INFO - 2018-03-07 18:14:04 --> Model Class Initialized
DEBUG - 2018-03-07 18:14:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-07 18:14:04 --> Config Class Initialized
INFO - 2018-03-07 18:14:04 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:14:04 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:14:04 --> Utf8 Class Initialized
INFO - 2018-03-07 18:14:04 --> URI Class Initialized
INFO - 2018-03-07 18:14:04 --> Router Class Initialized
INFO - 2018-03-07 18:14:04 --> Output Class Initialized
INFO - 2018-03-07 18:14:04 --> Security Class Initialized
DEBUG - 2018-03-07 18:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:14:04 --> Input Class Initialized
INFO - 2018-03-07 18:14:04 --> Language Class Initialized
INFO - 2018-03-07 18:14:04 --> Loader Class Initialized
INFO - 2018-03-07 18:14:04 --> Helper loaded: common_helper
INFO - 2018-03-07 18:14:04 --> Database Driver Class Initialized
INFO - 2018-03-07 18:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:14:04 --> Email Class Initialized
INFO - 2018-03-07 18:14:04 --> Controller Class Initialized
INFO - 2018-03-07 18:14:04 --> Helper loaded: form_helper
INFO - 2018-03-07 18:14:04 --> Form Validation Class Initialized
INFO - 2018-03-07 18:14:04 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:14:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:04 --> Helper loaded: url_helper
INFO - 2018-03-07 18:14:04 --> Model Class Initialized
INFO - 2018-03-07 18:14:04 --> Model Class Initialized
INFO - 2018-03-07 18:14:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 18:14:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 18:14:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-07 18:14:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 18:14:05 --> Final output sent to browser
DEBUG - 2018-03-07 18:14:05 --> Total execution time: 0.1650
INFO - 2018-03-07 18:14:09 --> Config Class Initialized
INFO - 2018-03-07 18:14:09 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:14:09 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:14:09 --> Utf8 Class Initialized
INFO - 2018-03-07 18:14:09 --> URI Class Initialized
INFO - 2018-03-07 18:14:09 --> Router Class Initialized
INFO - 2018-03-07 18:14:09 --> Output Class Initialized
INFO - 2018-03-07 18:14:09 --> Security Class Initialized
DEBUG - 2018-03-07 18:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:14:09 --> Input Class Initialized
INFO - 2018-03-07 18:14:09 --> Language Class Initialized
INFO - 2018-03-07 18:14:09 --> Loader Class Initialized
INFO - 2018-03-07 18:14:09 --> Helper loaded: common_helper
INFO - 2018-03-07 18:14:09 --> Database Driver Class Initialized
INFO - 2018-03-07 18:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:14:09 --> Email Class Initialized
INFO - 2018-03-07 18:14:09 --> Controller Class Initialized
INFO - 2018-03-07 18:14:09 --> Helper loaded: form_helper
INFO - 2018-03-07 18:14:09 --> Form Validation Class Initialized
INFO - 2018-03-07 18:14:09 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:14:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:10 --> Helper loaded: url_helper
INFO - 2018-03-07 18:14:10 --> Model Class Initialized
INFO - 2018-03-07 18:14:10 --> Model Class Initialized
INFO - 2018-03-07 18:14:10 --> Model Class Initialized
INFO - 2018-03-07 22:44:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:44:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:44:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:10 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:10 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-07 22:44:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-07 22:44:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:44:10 --> Final output sent to browser
DEBUG - 2018-03-07 22:44:10 --> Total execution time: 0.3290
INFO - 2018-03-07 18:14:18 --> Config Class Initialized
INFO - 2018-03-07 18:14:18 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:14:18 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:14:18 --> Utf8 Class Initialized
INFO - 2018-03-07 18:14:18 --> URI Class Initialized
INFO - 2018-03-07 18:14:18 --> Router Class Initialized
INFO - 2018-03-07 18:14:18 --> Output Class Initialized
INFO - 2018-03-07 18:14:18 --> Security Class Initialized
DEBUG - 2018-03-07 18:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:14:18 --> Input Class Initialized
INFO - 2018-03-07 18:14:18 --> Language Class Initialized
INFO - 2018-03-07 18:14:18 --> Loader Class Initialized
INFO - 2018-03-07 18:14:18 --> Helper loaded: common_helper
INFO - 2018-03-07 18:14:18 --> Database Driver Class Initialized
INFO - 2018-03-07 18:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:14:18 --> Email Class Initialized
INFO - 2018-03-07 18:14:18 --> Controller Class Initialized
INFO - 2018-03-07 18:14:18 --> Helper loaded: form_helper
INFO - 2018-03-07 18:14:18 --> Form Validation Class Initialized
INFO - 2018-03-07 18:14:18 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:18 --> Helper loaded: url_helper
INFO - 2018-03-07 18:14:18 --> Model Class Initialized
INFO - 2018-03-07 18:14:18 --> Model Class Initialized
INFO - 2018-03-07 18:14:18 --> Model Class Initialized
INFO - 2018-03-07 22:44:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:44:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:44:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 22:44:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-07 22:44:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 22:44:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:44:18 --> Final output sent to browser
DEBUG - 2018-03-07 22:44:18 --> Total execution time: 0.2280
INFO - 2018-03-07 18:14:35 --> Config Class Initialized
INFO - 2018-03-07 18:14:35 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:14:35 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:14:35 --> Utf8 Class Initialized
INFO - 2018-03-07 18:14:35 --> URI Class Initialized
INFO - 2018-03-07 18:14:35 --> Router Class Initialized
INFO - 2018-03-07 18:14:35 --> Output Class Initialized
INFO - 2018-03-07 18:14:35 --> Security Class Initialized
DEBUG - 2018-03-07 18:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:14:35 --> Input Class Initialized
INFO - 2018-03-07 18:14:35 --> Language Class Initialized
INFO - 2018-03-07 18:14:35 --> Loader Class Initialized
INFO - 2018-03-07 18:14:35 --> Helper loaded: common_helper
INFO - 2018-03-07 18:14:35 --> Database Driver Class Initialized
INFO - 2018-03-07 18:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:14:35 --> Email Class Initialized
INFO - 2018-03-07 18:14:35 --> Controller Class Initialized
INFO - 2018-03-07 18:14:35 --> Helper loaded: form_helper
INFO - 2018-03-07 18:14:35 --> Form Validation Class Initialized
INFO - 2018-03-07 18:14:35 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:35 --> Helper loaded: url_helper
INFO - 2018-03-07 18:14:35 --> Model Class Initialized
INFO - 2018-03-07 18:14:35 --> Model Class Initialized
INFO - 2018-03-07 18:14:35 --> Model Class Initialized
INFO - 2018-03-07 22:44:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:44:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:44:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:44:36 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:44:36 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-07 22:44:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-07 22:44:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:44:36 --> Final output sent to browser
DEBUG - 2018-03-07 22:44:36 --> Total execution time: 0.3760
INFO - 2018-03-07 18:14:46 --> Config Class Initialized
INFO - 2018-03-07 18:14:46 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:14:46 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:14:46 --> Utf8 Class Initialized
INFO - 2018-03-07 18:14:46 --> URI Class Initialized
INFO - 2018-03-07 18:14:46 --> Router Class Initialized
INFO - 2018-03-07 18:14:46 --> Output Class Initialized
INFO - 2018-03-07 18:14:46 --> Security Class Initialized
DEBUG - 2018-03-07 18:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:14:46 --> Input Class Initialized
INFO - 2018-03-07 18:14:46 --> Language Class Initialized
INFO - 2018-03-07 18:14:46 --> Loader Class Initialized
INFO - 2018-03-07 18:14:46 --> Helper loaded: common_helper
INFO - 2018-03-07 18:14:46 --> Database Driver Class Initialized
INFO - 2018-03-07 18:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:14:46 --> Email Class Initialized
INFO - 2018-03-07 18:14:46 --> Controller Class Initialized
INFO - 2018-03-07 18:14:46 --> Helper loaded: form_helper
INFO - 2018-03-07 18:14:46 --> Form Validation Class Initialized
INFO - 2018-03-07 18:14:46 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:14:46 --> Helper loaded: url_helper
INFO - 2018-03-07 18:14:46 --> Model Class Initialized
INFO - 2018-03-07 18:14:46 --> Model Class Initialized
INFO - 2018-03-07 18:14:46 --> Model Class Initialized
INFO - 2018-03-07 22:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-07 22:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 22:44:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:44:47 --> Final output sent to browser
DEBUG - 2018-03-07 22:44:47 --> Total execution time: 0.3480
INFO - 2018-03-07 18:21:13 --> Config Class Initialized
INFO - 2018-03-07 18:21:13 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:21:13 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:21:13 --> Utf8 Class Initialized
INFO - 2018-03-07 18:21:13 --> URI Class Initialized
INFO - 2018-03-07 18:21:14 --> Router Class Initialized
INFO - 2018-03-07 18:21:14 --> Output Class Initialized
INFO - 2018-03-07 18:21:14 --> Security Class Initialized
DEBUG - 2018-03-07 18:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:21:14 --> Input Class Initialized
INFO - 2018-03-07 18:21:14 --> Language Class Initialized
INFO - 2018-03-07 18:21:14 --> Loader Class Initialized
INFO - 2018-03-07 18:21:14 --> Helper loaded: common_helper
INFO - 2018-03-07 18:21:14 --> Database Driver Class Initialized
INFO - 2018-03-07 18:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:21:14 --> Email Class Initialized
INFO - 2018-03-07 18:21:14 --> Controller Class Initialized
INFO - 2018-03-07 18:21:14 --> Helper loaded: form_helper
INFO - 2018-03-07 18:21:14 --> Form Validation Class Initialized
INFO - 2018-03-07 18:21:14 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:21:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:21:14 --> Helper loaded: url_helper
INFO - 2018-03-07 18:21:14 --> Model Class Initialized
INFO - 2018-03-07 18:21:14 --> Model Class Initialized
INFO - 2018-03-07 18:21:14 --> Model Class Initialized
INFO - 2018-03-07 22:51:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:51:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:51:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-07 22:51:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 22:51:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:51:14 --> Final output sent to browser
DEBUG - 2018-03-07 22:51:14 --> Total execution time: 0.3790
INFO - 2018-03-07 18:24:21 --> Config Class Initialized
INFO - 2018-03-07 18:24:21 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:24:21 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:24:21 --> Utf8 Class Initialized
INFO - 2018-03-07 18:24:21 --> URI Class Initialized
INFO - 2018-03-07 18:24:21 --> Router Class Initialized
INFO - 2018-03-07 18:24:21 --> Output Class Initialized
INFO - 2018-03-07 18:24:21 --> Security Class Initialized
DEBUG - 2018-03-07 18:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:24:21 --> Input Class Initialized
INFO - 2018-03-07 18:24:21 --> Language Class Initialized
INFO - 2018-03-07 18:24:21 --> Loader Class Initialized
INFO - 2018-03-07 18:24:21 --> Helper loaded: common_helper
INFO - 2018-03-07 18:24:21 --> Database Driver Class Initialized
INFO - 2018-03-07 18:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:24:21 --> Email Class Initialized
INFO - 2018-03-07 18:24:21 --> Controller Class Initialized
INFO - 2018-03-07 18:24:21 --> Helper loaded: form_helper
INFO - 2018-03-07 18:24:21 --> Form Validation Class Initialized
INFO - 2018-03-07 18:24:21 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:24:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:24:21 --> Helper loaded: url_helper
INFO - 2018-03-07 18:24:21 --> Model Class Initialized
INFO - 2018-03-07 18:24:21 --> Model Class Initialized
INFO - 2018-03-07 18:24:21 --> Model Class Initialized
INFO - 2018-03-07 22:54:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:54:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:54:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-07 22:54:21 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:21 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:21 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:21 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:21 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:21 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:21 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:21 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:21 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:21 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-07 22:54:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-07 22:54:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-07 22:54:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-07 22:54:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:54:22 --> Final output sent to browser
DEBUG - 2018-03-07 22:54:22 --> Total execution time: 0.1970
INFO - 2018-03-07 18:24:25 --> Config Class Initialized
INFO - 2018-03-07 18:24:25 --> Hooks Class Initialized
DEBUG - 2018-03-07 18:24:25 --> UTF-8 Support Enabled
INFO - 2018-03-07 18:24:25 --> Utf8 Class Initialized
INFO - 2018-03-07 18:24:25 --> URI Class Initialized
INFO - 2018-03-07 18:24:25 --> Router Class Initialized
INFO - 2018-03-07 18:24:25 --> Output Class Initialized
INFO - 2018-03-07 18:24:25 --> Security Class Initialized
DEBUG - 2018-03-07 18:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-07 18:24:25 --> Input Class Initialized
INFO - 2018-03-07 18:24:25 --> Language Class Initialized
INFO - 2018-03-07 18:24:25 --> Loader Class Initialized
INFO - 2018-03-07 18:24:25 --> Helper loaded: common_helper
INFO - 2018-03-07 18:24:25 --> Database Driver Class Initialized
INFO - 2018-03-07 18:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-07 18:24:25 --> Email Class Initialized
INFO - 2018-03-07 18:24:25 --> Controller Class Initialized
INFO - 2018-03-07 18:24:25 --> Helper loaded: form_helper
INFO - 2018-03-07 18:24:25 --> Form Validation Class Initialized
INFO - 2018-03-07 18:24:25 --> Helper loaded: email_helper
DEBUG - 2018-03-07 18:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-07 18:24:25 --> Helper loaded: url_helper
INFO - 2018-03-07 18:24:25 --> Model Class Initialized
INFO - 2018-03-07 18:24:25 --> Model Class Initialized
INFO - 2018-03-07 18:24:25 --> Model Class Initialized
INFO - 2018-03-07 22:54:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-07 22:54:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-07 22:54:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 22:54:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-07 22:54:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-07 22:54:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-07 22:54:25 --> Final output sent to browser
DEBUG - 2018-03-07 22:54:25 --> Total execution time: 0.1310
