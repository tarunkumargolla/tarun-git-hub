<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-08 06:46:36 --> Config Class Initialized
INFO - 2018-03-08 06:46:36 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:36 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:36 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:36 --> URI Class Initialized
INFO - 2018-03-08 06:46:36 --> Router Class Initialized
INFO - 2018-03-08 06:46:36 --> Output Class Initialized
INFO - 2018-03-08 06:46:36 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:36 --> Input Class Initialized
INFO - 2018-03-08 06:46:36 --> Language Class Initialized
INFO - 2018-03-08 06:46:36 --> Loader Class Initialized
INFO - 2018-03-08 06:46:36 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:36 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:36 --> Email Class Initialized
INFO - 2018-03-08 06:46:36 --> Controller Class Initialized
INFO - 2018-03-08 06:46:36 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:36 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:36 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:36 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:36 --> Model Class Initialized
INFO - 2018-03-08 06:46:36 --> Model Class Initialized
INFO - 2018-03-08 06:46:36 --> Model Class Initialized
INFO - 2018-03-08 06:46:38 --> Config Class Initialized
INFO - 2018-03-08 06:46:38 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:38 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:38 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:38 --> URI Class Initialized
INFO - 2018-03-08 06:46:38 --> Router Class Initialized
INFO - 2018-03-08 06:46:38 --> Output Class Initialized
INFO - 2018-03-08 06:46:38 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:38 --> Input Class Initialized
INFO - 2018-03-08 06:46:38 --> Language Class Initialized
INFO - 2018-03-08 06:46:38 --> Loader Class Initialized
INFO - 2018-03-08 06:46:38 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:38 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:38 --> Email Class Initialized
INFO - 2018-03-08 06:46:38 --> Controller Class Initialized
INFO - 2018-03-08 06:46:38 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:38 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:38 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:38 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:38 --> Model Class Initialized
INFO - 2018-03-08 06:46:38 --> Model Class Initialized
INFO - 2018-03-08 06:46:38 --> Config Class Initialized
INFO - 2018-03-08 06:46:38 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:38 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:38 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:38 --> URI Class Initialized
DEBUG - 2018-03-08 06:46:38 --> No URI present. Default controller set.
INFO - 2018-03-08 06:46:38 --> Router Class Initialized
INFO - 2018-03-08 06:46:38 --> Output Class Initialized
INFO - 2018-03-08 06:46:38 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:38 --> Input Class Initialized
INFO - 2018-03-08 06:46:38 --> Language Class Initialized
INFO - 2018-03-08 06:46:38 --> Loader Class Initialized
INFO - 2018-03-08 06:46:38 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:38 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:38 --> Email Class Initialized
INFO - 2018-03-08 06:46:38 --> Controller Class Initialized
INFO - 2018-03-08 06:46:38 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:38 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:38 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:38 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:38 --> Model Class Initialized
INFO - 2018-03-08 06:46:38 --> Model Class Initialized
INFO - 2018-03-08 06:46:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-08 06:46:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 06:46:38 --> Final output sent to browser
DEBUG - 2018-03-08 06:46:38 --> Total execution time: 0.3880
INFO - 2018-03-08 06:46:41 --> Config Class Initialized
INFO - 2018-03-08 06:46:41 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:41 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:41 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:41 --> URI Class Initialized
DEBUG - 2018-03-08 06:46:41 --> No URI present. Default controller set.
INFO - 2018-03-08 06:46:41 --> Router Class Initialized
INFO - 2018-03-08 06:46:41 --> Output Class Initialized
INFO - 2018-03-08 06:46:41 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:41 --> Input Class Initialized
INFO - 2018-03-08 06:46:41 --> Language Class Initialized
INFO - 2018-03-08 06:46:41 --> Loader Class Initialized
INFO - 2018-03-08 06:46:41 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:41 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:42 --> Email Class Initialized
INFO - 2018-03-08 06:46:42 --> Controller Class Initialized
INFO - 2018-03-08 06:46:42 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:42 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:42 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:42 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:42 --> Model Class Initialized
INFO - 2018-03-08 06:46:42 --> Model Class Initialized
DEBUG - 2018-03-08 06:46:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-08 06:46:42 --> Config Class Initialized
INFO - 2018-03-08 06:46:42 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:42 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:42 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:42 --> URI Class Initialized
INFO - 2018-03-08 06:46:42 --> Router Class Initialized
INFO - 2018-03-08 06:46:42 --> Output Class Initialized
INFO - 2018-03-08 06:46:42 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:42 --> Input Class Initialized
INFO - 2018-03-08 06:46:42 --> Language Class Initialized
INFO - 2018-03-08 06:46:42 --> Loader Class Initialized
INFO - 2018-03-08 06:46:42 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:42 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:42 --> Email Class Initialized
INFO - 2018-03-08 06:46:42 --> Controller Class Initialized
INFO - 2018-03-08 06:46:42 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:42 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:42 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:42 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:42 --> Model Class Initialized
INFO - 2018-03-08 06:46:42 --> Model Class Initialized
INFO - 2018-03-08 06:46:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 06:46:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 06:46:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-08 06:46:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 06:46:42 --> Final output sent to browser
DEBUG - 2018-03-08 06:46:42 --> Total execution time: 0.2710
INFO - 2018-03-08 06:46:47 --> Config Class Initialized
INFO - 2018-03-08 06:46:47 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:47 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:47 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:47 --> URI Class Initialized
INFO - 2018-03-08 06:46:47 --> Router Class Initialized
INFO - 2018-03-08 06:46:47 --> Output Class Initialized
INFO - 2018-03-08 06:46:47 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:47 --> Input Class Initialized
INFO - 2018-03-08 06:46:47 --> Language Class Initialized
INFO - 2018-03-08 06:46:47 --> Loader Class Initialized
INFO - 2018-03-08 06:46:47 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:47 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:47 --> Email Class Initialized
INFO - 2018-03-08 06:46:47 --> Controller Class Initialized
INFO - 2018-03-08 06:46:47 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:47 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:47 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:47 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:47 --> Model Class Initialized
INFO - 2018-03-08 06:46:47 --> Model Class Initialized
INFO - 2018-03-08 06:46:47 --> Model Class Initialized
INFO - 2018-03-08 11:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 11:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 11:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:16:47 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:16:47 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-08 11:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-08 11:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 11:16:47 --> Final output sent to browser
DEBUG - 2018-03-08 11:16:47 --> Total execution time: 0.1520
INFO - 2018-03-08 06:46:59 --> Config Class Initialized
INFO - 2018-03-08 06:46:59 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:46:59 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:46:59 --> Utf8 Class Initialized
INFO - 2018-03-08 06:46:59 --> URI Class Initialized
INFO - 2018-03-08 06:46:59 --> Router Class Initialized
INFO - 2018-03-08 06:46:59 --> Output Class Initialized
INFO - 2018-03-08 06:46:59 --> Security Class Initialized
DEBUG - 2018-03-08 06:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:46:59 --> Input Class Initialized
INFO - 2018-03-08 06:46:59 --> Language Class Initialized
INFO - 2018-03-08 06:46:59 --> Loader Class Initialized
INFO - 2018-03-08 06:46:59 --> Helper loaded: common_helper
INFO - 2018-03-08 06:46:59 --> Database Driver Class Initialized
INFO - 2018-03-08 06:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:46:59 --> Email Class Initialized
INFO - 2018-03-08 06:46:59 --> Controller Class Initialized
INFO - 2018-03-08 06:46:59 --> Helper loaded: form_helper
INFO - 2018-03-08 06:46:59 --> Form Validation Class Initialized
INFO - 2018-03-08 06:46:59 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:46:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:46:59 --> Helper loaded: url_helper
INFO - 2018-03-08 06:46:59 --> Model Class Initialized
INFO - 2018-03-08 06:46:59 --> Model Class Initialized
INFO - 2018-03-08 06:46:59 --> Model Class Initialized
INFO - 2018-03-08 11:16:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 11:16:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 11:16:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-08 11:16:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-08 11:16:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-08 11:16:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 11:16:59 --> Final output sent to browser
DEBUG - 2018-03-08 11:16:59 --> Total execution time: 0.2170
INFO - 2018-03-08 06:47:11 --> Config Class Initialized
INFO - 2018-03-08 06:47:11 --> Hooks Class Initialized
DEBUG - 2018-03-08 06:47:11 --> UTF-8 Support Enabled
INFO - 2018-03-08 06:47:11 --> Utf8 Class Initialized
INFO - 2018-03-08 06:47:11 --> URI Class Initialized
INFO - 2018-03-08 06:47:11 --> Router Class Initialized
INFO - 2018-03-08 06:47:11 --> Output Class Initialized
INFO - 2018-03-08 06:47:11 --> Security Class Initialized
DEBUG - 2018-03-08 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 06:47:11 --> Input Class Initialized
INFO - 2018-03-08 06:47:11 --> Language Class Initialized
INFO - 2018-03-08 06:47:11 --> Loader Class Initialized
INFO - 2018-03-08 06:47:11 --> Helper loaded: common_helper
INFO - 2018-03-08 06:47:11 --> Database Driver Class Initialized
INFO - 2018-03-08 06:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 06:47:11 --> Email Class Initialized
INFO - 2018-03-08 06:47:11 --> Controller Class Initialized
INFO - 2018-03-08 06:47:11 --> Helper loaded: form_helper
INFO - 2018-03-08 06:47:11 --> Form Validation Class Initialized
INFO - 2018-03-08 06:47:11 --> Helper loaded: email_helper
DEBUG - 2018-03-08 06:47:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 06:47:11 --> Helper loaded: url_helper
INFO - 2018-03-08 06:47:11 --> Model Class Initialized
INFO - 2018-03-08 06:47:11 --> Model Class Initialized
INFO - 2018-03-08 06:47:11 --> Model Class Initialized
INFO - 2018-03-08 11:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 11:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 11:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 11:17:11 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 11:17:11 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-08 11:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-08 11:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 11:17:11 --> Final output sent to browser
DEBUG - 2018-03-08 11:17:11 --> Total execution time: 0.4440
INFO - 2018-03-08 08:25:15 --> Config Class Initialized
INFO - 2018-03-08 08:25:15 --> Hooks Class Initialized
DEBUG - 2018-03-08 08:25:15 --> UTF-8 Support Enabled
INFO - 2018-03-08 08:25:15 --> Utf8 Class Initialized
INFO - 2018-03-08 08:25:15 --> URI Class Initialized
INFO - 2018-03-08 08:25:15 --> Router Class Initialized
INFO - 2018-03-08 08:25:15 --> Output Class Initialized
INFO - 2018-03-08 08:25:15 --> Security Class Initialized
DEBUG - 2018-03-08 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 08:25:15 --> Input Class Initialized
INFO - 2018-03-08 08:25:15 --> Language Class Initialized
INFO - 2018-03-08 08:25:15 --> Loader Class Initialized
INFO - 2018-03-08 08:25:15 --> Helper loaded: common_helper
INFO - 2018-03-08 08:25:15 --> Database Driver Class Initialized
INFO - 2018-03-08 08:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 08:25:15 --> Email Class Initialized
INFO - 2018-03-08 08:25:15 --> Controller Class Initialized
INFO - 2018-03-08 08:25:15 --> Helper loaded: form_helper
INFO - 2018-03-08 08:25:15 --> Form Validation Class Initialized
INFO - 2018-03-08 08:25:15 --> Helper loaded: email_helper
DEBUG - 2018-03-08 08:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 08:25:15 --> Helper loaded: url_helper
INFO - 2018-03-08 08:25:15 --> Model Class Initialized
INFO - 2018-03-08 13:34:52 --> Config Class Initialized
INFO - 2018-03-08 13:34:52 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:34:52 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:34:52 --> Utf8 Class Initialized
INFO - 2018-03-08 13:34:52 --> URI Class Initialized
INFO - 2018-03-08 13:34:52 --> Router Class Initialized
INFO - 2018-03-08 13:34:52 --> Output Class Initialized
INFO - 2018-03-08 13:34:52 --> Security Class Initialized
DEBUG - 2018-03-08 13:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:34:52 --> Input Class Initialized
INFO - 2018-03-08 13:34:52 --> Language Class Initialized
INFO - 2018-03-08 13:34:52 --> Loader Class Initialized
INFO - 2018-03-08 13:34:52 --> Helper loaded: common_helper
INFO - 2018-03-08 13:34:52 --> Database Driver Class Initialized
ERROR - 2018-03-08 13:34:53 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-08 13:34:53 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-08 13:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 13:34:53 --> Email Class Initialized
INFO - 2018-03-08 13:34:53 --> Controller Class Initialized
INFO - 2018-03-08 13:34:53 --> Helper loaded: form_helper
INFO - 2018-03-08 13:34:53 --> Form Validation Class Initialized
INFO - 2018-03-08 13:34:53 --> Helper loaded: email_helper
DEBUG - 2018-03-08 13:34:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 13:34:53 --> Helper loaded: url_helper
INFO - 2018-03-08 13:34:53 --> Model Class Initialized
INFO - 2018-03-08 13:34:53 --> Model Class Initialized
INFO - 2018-03-08 13:34:55 --> Config Class Initialized
INFO - 2018-03-08 13:34:55 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:34:55 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:34:55 --> Utf8 Class Initialized
INFO - 2018-03-08 13:34:55 --> URI Class Initialized
INFO - 2018-03-08 13:34:55 --> Router Class Initialized
INFO - 2018-03-08 13:34:55 --> Output Class Initialized
INFO - 2018-03-08 13:34:55 --> Security Class Initialized
DEBUG - 2018-03-08 13:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:34:55 --> Input Class Initialized
INFO - 2018-03-08 13:34:55 --> Language Class Initialized
INFO - 2018-03-08 13:34:55 --> Loader Class Initialized
INFO - 2018-03-08 13:34:55 --> Helper loaded: common_helper
INFO - 2018-03-08 13:34:55 --> Database Driver Class Initialized
INFO - 2018-03-08 13:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 13:34:55 --> Email Class Initialized
INFO - 2018-03-08 13:34:55 --> Controller Class Initialized
INFO - 2018-03-08 13:34:55 --> Helper loaded: form_helper
INFO - 2018-03-08 13:34:55 --> Form Validation Class Initialized
INFO - 2018-03-08 13:34:55 --> Helper loaded: email_helper
DEBUG - 2018-03-08 13:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 13:34:55 --> Helper loaded: url_helper
INFO - 2018-03-08 13:34:55 --> Model Class Initialized
INFO - 2018-03-08 13:34:55 --> Model Class Initialized
INFO - 2018-03-08 13:34:55 --> Config Class Initialized
INFO - 2018-03-08 13:34:55 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:34:55 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:34:55 --> Utf8 Class Initialized
INFO - 2018-03-08 13:34:55 --> URI Class Initialized
DEBUG - 2018-03-08 13:34:55 --> No URI present. Default controller set.
INFO - 2018-03-08 13:34:55 --> Router Class Initialized
INFO - 2018-03-08 13:34:55 --> Output Class Initialized
INFO - 2018-03-08 13:34:55 --> Security Class Initialized
DEBUG - 2018-03-08 13:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:34:55 --> Input Class Initialized
INFO - 2018-03-08 13:34:55 --> Language Class Initialized
INFO - 2018-03-08 13:34:55 --> Loader Class Initialized
INFO - 2018-03-08 13:34:55 --> Helper loaded: common_helper
INFO - 2018-03-08 13:34:55 --> Database Driver Class Initialized
INFO - 2018-03-08 13:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 13:34:55 --> Email Class Initialized
INFO - 2018-03-08 13:34:55 --> Controller Class Initialized
INFO - 2018-03-08 13:34:55 --> Helper loaded: form_helper
INFO - 2018-03-08 13:34:55 --> Form Validation Class Initialized
INFO - 2018-03-08 13:34:55 --> Helper loaded: email_helper
DEBUG - 2018-03-08 13:34:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 13:34:55 --> Helper loaded: url_helper
INFO - 2018-03-08 13:34:55 --> Model Class Initialized
INFO - 2018-03-08 13:34:55 --> Model Class Initialized
INFO - 2018-03-08 13:34:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-08 13:34:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 13:34:55 --> Final output sent to browser
DEBUG - 2018-03-08 13:34:55 --> Total execution time: 0.4300
INFO - 2018-03-08 13:34:58 --> Config Class Initialized
INFO - 2018-03-08 13:34:58 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:34:58 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:34:58 --> Utf8 Class Initialized
INFO - 2018-03-08 13:34:58 --> URI Class Initialized
DEBUG - 2018-03-08 13:34:58 --> No URI present. Default controller set.
INFO - 2018-03-08 13:34:58 --> Router Class Initialized
INFO - 2018-03-08 13:34:58 --> Output Class Initialized
INFO - 2018-03-08 13:34:58 --> Security Class Initialized
DEBUG - 2018-03-08 13:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:34:58 --> Input Class Initialized
INFO - 2018-03-08 13:34:58 --> Language Class Initialized
INFO - 2018-03-08 13:34:58 --> Loader Class Initialized
INFO - 2018-03-08 13:34:58 --> Helper loaded: common_helper
INFO - 2018-03-08 13:34:58 --> Database Driver Class Initialized
INFO - 2018-03-08 13:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 13:34:58 --> Email Class Initialized
INFO - 2018-03-08 13:34:58 --> Controller Class Initialized
INFO - 2018-03-08 13:34:58 --> Helper loaded: form_helper
INFO - 2018-03-08 13:34:58 --> Form Validation Class Initialized
INFO - 2018-03-08 13:34:58 --> Helper loaded: email_helper
DEBUG - 2018-03-08 13:34:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 13:34:58 --> Helper loaded: url_helper
INFO - 2018-03-08 13:34:58 --> Model Class Initialized
INFO - 2018-03-08 13:34:58 --> Model Class Initialized
DEBUG - 2018-03-08 13:34:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 13:34:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-08 13:34:59 --> Config Class Initialized
INFO - 2018-03-08 13:34:59 --> Hooks Class Initialized
DEBUG - 2018-03-08 13:34:59 --> UTF-8 Support Enabled
INFO - 2018-03-08 13:34:59 --> Utf8 Class Initialized
INFO - 2018-03-08 13:34:59 --> URI Class Initialized
INFO - 2018-03-08 13:34:59 --> Router Class Initialized
INFO - 2018-03-08 13:34:59 --> Output Class Initialized
INFO - 2018-03-08 13:34:59 --> Security Class Initialized
DEBUG - 2018-03-08 13:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 13:34:59 --> Input Class Initialized
INFO - 2018-03-08 13:34:59 --> Language Class Initialized
INFO - 2018-03-08 13:34:59 --> Loader Class Initialized
INFO - 2018-03-08 13:34:59 --> Helper loaded: common_helper
INFO - 2018-03-08 13:34:59 --> Database Driver Class Initialized
INFO - 2018-03-08 13:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 13:34:59 --> Email Class Initialized
INFO - 2018-03-08 13:34:59 --> Controller Class Initialized
INFO - 2018-03-08 13:34:59 --> Helper loaded: form_helper
INFO - 2018-03-08 13:34:59 --> Form Validation Class Initialized
INFO - 2018-03-08 13:34:59 --> Helper loaded: email_helper
DEBUG - 2018-03-08 13:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 13:34:59 --> Helper loaded: url_helper
INFO - 2018-03-08 13:34:59 --> Model Class Initialized
INFO - 2018-03-08 13:34:59 --> Model Class Initialized
INFO - 2018-03-08 13:34:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 13:34:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 13:34:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-08 13:34:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 13:34:59 --> Final output sent to browser
DEBUG - 2018-03-08 13:34:59 --> Total execution time: 0.2630
INFO - 2018-03-08 18:23:50 --> Config Class Initialized
INFO - 2018-03-08 18:23:50 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:23:50 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:23:50 --> Utf8 Class Initialized
INFO - 2018-03-08 18:23:50 --> URI Class Initialized
INFO - 2018-03-08 18:23:50 --> Router Class Initialized
INFO - 2018-03-08 18:23:50 --> Output Class Initialized
INFO - 2018-03-08 18:23:50 --> Security Class Initialized
DEBUG - 2018-03-08 18:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:23:50 --> Input Class Initialized
INFO - 2018-03-08 18:23:50 --> Language Class Initialized
INFO - 2018-03-08 18:23:50 --> Loader Class Initialized
INFO - 2018-03-08 18:23:50 --> Helper loaded: common_helper
INFO - 2018-03-08 18:23:50 --> Database Driver Class Initialized
ERROR - 2018-03-08 18:23:50 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-08 18:23:50 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-08 18:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:23:50 --> Email Class Initialized
INFO - 2018-03-08 18:23:50 --> Controller Class Initialized
INFO - 2018-03-08 18:23:50 --> Helper loaded: form_helper
INFO - 2018-03-08 18:23:50 --> Form Validation Class Initialized
INFO - 2018-03-08 18:23:50 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:23:50 --> Helper loaded: url_helper
INFO - 2018-03-08 18:23:50 --> Model Class Initialized
INFO - 2018-03-08 18:23:50 --> Model Class Initialized
INFO - 2018-03-08 18:23:51 --> Config Class Initialized
INFO - 2018-03-08 18:23:51 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:23:51 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:23:51 --> Utf8 Class Initialized
INFO - 2018-03-08 18:23:52 --> URI Class Initialized
INFO - 2018-03-08 18:23:52 --> Router Class Initialized
INFO - 2018-03-08 18:23:52 --> Output Class Initialized
INFO - 2018-03-08 18:23:52 --> Security Class Initialized
DEBUG - 2018-03-08 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:23:52 --> Input Class Initialized
INFO - 2018-03-08 18:23:52 --> Language Class Initialized
INFO - 2018-03-08 18:23:52 --> Loader Class Initialized
INFO - 2018-03-08 18:23:52 --> Helper loaded: common_helper
INFO - 2018-03-08 18:23:52 --> Database Driver Class Initialized
INFO - 2018-03-08 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:23:52 --> Email Class Initialized
INFO - 2018-03-08 18:23:52 --> Controller Class Initialized
INFO - 2018-03-08 18:23:52 --> Helper loaded: form_helper
INFO - 2018-03-08 18:23:52 --> Form Validation Class Initialized
INFO - 2018-03-08 18:23:52 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:23:52 --> Helper loaded: url_helper
INFO - 2018-03-08 18:23:52 --> Model Class Initialized
INFO - 2018-03-08 18:23:52 --> Model Class Initialized
INFO - 2018-03-08 18:23:52 --> Config Class Initialized
INFO - 2018-03-08 18:23:52 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:23:52 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:23:52 --> Utf8 Class Initialized
INFO - 2018-03-08 18:23:52 --> URI Class Initialized
DEBUG - 2018-03-08 18:23:52 --> No URI present. Default controller set.
INFO - 2018-03-08 18:23:52 --> Router Class Initialized
INFO - 2018-03-08 18:23:52 --> Output Class Initialized
INFO - 2018-03-08 18:23:52 --> Security Class Initialized
DEBUG - 2018-03-08 18:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:23:52 --> Input Class Initialized
INFO - 2018-03-08 18:23:52 --> Language Class Initialized
INFO - 2018-03-08 18:23:52 --> Loader Class Initialized
INFO - 2018-03-08 18:23:52 --> Helper loaded: common_helper
INFO - 2018-03-08 18:23:52 --> Database Driver Class Initialized
INFO - 2018-03-08 18:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:23:52 --> Email Class Initialized
INFO - 2018-03-08 18:23:52 --> Controller Class Initialized
INFO - 2018-03-08 18:23:52 --> Helper loaded: form_helper
INFO - 2018-03-08 18:23:52 --> Form Validation Class Initialized
INFO - 2018-03-08 18:23:52 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:23:52 --> Helper loaded: url_helper
INFO - 2018-03-08 18:23:52 --> Model Class Initialized
INFO - 2018-03-08 18:23:52 --> Model Class Initialized
INFO - 2018-03-08 18:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-08 18:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 18:23:52 --> Final output sent to browser
DEBUG - 2018-03-08 18:23:52 --> Total execution time: 0.2000
INFO - 2018-03-08 18:23:55 --> Config Class Initialized
INFO - 2018-03-08 18:23:55 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:23:55 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:23:55 --> Utf8 Class Initialized
INFO - 2018-03-08 18:23:55 --> URI Class Initialized
DEBUG - 2018-03-08 18:23:55 --> No URI present. Default controller set.
INFO - 2018-03-08 18:23:55 --> Router Class Initialized
INFO - 2018-03-08 18:23:55 --> Output Class Initialized
INFO - 2018-03-08 18:23:55 --> Security Class Initialized
DEBUG - 2018-03-08 18:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:23:55 --> Input Class Initialized
INFO - 2018-03-08 18:23:55 --> Language Class Initialized
INFO - 2018-03-08 18:23:55 --> Loader Class Initialized
INFO - 2018-03-08 18:23:55 --> Helper loaded: common_helper
INFO - 2018-03-08 18:23:55 --> Database Driver Class Initialized
INFO - 2018-03-08 18:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:23:55 --> Email Class Initialized
INFO - 2018-03-08 18:23:55 --> Controller Class Initialized
INFO - 2018-03-08 18:23:55 --> Helper loaded: form_helper
INFO - 2018-03-08 18:23:55 --> Form Validation Class Initialized
INFO - 2018-03-08 18:23:55 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:23:55 --> Helper loaded: url_helper
INFO - 2018-03-08 18:23:55 --> Model Class Initialized
INFO - 2018-03-08 18:23:55 --> Model Class Initialized
DEBUG - 2018-03-08 18:23:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:23:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-08 18:23:57 --> Config Class Initialized
INFO - 2018-03-08 18:23:57 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:23:57 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:23:57 --> Utf8 Class Initialized
INFO - 2018-03-08 18:23:57 --> URI Class Initialized
INFO - 2018-03-08 18:23:57 --> Router Class Initialized
INFO - 2018-03-08 18:23:57 --> Output Class Initialized
INFO - 2018-03-08 18:23:57 --> Security Class Initialized
DEBUG - 2018-03-08 18:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:23:57 --> Input Class Initialized
INFO - 2018-03-08 18:23:57 --> Language Class Initialized
INFO - 2018-03-08 18:23:57 --> Loader Class Initialized
INFO - 2018-03-08 18:23:57 --> Helper loaded: common_helper
INFO - 2018-03-08 18:23:57 --> Database Driver Class Initialized
INFO - 2018-03-08 18:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:23:57 --> Email Class Initialized
INFO - 2018-03-08 18:23:57 --> Controller Class Initialized
INFO - 2018-03-08 18:23:57 --> Helper loaded: form_helper
INFO - 2018-03-08 18:23:57 --> Form Validation Class Initialized
INFO - 2018-03-08 18:23:57 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:23:57 --> Helper loaded: url_helper
INFO - 2018-03-08 18:23:57 --> Model Class Initialized
INFO - 2018-03-08 18:23:57 --> Model Class Initialized
INFO - 2018-03-08 18:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 18:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 18:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-08 18:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 18:23:57 --> Final output sent to browser
DEBUG - 2018-03-08 18:23:57 --> Total execution time: 0.0960
INFO - 2018-03-08 18:24:13 --> Config Class Initialized
INFO - 2018-03-08 18:24:13 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:24:13 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:24:13 --> Utf8 Class Initialized
INFO - 2018-03-08 18:24:13 --> URI Class Initialized
INFO - 2018-03-08 18:24:13 --> Router Class Initialized
INFO - 2018-03-08 18:24:13 --> Output Class Initialized
INFO - 2018-03-08 18:24:13 --> Security Class Initialized
DEBUG - 2018-03-08 18:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:24:13 --> Input Class Initialized
INFO - 2018-03-08 18:24:13 --> Language Class Initialized
INFO - 2018-03-08 18:24:13 --> Loader Class Initialized
INFO - 2018-03-08 18:24:13 --> Helper loaded: common_helper
INFO - 2018-03-08 18:24:13 --> Database Driver Class Initialized
INFO - 2018-03-08 18:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:24:13 --> Email Class Initialized
INFO - 2018-03-08 18:24:13 --> Controller Class Initialized
INFO - 2018-03-08 18:24:13 --> Helper loaded: form_helper
INFO - 2018-03-08 18:24:13 --> Form Validation Class Initialized
INFO - 2018-03-08 18:24:13 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:24:13 --> Helper loaded: url_helper
INFO - 2018-03-08 18:24:13 --> Model Class Initialized
INFO - 2018-03-08 18:25:27 --> Config Class Initialized
INFO - 2018-03-08 18:25:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:25:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:25:27 --> Utf8 Class Initialized
INFO - 2018-03-08 18:25:27 --> URI Class Initialized
INFO - 2018-03-08 18:25:27 --> Router Class Initialized
INFO - 2018-03-08 18:25:27 --> Output Class Initialized
INFO - 2018-03-08 18:25:27 --> Security Class Initialized
DEBUG - 2018-03-08 18:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:25:27 --> Input Class Initialized
INFO - 2018-03-08 18:25:27 --> Language Class Initialized
INFO - 2018-03-08 18:25:27 --> Loader Class Initialized
INFO - 2018-03-08 18:25:27 --> Helper loaded: common_helper
INFO - 2018-03-08 18:25:27 --> Database Driver Class Initialized
INFO - 2018-03-08 18:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:25:27 --> Email Class Initialized
INFO - 2018-03-08 18:25:27 --> Controller Class Initialized
INFO - 2018-03-08 18:25:27 --> Helper loaded: form_helper
INFO - 2018-03-08 18:25:27 --> Form Validation Class Initialized
INFO - 2018-03-08 18:25:27 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:25:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:25:27 --> Helper loaded: url_helper
INFO - 2018-03-08 18:25:27 --> Model Class Initialized
INFO - 2018-03-08 18:25:27 --> Model Class Initialized
INFO - 2018-03-08 18:25:27 --> Model Class Initialized
INFO - 2018-03-08 18:25:28 --> Config Class Initialized
INFO - 2018-03-08 18:25:28 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:25:28 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:25:28 --> Utf8 Class Initialized
INFO - 2018-03-08 18:25:28 --> URI Class Initialized
INFO - 2018-03-08 18:25:28 --> Router Class Initialized
INFO - 2018-03-08 18:25:28 --> Output Class Initialized
INFO - 2018-03-08 18:25:28 --> Security Class Initialized
DEBUG - 2018-03-08 18:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:25:28 --> Input Class Initialized
INFO - 2018-03-08 18:25:28 --> Language Class Initialized
INFO - 2018-03-08 18:25:28 --> Loader Class Initialized
INFO - 2018-03-08 18:25:28 --> Helper loaded: common_helper
INFO - 2018-03-08 18:25:28 --> Database Driver Class Initialized
INFO - 2018-03-08 18:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:25:28 --> Email Class Initialized
INFO - 2018-03-08 18:25:28 --> Controller Class Initialized
INFO - 2018-03-08 18:25:28 --> Helper loaded: form_helper
INFO - 2018-03-08 18:25:28 --> Form Validation Class Initialized
INFO - 2018-03-08 18:25:28 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:25:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:25:28 --> Helper loaded: url_helper
INFO - 2018-03-08 18:25:28 --> Model Class Initialized
INFO - 2018-03-08 18:25:28 --> Model Class Initialized
INFO - 2018-03-08 18:25:28 --> Model Class Initialized
INFO - 2018-03-08 18:26:43 --> Config Class Initialized
INFO - 2018-03-08 18:26:43 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:26:43 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:26:43 --> Utf8 Class Initialized
INFO - 2018-03-08 18:26:43 --> URI Class Initialized
INFO - 2018-03-08 18:26:43 --> Router Class Initialized
INFO - 2018-03-08 18:26:43 --> Output Class Initialized
INFO - 2018-03-08 18:26:43 --> Security Class Initialized
DEBUG - 2018-03-08 18:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:26:43 --> Input Class Initialized
INFO - 2018-03-08 18:26:43 --> Language Class Initialized
INFO - 2018-03-08 18:26:43 --> Loader Class Initialized
INFO - 2018-03-08 18:26:43 --> Helper loaded: common_helper
INFO - 2018-03-08 18:26:43 --> Database Driver Class Initialized
INFO - 2018-03-08 18:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:26:43 --> Email Class Initialized
INFO - 2018-03-08 18:26:43 --> Controller Class Initialized
INFO - 2018-03-08 18:26:43 --> Helper loaded: form_helper
INFO - 2018-03-08 18:26:43 --> Form Validation Class Initialized
INFO - 2018-03-08 18:26:43 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:26:43 --> Helper loaded: url_helper
INFO - 2018-03-08 18:26:43 --> Model Class Initialized
INFO - 2018-03-08 18:26:43 --> Model Class Initialized
INFO - 2018-03-08 18:26:43 --> Model Class Initialized
INFO - 2018-03-08 18:26:44 --> Config Class Initialized
INFO - 2018-03-08 18:26:44 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:26:44 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:26:44 --> Utf8 Class Initialized
INFO - 2018-03-08 18:26:44 --> URI Class Initialized
INFO - 2018-03-08 18:26:44 --> Router Class Initialized
INFO - 2018-03-08 18:26:44 --> Output Class Initialized
INFO - 2018-03-08 18:26:44 --> Security Class Initialized
DEBUG - 2018-03-08 18:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:26:44 --> Input Class Initialized
INFO - 2018-03-08 18:26:44 --> Language Class Initialized
INFO - 2018-03-08 18:26:44 --> Loader Class Initialized
INFO - 2018-03-08 18:26:44 --> Helper loaded: common_helper
INFO - 2018-03-08 18:26:44 --> Database Driver Class Initialized
INFO - 2018-03-08 18:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:26:44 --> Email Class Initialized
INFO - 2018-03-08 18:26:44 --> Controller Class Initialized
INFO - 2018-03-08 18:26:45 --> Helper loaded: form_helper
INFO - 2018-03-08 18:26:45 --> Form Validation Class Initialized
INFO - 2018-03-08 18:26:45 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:26:45 --> Helper loaded: url_helper
INFO - 2018-03-08 18:26:45 --> Model Class Initialized
INFO - 2018-03-08 18:26:45 --> Model Class Initialized
INFO - 2018-03-08 18:26:45 --> Model Class Initialized
INFO - 2018-03-08 18:26:45 --> Config Class Initialized
INFO - 2018-03-08 18:26:45 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:26:45 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:26:45 --> Utf8 Class Initialized
INFO - 2018-03-08 18:26:45 --> URI Class Initialized
INFO - 2018-03-08 18:26:45 --> Router Class Initialized
INFO - 2018-03-08 18:26:45 --> Output Class Initialized
INFO - 2018-03-08 18:26:45 --> Security Class Initialized
DEBUG - 2018-03-08 18:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:26:45 --> Input Class Initialized
INFO - 2018-03-08 18:26:45 --> Language Class Initialized
INFO - 2018-03-08 18:26:45 --> Loader Class Initialized
INFO - 2018-03-08 18:26:45 --> Helper loaded: common_helper
INFO - 2018-03-08 18:26:45 --> Database Driver Class Initialized
INFO - 2018-03-08 18:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:26:45 --> Email Class Initialized
INFO - 2018-03-08 18:26:45 --> Controller Class Initialized
INFO - 2018-03-08 18:26:45 --> Helper loaded: form_helper
INFO - 2018-03-08 18:26:45 --> Form Validation Class Initialized
INFO - 2018-03-08 18:26:45 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:26:45 --> Helper loaded: url_helper
INFO - 2018-03-08 18:26:45 --> Model Class Initialized
INFO - 2018-03-08 18:26:45 --> Model Class Initialized
INFO - 2018-03-08 18:26:45 --> Model Class Initialized
INFO - 2018-03-08 18:26:48 --> Config Class Initialized
INFO - 2018-03-08 18:26:48 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:26:48 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:26:48 --> Utf8 Class Initialized
INFO - 2018-03-08 18:26:48 --> URI Class Initialized
INFO - 2018-03-08 18:26:48 --> Router Class Initialized
INFO - 2018-03-08 18:26:48 --> Output Class Initialized
INFO - 2018-03-08 18:26:48 --> Security Class Initialized
DEBUG - 2018-03-08 18:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:26:48 --> Input Class Initialized
INFO - 2018-03-08 18:26:48 --> Language Class Initialized
INFO - 2018-03-08 18:26:48 --> Loader Class Initialized
INFO - 2018-03-08 18:26:48 --> Helper loaded: common_helper
INFO - 2018-03-08 18:26:48 --> Database Driver Class Initialized
INFO - 2018-03-08 18:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:26:48 --> Email Class Initialized
INFO - 2018-03-08 18:26:48 --> Controller Class Initialized
INFO - 2018-03-08 18:26:48 --> Helper loaded: form_helper
INFO - 2018-03-08 18:26:48 --> Form Validation Class Initialized
INFO - 2018-03-08 18:26:48 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:26:48 --> Helper loaded: url_helper
INFO - 2018-03-08 18:26:48 --> Model Class Initialized
INFO - 2018-03-08 18:26:48 --> Model Class Initialized
INFO - 2018-03-08 18:26:48 --> Model Class Initialized
INFO - 2018-03-08 18:26:48 --> Config Class Initialized
INFO - 2018-03-08 18:26:48 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:26:48 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:26:48 --> Utf8 Class Initialized
INFO - 2018-03-08 18:26:48 --> URI Class Initialized
INFO - 2018-03-08 18:26:48 --> Router Class Initialized
INFO - 2018-03-08 18:26:48 --> Output Class Initialized
INFO - 2018-03-08 18:26:48 --> Security Class Initialized
DEBUG - 2018-03-08 18:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:26:48 --> Input Class Initialized
INFO - 2018-03-08 18:26:48 --> Language Class Initialized
INFO - 2018-03-08 18:26:48 --> Loader Class Initialized
INFO - 2018-03-08 18:26:48 --> Helper loaded: common_helper
INFO - 2018-03-08 18:26:48 --> Database Driver Class Initialized
INFO - 2018-03-08 18:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:26:49 --> Email Class Initialized
INFO - 2018-03-08 18:26:49 --> Controller Class Initialized
INFO - 2018-03-08 18:26:49 --> Helper loaded: form_helper
INFO - 2018-03-08 18:26:49 --> Form Validation Class Initialized
INFO - 2018-03-08 18:26:49 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:26:49 --> Helper loaded: url_helper
INFO - 2018-03-08 18:26:49 --> Model Class Initialized
INFO - 2018-03-08 18:26:49 --> Model Class Initialized
INFO - 2018-03-08 18:26:49 --> Model Class Initialized
INFO - 2018-03-08 18:27:27 --> Config Class Initialized
INFO - 2018-03-08 18:27:27 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:27:27 --> Utf8 Class Initialized
INFO - 2018-03-08 18:27:27 --> URI Class Initialized
INFO - 2018-03-08 18:27:27 --> Router Class Initialized
INFO - 2018-03-08 18:27:27 --> Output Class Initialized
INFO - 2018-03-08 18:27:27 --> Security Class Initialized
DEBUG - 2018-03-08 18:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:27:27 --> Input Class Initialized
INFO - 2018-03-08 18:27:27 --> Language Class Initialized
INFO - 2018-03-08 18:27:27 --> Loader Class Initialized
INFO - 2018-03-08 18:27:27 --> Helper loaded: common_helper
INFO - 2018-03-08 18:27:27 --> Database Driver Class Initialized
INFO - 2018-03-08 18:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:27:27 --> Email Class Initialized
INFO - 2018-03-08 18:27:27 --> Controller Class Initialized
INFO - 2018-03-08 18:27:27 --> Helper loaded: form_helper
INFO - 2018-03-08 18:27:27 --> Form Validation Class Initialized
INFO - 2018-03-08 18:27:27 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:27:27 --> Helper loaded: url_helper
INFO - 2018-03-08 18:27:27 --> Model Class Initialized
INFO - 2018-03-08 18:27:27 --> Model Class Initialized
INFO - 2018-03-08 18:27:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 18:27:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 18:27:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-08 18:27:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 18:27:27 --> Final output sent to browser
DEBUG - 2018-03-08 18:27:27 --> Total execution time: 0.1430
INFO - 2018-03-08 18:27:29 --> Config Class Initialized
INFO - 2018-03-08 18:27:29 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:27:29 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:27:29 --> Utf8 Class Initialized
INFO - 2018-03-08 18:27:29 --> URI Class Initialized
INFO - 2018-03-08 18:27:29 --> Router Class Initialized
INFO - 2018-03-08 18:27:29 --> Output Class Initialized
INFO - 2018-03-08 18:27:29 --> Security Class Initialized
DEBUG - 2018-03-08 18:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:27:29 --> Input Class Initialized
INFO - 2018-03-08 18:27:29 --> Language Class Initialized
INFO - 2018-03-08 18:27:29 --> Loader Class Initialized
INFO - 2018-03-08 18:27:29 --> Helper loaded: common_helper
INFO - 2018-03-08 18:27:30 --> Database Driver Class Initialized
INFO - 2018-03-08 18:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:27:30 --> Email Class Initialized
INFO - 2018-03-08 18:27:30 --> Controller Class Initialized
INFO - 2018-03-08 18:27:30 --> Helper loaded: form_helper
INFO - 2018-03-08 18:27:30 --> Form Validation Class Initialized
INFO - 2018-03-08 18:27:30 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:27:30 --> Helper loaded: url_helper
INFO - 2018-03-08 18:27:30 --> Model Class Initialized
INFO - 2018-03-08 18:27:30 --> Model Class Initialized
INFO - 2018-03-08 18:27:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 18:27:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 18:27:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-08 18:27:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 18:27:30 --> Final output sent to browser
DEBUG - 2018-03-08 18:27:30 --> Total execution time: 0.3420
INFO - 2018-03-08 18:27:32 --> Config Class Initialized
INFO - 2018-03-08 18:27:32 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:27:32 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:27:32 --> Utf8 Class Initialized
INFO - 2018-03-08 18:27:32 --> URI Class Initialized
INFO - 2018-03-08 18:27:32 --> Router Class Initialized
INFO - 2018-03-08 18:27:32 --> Output Class Initialized
INFO - 2018-03-08 18:27:32 --> Security Class Initialized
DEBUG - 2018-03-08 18:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:27:32 --> Input Class Initialized
INFO - 2018-03-08 18:27:32 --> Language Class Initialized
INFO - 2018-03-08 18:27:32 --> Loader Class Initialized
INFO - 2018-03-08 18:27:32 --> Helper loaded: common_helper
INFO - 2018-03-08 18:27:32 --> Database Driver Class Initialized
INFO - 2018-03-08 18:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:27:32 --> Email Class Initialized
INFO - 2018-03-08 18:27:32 --> Controller Class Initialized
INFO - 2018-03-08 18:27:32 --> Helper loaded: form_helper
INFO - 2018-03-08 18:27:32 --> Form Validation Class Initialized
INFO - 2018-03-08 18:27:32 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:27:32 --> Helper loaded: url_helper
INFO - 2018-03-08 18:27:32 --> Model Class Initialized
INFO - 2018-03-08 18:27:32 --> Model Class Initialized
INFO - 2018-03-08 18:27:32 --> Model Class Initialized
INFO - 2018-03-08 18:27:43 --> Config Class Initialized
INFO - 2018-03-08 18:27:43 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:27:43 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:27:43 --> Utf8 Class Initialized
INFO - 2018-03-08 18:27:43 --> URI Class Initialized
INFO - 2018-03-08 18:27:43 --> Router Class Initialized
INFO - 2018-03-08 18:27:43 --> Output Class Initialized
INFO - 2018-03-08 18:27:43 --> Security Class Initialized
DEBUG - 2018-03-08 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:27:43 --> Input Class Initialized
INFO - 2018-03-08 18:27:43 --> Language Class Initialized
INFO - 2018-03-08 18:27:43 --> Loader Class Initialized
INFO - 2018-03-08 18:27:43 --> Helper loaded: common_helper
INFO - 2018-03-08 18:27:43 --> Database Driver Class Initialized
INFO - 2018-03-08 18:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:27:43 --> Email Class Initialized
INFO - 2018-03-08 18:27:43 --> Controller Class Initialized
INFO - 2018-03-08 18:27:43 --> Helper loaded: form_helper
INFO - 2018-03-08 18:27:43 --> Form Validation Class Initialized
INFO - 2018-03-08 18:27:43 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:27:43 --> Helper loaded: url_helper
INFO - 2018-03-08 18:27:43 --> Model Class Initialized
INFO - 2018-03-08 18:27:43 --> Model Class Initialized
INFO - 2018-03-08 18:27:43 --> Model Class Initialized
INFO - 2018-03-08 18:28:54 --> Config Class Initialized
INFO - 2018-03-08 18:28:54 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:28:54 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:28:54 --> Utf8 Class Initialized
INFO - 2018-03-08 18:28:54 --> URI Class Initialized
INFO - 2018-03-08 18:28:54 --> Router Class Initialized
INFO - 2018-03-08 18:28:54 --> Output Class Initialized
INFO - 2018-03-08 18:28:54 --> Security Class Initialized
DEBUG - 2018-03-08 18:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:28:54 --> Input Class Initialized
INFO - 2018-03-08 18:28:54 --> Language Class Initialized
INFO - 2018-03-08 18:28:54 --> Loader Class Initialized
INFO - 2018-03-08 18:28:54 --> Helper loaded: common_helper
INFO - 2018-03-08 18:28:54 --> Database Driver Class Initialized
INFO - 2018-03-08 18:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:28:54 --> Email Class Initialized
INFO - 2018-03-08 18:28:54 --> Controller Class Initialized
INFO - 2018-03-08 18:28:54 --> Helper loaded: form_helper
INFO - 2018-03-08 18:28:54 --> Form Validation Class Initialized
INFO - 2018-03-08 18:28:54 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:28:54 --> Helper loaded: url_helper
INFO - 2018-03-08 18:28:54 --> Model Class Initialized
INFO - 2018-03-08 18:29:04 --> Config Class Initialized
INFO - 2018-03-08 18:29:04 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:29:04 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:29:04 --> Utf8 Class Initialized
INFO - 2018-03-08 18:29:04 --> URI Class Initialized
INFO - 2018-03-08 18:29:04 --> Router Class Initialized
INFO - 2018-03-08 18:29:04 --> Output Class Initialized
INFO - 2018-03-08 18:29:04 --> Security Class Initialized
DEBUG - 2018-03-08 18:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:29:04 --> Input Class Initialized
INFO - 2018-03-08 18:29:04 --> Language Class Initialized
INFO - 2018-03-08 18:29:04 --> Loader Class Initialized
INFO - 2018-03-08 18:29:04 --> Helper loaded: common_helper
INFO - 2018-03-08 18:29:04 --> Database Driver Class Initialized
INFO - 2018-03-08 18:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:29:04 --> Email Class Initialized
INFO - 2018-03-08 18:29:04 --> Controller Class Initialized
INFO - 2018-03-08 18:29:04 --> Helper loaded: form_helper
INFO - 2018-03-08 18:29:04 --> Form Validation Class Initialized
INFO - 2018-03-08 18:29:04 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:29:04 --> Helper loaded: url_helper
INFO - 2018-03-08 18:29:04 --> Model Class Initialized
INFO - 2018-03-08 18:29:04 --> Model Class Initialized
INFO - 2018-03-08 18:29:04 --> Model Class Initialized
INFO - 2018-03-08 18:30:22 --> Config Class Initialized
INFO - 2018-03-08 18:30:22 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:30:22 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:30:22 --> Utf8 Class Initialized
INFO - 2018-03-08 18:30:22 --> URI Class Initialized
INFO - 2018-03-08 18:30:22 --> Router Class Initialized
INFO - 2018-03-08 18:30:22 --> Output Class Initialized
INFO - 2018-03-08 18:30:22 --> Security Class Initialized
DEBUG - 2018-03-08 18:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:30:22 --> Input Class Initialized
INFO - 2018-03-08 18:30:22 --> Language Class Initialized
INFO - 2018-03-08 18:30:22 --> Loader Class Initialized
INFO - 2018-03-08 18:30:22 --> Helper loaded: common_helper
INFO - 2018-03-08 18:30:22 --> Database Driver Class Initialized
INFO - 2018-03-08 18:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:30:22 --> Email Class Initialized
INFO - 2018-03-08 18:30:22 --> Controller Class Initialized
INFO - 2018-03-08 18:30:22 --> Helper loaded: form_helper
INFO - 2018-03-08 18:30:22 --> Form Validation Class Initialized
INFO - 2018-03-08 18:30:22 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:30:22 --> Helper loaded: url_helper
INFO - 2018-03-08 18:30:22 --> Model Class Initialized
INFO - 2018-03-08 18:30:34 --> Config Class Initialized
INFO - 2018-03-08 18:30:34 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:30:34 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:30:34 --> Utf8 Class Initialized
INFO - 2018-03-08 18:30:34 --> URI Class Initialized
INFO - 2018-03-08 18:30:34 --> Router Class Initialized
INFO - 2018-03-08 18:30:34 --> Output Class Initialized
INFO - 2018-03-08 18:30:34 --> Security Class Initialized
DEBUG - 2018-03-08 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:30:34 --> Input Class Initialized
INFO - 2018-03-08 18:30:34 --> Language Class Initialized
INFO - 2018-03-08 18:30:34 --> Loader Class Initialized
INFO - 2018-03-08 18:30:34 --> Helper loaded: common_helper
INFO - 2018-03-08 18:30:34 --> Database Driver Class Initialized
INFO - 2018-03-08 18:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:30:34 --> Email Class Initialized
INFO - 2018-03-08 18:30:34 --> Controller Class Initialized
INFO - 2018-03-08 18:30:34 --> Helper loaded: form_helper
INFO - 2018-03-08 18:30:34 --> Form Validation Class Initialized
INFO - 2018-03-08 18:30:34 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:30:34 --> Helper loaded: url_helper
INFO - 2018-03-08 18:30:34 --> Model Class Initialized
INFO - 2018-03-08 18:30:34 --> Model Class Initialized
INFO - 2018-03-08 18:30:34 --> Model Class Initialized
INFO - 2018-03-08 18:30:34 --> Config Class Initialized
INFO - 2018-03-08 18:30:34 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:30:34 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:30:34 --> Utf8 Class Initialized
INFO - 2018-03-08 18:30:34 --> URI Class Initialized
INFO - 2018-03-08 18:30:34 --> Router Class Initialized
INFO - 2018-03-08 18:30:34 --> Output Class Initialized
INFO - 2018-03-08 18:30:34 --> Security Class Initialized
DEBUG - 2018-03-08 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:30:34 --> Input Class Initialized
INFO - 2018-03-08 18:30:34 --> Language Class Initialized
INFO - 2018-03-08 18:30:34 --> Loader Class Initialized
INFO - 2018-03-08 18:30:34 --> Helper loaded: common_helper
INFO - 2018-03-08 18:30:34 --> Database Driver Class Initialized
INFO - 2018-03-08 18:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:30:34 --> Email Class Initialized
INFO - 2018-03-08 18:30:34 --> Controller Class Initialized
INFO - 2018-03-08 18:30:34 --> Helper loaded: form_helper
INFO - 2018-03-08 18:30:34 --> Form Validation Class Initialized
INFO - 2018-03-08 18:30:34 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:30:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:30:34 --> Helper loaded: url_helper
INFO - 2018-03-08 18:30:34 --> Model Class Initialized
INFO - 2018-03-08 18:30:34 --> Model Class Initialized
INFO - 2018-03-08 18:30:34 --> Model Class Initialized
INFO - 2018-03-08 18:30:35 --> Config Class Initialized
INFO - 2018-03-08 18:30:35 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:30:35 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:30:35 --> Utf8 Class Initialized
INFO - 2018-03-08 18:30:35 --> URI Class Initialized
INFO - 2018-03-08 18:30:35 --> Router Class Initialized
INFO - 2018-03-08 18:30:35 --> Output Class Initialized
INFO - 2018-03-08 18:30:35 --> Security Class Initialized
DEBUG - 2018-03-08 18:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:30:35 --> Input Class Initialized
INFO - 2018-03-08 18:30:35 --> Language Class Initialized
INFO - 2018-03-08 18:30:35 --> Loader Class Initialized
INFO - 2018-03-08 18:30:35 --> Helper loaded: common_helper
INFO - 2018-03-08 18:30:35 --> Database Driver Class Initialized
INFO - 2018-03-08 18:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:30:35 --> Email Class Initialized
INFO - 2018-03-08 18:30:35 --> Controller Class Initialized
INFO - 2018-03-08 18:30:35 --> Helper loaded: form_helper
INFO - 2018-03-08 18:30:35 --> Form Validation Class Initialized
INFO - 2018-03-08 18:30:35 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:30:35 --> Helper loaded: url_helper
INFO - 2018-03-08 18:30:35 --> Model Class Initialized
INFO - 2018-03-08 18:30:35 --> Model Class Initialized
INFO - 2018-03-08 18:30:35 --> Model Class Initialized
INFO - 2018-03-08 18:34:20 --> Config Class Initialized
INFO - 2018-03-08 18:34:20 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:34:20 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:34:20 --> Utf8 Class Initialized
INFO - 2018-03-08 18:34:20 --> URI Class Initialized
INFO - 2018-03-08 18:34:20 --> Router Class Initialized
INFO - 2018-03-08 18:34:20 --> Output Class Initialized
INFO - 2018-03-08 18:34:20 --> Security Class Initialized
DEBUG - 2018-03-08 18:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:34:20 --> Input Class Initialized
INFO - 2018-03-08 18:34:20 --> Language Class Initialized
INFO - 2018-03-08 18:34:20 --> Loader Class Initialized
INFO - 2018-03-08 18:34:20 --> Helper loaded: common_helper
INFO - 2018-03-08 18:34:20 --> Database Driver Class Initialized
INFO - 2018-03-08 18:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:34:20 --> Email Class Initialized
INFO - 2018-03-08 18:34:20 --> Controller Class Initialized
INFO - 2018-03-08 18:34:20 --> Helper loaded: form_helper
INFO - 2018-03-08 18:34:20 --> Form Validation Class Initialized
INFO - 2018-03-08 18:34:20 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:34:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:34:20 --> Helper loaded: url_helper
INFO - 2018-03-08 18:34:20 --> Model Class Initialized
INFO - 2018-03-08 18:34:20 --> Model Class Initialized
INFO - 2018-03-08 18:34:20 --> Model Class Initialized
INFO - 2018-03-08 23:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 23:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 23:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-08 23:04:20 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-08 23:04:20 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-08 23:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-08 23:04:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 23:04:20 --> Final output sent to browser
DEBUG - 2018-03-08 23:04:20 --> Total execution time: 0.3170
INFO - 2018-03-08 18:34:30 --> Config Class Initialized
INFO - 2018-03-08 18:34:30 --> Hooks Class Initialized
DEBUG - 2018-03-08 18:34:30 --> UTF-8 Support Enabled
INFO - 2018-03-08 18:34:30 --> Utf8 Class Initialized
INFO - 2018-03-08 18:34:30 --> URI Class Initialized
INFO - 2018-03-08 18:34:30 --> Router Class Initialized
INFO - 2018-03-08 18:34:30 --> Output Class Initialized
INFO - 2018-03-08 18:34:30 --> Security Class Initialized
DEBUG - 2018-03-08 18:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 18:34:30 --> Input Class Initialized
INFO - 2018-03-08 18:34:30 --> Language Class Initialized
INFO - 2018-03-08 18:34:30 --> Loader Class Initialized
INFO - 2018-03-08 18:34:30 --> Helper loaded: common_helper
INFO - 2018-03-08 18:34:30 --> Database Driver Class Initialized
INFO - 2018-03-08 18:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 18:34:30 --> Email Class Initialized
INFO - 2018-03-08 18:34:30 --> Controller Class Initialized
INFO - 2018-03-08 18:34:30 --> Helper loaded: form_helper
INFO - 2018-03-08 18:34:30 --> Form Validation Class Initialized
INFO - 2018-03-08 18:34:30 --> Helper loaded: email_helper
DEBUG - 2018-03-08 18:34:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 18:34:30 --> Helper loaded: url_helper
INFO - 2018-03-08 18:34:30 --> Model Class Initialized
INFO - 2018-03-08 18:34:30 --> Model Class Initialized
INFO - 2018-03-08 18:34:30 --> Model Class Initialized
INFO - 2018-03-08 23:04:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-08 23:04:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-08 23:04:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-08 23:04:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-08 23:04:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-08 23:04:30 --> Final output sent to browser
DEBUG - 2018-03-08 23:04:30 --> Total execution time: 0.2190
INFO - 2018-03-08 19:30:28 --> Config Class Initialized
INFO - 2018-03-08 19:30:28 --> Hooks Class Initialized
DEBUG - 2018-03-08 19:30:28 --> UTF-8 Support Enabled
INFO - 2018-03-08 19:30:28 --> Utf8 Class Initialized
INFO - 2018-03-08 19:30:28 --> URI Class Initialized
INFO - 2018-03-08 19:30:28 --> Router Class Initialized
INFO - 2018-03-08 19:30:28 --> Output Class Initialized
INFO - 2018-03-08 19:30:28 --> Security Class Initialized
DEBUG - 2018-03-08 19:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 19:30:28 --> Input Class Initialized
INFO - 2018-03-08 19:30:29 --> Language Class Initialized
INFO - 2018-03-08 19:30:29 --> Loader Class Initialized
INFO - 2018-03-08 19:30:29 --> Helper loaded: common_helper
INFO - 2018-03-08 19:30:30 --> Database Driver Class Initialized
INFO - 2018-03-08 19:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 19:30:30 --> Email Class Initialized
INFO - 2018-03-08 19:30:30 --> Controller Class Initialized
INFO - 2018-03-08 19:30:30 --> Helper loaded: form_helper
INFO - 2018-03-08 19:30:30 --> Form Validation Class Initialized
INFO - 2018-03-08 19:30:30 --> Helper loaded: email_helper
DEBUG - 2018-03-08 19:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 19:30:30 --> Helper loaded: url_helper
INFO - 2018-03-08 19:30:30 --> Model Class Initialized
INFO - 2018-03-08 19:30:30 --> Model Class Initialized
INFO - 2018-03-08 19:30:31 --> Model Class Initialized
INFO - 2018-03-08 19:30:36 --> Config Class Initialized
INFO - 2018-03-08 19:30:36 --> Hooks Class Initialized
DEBUG - 2018-03-08 19:30:36 --> UTF-8 Support Enabled
INFO - 2018-03-08 19:30:36 --> Utf8 Class Initialized
INFO - 2018-03-08 19:30:36 --> URI Class Initialized
INFO - 2018-03-08 19:30:36 --> Router Class Initialized
INFO - 2018-03-08 19:30:36 --> Output Class Initialized
INFO - 2018-03-08 19:30:36 --> Security Class Initialized
DEBUG - 2018-03-08 19:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 19:30:36 --> Input Class Initialized
INFO - 2018-03-08 19:30:36 --> Language Class Initialized
INFO - 2018-03-08 19:30:37 --> Loader Class Initialized
INFO - 2018-03-08 19:30:37 --> Helper loaded: common_helper
INFO - 2018-03-08 19:30:37 --> Database Driver Class Initialized
INFO - 2018-03-08 19:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 19:30:37 --> Email Class Initialized
INFO - 2018-03-08 19:30:37 --> Controller Class Initialized
INFO - 2018-03-08 19:30:37 --> Helper loaded: form_helper
INFO - 2018-03-08 19:30:37 --> Form Validation Class Initialized
INFO - 2018-03-08 19:30:37 --> Helper loaded: email_helper
DEBUG - 2018-03-08 19:30:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 19:30:37 --> Helper loaded: url_helper
INFO - 2018-03-08 19:30:37 --> Model Class Initialized
INFO - 2018-03-08 19:30:37 --> Model Class Initialized
INFO - 2018-03-08 19:30:37 --> Model Class Initialized
INFO - 2018-03-08 20:29:58 --> Config Class Initialized
INFO - 2018-03-08 20:29:58 --> Hooks Class Initialized
DEBUG - 2018-03-08 20:29:58 --> UTF-8 Support Enabled
INFO - 2018-03-08 20:29:58 --> Utf8 Class Initialized
INFO - 2018-03-08 20:29:58 --> URI Class Initialized
INFO - 2018-03-08 20:29:58 --> Router Class Initialized
INFO - 2018-03-08 20:29:58 --> Output Class Initialized
INFO - 2018-03-08 20:29:58 --> Security Class Initialized
DEBUG - 2018-03-08 20:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 20:29:58 --> Input Class Initialized
INFO - 2018-03-08 20:29:58 --> Language Class Initialized
INFO - 2018-03-08 20:29:58 --> Loader Class Initialized
INFO - 2018-03-08 20:29:58 --> Helper loaded: common_helper
INFO - 2018-03-08 20:29:58 --> Database Driver Class Initialized
ERROR - 2018-03-08 20:29:58 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-08 20:29:58 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-08 20:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 20:29:58 --> Email Class Initialized
INFO - 2018-03-08 20:29:58 --> Controller Class Initialized
INFO - 2018-03-08 20:29:58 --> Helper loaded: form_helper
INFO - 2018-03-08 20:29:58 --> Form Validation Class Initialized
INFO - 2018-03-08 20:29:58 --> Helper loaded: email_helper
DEBUG - 2018-03-08 20:29:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 20:29:58 --> Helper loaded: url_helper
INFO - 2018-03-08 20:29:58 --> Model Class Initialized
INFO - 2018-03-08 20:29:58 --> Model Class Initialized
INFO - 2018-03-08 20:29:58 --> Model Class Initialized
INFO - 2018-03-08 20:29:59 --> Config Class Initialized
INFO - 2018-03-08 20:29:59 --> Hooks Class Initialized
DEBUG - 2018-03-08 20:29:59 --> UTF-8 Support Enabled
INFO - 2018-03-08 20:29:59 --> Utf8 Class Initialized
INFO - 2018-03-08 20:29:59 --> URI Class Initialized
INFO - 2018-03-08 20:29:59 --> Router Class Initialized
INFO - 2018-03-08 20:29:59 --> Output Class Initialized
INFO - 2018-03-08 20:29:59 --> Security Class Initialized
DEBUG - 2018-03-08 20:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 20:29:59 --> Input Class Initialized
INFO - 2018-03-08 20:29:59 --> Language Class Initialized
INFO - 2018-03-08 20:29:59 --> Loader Class Initialized
INFO - 2018-03-08 20:29:59 --> Helper loaded: common_helper
INFO - 2018-03-08 20:29:59 --> Database Driver Class Initialized
INFO - 2018-03-08 20:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 20:29:59 --> Email Class Initialized
INFO - 2018-03-08 20:29:59 --> Controller Class Initialized
INFO - 2018-03-08 20:29:59 --> Helper loaded: form_helper
INFO - 2018-03-08 20:29:59 --> Form Validation Class Initialized
INFO - 2018-03-08 20:29:59 --> Helper loaded: email_helper
DEBUG - 2018-03-08 20:29:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 20:29:59 --> Helper loaded: url_helper
INFO - 2018-03-08 20:29:59 --> Model Class Initialized
INFO - 2018-03-08 20:29:59 --> Model Class Initialized
INFO - 2018-03-08 20:29:59 --> Model Class Initialized
INFO - 2018-03-08 20:30:05 --> Config Class Initialized
INFO - 2018-03-08 20:30:05 --> Hooks Class Initialized
DEBUG - 2018-03-08 20:30:05 --> UTF-8 Support Enabled
INFO - 2018-03-08 20:30:05 --> Utf8 Class Initialized
INFO - 2018-03-08 20:30:05 --> URI Class Initialized
INFO - 2018-03-08 20:30:05 --> Router Class Initialized
INFO - 2018-03-08 20:30:05 --> Output Class Initialized
INFO - 2018-03-08 20:30:05 --> Security Class Initialized
DEBUG - 2018-03-08 20:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 20:30:05 --> Input Class Initialized
INFO - 2018-03-08 20:30:05 --> Language Class Initialized
INFO - 2018-03-08 20:30:06 --> Loader Class Initialized
INFO - 2018-03-08 20:30:06 --> Helper loaded: common_helper
INFO - 2018-03-08 20:30:06 --> Database Driver Class Initialized
INFO - 2018-03-08 20:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 20:30:06 --> Email Class Initialized
INFO - 2018-03-08 20:30:06 --> Controller Class Initialized
INFO - 2018-03-08 20:30:06 --> Helper loaded: form_helper
INFO - 2018-03-08 20:30:06 --> Form Validation Class Initialized
INFO - 2018-03-08 20:30:06 --> Helper loaded: email_helper
DEBUG - 2018-03-08 20:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 20:30:06 --> Helper loaded: url_helper
INFO - 2018-03-08 20:30:06 --> Model Class Initialized
INFO - 2018-03-08 20:30:06 --> Model Class Initialized
INFO - 2018-03-08 20:30:06 --> Model Class Initialized
INFO - 2018-03-08 20:32:00 --> Config Class Initialized
INFO - 2018-03-08 20:32:00 --> Hooks Class Initialized
DEBUG - 2018-03-08 20:32:00 --> UTF-8 Support Enabled
INFO - 2018-03-08 20:32:00 --> Utf8 Class Initialized
INFO - 2018-03-08 20:32:00 --> URI Class Initialized
INFO - 2018-03-08 20:32:00 --> Router Class Initialized
INFO - 2018-03-08 20:32:00 --> Output Class Initialized
INFO - 2018-03-08 20:32:00 --> Security Class Initialized
DEBUG - 2018-03-08 20:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-08 20:32:00 --> Input Class Initialized
INFO - 2018-03-08 20:32:00 --> Language Class Initialized
INFO - 2018-03-08 20:32:00 --> Loader Class Initialized
INFO - 2018-03-08 20:32:00 --> Helper loaded: common_helper
INFO - 2018-03-08 20:32:00 --> Database Driver Class Initialized
INFO - 2018-03-08 20:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-08 20:32:00 --> Email Class Initialized
INFO - 2018-03-08 20:32:00 --> Controller Class Initialized
INFO - 2018-03-08 20:32:00 --> Helper loaded: form_helper
INFO - 2018-03-08 20:32:00 --> Form Validation Class Initialized
INFO - 2018-03-08 20:32:00 --> Helper loaded: email_helper
DEBUG - 2018-03-08 20:32:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-08 20:32:00 --> Helper loaded: url_helper
INFO - 2018-03-08 20:32:00 --> Model Class Initialized
INFO - 2018-03-08 20:32:00 --> Model Class Initialized
INFO - 2018-03-08 20:32:00 --> Model Class Initialized
