<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-09 00:00:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 00:00:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 00:00:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:00:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:00:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 00:00:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 00:00:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 00:00:32 --> Final output sent to browser
DEBUG - 2018-03-09 00:00:32 --> Total execution time: 4.2942
INFO - 2018-03-09 00:00:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 00:00:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 00:00:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 00:00:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 00:00:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 00:00:37 --> Final output sent to browser
DEBUG - 2018-03-09 00:00:37 --> Total execution time: 0.2350
INFO - 2018-03-09 00:59:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 00:59:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 00:59:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:58 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:58 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 00:59:59 --> Final output sent to browser
DEBUG - 2018-03-09 00:59:59 --> Total execution time: 0.3170
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 00:59:59 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 00:59:59 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 00:59:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 00:59:59 --> Final output sent to browser
DEBUG - 2018-03-09 00:59:59 --> Total execution time: 0.2100
INFO - 2018-03-09 01:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 01:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 01:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 01:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 01:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 01:00:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 01:00:06 --> Final output sent to browser
DEBUG - 2018-03-09 01:00:06 --> Total execution time: 0.1510
INFO - 2018-03-09 01:02:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 01:02:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 01:02:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 01:02:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 01:02:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 01:02:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 01:02:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 01:02:00 --> Final output sent to browser
DEBUG - 2018-03-09 01:02:00 --> Total execution time: 0.3580
INFO - 2018-03-09 05:37:49 --> Config Class Initialized
INFO - 2018-03-09 05:37:49 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:37:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:37:49 --> Utf8 Class Initialized
INFO - 2018-03-09 05:37:49 --> URI Class Initialized
INFO - 2018-03-09 05:37:49 --> Router Class Initialized
INFO - 2018-03-09 05:37:49 --> Output Class Initialized
INFO - 2018-03-09 05:37:49 --> Security Class Initialized
DEBUG - 2018-03-09 05:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:37:49 --> Input Class Initialized
INFO - 2018-03-09 05:37:49 --> Language Class Initialized
INFO - 2018-03-09 05:37:49 --> Loader Class Initialized
INFO - 2018-03-09 05:37:49 --> Helper loaded: common_helper
INFO - 2018-03-09 05:37:49 --> Database Driver Class Initialized
ERROR - 2018-03-09 05:37:49 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-09 05:37:49 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-09 05:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:37:49 --> Email Class Initialized
INFO - 2018-03-09 05:37:49 --> Controller Class Initialized
INFO - 2018-03-09 05:37:49 --> Helper loaded: form_helper
INFO - 2018-03-09 05:37:49 --> Form Validation Class Initialized
INFO - 2018-03-09 05:37:49 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:37:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:37:49 --> Helper loaded: url_helper
INFO - 2018-03-09 05:37:49 --> Model Class Initialized
INFO - 2018-03-09 05:37:49 --> Model Class Initialized
INFO - 2018-03-09 05:37:49 --> Model Class Initialized
INFO - 2018-03-09 10:07:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:07:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:07:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 10:07:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:07:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:07:49 --> Final output sent to browser
DEBUG - 2018-03-09 10:07:49 --> Total execution time: 0.1840
INFO - 2018-03-09 05:37:49 --> Config Class Initialized
INFO - 2018-03-09 05:37:49 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:37:49 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:37:49 --> Utf8 Class Initialized
INFO - 2018-03-09 05:37:49 --> URI Class Initialized
INFO - 2018-03-09 05:37:49 --> Router Class Initialized
INFO - 2018-03-09 05:37:49 --> Output Class Initialized
INFO - 2018-03-09 05:37:49 --> Security Class Initialized
DEBUG - 2018-03-09 05:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:37:49 --> Input Class Initialized
INFO - 2018-03-09 05:37:49 --> Language Class Initialized
INFO - 2018-03-09 05:37:49 --> Loader Class Initialized
INFO - 2018-03-09 05:37:49 --> Helper loaded: common_helper
INFO - 2018-03-09 05:37:50 --> Database Driver Class Initialized
INFO - 2018-03-09 05:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:37:50 --> Email Class Initialized
INFO - 2018-03-09 05:37:50 --> Controller Class Initialized
INFO - 2018-03-09 05:37:50 --> Helper loaded: form_helper
INFO - 2018-03-09 05:37:50 --> Form Validation Class Initialized
INFO - 2018-03-09 05:37:50 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:37:50 --> Helper loaded: url_helper
INFO - 2018-03-09 05:37:50 --> Model Class Initialized
INFO - 2018-03-09 05:37:50 --> Model Class Initialized
INFO - 2018-03-09 05:37:50 --> Model Class Initialized
INFO - 2018-03-09 10:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 10:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:07:50 --> Final output sent to browser
DEBUG - 2018-03-09 10:07:50 --> Total execution time: 0.2800
INFO - 2018-03-09 05:37:58 --> Config Class Initialized
INFO - 2018-03-09 05:37:58 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:37:58 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:37:58 --> Utf8 Class Initialized
INFO - 2018-03-09 05:37:58 --> URI Class Initialized
INFO - 2018-03-09 05:37:58 --> Router Class Initialized
INFO - 2018-03-09 05:37:58 --> Output Class Initialized
INFO - 2018-03-09 05:37:58 --> Security Class Initialized
DEBUG - 2018-03-09 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:37:58 --> Input Class Initialized
INFO - 2018-03-09 05:37:58 --> Language Class Initialized
INFO - 2018-03-09 05:37:58 --> Loader Class Initialized
INFO - 2018-03-09 05:37:58 --> Helper loaded: common_helper
INFO - 2018-03-09 05:37:58 --> Database Driver Class Initialized
INFO - 2018-03-09 05:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:37:58 --> Email Class Initialized
INFO - 2018-03-09 05:37:58 --> Controller Class Initialized
INFO - 2018-03-09 05:37:58 --> Helper loaded: form_helper
INFO - 2018-03-09 05:37:58 --> Form Validation Class Initialized
INFO - 2018-03-09 05:37:58 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:37:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:37:58 --> Helper loaded: url_helper
INFO - 2018-03-09 05:37:58 --> Model Class Initialized
INFO - 2018-03-09 05:37:58 --> Model Class Initialized
INFO - 2018-03-09 05:37:58 --> Model Class Initialized
INFO - 2018-03-09 05:37:58 --> Config Class Initialized
INFO - 2018-03-09 05:37:58 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:37:58 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:37:58 --> Utf8 Class Initialized
INFO - 2018-03-09 05:37:58 --> URI Class Initialized
INFO - 2018-03-09 05:37:58 --> Router Class Initialized
INFO - 2018-03-09 05:37:58 --> Output Class Initialized
INFO - 2018-03-09 05:37:58 --> Security Class Initialized
DEBUG - 2018-03-09 05:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:37:58 --> Input Class Initialized
INFO - 2018-03-09 05:37:58 --> Language Class Initialized
INFO - 2018-03-09 05:37:59 --> Loader Class Initialized
INFO - 2018-03-09 05:37:59 --> Helper loaded: common_helper
INFO - 2018-03-09 05:37:59 --> Database Driver Class Initialized
INFO - 2018-03-09 05:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:37:59 --> Email Class Initialized
INFO - 2018-03-09 05:37:59 --> Controller Class Initialized
INFO - 2018-03-09 05:37:59 --> Helper loaded: form_helper
INFO - 2018-03-09 05:37:59 --> Form Validation Class Initialized
INFO - 2018-03-09 05:37:59 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:37:59 --> Helper loaded: url_helper
INFO - 2018-03-09 05:37:59 --> Model Class Initialized
INFO - 2018-03-09 05:37:59 --> Model Class Initialized
INFO - 2018-03-09 05:37:59 --> Config Class Initialized
INFO - 2018-03-09 05:37:59 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:37:59 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:37:59 --> Utf8 Class Initialized
INFO - 2018-03-09 05:37:59 --> URI Class Initialized
DEBUG - 2018-03-09 05:37:59 --> No URI present. Default controller set.
INFO - 2018-03-09 05:37:59 --> Router Class Initialized
INFO - 2018-03-09 05:37:59 --> Output Class Initialized
INFO - 2018-03-09 05:37:59 --> Security Class Initialized
DEBUG - 2018-03-09 05:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:37:59 --> Input Class Initialized
INFO - 2018-03-09 05:37:59 --> Language Class Initialized
INFO - 2018-03-09 05:37:59 --> Loader Class Initialized
INFO - 2018-03-09 05:37:59 --> Helper loaded: common_helper
INFO - 2018-03-09 05:37:59 --> Database Driver Class Initialized
INFO - 2018-03-09 05:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:37:59 --> Email Class Initialized
INFO - 2018-03-09 05:37:59 --> Controller Class Initialized
INFO - 2018-03-09 05:37:59 --> Helper loaded: form_helper
INFO - 2018-03-09 05:37:59 --> Form Validation Class Initialized
INFO - 2018-03-09 05:37:59 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:37:59 --> Helper loaded: url_helper
INFO - 2018-03-09 05:37:59 --> Model Class Initialized
INFO - 2018-03-09 05:37:59 --> Model Class Initialized
INFO - 2018-03-09 05:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-09 05:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 05:37:59 --> Final output sent to browser
DEBUG - 2018-03-09 05:37:59 --> Total execution time: 0.1920
INFO - 2018-03-09 05:38:01 --> Config Class Initialized
INFO - 2018-03-09 05:38:01 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:38:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:38:01 --> Utf8 Class Initialized
INFO - 2018-03-09 05:38:01 --> URI Class Initialized
DEBUG - 2018-03-09 05:38:01 --> No URI present. Default controller set.
INFO - 2018-03-09 05:38:01 --> Router Class Initialized
INFO - 2018-03-09 05:38:01 --> Output Class Initialized
INFO - 2018-03-09 05:38:01 --> Security Class Initialized
DEBUG - 2018-03-09 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:38:01 --> Input Class Initialized
INFO - 2018-03-09 05:38:01 --> Language Class Initialized
INFO - 2018-03-09 05:38:01 --> Loader Class Initialized
INFO - 2018-03-09 05:38:01 --> Helper loaded: common_helper
INFO - 2018-03-09 05:38:01 --> Database Driver Class Initialized
INFO - 2018-03-09 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:38:02 --> Email Class Initialized
INFO - 2018-03-09 05:38:02 --> Controller Class Initialized
INFO - 2018-03-09 05:38:02 --> Helper loaded: form_helper
INFO - 2018-03-09 05:38:02 --> Form Validation Class Initialized
INFO - 2018-03-09 05:38:02 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:38:02 --> Helper loaded: url_helper
INFO - 2018-03-09 05:38:02 --> Model Class Initialized
INFO - 2018-03-09 05:38:02 --> Model Class Initialized
DEBUG - 2018-03-09 05:38:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:38:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-09 05:38:02 --> Config Class Initialized
INFO - 2018-03-09 05:38:02 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:38:02 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:38:02 --> Utf8 Class Initialized
INFO - 2018-03-09 05:38:02 --> URI Class Initialized
INFO - 2018-03-09 05:38:02 --> Router Class Initialized
INFO - 2018-03-09 05:38:02 --> Output Class Initialized
INFO - 2018-03-09 05:38:02 --> Security Class Initialized
DEBUG - 2018-03-09 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:38:02 --> Input Class Initialized
INFO - 2018-03-09 05:38:02 --> Language Class Initialized
INFO - 2018-03-09 05:38:02 --> Loader Class Initialized
INFO - 2018-03-09 05:38:02 --> Helper loaded: common_helper
INFO - 2018-03-09 05:38:02 --> Database Driver Class Initialized
INFO - 2018-03-09 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:38:02 --> Email Class Initialized
INFO - 2018-03-09 05:38:02 --> Controller Class Initialized
INFO - 2018-03-09 05:38:02 --> Helper loaded: form_helper
INFO - 2018-03-09 05:38:02 --> Form Validation Class Initialized
INFO - 2018-03-09 05:38:02 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:38:02 --> Helper loaded: url_helper
INFO - 2018-03-09 05:38:02 --> Model Class Initialized
INFO - 2018-03-09 05:38:02 --> Model Class Initialized
INFO - 2018-03-09 05:38:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 05:38:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 05:38:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-09 05:38:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 05:38:02 --> Final output sent to browser
DEBUG - 2018-03-09 05:38:02 --> Total execution time: 0.1550
INFO - 2018-03-09 05:38:06 --> Config Class Initialized
INFO - 2018-03-09 05:38:06 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:38:06 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:38:06 --> Utf8 Class Initialized
INFO - 2018-03-09 05:38:06 --> URI Class Initialized
INFO - 2018-03-09 05:38:06 --> Router Class Initialized
INFO - 2018-03-09 05:38:06 --> Output Class Initialized
INFO - 2018-03-09 05:38:06 --> Security Class Initialized
DEBUG - 2018-03-09 05:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:38:06 --> Input Class Initialized
INFO - 2018-03-09 05:38:06 --> Language Class Initialized
INFO - 2018-03-09 05:38:06 --> Loader Class Initialized
INFO - 2018-03-09 05:38:06 --> Helper loaded: common_helper
INFO - 2018-03-09 05:38:06 --> Database Driver Class Initialized
INFO - 2018-03-09 05:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:38:06 --> Email Class Initialized
INFO - 2018-03-09 05:38:06 --> Controller Class Initialized
INFO - 2018-03-09 05:38:06 --> Helper loaded: form_helper
INFO - 2018-03-09 05:38:06 --> Form Validation Class Initialized
INFO - 2018-03-09 05:38:06 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:38:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:38:06 --> Helper loaded: url_helper
INFO - 2018-03-09 05:38:06 --> Model Class Initialized
INFO - 2018-03-09 05:38:06 --> Model Class Initialized
INFO - 2018-03-09 05:38:06 --> Model Class Initialized
INFO - 2018-03-09 10:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 10:08:06 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 10:08:06 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 10:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 10:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:08:06 --> Final output sent to browser
DEBUG - 2018-03-09 10:08:06 --> Total execution time: 0.2350
INFO - 2018-03-09 05:38:14 --> Config Class Initialized
INFO - 2018-03-09 05:38:14 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:38:14 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:38:14 --> Utf8 Class Initialized
INFO - 2018-03-09 05:38:14 --> URI Class Initialized
INFO - 2018-03-09 05:38:14 --> Router Class Initialized
INFO - 2018-03-09 05:38:14 --> Output Class Initialized
INFO - 2018-03-09 05:38:14 --> Security Class Initialized
DEBUG - 2018-03-09 05:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:38:14 --> Input Class Initialized
INFO - 2018-03-09 05:38:14 --> Language Class Initialized
INFO - 2018-03-09 05:38:14 --> Loader Class Initialized
INFO - 2018-03-09 05:38:14 --> Helper loaded: common_helper
INFO - 2018-03-09 05:38:14 --> Database Driver Class Initialized
INFO - 2018-03-09 05:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:38:14 --> Email Class Initialized
INFO - 2018-03-09 05:38:14 --> Controller Class Initialized
INFO - 2018-03-09 05:38:14 --> Helper loaded: form_helper
INFO - 2018-03-09 05:38:14 --> Form Validation Class Initialized
INFO - 2018-03-09 05:38:14 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:38:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:38:14 --> Helper loaded: url_helper
INFO - 2018-03-09 05:38:14 --> Model Class Initialized
INFO - 2018-03-09 05:38:14 --> Model Class Initialized
INFO - 2018-03-09 05:38:14 --> Model Class Initialized
INFO - 2018-03-09 10:08:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:08:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:08:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:08:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:08:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:08:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:08:14 --> Final output sent to browser
DEBUG - 2018-03-09 10:08:14 --> Total execution time: 0.1350
INFO - 2018-03-09 05:39:53 --> Config Class Initialized
INFO - 2018-03-09 05:39:53 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:39:53 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:39:53 --> Utf8 Class Initialized
INFO - 2018-03-09 05:39:54 --> URI Class Initialized
INFO - 2018-03-09 05:39:54 --> Router Class Initialized
INFO - 2018-03-09 05:39:54 --> Output Class Initialized
INFO - 2018-03-09 05:39:54 --> Security Class Initialized
DEBUG - 2018-03-09 05:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:39:54 --> Input Class Initialized
INFO - 2018-03-09 05:39:54 --> Language Class Initialized
INFO - 2018-03-09 05:39:54 --> Loader Class Initialized
INFO - 2018-03-09 05:39:54 --> Helper loaded: common_helper
INFO - 2018-03-09 05:39:54 --> Database Driver Class Initialized
INFO - 2018-03-09 05:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:39:54 --> Email Class Initialized
INFO - 2018-03-09 05:39:54 --> Controller Class Initialized
INFO - 2018-03-09 05:39:54 --> Helper loaded: form_helper
INFO - 2018-03-09 05:39:54 --> Form Validation Class Initialized
INFO - 2018-03-09 05:39:54 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:39:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:39:54 --> Helper loaded: url_helper
INFO - 2018-03-09 05:39:54 --> Model Class Initialized
INFO - 2018-03-09 05:39:54 --> Model Class Initialized
INFO - 2018-03-09 05:39:54 --> Model Class Initialized
INFO - 2018-03-09 10:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:09:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:09:54 --> Final output sent to browser
DEBUG - 2018-03-09 10:09:54 --> Total execution time: 0.1820
INFO - 2018-03-09 05:41:09 --> Config Class Initialized
INFO - 2018-03-09 05:41:09 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:41:09 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:41:09 --> Utf8 Class Initialized
INFO - 2018-03-09 05:41:09 --> URI Class Initialized
INFO - 2018-03-09 05:41:09 --> Router Class Initialized
INFO - 2018-03-09 05:41:09 --> Output Class Initialized
INFO - 2018-03-09 05:41:09 --> Security Class Initialized
DEBUG - 2018-03-09 05:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:41:09 --> Input Class Initialized
INFO - 2018-03-09 05:41:09 --> Language Class Initialized
INFO - 2018-03-09 05:41:09 --> Loader Class Initialized
INFO - 2018-03-09 05:41:09 --> Helper loaded: common_helper
INFO - 2018-03-09 05:41:09 --> Database Driver Class Initialized
INFO - 2018-03-09 05:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:41:09 --> Email Class Initialized
INFO - 2018-03-09 05:41:09 --> Controller Class Initialized
INFO - 2018-03-09 05:41:09 --> Helper loaded: form_helper
INFO - 2018-03-09 05:41:09 --> Form Validation Class Initialized
INFO - 2018-03-09 05:41:09 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:41:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:41:09 --> Helper loaded: url_helper
INFO - 2018-03-09 05:41:09 --> Model Class Initialized
INFO - 2018-03-09 05:41:09 --> Model Class Initialized
INFO - 2018-03-09 05:41:09 --> Model Class Initialized
INFO - 2018-03-09 10:11:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:11:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:11:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:11:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:11:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:11:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:11:09 --> Final output sent to browser
DEBUG - 2018-03-09 10:11:09 --> Total execution time: 0.2510
INFO - 2018-03-09 05:44:47 --> Config Class Initialized
INFO - 2018-03-09 05:44:47 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:44:47 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:44:47 --> Utf8 Class Initialized
INFO - 2018-03-09 05:44:47 --> URI Class Initialized
INFO - 2018-03-09 05:44:47 --> Router Class Initialized
INFO - 2018-03-09 05:44:47 --> Output Class Initialized
INFO - 2018-03-09 05:44:47 --> Security Class Initialized
DEBUG - 2018-03-09 05:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:44:47 --> Input Class Initialized
INFO - 2018-03-09 05:44:47 --> Language Class Initialized
INFO - 2018-03-09 05:44:47 --> Loader Class Initialized
INFO - 2018-03-09 05:44:47 --> Helper loaded: common_helper
INFO - 2018-03-09 05:44:47 --> Database Driver Class Initialized
INFO - 2018-03-09 05:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:44:48 --> Email Class Initialized
INFO - 2018-03-09 05:44:48 --> Controller Class Initialized
INFO - 2018-03-09 05:44:48 --> Helper loaded: form_helper
INFO - 2018-03-09 05:44:48 --> Form Validation Class Initialized
INFO - 2018-03-09 05:44:48 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:44:48 --> Helper loaded: url_helper
INFO - 2018-03-09 05:44:48 --> Model Class Initialized
INFO - 2018-03-09 05:44:48 --> Model Class Initialized
INFO - 2018-03-09 05:44:48 --> Model Class Initialized
INFO - 2018-03-09 10:14:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:14:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:14:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:14:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:14:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:14:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:14:48 --> Final output sent to browser
DEBUG - 2018-03-09 10:14:48 --> Total execution time: 0.3270
INFO - 2018-03-09 05:46:20 --> Config Class Initialized
INFO - 2018-03-09 05:46:20 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:46:20 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:46:20 --> Utf8 Class Initialized
INFO - 2018-03-09 05:46:20 --> URI Class Initialized
INFO - 2018-03-09 05:46:20 --> Router Class Initialized
INFO - 2018-03-09 05:46:20 --> Output Class Initialized
INFO - 2018-03-09 05:46:20 --> Security Class Initialized
DEBUG - 2018-03-09 05:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:46:20 --> Input Class Initialized
INFO - 2018-03-09 05:46:20 --> Language Class Initialized
INFO - 2018-03-09 05:46:20 --> Loader Class Initialized
INFO - 2018-03-09 05:46:20 --> Helper loaded: common_helper
INFO - 2018-03-09 05:46:20 --> Database Driver Class Initialized
ERROR - 2018-03-09 05:46:20 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-09 05:46:20 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-09 05:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:46:20 --> Email Class Initialized
INFO - 2018-03-09 05:46:20 --> Controller Class Initialized
INFO - 2018-03-09 05:46:20 --> Helper loaded: form_helper
INFO - 2018-03-09 05:46:20 --> Form Validation Class Initialized
INFO - 2018-03-09 05:46:20 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:46:20 --> Helper loaded: url_helper
INFO - 2018-03-09 05:46:20 --> Model Class Initialized
INFO - 2018-03-09 05:46:20 --> Model Class Initialized
INFO - 2018-03-09 05:46:20 --> Model Class Initialized
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:16:20 --> Final output sent to browser
DEBUG - 2018-03-09 10:16:20 --> Total execution time: 0.1950
INFO - 2018-03-09 05:46:20 --> Config Class Initialized
INFO - 2018-03-09 05:46:20 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:46:20 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:46:20 --> Utf8 Class Initialized
INFO - 2018-03-09 05:46:20 --> URI Class Initialized
INFO - 2018-03-09 05:46:20 --> Router Class Initialized
INFO - 2018-03-09 05:46:20 --> Output Class Initialized
INFO - 2018-03-09 05:46:20 --> Security Class Initialized
DEBUG - 2018-03-09 05:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:46:20 --> Input Class Initialized
INFO - 2018-03-09 05:46:20 --> Language Class Initialized
INFO - 2018-03-09 05:46:20 --> Loader Class Initialized
INFO - 2018-03-09 05:46:20 --> Helper loaded: common_helper
INFO - 2018-03-09 05:46:20 --> Database Driver Class Initialized
INFO - 2018-03-09 05:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:46:20 --> Email Class Initialized
INFO - 2018-03-09 05:46:20 --> Controller Class Initialized
INFO - 2018-03-09 05:46:20 --> Helper loaded: form_helper
INFO - 2018-03-09 05:46:20 --> Form Validation Class Initialized
INFO - 2018-03-09 05:46:20 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:46:20 --> Helper loaded: url_helper
INFO - 2018-03-09 05:46:20 --> Model Class Initialized
INFO - 2018-03-09 05:46:20 --> Model Class Initialized
INFO - 2018-03-09 05:46:20 --> Model Class Initialized
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:16:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:16:20 --> Final output sent to browser
DEBUG - 2018-03-09 10:16:20 --> Total execution time: 0.1560
INFO - 2018-03-09 05:51:35 --> Config Class Initialized
INFO - 2018-03-09 05:51:35 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:51:35 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:51:35 --> Utf8 Class Initialized
INFO - 2018-03-09 05:51:35 --> URI Class Initialized
INFO - 2018-03-09 05:51:35 --> Router Class Initialized
INFO - 2018-03-09 05:51:35 --> Output Class Initialized
INFO - 2018-03-09 05:51:35 --> Security Class Initialized
DEBUG - 2018-03-09 05:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:51:35 --> Input Class Initialized
INFO - 2018-03-09 05:51:35 --> Language Class Initialized
INFO - 2018-03-09 05:51:35 --> Loader Class Initialized
INFO - 2018-03-09 05:51:35 --> Helper loaded: common_helper
INFO - 2018-03-09 05:51:35 --> Database Driver Class Initialized
ERROR - 2018-03-09 05:51:35 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-09 05:51:35 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-09 05:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:51:35 --> Email Class Initialized
INFO - 2018-03-09 05:51:35 --> Controller Class Initialized
INFO - 2018-03-09 05:51:35 --> Helper loaded: form_helper
INFO - 2018-03-09 05:51:35 --> Form Validation Class Initialized
INFO - 2018-03-09 05:51:35 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:51:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:51:35 --> Helper loaded: url_helper
INFO - 2018-03-09 05:51:35 --> Model Class Initialized
INFO - 2018-03-09 05:51:35 --> Model Class Initialized
INFO - 2018-03-09 05:51:35 --> Model Class Initialized
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:21:36 --> Final output sent to browser
DEBUG - 2018-03-09 10:21:36 --> Total execution time: 0.2150
INFO - 2018-03-09 05:51:36 --> Config Class Initialized
INFO - 2018-03-09 05:51:36 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:51:36 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:51:36 --> Utf8 Class Initialized
INFO - 2018-03-09 05:51:36 --> URI Class Initialized
INFO - 2018-03-09 05:51:36 --> Router Class Initialized
INFO - 2018-03-09 05:51:36 --> Output Class Initialized
INFO - 2018-03-09 05:51:36 --> Security Class Initialized
DEBUG - 2018-03-09 05:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:51:36 --> Input Class Initialized
INFO - 2018-03-09 05:51:36 --> Language Class Initialized
INFO - 2018-03-09 05:51:36 --> Loader Class Initialized
INFO - 2018-03-09 05:51:36 --> Helper loaded: common_helper
INFO - 2018-03-09 05:51:36 --> Database Driver Class Initialized
INFO - 2018-03-09 05:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:51:36 --> Email Class Initialized
INFO - 2018-03-09 05:51:36 --> Controller Class Initialized
INFO - 2018-03-09 05:51:36 --> Helper loaded: form_helper
INFO - 2018-03-09 05:51:36 --> Form Validation Class Initialized
INFO - 2018-03-09 05:51:36 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:51:36 --> Helper loaded: url_helper
INFO - 2018-03-09 05:51:36 --> Model Class Initialized
INFO - 2018-03-09 05:51:36 --> Model Class Initialized
INFO - 2018-03-09 05:51:36 --> Model Class Initialized
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:21:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:21:36 --> Final output sent to browser
DEBUG - 2018-03-09 10:21:36 --> Total execution time: 0.2100
INFO - 2018-03-09 05:52:08 --> Config Class Initialized
INFO - 2018-03-09 05:52:08 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:52:08 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:52:08 --> Utf8 Class Initialized
INFO - 2018-03-09 05:52:08 --> URI Class Initialized
INFO - 2018-03-09 05:52:08 --> Router Class Initialized
INFO - 2018-03-09 05:52:08 --> Output Class Initialized
INFO - 2018-03-09 05:52:08 --> Security Class Initialized
DEBUG - 2018-03-09 05:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:52:08 --> Input Class Initialized
INFO - 2018-03-09 05:52:08 --> Language Class Initialized
INFO - 2018-03-09 05:52:08 --> Loader Class Initialized
INFO - 2018-03-09 05:52:08 --> Helper loaded: common_helper
INFO - 2018-03-09 05:52:08 --> Database Driver Class Initialized
INFO - 2018-03-09 05:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:52:08 --> Email Class Initialized
INFO - 2018-03-09 05:52:08 --> Controller Class Initialized
INFO - 2018-03-09 05:52:08 --> Helper loaded: form_helper
INFO - 2018-03-09 05:52:08 --> Form Validation Class Initialized
INFO - 2018-03-09 05:52:08 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:52:08 --> Helper loaded: url_helper
INFO - 2018-03-09 05:52:08 --> Model Class Initialized
INFO - 2018-03-09 05:52:08 --> Model Class Initialized
INFO - 2018-03-09 05:52:08 --> Model Class Initialized
INFO - 2018-03-09 10:22:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:22:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:22:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:22:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:22:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:22:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:22:08 --> Final output sent to browser
DEBUG - 2018-03-09 10:22:08 --> Total execution time: 0.1350
INFO - 2018-03-09 05:53:14 --> Config Class Initialized
INFO - 2018-03-09 05:53:14 --> Hooks Class Initialized
DEBUG - 2018-03-09 05:53:14 --> UTF-8 Support Enabled
INFO - 2018-03-09 05:53:14 --> Utf8 Class Initialized
INFO - 2018-03-09 05:53:14 --> URI Class Initialized
INFO - 2018-03-09 05:53:14 --> Router Class Initialized
INFO - 2018-03-09 05:53:14 --> Output Class Initialized
INFO - 2018-03-09 05:53:14 --> Security Class Initialized
DEBUG - 2018-03-09 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 05:53:14 --> Input Class Initialized
INFO - 2018-03-09 05:53:14 --> Language Class Initialized
INFO - 2018-03-09 05:53:14 --> Loader Class Initialized
INFO - 2018-03-09 05:53:14 --> Helper loaded: common_helper
INFO - 2018-03-09 05:53:14 --> Database Driver Class Initialized
INFO - 2018-03-09 05:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 05:53:14 --> Email Class Initialized
INFO - 2018-03-09 05:53:14 --> Controller Class Initialized
INFO - 2018-03-09 05:53:14 --> Helper loaded: form_helper
INFO - 2018-03-09 05:53:14 --> Form Validation Class Initialized
INFO - 2018-03-09 05:53:14 --> Helper loaded: email_helper
DEBUG - 2018-03-09 05:53:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 05:53:14 --> Helper loaded: url_helper
INFO - 2018-03-09 05:53:15 --> Model Class Initialized
INFO - 2018-03-09 05:53:15 --> Model Class Initialized
INFO - 2018-03-09 05:53:15 --> Model Class Initialized
INFO - 2018-03-09 10:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:23:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:23:15 --> Final output sent to browser
DEBUG - 2018-03-09 10:23:15 --> Total execution time: 0.1520
INFO - 2018-03-09 06:07:17 --> Config Class Initialized
INFO - 2018-03-09 06:07:17 --> Hooks Class Initialized
DEBUG - 2018-03-09 06:07:17 --> UTF-8 Support Enabled
INFO - 2018-03-09 06:07:17 --> Utf8 Class Initialized
INFO - 2018-03-09 06:07:17 --> URI Class Initialized
INFO - 2018-03-09 06:07:17 --> Router Class Initialized
INFO - 2018-03-09 06:07:17 --> Output Class Initialized
INFO - 2018-03-09 06:07:17 --> Security Class Initialized
DEBUG - 2018-03-09 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 06:07:17 --> Input Class Initialized
INFO - 2018-03-09 06:07:17 --> Language Class Initialized
INFO - 2018-03-09 06:07:17 --> Loader Class Initialized
INFO - 2018-03-09 06:07:17 --> Helper loaded: common_helper
INFO - 2018-03-09 06:07:17 --> Database Driver Class Initialized
INFO - 2018-03-09 06:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 06:07:17 --> Email Class Initialized
INFO - 2018-03-09 06:07:17 --> Controller Class Initialized
INFO - 2018-03-09 06:07:17 --> Helper loaded: form_helper
INFO - 2018-03-09 06:07:17 --> Form Validation Class Initialized
INFO - 2018-03-09 06:07:17 --> Helper loaded: email_helper
DEBUG - 2018-03-09 06:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 06:07:17 --> Helper loaded: url_helper
INFO - 2018-03-09 06:07:17 --> Model Class Initialized
INFO - 2018-03-09 06:07:17 --> Model Class Initialized
INFO - 2018-03-09 06:07:17 --> Model Class Initialized
INFO - 2018-03-09 10:37:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 10:37:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 10:37:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:37:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 10:37:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 10:37:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 10:37:17 --> Final output sent to browser
DEBUG - 2018-03-09 10:37:17 --> Total execution time: 0.1450
INFO - 2018-03-09 06:57:59 --> Config Class Initialized
INFO - 2018-03-09 06:57:59 --> Hooks Class Initialized
DEBUG - 2018-03-09 06:57:59 --> UTF-8 Support Enabled
INFO - 2018-03-09 06:57:59 --> Utf8 Class Initialized
INFO - 2018-03-09 06:57:59 --> URI Class Initialized
INFO - 2018-03-09 06:57:59 --> Router Class Initialized
INFO - 2018-03-09 06:57:59 --> Output Class Initialized
INFO - 2018-03-09 06:57:59 --> Security Class Initialized
DEBUG - 2018-03-09 06:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 06:57:59 --> Input Class Initialized
INFO - 2018-03-09 06:57:59 --> Language Class Initialized
INFO - 2018-03-09 06:57:59 --> Loader Class Initialized
INFO - 2018-03-09 06:57:59 --> Helper loaded: common_helper
INFO - 2018-03-09 06:57:59 --> Database Driver Class Initialized
INFO - 2018-03-09 06:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 06:57:59 --> Email Class Initialized
INFO - 2018-03-09 06:57:59 --> Controller Class Initialized
INFO - 2018-03-09 06:57:59 --> Helper loaded: form_helper
INFO - 2018-03-09 06:57:59 --> Form Validation Class Initialized
INFO - 2018-03-09 06:57:59 --> Helper loaded: email_helper
DEBUG - 2018-03-09 06:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 06:57:59 --> Helper loaded: url_helper
INFO - 2018-03-09 06:57:59 --> Model Class Initialized
INFO - 2018-03-09 06:57:59 --> Model Class Initialized
INFO - 2018-03-09 06:57:59 --> Model Class Initialized
INFO - 2018-03-09 11:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 11:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 11:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 11:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 11:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 11:27:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 11:27:59 --> Final output sent to browser
DEBUG - 2018-03-09 11:27:59 --> Total execution time: 0.4360
INFO - 2018-03-09 07:17:31 --> Config Class Initialized
INFO - 2018-03-09 07:17:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 07:17:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 07:17:31 --> Utf8 Class Initialized
INFO - 2018-03-09 07:17:31 --> URI Class Initialized
INFO - 2018-03-09 07:17:31 --> Router Class Initialized
INFO - 2018-03-09 07:17:31 --> Output Class Initialized
INFO - 2018-03-09 07:17:31 --> Security Class Initialized
DEBUG - 2018-03-09 07:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 07:17:31 --> Input Class Initialized
INFO - 2018-03-09 07:17:31 --> Language Class Initialized
INFO - 2018-03-09 07:17:31 --> Loader Class Initialized
INFO - 2018-03-09 07:17:31 --> Helper loaded: common_helper
INFO - 2018-03-09 07:17:31 --> Database Driver Class Initialized
INFO - 2018-03-09 07:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 07:17:31 --> Email Class Initialized
INFO - 2018-03-09 07:17:31 --> Controller Class Initialized
INFO - 2018-03-09 07:17:31 --> Helper loaded: form_helper
INFO - 2018-03-09 07:17:31 --> Form Validation Class Initialized
INFO - 2018-03-09 07:17:31 --> Helper loaded: email_helper
DEBUG - 2018-03-09 07:17:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 07:17:31 --> Helper loaded: url_helper
INFO - 2018-03-09 07:17:31 --> Model Class Initialized
INFO - 2018-03-09 07:17:31 --> Model Class Initialized
INFO - 2018-03-09 07:17:31 --> Model Class Initialized
INFO - 2018-03-09 11:47:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-03-09 11:47:31 --> Call to undefined function sideMenu()
ERROR - 2018-03-09 11:47:31 --> Severity: Error --> Call to undefined function sideMenu() C:\xampp\htdocs\FlickNews\admin\application\views\News\addNews.php 29
INFO - 2018-03-09 07:18:24 --> Config Class Initialized
INFO - 2018-03-09 07:18:24 --> Hooks Class Initialized
DEBUG - 2018-03-09 07:18:24 --> UTF-8 Support Enabled
INFO - 2018-03-09 07:18:24 --> Utf8 Class Initialized
INFO - 2018-03-09 07:18:24 --> URI Class Initialized
INFO - 2018-03-09 07:18:24 --> Router Class Initialized
INFO - 2018-03-09 07:18:24 --> Output Class Initialized
INFO - 2018-03-09 07:18:24 --> Security Class Initialized
DEBUG - 2018-03-09 07:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 07:18:24 --> Input Class Initialized
INFO - 2018-03-09 07:18:24 --> Language Class Initialized
INFO - 2018-03-09 07:18:24 --> Loader Class Initialized
INFO - 2018-03-09 07:18:24 --> Helper loaded: common_helper
INFO - 2018-03-09 07:18:24 --> Database Driver Class Initialized
INFO - 2018-03-09 07:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 07:18:24 --> Email Class Initialized
INFO - 2018-03-09 07:18:24 --> Controller Class Initialized
INFO - 2018-03-09 07:18:24 --> Helper loaded: form_helper
INFO - 2018-03-09 07:18:24 --> Form Validation Class Initialized
INFO - 2018-03-09 07:18:24 --> Helper loaded: email_helper
DEBUG - 2018-03-09 07:18:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 07:18:24 --> Helper loaded: url_helper
INFO - 2018-03-09 07:18:24 --> Model Class Initialized
INFO - 2018-03-09 07:18:24 --> Model Class Initialized
INFO - 2018-03-09 07:18:24 --> Model Class Initialized
INFO - 2018-03-09 11:48:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 11:48:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 11:48:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 11:48:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 11:48:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 11:48:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 11:48:24 --> Final output sent to browser
DEBUG - 2018-03-09 11:48:24 --> Total execution time: 0.1620
INFO - 2018-03-09 07:29:40 --> Config Class Initialized
INFO - 2018-03-09 07:29:40 --> Hooks Class Initialized
DEBUG - 2018-03-09 07:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-09 07:29:40 --> Utf8 Class Initialized
INFO - 2018-03-09 07:29:40 --> URI Class Initialized
INFO - 2018-03-09 07:29:40 --> Router Class Initialized
INFO - 2018-03-09 07:29:40 --> Output Class Initialized
INFO - 2018-03-09 07:29:40 --> Security Class Initialized
DEBUG - 2018-03-09 07:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 07:29:40 --> Input Class Initialized
INFO - 2018-03-09 07:29:40 --> Language Class Initialized
INFO - 2018-03-09 07:29:40 --> Loader Class Initialized
INFO - 2018-03-09 07:29:40 --> Helper loaded: common_helper
INFO - 2018-03-09 07:29:40 --> Database Driver Class Initialized
INFO - 2018-03-09 07:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 07:29:40 --> Email Class Initialized
INFO - 2018-03-09 07:29:40 --> Controller Class Initialized
INFO - 2018-03-09 07:29:40 --> Helper loaded: form_helper
INFO - 2018-03-09 07:29:40 --> Form Validation Class Initialized
INFO - 2018-03-09 07:29:40 --> Helper loaded: email_helper
DEBUG - 2018-03-09 07:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 07:29:40 --> Helper loaded: url_helper
INFO - 2018-03-09 07:29:40 --> Model Class Initialized
INFO - 2018-03-09 07:29:40 --> Model Class Initialized
INFO - 2018-03-09 07:29:40 --> Model Class Initialized
INFO - 2018-03-09 11:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 11:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 11:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 11:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 11:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 11:59:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 11:59:40 --> Final output sent to browser
DEBUG - 2018-03-09 11:59:40 --> Total execution time: 0.1450
INFO - 2018-03-09 07:31:41 --> Config Class Initialized
INFO - 2018-03-09 07:31:41 --> Hooks Class Initialized
DEBUG - 2018-03-09 07:31:41 --> UTF-8 Support Enabled
INFO - 2018-03-09 07:31:41 --> Utf8 Class Initialized
INFO - 2018-03-09 07:31:41 --> URI Class Initialized
INFO - 2018-03-09 07:31:41 --> Router Class Initialized
INFO - 2018-03-09 07:31:41 --> Output Class Initialized
INFO - 2018-03-09 07:31:41 --> Security Class Initialized
DEBUG - 2018-03-09 07:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 07:31:41 --> Input Class Initialized
INFO - 2018-03-09 07:31:41 --> Language Class Initialized
INFO - 2018-03-09 07:31:41 --> Loader Class Initialized
INFO - 2018-03-09 07:31:41 --> Helper loaded: common_helper
INFO - 2018-03-09 07:31:41 --> Database Driver Class Initialized
INFO - 2018-03-09 07:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 07:31:41 --> Email Class Initialized
INFO - 2018-03-09 07:31:41 --> Controller Class Initialized
INFO - 2018-03-09 07:31:41 --> Helper loaded: form_helper
INFO - 2018-03-09 07:31:41 --> Form Validation Class Initialized
INFO - 2018-03-09 07:31:41 --> Helper loaded: email_helper
DEBUG - 2018-03-09 07:31:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 07:31:41 --> Helper loaded: url_helper
INFO - 2018-03-09 07:31:41 --> Model Class Initialized
INFO - 2018-03-09 07:31:41 --> Model Class Initialized
INFO - 2018-03-09 07:31:41 --> Model Class Initialized
INFO - 2018-03-09 12:01:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 12:01:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 12:01:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 12:01:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 12:01:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 12:01:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 12:01:41 --> Final output sent to browser
DEBUG - 2018-03-09 12:01:41 --> Total execution time: 0.1430
INFO - 2018-03-09 07:34:22 --> Config Class Initialized
INFO - 2018-03-09 07:34:22 --> Hooks Class Initialized
DEBUG - 2018-03-09 07:34:22 --> UTF-8 Support Enabled
INFO - 2018-03-09 07:34:22 --> Utf8 Class Initialized
INFO - 2018-03-09 07:34:22 --> URI Class Initialized
INFO - 2018-03-09 07:34:22 --> Router Class Initialized
INFO - 2018-03-09 07:34:22 --> Output Class Initialized
INFO - 2018-03-09 07:34:22 --> Security Class Initialized
DEBUG - 2018-03-09 07:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 07:34:22 --> Input Class Initialized
INFO - 2018-03-09 07:34:22 --> Language Class Initialized
INFO - 2018-03-09 07:34:22 --> Loader Class Initialized
INFO - 2018-03-09 07:34:22 --> Helper loaded: common_helper
INFO - 2018-03-09 07:34:22 --> Database Driver Class Initialized
INFO - 2018-03-09 07:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 07:34:22 --> Email Class Initialized
INFO - 2018-03-09 07:34:22 --> Controller Class Initialized
INFO - 2018-03-09 07:34:22 --> Helper loaded: form_helper
INFO - 2018-03-09 07:34:22 --> Form Validation Class Initialized
INFO - 2018-03-09 07:34:22 --> Helper loaded: email_helper
DEBUG - 2018-03-09 07:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 07:34:22 --> Helper loaded: url_helper
INFO - 2018-03-09 07:34:22 --> Model Class Initialized
INFO - 2018-03-09 07:34:22 --> Model Class Initialized
INFO - 2018-03-09 07:34:22 --> Model Class Initialized
INFO - 2018-03-09 12:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 12:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 12:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 12:04:22 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 12:04:22 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 12:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 12:04:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 12:04:22 --> Final output sent to browser
DEBUG - 2018-03-09 12:04:22 --> Total execution time: 0.2530
INFO - 2018-03-09 08:10:40 --> Config Class Initialized
INFO - 2018-03-09 08:10:40 --> Hooks Class Initialized
DEBUG - 2018-03-09 08:10:40 --> UTF-8 Support Enabled
INFO - 2018-03-09 08:10:40 --> Utf8 Class Initialized
INFO - 2018-03-09 08:10:40 --> URI Class Initialized
INFO - 2018-03-09 08:10:40 --> Router Class Initialized
INFO - 2018-03-09 08:10:40 --> Output Class Initialized
INFO - 2018-03-09 08:10:40 --> Security Class Initialized
DEBUG - 2018-03-09 08:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 08:10:40 --> Input Class Initialized
INFO - 2018-03-09 08:10:40 --> Language Class Initialized
INFO - 2018-03-09 08:10:40 --> Loader Class Initialized
INFO - 2018-03-09 08:10:40 --> Helper loaded: common_helper
INFO - 2018-03-09 08:10:40 --> Database Driver Class Initialized
INFO - 2018-03-09 08:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 08:10:40 --> Email Class Initialized
INFO - 2018-03-09 08:10:40 --> Controller Class Initialized
INFO - 2018-03-09 08:10:40 --> Helper loaded: form_helper
INFO - 2018-03-09 08:10:40 --> Form Validation Class Initialized
INFO - 2018-03-09 08:10:40 --> Helper loaded: email_helper
DEBUG - 2018-03-09 08:10:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 08:10:40 --> Helper loaded: url_helper
INFO - 2018-03-09 08:10:40 --> Model Class Initialized
INFO - 2018-03-09 08:10:40 --> Model Class Initialized
INFO - 2018-03-09 08:10:40 --> Model Class Initialized
INFO - 2018-03-09 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 12:40:40 --> Final output sent to browser
DEBUG - 2018-03-09 12:40:40 --> Total execution time: 0.2110
INFO - 2018-03-09 08:12:01 --> Config Class Initialized
INFO - 2018-03-09 08:12:01 --> Hooks Class Initialized
DEBUG - 2018-03-09 08:12:01 --> UTF-8 Support Enabled
INFO - 2018-03-09 08:12:01 --> Utf8 Class Initialized
INFO - 2018-03-09 08:12:01 --> URI Class Initialized
INFO - 2018-03-09 08:12:01 --> Router Class Initialized
INFO - 2018-03-09 08:12:01 --> Output Class Initialized
INFO - 2018-03-09 08:12:01 --> Security Class Initialized
DEBUG - 2018-03-09 08:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 08:12:01 --> Input Class Initialized
INFO - 2018-03-09 08:12:01 --> Language Class Initialized
INFO - 2018-03-09 08:12:01 --> Loader Class Initialized
INFO - 2018-03-09 08:12:01 --> Helper loaded: common_helper
INFO - 2018-03-09 08:12:02 --> Database Driver Class Initialized
INFO - 2018-03-09 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 08:12:02 --> Email Class Initialized
INFO - 2018-03-09 08:12:02 --> Controller Class Initialized
INFO - 2018-03-09 08:12:02 --> Helper loaded: form_helper
INFO - 2018-03-09 08:12:02 --> Form Validation Class Initialized
INFO - 2018-03-09 08:12:02 --> Helper loaded: email_helper
DEBUG - 2018-03-09 08:12:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 08:12:02 --> Helper loaded: url_helper
INFO - 2018-03-09 08:12:02 --> Model Class Initialized
INFO - 2018-03-09 08:12:02 --> Model Class Initialized
INFO - 2018-03-09 08:12:02 --> Model Class Initialized
INFO - 2018-03-09 12:42:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 12:42:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 12:42:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 12:42:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 12:42:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 12:42:02 --> Final output sent to browser
DEBUG - 2018-03-09 12:42:02 --> Total execution time: 0.1440
INFO - 2018-03-09 13:37:15 --> Config Class Initialized
INFO - 2018-03-09 13:37:15 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:15 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:15 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:15 --> URI Class Initialized
INFO - 2018-03-09 13:37:15 --> Router Class Initialized
INFO - 2018-03-09 13:37:16 --> Output Class Initialized
INFO - 2018-03-09 13:37:16 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:16 --> Input Class Initialized
INFO - 2018-03-09 13:37:16 --> Language Class Initialized
INFO - 2018-03-09 13:37:16 --> Loader Class Initialized
INFO - 2018-03-09 13:37:16 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:17 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:17 --> Email Class Initialized
INFO - 2018-03-09 13:37:17 --> Controller Class Initialized
INFO - 2018-03-09 13:37:17 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:17 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:17 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:17 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:17 --> Model Class Initialized
INFO - 2018-03-09 13:37:17 --> Model Class Initialized
INFO - 2018-03-09 13:37:17 --> Model Class Initialized
INFO - 2018-03-09 18:07:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:07:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:07:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 18:07:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 18:07:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:07:19 --> Final output sent to browser
DEBUG - 2018-03-09 18:07:19 --> Total execution time: 3.9692
INFO - 2018-03-09 13:37:19 --> Config Class Initialized
INFO - 2018-03-09 13:37:19 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:19 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:19 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:19 --> URI Class Initialized
INFO - 2018-03-09 13:37:19 --> Router Class Initialized
INFO - 2018-03-09 13:37:19 --> Output Class Initialized
INFO - 2018-03-09 13:37:19 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:19 --> Input Class Initialized
INFO - 2018-03-09 13:37:19 --> Language Class Initialized
INFO - 2018-03-09 13:37:19 --> Loader Class Initialized
INFO - 2018-03-09 13:37:19 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:19 --> Database Driver Class Initialized
ERROR - 2018-03-09 13:37:20 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-09 13:37:20 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-09 13:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:20 --> Email Class Initialized
INFO - 2018-03-09 13:37:20 --> Controller Class Initialized
INFO - 2018-03-09 13:37:20 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:20 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:20 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:20 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:20 --> Model Class Initialized
INFO - 2018-03-09 13:37:20 --> Model Class Initialized
INFO - 2018-03-09 13:37:20 --> Model Class Initialized
INFO - 2018-03-09 13:37:32 --> Config Class Initialized
INFO - 2018-03-09 13:37:32 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:32 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:32 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:32 --> URI Class Initialized
INFO - 2018-03-09 13:37:32 --> Router Class Initialized
INFO - 2018-03-09 13:37:32 --> Output Class Initialized
INFO - 2018-03-09 13:37:32 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:32 --> Input Class Initialized
INFO - 2018-03-09 13:37:32 --> Language Class Initialized
INFO - 2018-03-09 13:37:32 --> Loader Class Initialized
INFO - 2018-03-09 13:37:32 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:32 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:32 --> Email Class Initialized
INFO - 2018-03-09 13:37:32 --> Controller Class Initialized
INFO - 2018-03-09 13:37:32 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:32 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:32 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:32 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:32 --> Model Class Initialized
INFO - 2018-03-09 13:37:32 --> Model Class Initialized
INFO - 2018-03-09 13:37:32 --> Config Class Initialized
INFO - 2018-03-09 13:37:32 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:32 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:32 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:32 --> URI Class Initialized
DEBUG - 2018-03-09 13:37:32 --> No URI present. Default controller set.
INFO - 2018-03-09 13:37:32 --> Router Class Initialized
INFO - 2018-03-09 13:37:32 --> Output Class Initialized
INFO - 2018-03-09 13:37:32 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:32 --> Input Class Initialized
INFO - 2018-03-09 13:37:32 --> Language Class Initialized
INFO - 2018-03-09 13:37:32 --> Loader Class Initialized
INFO - 2018-03-09 13:37:32 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:32 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:32 --> Email Class Initialized
INFO - 2018-03-09 13:37:32 --> Controller Class Initialized
INFO - 2018-03-09 13:37:32 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:32 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:32 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:32 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:32 --> Model Class Initialized
INFO - 2018-03-09 13:37:32 --> Model Class Initialized
INFO - 2018-03-09 13:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-09 13:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 13:37:33 --> Final output sent to browser
DEBUG - 2018-03-09 13:37:33 --> Total execution time: 0.6260
INFO - 2018-03-09 13:37:36 --> Config Class Initialized
INFO - 2018-03-09 13:37:36 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:36 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:36 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:36 --> URI Class Initialized
DEBUG - 2018-03-09 13:37:36 --> No URI present. Default controller set.
INFO - 2018-03-09 13:37:36 --> Router Class Initialized
INFO - 2018-03-09 13:37:36 --> Output Class Initialized
INFO - 2018-03-09 13:37:36 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:36 --> Input Class Initialized
INFO - 2018-03-09 13:37:36 --> Language Class Initialized
INFO - 2018-03-09 13:37:36 --> Loader Class Initialized
INFO - 2018-03-09 13:37:36 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:36 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:36 --> Email Class Initialized
INFO - 2018-03-09 13:37:36 --> Controller Class Initialized
INFO - 2018-03-09 13:37:36 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:36 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:36 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:36 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:36 --> Model Class Initialized
INFO - 2018-03-09 13:37:36 --> Model Class Initialized
DEBUG - 2018-03-09 13:37:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-09 13:37:39 --> Config Class Initialized
INFO - 2018-03-09 13:37:39 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:39 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:39 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:39 --> URI Class Initialized
INFO - 2018-03-09 13:37:39 --> Router Class Initialized
INFO - 2018-03-09 13:37:39 --> Output Class Initialized
INFO - 2018-03-09 13:37:39 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:39 --> Input Class Initialized
INFO - 2018-03-09 13:37:39 --> Language Class Initialized
INFO - 2018-03-09 13:37:39 --> Loader Class Initialized
INFO - 2018-03-09 13:37:39 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:39 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:39 --> Email Class Initialized
INFO - 2018-03-09 13:37:39 --> Controller Class Initialized
INFO - 2018-03-09 13:37:39 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:39 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:39 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:39 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:39 --> Model Class Initialized
INFO - 2018-03-09 13:37:39 --> Model Class Initialized
INFO - 2018-03-09 13:37:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 13:37:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 13:37:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-09 13:37:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 13:37:39 --> Final output sent to browser
DEBUG - 2018-03-09 13:37:39 --> Total execution time: 0.1810
INFO - 2018-03-09 13:37:42 --> Config Class Initialized
INFO - 2018-03-09 13:37:42 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:42 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:42 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:42 --> URI Class Initialized
INFO - 2018-03-09 13:37:42 --> Router Class Initialized
INFO - 2018-03-09 13:37:42 --> Output Class Initialized
INFO - 2018-03-09 13:37:42 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:42 --> Input Class Initialized
INFO - 2018-03-09 13:37:42 --> Language Class Initialized
INFO - 2018-03-09 13:37:42 --> Loader Class Initialized
INFO - 2018-03-09 13:37:42 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:42 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:42 --> Email Class Initialized
INFO - 2018-03-09 13:37:42 --> Controller Class Initialized
INFO - 2018-03-09 13:37:42 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:42 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:42 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:42 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:42 --> Model Class Initialized
INFO - 2018-03-09 13:37:42 --> Model Class Initialized
INFO - 2018-03-09 13:37:42 --> Model Class Initialized
INFO - 2018-03-09 18:07:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:07:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:07:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:07:42 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:07:42 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 18:07:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 18:07:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:07:42 --> Final output sent to browser
DEBUG - 2018-03-09 18:07:42 --> Total execution time: 0.1410
INFO - 2018-03-09 13:37:50 --> Config Class Initialized
INFO - 2018-03-09 13:37:50 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:37:50 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:37:50 --> Utf8 Class Initialized
INFO - 2018-03-09 13:37:50 --> URI Class Initialized
INFO - 2018-03-09 13:37:50 --> Router Class Initialized
INFO - 2018-03-09 13:37:50 --> Output Class Initialized
INFO - 2018-03-09 13:37:50 --> Security Class Initialized
DEBUG - 2018-03-09 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:37:50 --> Input Class Initialized
INFO - 2018-03-09 13:37:50 --> Language Class Initialized
INFO - 2018-03-09 13:37:50 --> Loader Class Initialized
INFO - 2018-03-09 13:37:50 --> Helper loaded: common_helper
INFO - 2018-03-09 13:37:50 --> Database Driver Class Initialized
INFO - 2018-03-09 13:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:37:50 --> Email Class Initialized
INFO - 2018-03-09 13:37:50 --> Controller Class Initialized
INFO - 2018-03-09 13:37:50 --> Helper loaded: form_helper
INFO - 2018-03-09 13:37:50 --> Form Validation Class Initialized
INFO - 2018-03-09 13:37:50 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:37:50 --> Helper loaded: url_helper
INFO - 2018-03-09 13:37:50 --> Model Class Initialized
INFO - 2018-03-09 13:37:50 --> Model Class Initialized
INFO - 2018-03-09 13:37:50 --> Model Class Initialized
INFO - 2018-03-09 18:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 18:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-09 18:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 18:07:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:07:50 --> Final output sent to browser
DEBUG - 2018-03-09 18:07:50 --> Total execution time: 0.1000
INFO - 2018-03-09 13:38:29 --> Config Class Initialized
INFO - 2018-03-09 13:38:29 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:38:29 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:38:29 --> Utf8 Class Initialized
INFO - 2018-03-09 13:38:29 --> URI Class Initialized
INFO - 2018-03-09 13:38:29 --> Router Class Initialized
INFO - 2018-03-09 13:38:29 --> Output Class Initialized
INFO - 2018-03-09 13:38:29 --> Security Class Initialized
DEBUG - 2018-03-09 13:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:38:29 --> Input Class Initialized
INFO - 2018-03-09 13:38:29 --> Language Class Initialized
INFO - 2018-03-09 13:38:29 --> Loader Class Initialized
INFO - 2018-03-09 13:38:29 --> Helper loaded: common_helper
INFO - 2018-03-09 13:38:29 --> Database Driver Class Initialized
INFO - 2018-03-09 13:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:38:29 --> Email Class Initialized
INFO - 2018-03-09 13:38:29 --> Controller Class Initialized
INFO - 2018-03-09 13:38:29 --> Helper loaded: form_helper
INFO - 2018-03-09 13:38:29 --> Form Validation Class Initialized
INFO - 2018-03-09 13:38:29 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:38:29 --> Helper loaded: url_helper
INFO - 2018-03-09 13:38:29 --> Model Class Initialized
INFO - 2018-03-09 13:38:29 --> Model Class Initialized
INFO - 2018-03-09 13:38:29 --> Model Class Initialized
DEBUG - 2018-03-09 18:08:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-09 18:08:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-09 13:38:31 --> Config Class Initialized
INFO - 2018-03-09 13:38:31 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:38:31 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:38:31 --> Utf8 Class Initialized
INFO - 2018-03-09 13:38:31 --> URI Class Initialized
INFO - 2018-03-09 13:38:31 --> Router Class Initialized
INFO - 2018-03-09 13:38:31 --> Output Class Initialized
INFO - 2018-03-09 13:38:31 --> Security Class Initialized
DEBUG - 2018-03-09 13:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:38:31 --> Input Class Initialized
INFO - 2018-03-09 13:38:31 --> Language Class Initialized
INFO - 2018-03-09 13:38:31 --> Loader Class Initialized
INFO - 2018-03-09 13:38:31 --> Helper loaded: common_helper
INFO - 2018-03-09 13:38:31 --> Database Driver Class Initialized
INFO - 2018-03-09 13:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:38:31 --> Email Class Initialized
INFO - 2018-03-09 13:38:31 --> Controller Class Initialized
INFO - 2018-03-09 13:38:31 --> Helper loaded: form_helper
INFO - 2018-03-09 13:38:31 --> Form Validation Class Initialized
INFO - 2018-03-09 13:38:31 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:38:31 --> Helper loaded: url_helper
INFO - 2018-03-09 13:38:31 --> Model Class Initialized
INFO - 2018-03-09 13:38:31 --> Model Class Initialized
INFO - 2018-03-09 13:38:31 --> Model Class Initialized
INFO - 2018-03-09 18:08:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:08:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:08:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:08:31 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:08:31 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 18:08:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 18:08:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:08:31 --> Final output sent to browser
DEBUG - 2018-03-09 18:08:31 --> Total execution time: 0.1860
INFO - 2018-03-09 13:38:38 --> Config Class Initialized
INFO - 2018-03-09 13:38:38 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:38:38 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:38:38 --> Utf8 Class Initialized
INFO - 2018-03-09 13:38:38 --> URI Class Initialized
INFO - 2018-03-09 13:38:38 --> Router Class Initialized
INFO - 2018-03-09 13:38:38 --> Output Class Initialized
INFO - 2018-03-09 13:38:38 --> Security Class Initialized
DEBUG - 2018-03-09 13:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:38:38 --> Input Class Initialized
INFO - 2018-03-09 13:38:38 --> Language Class Initialized
INFO - 2018-03-09 13:38:38 --> Loader Class Initialized
INFO - 2018-03-09 13:38:38 --> Helper loaded: common_helper
INFO - 2018-03-09 13:38:38 --> Database Driver Class Initialized
INFO - 2018-03-09 13:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:38:38 --> Email Class Initialized
INFO - 2018-03-09 13:38:38 --> Controller Class Initialized
INFO - 2018-03-09 13:38:38 --> Helper loaded: form_helper
INFO - 2018-03-09 13:38:38 --> Form Validation Class Initialized
INFO - 2018-03-09 13:38:38 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:38:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:38:38 --> Helper loaded: url_helper
INFO - 2018-03-09 13:38:38 --> Model Class Initialized
INFO - 2018-03-09 13:38:38 --> Model Class Initialized
INFO - 2018-03-09 13:38:38 --> Model Class Initialized
INFO - 2018-03-09 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 18:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:08:38 --> Final output sent to browser
DEBUG - 2018-03-09 18:08:38 --> Total execution time: 0.1490
INFO - 2018-03-09 13:39:00 --> Config Class Initialized
INFO - 2018-03-09 13:39:00 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:39:00 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:39:00 --> Utf8 Class Initialized
INFO - 2018-03-09 13:39:00 --> URI Class Initialized
INFO - 2018-03-09 13:39:00 --> Router Class Initialized
INFO - 2018-03-09 13:39:00 --> Output Class Initialized
INFO - 2018-03-09 13:39:00 --> Security Class Initialized
DEBUG - 2018-03-09 13:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:39:00 --> Input Class Initialized
INFO - 2018-03-09 13:39:00 --> Language Class Initialized
INFO - 2018-03-09 13:39:00 --> Loader Class Initialized
INFO - 2018-03-09 13:39:00 --> Helper loaded: common_helper
INFO - 2018-03-09 13:39:00 --> Database Driver Class Initialized
INFO - 2018-03-09 13:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:39:00 --> Email Class Initialized
INFO - 2018-03-09 13:39:00 --> Controller Class Initialized
INFO - 2018-03-09 13:39:00 --> Helper loaded: form_helper
INFO - 2018-03-09 13:39:00 --> Form Validation Class Initialized
INFO - 2018-03-09 13:39:00 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:39:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:39:00 --> Helper loaded: url_helper
INFO - 2018-03-09 13:39:00 --> Model Class Initialized
INFO - 2018-03-09 13:39:00 --> Model Class Initialized
INFO - 2018-03-09 13:39:00 --> Model Class Initialized
INFO - 2018-03-09 18:09:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:09:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:09:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-09 18:09:00 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-09 18:09:00 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-09 18:09:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-09 18:09:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:09:00 --> Final output sent to browser
DEBUG - 2018-03-09 18:09:00 --> Total execution time: 0.2250
INFO - 2018-03-09 13:47:59 --> Config Class Initialized
INFO - 2018-03-09 13:47:59 --> Hooks Class Initialized
DEBUG - 2018-03-09 13:47:59 --> UTF-8 Support Enabled
INFO - 2018-03-09 13:47:59 --> Utf8 Class Initialized
INFO - 2018-03-09 13:47:59 --> URI Class Initialized
INFO - 2018-03-09 13:47:59 --> Router Class Initialized
INFO - 2018-03-09 13:47:59 --> Output Class Initialized
INFO - 2018-03-09 13:47:59 --> Security Class Initialized
DEBUG - 2018-03-09 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-09 13:47:59 --> Input Class Initialized
INFO - 2018-03-09 13:47:59 --> Language Class Initialized
INFO - 2018-03-09 13:47:59 --> Loader Class Initialized
INFO - 2018-03-09 13:47:59 --> Helper loaded: common_helper
INFO - 2018-03-09 13:47:59 --> Database Driver Class Initialized
INFO - 2018-03-09 13:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-09 13:47:59 --> Email Class Initialized
INFO - 2018-03-09 13:47:59 --> Controller Class Initialized
INFO - 2018-03-09 13:47:59 --> Helper loaded: form_helper
INFO - 2018-03-09 13:47:59 --> Form Validation Class Initialized
INFO - 2018-03-09 13:47:59 --> Helper loaded: email_helper
DEBUG - 2018-03-09 13:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-09 13:47:59 --> Helper loaded: url_helper
INFO - 2018-03-09 13:47:59 --> Model Class Initialized
INFO - 2018-03-09 13:47:59 --> Model Class Initialized
INFO - 2018-03-09 13:47:59 --> Model Class Initialized
INFO - 2018-03-09 18:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-09 18:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-09 18:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-09 18:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-09 18:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-09 18:17:59 --> Final output sent to browser
DEBUG - 2018-03-09 18:17:59 --> Total execution time: 0.1960
