<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-10 07:07:56 --> Config Class Initialized
INFO - 2018-03-10 07:07:56 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:07:56 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:07:56 --> Utf8 Class Initialized
INFO - 2018-03-10 07:07:56 --> URI Class Initialized
INFO - 2018-03-10 07:07:56 --> Router Class Initialized
INFO - 2018-03-10 07:07:56 --> Output Class Initialized
INFO - 2018-03-10 07:07:56 --> Security Class Initialized
DEBUG - 2018-03-10 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:07:56 --> Input Class Initialized
INFO - 2018-03-10 07:07:56 --> Language Class Initialized
INFO - 2018-03-10 07:07:56 --> Loader Class Initialized
INFO - 2018-03-10 07:07:56 --> Helper loaded: common_helper
INFO - 2018-03-10 07:07:57 --> Database Driver Class Initialized
ERROR - 2018-03-10 07:07:57 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-10 07:07:57 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-10 07:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:07:57 --> Email Class Initialized
INFO - 2018-03-10 07:07:57 --> Controller Class Initialized
INFO - 2018-03-10 07:07:57 --> Helper loaded: form_helper
INFO - 2018-03-10 07:07:57 --> Form Validation Class Initialized
INFO - 2018-03-10 07:07:57 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:07:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:07:57 --> Helper loaded: url_helper
INFO - 2018-03-10 07:07:57 --> Model Class Initialized
INFO - 2018-03-10 07:07:57 --> Model Class Initialized
INFO - 2018-03-10 07:07:57 --> Model Class Initialized
INFO - 2018-03-10 07:07:59 --> Config Class Initialized
INFO - 2018-03-10 07:07:59 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:07:59 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:07:59 --> Utf8 Class Initialized
INFO - 2018-03-10 07:07:59 --> URI Class Initialized
INFO - 2018-03-10 07:07:59 --> Router Class Initialized
INFO - 2018-03-10 07:07:59 --> Output Class Initialized
INFO - 2018-03-10 07:07:59 --> Security Class Initialized
DEBUG - 2018-03-10 07:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:07:59 --> Input Class Initialized
INFO - 2018-03-10 07:07:59 --> Language Class Initialized
INFO - 2018-03-10 07:07:59 --> Loader Class Initialized
INFO - 2018-03-10 07:07:59 --> Helper loaded: common_helper
INFO - 2018-03-10 07:07:59 --> Database Driver Class Initialized
INFO - 2018-03-10 07:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:07:59 --> Email Class Initialized
INFO - 2018-03-10 07:07:59 --> Controller Class Initialized
INFO - 2018-03-10 07:07:59 --> Helper loaded: form_helper
INFO - 2018-03-10 07:07:59 --> Form Validation Class Initialized
INFO - 2018-03-10 07:07:59 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:07:59 --> Helper loaded: url_helper
INFO - 2018-03-10 07:07:59 --> Model Class Initialized
INFO - 2018-03-10 07:07:59 --> Model Class Initialized
INFO - 2018-03-10 07:07:59 --> Config Class Initialized
INFO - 2018-03-10 07:07:59 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:07:59 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:07:59 --> Utf8 Class Initialized
INFO - 2018-03-10 07:07:59 --> URI Class Initialized
DEBUG - 2018-03-10 07:07:59 --> No URI present. Default controller set.
INFO - 2018-03-10 07:07:59 --> Router Class Initialized
INFO - 2018-03-10 07:07:59 --> Output Class Initialized
INFO - 2018-03-10 07:07:59 --> Security Class Initialized
DEBUG - 2018-03-10 07:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:07:59 --> Input Class Initialized
INFO - 2018-03-10 07:07:59 --> Language Class Initialized
INFO - 2018-03-10 07:07:59 --> Loader Class Initialized
INFO - 2018-03-10 07:07:59 --> Helper loaded: common_helper
INFO - 2018-03-10 07:07:59 --> Database Driver Class Initialized
INFO - 2018-03-10 07:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:07:59 --> Email Class Initialized
INFO - 2018-03-10 07:07:59 --> Controller Class Initialized
INFO - 2018-03-10 07:07:59 --> Helper loaded: form_helper
INFO - 2018-03-10 07:07:59 --> Form Validation Class Initialized
INFO - 2018-03-10 07:07:59 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:07:59 --> Helper loaded: url_helper
INFO - 2018-03-10 07:07:59 --> Model Class Initialized
INFO - 2018-03-10 07:07:59 --> Model Class Initialized
INFO - 2018-03-10 07:07:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-10 07:08:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 07:08:00 --> Final output sent to browser
DEBUG - 2018-03-10 07:08:00 --> Total execution time: 0.2130
INFO - 2018-03-10 07:08:03 --> Config Class Initialized
INFO - 2018-03-10 07:08:03 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:08:03 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:08:03 --> Utf8 Class Initialized
INFO - 2018-03-10 07:08:03 --> URI Class Initialized
DEBUG - 2018-03-10 07:08:03 --> No URI present. Default controller set.
INFO - 2018-03-10 07:08:03 --> Router Class Initialized
INFO - 2018-03-10 07:08:03 --> Output Class Initialized
INFO - 2018-03-10 07:08:03 --> Security Class Initialized
DEBUG - 2018-03-10 07:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:08:03 --> Input Class Initialized
INFO - 2018-03-10 07:08:03 --> Language Class Initialized
INFO - 2018-03-10 07:08:03 --> Loader Class Initialized
INFO - 2018-03-10 07:08:03 --> Helper loaded: common_helper
INFO - 2018-03-10 07:08:03 --> Database Driver Class Initialized
INFO - 2018-03-10 07:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:08:03 --> Email Class Initialized
INFO - 2018-03-10 07:08:03 --> Controller Class Initialized
INFO - 2018-03-10 07:08:03 --> Helper loaded: form_helper
INFO - 2018-03-10 07:08:03 --> Form Validation Class Initialized
INFO - 2018-03-10 07:08:03 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:08:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:08:03 --> Helper loaded: url_helper
INFO - 2018-03-10 07:08:03 --> Model Class Initialized
INFO - 2018-03-10 07:08:03 --> Model Class Initialized
DEBUG - 2018-03-10 07:08:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:08:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-10 07:08:06 --> Config Class Initialized
INFO - 2018-03-10 07:08:06 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:08:06 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:08:06 --> Utf8 Class Initialized
INFO - 2018-03-10 07:08:06 --> URI Class Initialized
INFO - 2018-03-10 07:08:06 --> Router Class Initialized
INFO - 2018-03-10 07:08:06 --> Output Class Initialized
INFO - 2018-03-10 07:08:06 --> Security Class Initialized
DEBUG - 2018-03-10 07:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:08:06 --> Input Class Initialized
INFO - 2018-03-10 07:08:06 --> Language Class Initialized
INFO - 2018-03-10 07:08:06 --> Loader Class Initialized
INFO - 2018-03-10 07:08:06 --> Helper loaded: common_helper
INFO - 2018-03-10 07:08:06 --> Database Driver Class Initialized
INFO - 2018-03-10 07:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:08:06 --> Email Class Initialized
INFO - 2018-03-10 07:08:06 --> Controller Class Initialized
INFO - 2018-03-10 07:08:06 --> Helper loaded: form_helper
INFO - 2018-03-10 07:08:06 --> Form Validation Class Initialized
INFO - 2018-03-10 07:08:06 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:08:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:08:06 --> Helper loaded: url_helper
INFO - 2018-03-10 07:08:06 --> Model Class Initialized
INFO - 2018-03-10 07:08:06 --> Model Class Initialized
INFO - 2018-03-10 07:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 07:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 07:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-10 07:08:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 07:08:06 --> Final output sent to browser
DEBUG - 2018-03-10 07:08:06 --> Total execution time: 0.3860
INFO - 2018-03-10 07:10:02 --> Config Class Initialized
INFO - 2018-03-10 07:10:02 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:10:02 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:10:02 --> Utf8 Class Initialized
INFO - 2018-03-10 07:10:02 --> URI Class Initialized
INFO - 2018-03-10 07:10:02 --> Router Class Initialized
INFO - 2018-03-10 07:10:02 --> Output Class Initialized
INFO - 2018-03-10 07:10:02 --> Security Class Initialized
DEBUG - 2018-03-10 07:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:10:02 --> Input Class Initialized
INFO - 2018-03-10 07:10:02 --> Language Class Initialized
INFO - 2018-03-10 07:10:02 --> Loader Class Initialized
INFO - 2018-03-10 07:10:02 --> Helper loaded: common_helper
INFO - 2018-03-10 07:10:02 --> Database Driver Class Initialized
INFO - 2018-03-10 07:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:10:03 --> Email Class Initialized
INFO - 2018-03-10 07:10:03 --> Controller Class Initialized
INFO - 2018-03-10 07:10:03 --> Helper loaded: form_helper
INFO - 2018-03-10 07:10:03 --> Form Validation Class Initialized
INFO - 2018-03-10 07:10:03 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:10:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:10:03 --> Helper loaded: url_helper
INFO - 2018-03-10 07:10:03 --> Model Class Initialized
INFO - 2018-03-10 07:10:03 --> Model Class Initialized
INFO - 2018-03-10 07:10:03 --> Model Class Initialized
INFO - 2018-03-10 11:40:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 11:40:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 11:40:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:03 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:03 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-10 11:40:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-10 11:40:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 11:40:03 --> Final output sent to browser
DEBUG - 2018-03-10 11:40:03 --> Total execution time: 0.2750
INFO - 2018-03-10 07:10:11 --> Config Class Initialized
INFO - 2018-03-10 07:10:11 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:10:11 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:10:11 --> Utf8 Class Initialized
INFO - 2018-03-10 07:10:11 --> URI Class Initialized
INFO - 2018-03-10 07:10:11 --> Router Class Initialized
INFO - 2018-03-10 07:10:11 --> Output Class Initialized
INFO - 2018-03-10 07:10:11 --> Security Class Initialized
DEBUG - 2018-03-10 07:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:10:11 --> Input Class Initialized
INFO - 2018-03-10 07:10:11 --> Language Class Initialized
INFO - 2018-03-10 07:10:11 --> Loader Class Initialized
INFO - 2018-03-10 07:10:11 --> Helper loaded: common_helper
INFO - 2018-03-10 07:10:11 --> Database Driver Class Initialized
INFO - 2018-03-10 07:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:10:11 --> Email Class Initialized
INFO - 2018-03-10 07:10:11 --> Controller Class Initialized
INFO - 2018-03-10 07:10:11 --> Helper loaded: form_helper
INFO - 2018-03-10 07:10:11 --> Form Validation Class Initialized
INFO - 2018-03-10 07:10:11 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:10:11 --> Helper loaded: url_helper
INFO - 2018-03-10 07:10:11 --> Model Class Initialized
INFO - 2018-03-10 07:10:11 --> Model Class Initialized
INFO - 2018-03-10 07:10:11 --> Model Class Initialized
INFO - 2018-03-10 11:40:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 11:40:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 11:40:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-10 11:40:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-10 11:40:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-10 11:40:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 11:40:11 --> Final output sent to browser
DEBUG - 2018-03-10 11:40:11 --> Total execution time: 0.1510
INFO - 2018-03-10 07:10:28 --> Config Class Initialized
INFO - 2018-03-10 07:10:28 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:10:28 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:10:28 --> Utf8 Class Initialized
INFO - 2018-03-10 07:10:28 --> URI Class Initialized
INFO - 2018-03-10 07:10:28 --> Router Class Initialized
INFO - 2018-03-10 07:10:28 --> Output Class Initialized
INFO - 2018-03-10 07:10:28 --> Security Class Initialized
DEBUG - 2018-03-10 07:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:10:28 --> Input Class Initialized
INFO - 2018-03-10 07:10:28 --> Language Class Initialized
INFO - 2018-03-10 07:10:28 --> Loader Class Initialized
INFO - 2018-03-10 07:10:28 --> Helper loaded: common_helper
INFO - 2018-03-10 07:10:28 --> Database Driver Class Initialized
INFO - 2018-03-10 07:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:10:28 --> Email Class Initialized
INFO - 2018-03-10 07:10:28 --> Controller Class Initialized
INFO - 2018-03-10 07:10:28 --> Helper loaded: form_helper
INFO - 2018-03-10 07:10:28 --> Form Validation Class Initialized
INFO - 2018-03-10 07:10:28 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:10:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:10:28 --> Helper loaded: url_helper
INFO - 2018-03-10 07:10:28 --> Model Class Initialized
INFO - 2018-03-10 07:10:28 --> Model Class Initialized
INFO - 2018-03-10 07:10:28 --> Model Class Initialized
INFO - 2018-03-10 11:40:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 11:40:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 11:40:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 11:40:28 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 11:40:28 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-10 11:40:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-10 11:40:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 11:40:28 --> Final output sent to browser
DEBUG - 2018-03-10 11:40:28 --> Total execution time: 0.2030
INFO - 2018-03-10 07:59:13 --> Config Class Initialized
INFO - 2018-03-10 07:59:13 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:13 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:13 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:13 --> URI Class Initialized
INFO - 2018-03-10 07:59:13 --> Router Class Initialized
INFO - 2018-03-10 07:59:13 --> Output Class Initialized
INFO - 2018-03-10 07:59:13 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:13 --> Input Class Initialized
INFO - 2018-03-10 07:59:13 --> Language Class Initialized
INFO - 2018-03-10 07:59:13 --> Loader Class Initialized
INFO - 2018-03-10 07:59:13 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:13 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:13 --> Email Class Initialized
INFO - 2018-03-10 07:59:13 --> Controller Class Initialized
INFO - 2018-03-10 07:59:13 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:13 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:13 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:13 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:13 --> Model Class Initialized
INFO - 2018-03-10 07:59:13 --> Model Class Initialized
INFO - 2018-03-10 07:59:13 --> Model Class Initialized
INFO - 2018-03-10 12:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 12:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 12:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-10 12:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-10 12:29:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 12:29:14 --> Final output sent to browser
DEBUG - 2018-03-10 12:29:14 --> Total execution time: 0.3160
INFO - 2018-03-10 07:59:23 --> Config Class Initialized
INFO - 2018-03-10 07:59:23 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:23 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:23 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:23 --> URI Class Initialized
INFO - 2018-03-10 07:59:23 --> Router Class Initialized
INFO - 2018-03-10 07:59:23 --> Output Class Initialized
INFO - 2018-03-10 07:59:23 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:23 --> Input Class Initialized
INFO - 2018-03-10 07:59:23 --> Language Class Initialized
INFO - 2018-03-10 07:59:23 --> Loader Class Initialized
INFO - 2018-03-10 07:59:23 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:23 --> Database Driver Class Initialized
ERROR - 2018-03-10 07:59:23 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-10 07:59:23 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-10 07:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:23 --> Email Class Initialized
INFO - 2018-03-10 07:59:23 --> Controller Class Initialized
INFO - 2018-03-10 07:59:23 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:23 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:23 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:23 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:23 --> Model Class Initialized
INFO - 2018-03-10 07:59:23 --> Model Class Initialized
INFO - 2018-03-10 07:59:23 --> Model Class Initialized
INFO - 2018-03-10 12:29:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 12:29:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 12:29:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:23 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:23 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-10 12:29:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-10 12:29:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 12:29:23 --> Final output sent to browser
DEBUG - 2018-03-10 12:29:23 --> Total execution time: 0.3070
INFO - 2018-03-10 07:59:26 --> Config Class Initialized
INFO - 2018-03-10 07:59:26 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:26 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:26 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:26 --> URI Class Initialized
INFO - 2018-03-10 07:59:26 --> Router Class Initialized
INFO - 2018-03-10 07:59:26 --> Output Class Initialized
INFO - 2018-03-10 07:59:26 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:26 --> Input Class Initialized
INFO - 2018-03-10 07:59:26 --> Language Class Initialized
INFO - 2018-03-10 07:59:27 --> Loader Class Initialized
INFO - 2018-03-10 07:59:27 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:27 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:27 --> Email Class Initialized
INFO - 2018-03-10 07:59:27 --> Controller Class Initialized
INFO - 2018-03-10 07:59:27 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:27 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:27 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:27 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:27 --> Model Class Initialized
INFO - 2018-03-10 07:59:27 --> Model Class Initialized
INFO - 2018-03-10 07:59:27 --> Model Class Initialized
INFO - 2018-03-10 12:29:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 12:29:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 12:29:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-10 12:29:27 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-10 12:29:27 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-10 12:29:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-10 12:29:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 12:29:27 --> Final output sent to browser
DEBUG - 2018-03-10 12:29:27 --> Total execution time: 0.1880
INFO - 2018-03-10 07:59:34 --> Config Class Initialized
INFO - 2018-03-10 07:59:34 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:34 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:34 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:34 --> URI Class Initialized
INFO - 2018-03-10 07:59:34 --> Router Class Initialized
INFO - 2018-03-10 07:59:34 --> Output Class Initialized
INFO - 2018-03-10 07:59:34 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:34 --> Input Class Initialized
INFO - 2018-03-10 07:59:34 --> Language Class Initialized
INFO - 2018-03-10 07:59:34 --> Loader Class Initialized
INFO - 2018-03-10 07:59:34 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:34 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:34 --> Email Class Initialized
INFO - 2018-03-10 07:59:34 --> Controller Class Initialized
INFO - 2018-03-10 07:59:34 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:34 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:34 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:34 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:34 --> Model Class Initialized
INFO - 2018-03-10 07:59:34 --> Model Class Initialized
INFO - 2018-03-10 07:59:34 --> Model Class Initialized
INFO - 2018-03-10 12:29:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 12:29:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 12:29:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-10 12:29:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-10 12:29:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 12:29:35 --> Final output sent to browser
DEBUG - 2018-03-10 12:29:35 --> Total execution time: 0.3590
INFO - 2018-03-10 07:59:43 --> Config Class Initialized
INFO - 2018-03-10 07:59:43 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:43 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:43 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:43 --> URI Class Initialized
INFO - 2018-03-10 07:59:43 --> Router Class Initialized
INFO - 2018-03-10 07:59:43 --> Output Class Initialized
INFO - 2018-03-10 07:59:43 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:43 --> Input Class Initialized
INFO - 2018-03-10 07:59:43 --> Language Class Initialized
INFO - 2018-03-10 07:59:43 --> Loader Class Initialized
INFO - 2018-03-10 07:59:43 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:43 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:43 --> Email Class Initialized
INFO - 2018-03-10 07:59:43 --> Controller Class Initialized
INFO - 2018-03-10 07:59:43 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:43 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:43 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:43 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:43 --> Model Class Initialized
INFO - 2018-03-10 07:59:43 --> Model Class Initialized
INFO - 2018-03-10 07:59:43 --> Model Class Initialized
INFO - 2018-03-10 07:59:43 --> Config Class Initialized
INFO - 2018-03-10 07:59:43 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:43 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:43 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:43 --> URI Class Initialized
INFO - 2018-03-10 07:59:43 --> Router Class Initialized
INFO - 2018-03-10 07:59:43 --> Output Class Initialized
INFO - 2018-03-10 07:59:43 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:43 --> Input Class Initialized
INFO - 2018-03-10 07:59:43 --> Language Class Initialized
INFO - 2018-03-10 07:59:43 --> Loader Class Initialized
INFO - 2018-03-10 07:59:43 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:43 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:43 --> Email Class Initialized
INFO - 2018-03-10 07:59:43 --> Controller Class Initialized
INFO - 2018-03-10 07:59:43 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:43 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:43 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:43 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:43 --> Model Class Initialized
INFO - 2018-03-10 07:59:43 --> Model Class Initialized
INFO - 2018-03-10 07:59:43 --> Model Class Initialized
INFO - 2018-03-10 12:29:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 12:29:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 12:29:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-10 12:29:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-10 12:29:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 12:29:43 --> Final output sent to browser
DEBUG - 2018-03-10 12:29:43 --> Total execution time: 0.1720
INFO - 2018-03-10 07:59:54 --> Config Class Initialized
INFO - 2018-03-10 07:59:54 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:54 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:54 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:54 --> URI Class Initialized
INFO - 2018-03-10 07:59:54 --> Router Class Initialized
INFO - 2018-03-10 07:59:54 --> Output Class Initialized
INFO - 2018-03-10 07:59:54 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:54 --> Input Class Initialized
INFO - 2018-03-10 07:59:54 --> Language Class Initialized
INFO - 2018-03-10 07:59:54 --> Loader Class Initialized
INFO - 2018-03-10 07:59:54 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:54 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:55 --> Email Class Initialized
INFO - 2018-03-10 07:59:55 --> Controller Class Initialized
INFO - 2018-03-10 07:59:55 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:55 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:55 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:55 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:55 --> Model Class Initialized
INFO - 2018-03-10 07:59:55 --> Model Class Initialized
INFO - 2018-03-10 07:59:55 --> Model Class Initialized
INFO - 2018-03-10 07:59:55 --> Config Class Initialized
INFO - 2018-03-10 07:59:55 --> Hooks Class Initialized
DEBUG - 2018-03-10 07:59:55 --> UTF-8 Support Enabled
INFO - 2018-03-10 07:59:55 --> Utf8 Class Initialized
INFO - 2018-03-10 07:59:55 --> URI Class Initialized
INFO - 2018-03-10 07:59:55 --> Router Class Initialized
INFO - 2018-03-10 07:59:55 --> Output Class Initialized
INFO - 2018-03-10 07:59:55 --> Security Class Initialized
DEBUG - 2018-03-10 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 07:59:55 --> Input Class Initialized
INFO - 2018-03-10 07:59:55 --> Language Class Initialized
INFO - 2018-03-10 07:59:55 --> Loader Class Initialized
INFO - 2018-03-10 07:59:55 --> Helper loaded: common_helper
INFO - 2018-03-10 07:59:55 --> Database Driver Class Initialized
INFO - 2018-03-10 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 07:59:55 --> Email Class Initialized
INFO - 2018-03-10 07:59:55 --> Controller Class Initialized
INFO - 2018-03-10 07:59:55 --> Helper loaded: form_helper
INFO - 2018-03-10 07:59:55 --> Form Validation Class Initialized
INFO - 2018-03-10 07:59:55 --> Helper loaded: email_helper
DEBUG - 2018-03-10 07:59:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 07:59:55 --> Helper loaded: url_helper
INFO - 2018-03-10 07:59:55 --> Model Class Initialized
INFO - 2018-03-10 07:59:55 --> Model Class Initialized
INFO - 2018-03-10 07:59:55 --> Model Class Initialized
INFO - 2018-03-10 12:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 12:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 12:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-10 12:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-10 12:29:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 12:29:55 --> Final output sent to browser
DEBUG - 2018-03-10 12:29:55 --> Total execution time: 0.1320
INFO - 2018-03-10 10:12:38 --> Config Class Initialized
INFO - 2018-03-10 10:12:38 --> Hooks Class Initialized
DEBUG - 2018-03-10 10:12:38 --> UTF-8 Support Enabled
INFO - 2018-03-10 10:12:38 --> Utf8 Class Initialized
INFO - 2018-03-10 10:12:38 --> URI Class Initialized
INFO - 2018-03-10 10:12:38 --> Router Class Initialized
INFO - 2018-03-10 10:12:38 --> Output Class Initialized
INFO - 2018-03-10 10:12:38 --> Security Class Initialized
DEBUG - 2018-03-10 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 10:12:38 --> Input Class Initialized
INFO - 2018-03-10 10:12:38 --> Language Class Initialized
INFO - 2018-03-10 10:12:38 --> Loader Class Initialized
INFO - 2018-03-10 10:12:38 --> Helper loaded: common_helper
INFO - 2018-03-10 10:12:38 --> Database Driver Class Initialized
INFO - 2018-03-10 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 10:12:38 --> Email Class Initialized
INFO - 2018-03-10 10:12:38 --> Controller Class Initialized
INFO - 2018-03-10 10:12:38 --> Helper loaded: form_helper
INFO - 2018-03-10 10:12:38 --> Form Validation Class Initialized
INFO - 2018-03-10 10:12:38 --> Helper loaded: email_helper
DEBUG - 2018-03-10 10:12:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 10:12:38 --> Helper loaded: url_helper
INFO - 2018-03-10 10:12:38 --> Model Class Initialized
INFO - 2018-03-10 10:12:38 --> Model Class Initialized
INFO - 2018-03-10 10:12:41 --> Config Class Initialized
INFO - 2018-03-10 10:12:41 --> Hooks Class Initialized
DEBUG - 2018-03-10 10:12:41 --> UTF-8 Support Enabled
INFO - 2018-03-10 10:12:41 --> Utf8 Class Initialized
INFO - 2018-03-10 10:12:41 --> URI Class Initialized
INFO - 2018-03-10 10:12:41 --> Router Class Initialized
INFO - 2018-03-10 10:12:41 --> Output Class Initialized
INFO - 2018-03-10 10:12:41 --> Security Class Initialized
DEBUG - 2018-03-10 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 10:12:41 --> Input Class Initialized
INFO - 2018-03-10 10:12:41 --> Language Class Initialized
INFO - 2018-03-10 10:12:41 --> Loader Class Initialized
INFO - 2018-03-10 10:12:41 --> Helper loaded: common_helper
INFO - 2018-03-10 10:12:41 --> Database Driver Class Initialized
INFO - 2018-03-10 10:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 10:12:41 --> Email Class Initialized
INFO - 2018-03-10 10:12:41 --> Controller Class Initialized
INFO - 2018-03-10 10:12:41 --> Helper loaded: form_helper
INFO - 2018-03-10 10:12:41 --> Form Validation Class Initialized
INFO - 2018-03-10 10:12:41 --> Helper loaded: email_helper
DEBUG - 2018-03-10 10:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 10:12:41 --> Helper loaded: url_helper
INFO - 2018-03-10 10:12:41 --> Model Class Initialized
INFO - 2018-03-10 10:12:41 --> Model Class Initialized
INFO - 2018-03-10 10:12:41 --> Config Class Initialized
INFO - 2018-03-10 10:12:41 --> Hooks Class Initialized
DEBUG - 2018-03-10 10:12:41 --> UTF-8 Support Enabled
INFO - 2018-03-10 10:12:41 --> Utf8 Class Initialized
INFO - 2018-03-10 10:12:41 --> URI Class Initialized
DEBUG - 2018-03-10 10:12:41 --> No URI present. Default controller set.
INFO - 2018-03-10 10:12:41 --> Router Class Initialized
INFO - 2018-03-10 10:12:41 --> Output Class Initialized
INFO - 2018-03-10 10:12:41 --> Security Class Initialized
DEBUG - 2018-03-10 10:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 10:12:41 --> Input Class Initialized
INFO - 2018-03-10 10:12:41 --> Language Class Initialized
INFO - 2018-03-10 10:12:41 --> Loader Class Initialized
INFO - 2018-03-10 10:12:41 --> Helper loaded: common_helper
INFO - 2018-03-10 10:12:41 --> Database Driver Class Initialized
INFO - 2018-03-10 10:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 10:12:41 --> Email Class Initialized
INFO - 2018-03-10 10:12:41 --> Controller Class Initialized
INFO - 2018-03-10 10:12:41 --> Helper loaded: form_helper
INFO - 2018-03-10 10:12:41 --> Form Validation Class Initialized
INFO - 2018-03-10 10:12:41 --> Helper loaded: email_helper
DEBUG - 2018-03-10 10:12:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 10:12:41 --> Helper loaded: url_helper
INFO - 2018-03-10 10:12:41 --> Model Class Initialized
INFO - 2018-03-10 10:12:41 --> Model Class Initialized
INFO - 2018-03-10 10:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-10 10:12:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 10:12:41 --> Final output sent to browser
DEBUG - 2018-03-10 10:12:41 --> Total execution time: 0.1490
INFO - 2018-03-10 10:12:49 --> Config Class Initialized
INFO - 2018-03-10 10:12:49 --> Hooks Class Initialized
DEBUG - 2018-03-10 10:12:49 --> UTF-8 Support Enabled
INFO - 2018-03-10 10:12:49 --> Utf8 Class Initialized
INFO - 2018-03-10 10:12:49 --> URI Class Initialized
DEBUG - 2018-03-10 10:12:49 --> No URI present. Default controller set.
INFO - 2018-03-10 10:12:49 --> Router Class Initialized
INFO - 2018-03-10 10:12:49 --> Output Class Initialized
INFO - 2018-03-10 10:12:49 --> Security Class Initialized
DEBUG - 2018-03-10 10:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 10:12:49 --> Input Class Initialized
INFO - 2018-03-10 10:12:49 --> Language Class Initialized
INFO - 2018-03-10 10:12:49 --> Loader Class Initialized
INFO - 2018-03-10 10:12:49 --> Helper loaded: common_helper
INFO - 2018-03-10 10:12:49 --> Database Driver Class Initialized
INFO - 2018-03-10 10:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 10:12:49 --> Email Class Initialized
INFO - 2018-03-10 10:12:49 --> Controller Class Initialized
INFO - 2018-03-10 10:12:49 --> Helper loaded: form_helper
INFO - 2018-03-10 10:12:49 --> Form Validation Class Initialized
INFO - 2018-03-10 10:12:49 --> Helper loaded: email_helper
DEBUG - 2018-03-10 10:12:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 10:12:49 --> Helper loaded: url_helper
INFO - 2018-03-10 10:12:49 --> Model Class Initialized
INFO - 2018-03-10 10:12:49 --> Model Class Initialized
DEBUG - 2018-03-10 10:12:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-10 10:12:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-10 10:12:53 --> Config Class Initialized
INFO - 2018-03-10 10:12:53 --> Hooks Class Initialized
DEBUG - 2018-03-10 10:12:53 --> UTF-8 Support Enabled
INFO - 2018-03-10 10:12:53 --> Utf8 Class Initialized
INFO - 2018-03-10 10:12:53 --> URI Class Initialized
INFO - 2018-03-10 10:12:53 --> Router Class Initialized
INFO - 2018-03-10 10:12:53 --> Output Class Initialized
INFO - 2018-03-10 10:12:53 --> Security Class Initialized
DEBUG - 2018-03-10 10:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-10 10:12:53 --> Input Class Initialized
INFO - 2018-03-10 10:12:53 --> Language Class Initialized
INFO - 2018-03-10 10:12:53 --> Loader Class Initialized
INFO - 2018-03-10 10:12:53 --> Helper loaded: common_helper
INFO - 2018-03-10 10:12:53 --> Database Driver Class Initialized
INFO - 2018-03-10 10:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-10 10:12:53 --> Email Class Initialized
INFO - 2018-03-10 10:12:53 --> Controller Class Initialized
INFO - 2018-03-10 10:12:53 --> Helper loaded: form_helper
INFO - 2018-03-10 10:12:53 --> Form Validation Class Initialized
INFO - 2018-03-10 10:12:53 --> Helper loaded: email_helper
DEBUG - 2018-03-10 10:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-10 10:12:53 --> Helper loaded: url_helper
INFO - 2018-03-10 10:12:53 --> Model Class Initialized
INFO - 2018-03-10 10:12:53 --> Model Class Initialized
INFO - 2018-03-10 10:12:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-10 10:12:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-10 10:12:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-10 10:12:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-10 10:12:53 --> Final output sent to browser
DEBUG - 2018-03-10 10:12:53 --> Total execution time: 0.1460
