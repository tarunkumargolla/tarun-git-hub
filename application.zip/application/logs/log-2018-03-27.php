<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-27 07:35:05 --> Config Class Initialized
INFO - 2018-03-27 07:35:05 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:35:05 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:35:05 --> Utf8 Class Initialized
INFO - 2018-03-27 07:35:05 --> URI Class Initialized
DEBUG - 2018-03-27 07:35:06 --> No URI present. Default controller set.
INFO - 2018-03-27 07:35:06 --> Router Class Initialized
INFO - 2018-03-27 07:35:06 --> Output Class Initialized
INFO - 2018-03-27 07:35:06 --> Security Class Initialized
DEBUG - 2018-03-27 07:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:35:06 --> Input Class Initialized
INFO - 2018-03-27 07:35:06 --> Language Class Initialized
INFO - 2018-03-27 07:35:06 --> Loader Class Initialized
INFO - 2018-03-27 07:35:06 --> Helper loaded: common_helper
INFO - 2018-03-27 07:35:06 --> Database Driver Class Initialized
INFO - 2018-03-27 07:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:35:06 --> Email Class Initialized
INFO - 2018-03-27 07:35:06 --> Controller Class Initialized
INFO - 2018-03-27 07:35:06 --> Helper loaded: form_helper
INFO - 2018-03-27 07:35:06 --> Form Validation Class Initialized
INFO - 2018-03-27 07:35:06 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:35:06 --> Helper loaded: url_helper
INFO - 2018-03-27 07:35:06 --> Model Class Initialized
INFO - 2018-03-27 07:35:06 --> Model Class Initialized
INFO - 2018-03-27 07:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-27 07:35:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:35:06 --> Final output sent to browser
DEBUG - 2018-03-27 07:35:06 --> Total execution time: 1.0451
INFO - 2018-03-27 07:35:20 --> Config Class Initialized
INFO - 2018-03-27 07:35:20 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:35:20 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:35:20 --> Utf8 Class Initialized
INFO - 2018-03-27 07:35:20 --> URI Class Initialized
DEBUG - 2018-03-27 07:35:20 --> No URI present. Default controller set.
INFO - 2018-03-27 07:35:20 --> Router Class Initialized
INFO - 2018-03-27 07:35:20 --> Output Class Initialized
INFO - 2018-03-27 07:35:20 --> Security Class Initialized
DEBUG - 2018-03-27 07:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:35:20 --> Input Class Initialized
INFO - 2018-03-27 07:35:20 --> Language Class Initialized
INFO - 2018-03-27 07:35:20 --> Loader Class Initialized
INFO - 2018-03-27 07:35:20 --> Helper loaded: common_helper
INFO - 2018-03-27 07:35:20 --> Database Driver Class Initialized
INFO - 2018-03-27 07:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:35:20 --> Email Class Initialized
INFO - 2018-03-27 07:35:20 --> Controller Class Initialized
INFO - 2018-03-27 07:35:20 --> Helper loaded: form_helper
INFO - 2018-03-27 07:35:20 --> Form Validation Class Initialized
INFO - 2018-03-27 07:35:20 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:35:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:35:20 --> Helper loaded: url_helper
INFO - 2018-03-27 07:35:20 --> Model Class Initialized
INFO - 2018-03-27 07:35:20 --> Model Class Initialized
DEBUG - 2018-03-27 07:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:35:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-27 07:35:20 --> Config Class Initialized
INFO - 2018-03-27 07:35:20 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:35:20 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:35:20 --> Utf8 Class Initialized
INFO - 2018-03-27 07:35:20 --> URI Class Initialized
DEBUG - 2018-03-27 07:35:21 --> No URI present. Default controller set.
INFO - 2018-03-27 07:35:21 --> Router Class Initialized
INFO - 2018-03-27 07:35:21 --> Output Class Initialized
INFO - 2018-03-27 07:35:21 --> Security Class Initialized
DEBUG - 2018-03-27 07:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:35:21 --> Input Class Initialized
INFO - 2018-03-27 07:35:21 --> Language Class Initialized
INFO - 2018-03-27 07:35:21 --> Loader Class Initialized
INFO - 2018-03-27 07:35:21 --> Helper loaded: common_helper
INFO - 2018-03-27 07:35:21 --> Database Driver Class Initialized
INFO - 2018-03-27 07:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:35:21 --> Email Class Initialized
INFO - 2018-03-27 07:35:21 --> Controller Class Initialized
INFO - 2018-03-27 07:35:21 --> Helper loaded: form_helper
INFO - 2018-03-27 07:35:21 --> Form Validation Class Initialized
INFO - 2018-03-27 07:35:21 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:35:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:35:21 --> Helper loaded: url_helper
INFO - 2018-03-27 07:35:21 --> Model Class Initialized
INFO - 2018-03-27 07:35:21 --> Model Class Initialized
INFO - 2018-03-27 07:35:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-27 07:35:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:35:21 --> Final output sent to browser
DEBUG - 2018-03-27 07:35:21 --> Total execution time: 0.1350
INFO - 2018-03-27 07:37:14 --> Config Class Initialized
INFO - 2018-03-27 07:37:14 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:37:14 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:37:14 --> Utf8 Class Initialized
INFO - 2018-03-27 07:37:14 --> URI Class Initialized
INFO - 2018-03-27 07:37:14 --> Router Class Initialized
INFO - 2018-03-27 07:37:14 --> Output Class Initialized
INFO - 2018-03-27 07:37:14 --> Security Class Initialized
DEBUG - 2018-03-27 07:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:37:14 --> Input Class Initialized
INFO - 2018-03-27 07:37:14 --> Language Class Initialized
ERROR - 2018-03-27 07:37:14 --> 404 Page Not Found: Resgister/index
INFO - 2018-03-27 07:37:18 --> Config Class Initialized
INFO - 2018-03-27 07:37:18 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:37:18 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:37:18 --> Utf8 Class Initialized
INFO - 2018-03-27 07:37:18 --> URI Class Initialized
DEBUG - 2018-03-27 07:37:18 --> No URI present. Default controller set.
INFO - 2018-03-27 07:37:18 --> Router Class Initialized
INFO - 2018-03-27 07:37:18 --> Output Class Initialized
INFO - 2018-03-27 07:37:18 --> Security Class Initialized
DEBUG - 2018-03-27 07:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:37:18 --> Input Class Initialized
INFO - 2018-03-27 07:37:18 --> Language Class Initialized
INFO - 2018-03-27 07:37:18 --> Loader Class Initialized
INFO - 2018-03-27 07:37:18 --> Helper loaded: common_helper
INFO - 2018-03-27 07:37:18 --> Database Driver Class Initialized
INFO - 2018-03-27 07:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:37:18 --> Email Class Initialized
INFO - 2018-03-27 07:37:18 --> Controller Class Initialized
INFO - 2018-03-27 07:37:18 --> Helper loaded: form_helper
INFO - 2018-03-27 07:37:18 --> Form Validation Class Initialized
INFO - 2018-03-27 07:37:18 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:37:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:37:18 --> Helper loaded: url_helper
INFO - 2018-03-27 07:37:18 --> Model Class Initialized
INFO - 2018-03-27 07:37:18 --> Model Class Initialized
INFO - 2018-03-27 07:37:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-27 07:37:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:37:18 --> Final output sent to browser
DEBUG - 2018-03-27 07:37:18 --> Total execution time: 0.1620
INFO - 2018-03-27 07:37:33 --> Config Class Initialized
INFO - 2018-03-27 07:37:33 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:37:33 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:37:33 --> Utf8 Class Initialized
INFO - 2018-03-27 07:37:33 --> URI Class Initialized
DEBUG - 2018-03-27 07:37:33 --> No URI present. Default controller set.
INFO - 2018-03-27 07:37:33 --> Router Class Initialized
INFO - 2018-03-27 07:37:33 --> Output Class Initialized
INFO - 2018-03-27 07:37:33 --> Security Class Initialized
DEBUG - 2018-03-27 07:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:37:33 --> Input Class Initialized
INFO - 2018-03-27 07:37:33 --> Language Class Initialized
INFO - 2018-03-27 07:37:33 --> Loader Class Initialized
INFO - 2018-03-27 07:37:33 --> Helper loaded: common_helper
INFO - 2018-03-27 07:37:33 --> Database Driver Class Initialized
INFO - 2018-03-27 07:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:37:33 --> Email Class Initialized
INFO - 2018-03-27 07:37:33 --> Controller Class Initialized
INFO - 2018-03-27 07:37:33 --> Helper loaded: form_helper
INFO - 2018-03-27 07:37:33 --> Form Validation Class Initialized
INFO - 2018-03-27 07:37:33 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:37:33 --> Helper loaded: url_helper
INFO - 2018-03-27 07:37:33 --> Model Class Initialized
INFO - 2018-03-27 07:37:33 --> Model Class Initialized
INFO - 2018-03-27 07:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-27 07:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:37:33 --> Final output sent to browser
DEBUG - 2018-03-27 07:37:33 --> Total execution time: 0.1560
INFO - 2018-03-27 07:38:47 --> Config Class Initialized
INFO - 2018-03-27 07:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:38:47 --> Utf8 Class Initialized
INFO - 2018-03-27 07:38:47 --> URI Class Initialized
DEBUG - 2018-03-27 07:38:47 --> No URI present. Default controller set.
INFO - 2018-03-27 07:38:47 --> Router Class Initialized
INFO - 2018-03-27 07:38:47 --> Output Class Initialized
INFO - 2018-03-27 07:38:47 --> Security Class Initialized
DEBUG - 2018-03-27 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:38:47 --> Input Class Initialized
INFO - 2018-03-27 07:38:47 --> Language Class Initialized
INFO - 2018-03-27 07:38:47 --> Loader Class Initialized
INFO - 2018-03-27 07:38:47 --> Helper loaded: common_helper
INFO - 2018-03-27 07:38:47 --> Database Driver Class Initialized
INFO - 2018-03-27 07:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:38:47 --> Email Class Initialized
INFO - 2018-03-27 07:38:47 --> Controller Class Initialized
INFO - 2018-03-27 07:38:47 --> Helper loaded: form_helper
INFO - 2018-03-27 07:38:47 --> Form Validation Class Initialized
INFO - 2018-03-27 07:38:47 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:38:47 --> Helper loaded: url_helper
INFO - 2018-03-27 07:38:47 --> Model Class Initialized
INFO - 2018-03-27 07:38:47 --> Model Class Initialized
DEBUG - 2018-03-27 07:38:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:38:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-27 07:38:47 --> Config Class Initialized
INFO - 2018-03-27 07:38:47 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:38:47 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:38:47 --> Utf8 Class Initialized
INFO - 2018-03-27 07:38:47 --> URI Class Initialized
INFO - 2018-03-27 07:38:47 --> Router Class Initialized
INFO - 2018-03-27 07:38:47 --> Output Class Initialized
INFO - 2018-03-27 07:38:47 --> Security Class Initialized
DEBUG - 2018-03-27 07:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:38:47 --> Input Class Initialized
INFO - 2018-03-27 07:38:47 --> Language Class Initialized
INFO - 2018-03-27 07:38:47 --> Loader Class Initialized
INFO - 2018-03-27 07:38:47 --> Helper loaded: common_helper
INFO - 2018-03-27 07:38:47 --> Database Driver Class Initialized
INFO - 2018-03-27 07:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:38:47 --> Email Class Initialized
INFO - 2018-03-27 07:38:47 --> Controller Class Initialized
INFO - 2018-03-27 07:38:47 --> Helper loaded: form_helper
INFO - 2018-03-27 07:38:47 --> Form Validation Class Initialized
INFO - 2018-03-27 07:38:47 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:38:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:38:47 --> Helper loaded: url_helper
INFO - 2018-03-27 07:38:47 --> Model Class Initialized
INFO - 2018-03-27 07:38:47 --> Model Class Initialized
INFO - 2018-03-27 07:38:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 07:38:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 07:38:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-27 07:38:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:38:47 --> Final output sent to browser
DEBUG - 2018-03-27 07:38:47 --> Total execution time: 0.2420
INFO - 2018-03-27 07:39:02 --> Config Class Initialized
INFO - 2018-03-27 07:39:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:39:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:39:02 --> Utf8 Class Initialized
INFO - 2018-03-27 07:39:02 --> URI Class Initialized
INFO - 2018-03-27 07:39:02 --> Router Class Initialized
INFO - 2018-03-27 07:39:02 --> Output Class Initialized
INFO - 2018-03-27 07:39:02 --> Security Class Initialized
DEBUG - 2018-03-27 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:39:02 --> Input Class Initialized
INFO - 2018-03-27 07:39:02 --> Language Class Initialized
INFO - 2018-03-27 07:39:02 --> Loader Class Initialized
INFO - 2018-03-27 07:39:02 --> Helper loaded: common_helper
INFO - 2018-03-27 07:39:02 --> Database Driver Class Initialized
INFO - 2018-03-27 07:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:39:02 --> Email Class Initialized
INFO - 2018-03-27 07:39:02 --> Controller Class Initialized
INFO - 2018-03-27 07:39:02 --> Helper loaded: form_helper
INFO - 2018-03-27 07:39:02 --> Form Validation Class Initialized
INFO - 2018-03-27 07:39:02 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:39:02 --> Helper loaded: url_helper
INFO - 2018-03-27 07:39:02 --> Model Class Initialized
INFO - 2018-03-27 07:39:02 --> Model Class Initialized
INFO - 2018-03-27 11:09:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:09:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:09:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:09:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:09:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:09:02 --> Final output sent to browser
DEBUG - 2018-03-27 11:09:02 --> Total execution time: 0.2700
INFO - 2018-03-27 07:41:25 --> Config Class Initialized
INFO - 2018-03-27 07:41:25 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:41:25 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:41:25 --> Utf8 Class Initialized
INFO - 2018-03-27 07:41:25 --> URI Class Initialized
INFO - 2018-03-27 07:41:25 --> Router Class Initialized
INFO - 2018-03-27 07:41:25 --> Output Class Initialized
INFO - 2018-03-27 07:41:25 --> Security Class Initialized
DEBUG - 2018-03-27 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:41:25 --> Input Class Initialized
INFO - 2018-03-27 07:41:25 --> Language Class Initialized
INFO - 2018-03-27 07:41:25 --> Loader Class Initialized
INFO - 2018-03-27 07:41:25 --> Helper loaded: common_helper
INFO - 2018-03-27 07:41:25 --> Database Driver Class Initialized
INFO - 2018-03-27 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:41:25 --> Email Class Initialized
INFO - 2018-03-27 07:41:25 --> Controller Class Initialized
INFO - 2018-03-27 07:41:25 --> Helper loaded: form_helper
INFO - 2018-03-27 07:41:25 --> Form Validation Class Initialized
INFO - 2018-03-27 07:41:25 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:41:25 --> Helper loaded: url_helper
INFO - 2018-03-27 07:41:25 --> Model Class Initialized
INFO - 2018-03-27 07:41:25 --> Model Class Initialized
INFO - 2018-03-27 11:11:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:11:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:11:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2018-03-27 11:11:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:11:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:11:25 --> Final output sent to browser
DEBUG - 2018-03-27 11:11:25 --> Total execution time: 0.1800
INFO - 2018-03-27 07:43:43 --> Config Class Initialized
INFO - 2018-03-27 07:43:43 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:43:43 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:43:43 --> Utf8 Class Initialized
INFO - 2018-03-27 07:43:43 --> URI Class Initialized
INFO - 2018-03-27 07:43:43 --> Router Class Initialized
INFO - 2018-03-27 07:43:43 --> Output Class Initialized
INFO - 2018-03-27 07:43:43 --> Security Class Initialized
DEBUG - 2018-03-27 07:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:43:43 --> Input Class Initialized
INFO - 2018-03-27 07:43:43 --> Language Class Initialized
INFO - 2018-03-27 07:43:43 --> Loader Class Initialized
INFO - 2018-03-27 07:43:43 --> Helper loaded: common_helper
INFO - 2018-03-27 07:43:43 --> Database Driver Class Initialized
INFO - 2018-03-27 07:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:43:43 --> Email Class Initialized
INFO - 2018-03-27 07:43:43 --> Controller Class Initialized
INFO - 2018-03-27 07:43:43 --> Helper loaded: form_helper
INFO - 2018-03-27 07:43:43 --> Form Validation Class Initialized
INFO - 2018-03-27 07:43:43 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:43:43 --> Helper loaded: url_helper
INFO - 2018-03-27 07:43:43 --> Model Class Initialized
INFO - 2018-03-27 07:43:43 --> Model Class Initialized
INFO - 2018-03-27 11:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:13:43 --> Final output sent to browser
DEBUG - 2018-03-27 11:13:43 --> Total execution time: 0.1850
INFO - 2018-03-27 07:43:46 --> Config Class Initialized
INFO - 2018-03-27 07:43:46 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:43:46 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:43:46 --> Utf8 Class Initialized
INFO - 2018-03-27 07:43:46 --> URI Class Initialized
INFO - 2018-03-27 07:43:46 --> Router Class Initialized
INFO - 2018-03-27 07:43:46 --> Output Class Initialized
INFO - 2018-03-27 07:43:46 --> Security Class Initialized
DEBUG - 2018-03-27 07:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:43:46 --> Input Class Initialized
INFO - 2018-03-27 07:43:46 --> Language Class Initialized
INFO - 2018-03-27 07:43:46 --> Loader Class Initialized
INFO - 2018-03-27 07:43:46 --> Helper loaded: common_helper
INFO - 2018-03-27 07:43:46 --> Database Driver Class Initialized
INFO - 2018-03-27 07:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:43:46 --> Email Class Initialized
INFO - 2018-03-27 07:43:46 --> Controller Class Initialized
INFO - 2018-03-27 07:43:46 --> Helper loaded: form_helper
INFO - 2018-03-27 07:43:46 --> Form Validation Class Initialized
INFO - 2018-03-27 07:43:46 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:43:46 --> Helper loaded: url_helper
INFO - 2018-03-27 07:43:46 --> Model Class Initialized
INFO - 2018-03-27 07:43:46 --> Model Class Initialized
INFO - 2018-03-27 11:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2018-03-27 11:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:13:46 --> Final output sent to browser
DEBUG - 2018-03-27 11:13:46 --> Total execution time: 0.1230
INFO - 2018-03-27 07:44:04 --> Config Class Initialized
INFO - 2018-03-27 07:44:04 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:44:04 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:44:04 --> Utf8 Class Initialized
INFO - 2018-03-27 07:44:04 --> URI Class Initialized
INFO - 2018-03-27 07:44:04 --> Router Class Initialized
INFO - 2018-03-27 07:44:04 --> Output Class Initialized
INFO - 2018-03-27 07:44:04 --> Security Class Initialized
DEBUG - 2018-03-27 07:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:44:04 --> Input Class Initialized
INFO - 2018-03-27 07:44:04 --> Language Class Initialized
INFO - 2018-03-27 07:44:04 --> Loader Class Initialized
INFO - 2018-03-27 07:44:04 --> Helper loaded: common_helper
INFO - 2018-03-27 07:44:04 --> Database Driver Class Initialized
INFO - 2018-03-27 07:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:44:04 --> Email Class Initialized
INFO - 2018-03-27 07:44:04 --> Controller Class Initialized
INFO - 2018-03-27 07:44:04 --> Helper loaded: form_helper
INFO - 2018-03-27 07:44:04 --> Form Validation Class Initialized
INFO - 2018-03-27 07:44:04 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:44:04 --> Helper loaded: url_helper
INFO - 2018-03-27 07:44:04 --> Model Class Initialized
INFO - 2018-03-27 07:44:04 --> Model Class Initialized
INFO - 2018-03-27 11:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:14:04 --> Final output sent to browser
DEBUG - 2018-03-27 11:14:04 --> Total execution time: 0.1370
INFO - 2018-03-27 07:44:18 --> Config Class Initialized
INFO - 2018-03-27 07:44:18 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:44:18 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:44:18 --> Utf8 Class Initialized
INFO - 2018-03-27 07:44:18 --> URI Class Initialized
INFO - 2018-03-27 07:44:18 --> Router Class Initialized
INFO - 2018-03-27 07:44:18 --> Output Class Initialized
INFO - 2018-03-27 07:44:18 --> Security Class Initialized
DEBUG - 2018-03-27 07:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:44:18 --> Input Class Initialized
INFO - 2018-03-27 07:44:18 --> Language Class Initialized
INFO - 2018-03-27 07:44:18 --> Loader Class Initialized
INFO - 2018-03-27 07:44:18 --> Helper loaded: common_helper
INFO - 2018-03-27 07:44:18 --> Database Driver Class Initialized
INFO - 2018-03-27 07:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:44:19 --> Email Class Initialized
INFO - 2018-03-27 07:44:19 --> Controller Class Initialized
INFO - 2018-03-27 07:44:19 --> Helper loaded: form_helper
INFO - 2018-03-27 07:44:19 --> Form Validation Class Initialized
INFO - 2018-03-27 07:44:19 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:44:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:44:19 --> Helper loaded: url_helper
INFO - 2018-03-27 07:44:19 --> Model Class Initialized
INFO - 2018-03-27 07:44:19 --> Model Class Initialized
INFO - 2018-03-27 11:14:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:14:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:14:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2018-03-27 11:14:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:14:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:14:19 --> Final output sent to browser
DEBUG - 2018-03-27 11:14:19 --> Total execution time: 0.1230
INFO - 2018-03-27 07:44:33 --> Config Class Initialized
INFO - 2018-03-27 07:44:33 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:44:33 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:44:33 --> Utf8 Class Initialized
INFO - 2018-03-27 07:44:33 --> URI Class Initialized
INFO - 2018-03-27 07:44:33 --> Router Class Initialized
INFO - 2018-03-27 07:44:33 --> Output Class Initialized
INFO - 2018-03-27 07:44:33 --> Security Class Initialized
DEBUG - 2018-03-27 07:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:44:33 --> Input Class Initialized
INFO - 2018-03-27 07:44:33 --> Language Class Initialized
INFO - 2018-03-27 07:44:33 --> Loader Class Initialized
INFO - 2018-03-27 07:44:33 --> Helper loaded: common_helper
INFO - 2018-03-27 07:44:33 --> Database Driver Class Initialized
INFO - 2018-03-27 07:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:44:33 --> Email Class Initialized
INFO - 2018-03-27 07:44:33 --> Controller Class Initialized
INFO - 2018-03-27 07:44:33 --> Helper loaded: form_helper
INFO - 2018-03-27 07:44:33 --> Form Validation Class Initialized
INFO - 2018-03-27 07:44:33 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:44:33 --> Helper loaded: url_helper
INFO - 2018-03-27 07:44:33 --> Model Class Initialized
INFO - 2018-03-27 07:44:33 --> Model Class Initialized
INFO - 2018-03-27 11:14:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:14:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:14:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:14:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:14:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:14:33 --> Final output sent to browser
DEBUG - 2018-03-27 11:14:33 --> Total execution time: 0.2130
INFO - 2018-03-27 07:51:21 --> Config Class Initialized
INFO - 2018-03-27 07:51:21 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:51:21 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:51:21 --> Utf8 Class Initialized
INFO - 2018-03-27 07:51:21 --> URI Class Initialized
INFO - 2018-03-27 07:51:21 --> Router Class Initialized
INFO - 2018-03-27 07:51:21 --> Output Class Initialized
INFO - 2018-03-27 07:51:21 --> Security Class Initialized
DEBUG - 2018-03-27 07:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:51:21 --> Input Class Initialized
INFO - 2018-03-27 07:51:21 --> Language Class Initialized
INFO - 2018-03-27 07:51:21 --> Loader Class Initialized
INFO - 2018-03-27 07:51:21 --> Helper loaded: common_helper
INFO - 2018-03-27 07:51:21 --> Database Driver Class Initialized
INFO - 2018-03-27 07:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:51:21 --> Email Class Initialized
INFO - 2018-03-27 07:51:21 --> Controller Class Initialized
INFO - 2018-03-27 07:51:21 --> Helper loaded: form_helper
INFO - 2018-03-27 07:51:21 --> Form Validation Class Initialized
INFO - 2018-03-27 07:51:21 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:51:21 --> Helper loaded: url_helper
INFO - 2018-03-27 07:51:21 --> Model Class Initialized
INFO - 2018-03-27 07:51:21 --> Model Class Initialized
INFO - 2018-03-27 07:51:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 07:51:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 07:51:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-27 07:51:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:51:21 --> Final output sent to browser
DEBUG - 2018-03-27 07:51:21 --> Total execution time: 0.1300
INFO - 2018-03-27 07:51:25 --> Config Class Initialized
INFO - 2018-03-27 07:51:25 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:51:25 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:51:25 --> Utf8 Class Initialized
INFO - 2018-03-27 07:51:25 --> URI Class Initialized
INFO - 2018-03-27 07:51:25 --> Router Class Initialized
INFO - 2018-03-27 07:51:25 --> Output Class Initialized
INFO - 2018-03-27 07:51:25 --> Security Class Initialized
DEBUG - 2018-03-27 07:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:51:25 --> Input Class Initialized
INFO - 2018-03-27 07:51:25 --> Language Class Initialized
INFO - 2018-03-27 07:51:25 --> Loader Class Initialized
INFO - 2018-03-27 07:51:25 --> Helper loaded: common_helper
INFO - 2018-03-27 07:51:25 --> Database Driver Class Initialized
INFO - 2018-03-27 07:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:51:25 --> Email Class Initialized
INFO - 2018-03-27 07:51:25 --> Controller Class Initialized
INFO - 2018-03-27 07:51:25 --> Helper loaded: form_helper
INFO - 2018-03-27 07:51:25 --> Form Validation Class Initialized
INFO - 2018-03-27 07:51:25 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:51:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:51:25 --> Helper loaded: url_helper
INFO - 2018-03-27 07:51:25 --> Model Class Initialized
INFO - 2018-03-27 07:51:25 --> Model Class Initialized
INFO - 2018-03-27 07:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 07:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 07:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-27 07:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:51:25 --> Final output sent to browser
DEBUG - 2018-03-27 07:51:25 --> Total execution time: 0.2010
INFO - 2018-03-27 07:52:16 --> Config Class Initialized
INFO - 2018-03-27 07:52:16 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:52:16 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:52:16 --> Utf8 Class Initialized
INFO - 2018-03-27 07:52:16 --> URI Class Initialized
INFO - 2018-03-27 07:52:16 --> Router Class Initialized
INFO - 2018-03-27 07:52:16 --> Output Class Initialized
INFO - 2018-03-27 07:52:16 --> Security Class Initialized
DEBUG - 2018-03-27 07:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:52:16 --> Input Class Initialized
INFO - 2018-03-27 07:52:16 --> Language Class Initialized
INFO - 2018-03-27 07:52:16 --> Loader Class Initialized
INFO - 2018-03-27 07:52:16 --> Helper loaded: common_helper
INFO - 2018-03-27 07:52:16 --> Database Driver Class Initialized
INFO - 2018-03-27 07:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:52:16 --> Email Class Initialized
INFO - 2018-03-27 07:52:16 --> Controller Class Initialized
INFO - 2018-03-27 07:52:16 --> Helper loaded: form_helper
INFO - 2018-03-27 07:52:16 --> Form Validation Class Initialized
INFO - 2018-03-27 07:52:16 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:52:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:52:16 --> Helper loaded: url_helper
INFO - 2018-03-27 07:52:16 --> Model Class Initialized
INFO - 2018-03-27 07:52:16 --> Model Class Initialized
INFO - 2018-03-27 07:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 07:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 07:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-27 07:52:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:52:16 --> Final output sent to browser
DEBUG - 2018-03-27 07:52:16 --> Total execution time: 0.1260
INFO - 2018-03-27 07:53:59 --> Config Class Initialized
INFO - 2018-03-27 07:53:59 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:53:59 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:53:59 --> Utf8 Class Initialized
INFO - 2018-03-27 07:53:59 --> URI Class Initialized
INFO - 2018-03-27 07:53:59 --> Router Class Initialized
INFO - 2018-03-27 07:53:59 --> Output Class Initialized
INFO - 2018-03-27 07:53:59 --> Security Class Initialized
DEBUG - 2018-03-27 07:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:53:59 --> Input Class Initialized
INFO - 2018-03-27 07:53:59 --> Language Class Initialized
INFO - 2018-03-27 07:53:59 --> Loader Class Initialized
INFO - 2018-03-27 07:53:59 --> Helper loaded: common_helper
INFO - 2018-03-27 07:53:59 --> Database Driver Class Initialized
INFO - 2018-03-27 07:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:53:59 --> Email Class Initialized
INFO - 2018-03-27 07:53:59 --> Controller Class Initialized
INFO - 2018-03-27 07:53:59 --> Helper loaded: form_helper
INFO - 2018-03-27 07:53:59 --> Form Validation Class Initialized
INFO - 2018-03-27 07:53:59 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:53:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:53:59 --> Helper loaded: url_helper
INFO - 2018-03-27 07:53:59 --> Model Class Initialized
INFO - 2018-03-27 07:53:59 --> Model Class Initialized
INFO - 2018-03-27 07:53:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 07:53:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 07:53:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-27 07:53:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 07:53:59 --> Final output sent to browser
DEBUG - 2018-03-27 07:53:59 --> Total execution time: 0.1730
INFO - 2018-03-27 07:54:02 --> Config Class Initialized
INFO - 2018-03-27 07:54:02 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:54:02 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:54:02 --> Utf8 Class Initialized
INFO - 2018-03-27 07:54:02 --> URI Class Initialized
INFO - 2018-03-27 07:54:02 --> Router Class Initialized
INFO - 2018-03-27 07:54:02 --> Output Class Initialized
INFO - 2018-03-27 07:54:02 --> Security Class Initialized
DEBUG - 2018-03-27 07:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:54:02 --> Input Class Initialized
INFO - 2018-03-27 07:54:02 --> Language Class Initialized
INFO - 2018-03-27 07:54:02 --> Loader Class Initialized
INFO - 2018-03-27 07:54:02 --> Helper loaded: common_helper
INFO - 2018-03-27 07:54:02 --> Database Driver Class Initialized
INFO - 2018-03-27 07:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:54:02 --> Email Class Initialized
INFO - 2018-03-27 07:54:02 --> Controller Class Initialized
INFO - 2018-03-27 07:54:02 --> Helper loaded: form_helper
INFO - 2018-03-27 07:54:02 --> Form Validation Class Initialized
INFO - 2018-03-27 07:54:02 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:54:02 --> Helper loaded: url_helper
INFO - 2018-03-27 07:54:02 --> Model Class Initialized
INFO - 2018-03-27 07:54:02 --> Model Class Initialized
INFO - 2018-03-27 11:24:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:24:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:24:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:24:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:24:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:24:02 --> Final output sent to browser
DEBUG - 2018-03-27 11:24:02 --> Total execution time: 0.1210
INFO - 2018-03-27 07:57:11 --> Config Class Initialized
INFO - 2018-03-27 07:57:11 --> Hooks Class Initialized
DEBUG - 2018-03-27 07:57:11 --> UTF-8 Support Enabled
INFO - 2018-03-27 07:57:11 --> Utf8 Class Initialized
INFO - 2018-03-27 07:57:11 --> URI Class Initialized
INFO - 2018-03-27 07:57:11 --> Router Class Initialized
INFO - 2018-03-27 07:57:11 --> Output Class Initialized
INFO - 2018-03-27 07:57:11 --> Security Class Initialized
DEBUG - 2018-03-27 07:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 07:57:11 --> Input Class Initialized
INFO - 2018-03-27 07:57:11 --> Language Class Initialized
INFO - 2018-03-27 07:57:11 --> Loader Class Initialized
INFO - 2018-03-27 07:57:11 --> Helper loaded: common_helper
INFO - 2018-03-27 07:57:11 --> Database Driver Class Initialized
INFO - 2018-03-27 07:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 07:57:11 --> Email Class Initialized
INFO - 2018-03-27 07:57:11 --> Controller Class Initialized
INFO - 2018-03-27 07:57:11 --> Helper loaded: form_helper
INFO - 2018-03-27 07:57:11 --> Form Validation Class Initialized
INFO - 2018-03-27 07:57:11 --> Helper loaded: email_helper
DEBUG - 2018-03-27 07:57:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 07:57:11 --> Helper loaded: url_helper
INFO - 2018-03-27 07:57:11 --> Model Class Initialized
INFO - 2018-03-27 07:57:11 --> Model Class Initialized
INFO - 2018-03-27 11:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:27:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:27:11 --> Final output sent to browser
DEBUG - 2018-03-27 11:27:11 --> Total execution time: 0.1890
INFO - 2018-03-27 08:01:31 --> Config Class Initialized
INFO - 2018-03-27 08:01:31 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:01:31 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:01:31 --> Utf8 Class Initialized
INFO - 2018-03-27 08:01:31 --> URI Class Initialized
INFO - 2018-03-27 08:01:31 --> Router Class Initialized
INFO - 2018-03-27 08:01:31 --> Output Class Initialized
INFO - 2018-03-27 08:01:31 --> Security Class Initialized
DEBUG - 2018-03-27 08:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:01:31 --> Input Class Initialized
INFO - 2018-03-27 08:01:31 --> Language Class Initialized
INFO - 2018-03-27 08:01:31 --> Loader Class Initialized
INFO - 2018-03-27 08:01:31 --> Helper loaded: common_helper
INFO - 2018-03-27 08:01:31 --> Database Driver Class Initialized
INFO - 2018-03-27 08:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:01:31 --> Email Class Initialized
INFO - 2018-03-27 08:01:31 --> Controller Class Initialized
INFO - 2018-03-27 08:01:31 --> Helper loaded: form_helper
INFO - 2018-03-27 08:01:31 --> Form Validation Class Initialized
INFO - 2018-03-27 08:01:31 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:01:31 --> Helper loaded: url_helper
INFO - 2018-03-27 08:01:31 --> Model Class Initialized
INFO - 2018-03-27 08:01:31 --> Model Class Initialized
INFO - 2018-03-27 11:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/addSubscription.php
INFO - 2018-03-27 11:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:31:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:31:31 --> Final output sent to browser
DEBUG - 2018-03-27 11:31:31 --> Total execution time: 0.3075
INFO - 2018-03-27 08:03:41 --> Config Class Initialized
INFO - 2018-03-27 08:03:41 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:03:41 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:03:41 --> Utf8 Class Initialized
INFO - 2018-03-27 08:03:41 --> URI Class Initialized
INFO - 2018-03-27 08:03:41 --> Router Class Initialized
INFO - 2018-03-27 08:03:41 --> Output Class Initialized
INFO - 2018-03-27 08:03:41 --> Security Class Initialized
DEBUG - 2018-03-27 08:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:03:41 --> Input Class Initialized
INFO - 2018-03-27 08:03:41 --> Language Class Initialized
INFO - 2018-03-27 08:03:41 --> Loader Class Initialized
INFO - 2018-03-27 08:03:41 --> Helper loaded: common_helper
INFO - 2018-03-27 08:03:41 --> Database Driver Class Initialized
INFO - 2018-03-27 08:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:03:41 --> Email Class Initialized
INFO - 2018-03-27 08:03:41 --> Controller Class Initialized
INFO - 2018-03-27 08:03:41 --> Helper loaded: form_helper
INFO - 2018-03-27 08:03:41 --> Form Validation Class Initialized
INFO - 2018-03-27 08:03:41 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:03:41 --> Helper loaded: url_helper
INFO - 2018-03-27 08:03:41 --> Model Class Initialized
INFO - 2018-03-27 08:03:41 --> Model Class Initialized
INFO - 2018-03-27 11:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-03-27 11:33:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:33:41 --> Final output sent to browser
DEBUG - 2018-03-27 11:33:41 --> Total execution time: 0.2300
INFO - 2018-03-27 08:21:39 --> Config Class Initialized
INFO - 2018-03-27 08:21:39 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:21:39 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:21:39 --> Utf8 Class Initialized
INFO - 2018-03-27 08:21:39 --> URI Class Initialized
INFO - 2018-03-27 08:21:39 --> Router Class Initialized
INFO - 2018-03-27 08:21:39 --> Output Class Initialized
INFO - 2018-03-27 08:21:39 --> Security Class Initialized
DEBUG - 2018-03-27 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:21:39 --> Input Class Initialized
INFO - 2018-03-27 08:21:39 --> Language Class Initialized
INFO - 2018-03-27 08:21:39 --> Loader Class Initialized
INFO - 2018-03-27 08:21:39 --> Helper loaded: common_helper
INFO - 2018-03-27 08:21:39 --> Database Driver Class Initialized
INFO - 2018-03-27 08:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:21:39 --> Email Class Initialized
INFO - 2018-03-27 08:21:39 --> Controller Class Initialized
INFO - 2018-03-27 08:21:39 --> Helper loaded: form_helper
INFO - 2018-03-27 08:21:39 --> Form Validation Class Initialized
INFO - 2018-03-27 08:21:39 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:21:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:21:39 --> Helper loaded: url_helper
INFO - 2018-03-27 08:21:39 --> Model Class Initialized
INFO - 2018-03-27 08:21:39 --> Model Class Initialized
INFO - 2018-03-27 08:21:39 --> Model Class Initialized
INFO - 2018-03-27 11:51:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:51:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:51:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:51:39 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:51:39 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-27 11:51:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-27 11:51:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:51:39 --> Final output sent to browser
DEBUG - 2018-03-27 11:51:39 --> Total execution time: 0.3690
INFO - 2018-03-27 08:21:45 --> Config Class Initialized
INFO - 2018-03-27 08:21:45 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:21:45 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:21:45 --> Utf8 Class Initialized
INFO - 2018-03-27 08:21:45 --> URI Class Initialized
INFO - 2018-03-27 08:21:45 --> Router Class Initialized
INFO - 2018-03-27 08:21:45 --> Output Class Initialized
INFO - 2018-03-27 08:21:45 --> Security Class Initialized
DEBUG - 2018-03-27 08:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:21:45 --> Input Class Initialized
INFO - 2018-03-27 08:21:45 --> Language Class Initialized
INFO - 2018-03-27 08:21:45 --> Loader Class Initialized
INFO - 2018-03-27 08:21:45 --> Helper loaded: common_helper
INFO - 2018-03-27 08:21:45 --> Database Driver Class Initialized
INFO - 2018-03-27 08:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:21:45 --> Email Class Initialized
INFO - 2018-03-27 08:21:45 --> Controller Class Initialized
INFO - 2018-03-27 08:21:45 --> Helper loaded: form_helper
INFO - 2018-03-27 08:21:45 --> Form Validation Class Initialized
INFO - 2018-03-27 08:21:45 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:21:45 --> Helper loaded: url_helper
INFO - 2018-03-27 08:21:45 --> Model Class Initialized
INFO - 2018-03-27 08:21:45 --> Model Class Initialized
INFO - 2018-03-27 08:21:45 --> Model Class Initialized
INFO - 2018-03-27 11:51:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:51:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:51:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:51:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-27 11:51:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:51:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:51:45 --> Final output sent to browser
DEBUG - 2018-03-27 11:51:45 --> Total execution time: 0.1640
INFO - 2018-03-27 08:22:12 --> Config Class Initialized
INFO - 2018-03-27 08:22:12 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:22:12 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:22:12 --> Utf8 Class Initialized
INFO - 2018-03-27 08:22:12 --> URI Class Initialized
INFO - 2018-03-27 08:22:12 --> Router Class Initialized
INFO - 2018-03-27 08:22:12 --> Output Class Initialized
INFO - 2018-03-27 08:22:12 --> Security Class Initialized
DEBUG - 2018-03-27 08:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:22:12 --> Input Class Initialized
INFO - 2018-03-27 08:22:12 --> Language Class Initialized
INFO - 2018-03-27 08:22:12 --> Loader Class Initialized
INFO - 2018-03-27 08:22:12 --> Helper loaded: common_helper
INFO - 2018-03-27 08:22:12 --> Database Driver Class Initialized
INFO - 2018-03-27 08:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:22:12 --> Email Class Initialized
INFO - 2018-03-27 08:22:12 --> Controller Class Initialized
INFO - 2018-03-27 08:22:12 --> Helper loaded: form_helper
INFO - 2018-03-27 08:22:12 --> Form Validation Class Initialized
INFO - 2018-03-27 08:22:12 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:22:12 --> Helper loaded: url_helper
INFO - 2018-03-27 08:22:12 --> Model Class Initialized
INFO - 2018-03-27 08:22:12 --> Model Class Initialized
INFO - 2018-03-27 08:22:12 --> Model Class Initialized
INFO - 2018-03-27 11:52:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:52:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:52:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:52:12 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:52:12 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-27 11:52:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-27 11:52:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:52:12 --> Final output sent to browser
DEBUG - 2018-03-27 11:52:12 --> Total execution time: 0.2460
INFO - 2018-03-27 08:22:24 --> Config Class Initialized
INFO - 2018-03-27 08:22:24 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:22:24 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:22:24 --> Utf8 Class Initialized
INFO - 2018-03-27 08:22:24 --> URI Class Initialized
INFO - 2018-03-27 08:22:24 --> Router Class Initialized
INFO - 2018-03-27 08:22:24 --> Output Class Initialized
INFO - 2018-03-27 08:22:24 --> Security Class Initialized
DEBUG - 2018-03-27 08:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:22:24 --> Input Class Initialized
INFO - 2018-03-27 08:22:24 --> Language Class Initialized
INFO - 2018-03-27 08:22:24 --> Loader Class Initialized
INFO - 2018-03-27 08:22:24 --> Helper loaded: common_helper
INFO - 2018-03-27 08:22:24 --> Database Driver Class Initialized
INFO - 2018-03-27 08:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:22:24 --> Email Class Initialized
INFO - 2018-03-27 08:22:24 --> Controller Class Initialized
INFO - 2018-03-27 08:22:24 --> Helper loaded: form_helper
INFO - 2018-03-27 08:22:24 --> Form Validation Class Initialized
INFO - 2018-03-27 08:22:24 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:22:24 --> Helper loaded: url_helper
INFO - 2018-03-27 08:22:24 --> Model Class Initialized
INFO - 2018-03-27 08:22:24 --> Model Class Initialized
INFO - 2018-03-27 08:22:24 --> Model Class Initialized
INFO - 2018-03-27 11:52:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:52:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:52:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-27 11:52:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:52:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:52:25 --> Final output sent to browser
DEBUG - 2018-03-27 11:52:25 --> Total execution time: 0.2380
INFO - 2018-03-27 08:22:36 --> Config Class Initialized
INFO - 2018-03-27 08:22:36 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:22:36 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:22:36 --> Utf8 Class Initialized
INFO - 2018-03-27 08:22:36 --> URI Class Initialized
INFO - 2018-03-27 08:22:36 --> Router Class Initialized
INFO - 2018-03-27 08:22:36 --> Output Class Initialized
INFO - 2018-03-27 08:22:36 --> Security Class Initialized
DEBUG - 2018-03-27 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:22:36 --> Input Class Initialized
INFO - 2018-03-27 08:22:36 --> Language Class Initialized
INFO - 2018-03-27 08:22:36 --> Loader Class Initialized
INFO - 2018-03-27 08:22:36 --> Helper loaded: common_helper
INFO - 2018-03-27 08:22:36 --> Database Driver Class Initialized
INFO - 2018-03-27 08:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:22:36 --> Email Class Initialized
INFO - 2018-03-27 08:22:36 --> Controller Class Initialized
INFO - 2018-03-27 08:22:36 --> Helper loaded: form_helper
INFO - 2018-03-27 08:22:36 --> Form Validation Class Initialized
INFO - 2018-03-27 08:22:36 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:22:36 --> Helper loaded: url_helper
INFO - 2018-03-27 08:22:36 --> Model Class Initialized
INFO - 2018-03-27 08:22:36 --> Model Class Initialized
INFO - 2018-03-27 08:22:36 --> Model Class Initialized
INFO - 2018-03-27 08:22:36 --> Config Class Initialized
INFO - 2018-03-27 08:22:36 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:22:36 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:22:36 --> Utf8 Class Initialized
INFO - 2018-03-27 08:22:36 --> URI Class Initialized
INFO - 2018-03-27 08:22:36 --> Router Class Initialized
INFO - 2018-03-27 08:22:36 --> Output Class Initialized
INFO - 2018-03-27 08:22:36 --> Security Class Initialized
DEBUG - 2018-03-27 08:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:22:36 --> Input Class Initialized
INFO - 2018-03-27 08:22:36 --> Language Class Initialized
INFO - 2018-03-27 08:22:36 --> Loader Class Initialized
INFO - 2018-03-27 08:22:36 --> Helper loaded: common_helper
INFO - 2018-03-27 08:22:36 --> Database Driver Class Initialized
INFO - 2018-03-27 08:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:22:36 --> Email Class Initialized
INFO - 2018-03-27 08:22:36 --> Controller Class Initialized
INFO - 2018-03-27 08:22:36 --> Helper loaded: form_helper
INFO - 2018-03-27 08:22:36 --> Form Validation Class Initialized
INFO - 2018-03-27 08:22:36 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:22:36 --> Helper loaded: url_helper
INFO - 2018-03-27 08:22:36 --> Model Class Initialized
INFO - 2018-03-27 08:22:36 --> Model Class Initialized
INFO - 2018-03-27 08:22:36 --> Model Class Initialized
INFO - 2018-03-27 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-27 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:52:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:52:36 --> Final output sent to browser
DEBUG - 2018-03-27 11:52:36 --> Total execution time: 0.1310
INFO - 2018-03-27 08:22:54 --> Config Class Initialized
INFO - 2018-03-27 08:22:54 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:22:54 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:22:54 --> Utf8 Class Initialized
INFO - 2018-03-27 08:22:54 --> URI Class Initialized
INFO - 2018-03-27 08:22:54 --> Router Class Initialized
INFO - 2018-03-27 08:22:54 --> Output Class Initialized
INFO - 2018-03-27 08:22:54 --> Security Class Initialized
DEBUG - 2018-03-27 08:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:22:54 --> Input Class Initialized
INFO - 2018-03-27 08:22:54 --> Language Class Initialized
INFO - 2018-03-27 08:22:54 --> Loader Class Initialized
INFO - 2018-03-27 08:22:54 --> Helper loaded: common_helper
INFO - 2018-03-27 08:22:54 --> Database Driver Class Initialized
INFO - 2018-03-27 08:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:22:54 --> Email Class Initialized
INFO - 2018-03-27 08:22:54 --> Controller Class Initialized
INFO - 2018-03-27 08:22:54 --> Helper loaded: form_helper
INFO - 2018-03-27 08:22:54 --> Form Validation Class Initialized
INFO - 2018-03-27 08:22:54 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:22:54 --> Helper loaded: url_helper
INFO - 2018-03-27 08:22:54 --> Model Class Initialized
INFO - 2018-03-27 08:22:54 --> Model Class Initialized
INFO - 2018-03-27 08:22:54 --> Model Class Initialized
INFO - 2018-03-27 08:22:55 --> Config Class Initialized
INFO - 2018-03-27 08:22:55 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:22:55 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:22:55 --> Utf8 Class Initialized
INFO - 2018-03-27 08:22:55 --> URI Class Initialized
INFO - 2018-03-27 08:22:55 --> Router Class Initialized
INFO - 2018-03-27 08:22:55 --> Output Class Initialized
INFO - 2018-03-27 08:22:55 --> Security Class Initialized
DEBUG - 2018-03-27 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:22:55 --> Input Class Initialized
INFO - 2018-03-27 08:22:55 --> Language Class Initialized
INFO - 2018-03-27 08:22:55 --> Loader Class Initialized
INFO - 2018-03-27 08:22:55 --> Helper loaded: common_helper
INFO - 2018-03-27 08:22:55 --> Database Driver Class Initialized
INFO - 2018-03-27 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:22:55 --> Email Class Initialized
INFO - 2018-03-27 08:22:55 --> Controller Class Initialized
INFO - 2018-03-27 08:22:55 --> Helper loaded: form_helper
INFO - 2018-03-27 08:22:55 --> Form Validation Class Initialized
INFO - 2018-03-27 08:22:55 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:22:55 --> Helper loaded: url_helper
INFO - 2018-03-27 08:22:55 --> Model Class Initialized
INFO - 2018-03-27 08:22:55 --> Model Class Initialized
INFO - 2018-03-27 08:22:55 --> Model Class Initialized
INFO - 2018-03-27 11:52:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:52:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:52:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-27 11:52:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:52:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:52:55 --> Final output sent to browser
DEBUG - 2018-03-27 11:52:55 --> Total execution time: 0.1480
INFO - 2018-03-27 08:23:04 --> Config Class Initialized
INFO - 2018-03-27 08:23:04 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:23:04 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:23:04 --> Utf8 Class Initialized
INFO - 2018-03-27 08:23:04 --> URI Class Initialized
INFO - 2018-03-27 08:23:04 --> Router Class Initialized
INFO - 2018-03-27 08:23:04 --> Output Class Initialized
INFO - 2018-03-27 08:23:04 --> Security Class Initialized
DEBUG - 2018-03-27 08:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:23:04 --> Input Class Initialized
INFO - 2018-03-27 08:23:04 --> Language Class Initialized
INFO - 2018-03-27 08:23:04 --> Loader Class Initialized
INFO - 2018-03-27 08:23:04 --> Helper loaded: common_helper
INFO - 2018-03-27 08:23:04 --> Database Driver Class Initialized
INFO - 2018-03-27 08:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:23:04 --> Email Class Initialized
INFO - 2018-03-27 08:23:04 --> Controller Class Initialized
INFO - 2018-03-27 08:23:04 --> Helper loaded: form_helper
INFO - 2018-03-27 08:23:04 --> Form Validation Class Initialized
INFO - 2018-03-27 08:23:04 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:23:04 --> Helper loaded: url_helper
INFO - 2018-03-27 08:23:04 --> Model Class Initialized
INFO - 2018-03-27 08:23:04 --> Model Class Initialized
INFO - 2018-03-27 08:23:04 --> Model Class Initialized
INFO - 2018-03-27 11:53:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:53:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:53:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-27 11:53:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:53:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:53:04 --> Final output sent to browser
DEBUG - 2018-03-27 11:53:04 --> Total execution time: 0.1940
INFO - 2018-03-27 08:23:08 --> Config Class Initialized
INFO - 2018-03-27 08:23:08 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:23:08 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:23:08 --> Utf8 Class Initialized
INFO - 2018-03-27 08:23:08 --> URI Class Initialized
INFO - 2018-03-27 08:23:08 --> Router Class Initialized
INFO - 2018-03-27 08:23:08 --> Output Class Initialized
INFO - 2018-03-27 08:23:08 --> Security Class Initialized
DEBUG - 2018-03-27 08:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:23:08 --> Input Class Initialized
INFO - 2018-03-27 08:23:08 --> Language Class Initialized
INFO - 2018-03-27 08:23:08 --> Loader Class Initialized
INFO - 2018-03-27 08:23:08 --> Helper loaded: common_helper
INFO - 2018-03-27 08:23:08 --> Database Driver Class Initialized
INFO - 2018-03-27 08:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:23:08 --> Email Class Initialized
INFO - 2018-03-27 08:23:08 --> Controller Class Initialized
INFO - 2018-03-27 08:23:08 --> Helper loaded: form_helper
INFO - 2018-03-27 08:23:08 --> Form Validation Class Initialized
INFO - 2018-03-27 08:23:08 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:23:08 --> Helper loaded: url_helper
INFO - 2018-03-27 08:23:08 --> Model Class Initialized
INFO - 2018-03-27 08:23:08 --> Model Class Initialized
INFO - 2018-03-27 08:23:08 --> Model Class Initialized
INFO - 2018-03-27 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:53:08 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:53:08 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-27 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-27 11:53:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:53:08 --> Final output sent to browser
DEBUG - 2018-03-27 11:53:08 --> Total execution time: 0.1960
INFO - 2018-03-27 08:23:13 --> Config Class Initialized
INFO - 2018-03-27 08:23:13 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:23:13 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:23:13 --> Utf8 Class Initialized
INFO - 2018-03-27 08:23:13 --> URI Class Initialized
INFO - 2018-03-27 08:23:13 --> Router Class Initialized
INFO - 2018-03-27 08:23:13 --> Output Class Initialized
INFO - 2018-03-27 08:23:13 --> Security Class Initialized
DEBUG - 2018-03-27 08:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:23:13 --> Input Class Initialized
INFO - 2018-03-27 08:23:13 --> Language Class Initialized
INFO - 2018-03-27 08:23:13 --> Loader Class Initialized
INFO - 2018-03-27 08:23:13 --> Helper loaded: common_helper
INFO - 2018-03-27 08:23:13 --> Database Driver Class Initialized
INFO - 2018-03-27 08:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:23:13 --> Email Class Initialized
INFO - 2018-03-27 08:23:13 --> Controller Class Initialized
INFO - 2018-03-27 08:23:13 --> Helper loaded: form_helper
INFO - 2018-03-27 08:23:13 --> Form Validation Class Initialized
INFO - 2018-03-27 08:23:13 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:23:13 --> Helper loaded: url_helper
INFO - 2018-03-27 08:23:13 --> Model Class Initialized
INFO - 2018-03-27 08:23:13 --> Model Class Initialized
INFO - 2018-03-27 08:23:13 --> Model Class Initialized
INFO - 2018-03-27 11:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-27 11:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 11:53:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:53:13 --> Final output sent to browser
DEBUG - 2018-03-27 11:53:13 --> Total execution time: 0.1560
INFO - 2018-03-27 08:28:09 --> Config Class Initialized
INFO - 2018-03-27 08:28:09 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:28:09 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:28:09 --> Utf8 Class Initialized
INFO - 2018-03-27 08:28:09 --> URI Class Initialized
INFO - 2018-03-27 08:28:09 --> Router Class Initialized
INFO - 2018-03-27 08:28:09 --> Output Class Initialized
INFO - 2018-03-27 08:28:09 --> Security Class Initialized
DEBUG - 2018-03-27 08:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:28:09 --> Input Class Initialized
INFO - 2018-03-27 08:28:09 --> Language Class Initialized
INFO - 2018-03-27 08:28:09 --> Loader Class Initialized
INFO - 2018-03-27 08:28:09 --> Helper loaded: common_helper
INFO - 2018-03-27 08:28:09 --> Database Driver Class Initialized
INFO - 2018-03-27 08:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:28:09 --> Email Class Initialized
INFO - 2018-03-27 08:28:09 --> Controller Class Initialized
INFO - 2018-03-27 08:28:09 --> Helper loaded: form_helper
INFO - 2018-03-27 08:28:09 --> Form Validation Class Initialized
INFO - 2018-03-27 08:28:09 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:28:09 --> Helper loaded: url_helper
INFO - 2018-03-27 08:28:09 --> Model Class Initialized
INFO - 2018-03-27 08:28:09 --> Model Class Initialized
INFO - 2018-03-27 08:28:09 --> Model Class Initialized
INFO - 2018-03-27 11:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 11:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 11:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH'
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Use of undefined constant HOSPITAL_IMAGE_PATH - assumed 'HOSPITAL_IMAGE_PATH' C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
ERROR - 2018-03-27 11:58:09 --> Undefined property: stdClass::$hospitalImage
ERROR - 2018-03-27 11:58:09 --> Severity: Notice --> Undefined property: stdClass::$hospitalImage C:\xampp\htdocs\FlickNews\admin\application\views\News\news.php 73
INFO - 2018-03-27 11:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-27 11:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 11:58:09 --> Final output sent to browser
DEBUG - 2018-03-27 11:58:09 --> Total execution time: 0.2230
INFO - 2018-03-27 08:30:48 --> Config Class Initialized
INFO - 2018-03-27 08:30:48 --> Hooks Class Initialized
DEBUG - 2018-03-27 08:30:48 --> UTF-8 Support Enabled
INFO - 2018-03-27 08:30:48 --> Utf8 Class Initialized
INFO - 2018-03-27 08:30:48 --> URI Class Initialized
INFO - 2018-03-27 08:30:48 --> Router Class Initialized
INFO - 2018-03-27 08:30:48 --> Output Class Initialized
INFO - 2018-03-27 08:30:48 --> Security Class Initialized
DEBUG - 2018-03-27 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-27 08:30:48 --> Input Class Initialized
INFO - 2018-03-27 08:30:48 --> Language Class Initialized
INFO - 2018-03-27 08:30:48 --> Loader Class Initialized
INFO - 2018-03-27 08:30:48 --> Helper loaded: common_helper
INFO - 2018-03-27 08:30:48 --> Database Driver Class Initialized
INFO - 2018-03-27 08:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-27 08:30:48 --> Email Class Initialized
INFO - 2018-03-27 08:30:48 --> Controller Class Initialized
INFO - 2018-03-27 08:30:48 --> Helper loaded: form_helper
INFO - 2018-03-27 08:30:48 --> Form Validation Class Initialized
INFO - 2018-03-27 08:30:48 --> Helper loaded: email_helper
DEBUG - 2018-03-27 08:30:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-27 08:30:48 --> Helper loaded: url_helper
INFO - 2018-03-27 08:30:48 --> Model Class Initialized
INFO - 2018-03-27 08:30:48 --> Model Class Initialized
INFO - 2018-03-27 08:30:48 --> Model Class Initialized
INFO - 2018-03-27 12:00:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-27 12:00:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-27 12:00:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 12:00:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-27 12:00:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-27 12:00:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-27 12:00:49 --> Final output sent to browser
DEBUG - 2018-03-27 12:00:49 --> Total execution time: 0.1350
