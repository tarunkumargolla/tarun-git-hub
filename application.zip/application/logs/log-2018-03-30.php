<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-30 19:11:45 --> Config Class Initialized
INFO - 2018-03-30 19:11:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:11:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:11:45 --> Utf8 Class Initialized
INFO - 2018-03-30 19:11:45 --> URI Class Initialized
INFO - 2018-03-30 19:11:45 --> Router Class Initialized
INFO - 2018-03-30 19:11:45 --> Output Class Initialized
INFO - 2018-03-30 19:11:45 --> Security Class Initialized
DEBUG - 2018-03-30 19:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:11:45 --> Input Class Initialized
INFO - 2018-03-30 19:11:45 --> Language Class Initialized
INFO - 2018-03-30 19:11:45 --> Loader Class Initialized
INFO - 2018-03-30 19:11:45 --> Helper loaded: common_helper
INFO - 2018-03-30 19:11:45 --> Database Driver Class Initialized
ERROR - 2018-03-30 19:11:45 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-30 19:11:45 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-30 19:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:11:46 --> Email Class Initialized
INFO - 2018-03-30 19:11:46 --> Controller Class Initialized
INFO - 2018-03-30 19:11:46 --> Helper loaded: form_helper
INFO - 2018-03-30 19:11:46 --> Form Validation Class Initialized
INFO - 2018-03-30 19:11:46 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:11:46 --> Helper loaded: url_helper
INFO - 2018-03-30 19:11:46 --> Model Class Initialized
INFO - 2018-03-30 19:11:46 --> Model Class Initialized
INFO - 2018-03-30 19:11:46 --> Model Class Initialized
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 22:41:46 --> Final output sent to browser
DEBUG - 2018-03-30 22:41:46 --> Total execution time: 0.7150
INFO - 2018-03-30 19:11:46 --> Config Class Initialized
INFO - 2018-03-30 19:11:46 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:11:46 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:11:46 --> Utf8 Class Initialized
INFO - 2018-03-30 19:11:46 --> URI Class Initialized
INFO - 2018-03-30 19:11:46 --> Router Class Initialized
INFO - 2018-03-30 19:11:46 --> Output Class Initialized
INFO - 2018-03-30 19:11:46 --> Security Class Initialized
DEBUG - 2018-03-30 19:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:11:46 --> Input Class Initialized
INFO - 2018-03-30 19:11:46 --> Language Class Initialized
INFO - 2018-03-30 19:11:46 --> Loader Class Initialized
INFO - 2018-03-30 19:11:46 --> Helper loaded: common_helper
INFO - 2018-03-30 19:11:46 --> Database Driver Class Initialized
INFO - 2018-03-30 19:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:11:46 --> Email Class Initialized
INFO - 2018-03-30 19:11:46 --> Controller Class Initialized
INFO - 2018-03-30 19:11:46 --> Helper loaded: form_helper
INFO - 2018-03-30 19:11:46 --> Form Validation Class Initialized
INFO - 2018-03-30 19:11:46 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:11:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:11:46 --> Helper loaded: url_helper
INFO - 2018-03-30 19:11:46 --> Model Class Initialized
INFO - 2018-03-30 19:11:46 --> Model Class Initialized
INFO - 2018-03-30 19:11:46 --> Model Class Initialized
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 22:41:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 22:41:46 --> Final output sent to browser
DEBUG - 2018-03-30 22:41:46 --> Total execution time: 0.1460
INFO - 2018-03-30 19:21:46 --> Config Class Initialized
INFO - 2018-03-30 19:21:46 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:21:46 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:21:46 --> Utf8 Class Initialized
INFO - 2018-03-30 19:21:46 --> URI Class Initialized
INFO - 2018-03-30 19:21:46 --> Router Class Initialized
INFO - 2018-03-30 19:21:46 --> Output Class Initialized
INFO - 2018-03-30 19:21:46 --> Security Class Initialized
DEBUG - 2018-03-30 19:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:21:46 --> Input Class Initialized
INFO - 2018-03-30 19:21:46 --> Language Class Initialized
INFO - 2018-03-30 19:21:46 --> Loader Class Initialized
INFO - 2018-03-30 19:21:46 --> Helper loaded: common_helper
INFO - 2018-03-30 19:21:46 --> Database Driver Class Initialized
INFO - 2018-03-30 19:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:21:46 --> Email Class Initialized
INFO - 2018-03-30 19:21:46 --> Controller Class Initialized
INFO - 2018-03-30 19:21:46 --> Helper loaded: form_helper
INFO - 2018-03-30 19:21:46 --> Form Validation Class Initialized
INFO - 2018-03-30 19:21:46 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:21:46 --> Helper loaded: url_helper
INFO - 2018-03-30 19:21:46 --> Model Class Initialized
INFO - 2018-03-30 19:21:46 --> Model Class Initialized
INFO - 2018-03-30 19:21:46 --> Model Class Initialized
INFO - 2018-03-30 19:22:24 --> Config Class Initialized
INFO - 2018-03-30 19:22:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:22:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:22:24 --> Utf8 Class Initialized
INFO - 2018-03-30 19:22:24 --> URI Class Initialized
INFO - 2018-03-30 19:22:24 --> Router Class Initialized
INFO - 2018-03-30 19:22:24 --> Output Class Initialized
INFO - 2018-03-30 19:22:24 --> Security Class Initialized
DEBUG - 2018-03-30 19:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:22:24 --> Input Class Initialized
INFO - 2018-03-30 19:22:24 --> Language Class Initialized
INFO - 2018-03-30 19:22:24 --> Loader Class Initialized
INFO - 2018-03-30 19:22:24 --> Helper loaded: common_helper
INFO - 2018-03-30 19:22:24 --> Database Driver Class Initialized
INFO - 2018-03-30 19:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:22:25 --> Email Class Initialized
INFO - 2018-03-30 19:22:25 --> Controller Class Initialized
INFO - 2018-03-30 19:22:25 --> Helper loaded: form_helper
INFO - 2018-03-30 19:22:25 --> Form Validation Class Initialized
INFO - 2018-03-30 19:22:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:22:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:22:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:22:25 --> Model Class Initialized
INFO - 2018-03-30 19:22:25 --> Model Class Initialized
INFO - 2018-03-30 19:22:25 --> Model Class Initialized
ERROR - 2018-03-30 22:52:25 --> Call to undefined method Galery::getAllRecord()
ERROR - 2018-03-30 22:52:25 --> Severity: Error --> Call to undefined method Galery::getAllRecord() C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 25
INFO - 2018-03-30 19:22:37 --> Config Class Initialized
INFO - 2018-03-30 19:22:37 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:22:37 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:22:37 --> Utf8 Class Initialized
INFO - 2018-03-30 19:22:37 --> URI Class Initialized
INFO - 2018-03-30 19:22:37 --> Router Class Initialized
INFO - 2018-03-30 19:22:37 --> Output Class Initialized
INFO - 2018-03-30 19:22:37 --> Security Class Initialized
DEBUG - 2018-03-30 19:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:22:37 --> Input Class Initialized
INFO - 2018-03-30 19:22:37 --> Language Class Initialized
INFO - 2018-03-30 19:22:37 --> Loader Class Initialized
INFO - 2018-03-30 19:22:37 --> Helper loaded: common_helper
INFO - 2018-03-30 19:22:37 --> Database Driver Class Initialized
INFO - 2018-03-30 19:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:22:37 --> Email Class Initialized
INFO - 2018-03-30 19:22:37 --> Controller Class Initialized
INFO - 2018-03-30 19:22:37 --> Helper loaded: form_helper
INFO - 2018-03-30 19:22:37 --> Form Validation Class Initialized
INFO - 2018-03-30 19:22:37 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:22:37 --> Helper loaded: url_helper
INFO - 2018-03-30 19:22:37 --> Model Class Initialized
INFO - 2018-03-30 19:22:37 --> Model Class Initialized
INFO - 2018-03-30 19:22:37 --> Model Class Initialized
INFO - 2018-03-30 19:23:10 --> Config Class Initialized
INFO - 2018-03-30 19:23:10 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:23:10 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:23:10 --> Utf8 Class Initialized
INFO - 2018-03-30 19:23:10 --> URI Class Initialized
INFO - 2018-03-30 19:23:10 --> Router Class Initialized
INFO - 2018-03-30 19:23:10 --> Output Class Initialized
INFO - 2018-03-30 19:23:10 --> Security Class Initialized
DEBUG - 2018-03-30 19:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:23:10 --> Input Class Initialized
INFO - 2018-03-30 19:23:10 --> Language Class Initialized
INFO - 2018-03-30 19:23:10 --> Loader Class Initialized
INFO - 2018-03-30 19:23:10 --> Helper loaded: common_helper
INFO - 2018-03-30 19:23:10 --> Database Driver Class Initialized
INFO - 2018-03-30 19:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:23:10 --> Email Class Initialized
INFO - 2018-03-30 19:23:10 --> Controller Class Initialized
INFO - 2018-03-30 19:23:10 --> Helper loaded: form_helper
INFO - 2018-03-30 19:23:10 --> Form Validation Class Initialized
INFO - 2018-03-30 19:23:10 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:23:10 --> Helper loaded: url_helper
INFO - 2018-03-30 19:23:10 --> Model Class Initialized
INFO - 2018-03-30 19:23:10 --> Model Class Initialized
INFO - 2018-03-30 19:23:10 --> Model Class Initialized
ERROR - 2018-03-30 22:53:10 --> Object of class stdClass could not be converted to string
ERROR - 2018-03-30 22:53:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 22:53:10 --> Object of class stdClass could not be converted to string
ERROR - 2018-03-30 22:53:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 22:53:10 --> Object of class stdClass could not be converted to string
ERROR - 2018-03-30 22:53:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 22:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 22:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 22:53:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 22:53:10 --> Final output sent to browser
DEBUG - 2018-03-30 22:53:10 --> Total execution time: 0.5010
INFO - 2018-03-30 19:23:10 --> Config Class Initialized
INFO - 2018-03-30 19:23:10 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:23:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:23:11 --> Utf8 Class Initialized
INFO - 2018-03-30 19:23:11 --> URI Class Initialized
INFO - 2018-03-30 19:23:11 --> Router Class Initialized
INFO - 2018-03-30 19:23:11 --> Output Class Initialized
INFO - 2018-03-30 19:23:11 --> Security Class Initialized
DEBUG - 2018-03-30 19:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:23:11 --> Input Class Initialized
INFO - 2018-03-30 19:23:11 --> Language Class Initialized
INFO - 2018-03-30 19:23:11 --> Loader Class Initialized
INFO - 2018-03-30 19:23:11 --> Helper loaded: common_helper
INFO - 2018-03-30 19:23:11 --> Database Driver Class Initialized
INFO - 2018-03-30 19:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:23:11 --> Email Class Initialized
INFO - 2018-03-30 19:23:11 --> Controller Class Initialized
INFO - 2018-03-30 19:23:11 --> Helper loaded: form_helper
INFO - 2018-03-30 19:23:11 --> Form Validation Class Initialized
INFO - 2018-03-30 19:23:11 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:23:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:23:11 --> Helper loaded: url_helper
INFO - 2018-03-30 19:23:11 --> Model Class Initialized
INFO - 2018-03-30 19:23:11 --> Model Class Initialized
INFO - 2018-03-30 19:23:11 --> Model Class Initialized
ERROR - 2018-03-30 22:53:11 --> Object of class stdClass could not be converted to string
ERROR - 2018-03-30 22:53:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 22:53:11 --> Object of class stdClass could not be converted to string
ERROR - 2018-03-30 22:53:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 22:53:11 --> Object of class stdClass could not be converted to string
ERROR - 2018-03-30 22:53:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 22:53:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:53:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:53:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 22:53:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 22:53:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 22:53:11 --> Final output sent to browser
DEBUG - 2018-03-30 22:53:11 --> Total execution time: 0.3910
INFO - 2018-03-30 19:23:32 --> Config Class Initialized
INFO - 2018-03-30 19:23:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:23:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:23:32 --> Utf8 Class Initialized
INFO - 2018-03-30 19:23:32 --> URI Class Initialized
INFO - 2018-03-30 19:23:32 --> Router Class Initialized
INFO - 2018-03-30 19:23:32 --> Output Class Initialized
INFO - 2018-03-30 19:23:32 --> Security Class Initialized
DEBUG - 2018-03-30 19:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:23:32 --> Input Class Initialized
INFO - 2018-03-30 19:23:32 --> Language Class Initialized
INFO - 2018-03-30 19:23:32 --> Loader Class Initialized
INFO - 2018-03-30 19:23:32 --> Helper loaded: common_helper
INFO - 2018-03-30 19:23:33 --> Database Driver Class Initialized
INFO - 2018-03-30 19:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:23:33 --> Email Class Initialized
INFO - 2018-03-30 19:23:33 --> Controller Class Initialized
INFO - 2018-03-30 19:23:33 --> Helper loaded: form_helper
INFO - 2018-03-30 19:23:33 --> Form Validation Class Initialized
INFO - 2018-03-30 19:23:33 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:23:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:23:33 --> Helper loaded: url_helper
INFO - 2018-03-30 19:23:33 --> Model Class Initialized
INFO - 2018-03-30 19:23:33 --> Model Class Initialized
INFO - 2018-03-30 19:23:33 --> Model Class Initialized
INFO - 2018-03-30 22:53:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:53:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:53:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 22:53:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 22:53:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 22:53:33 --> Final output sent to browser
DEBUG - 2018-03-30 22:53:33 --> Total execution time: 0.2070
INFO - 2018-03-30 19:25:11 --> Config Class Initialized
INFO - 2018-03-30 19:25:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:25:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:25:11 --> Utf8 Class Initialized
INFO - 2018-03-30 19:25:11 --> URI Class Initialized
INFO - 2018-03-30 19:25:11 --> Router Class Initialized
INFO - 2018-03-30 19:25:11 --> Output Class Initialized
INFO - 2018-03-30 19:25:11 --> Security Class Initialized
DEBUG - 2018-03-30 19:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:25:11 --> Input Class Initialized
INFO - 2018-03-30 19:25:11 --> Language Class Initialized
INFO - 2018-03-30 19:25:11 --> Loader Class Initialized
INFO - 2018-03-30 19:25:11 --> Helper loaded: common_helper
INFO - 2018-03-30 19:25:11 --> Database Driver Class Initialized
INFO - 2018-03-30 19:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:25:11 --> Email Class Initialized
INFO - 2018-03-30 19:25:11 --> Controller Class Initialized
INFO - 2018-03-30 19:25:11 --> Helper loaded: form_helper
INFO - 2018-03-30 19:25:11 --> Form Validation Class Initialized
INFO - 2018-03-30 19:25:11 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:25:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:25:11 --> Helper loaded: url_helper
INFO - 2018-03-30 19:25:11 --> Model Class Initialized
INFO - 2018-03-30 19:25:11 --> Model Class Initialized
INFO - 2018-03-30 19:25:11 --> Model Class Initialized
INFO - 2018-03-30 19:26:15 --> Config Class Initialized
INFO - 2018-03-30 19:26:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:26:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:26:15 --> Utf8 Class Initialized
INFO - 2018-03-30 19:26:15 --> URI Class Initialized
INFO - 2018-03-30 19:26:15 --> Router Class Initialized
INFO - 2018-03-30 19:26:15 --> Output Class Initialized
INFO - 2018-03-30 19:26:15 --> Security Class Initialized
DEBUG - 2018-03-30 19:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:26:15 --> Input Class Initialized
INFO - 2018-03-30 19:26:15 --> Language Class Initialized
INFO - 2018-03-30 19:26:15 --> Loader Class Initialized
INFO - 2018-03-30 19:26:15 --> Helper loaded: common_helper
INFO - 2018-03-30 19:26:15 --> Database Driver Class Initialized
INFO - 2018-03-30 19:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:26:15 --> Email Class Initialized
INFO - 2018-03-30 19:26:15 --> Controller Class Initialized
INFO - 2018-03-30 19:26:15 --> Helper loaded: form_helper
INFO - 2018-03-30 19:26:15 --> Form Validation Class Initialized
INFO - 2018-03-30 19:26:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:26:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:26:15 --> Helper loaded: url_helper
INFO - 2018-03-30 19:26:15 --> Model Class Initialized
INFO - 2018-03-30 19:26:15 --> Model Class Initialized
INFO - 2018-03-30 19:26:15 --> Model Class Initialized
INFO - 2018-03-30 19:27:10 --> Config Class Initialized
INFO - 2018-03-30 19:27:10 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:27:10 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:27:10 --> Utf8 Class Initialized
INFO - 2018-03-30 19:27:10 --> URI Class Initialized
INFO - 2018-03-30 19:27:11 --> Router Class Initialized
INFO - 2018-03-30 19:27:11 --> Output Class Initialized
INFO - 2018-03-30 19:27:11 --> Security Class Initialized
DEBUG - 2018-03-30 19:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:27:11 --> Input Class Initialized
INFO - 2018-03-30 19:27:11 --> Language Class Initialized
INFO - 2018-03-30 19:27:11 --> Loader Class Initialized
INFO - 2018-03-30 19:27:11 --> Helper loaded: common_helper
INFO - 2018-03-30 19:27:11 --> Database Driver Class Initialized
INFO - 2018-03-30 19:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:27:11 --> Email Class Initialized
INFO - 2018-03-30 19:27:11 --> Controller Class Initialized
INFO - 2018-03-30 19:27:11 --> Helper loaded: form_helper
INFO - 2018-03-30 19:27:11 --> Form Validation Class Initialized
INFO - 2018-03-30 19:27:11 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:27:11 --> Helper loaded: url_helper
INFO - 2018-03-30 19:27:11 --> Model Class Initialized
INFO - 2018-03-30 19:27:11 --> Model Class Initialized
INFO - 2018-03-30 19:27:11 --> Model Class Initialized
INFO - 2018-03-30 22:57:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:57:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:57:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 22:57:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 22:57:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 22:57:11 --> Final output sent to browser
DEBUG - 2018-03-30 22:57:11 --> Total execution time: 0.1280
INFO - 2018-03-30 19:28:05 --> Config Class Initialized
INFO - 2018-03-30 19:28:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:28:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:28:05 --> Utf8 Class Initialized
INFO - 2018-03-30 19:28:05 --> URI Class Initialized
INFO - 2018-03-30 19:28:05 --> Router Class Initialized
INFO - 2018-03-30 19:28:05 --> Output Class Initialized
INFO - 2018-03-30 19:28:05 --> Security Class Initialized
DEBUG - 2018-03-30 19:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:28:05 --> Input Class Initialized
INFO - 2018-03-30 19:28:05 --> Language Class Initialized
INFO - 2018-03-30 19:28:05 --> Loader Class Initialized
INFO - 2018-03-30 19:28:05 --> Helper loaded: common_helper
INFO - 2018-03-30 19:28:05 --> Database Driver Class Initialized
INFO - 2018-03-30 19:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:28:05 --> Email Class Initialized
INFO - 2018-03-30 19:28:05 --> Controller Class Initialized
INFO - 2018-03-30 19:28:05 --> Helper loaded: form_helper
INFO - 2018-03-30 19:28:05 --> Form Validation Class Initialized
INFO - 2018-03-30 19:28:05 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:28:05 --> Helper loaded: url_helper
INFO - 2018-03-30 19:28:05 --> Model Class Initialized
INFO - 2018-03-30 19:28:05 --> Model Class Initialized
INFO - 2018-03-30 19:28:05 --> Model Class Initialized
INFO - 2018-03-30 22:58:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:58:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:58:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 19:29:09 --> Config Class Initialized
INFO - 2018-03-30 19:29:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:29:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:29:09 --> Utf8 Class Initialized
INFO - 2018-03-30 19:29:09 --> URI Class Initialized
INFO - 2018-03-30 19:29:09 --> Router Class Initialized
INFO - 2018-03-30 19:29:09 --> Output Class Initialized
INFO - 2018-03-30 19:29:09 --> Security Class Initialized
DEBUG - 2018-03-30 19:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:29:09 --> Input Class Initialized
INFO - 2018-03-30 19:29:09 --> Language Class Initialized
INFO - 2018-03-30 19:29:09 --> Loader Class Initialized
INFO - 2018-03-30 19:29:09 --> Helper loaded: common_helper
INFO - 2018-03-30 19:29:09 --> Database Driver Class Initialized
INFO - 2018-03-30 19:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:29:09 --> Email Class Initialized
INFO - 2018-03-30 19:29:09 --> Controller Class Initialized
INFO - 2018-03-30 19:29:09 --> Helper loaded: form_helper
INFO - 2018-03-30 19:29:09 --> Form Validation Class Initialized
INFO - 2018-03-30 19:29:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:29:09 --> Helper loaded: url_helper
INFO - 2018-03-30 19:29:09 --> Model Class Initialized
INFO - 2018-03-30 19:29:09 --> Model Class Initialized
INFO - 2018-03-30 19:29:09 --> Model Class Initialized
INFO - 2018-03-30 22:59:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 22:59:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 22:59:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 19:30:28 --> Config Class Initialized
INFO - 2018-03-30 19:30:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:30:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:30:28 --> Utf8 Class Initialized
INFO - 2018-03-30 19:30:28 --> URI Class Initialized
INFO - 2018-03-30 19:30:28 --> Router Class Initialized
INFO - 2018-03-30 19:30:28 --> Output Class Initialized
INFO - 2018-03-30 19:30:28 --> Security Class Initialized
DEBUG - 2018-03-30 19:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:30:28 --> Input Class Initialized
INFO - 2018-03-30 19:30:28 --> Language Class Initialized
INFO - 2018-03-30 19:30:28 --> Loader Class Initialized
INFO - 2018-03-30 19:30:28 --> Helper loaded: common_helper
INFO - 2018-03-30 19:30:28 --> Database Driver Class Initialized
INFO - 2018-03-30 19:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:30:28 --> Email Class Initialized
INFO - 2018-03-30 19:30:28 --> Controller Class Initialized
INFO - 2018-03-30 19:30:28 --> Helper loaded: form_helper
INFO - 2018-03-30 19:30:28 --> Form Validation Class Initialized
INFO - 2018-03-30 19:30:28 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:30:28 --> Helper loaded: url_helper
INFO - 2018-03-30 19:30:28 --> Model Class Initialized
INFO - 2018-03-30 19:30:28 --> Model Class Initialized
INFO - 2018-03-30 19:30:28 --> Model Class Initialized
INFO - 2018-03-30 23:00:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:00:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:00:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:00:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:00:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:00:28 --> Final output sent to browser
DEBUG - 2018-03-30 23:00:28 --> Total execution time: 0.1310
INFO - 2018-03-30 19:32:28 --> Config Class Initialized
INFO - 2018-03-30 19:32:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:32:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:32:28 --> Utf8 Class Initialized
INFO - 2018-03-30 19:32:28 --> URI Class Initialized
INFO - 2018-03-30 19:32:28 --> Router Class Initialized
INFO - 2018-03-30 19:32:28 --> Output Class Initialized
INFO - 2018-03-30 19:32:28 --> Security Class Initialized
DEBUG - 2018-03-30 19:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:32:28 --> Input Class Initialized
INFO - 2018-03-30 19:32:28 --> Language Class Initialized
INFO - 2018-03-30 19:32:28 --> Loader Class Initialized
INFO - 2018-03-30 19:32:28 --> Helper loaded: common_helper
INFO - 2018-03-30 19:32:28 --> Database Driver Class Initialized
INFO - 2018-03-30 19:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:32:28 --> Email Class Initialized
INFO - 2018-03-30 19:32:28 --> Controller Class Initialized
INFO - 2018-03-30 19:32:28 --> Helper loaded: form_helper
INFO - 2018-03-30 19:32:28 --> Form Validation Class Initialized
INFO - 2018-03-30 19:32:28 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:32:28 --> Helper loaded: url_helper
INFO - 2018-03-30 19:32:28 --> Model Class Initialized
INFO - 2018-03-30 19:32:28 --> Model Class Initialized
INFO - 2018-03-30 19:32:28 --> Model Class Initialized
INFO - 2018-03-30 23:02:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:02:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:02:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:02:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:02:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:02:28 --> Final output sent to browser
DEBUG - 2018-03-30 23:02:28 --> Total execution time: 0.1450
INFO - 2018-03-30 19:32:34 --> Config Class Initialized
INFO - 2018-03-30 19:32:34 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:32:34 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:32:34 --> Utf8 Class Initialized
INFO - 2018-03-30 19:32:34 --> URI Class Initialized
INFO - 2018-03-30 19:32:34 --> Router Class Initialized
INFO - 2018-03-30 19:32:34 --> Output Class Initialized
INFO - 2018-03-30 19:32:34 --> Security Class Initialized
DEBUG - 2018-03-30 19:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:32:34 --> Input Class Initialized
INFO - 2018-03-30 19:32:34 --> Language Class Initialized
ERROR - 2018-03-30 19:32:34 --> 404 Page Not Found: Galery/index
INFO - 2018-03-30 19:32:47 --> Config Class Initialized
INFO - 2018-03-30 19:32:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:32:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:32:47 --> Utf8 Class Initialized
INFO - 2018-03-30 19:32:47 --> URI Class Initialized
INFO - 2018-03-30 19:32:47 --> Router Class Initialized
INFO - 2018-03-30 19:32:47 --> Output Class Initialized
INFO - 2018-03-30 19:32:47 --> Security Class Initialized
DEBUG - 2018-03-30 19:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:32:47 --> Input Class Initialized
INFO - 2018-03-30 19:32:47 --> Language Class Initialized
INFO - 2018-03-30 19:32:47 --> Loader Class Initialized
INFO - 2018-03-30 19:32:47 --> Helper loaded: common_helper
INFO - 2018-03-30 19:32:47 --> Database Driver Class Initialized
INFO - 2018-03-30 19:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:32:47 --> Email Class Initialized
INFO - 2018-03-30 19:32:47 --> Controller Class Initialized
INFO - 2018-03-30 19:32:47 --> Helper loaded: form_helper
INFO - 2018-03-30 19:32:47 --> Form Validation Class Initialized
INFO - 2018-03-30 19:32:47 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:32:47 --> Helper loaded: url_helper
INFO - 2018-03-30 19:32:47 --> Model Class Initialized
INFO - 2018-03-30 19:32:47 --> Model Class Initialized
INFO - 2018-03-30 19:32:47 --> Model Class Initialized
INFO - 2018-03-30 23:02:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:02:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:02:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:02:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:02:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:02:47 --> Final output sent to browser
DEBUG - 2018-03-30 23:02:47 --> Total execution time: 0.1750
INFO - 2018-03-30 19:32:59 --> Config Class Initialized
INFO - 2018-03-30 19:32:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:32:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:32:59 --> Utf8 Class Initialized
INFO - 2018-03-30 19:32:59 --> URI Class Initialized
DEBUG - 2018-03-30 19:32:59 --> No URI present. Default controller set.
INFO - 2018-03-30 19:32:59 --> Router Class Initialized
INFO - 2018-03-30 19:32:59 --> Output Class Initialized
INFO - 2018-03-30 19:32:59 --> Security Class Initialized
DEBUG - 2018-03-30 19:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:32:59 --> Input Class Initialized
INFO - 2018-03-30 19:32:59 --> Language Class Initialized
INFO - 2018-03-30 19:32:59 --> Loader Class Initialized
INFO - 2018-03-30 19:32:59 --> Helper loaded: common_helper
INFO - 2018-03-30 19:32:59 --> Database Driver Class Initialized
ERROR - 2018-03-30 19:32:59 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-30 19:32:59 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-30 19:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:32:59 --> Email Class Initialized
INFO - 2018-03-30 19:32:59 --> Controller Class Initialized
INFO - 2018-03-30 19:32:59 --> Helper loaded: form_helper
INFO - 2018-03-30 19:32:59 --> Form Validation Class Initialized
INFO - 2018-03-30 19:32:59 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:32:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:32:59 --> Helper loaded: url_helper
INFO - 2018-03-30 19:32:59 --> Model Class Initialized
INFO - 2018-03-30 19:32:59 --> Model Class Initialized
INFO - 2018-03-30 19:33:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-30 19:33:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:33:00 --> Final output sent to browser
DEBUG - 2018-03-30 19:33:00 --> Total execution time: 0.3040
INFO - 2018-03-30 19:33:00 --> Config Class Initialized
INFO - 2018-03-30 19:33:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:00 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:00 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:00 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:00 --> Router Class Initialized
INFO - 2018-03-30 19:33:00 --> Output Class Initialized
INFO - 2018-03-30 19:33:00 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:00 --> Input Class Initialized
INFO - 2018-03-30 19:33:00 --> Language Class Initialized
INFO - 2018-03-30 19:33:00 --> Loader Class Initialized
INFO - 2018-03-30 19:33:00 --> Helper loaded: common_helper
INFO - 2018-03-30 19:33:00 --> Database Driver Class Initialized
INFO - 2018-03-30 19:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:00 --> Email Class Initialized
INFO - 2018-03-30 19:33:00 --> Controller Class Initialized
INFO - 2018-03-30 19:33:00 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:00 --> Form Validation Class Initialized
INFO - 2018-03-30 19:33:00 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:33:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:00 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:00 --> Model Class Initialized
INFO - 2018-03-30 19:33:00 --> Model Class Initialized
INFO - 2018-03-30 19:33:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-30 19:33:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:33:00 --> Final output sent to browser
DEBUG - 2018-03-30 19:33:00 --> Total execution time: 0.1170
INFO - 2018-03-30 19:33:20 --> Config Class Initialized
INFO - 2018-03-30 19:33:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:20 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:20 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:20 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:20 --> Router Class Initialized
INFO - 2018-03-30 19:33:20 --> Output Class Initialized
INFO - 2018-03-30 19:33:20 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:20 --> Input Class Initialized
INFO - 2018-03-30 19:33:20 --> Language Class Initialized
INFO - 2018-03-30 19:33:20 --> Loader Class Initialized
INFO - 2018-03-30 19:33:20 --> Helper loaded: common_helper
INFO - 2018-03-30 19:33:20 --> Database Driver Class Initialized
INFO - 2018-03-30 19:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:20 --> Email Class Initialized
INFO - 2018-03-30 19:33:20 --> Controller Class Initialized
INFO - 2018-03-30 19:33:20 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:20 --> Form Validation Class Initialized
INFO - 2018-03-30 19:33:20 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:20 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:20 --> Model Class Initialized
INFO - 2018-03-30 19:33:20 --> Model Class Initialized
DEBUG - 2018-03-30 19:33:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 19:33:20 --> Config Class Initialized
INFO - 2018-03-30 19:33:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:20 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:20 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:20 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:20 --> Router Class Initialized
INFO - 2018-03-30 19:33:20 --> Output Class Initialized
INFO - 2018-03-30 19:33:20 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:20 --> Input Class Initialized
INFO - 2018-03-30 19:33:20 --> Language Class Initialized
INFO - 2018-03-30 19:33:21 --> Loader Class Initialized
INFO - 2018-03-30 19:33:21 --> Helper loaded: common_helper
INFO - 2018-03-30 19:33:21 --> Database Driver Class Initialized
INFO - 2018-03-30 19:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:21 --> Email Class Initialized
INFO - 2018-03-30 19:33:21 --> Controller Class Initialized
INFO - 2018-03-30 19:33:21 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:21 --> Form Validation Class Initialized
INFO - 2018-03-30 19:33:21 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:21 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:21 --> Model Class Initialized
INFO - 2018-03-30 19:33:21 --> Model Class Initialized
INFO - 2018-03-30 19:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-30 19:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:33:21 --> Final output sent to browser
DEBUG - 2018-03-30 19:33:21 --> Total execution time: 0.1140
INFO - 2018-03-30 19:33:36 --> Config Class Initialized
INFO - 2018-03-30 19:33:36 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:36 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:36 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:36 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:36 --> Router Class Initialized
INFO - 2018-03-30 19:33:36 --> Output Class Initialized
INFO - 2018-03-30 19:33:36 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:36 --> Input Class Initialized
INFO - 2018-03-30 19:33:36 --> Language Class Initialized
INFO - 2018-03-30 19:33:36 --> Loader Class Initialized
INFO - 2018-03-30 19:33:36 --> Helper loaded: common_helper
INFO - 2018-03-30 19:33:36 --> Database Driver Class Initialized
INFO - 2018-03-30 19:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:36 --> Email Class Initialized
INFO - 2018-03-30 19:33:36 --> Controller Class Initialized
INFO - 2018-03-30 19:33:36 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:36 --> Form Validation Class Initialized
INFO - 2018-03-30 19:33:36 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:36 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:36 --> Model Class Initialized
INFO - 2018-03-30 19:33:36 --> Model Class Initialized
DEBUG - 2018-03-30 19:33:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 19:33:36 --> Config Class Initialized
INFO - 2018-03-30 19:33:36 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:33:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:33:36 --> Utf8 Class Initialized
INFO - 2018-03-30 19:33:36 --> URI Class Initialized
DEBUG - 2018-03-30 19:33:36 --> No URI present. Default controller set.
INFO - 2018-03-30 19:33:36 --> Router Class Initialized
INFO - 2018-03-30 19:33:36 --> Output Class Initialized
INFO - 2018-03-30 19:33:36 --> Security Class Initialized
DEBUG - 2018-03-30 19:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:33:36 --> Input Class Initialized
INFO - 2018-03-30 19:33:36 --> Language Class Initialized
INFO - 2018-03-30 19:33:36 --> Loader Class Initialized
INFO - 2018-03-30 19:33:36 --> Helper loaded: common_helper
INFO - 2018-03-30 19:33:36 --> Database Driver Class Initialized
INFO - 2018-03-30 19:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:33:36 --> Email Class Initialized
INFO - 2018-03-30 19:33:36 --> Controller Class Initialized
INFO - 2018-03-30 19:33:36 --> Helper loaded: form_helper
INFO - 2018-03-30 19:33:36 --> Form Validation Class Initialized
INFO - 2018-03-30 19:33:36 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:33:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:33:36 --> Helper loaded: url_helper
INFO - 2018-03-30 19:33:36 --> Model Class Initialized
INFO - 2018-03-30 19:33:36 --> Model Class Initialized
INFO - 2018-03-30 19:33:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-30 19:33:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:33:36 --> Final output sent to browser
DEBUG - 2018-03-30 19:33:36 --> Total execution time: 0.1140
INFO - 2018-03-30 19:34:25 --> Config Class Initialized
INFO - 2018-03-30 19:34:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:34:25 --> Utf8 Class Initialized
INFO - 2018-03-30 19:34:25 --> URI Class Initialized
DEBUG - 2018-03-30 19:34:25 --> No URI present. Default controller set.
INFO - 2018-03-30 19:34:25 --> Router Class Initialized
INFO - 2018-03-30 19:34:25 --> Output Class Initialized
INFO - 2018-03-30 19:34:25 --> Security Class Initialized
DEBUG - 2018-03-30 19:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:34:25 --> Input Class Initialized
INFO - 2018-03-30 19:34:25 --> Language Class Initialized
INFO - 2018-03-30 19:34:25 --> Loader Class Initialized
INFO - 2018-03-30 19:34:25 --> Helper loaded: common_helper
INFO - 2018-03-30 19:34:25 --> Database Driver Class Initialized
INFO - 2018-03-30 19:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:34:25 --> Email Class Initialized
INFO - 2018-03-30 19:34:25 --> Controller Class Initialized
INFO - 2018-03-30 19:34:25 --> Helper loaded: form_helper
INFO - 2018-03-30 19:34:25 --> Form Validation Class Initialized
INFO - 2018-03-30 19:34:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:34:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:34:25 --> Model Class Initialized
INFO - 2018-03-30 19:34:25 --> Model Class Initialized
DEBUG - 2018-03-30 19:34:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:34:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-30 19:34:25 --> Config Class Initialized
INFO - 2018-03-30 19:34:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:34:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:34:25 --> Utf8 Class Initialized
INFO - 2018-03-30 19:34:25 --> URI Class Initialized
INFO - 2018-03-30 19:34:25 --> Router Class Initialized
INFO - 2018-03-30 19:34:25 --> Output Class Initialized
INFO - 2018-03-30 19:34:25 --> Security Class Initialized
DEBUG - 2018-03-30 19:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:34:25 --> Input Class Initialized
INFO - 2018-03-30 19:34:25 --> Language Class Initialized
INFO - 2018-03-30 19:34:25 --> Loader Class Initialized
INFO - 2018-03-30 19:34:25 --> Helper loaded: common_helper
INFO - 2018-03-30 19:34:25 --> Database Driver Class Initialized
INFO - 2018-03-30 19:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:34:25 --> Email Class Initialized
INFO - 2018-03-30 19:34:25 --> Controller Class Initialized
INFO - 2018-03-30 19:34:25 --> Helper loaded: form_helper
INFO - 2018-03-30 19:34:25 --> Form Validation Class Initialized
INFO - 2018-03-30 19:34:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:34:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:34:25 --> Model Class Initialized
INFO - 2018-03-30 19:34:25 --> Model Class Initialized
INFO - 2018-03-30 19:34:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-30 19:34:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:34:26 --> Final output sent to browser
DEBUG - 2018-03-30 19:34:26 --> Total execution time: 0.1600
INFO - 2018-03-30 19:34:42 --> Config Class Initialized
INFO - 2018-03-30 19:34:42 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:34:42 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:34:42 --> Utf8 Class Initialized
INFO - 2018-03-30 19:34:42 --> URI Class Initialized
INFO - 2018-03-30 19:34:42 --> Router Class Initialized
INFO - 2018-03-30 19:34:42 --> Output Class Initialized
INFO - 2018-03-30 19:34:42 --> Security Class Initialized
DEBUG - 2018-03-30 19:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:34:42 --> Input Class Initialized
INFO - 2018-03-30 19:34:42 --> Language Class Initialized
INFO - 2018-03-30 19:34:42 --> Loader Class Initialized
INFO - 2018-03-30 19:34:42 --> Helper loaded: common_helper
INFO - 2018-03-30 19:34:42 --> Database Driver Class Initialized
INFO - 2018-03-30 19:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:34:42 --> Email Class Initialized
INFO - 2018-03-30 19:34:42 --> Controller Class Initialized
INFO - 2018-03-30 19:34:42 --> Helper loaded: form_helper
INFO - 2018-03-30 19:34:42 --> Form Validation Class Initialized
INFO - 2018-03-30 19:34:42 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:34:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:34:42 --> Helper loaded: url_helper
INFO - 2018-03-30 19:34:42 --> Model Class Initialized
INFO - 2018-03-30 19:34:42 --> Model Class Initialized
INFO - 2018-03-30 19:34:42 --> Model Class Initialized
INFO - 2018-03-30 23:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:04:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:04:42 --> Final output sent to browser
DEBUG - 2018-03-30 23:04:42 --> Total execution time: 0.1420
INFO - 2018-03-30 19:36:16 --> Config Class Initialized
INFO - 2018-03-30 19:36:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:36:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:36:16 --> Utf8 Class Initialized
INFO - 2018-03-30 19:36:16 --> URI Class Initialized
INFO - 2018-03-30 19:36:16 --> Router Class Initialized
INFO - 2018-03-30 19:36:16 --> Output Class Initialized
INFO - 2018-03-30 19:36:16 --> Security Class Initialized
DEBUG - 2018-03-30 19:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:36:16 --> Input Class Initialized
INFO - 2018-03-30 19:36:16 --> Language Class Initialized
INFO - 2018-03-30 19:36:16 --> Loader Class Initialized
INFO - 2018-03-30 19:36:16 --> Helper loaded: common_helper
INFO - 2018-03-30 19:36:16 --> Database Driver Class Initialized
INFO - 2018-03-30 19:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:36:16 --> Email Class Initialized
INFO - 2018-03-30 19:36:16 --> Controller Class Initialized
INFO - 2018-03-30 19:36:16 --> Helper loaded: form_helper
INFO - 2018-03-30 19:36:16 --> Form Validation Class Initialized
INFO - 2018-03-30 19:36:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:36:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:36:16 --> Helper loaded: url_helper
INFO - 2018-03-30 19:36:16 --> Model Class Initialized
INFO - 2018-03-30 19:36:16 --> Model Class Initialized
INFO - 2018-03-30 19:36:16 --> Model Class Initialized
INFO - 2018-03-30 23:06:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:06:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:06:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:06:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:06:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:06:16 --> Final output sent to browser
DEBUG - 2018-03-30 23:06:16 --> Total execution time: 0.1280
INFO - 2018-03-30 19:39:18 --> Config Class Initialized
INFO - 2018-03-30 19:39:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:39:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:39:18 --> Utf8 Class Initialized
INFO - 2018-03-30 19:39:18 --> URI Class Initialized
INFO - 2018-03-30 19:39:18 --> Router Class Initialized
INFO - 2018-03-30 19:39:18 --> Output Class Initialized
INFO - 2018-03-30 19:39:18 --> Security Class Initialized
DEBUG - 2018-03-30 19:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:39:18 --> Input Class Initialized
INFO - 2018-03-30 19:39:18 --> Language Class Initialized
INFO - 2018-03-30 19:39:18 --> Loader Class Initialized
INFO - 2018-03-30 19:39:18 --> Helper loaded: common_helper
INFO - 2018-03-30 19:39:18 --> Database Driver Class Initialized
INFO - 2018-03-30 19:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:39:18 --> Email Class Initialized
INFO - 2018-03-30 19:39:18 --> Controller Class Initialized
INFO - 2018-03-30 19:39:18 --> Helper loaded: form_helper
INFO - 2018-03-30 19:39:18 --> Form Validation Class Initialized
INFO - 2018-03-30 19:39:18 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:39:18 --> Helper loaded: url_helper
INFO - 2018-03-30 19:39:18 --> Model Class Initialized
INFO - 2018-03-30 19:39:18 --> Model Class Initialized
INFO - 2018-03-30 19:39:18 --> Model Class Initialized
INFO - 2018-03-30 23:09:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:09:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:09:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:09:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:09:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:09:18 --> Final output sent to browser
DEBUG - 2018-03-30 23:09:18 --> Total execution time: 0.1560
INFO - 2018-03-30 19:43:27 --> Config Class Initialized
INFO - 2018-03-30 19:43:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:43:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:43:27 --> Utf8 Class Initialized
INFO - 2018-03-30 19:43:27 --> URI Class Initialized
INFO - 2018-03-30 19:43:27 --> Router Class Initialized
INFO - 2018-03-30 19:43:27 --> Output Class Initialized
INFO - 2018-03-30 19:43:27 --> Security Class Initialized
DEBUG - 2018-03-30 19:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:43:27 --> Input Class Initialized
INFO - 2018-03-30 19:43:27 --> Language Class Initialized
INFO - 2018-03-30 19:43:27 --> Loader Class Initialized
INFO - 2018-03-30 19:43:27 --> Helper loaded: common_helper
INFO - 2018-03-30 19:43:27 --> Database Driver Class Initialized
INFO - 2018-03-30 19:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:43:27 --> Email Class Initialized
INFO - 2018-03-30 19:43:27 --> Controller Class Initialized
INFO - 2018-03-30 19:43:27 --> Helper loaded: form_helper
INFO - 2018-03-30 19:43:27 --> Form Validation Class Initialized
INFO - 2018-03-30 19:43:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:43:27 --> Helper loaded: url_helper
INFO - 2018-03-30 19:43:27 --> Model Class Initialized
INFO - 2018-03-30 19:43:27 --> Model Class Initialized
INFO - 2018-03-30 19:43:27 --> Model Class Initialized
INFO - 2018-03-30 19:45:45 --> Config Class Initialized
INFO - 2018-03-30 19:45:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:45:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:45:45 --> Utf8 Class Initialized
INFO - 2018-03-30 19:45:45 --> URI Class Initialized
INFO - 2018-03-30 19:45:45 --> Router Class Initialized
INFO - 2018-03-30 19:45:45 --> Output Class Initialized
INFO - 2018-03-30 19:45:45 --> Security Class Initialized
DEBUG - 2018-03-30 19:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:45:45 --> Input Class Initialized
INFO - 2018-03-30 19:45:45 --> Language Class Initialized
INFO - 2018-03-30 19:45:45 --> Loader Class Initialized
INFO - 2018-03-30 19:45:45 --> Helper loaded: common_helper
INFO - 2018-03-30 19:45:45 --> Database Driver Class Initialized
INFO - 2018-03-30 19:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:45:45 --> Email Class Initialized
INFO - 2018-03-30 19:45:45 --> Controller Class Initialized
INFO - 2018-03-30 19:45:45 --> Helper loaded: form_helper
INFO - 2018-03-30 19:45:45 --> Form Validation Class Initialized
INFO - 2018-03-30 19:45:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:45:45 --> Helper loaded: url_helper
INFO - 2018-03-30 19:45:45 --> Model Class Initialized
INFO - 2018-03-30 19:45:45 --> Model Class Initialized
INFO - 2018-03-30 19:45:45 --> Model Class Initialized
INFO - 2018-03-30 19:45:53 --> Config Class Initialized
INFO - 2018-03-30 19:45:53 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:45:53 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:45:53 --> Utf8 Class Initialized
INFO - 2018-03-30 19:45:54 --> URI Class Initialized
INFO - 2018-03-30 19:45:54 --> Router Class Initialized
INFO - 2018-03-30 19:45:54 --> Output Class Initialized
INFO - 2018-03-30 19:45:54 --> Security Class Initialized
DEBUG - 2018-03-30 19:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:45:54 --> Input Class Initialized
INFO - 2018-03-30 19:45:54 --> Language Class Initialized
INFO - 2018-03-30 19:45:54 --> Loader Class Initialized
INFO - 2018-03-30 19:45:54 --> Helper loaded: common_helper
INFO - 2018-03-30 19:45:54 --> Database Driver Class Initialized
INFO - 2018-03-30 19:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:45:54 --> Email Class Initialized
INFO - 2018-03-30 19:45:54 --> Controller Class Initialized
INFO - 2018-03-30 19:45:54 --> Helper loaded: form_helper
INFO - 2018-03-30 19:45:54 --> Form Validation Class Initialized
INFO - 2018-03-30 19:45:54 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:45:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:45:54 --> Helper loaded: url_helper
INFO - 2018-03-30 19:45:54 --> Model Class Initialized
INFO - 2018-03-30 19:45:54 --> Model Class Initialized
INFO - 2018-03-30 19:45:54 --> Model Class Initialized
INFO - 2018-03-30 19:46:13 --> Config Class Initialized
INFO - 2018-03-30 19:46:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:13 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:13 --> URI Class Initialized
INFO - 2018-03-30 19:46:13 --> Router Class Initialized
INFO - 2018-03-30 19:46:13 --> Output Class Initialized
INFO - 2018-03-30 19:46:13 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:13 --> Input Class Initialized
INFO - 2018-03-30 19:46:13 --> Language Class Initialized
INFO - 2018-03-30 19:46:13 --> Loader Class Initialized
INFO - 2018-03-30 19:46:13 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:13 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:13 --> Email Class Initialized
INFO - 2018-03-30 19:46:13 --> Controller Class Initialized
INFO - 2018-03-30 19:46:13 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:13 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:13 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:13 --> Model Class Initialized
INFO - 2018-03-30 19:46:13 --> Model Class Initialized
INFO - 2018-03-30 19:46:13 --> Model Class Initialized
ERROR - 2018-03-30 23:16:13 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:13 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:46:26 --> Config Class Initialized
INFO - 2018-03-30 19:46:26 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:27 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:27 --> URI Class Initialized
INFO - 2018-03-30 19:46:27 --> Router Class Initialized
INFO - 2018-03-30 19:46:27 --> Output Class Initialized
INFO - 2018-03-30 19:46:27 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:27 --> Input Class Initialized
INFO - 2018-03-30 19:46:27 --> Language Class Initialized
INFO - 2018-03-30 19:46:27 --> Loader Class Initialized
INFO - 2018-03-30 19:46:27 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:27 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:27 --> Email Class Initialized
INFO - 2018-03-30 19:46:27 --> Controller Class Initialized
INFO - 2018-03-30 19:46:27 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:27 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:27 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:27 --> Model Class Initialized
INFO - 2018-03-30 19:46:27 --> Model Class Initialized
INFO - 2018-03-30 19:46:27 --> Model Class Initialized
ERROR - 2018-03-30 23:16:27 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:27 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:46:28 --> Config Class Initialized
INFO - 2018-03-30 19:46:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:28 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:28 --> URI Class Initialized
INFO - 2018-03-30 19:46:28 --> Router Class Initialized
INFO - 2018-03-30 19:46:28 --> Output Class Initialized
INFO - 2018-03-30 19:46:28 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:28 --> Input Class Initialized
INFO - 2018-03-30 19:46:28 --> Language Class Initialized
INFO - 2018-03-30 19:46:28 --> Loader Class Initialized
INFO - 2018-03-30 19:46:28 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:28 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:28 --> Email Class Initialized
INFO - 2018-03-30 19:46:28 --> Controller Class Initialized
INFO - 2018-03-30 19:46:28 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:28 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:28 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:28 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:28 --> Model Class Initialized
INFO - 2018-03-30 19:46:28 --> Model Class Initialized
INFO - 2018-03-30 19:46:28 --> Model Class Initialized
ERROR - 2018-03-30 23:16:28 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:28 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:46:29 --> Config Class Initialized
INFO - 2018-03-30 19:46:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:29 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:29 --> URI Class Initialized
INFO - 2018-03-30 19:46:29 --> Router Class Initialized
INFO - 2018-03-30 19:46:29 --> Output Class Initialized
INFO - 2018-03-30 19:46:29 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:29 --> Input Class Initialized
INFO - 2018-03-30 19:46:29 --> Language Class Initialized
INFO - 2018-03-30 19:46:29 --> Loader Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:29 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:29 --> Email Class Initialized
INFO - 2018-03-30 19:46:29 --> Controller Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:29 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:29 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
ERROR - 2018-03-30 23:16:29 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:29 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:46:29 --> Config Class Initialized
INFO - 2018-03-30 19:46:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:29 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:29 --> URI Class Initialized
INFO - 2018-03-30 19:46:29 --> Router Class Initialized
INFO - 2018-03-30 19:46:29 --> Output Class Initialized
INFO - 2018-03-30 19:46:29 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:29 --> Input Class Initialized
INFO - 2018-03-30 19:46:29 --> Language Class Initialized
INFO - 2018-03-30 19:46:29 --> Loader Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:29 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:29 --> Email Class Initialized
INFO - 2018-03-30 19:46:29 --> Controller Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:29 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:29 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
ERROR - 2018-03-30 23:16:29 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:29 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:46:29 --> Config Class Initialized
INFO - 2018-03-30 19:46:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:29 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:29 --> URI Class Initialized
INFO - 2018-03-30 19:46:29 --> Router Class Initialized
INFO - 2018-03-30 19:46:29 --> Output Class Initialized
INFO - 2018-03-30 19:46:29 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:29 --> Input Class Initialized
INFO - 2018-03-30 19:46:29 --> Language Class Initialized
INFO - 2018-03-30 19:46:29 --> Loader Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:29 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:29 --> Email Class Initialized
INFO - 2018-03-30 19:46:29 --> Controller Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:29 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:29 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
INFO - 2018-03-30 19:46:29 --> Model Class Initialized
ERROR - 2018-03-30 23:16:29 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:29 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:46:29 --> Config Class Initialized
INFO - 2018-03-30 19:46:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:46:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:46:30 --> Utf8 Class Initialized
INFO - 2018-03-30 19:46:30 --> URI Class Initialized
INFO - 2018-03-30 19:46:30 --> Router Class Initialized
INFO - 2018-03-30 19:46:30 --> Output Class Initialized
INFO - 2018-03-30 19:46:30 --> Security Class Initialized
DEBUG - 2018-03-30 19:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:46:30 --> Input Class Initialized
INFO - 2018-03-30 19:46:30 --> Language Class Initialized
INFO - 2018-03-30 19:46:30 --> Loader Class Initialized
INFO - 2018-03-30 19:46:30 --> Helper loaded: common_helper
INFO - 2018-03-30 19:46:30 --> Database Driver Class Initialized
INFO - 2018-03-30 19:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:46:30 --> Email Class Initialized
INFO - 2018-03-30 19:46:30 --> Controller Class Initialized
INFO - 2018-03-30 19:46:30 --> Helper loaded: form_helper
INFO - 2018-03-30 19:46:30 --> Form Validation Class Initialized
INFO - 2018-03-30 19:46:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:46:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:46:30 --> Helper loaded: url_helper
INFO - 2018-03-30 19:46:30 --> Model Class Initialized
INFO - 2018-03-30 19:46:30 --> Model Class Initialized
INFO - 2018-03-30 19:46:30 --> Model Class Initialized
ERROR - 2018-03-30 23:16:30 --> Cannot use object of type stdClass as array
ERROR - 2018-03-30 23:16:30 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:47:07 --> Config Class Initialized
INFO - 2018-03-30 19:47:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:47:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:47:07 --> Utf8 Class Initialized
INFO - 2018-03-30 19:47:07 --> URI Class Initialized
INFO - 2018-03-30 19:47:07 --> Router Class Initialized
INFO - 2018-03-30 19:47:07 --> Output Class Initialized
INFO - 2018-03-30 19:47:07 --> Security Class Initialized
DEBUG - 2018-03-30 19:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:47:07 --> Input Class Initialized
INFO - 2018-03-30 19:47:07 --> Language Class Initialized
INFO - 2018-03-30 19:47:07 --> Loader Class Initialized
INFO - 2018-03-30 19:47:07 --> Helper loaded: common_helper
INFO - 2018-03-30 19:47:07 --> Database Driver Class Initialized
INFO - 2018-03-30 19:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:47:07 --> Email Class Initialized
INFO - 2018-03-30 19:47:07 --> Controller Class Initialized
INFO - 2018-03-30 19:47:07 --> Helper loaded: form_helper
INFO - 2018-03-30 19:47:07 --> Form Validation Class Initialized
INFO - 2018-03-30 19:47:07 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:47:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:47:07 --> Helper loaded: url_helper
INFO - 2018-03-30 19:47:07 --> Model Class Initialized
INFO - 2018-03-30 19:47:07 --> Model Class Initialized
INFO - 2018-03-30 19:47:07 --> Model Class Initialized
INFO - 2018-03-30 19:48:24 --> Config Class Initialized
INFO - 2018-03-30 19:48:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:48:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:48:24 --> Utf8 Class Initialized
INFO - 2018-03-30 19:48:24 --> URI Class Initialized
INFO - 2018-03-30 19:48:24 --> Router Class Initialized
INFO - 2018-03-30 19:48:24 --> Output Class Initialized
INFO - 2018-03-30 19:48:24 --> Security Class Initialized
DEBUG - 2018-03-30 19:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:48:24 --> Input Class Initialized
INFO - 2018-03-30 19:48:24 --> Language Class Initialized
INFO - 2018-03-30 19:48:24 --> Loader Class Initialized
INFO - 2018-03-30 19:48:24 --> Helper loaded: common_helper
INFO - 2018-03-30 19:48:24 --> Database Driver Class Initialized
INFO - 2018-03-30 19:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:48:24 --> Email Class Initialized
INFO - 2018-03-30 19:48:24 --> Controller Class Initialized
INFO - 2018-03-30 19:48:24 --> Helper loaded: form_helper
INFO - 2018-03-30 19:48:24 --> Form Validation Class Initialized
INFO - 2018-03-30 19:48:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:48:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:48:24 --> Helper loaded: url_helper
INFO - 2018-03-30 19:48:24 --> Model Class Initialized
INFO - 2018-03-30 19:48:24 --> Model Class Initialized
INFO - 2018-03-30 19:48:24 --> Model Class Initialized
INFO - 2018-03-30 19:48:25 --> Config Class Initialized
INFO - 2018-03-30 19:48:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:48:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:48:25 --> Utf8 Class Initialized
INFO - 2018-03-30 19:48:25 --> URI Class Initialized
INFO - 2018-03-30 19:48:25 --> Router Class Initialized
INFO - 2018-03-30 19:48:25 --> Output Class Initialized
INFO - 2018-03-30 19:48:25 --> Security Class Initialized
DEBUG - 2018-03-30 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:48:25 --> Input Class Initialized
INFO - 2018-03-30 19:48:25 --> Language Class Initialized
INFO - 2018-03-30 19:48:25 --> Loader Class Initialized
INFO - 2018-03-30 19:48:25 --> Helper loaded: common_helper
INFO - 2018-03-30 19:48:25 --> Database Driver Class Initialized
INFO - 2018-03-30 19:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:48:25 --> Email Class Initialized
INFO - 2018-03-30 19:48:25 --> Controller Class Initialized
INFO - 2018-03-30 19:48:25 --> Helper loaded: form_helper
INFO - 2018-03-30 19:48:25 --> Form Validation Class Initialized
INFO - 2018-03-30 19:48:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:48:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:48:25 --> Helper loaded: url_helper
INFO - 2018-03-30 19:48:25 --> Model Class Initialized
INFO - 2018-03-30 19:48:25 --> Model Class Initialized
INFO - 2018-03-30 19:48:25 --> Model Class Initialized
INFO - 2018-03-30 19:48:44 --> Config Class Initialized
INFO - 2018-03-30 19:48:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:48:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:48:44 --> Utf8 Class Initialized
INFO - 2018-03-30 19:48:44 --> URI Class Initialized
INFO - 2018-03-30 19:48:44 --> Router Class Initialized
INFO - 2018-03-30 19:48:44 --> Output Class Initialized
INFO - 2018-03-30 19:48:44 --> Security Class Initialized
DEBUG - 2018-03-30 19:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:48:44 --> Input Class Initialized
INFO - 2018-03-30 19:48:44 --> Language Class Initialized
INFO - 2018-03-30 19:48:45 --> Loader Class Initialized
INFO - 2018-03-30 19:48:45 --> Helper loaded: common_helper
INFO - 2018-03-30 19:48:45 --> Database Driver Class Initialized
INFO - 2018-03-30 19:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:48:45 --> Email Class Initialized
INFO - 2018-03-30 19:48:45 --> Controller Class Initialized
INFO - 2018-03-30 19:48:45 --> Helper loaded: form_helper
INFO - 2018-03-30 19:48:45 --> Form Validation Class Initialized
INFO - 2018-03-30 19:48:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:48:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:48:45 --> Helper loaded: url_helper
INFO - 2018-03-30 19:48:45 --> Model Class Initialized
INFO - 2018-03-30 19:48:45 --> Model Class Initialized
INFO - 2018-03-30 19:48:45 --> Model Class Initialized
INFO - 2018-03-30 19:50:08 --> Config Class Initialized
INFO - 2018-03-30 19:50:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:50:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:50:08 --> Utf8 Class Initialized
INFO - 2018-03-30 19:50:08 --> URI Class Initialized
INFO - 2018-03-30 19:50:08 --> Router Class Initialized
INFO - 2018-03-30 19:50:08 --> Output Class Initialized
INFO - 2018-03-30 19:50:08 --> Security Class Initialized
DEBUG - 2018-03-30 19:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:50:08 --> Input Class Initialized
INFO - 2018-03-30 19:50:08 --> Language Class Initialized
INFO - 2018-03-30 19:50:08 --> Loader Class Initialized
INFO - 2018-03-30 19:50:08 --> Helper loaded: common_helper
INFO - 2018-03-30 19:50:08 --> Database Driver Class Initialized
INFO - 2018-03-30 19:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:50:08 --> Email Class Initialized
INFO - 2018-03-30 19:50:08 --> Controller Class Initialized
INFO - 2018-03-30 19:50:08 --> Helper loaded: form_helper
INFO - 2018-03-30 19:50:08 --> Form Validation Class Initialized
INFO - 2018-03-30 19:50:08 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:50:08 --> Helper loaded: url_helper
INFO - 2018-03-30 19:50:08 --> Model Class Initialized
INFO - 2018-03-30 19:50:08 --> Model Class Initialized
INFO - 2018-03-30 19:50:08 --> Model Class Initialized
INFO - 2018-03-30 19:50:24 --> Config Class Initialized
INFO - 2018-03-30 19:50:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:50:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:50:24 --> Utf8 Class Initialized
INFO - 2018-03-30 19:50:24 --> URI Class Initialized
INFO - 2018-03-30 19:50:24 --> Router Class Initialized
INFO - 2018-03-30 19:50:24 --> Output Class Initialized
INFO - 2018-03-30 19:50:24 --> Security Class Initialized
DEBUG - 2018-03-30 19:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:50:24 --> Input Class Initialized
INFO - 2018-03-30 19:50:24 --> Language Class Initialized
INFO - 2018-03-30 19:50:24 --> Loader Class Initialized
INFO - 2018-03-30 19:50:24 --> Helper loaded: common_helper
INFO - 2018-03-30 19:50:24 --> Database Driver Class Initialized
INFO - 2018-03-30 19:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:50:24 --> Email Class Initialized
INFO - 2018-03-30 19:50:24 --> Controller Class Initialized
INFO - 2018-03-30 19:50:24 --> Helper loaded: form_helper
INFO - 2018-03-30 19:50:24 --> Form Validation Class Initialized
INFO - 2018-03-30 19:50:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:50:24 --> Helper loaded: url_helper
INFO - 2018-03-30 19:50:24 --> Model Class Initialized
INFO - 2018-03-30 19:50:24 --> Model Class Initialized
INFO - 2018-03-30 19:50:24 --> Model Class Initialized
INFO - 2018-03-30 19:50:32 --> Config Class Initialized
INFO - 2018-03-30 19:50:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:50:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:50:32 --> Utf8 Class Initialized
INFO - 2018-03-30 19:50:32 --> URI Class Initialized
INFO - 2018-03-30 19:50:32 --> Router Class Initialized
INFO - 2018-03-30 19:50:32 --> Output Class Initialized
INFO - 2018-03-30 19:50:32 --> Security Class Initialized
DEBUG - 2018-03-30 19:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:50:32 --> Input Class Initialized
INFO - 2018-03-30 19:50:32 --> Language Class Initialized
INFO - 2018-03-30 19:50:32 --> Loader Class Initialized
INFO - 2018-03-30 19:50:32 --> Helper loaded: common_helper
INFO - 2018-03-30 19:50:32 --> Database Driver Class Initialized
INFO - 2018-03-30 19:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:50:32 --> Email Class Initialized
INFO - 2018-03-30 19:50:32 --> Controller Class Initialized
INFO - 2018-03-30 19:50:32 --> Helper loaded: form_helper
INFO - 2018-03-30 19:50:32 --> Form Validation Class Initialized
INFO - 2018-03-30 19:50:32 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:50:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:50:32 --> Helper loaded: url_helper
INFO - 2018-03-30 19:50:32 --> Model Class Initialized
INFO - 2018-03-30 19:50:32 --> Model Class Initialized
INFO - 2018-03-30 19:50:32 --> Model Class Initialized
INFO - 2018-03-30 19:51:02 --> Config Class Initialized
INFO - 2018-03-30 19:51:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:51:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:51:02 --> Utf8 Class Initialized
INFO - 2018-03-30 19:51:02 --> URI Class Initialized
INFO - 2018-03-30 19:51:02 --> Router Class Initialized
INFO - 2018-03-30 19:51:02 --> Output Class Initialized
INFO - 2018-03-30 19:51:02 --> Security Class Initialized
DEBUG - 2018-03-30 19:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:51:02 --> Input Class Initialized
INFO - 2018-03-30 19:51:02 --> Language Class Initialized
INFO - 2018-03-30 19:51:02 --> Loader Class Initialized
INFO - 2018-03-30 19:51:02 --> Helper loaded: common_helper
INFO - 2018-03-30 19:51:02 --> Database Driver Class Initialized
INFO - 2018-03-30 19:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:51:02 --> Email Class Initialized
INFO - 2018-03-30 19:51:02 --> Controller Class Initialized
INFO - 2018-03-30 19:51:02 --> Helper loaded: form_helper
INFO - 2018-03-30 19:51:02 --> Form Validation Class Initialized
INFO - 2018-03-30 19:51:02 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:51:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:51:02 --> Helper loaded: url_helper
INFO - 2018-03-30 19:51:02 --> Model Class Initialized
INFO - 2018-03-30 19:51:02 --> Model Class Initialized
INFO - 2018-03-30 19:51:02 --> Model Class Initialized
INFO - 2018-03-30 19:53:41 --> Config Class Initialized
INFO - 2018-03-30 19:53:41 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:53:41 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:53:41 --> Utf8 Class Initialized
INFO - 2018-03-30 19:53:41 --> URI Class Initialized
INFO - 2018-03-30 19:53:41 --> Router Class Initialized
INFO - 2018-03-30 19:53:41 --> Output Class Initialized
INFO - 2018-03-30 19:53:41 --> Security Class Initialized
DEBUG - 2018-03-30 19:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:53:41 --> Input Class Initialized
INFO - 2018-03-30 19:53:41 --> Language Class Initialized
ERROR - 2018-03-30 19:53:42 --> syntax error, unexpected ')', expecting ';'
ERROR - 2018-03-30 19:53:42 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ';' C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 19:54:28 --> Config Class Initialized
INFO - 2018-03-30 19:54:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:54:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:54:28 --> Utf8 Class Initialized
INFO - 2018-03-30 19:54:28 --> URI Class Initialized
INFO - 2018-03-30 19:54:28 --> Router Class Initialized
INFO - 2018-03-30 19:54:28 --> Output Class Initialized
INFO - 2018-03-30 19:54:28 --> Security Class Initialized
DEBUG - 2018-03-30 19:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:54:28 --> Input Class Initialized
INFO - 2018-03-30 19:54:28 --> Language Class Initialized
INFO - 2018-03-30 19:54:29 --> Loader Class Initialized
INFO - 2018-03-30 19:54:29 --> Helper loaded: common_helper
INFO - 2018-03-30 19:54:29 --> Database Driver Class Initialized
INFO - 2018-03-30 19:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:54:29 --> Email Class Initialized
INFO - 2018-03-30 19:54:29 --> Controller Class Initialized
INFO - 2018-03-30 19:54:29 --> Helper loaded: form_helper
INFO - 2018-03-30 19:54:29 --> Form Validation Class Initialized
INFO - 2018-03-30 19:54:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:54:29 --> Helper loaded: url_helper
INFO - 2018-03-30 19:54:29 --> Model Class Initialized
INFO - 2018-03-30 19:54:29 --> Model Class Initialized
INFO - 2018-03-30 19:54:29 --> Model Class Initialized
INFO - 2018-03-30 19:54:50 --> Config Class Initialized
INFO - 2018-03-30 19:54:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:54:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:54:50 --> Utf8 Class Initialized
INFO - 2018-03-30 19:54:50 --> URI Class Initialized
INFO - 2018-03-30 19:54:50 --> Router Class Initialized
INFO - 2018-03-30 19:54:50 --> Output Class Initialized
INFO - 2018-03-30 19:54:50 --> Security Class Initialized
DEBUG - 2018-03-30 19:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:54:50 --> Input Class Initialized
INFO - 2018-03-30 19:54:50 --> Language Class Initialized
INFO - 2018-03-30 19:54:50 --> Loader Class Initialized
INFO - 2018-03-30 19:54:50 --> Helper loaded: common_helper
INFO - 2018-03-30 19:54:50 --> Database Driver Class Initialized
INFO - 2018-03-30 19:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:54:50 --> Email Class Initialized
INFO - 2018-03-30 19:54:50 --> Controller Class Initialized
INFO - 2018-03-30 19:54:50 --> Helper loaded: form_helper
INFO - 2018-03-30 19:54:50 --> Form Validation Class Initialized
INFO - 2018-03-30 19:54:50 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:54:50 --> Helper loaded: url_helper
INFO - 2018-03-30 19:54:50 --> Model Class Initialized
INFO - 2018-03-30 19:54:50 --> Model Class Initialized
INFO - 2018-03-30 19:54:50 --> Model Class Initialized
ERROR - 2018-03-30 23:24:50 --> Undefined offset: 3
ERROR - 2018-03-30 23:24:50 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:24:50 --> Trying to get property of non-object
ERROR - 2018-03-30 23:24:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:56:03 --> Config Class Initialized
INFO - 2018-03-30 19:56:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:56:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:56:03 --> Utf8 Class Initialized
INFO - 2018-03-30 19:56:03 --> URI Class Initialized
INFO - 2018-03-30 19:56:03 --> Router Class Initialized
INFO - 2018-03-30 19:56:03 --> Output Class Initialized
INFO - 2018-03-30 19:56:03 --> Security Class Initialized
DEBUG - 2018-03-30 19:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:56:03 --> Input Class Initialized
INFO - 2018-03-30 19:56:03 --> Language Class Initialized
INFO - 2018-03-30 19:56:03 --> Loader Class Initialized
INFO - 2018-03-30 19:56:03 --> Helper loaded: common_helper
INFO - 2018-03-30 19:56:03 --> Database Driver Class Initialized
INFO - 2018-03-30 19:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:56:03 --> Email Class Initialized
INFO - 2018-03-30 19:56:03 --> Controller Class Initialized
INFO - 2018-03-30 19:56:03 --> Helper loaded: form_helper
INFO - 2018-03-30 19:56:03 --> Form Validation Class Initialized
INFO - 2018-03-30 19:56:03 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:56:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:56:03 --> Helper loaded: url_helper
INFO - 2018-03-30 19:56:03 --> Model Class Initialized
INFO - 2018-03-30 19:56:04 --> Model Class Initialized
INFO - 2018-03-30 19:56:04 --> Model Class Initialized
ERROR - 2018-03-30 23:26:04 --> Undefined offset: 3
ERROR - 2018-03-30 23:26:04 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:26:04 --> Trying to get property of non-object
ERROR - 2018-03-30 23:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:26:04 --> Final output sent to browser
DEBUG - 2018-03-30 23:26:04 --> Total execution time: 0.2470
INFO - 2018-03-30 19:56:04 --> Config Class Initialized
INFO - 2018-03-30 19:56:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:56:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:56:04 --> Utf8 Class Initialized
INFO - 2018-03-30 19:56:04 --> URI Class Initialized
INFO - 2018-03-30 19:56:04 --> Router Class Initialized
INFO - 2018-03-30 19:56:04 --> Output Class Initialized
INFO - 2018-03-30 19:56:04 --> Security Class Initialized
DEBUG - 2018-03-30 19:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:56:04 --> Input Class Initialized
INFO - 2018-03-30 19:56:04 --> Language Class Initialized
INFO - 2018-03-30 19:56:04 --> Loader Class Initialized
INFO - 2018-03-30 19:56:04 --> Helper loaded: common_helper
INFO - 2018-03-30 19:56:04 --> Database Driver Class Initialized
INFO - 2018-03-30 19:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:56:04 --> Email Class Initialized
INFO - 2018-03-30 19:56:04 --> Controller Class Initialized
INFO - 2018-03-30 19:56:04 --> Helper loaded: form_helper
INFO - 2018-03-30 19:56:04 --> Form Validation Class Initialized
INFO - 2018-03-30 19:56:04 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:56:04 --> Helper loaded: url_helper
INFO - 2018-03-30 19:56:04 --> Model Class Initialized
INFO - 2018-03-30 19:56:04 --> Model Class Initialized
INFO - 2018-03-30 19:56:04 --> Model Class Initialized
ERROR - 2018-03-30 23:26:04 --> Undefined offset: 3
ERROR - 2018-03-30 23:26:04 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:26:04 --> Trying to get property of non-object
ERROR - 2018-03-30 23:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:26:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:26:04 --> Final output sent to browser
DEBUG - 2018-03-30 23:26:04 --> Total execution time: 0.1750
INFO - 2018-03-30 19:56:24 --> Config Class Initialized
INFO - 2018-03-30 19:56:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:56:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:56:24 --> Utf8 Class Initialized
INFO - 2018-03-30 19:56:24 --> URI Class Initialized
INFO - 2018-03-30 19:56:24 --> Router Class Initialized
INFO - 2018-03-30 19:56:24 --> Output Class Initialized
INFO - 2018-03-30 19:56:24 --> Security Class Initialized
DEBUG - 2018-03-30 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:56:24 --> Input Class Initialized
INFO - 2018-03-30 19:56:24 --> Language Class Initialized
INFO - 2018-03-30 19:56:24 --> Loader Class Initialized
INFO - 2018-03-30 19:56:24 --> Helper loaded: common_helper
INFO - 2018-03-30 19:56:24 --> Database Driver Class Initialized
INFO - 2018-03-30 19:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:56:24 --> Email Class Initialized
INFO - 2018-03-30 19:56:24 --> Controller Class Initialized
INFO - 2018-03-30 19:56:24 --> Helper loaded: form_helper
INFO - 2018-03-30 19:56:24 --> Form Validation Class Initialized
INFO - 2018-03-30 19:56:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:56:24 --> Helper loaded: url_helper
INFO - 2018-03-30 19:56:24 --> Model Class Initialized
INFO - 2018-03-30 19:56:24 --> Model Class Initialized
INFO - 2018-03-30 19:56:24 --> Model Class Initialized
ERROR - 2018-03-30 23:26:24 --> Undefined offset: 3
ERROR - 2018-03-30 23:26:24 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:26:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:26:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 19:56:29 --> Config Class Initialized
INFO - 2018-03-30 19:56:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:56:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:56:29 --> Utf8 Class Initialized
INFO - 2018-03-30 19:56:29 --> URI Class Initialized
INFO - 2018-03-30 19:56:29 --> Router Class Initialized
INFO - 2018-03-30 19:56:29 --> Output Class Initialized
INFO - 2018-03-30 19:56:29 --> Security Class Initialized
DEBUG - 2018-03-30 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:56:29 --> Input Class Initialized
INFO - 2018-03-30 19:56:29 --> Language Class Initialized
INFO - 2018-03-30 19:56:29 --> Loader Class Initialized
INFO - 2018-03-30 19:56:29 --> Helper loaded: common_helper
INFO - 2018-03-30 19:56:29 --> Database Driver Class Initialized
INFO - 2018-03-30 19:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:56:29 --> Email Class Initialized
INFO - 2018-03-30 19:56:29 --> Controller Class Initialized
INFO - 2018-03-30 19:56:29 --> Helper loaded: form_helper
INFO - 2018-03-30 19:56:29 --> Form Validation Class Initialized
INFO - 2018-03-30 19:56:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:56:29 --> Helper loaded: url_helper
INFO - 2018-03-30 19:56:29 --> Model Class Initialized
INFO - 2018-03-30 19:56:29 --> Model Class Initialized
INFO - 2018-03-30 19:56:29 --> Model Class Initialized
ERROR - 2018-03-30 23:26:29 --> Undefined offset: 3
ERROR - 2018-03-30 23:26:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:26:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:26:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:26:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:26:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:26:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 19:57:00 --> Config Class Initialized
INFO - 2018-03-30 19:57:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:57:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:57:00 --> Utf8 Class Initialized
INFO - 2018-03-30 19:57:00 --> URI Class Initialized
INFO - 2018-03-30 19:57:00 --> Router Class Initialized
INFO - 2018-03-30 19:57:00 --> Output Class Initialized
INFO - 2018-03-30 19:57:00 --> Security Class Initialized
DEBUG - 2018-03-30 19:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:57:00 --> Input Class Initialized
INFO - 2018-03-30 19:57:00 --> Language Class Initialized
INFO - 2018-03-30 19:57:00 --> Loader Class Initialized
INFO - 2018-03-30 19:57:00 --> Helper loaded: common_helper
INFO - 2018-03-30 19:57:00 --> Database Driver Class Initialized
INFO - 2018-03-30 19:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:57:00 --> Email Class Initialized
INFO - 2018-03-30 19:57:00 --> Controller Class Initialized
INFO - 2018-03-30 19:57:00 --> Helper loaded: form_helper
INFO - 2018-03-30 19:57:00 --> Form Validation Class Initialized
INFO - 2018-03-30 19:57:00 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:57:00 --> Helper loaded: url_helper
INFO - 2018-03-30 19:57:00 --> Model Class Initialized
INFO - 2018-03-30 19:57:00 --> Model Class Initialized
INFO - 2018-03-30 19:57:00 --> Model Class Initialized
INFO - 2018-03-30 19:57:31 --> Config Class Initialized
INFO - 2018-03-30 19:57:31 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:57:31 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:57:31 --> Utf8 Class Initialized
INFO - 2018-03-30 19:57:31 --> URI Class Initialized
INFO - 2018-03-30 19:57:31 --> Router Class Initialized
INFO - 2018-03-30 19:57:31 --> Output Class Initialized
INFO - 2018-03-30 19:57:31 --> Security Class Initialized
DEBUG - 2018-03-30 19:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:57:31 --> Input Class Initialized
INFO - 2018-03-30 19:57:31 --> Language Class Initialized
INFO - 2018-03-30 19:57:31 --> Loader Class Initialized
INFO - 2018-03-30 19:57:31 --> Helper loaded: common_helper
INFO - 2018-03-30 19:57:31 --> Database Driver Class Initialized
INFO - 2018-03-30 19:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:57:31 --> Email Class Initialized
INFO - 2018-03-30 19:57:31 --> Controller Class Initialized
INFO - 2018-03-30 19:57:31 --> Helper loaded: form_helper
INFO - 2018-03-30 19:57:31 --> Form Validation Class Initialized
INFO - 2018-03-30 19:57:31 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:57:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:57:31 --> Helper loaded: url_helper
INFO - 2018-03-30 19:57:31 --> Model Class Initialized
INFO - 2018-03-30 19:57:31 --> Model Class Initialized
INFO - 2018-03-30 19:57:31 --> Model Class Initialized
INFO - 2018-03-30 19:57:52 --> Config Class Initialized
INFO - 2018-03-30 19:57:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:57:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:57:52 --> Utf8 Class Initialized
INFO - 2018-03-30 19:57:52 --> URI Class Initialized
INFO - 2018-03-30 19:57:52 --> Router Class Initialized
INFO - 2018-03-30 19:57:52 --> Output Class Initialized
INFO - 2018-03-30 19:57:52 --> Security Class Initialized
DEBUG - 2018-03-30 19:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:57:52 --> Input Class Initialized
INFO - 2018-03-30 19:57:52 --> Language Class Initialized
INFO - 2018-03-30 19:57:52 --> Loader Class Initialized
INFO - 2018-03-30 19:57:52 --> Helper loaded: common_helper
INFO - 2018-03-30 19:57:52 --> Database Driver Class Initialized
INFO - 2018-03-30 19:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:57:52 --> Email Class Initialized
INFO - 2018-03-30 19:57:52 --> Controller Class Initialized
INFO - 2018-03-30 19:57:52 --> Helper loaded: form_helper
INFO - 2018-03-30 19:57:52 --> Form Validation Class Initialized
INFO - 2018-03-30 19:57:52 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:57:52 --> Helper loaded: url_helper
INFO - 2018-03-30 19:57:52 --> Model Class Initialized
INFO - 2018-03-30 19:57:52 --> Model Class Initialized
INFO - 2018-03-30 19:57:52 --> Model Class Initialized
ERROR - 2018-03-30 23:27:52 --> Undefined offset: 3
ERROR - 2018-03-30 23:27:52 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:27:52 --> Trying to get property of non-object
ERROR - 2018-03-30 23:27:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:59:42 --> Config Class Initialized
INFO - 2018-03-30 19:59:42 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:42 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:42 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:42 --> URI Class Initialized
INFO - 2018-03-30 19:59:42 --> Router Class Initialized
INFO - 2018-03-30 19:59:42 --> Output Class Initialized
INFO - 2018-03-30 19:59:42 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:42 --> Input Class Initialized
INFO - 2018-03-30 19:59:42 --> Language Class Initialized
INFO - 2018-03-30 19:59:42 --> Loader Class Initialized
INFO - 2018-03-30 19:59:42 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:42 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:42 --> Email Class Initialized
INFO - 2018-03-30 19:59:42 --> Controller Class Initialized
INFO - 2018-03-30 19:59:42 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:42 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:42 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:42 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:42 --> Model Class Initialized
INFO - 2018-03-30 19:59:42 --> Model Class Initialized
INFO - 2018-03-30 19:59:42 --> Model Class Initialized
ERROR - 2018-03-30 23:29:42 --> Undefined offset: 2
ERROR - 2018-03-30 23:29:42 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:29:42 --> Trying to get property of non-object
ERROR - 2018-03-30 23:29:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:59:44 --> Config Class Initialized
INFO - 2018-03-30 19:59:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:44 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:44 --> URI Class Initialized
INFO - 2018-03-30 19:59:44 --> Router Class Initialized
INFO - 2018-03-30 19:59:44 --> Output Class Initialized
INFO - 2018-03-30 19:59:44 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:44 --> Input Class Initialized
INFO - 2018-03-30 19:59:44 --> Language Class Initialized
INFO - 2018-03-30 19:59:44 --> Loader Class Initialized
INFO - 2018-03-30 19:59:44 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:44 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:44 --> Email Class Initialized
INFO - 2018-03-30 19:59:44 --> Controller Class Initialized
INFO - 2018-03-30 19:59:44 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:44 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:44 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:44 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:44 --> Model Class Initialized
INFO - 2018-03-30 19:59:44 --> Model Class Initialized
INFO - 2018-03-30 19:59:44 --> Model Class Initialized
ERROR - 2018-03-30 23:29:44 --> Undefined offset: 2
ERROR - 2018-03-30 23:29:44 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:29:44 --> Trying to get property of non-object
ERROR - 2018-03-30 23:29:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:59:44 --> Config Class Initialized
INFO - 2018-03-30 19:59:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:44 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:44 --> URI Class Initialized
INFO - 2018-03-30 19:59:44 --> Router Class Initialized
INFO - 2018-03-30 19:59:44 --> Output Class Initialized
INFO - 2018-03-30 19:59:44 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:44 --> Input Class Initialized
INFO - 2018-03-30 19:59:44 --> Language Class Initialized
INFO - 2018-03-30 19:59:44 --> Loader Class Initialized
INFO - 2018-03-30 19:59:44 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:44 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:44 --> Email Class Initialized
INFO - 2018-03-30 19:59:44 --> Controller Class Initialized
INFO - 2018-03-30 19:59:44 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:44 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:44 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:44 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:44 --> Model Class Initialized
INFO - 2018-03-30 19:59:44 --> Model Class Initialized
INFO - 2018-03-30 19:59:44 --> Model Class Initialized
ERROR - 2018-03-30 23:29:44 --> Undefined offset: 2
ERROR - 2018-03-30 23:29:44 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:29:44 --> Trying to get property of non-object
ERROR - 2018-03-30 23:29:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:59:45 --> Config Class Initialized
INFO - 2018-03-30 19:59:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:45 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:45 --> URI Class Initialized
INFO - 2018-03-30 19:59:45 --> Router Class Initialized
INFO - 2018-03-30 19:59:45 --> Output Class Initialized
INFO - 2018-03-30 19:59:45 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:45 --> Input Class Initialized
INFO - 2018-03-30 19:59:45 --> Language Class Initialized
INFO - 2018-03-30 19:59:45 --> Loader Class Initialized
INFO - 2018-03-30 19:59:45 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:45 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:45 --> Email Class Initialized
INFO - 2018-03-30 19:59:45 --> Controller Class Initialized
INFO - 2018-03-30 19:59:45 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:45 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:45 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:45 --> Model Class Initialized
INFO - 2018-03-30 19:59:45 --> Model Class Initialized
INFO - 2018-03-30 19:59:45 --> Model Class Initialized
ERROR - 2018-03-30 23:29:45 --> Undefined offset: 2
ERROR - 2018-03-30 23:29:45 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:29:45 --> Trying to get property of non-object
ERROR - 2018-03-30 23:29:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:59:45 --> Config Class Initialized
INFO - 2018-03-30 19:59:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:45 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:45 --> URI Class Initialized
INFO - 2018-03-30 19:59:45 --> Router Class Initialized
INFO - 2018-03-30 19:59:45 --> Output Class Initialized
INFO - 2018-03-30 19:59:45 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:45 --> Input Class Initialized
INFO - 2018-03-30 19:59:45 --> Language Class Initialized
INFO - 2018-03-30 19:59:45 --> Loader Class Initialized
INFO - 2018-03-30 19:59:45 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:45 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:45 --> Email Class Initialized
INFO - 2018-03-30 19:59:45 --> Controller Class Initialized
INFO - 2018-03-30 19:59:45 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:45 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:45 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:45 --> Model Class Initialized
INFO - 2018-03-30 19:59:45 --> Model Class Initialized
INFO - 2018-03-30 19:59:45 --> Model Class Initialized
ERROR - 2018-03-30 23:29:45 --> Undefined offset: 2
ERROR - 2018-03-30 23:29:45 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:29:45 --> Trying to get property of non-object
ERROR - 2018-03-30 23:29:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 19:59:48 --> Config Class Initialized
INFO - 2018-03-30 19:59:48 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:48 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:48 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:48 --> URI Class Initialized
INFO - 2018-03-30 19:59:48 --> Router Class Initialized
INFO - 2018-03-30 19:59:48 --> Output Class Initialized
INFO - 2018-03-30 19:59:48 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:48 --> Input Class Initialized
INFO - 2018-03-30 19:59:48 --> Language Class Initialized
INFO - 2018-03-30 19:59:48 --> Loader Class Initialized
INFO - 2018-03-30 19:59:48 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:48 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:48 --> Email Class Initialized
INFO - 2018-03-30 19:59:48 --> Controller Class Initialized
INFO - 2018-03-30 19:59:48 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:48 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:48 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:48 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:48 --> Model Class Initialized
INFO - 2018-03-30 19:59:48 --> Model Class Initialized
INFO - 2018-03-30 19:59:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 19:59:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 19:59:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-30 19:59:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:59:48 --> Final output sent to browser
DEBUG - 2018-03-30 19:59:48 --> Total execution time: 0.1530
INFO - 2018-03-30 19:59:50 --> Config Class Initialized
INFO - 2018-03-30 19:59:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:50 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:50 --> URI Class Initialized
INFO - 2018-03-30 19:59:50 --> Router Class Initialized
INFO - 2018-03-30 19:59:50 --> Output Class Initialized
INFO - 2018-03-30 19:59:50 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:50 --> Input Class Initialized
INFO - 2018-03-30 19:59:50 --> Language Class Initialized
INFO - 2018-03-30 19:59:50 --> Loader Class Initialized
INFO - 2018-03-30 19:59:50 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:50 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:50 --> Email Class Initialized
INFO - 2018-03-30 19:59:50 --> Controller Class Initialized
INFO - 2018-03-30 19:59:50 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:50 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:50 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:50 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:50 --> Model Class Initialized
INFO - 2018-03-30 19:59:50 --> Model Class Initialized
INFO - 2018-03-30 19:59:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 19:59:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 19:59:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-30 19:59:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 19:59:50 --> Final output sent to browser
DEBUG - 2018-03-30 19:59:50 --> Total execution time: 0.1310
INFO - 2018-03-30 19:59:52 --> Config Class Initialized
INFO - 2018-03-30 19:59:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 19:59:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 19:59:52 --> Utf8 Class Initialized
INFO - 2018-03-30 19:59:52 --> URI Class Initialized
INFO - 2018-03-30 19:59:52 --> Router Class Initialized
INFO - 2018-03-30 19:59:52 --> Output Class Initialized
INFO - 2018-03-30 19:59:52 --> Security Class Initialized
DEBUG - 2018-03-30 19:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 19:59:52 --> Input Class Initialized
INFO - 2018-03-30 19:59:52 --> Language Class Initialized
INFO - 2018-03-30 19:59:52 --> Loader Class Initialized
INFO - 2018-03-30 19:59:52 --> Helper loaded: common_helper
INFO - 2018-03-30 19:59:52 --> Database Driver Class Initialized
INFO - 2018-03-30 19:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 19:59:52 --> Email Class Initialized
INFO - 2018-03-30 19:59:52 --> Controller Class Initialized
INFO - 2018-03-30 19:59:52 --> Helper loaded: form_helper
INFO - 2018-03-30 19:59:52 --> Form Validation Class Initialized
INFO - 2018-03-30 19:59:52 --> Helper loaded: email_helper
DEBUG - 2018-03-30 19:59:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 19:59:52 --> Helper loaded: url_helper
INFO - 2018-03-30 19:59:52 --> Model Class Initialized
INFO - 2018-03-30 19:59:52 --> Model Class Initialized
INFO - 2018-03-30 19:59:52 --> Model Class Initialized
ERROR - 2018-03-30 23:29:52 --> Undefined offset: 2
ERROR - 2018-03-30 23:29:52 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:29:52 --> Trying to get property of non-object
ERROR - 2018-03-30 23:29:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:00:14 --> Config Class Initialized
INFO - 2018-03-30 20:00:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:00:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:00:14 --> Utf8 Class Initialized
INFO - 2018-03-30 20:00:14 --> URI Class Initialized
INFO - 2018-03-30 20:00:14 --> Router Class Initialized
INFO - 2018-03-30 20:00:14 --> Output Class Initialized
INFO - 2018-03-30 20:00:14 --> Security Class Initialized
DEBUG - 2018-03-30 20:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:00:14 --> Input Class Initialized
INFO - 2018-03-30 20:00:14 --> Language Class Initialized
INFO - 2018-03-30 20:00:14 --> Loader Class Initialized
INFO - 2018-03-30 20:00:14 --> Helper loaded: common_helper
INFO - 2018-03-30 20:00:14 --> Database Driver Class Initialized
INFO - 2018-03-30 20:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:00:14 --> Email Class Initialized
INFO - 2018-03-30 20:00:14 --> Controller Class Initialized
INFO - 2018-03-30 20:00:14 --> Helper loaded: form_helper
INFO - 2018-03-30 20:00:14 --> Form Validation Class Initialized
INFO - 2018-03-30 20:00:14 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:00:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:00:14 --> Helper loaded: url_helper
INFO - 2018-03-30 20:00:14 --> Model Class Initialized
INFO - 2018-03-30 20:00:14 --> Model Class Initialized
INFO - 2018-03-30 20:00:14 --> Model Class Initialized
ERROR - 2018-03-30 23:30:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:30:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:30:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:30:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:00:16 --> Config Class Initialized
INFO - 2018-03-30 20:00:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:00:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:00:16 --> Utf8 Class Initialized
INFO - 2018-03-30 20:00:16 --> URI Class Initialized
INFO - 2018-03-30 20:00:16 --> Router Class Initialized
INFO - 2018-03-30 20:00:16 --> Output Class Initialized
INFO - 2018-03-30 20:00:16 --> Security Class Initialized
DEBUG - 2018-03-30 20:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:00:16 --> Input Class Initialized
INFO - 2018-03-30 20:00:16 --> Language Class Initialized
INFO - 2018-03-30 20:00:16 --> Loader Class Initialized
INFO - 2018-03-30 20:00:16 --> Helper loaded: common_helper
INFO - 2018-03-30 20:00:16 --> Database Driver Class Initialized
INFO - 2018-03-30 20:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:00:16 --> Email Class Initialized
INFO - 2018-03-30 20:00:16 --> Controller Class Initialized
INFO - 2018-03-30 20:00:16 --> Helper loaded: form_helper
INFO - 2018-03-30 20:00:16 --> Form Validation Class Initialized
INFO - 2018-03-30 20:00:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:00:16 --> Helper loaded: url_helper
INFO - 2018-03-30 20:00:16 --> Model Class Initialized
INFO - 2018-03-30 20:00:16 --> Model Class Initialized
INFO - 2018-03-30 20:00:16 --> Model Class Initialized
ERROR - 2018-03-30 23:30:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:30:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:30:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:00:16 --> Config Class Initialized
INFO - 2018-03-30 20:00:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:00:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:00:16 --> Utf8 Class Initialized
INFO - 2018-03-30 20:00:16 --> URI Class Initialized
INFO - 2018-03-30 20:00:16 --> Router Class Initialized
INFO - 2018-03-30 20:00:16 --> Output Class Initialized
INFO - 2018-03-30 20:00:16 --> Security Class Initialized
DEBUG - 2018-03-30 20:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:00:16 --> Input Class Initialized
INFO - 2018-03-30 20:00:16 --> Language Class Initialized
INFO - 2018-03-30 20:00:16 --> Loader Class Initialized
INFO - 2018-03-30 20:00:16 --> Helper loaded: common_helper
INFO - 2018-03-30 20:00:16 --> Database Driver Class Initialized
INFO - 2018-03-30 20:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:00:16 --> Email Class Initialized
INFO - 2018-03-30 20:00:16 --> Controller Class Initialized
INFO - 2018-03-30 20:00:16 --> Helper loaded: form_helper
INFO - 2018-03-30 20:00:16 --> Form Validation Class Initialized
INFO - 2018-03-30 20:00:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:00:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:00:16 --> Helper loaded: url_helper
INFO - 2018-03-30 20:00:16 --> Model Class Initialized
INFO - 2018-03-30 20:00:16 --> Model Class Initialized
INFO - 2018-03-30 20:00:16 --> Model Class Initialized
ERROR - 2018-03-30 23:30:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:30:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:30:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:30:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:00:17 --> Config Class Initialized
INFO - 2018-03-30 20:00:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:00:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:00:17 --> Utf8 Class Initialized
INFO - 2018-03-30 20:00:17 --> URI Class Initialized
INFO - 2018-03-30 20:00:17 --> Router Class Initialized
INFO - 2018-03-30 20:00:17 --> Output Class Initialized
INFO - 2018-03-30 20:00:17 --> Security Class Initialized
DEBUG - 2018-03-30 20:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:00:17 --> Input Class Initialized
INFO - 2018-03-30 20:00:17 --> Language Class Initialized
INFO - 2018-03-30 20:00:17 --> Loader Class Initialized
INFO - 2018-03-30 20:00:17 --> Helper loaded: common_helper
INFO - 2018-03-30 20:00:17 --> Database Driver Class Initialized
INFO - 2018-03-30 20:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:00:17 --> Email Class Initialized
INFO - 2018-03-30 20:00:17 --> Controller Class Initialized
INFO - 2018-03-30 20:00:17 --> Helper loaded: form_helper
INFO - 2018-03-30 20:00:17 --> Form Validation Class Initialized
INFO - 2018-03-30 20:00:17 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:00:17 --> Helper loaded: url_helper
INFO - 2018-03-30 20:00:17 --> Model Class Initialized
INFO - 2018-03-30 20:00:17 --> Model Class Initialized
INFO - 2018-03-30 20:00:17 --> Model Class Initialized
ERROR - 2018-03-30 23:30:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:30:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:30:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:00:17 --> Config Class Initialized
INFO - 2018-03-30 20:00:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:00:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:00:17 --> Utf8 Class Initialized
INFO - 2018-03-30 20:00:17 --> URI Class Initialized
INFO - 2018-03-30 20:00:17 --> Router Class Initialized
INFO - 2018-03-30 20:00:17 --> Output Class Initialized
INFO - 2018-03-30 20:00:17 --> Security Class Initialized
DEBUG - 2018-03-30 20:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:00:17 --> Input Class Initialized
INFO - 2018-03-30 20:00:17 --> Language Class Initialized
INFO - 2018-03-30 20:00:17 --> Loader Class Initialized
INFO - 2018-03-30 20:00:17 --> Helper loaded: common_helper
INFO - 2018-03-30 20:00:17 --> Database Driver Class Initialized
INFO - 2018-03-30 20:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:00:17 --> Email Class Initialized
INFO - 2018-03-30 20:00:17 --> Controller Class Initialized
INFO - 2018-03-30 20:00:17 --> Helper loaded: form_helper
INFO - 2018-03-30 20:00:17 --> Form Validation Class Initialized
INFO - 2018-03-30 20:00:17 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:00:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:00:17 --> Helper loaded: url_helper
INFO - 2018-03-30 20:00:17 --> Model Class Initialized
INFO - 2018-03-30 20:00:17 --> Model Class Initialized
INFO - 2018-03-30 20:00:17 --> Model Class Initialized
ERROR - 2018-03-30 23:30:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:30:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:30:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:00:45 --> Config Class Initialized
INFO - 2018-03-30 20:00:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:00:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:00:45 --> Utf8 Class Initialized
INFO - 2018-03-30 20:00:45 --> URI Class Initialized
INFO - 2018-03-30 20:00:45 --> Router Class Initialized
INFO - 2018-03-30 20:00:45 --> Output Class Initialized
INFO - 2018-03-30 20:00:45 --> Security Class Initialized
DEBUG - 2018-03-30 20:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:00:45 --> Input Class Initialized
INFO - 2018-03-30 20:00:45 --> Language Class Initialized
INFO - 2018-03-30 20:00:45 --> Loader Class Initialized
INFO - 2018-03-30 20:00:45 --> Helper loaded: common_helper
INFO - 2018-03-30 20:00:45 --> Database Driver Class Initialized
INFO - 2018-03-30 20:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:00:45 --> Email Class Initialized
INFO - 2018-03-30 20:00:45 --> Controller Class Initialized
INFO - 2018-03-30 20:00:45 --> Helper loaded: form_helper
INFO - 2018-03-30 20:00:45 --> Form Validation Class Initialized
INFO - 2018-03-30 20:00:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:00:45 --> Helper loaded: url_helper
INFO - 2018-03-30 20:00:45 --> Model Class Initialized
INFO - 2018-03-30 20:00:45 --> Model Class Initialized
INFO - 2018-03-30 20:00:45 --> Model Class Initialized
INFO - 2018-03-30 20:01:09 --> Config Class Initialized
INFO - 2018-03-30 20:01:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:01:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:01:09 --> Utf8 Class Initialized
INFO - 2018-03-30 20:01:09 --> URI Class Initialized
INFO - 2018-03-30 20:01:09 --> Router Class Initialized
INFO - 2018-03-30 20:01:09 --> Output Class Initialized
INFO - 2018-03-30 20:01:09 --> Security Class Initialized
DEBUG - 2018-03-30 20:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:01:09 --> Input Class Initialized
INFO - 2018-03-30 20:01:09 --> Language Class Initialized
INFO - 2018-03-30 20:01:09 --> Loader Class Initialized
INFO - 2018-03-30 20:01:09 --> Helper loaded: common_helper
INFO - 2018-03-30 20:01:09 --> Database Driver Class Initialized
INFO - 2018-03-30 20:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:01:09 --> Email Class Initialized
INFO - 2018-03-30 20:01:09 --> Controller Class Initialized
INFO - 2018-03-30 20:01:09 --> Helper loaded: form_helper
INFO - 2018-03-30 20:01:09 --> Form Validation Class Initialized
INFO - 2018-03-30 20:01:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:01:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:01:09 --> Helper loaded: url_helper
INFO - 2018-03-30 20:01:09 --> Model Class Initialized
INFO - 2018-03-30 20:01:09 --> Model Class Initialized
INFO - 2018-03-30 20:01:09 --> Model Class Initialized
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:09 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:10 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:11 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:12 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:14 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:15 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:16 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:18 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:19 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:20 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:21 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:22 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:23 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:24 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:25 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:26 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:27 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:28 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:30 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:31 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:32 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:33 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:34 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:35 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:36 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:37 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:01:38 --> Config Class Initialized
INFO - 2018-03-30 20:01:38 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:01:38 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:01:38 --> Utf8 Class Initialized
INFO - 2018-03-30 20:01:38 --> URI Class Initialized
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
INFO - 2018-03-30 20:01:38 --> Router Class Initialized
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:01:38 --> Output Class Initialized
INFO - 2018-03-30 20:01:38 --> Security Class Initialized
DEBUG - 2018-03-30 20:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:01:38 --> Input Class Initialized
INFO - 2018-03-30 20:01:38 --> Language Class Initialized
INFO - 2018-03-30 20:01:38 --> Loader Class Initialized
INFO - 2018-03-30 20:01:38 --> Helper loaded: common_helper
INFO - 2018-03-30 20:01:38 --> Database Driver Class Initialized
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:01:38 --> Email Class Initialized
INFO - 2018-03-30 20:01:38 --> Controller Class Initialized
INFO - 2018-03-30 20:01:38 --> Helper loaded: form_helper
INFO - 2018-03-30 20:01:38 --> Form Validation Class Initialized
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:01:38 --> Helper loaded: email_helper
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
DEBUG - 2018-03-30 20:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:01:38 --> Helper loaded: url_helper
INFO - 2018-03-30 20:01:38 --> Model Class Initialized
INFO - 2018-03-30 20:01:38 --> Model Class Initialized
INFO - 2018-03-30 20:01:38 --> Model Class Initialized
ERROR - 2018-03-30 23:31:38 --> Undefined variable: newstitle
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined variable: newstitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 46
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Undefined offset: 2
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:31:38 --> Trying to get property of non-object
ERROR - 2018-03-30 23:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:01:40 --> Config Class Initialized
INFO - 2018-03-30 20:01:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:01:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:01:40 --> Utf8 Class Initialized
INFO - 2018-03-30 20:01:40 --> URI Class Initialized
INFO - 2018-03-30 20:01:40 --> Router Class Initialized
INFO - 2018-03-30 20:01:40 --> Output Class Initialized
INFO - 2018-03-30 20:01:40 --> Security Class Initialized
DEBUG - 2018-03-30 20:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:01:40 --> Input Class Initialized
INFO - 2018-03-30 20:01:40 --> Language Class Initialized
INFO - 2018-03-30 20:01:40 --> Loader Class Initialized
INFO - 2018-03-30 20:01:40 --> Helper loaded: common_helper
INFO - 2018-03-30 20:01:40 --> Database Driver Class Initialized
INFO - 2018-03-30 20:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:01:41 --> Email Class Initialized
INFO - 2018-03-30 20:01:41 --> Controller Class Initialized
INFO - 2018-03-30 20:01:41 --> Helper loaded: form_helper
INFO - 2018-03-30 20:01:41 --> Form Validation Class Initialized
INFO - 2018-03-30 20:01:41 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:01:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:01:41 --> Helper loaded: url_helper
INFO - 2018-03-30 20:01:41 --> Model Class Initialized
INFO - 2018-03-30 20:01:41 --> Model Class Initialized
INFO - 2018-03-30 20:01:41 --> Model Class Initialized
ERROR - 2018-03-30 23:31:41 --> Undefined variable: newstitle
ERROR - 2018-03-30 23:31:41 --> Severity: Notice --> Undefined variable: newstitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 46
INFO - 2018-03-30 20:02:13 --> Config Class Initialized
INFO - 2018-03-30 20:02:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:13 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:13 --> URI Class Initialized
INFO - 2018-03-30 20:02:13 --> Router Class Initialized
INFO - 2018-03-30 20:02:13 --> Output Class Initialized
INFO - 2018-03-30 20:02:13 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:13 --> Input Class Initialized
INFO - 2018-03-30 20:02:13 --> Language Class Initialized
INFO - 2018-03-30 20:02:13 --> Loader Class Initialized
INFO - 2018-03-30 20:02:13 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:13 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:13 --> Email Class Initialized
INFO - 2018-03-30 20:02:13 --> Controller Class Initialized
INFO - 2018-03-30 20:02:13 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:13 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:13 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:13 --> Model Class Initialized
INFO - 2018-03-30 20:02:13 --> Model Class Initialized
INFO - 2018-03-30 20:02:13 --> Model Class Initialized
ERROR - 2018-03-30 23:32:13 --> Undefined variable: images
ERROR - 2018-03-30 23:32:13 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:15 --> Config Class Initialized
INFO - 2018-03-30 20:02:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:15 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:15 --> URI Class Initialized
INFO - 2018-03-30 20:02:15 --> Router Class Initialized
INFO - 2018-03-30 20:02:15 --> Output Class Initialized
INFO - 2018-03-30 20:02:15 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:15 --> Input Class Initialized
INFO - 2018-03-30 20:02:15 --> Language Class Initialized
INFO - 2018-03-30 20:02:15 --> Loader Class Initialized
INFO - 2018-03-30 20:02:15 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:15 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:15 --> Email Class Initialized
INFO - 2018-03-30 20:02:15 --> Controller Class Initialized
INFO - 2018-03-30 20:02:15 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:15 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:15 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:15 --> Model Class Initialized
INFO - 2018-03-30 20:02:15 --> Model Class Initialized
INFO - 2018-03-30 20:02:15 --> Model Class Initialized
ERROR - 2018-03-30 23:32:15 --> Undefined variable: images
ERROR - 2018-03-30 23:32:15 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:15 --> Config Class Initialized
INFO - 2018-03-30 20:02:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:15 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:15 --> URI Class Initialized
INFO - 2018-03-30 20:02:15 --> Router Class Initialized
INFO - 2018-03-30 20:02:15 --> Output Class Initialized
INFO - 2018-03-30 20:02:15 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:15 --> Input Class Initialized
INFO - 2018-03-30 20:02:15 --> Language Class Initialized
INFO - 2018-03-30 20:02:15 --> Loader Class Initialized
INFO - 2018-03-30 20:02:15 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:15 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:15 --> Email Class Initialized
INFO - 2018-03-30 20:02:15 --> Controller Class Initialized
INFO - 2018-03-30 20:02:15 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:15 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:15 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:15 --> Model Class Initialized
INFO - 2018-03-30 20:02:15 --> Model Class Initialized
INFO - 2018-03-30 20:02:15 --> Model Class Initialized
ERROR - 2018-03-30 23:32:15 --> Undefined variable: images
ERROR - 2018-03-30 23:32:15 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:16 --> Config Class Initialized
INFO - 2018-03-30 20:02:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:16 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:16 --> URI Class Initialized
INFO - 2018-03-30 20:02:16 --> Router Class Initialized
INFO - 2018-03-30 20:02:16 --> Output Class Initialized
INFO - 2018-03-30 20:02:16 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:16 --> Input Class Initialized
INFO - 2018-03-30 20:02:16 --> Language Class Initialized
INFO - 2018-03-30 20:02:16 --> Loader Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:16 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:16 --> Email Class Initialized
INFO - 2018-03-30 20:02:16 --> Controller Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:16 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:16 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
ERROR - 2018-03-30 23:32:16 --> Undefined variable: images
ERROR - 2018-03-30 23:32:16 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:16 --> Config Class Initialized
INFO - 2018-03-30 20:02:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:16 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:16 --> URI Class Initialized
INFO - 2018-03-30 20:02:16 --> Router Class Initialized
INFO - 2018-03-30 20:02:16 --> Output Class Initialized
INFO - 2018-03-30 20:02:16 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:16 --> Input Class Initialized
INFO - 2018-03-30 20:02:16 --> Language Class Initialized
INFO - 2018-03-30 20:02:16 --> Loader Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:16 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:16 --> Email Class Initialized
INFO - 2018-03-30 20:02:16 --> Controller Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:16 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:16 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
ERROR - 2018-03-30 23:32:16 --> Undefined variable: images
ERROR - 2018-03-30 23:32:16 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:16 --> Config Class Initialized
INFO - 2018-03-30 20:02:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:16 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:16 --> URI Class Initialized
INFO - 2018-03-30 20:02:16 --> Router Class Initialized
INFO - 2018-03-30 20:02:16 --> Output Class Initialized
INFO - 2018-03-30 20:02:16 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:16 --> Input Class Initialized
INFO - 2018-03-30 20:02:16 --> Language Class Initialized
INFO - 2018-03-30 20:02:16 --> Loader Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:16 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:16 --> Email Class Initialized
INFO - 2018-03-30 20:02:16 --> Controller Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:16 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:16 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
ERROR - 2018-03-30 23:32:16 --> Undefined variable: images
ERROR - 2018-03-30 23:32:16 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:16 --> Config Class Initialized
INFO - 2018-03-30 20:02:16 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:16 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:16 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:16 --> URI Class Initialized
INFO - 2018-03-30 20:02:16 --> Router Class Initialized
INFO - 2018-03-30 20:02:16 --> Output Class Initialized
INFO - 2018-03-30 20:02:16 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:16 --> Input Class Initialized
INFO - 2018-03-30 20:02:16 --> Language Class Initialized
INFO - 2018-03-30 20:02:16 --> Loader Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:16 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:16 --> Email Class Initialized
INFO - 2018-03-30 20:02:16 --> Controller Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:16 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:16 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:16 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
INFO - 2018-03-30 20:02:16 --> Model Class Initialized
ERROR - 2018-03-30 23:32:16 --> Undefined variable: images
ERROR - 2018-03-30 23:32:16 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 48
INFO - 2018-03-30 20:02:50 --> Config Class Initialized
INFO - 2018-03-30 20:02:50 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:02:50 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:02:50 --> Utf8 Class Initialized
INFO - 2018-03-30 20:02:50 --> URI Class Initialized
INFO - 2018-03-30 20:02:50 --> Router Class Initialized
INFO - 2018-03-30 20:02:50 --> Output Class Initialized
INFO - 2018-03-30 20:02:50 --> Security Class Initialized
DEBUG - 2018-03-30 20:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:02:50 --> Input Class Initialized
INFO - 2018-03-30 20:02:50 --> Language Class Initialized
INFO - 2018-03-30 20:02:50 --> Loader Class Initialized
INFO - 2018-03-30 20:02:50 --> Helper loaded: common_helper
INFO - 2018-03-30 20:02:50 --> Database Driver Class Initialized
INFO - 2018-03-30 20:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:02:50 --> Email Class Initialized
INFO - 2018-03-30 20:02:50 --> Controller Class Initialized
INFO - 2018-03-30 20:02:50 --> Helper loaded: form_helper
INFO - 2018-03-30 20:02:50 --> Form Validation Class Initialized
INFO - 2018-03-30 20:02:50 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:02:50 --> Helper loaded: url_helper
INFO - 2018-03-30 20:02:50 --> Model Class Initialized
INFO - 2018-03-30 20:02:50 --> Model Class Initialized
INFO - 2018-03-30 20:02:50 --> Model Class Initialized
ERROR - 2018-03-30 23:32:50 --> Undefined offset: 2
ERROR - 2018-03-30 23:32:50 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:32:50 --> Trying to get property of non-object
ERROR - 2018-03-30 23:32:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:03:29 --> Config Class Initialized
INFO - 2018-03-30 20:03:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:03:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:03:29 --> Utf8 Class Initialized
INFO - 2018-03-30 20:03:29 --> URI Class Initialized
INFO - 2018-03-30 20:03:29 --> Router Class Initialized
INFO - 2018-03-30 20:03:29 --> Output Class Initialized
INFO - 2018-03-30 20:03:29 --> Security Class Initialized
DEBUG - 2018-03-30 20:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:03:29 --> Input Class Initialized
INFO - 2018-03-30 20:03:29 --> Language Class Initialized
INFO - 2018-03-30 20:03:29 --> Loader Class Initialized
INFO - 2018-03-30 20:03:29 --> Helper loaded: common_helper
INFO - 2018-03-30 20:03:29 --> Database Driver Class Initialized
INFO - 2018-03-30 20:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:03:29 --> Email Class Initialized
INFO - 2018-03-30 20:03:29 --> Controller Class Initialized
INFO - 2018-03-30 20:03:29 --> Helper loaded: form_helper
INFO - 2018-03-30 20:03:29 --> Form Validation Class Initialized
INFO - 2018-03-30 20:03:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:03:29 --> Helper loaded: url_helper
INFO - 2018-03-30 20:03:29 --> Model Class Initialized
INFO - 2018-03-30 20:03:29 --> Model Class Initialized
INFO - 2018-03-30 20:03:29 --> Model Class Initialized
ERROR - 2018-03-30 23:33:29 --> Undefined offset: 2
ERROR - 2018-03-30 23:33:29 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:33:29 --> Trying to get property of non-object
ERROR - 2018-03-30 23:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:03:52 --> Config Class Initialized
INFO - 2018-03-30 20:03:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:03:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:03:52 --> Utf8 Class Initialized
INFO - 2018-03-30 20:03:52 --> URI Class Initialized
INFO - 2018-03-30 20:03:52 --> Router Class Initialized
INFO - 2018-03-30 20:03:52 --> Output Class Initialized
INFO - 2018-03-30 20:03:52 --> Security Class Initialized
DEBUG - 2018-03-30 20:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:03:52 --> Input Class Initialized
INFO - 2018-03-30 20:03:52 --> Language Class Initialized
INFO - 2018-03-30 20:03:52 --> Loader Class Initialized
INFO - 2018-03-30 20:03:52 --> Helper loaded: common_helper
INFO - 2018-03-30 20:03:52 --> Database Driver Class Initialized
INFO - 2018-03-30 20:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:03:52 --> Email Class Initialized
INFO - 2018-03-30 20:03:52 --> Controller Class Initialized
INFO - 2018-03-30 20:03:52 --> Helper loaded: form_helper
INFO - 2018-03-30 20:03:52 --> Form Validation Class Initialized
INFO - 2018-03-30 20:03:52 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:03:52 --> Helper loaded: url_helper
INFO - 2018-03-30 20:03:52 --> Model Class Initialized
INFO - 2018-03-30 20:03:52 --> Model Class Initialized
INFO - 2018-03-30 20:03:52 --> Model Class Initialized
ERROR - 2018-03-30 23:33:52 --> Undefined offset: 2
ERROR - 2018-03-30 23:33:52 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:33:52 --> Trying to get property of non-object
ERROR - 2018-03-30 23:33:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:33:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:33:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:33:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 20:04:07 --> Config Class Initialized
INFO - 2018-03-30 20:04:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:04:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:04:07 --> Utf8 Class Initialized
INFO - 2018-03-30 20:04:07 --> URI Class Initialized
INFO - 2018-03-30 20:04:07 --> Router Class Initialized
INFO - 2018-03-30 20:04:07 --> Output Class Initialized
INFO - 2018-03-30 20:04:07 --> Security Class Initialized
DEBUG - 2018-03-30 20:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:04:07 --> Input Class Initialized
INFO - 2018-03-30 20:04:07 --> Language Class Initialized
INFO - 2018-03-30 20:04:07 --> Loader Class Initialized
INFO - 2018-03-30 20:04:07 --> Helper loaded: common_helper
INFO - 2018-03-30 20:04:07 --> Database Driver Class Initialized
INFO - 2018-03-30 20:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:04:07 --> Email Class Initialized
INFO - 2018-03-30 20:04:07 --> Controller Class Initialized
INFO - 2018-03-30 20:04:07 --> Helper loaded: form_helper
INFO - 2018-03-30 20:04:07 --> Form Validation Class Initialized
INFO - 2018-03-30 20:04:07 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:04:07 --> Helper loaded: url_helper
INFO - 2018-03-30 20:04:07 --> Model Class Initialized
INFO - 2018-03-30 20:04:07 --> Model Class Initialized
INFO - 2018-03-30 20:04:07 --> Model Class Initialized
ERROR - 2018-03-30 23:34:07 --> Undefined offset: 2
ERROR - 2018-03-30 23:34:07 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:34:07 --> Trying to get property of non-object
ERROR - 2018-03-30 23:34:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:34:07 --> Final output sent to browser
DEBUG - 2018-03-30 23:34:07 --> Total execution time: 0.2220
INFO - 2018-03-30 20:04:07 --> Config Class Initialized
INFO - 2018-03-30 20:04:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:04:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:04:07 --> Utf8 Class Initialized
INFO - 2018-03-30 20:04:07 --> URI Class Initialized
INFO - 2018-03-30 20:04:07 --> Router Class Initialized
INFO - 2018-03-30 20:04:07 --> Output Class Initialized
INFO - 2018-03-30 20:04:07 --> Security Class Initialized
DEBUG - 2018-03-30 20:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:04:07 --> Input Class Initialized
INFO - 2018-03-30 20:04:07 --> Language Class Initialized
INFO - 2018-03-30 20:04:07 --> Loader Class Initialized
INFO - 2018-03-30 20:04:07 --> Helper loaded: common_helper
INFO - 2018-03-30 20:04:07 --> Database Driver Class Initialized
INFO - 2018-03-30 20:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:04:07 --> Email Class Initialized
INFO - 2018-03-30 20:04:07 --> Controller Class Initialized
INFO - 2018-03-30 20:04:07 --> Helper loaded: form_helper
INFO - 2018-03-30 20:04:07 --> Form Validation Class Initialized
INFO - 2018-03-30 20:04:07 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:04:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:04:07 --> Helper loaded: url_helper
INFO - 2018-03-30 20:04:07 --> Model Class Initialized
INFO - 2018-03-30 20:04:07 --> Model Class Initialized
INFO - 2018-03-30 20:04:07 --> Model Class Initialized
ERROR - 2018-03-30 23:34:07 --> Undefined offset: 2
ERROR - 2018-03-30 23:34:07 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:34:07 --> Trying to get property of non-object
ERROR - 2018-03-30 23:34:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:34:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:34:07 --> Final output sent to browser
DEBUG - 2018-03-30 23:34:07 --> Total execution time: 0.1560
INFO - 2018-03-30 20:04:34 --> Config Class Initialized
INFO - 2018-03-30 20:04:34 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:04:34 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:04:34 --> Utf8 Class Initialized
INFO - 2018-03-30 20:04:34 --> URI Class Initialized
INFO - 2018-03-30 20:04:34 --> Router Class Initialized
INFO - 2018-03-30 20:04:34 --> Output Class Initialized
INFO - 2018-03-30 20:04:34 --> Security Class Initialized
DEBUG - 2018-03-30 20:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:04:34 --> Input Class Initialized
INFO - 2018-03-30 20:04:34 --> Language Class Initialized
INFO - 2018-03-30 20:04:34 --> Loader Class Initialized
INFO - 2018-03-30 20:04:34 --> Helper loaded: common_helper
INFO - 2018-03-30 20:04:34 --> Database Driver Class Initialized
INFO - 2018-03-30 20:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:04:34 --> Email Class Initialized
INFO - 2018-03-30 20:04:34 --> Controller Class Initialized
INFO - 2018-03-30 20:04:34 --> Helper loaded: form_helper
INFO - 2018-03-30 20:04:34 --> Form Validation Class Initialized
INFO - 2018-03-30 20:04:34 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:04:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:04:34 --> Helper loaded: url_helper
INFO - 2018-03-30 20:04:34 --> Model Class Initialized
INFO - 2018-03-30 20:04:34 --> Model Class Initialized
INFO - 2018-03-30 20:04:34 --> Model Class Initialized
INFO - 2018-03-30 20:04:39 --> Config Class Initialized
INFO - 2018-03-30 20:04:39 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:04:39 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:04:39 --> Utf8 Class Initialized
INFO - 2018-03-30 20:04:39 --> URI Class Initialized
INFO - 2018-03-30 20:04:39 --> Router Class Initialized
INFO - 2018-03-30 20:04:39 --> Output Class Initialized
INFO - 2018-03-30 20:04:39 --> Security Class Initialized
DEBUG - 2018-03-30 20:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:04:39 --> Input Class Initialized
INFO - 2018-03-30 20:04:39 --> Language Class Initialized
INFO - 2018-03-30 20:04:39 --> Loader Class Initialized
INFO - 2018-03-30 20:04:39 --> Helper loaded: common_helper
INFO - 2018-03-30 20:04:39 --> Database Driver Class Initialized
INFO - 2018-03-30 20:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:04:39 --> Email Class Initialized
INFO - 2018-03-30 20:04:39 --> Controller Class Initialized
INFO - 2018-03-30 20:04:39 --> Helper loaded: form_helper
INFO - 2018-03-30 20:04:39 --> Form Validation Class Initialized
INFO - 2018-03-30 20:04:39 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:04:39 --> Helper loaded: url_helper
INFO - 2018-03-30 20:04:39 --> Model Class Initialized
INFO - 2018-03-30 20:04:39 --> Model Class Initialized
INFO - 2018-03-30 20:04:39 --> Model Class Initialized
INFO - 2018-03-30 20:06:48 --> Config Class Initialized
INFO - 2018-03-30 20:06:48 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:06:48 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:06:48 --> Utf8 Class Initialized
INFO - 2018-03-30 20:06:48 --> URI Class Initialized
INFO - 2018-03-30 20:06:48 --> Router Class Initialized
INFO - 2018-03-30 20:06:48 --> Output Class Initialized
INFO - 2018-03-30 20:06:48 --> Security Class Initialized
DEBUG - 2018-03-30 20:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:06:48 --> Input Class Initialized
INFO - 2018-03-30 20:06:48 --> Language Class Initialized
INFO - 2018-03-30 20:06:48 --> Loader Class Initialized
INFO - 2018-03-30 20:06:48 --> Helper loaded: common_helper
INFO - 2018-03-30 20:06:48 --> Database Driver Class Initialized
INFO - 2018-03-30 20:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:06:48 --> Email Class Initialized
INFO - 2018-03-30 20:06:48 --> Controller Class Initialized
INFO - 2018-03-30 20:06:48 --> Helper loaded: form_helper
INFO - 2018-03-30 20:06:48 --> Form Validation Class Initialized
INFO - 2018-03-30 20:06:48 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:06:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:06:48 --> Helper loaded: url_helper
INFO - 2018-03-30 20:06:48 --> Model Class Initialized
INFO - 2018-03-30 20:06:48 --> Model Class Initialized
INFO - 2018-03-30 20:06:48 --> Model Class Initialized
INFO - 2018-03-30 20:06:59 --> Config Class Initialized
INFO - 2018-03-30 20:06:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:06:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:06:59 --> Utf8 Class Initialized
INFO - 2018-03-30 20:06:59 --> URI Class Initialized
INFO - 2018-03-30 20:06:59 --> Router Class Initialized
INFO - 2018-03-30 20:06:59 --> Output Class Initialized
INFO - 2018-03-30 20:06:59 --> Security Class Initialized
DEBUG - 2018-03-30 20:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:06:59 --> Input Class Initialized
INFO - 2018-03-30 20:06:59 --> Language Class Initialized
INFO - 2018-03-30 20:06:59 --> Loader Class Initialized
INFO - 2018-03-30 20:06:59 --> Helper loaded: common_helper
INFO - 2018-03-30 20:06:59 --> Database Driver Class Initialized
INFO - 2018-03-30 20:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:06:59 --> Email Class Initialized
INFO - 2018-03-30 20:06:59 --> Controller Class Initialized
INFO - 2018-03-30 20:06:59 --> Helper loaded: form_helper
INFO - 2018-03-30 20:06:59 --> Form Validation Class Initialized
INFO - 2018-03-30 20:06:59 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:06:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:06:59 --> Helper loaded: url_helper
INFO - 2018-03-30 20:06:59 --> Model Class Initialized
INFO - 2018-03-30 20:06:59 --> Model Class Initialized
INFO - 2018-03-30 20:06:59 --> Model Class Initialized
INFO - 2018-03-30 23:36:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:36:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:36:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:36:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:36:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:36:59 --> Final output sent to browser
DEBUG - 2018-03-30 23:36:59 --> Total execution time: 0.1320
INFO - 2018-03-30 20:07:57 --> Config Class Initialized
INFO - 2018-03-30 20:07:57 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:07:57 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:07:57 --> Utf8 Class Initialized
INFO - 2018-03-30 20:07:57 --> URI Class Initialized
INFO - 2018-03-30 20:07:57 --> Router Class Initialized
INFO - 2018-03-30 20:07:57 --> Output Class Initialized
INFO - 2018-03-30 20:07:58 --> Security Class Initialized
DEBUG - 2018-03-30 20:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:07:58 --> Input Class Initialized
INFO - 2018-03-30 20:07:58 --> Language Class Initialized
INFO - 2018-03-30 20:07:58 --> Loader Class Initialized
INFO - 2018-03-30 20:07:58 --> Helper loaded: common_helper
INFO - 2018-03-30 20:07:58 --> Database Driver Class Initialized
INFO - 2018-03-30 20:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:07:58 --> Email Class Initialized
INFO - 2018-03-30 20:07:58 --> Controller Class Initialized
INFO - 2018-03-30 20:07:58 --> Helper loaded: form_helper
INFO - 2018-03-30 20:07:58 --> Form Validation Class Initialized
INFO - 2018-03-30 20:07:58 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:07:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:07:58 --> Helper loaded: url_helper
INFO - 2018-03-30 20:07:58 --> Model Class Initialized
INFO - 2018-03-30 20:07:58 --> Model Class Initialized
INFO - 2018-03-30 20:07:58 --> Model Class Initialized
INFO - 2018-03-30 23:37:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:37:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:37:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:37:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:37:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:37:58 --> Final output sent to browser
DEBUG - 2018-03-30 23:37:58 --> Total execution time: 0.1450
INFO - 2018-03-30 20:08:15 --> Config Class Initialized
INFO - 2018-03-30 20:08:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:08:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:08:15 --> Utf8 Class Initialized
INFO - 2018-03-30 20:08:15 --> URI Class Initialized
INFO - 2018-03-30 20:08:15 --> Router Class Initialized
INFO - 2018-03-30 20:08:15 --> Output Class Initialized
INFO - 2018-03-30 20:08:15 --> Security Class Initialized
DEBUG - 2018-03-30 20:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:08:15 --> Input Class Initialized
INFO - 2018-03-30 20:08:15 --> Language Class Initialized
INFO - 2018-03-30 20:08:15 --> Loader Class Initialized
INFO - 2018-03-30 20:08:15 --> Helper loaded: common_helper
INFO - 2018-03-30 20:08:15 --> Database Driver Class Initialized
INFO - 2018-03-30 20:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:08:15 --> Email Class Initialized
INFO - 2018-03-30 20:08:15 --> Controller Class Initialized
INFO - 2018-03-30 20:08:15 --> Helper loaded: form_helper
INFO - 2018-03-30 20:08:15 --> Form Validation Class Initialized
INFO - 2018-03-30 20:08:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:08:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:08:15 --> Helper loaded: url_helper
INFO - 2018-03-30 20:08:15 --> Model Class Initialized
INFO - 2018-03-30 20:08:15 --> Model Class Initialized
INFO - 2018-03-30 20:08:15 --> Model Class Initialized
INFO - 2018-03-30 23:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 20:08:40 --> Config Class Initialized
INFO - 2018-03-30 20:08:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:08:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:08:40 --> Utf8 Class Initialized
INFO - 2018-03-30 20:08:40 --> URI Class Initialized
INFO - 2018-03-30 20:08:40 --> Router Class Initialized
INFO - 2018-03-30 20:08:40 --> Output Class Initialized
INFO - 2018-03-30 20:08:40 --> Security Class Initialized
DEBUG - 2018-03-30 20:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:08:40 --> Input Class Initialized
INFO - 2018-03-30 20:08:40 --> Language Class Initialized
INFO - 2018-03-30 20:08:40 --> Loader Class Initialized
INFO - 2018-03-30 20:08:40 --> Helper loaded: common_helper
INFO - 2018-03-30 20:08:40 --> Database Driver Class Initialized
INFO - 2018-03-30 20:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:08:40 --> Email Class Initialized
INFO - 2018-03-30 20:08:40 --> Controller Class Initialized
INFO - 2018-03-30 20:08:40 --> Helper loaded: form_helper
INFO - 2018-03-30 20:08:40 --> Form Validation Class Initialized
INFO - 2018-03-30 20:08:40 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:08:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:08:40 --> Helper loaded: url_helper
INFO - 2018-03-30 20:08:40 --> Model Class Initialized
INFO - 2018-03-30 20:08:40 --> Model Class Initialized
INFO - 2018-03-30 20:08:40 --> Model Class Initialized
INFO - 2018-03-30 23:38:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:38:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:38:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 20:08:51 --> Config Class Initialized
INFO - 2018-03-30 20:08:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:08:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:08:51 --> Utf8 Class Initialized
INFO - 2018-03-30 20:08:51 --> URI Class Initialized
INFO - 2018-03-30 20:08:51 --> Router Class Initialized
INFO - 2018-03-30 20:08:51 --> Output Class Initialized
INFO - 2018-03-30 20:08:51 --> Security Class Initialized
DEBUG - 2018-03-30 20:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:08:51 --> Input Class Initialized
INFO - 2018-03-30 20:08:51 --> Language Class Initialized
INFO - 2018-03-30 20:08:51 --> Loader Class Initialized
INFO - 2018-03-30 20:08:51 --> Helper loaded: common_helper
INFO - 2018-03-30 20:08:51 --> Database Driver Class Initialized
INFO - 2018-03-30 20:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:08:51 --> Email Class Initialized
INFO - 2018-03-30 20:08:51 --> Controller Class Initialized
INFO - 2018-03-30 20:08:51 --> Helper loaded: form_helper
INFO - 2018-03-30 20:08:51 --> Form Validation Class Initialized
INFO - 2018-03-30 20:08:51 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:08:51 --> Helper loaded: url_helper
INFO - 2018-03-30 20:08:51 --> Model Class Initialized
INFO - 2018-03-30 20:08:51 --> Model Class Initialized
INFO - 2018-03-30 20:08:51 --> Model Class Initialized
INFO - 2018-03-30 23:38:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:38:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:38:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:38:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:38:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:38:51 --> Final output sent to browser
DEBUG - 2018-03-30 23:38:51 --> Total execution time: 0.1290
INFO - 2018-03-30 20:09:13 --> Config Class Initialized
INFO - 2018-03-30 20:09:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:09:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:09:13 --> Utf8 Class Initialized
INFO - 2018-03-30 20:09:13 --> URI Class Initialized
INFO - 2018-03-30 20:09:13 --> Router Class Initialized
INFO - 2018-03-30 20:09:13 --> Output Class Initialized
INFO - 2018-03-30 20:09:13 --> Security Class Initialized
DEBUG - 2018-03-30 20:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:09:13 --> Input Class Initialized
INFO - 2018-03-30 20:09:13 --> Language Class Initialized
INFO - 2018-03-30 20:09:13 --> Loader Class Initialized
INFO - 2018-03-30 20:09:13 --> Helper loaded: common_helper
INFO - 2018-03-30 20:09:13 --> Database Driver Class Initialized
INFO - 2018-03-30 20:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:09:14 --> Email Class Initialized
INFO - 2018-03-30 20:09:14 --> Controller Class Initialized
INFO - 2018-03-30 20:09:14 --> Helper loaded: form_helper
INFO - 2018-03-30 20:09:14 --> Form Validation Class Initialized
INFO - 2018-03-30 20:09:14 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:09:14 --> Helper loaded: url_helper
INFO - 2018-03-30 20:09:14 --> Model Class Initialized
INFO - 2018-03-30 20:09:14 --> Model Class Initialized
INFO - 2018-03-30 20:09:14 --> Model Class Initialized
INFO - 2018-03-30 23:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:39:14 --> Final output sent to browser
DEBUG - 2018-03-30 23:39:14 --> Total execution time: 0.1320
INFO - 2018-03-30 20:11:26 --> Config Class Initialized
INFO - 2018-03-30 20:11:26 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:11:26 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:11:26 --> Utf8 Class Initialized
INFO - 2018-03-30 20:11:26 --> URI Class Initialized
INFO - 2018-03-30 20:11:26 --> Router Class Initialized
INFO - 2018-03-30 20:11:26 --> Output Class Initialized
INFO - 2018-03-30 20:11:26 --> Security Class Initialized
DEBUG - 2018-03-30 20:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:11:26 --> Input Class Initialized
INFO - 2018-03-30 20:11:26 --> Language Class Initialized
INFO - 2018-03-30 20:11:26 --> Loader Class Initialized
INFO - 2018-03-30 20:11:26 --> Helper loaded: common_helper
INFO - 2018-03-30 20:11:26 --> Database Driver Class Initialized
INFO - 2018-03-30 20:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:11:26 --> Email Class Initialized
INFO - 2018-03-30 20:11:26 --> Controller Class Initialized
INFO - 2018-03-30 20:11:26 --> Helper loaded: form_helper
INFO - 2018-03-30 20:11:26 --> Form Validation Class Initialized
INFO - 2018-03-30 20:11:26 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:11:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:11:26 --> Helper loaded: url_helper
INFO - 2018-03-30 20:11:26 --> Model Class Initialized
INFO - 2018-03-30 20:11:26 --> Model Class Initialized
INFO - 2018-03-30 20:11:26 --> Model Class Initialized
ERROR - 2018-03-30 23:41:26 --> Array to string conversion
ERROR - 2018-03-30 23:41:26 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 26
INFO - 2018-03-30 20:14:20 --> Config Class Initialized
INFO - 2018-03-30 20:14:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:14:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:14:20 --> Utf8 Class Initialized
INFO - 2018-03-30 20:14:20 --> URI Class Initialized
INFO - 2018-03-30 20:14:20 --> Router Class Initialized
INFO - 2018-03-30 20:14:20 --> Output Class Initialized
INFO - 2018-03-30 20:14:20 --> Security Class Initialized
DEBUG - 2018-03-30 20:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:14:20 --> Input Class Initialized
INFO - 2018-03-30 20:14:20 --> Language Class Initialized
INFO - 2018-03-30 20:14:20 --> Loader Class Initialized
INFO - 2018-03-30 20:14:20 --> Helper loaded: common_helper
INFO - 2018-03-30 20:14:20 --> Database Driver Class Initialized
INFO - 2018-03-30 20:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:14:20 --> Email Class Initialized
INFO - 2018-03-30 20:14:20 --> Controller Class Initialized
INFO - 2018-03-30 20:14:20 --> Helper loaded: form_helper
INFO - 2018-03-30 20:14:20 --> Form Validation Class Initialized
INFO - 2018-03-30 20:14:20 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:14:20 --> Helper loaded: url_helper
INFO - 2018-03-30 20:14:20 --> Model Class Initialized
INFO - 2018-03-30 20:14:20 --> Model Class Initialized
INFO - 2018-03-30 20:14:20 --> Model Class Initialized
ERROR - 2018-03-30 23:44:20 --> Array to string conversion
ERROR - 2018-03-30 23:44:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 26
INFO - 2018-03-30 20:14:22 --> Config Class Initialized
INFO - 2018-03-30 20:14:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:14:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:14:22 --> Utf8 Class Initialized
INFO - 2018-03-30 20:14:22 --> URI Class Initialized
INFO - 2018-03-30 20:14:22 --> Router Class Initialized
INFO - 2018-03-30 20:14:22 --> Output Class Initialized
INFO - 2018-03-30 20:14:22 --> Security Class Initialized
DEBUG - 2018-03-30 20:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:14:22 --> Input Class Initialized
INFO - 2018-03-30 20:14:22 --> Language Class Initialized
INFO - 2018-03-30 20:14:22 --> Loader Class Initialized
INFO - 2018-03-30 20:14:22 --> Helper loaded: common_helper
INFO - 2018-03-30 20:14:22 --> Database Driver Class Initialized
INFO - 2018-03-30 20:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:14:22 --> Email Class Initialized
INFO - 2018-03-30 20:14:22 --> Controller Class Initialized
INFO - 2018-03-30 20:14:22 --> Helper loaded: form_helper
INFO - 2018-03-30 20:14:22 --> Form Validation Class Initialized
INFO - 2018-03-30 20:14:22 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:14:22 --> Helper loaded: url_helper
INFO - 2018-03-30 20:14:22 --> Model Class Initialized
INFO - 2018-03-30 20:14:22 --> Model Class Initialized
INFO - 2018-03-30 20:14:22 --> Model Class Initialized
ERROR - 2018-03-30 23:44:22 --> Array to string conversion
ERROR - 2018-03-30 23:44:22 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 26
INFO - 2018-03-30 20:14:42 --> Config Class Initialized
INFO - 2018-03-30 20:14:42 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:14:42 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:14:42 --> Utf8 Class Initialized
INFO - 2018-03-30 20:14:42 --> URI Class Initialized
INFO - 2018-03-30 20:14:42 --> Router Class Initialized
INFO - 2018-03-30 20:14:42 --> Output Class Initialized
INFO - 2018-03-30 20:14:42 --> Security Class Initialized
DEBUG - 2018-03-30 20:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:14:42 --> Input Class Initialized
INFO - 2018-03-30 20:14:42 --> Language Class Initialized
INFO - 2018-03-30 20:14:42 --> Loader Class Initialized
INFO - 2018-03-30 20:14:42 --> Helper loaded: common_helper
INFO - 2018-03-30 20:14:42 --> Database Driver Class Initialized
INFO - 2018-03-30 20:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:14:42 --> Email Class Initialized
INFO - 2018-03-30 20:14:42 --> Controller Class Initialized
INFO - 2018-03-30 20:14:42 --> Helper loaded: form_helper
INFO - 2018-03-30 20:14:42 --> Form Validation Class Initialized
INFO - 2018-03-30 20:14:42 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:14:42 --> Helper loaded: url_helper
INFO - 2018-03-30 20:14:42 --> Model Class Initialized
INFO - 2018-03-30 20:14:42 --> Model Class Initialized
INFO - 2018-03-30 20:14:42 --> Model Class Initialized
ERROR - 2018-03-30 23:45:12 --> Maximum execution time of 30 seconds exceeded
ERROR - 2018-03-30 23:45:12 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 37
INFO - 2018-03-30 20:15:17 --> Config Class Initialized
INFO - 2018-03-30 20:15:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:15:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:15:17 --> Utf8 Class Initialized
INFO - 2018-03-30 20:15:17 --> URI Class Initialized
INFO - 2018-03-30 20:15:17 --> Router Class Initialized
INFO - 2018-03-30 20:15:17 --> Output Class Initialized
INFO - 2018-03-30 20:15:17 --> Security Class Initialized
DEBUG - 2018-03-30 20:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:15:17 --> Input Class Initialized
INFO - 2018-03-30 20:15:17 --> Language Class Initialized
INFO - 2018-03-30 20:15:17 --> Loader Class Initialized
INFO - 2018-03-30 20:15:17 --> Helper loaded: common_helper
INFO - 2018-03-30 20:15:17 --> Database Driver Class Initialized
INFO - 2018-03-30 20:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:15:17 --> Email Class Initialized
INFO - 2018-03-30 20:15:17 --> Controller Class Initialized
INFO - 2018-03-30 20:15:17 --> Helper loaded: form_helper
INFO - 2018-03-30 20:15:17 --> Form Validation Class Initialized
INFO - 2018-03-30 20:15:17 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:15:17 --> Helper loaded: url_helper
INFO - 2018-03-30 20:15:17 --> Model Class Initialized
INFO - 2018-03-30 20:15:17 --> Model Class Initialized
INFO - 2018-03-30 20:15:17 --> Model Class Initialized
ERROR - 2018-03-30 23:45:47 --> Maximum execution time of 30 seconds exceeded
ERROR - 2018-03-30 23:45:47 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 37
INFO - 2018-03-30 20:15:56 --> Config Class Initialized
INFO - 2018-03-30 20:15:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:15:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:15:56 --> Utf8 Class Initialized
INFO - 2018-03-30 20:15:56 --> URI Class Initialized
INFO - 2018-03-30 20:15:56 --> Router Class Initialized
INFO - 2018-03-30 20:15:56 --> Output Class Initialized
INFO - 2018-03-30 20:15:56 --> Security Class Initialized
DEBUG - 2018-03-30 20:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:15:56 --> Input Class Initialized
INFO - 2018-03-30 20:15:56 --> Language Class Initialized
INFO - 2018-03-30 20:15:56 --> Loader Class Initialized
INFO - 2018-03-30 20:15:56 --> Helper loaded: common_helper
INFO - 2018-03-30 20:15:56 --> Database Driver Class Initialized
INFO - 2018-03-30 20:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:15:56 --> Email Class Initialized
INFO - 2018-03-30 20:15:56 --> Controller Class Initialized
INFO - 2018-03-30 20:15:56 --> Helper loaded: form_helper
INFO - 2018-03-30 20:15:56 --> Form Validation Class Initialized
INFO - 2018-03-30 20:15:56 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:15:56 --> Helper loaded: url_helper
INFO - 2018-03-30 20:15:56 --> Model Class Initialized
INFO - 2018-03-30 20:15:56 --> Model Class Initialized
INFO - 2018-03-30 20:15:56 --> Model Class Initialized
INFO - 2018-03-30 20:16:17 --> Config Class Initialized
INFO - 2018-03-30 20:16:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:16:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:16:17 --> Utf8 Class Initialized
INFO - 2018-03-30 20:16:17 --> URI Class Initialized
INFO - 2018-03-30 20:16:17 --> Router Class Initialized
INFO - 2018-03-30 20:16:17 --> Output Class Initialized
INFO - 2018-03-30 20:16:17 --> Security Class Initialized
DEBUG - 2018-03-30 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:16:17 --> Input Class Initialized
INFO - 2018-03-30 20:16:17 --> Language Class Initialized
INFO - 2018-03-30 20:16:18 --> Loader Class Initialized
INFO - 2018-03-30 20:16:18 --> Helper loaded: common_helper
INFO - 2018-03-30 20:16:18 --> Database Driver Class Initialized
INFO - 2018-03-30 20:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:16:18 --> Email Class Initialized
INFO - 2018-03-30 20:16:18 --> Controller Class Initialized
INFO - 2018-03-30 20:16:18 --> Helper loaded: form_helper
INFO - 2018-03-30 20:16:18 --> Form Validation Class Initialized
INFO - 2018-03-30 20:16:18 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:16:18 --> Helper loaded: url_helper
INFO - 2018-03-30 20:16:18 --> Model Class Initialized
INFO - 2018-03-30 20:16:18 --> Model Class Initialized
INFO - 2018-03-30 20:16:18 --> Model Class Initialized
ERROR - 2018-03-30 23:46:47 --> Maximum execution time of 30 seconds exceeded
ERROR - 2018-03-30 23:46:47 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 37
INFO - 2018-03-30 20:17:09 --> Config Class Initialized
INFO - 2018-03-30 20:17:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:17:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:17:09 --> Utf8 Class Initialized
INFO - 2018-03-30 20:17:09 --> URI Class Initialized
INFO - 2018-03-30 20:17:09 --> Router Class Initialized
INFO - 2018-03-30 20:17:09 --> Output Class Initialized
INFO - 2018-03-30 20:17:09 --> Security Class Initialized
DEBUG - 2018-03-30 20:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:17:09 --> Input Class Initialized
INFO - 2018-03-30 20:17:09 --> Language Class Initialized
INFO - 2018-03-30 20:17:09 --> Loader Class Initialized
INFO - 2018-03-30 20:17:09 --> Helper loaded: common_helper
INFO - 2018-03-30 20:17:09 --> Database Driver Class Initialized
INFO - 2018-03-30 20:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:17:09 --> Email Class Initialized
INFO - 2018-03-30 20:17:09 --> Controller Class Initialized
INFO - 2018-03-30 20:17:09 --> Helper loaded: form_helper
INFO - 2018-03-30 20:17:09 --> Form Validation Class Initialized
INFO - 2018-03-30 20:17:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:17:09 --> Helper loaded: url_helper
INFO - 2018-03-30 20:17:09 --> Model Class Initialized
INFO - 2018-03-30 20:17:09 --> Model Class Initialized
INFO - 2018-03-30 20:17:09 --> Model Class Initialized
ERROR - 2018-03-30 23:47:39 --> Maximum execution time of 30 seconds exceeded
ERROR - 2018-03-30 23:47:39 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 37
INFO - 2018-03-30 20:18:09 --> Config Class Initialized
INFO - 2018-03-30 20:18:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:18:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:18:09 --> Utf8 Class Initialized
INFO - 2018-03-30 20:18:09 --> URI Class Initialized
INFO - 2018-03-30 20:18:09 --> Router Class Initialized
INFO - 2018-03-30 20:18:09 --> Output Class Initialized
INFO - 2018-03-30 20:18:09 --> Security Class Initialized
DEBUG - 2018-03-30 20:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:18:09 --> Input Class Initialized
INFO - 2018-03-30 20:18:09 --> Language Class Initialized
ERROR - 2018-03-30 20:18:09 --> syntax error, unexpected ';', expecting ')'
ERROR - 2018-03-30 20:18:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 28
INFO - 2018-03-30 20:18:45 --> Config Class Initialized
INFO - 2018-03-30 20:18:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:18:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:18:45 --> Utf8 Class Initialized
INFO - 2018-03-30 20:18:45 --> URI Class Initialized
INFO - 2018-03-30 20:18:45 --> Router Class Initialized
INFO - 2018-03-30 20:18:45 --> Output Class Initialized
INFO - 2018-03-30 20:18:45 --> Security Class Initialized
DEBUG - 2018-03-30 20:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:18:45 --> Input Class Initialized
INFO - 2018-03-30 20:18:45 --> Language Class Initialized
INFO - 2018-03-30 20:18:45 --> Loader Class Initialized
INFO - 2018-03-30 20:18:45 --> Helper loaded: common_helper
INFO - 2018-03-30 20:18:45 --> Database Driver Class Initialized
INFO - 2018-03-30 20:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:18:45 --> Email Class Initialized
INFO - 2018-03-30 20:18:45 --> Controller Class Initialized
INFO - 2018-03-30 20:18:45 --> Helper loaded: form_helper
INFO - 2018-03-30 20:18:45 --> Form Validation Class Initialized
INFO - 2018-03-30 20:18:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:18:45 --> Helper loaded: url_helper
INFO - 2018-03-30 20:18:45 --> Model Class Initialized
INFO - 2018-03-30 20:18:45 --> Model Class Initialized
INFO - 2018-03-30 20:18:45 --> Model Class Initialized
INFO - 2018-03-30 20:19:23 --> Config Class Initialized
INFO - 2018-03-30 20:19:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:19:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:19:23 --> Utf8 Class Initialized
INFO - 2018-03-30 20:19:23 --> URI Class Initialized
INFO - 2018-03-30 20:19:23 --> Router Class Initialized
INFO - 2018-03-30 20:19:23 --> Output Class Initialized
INFO - 2018-03-30 20:19:23 --> Security Class Initialized
DEBUG - 2018-03-30 20:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:19:23 --> Input Class Initialized
INFO - 2018-03-30 20:19:23 --> Language Class Initialized
INFO - 2018-03-30 20:19:23 --> Loader Class Initialized
INFO - 2018-03-30 20:19:23 --> Helper loaded: common_helper
INFO - 2018-03-30 20:19:23 --> Database Driver Class Initialized
INFO - 2018-03-30 20:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:19:23 --> Email Class Initialized
INFO - 2018-03-30 20:19:23 --> Controller Class Initialized
INFO - 2018-03-30 20:19:23 --> Helper loaded: form_helper
INFO - 2018-03-30 20:19:23 --> Form Validation Class Initialized
INFO - 2018-03-30 20:19:23 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:19:23 --> Helper loaded: url_helper
INFO - 2018-03-30 20:19:23 --> Model Class Initialized
INFO - 2018-03-30 20:19:23 --> Model Class Initialized
INFO - 2018-03-30 20:19:23 --> Model Class Initialized
INFO - 2018-03-30 20:19:24 --> Config Class Initialized
INFO - 2018-03-30 20:19:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:19:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:19:24 --> Utf8 Class Initialized
INFO - 2018-03-30 20:19:24 --> URI Class Initialized
INFO - 2018-03-30 20:19:24 --> Router Class Initialized
INFO - 2018-03-30 20:19:24 --> Output Class Initialized
INFO - 2018-03-30 20:19:24 --> Security Class Initialized
DEBUG - 2018-03-30 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:19:24 --> Input Class Initialized
INFO - 2018-03-30 20:19:24 --> Language Class Initialized
INFO - 2018-03-30 20:19:24 --> Loader Class Initialized
INFO - 2018-03-30 20:19:24 --> Helper loaded: common_helper
INFO - 2018-03-30 20:19:24 --> Database Driver Class Initialized
INFO - 2018-03-30 20:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:19:24 --> Email Class Initialized
INFO - 2018-03-30 20:19:24 --> Controller Class Initialized
INFO - 2018-03-30 20:19:24 --> Helper loaded: form_helper
INFO - 2018-03-30 20:19:24 --> Form Validation Class Initialized
INFO - 2018-03-30 20:19:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:19:24 --> Helper loaded: url_helper
INFO - 2018-03-30 20:19:24 --> Model Class Initialized
INFO - 2018-03-30 20:19:24 --> Model Class Initialized
INFO - 2018-03-30 20:19:24 --> Model Class Initialized
INFO - 2018-03-30 20:19:24 --> Config Class Initialized
INFO - 2018-03-30 20:19:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:19:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:19:24 --> Utf8 Class Initialized
INFO - 2018-03-30 20:19:24 --> URI Class Initialized
INFO - 2018-03-30 20:19:24 --> Router Class Initialized
INFO - 2018-03-30 20:19:24 --> Output Class Initialized
INFO - 2018-03-30 20:19:24 --> Security Class Initialized
DEBUG - 2018-03-30 20:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:19:24 --> Input Class Initialized
INFO - 2018-03-30 20:19:24 --> Language Class Initialized
INFO - 2018-03-30 20:19:24 --> Loader Class Initialized
INFO - 2018-03-30 20:19:24 --> Helper loaded: common_helper
INFO - 2018-03-30 20:19:24 --> Database Driver Class Initialized
INFO - 2018-03-30 20:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:19:24 --> Email Class Initialized
INFO - 2018-03-30 20:19:24 --> Controller Class Initialized
INFO - 2018-03-30 20:19:24 --> Helper loaded: form_helper
INFO - 2018-03-30 20:19:24 --> Form Validation Class Initialized
INFO - 2018-03-30 20:19:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:19:24 --> Helper loaded: url_helper
INFO - 2018-03-30 20:19:24 --> Model Class Initialized
INFO - 2018-03-30 20:19:24 --> Model Class Initialized
INFO - 2018-03-30 20:19:24 --> Model Class Initialized
INFO - 2018-03-30 20:19:25 --> Config Class Initialized
INFO - 2018-03-30 20:19:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:19:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:19:25 --> Utf8 Class Initialized
INFO - 2018-03-30 20:19:25 --> URI Class Initialized
INFO - 2018-03-30 20:19:25 --> Router Class Initialized
INFO - 2018-03-30 20:19:25 --> Output Class Initialized
INFO - 2018-03-30 20:19:25 --> Security Class Initialized
DEBUG - 2018-03-30 20:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:19:25 --> Input Class Initialized
INFO - 2018-03-30 20:19:25 --> Language Class Initialized
INFO - 2018-03-30 20:19:25 --> Loader Class Initialized
INFO - 2018-03-30 20:19:25 --> Helper loaded: common_helper
INFO - 2018-03-30 20:19:25 --> Database Driver Class Initialized
INFO - 2018-03-30 20:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:19:25 --> Email Class Initialized
INFO - 2018-03-30 20:19:25 --> Controller Class Initialized
INFO - 2018-03-30 20:19:25 --> Helper loaded: form_helper
INFO - 2018-03-30 20:19:25 --> Form Validation Class Initialized
INFO - 2018-03-30 20:19:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:19:25 --> Helper loaded: url_helper
INFO - 2018-03-30 20:19:25 --> Model Class Initialized
INFO - 2018-03-30 20:19:25 --> Model Class Initialized
INFO - 2018-03-30 20:19:25 --> Model Class Initialized
INFO - 2018-03-30 20:19:25 --> Config Class Initialized
INFO - 2018-03-30 20:19:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:19:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:19:25 --> Utf8 Class Initialized
INFO - 2018-03-30 20:19:25 --> URI Class Initialized
INFO - 2018-03-30 20:19:25 --> Router Class Initialized
INFO - 2018-03-30 20:19:25 --> Output Class Initialized
INFO - 2018-03-30 20:19:25 --> Security Class Initialized
DEBUG - 2018-03-30 20:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:19:25 --> Input Class Initialized
INFO - 2018-03-30 20:19:25 --> Language Class Initialized
INFO - 2018-03-30 20:19:25 --> Loader Class Initialized
INFO - 2018-03-30 20:19:25 --> Helper loaded: common_helper
INFO - 2018-03-30 20:19:25 --> Database Driver Class Initialized
INFO - 2018-03-30 20:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:19:25 --> Email Class Initialized
INFO - 2018-03-30 20:19:25 --> Controller Class Initialized
INFO - 2018-03-30 20:19:25 --> Helper loaded: form_helper
INFO - 2018-03-30 20:19:25 --> Form Validation Class Initialized
INFO - 2018-03-30 20:19:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:19:25 --> Helper loaded: url_helper
INFO - 2018-03-30 20:19:25 --> Model Class Initialized
INFO - 2018-03-30 20:19:25 --> Model Class Initialized
INFO - 2018-03-30 20:19:25 --> Model Class Initialized
INFO - 2018-03-30 20:19:42 --> Config Class Initialized
INFO - 2018-03-30 20:19:42 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:19:42 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:19:42 --> Utf8 Class Initialized
INFO - 2018-03-30 20:19:42 --> URI Class Initialized
INFO - 2018-03-30 20:19:42 --> Router Class Initialized
INFO - 2018-03-30 20:19:42 --> Output Class Initialized
INFO - 2018-03-30 20:19:42 --> Security Class Initialized
DEBUG - 2018-03-30 20:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:19:42 --> Input Class Initialized
INFO - 2018-03-30 20:19:42 --> Language Class Initialized
INFO - 2018-03-30 20:19:42 --> Loader Class Initialized
INFO - 2018-03-30 20:19:42 --> Helper loaded: common_helper
INFO - 2018-03-30 20:19:42 --> Database Driver Class Initialized
INFO - 2018-03-30 20:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:19:42 --> Email Class Initialized
INFO - 2018-03-30 20:19:42 --> Controller Class Initialized
INFO - 2018-03-30 20:19:42 --> Helper loaded: form_helper
INFO - 2018-03-30 20:19:42 --> Form Validation Class Initialized
INFO - 2018-03-30 20:19:42 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:19:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:19:42 --> Helper loaded: url_helper
INFO - 2018-03-30 20:19:42 --> Model Class Initialized
INFO - 2018-03-30 20:19:42 --> Model Class Initialized
INFO - 2018-03-30 20:19:42 --> Model Class Initialized
ERROR - 2018-03-30 23:50:12 --> Maximum execution time of 30 seconds exceeded
ERROR - 2018-03-30 23:50:12 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 37
INFO - 2018-03-30 20:21:17 --> Config Class Initialized
INFO - 2018-03-30 20:21:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:21:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:21:17 --> Utf8 Class Initialized
INFO - 2018-03-30 20:21:17 --> URI Class Initialized
INFO - 2018-03-30 20:21:17 --> Router Class Initialized
INFO - 2018-03-30 20:21:17 --> Output Class Initialized
INFO - 2018-03-30 20:21:17 --> Security Class Initialized
DEBUG - 2018-03-30 20:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:21:17 --> Input Class Initialized
INFO - 2018-03-30 20:21:17 --> Language Class Initialized
INFO - 2018-03-30 20:21:17 --> Loader Class Initialized
INFO - 2018-03-30 20:21:17 --> Helper loaded: common_helper
INFO - 2018-03-30 20:21:17 --> Database Driver Class Initialized
INFO - 2018-03-30 20:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:21:17 --> Email Class Initialized
INFO - 2018-03-30 20:21:17 --> Controller Class Initialized
INFO - 2018-03-30 20:21:17 --> Helper loaded: form_helper
INFO - 2018-03-30 20:21:17 --> Form Validation Class Initialized
INFO - 2018-03-30 20:21:17 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:21:17 --> Helper loaded: url_helper
INFO - 2018-03-30 20:21:17 --> Model Class Initialized
INFO - 2018-03-30 20:21:17 --> Model Class Initialized
INFO - 2018-03-30 20:21:17 --> Model Class Initialized
ERROR - 2018-03-30 23:51:17 --> Undefined offset: 3
ERROR - 2018-03-30 23:51:17 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 32
ERROR - 2018-03-30 23:51:17 --> Trying to get property of non-object
ERROR - 2018-03-30 23:51:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 32
INFO - 2018-03-30 20:22:55 --> Config Class Initialized
INFO - 2018-03-30 20:22:55 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:22:55 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:22:55 --> Utf8 Class Initialized
INFO - 2018-03-30 20:22:55 --> URI Class Initialized
INFO - 2018-03-30 20:22:55 --> Router Class Initialized
INFO - 2018-03-30 20:22:55 --> Output Class Initialized
INFO - 2018-03-30 20:22:55 --> Security Class Initialized
DEBUG - 2018-03-30 20:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:22:55 --> Input Class Initialized
INFO - 2018-03-30 20:22:55 --> Language Class Initialized
INFO - 2018-03-30 20:22:55 --> Loader Class Initialized
INFO - 2018-03-30 20:22:55 --> Helper loaded: common_helper
INFO - 2018-03-30 20:22:55 --> Database Driver Class Initialized
INFO - 2018-03-30 20:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:22:55 --> Email Class Initialized
INFO - 2018-03-30 20:22:55 --> Controller Class Initialized
INFO - 2018-03-30 20:22:55 --> Helper loaded: form_helper
INFO - 2018-03-30 20:22:55 --> Form Validation Class Initialized
INFO - 2018-03-30 20:22:55 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:22:55 --> Helper loaded: url_helper
INFO - 2018-03-30 20:22:55 --> Model Class Initialized
INFO - 2018-03-30 20:22:55 --> Model Class Initialized
INFO - 2018-03-30 20:22:55 --> Model Class Initialized
INFO - 2018-03-30 20:23:13 --> Config Class Initialized
INFO - 2018-03-30 20:23:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:23:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:23:13 --> Utf8 Class Initialized
INFO - 2018-03-30 20:23:13 --> URI Class Initialized
INFO - 2018-03-30 20:23:13 --> Router Class Initialized
INFO - 2018-03-30 20:23:13 --> Output Class Initialized
INFO - 2018-03-30 20:23:13 --> Security Class Initialized
DEBUG - 2018-03-30 20:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:23:13 --> Input Class Initialized
INFO - 2018-03-30 20:23:13 --> Language Class Initialized
INFO - 2018-03-30 20:23:13 --> Loader Class Initialized
INFO - 2018-03-30 20:23:13 --> Helper loaded: common_helper
INFO - 2018-03-30 20:23:13 --> Database Driver Class Initialized
INFO - 2018-03-30 20:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:23:13 --> Email Class Initialized
INFO - 2018-03-30 20:23:13 --> Controller Class Initialized
INFO - 2018-03-30 20:23:13 --> Helper loaded: form_helper
INFO - 2018-03-30 20:23:13 --> Form Validation Class Initialized
INFO - 2018-03-30 20:23:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:23:13 --> Helper loaded: url_helper
INFO - 2018-03-30 20:23:13 --> Model Class Initialized
INFO - 2018-03-30 20:23:13 --> Model Class Initialized
INFO - 2018-03-30 20:23:13 --> Model Class Initialized
ERROR - 2018-03-30 23:53:13 --> Undefined offset: 2
ERROR - 2018-03-30 23:53:13 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
ERROR - 2018-03-30 23:53:13 --> Trying to get property of non-object
ERROR - 2018-03-30 23:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 29
INFO - 2018-03-30 20:24:14 --> Config Class Initialized
INFO - 2018-03-30 20:24:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:24:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:24:14 --> Utf8 Class Initialized
INFO - 2018-03-30 20:24:14 --> URI Class Initialized
INFO - 2018-03-30 20:24:14 --> Router Class Initialized
INFO - 2018-03-30 20:24:14 --> Output Class Initialized
INFO - 2018-03-30 20:24:14 --> Security Class Initialized
DEBUG - 2018-03-30 20:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:24:14 --> Input Class Initialized
INFO - 2018-03-30 20:24:14 --> Language Class Initialized
INFO - 2018-03-30 20:24:14 --> Loader Class Initialized
INFO - 2018-03-30 20:24:14 --> Helper loaded: common_helper
INFO - 2018-03-30 20:24:14 --> Database Driver Class Initialized
INFO - 2018-03-30 20:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:24:15 --> Email Class Initialized
INFO - 2018-03-30 20:24:15 --> Controller Class Initialized
INFO - 2018-03-30 20:24:15 --> Helper loaded: form_helper
INFO - 2018-03-30 20:24:15 --> Form Validation Class Initialized
INFO - 2018-03-30 20:24:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:24:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:24:15 --> Helper loaded: url_helper
INFO - 2018-03-30 20:24:15 --> Model Class Initialized
INFO - 2018-03-30 20:24:15 --> Model Class Initialized
INFO - 2018-03-30 20:24:15 --> Model Class Initialized
INFO - 2018-03-30 20:24:30 --> Config Class Initialized
INFO - 2018-03-30 20:24:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:24:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:24:30 --> Utf8 Class Initialized
INFO - 2018-03-30 20:24:30 --> URI Class Initialized
INFO - 2018-03-30 20:24:30 --> Router Class Initialized
INFO - 2018-03-30 20:24:30 --> Output Class Initialized
INFO - 2018-03-30 20:24:30 --> Security Class Initialized
DEBUG - 2018-03-30 20:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:24:30 --> Input Class Initialized
INFO - 2018-03-30 20:24:30 --> Language Class Initialized
INFO - 2018-03-30 20:24:30 --> Loader Class Initialized
INFO - 2018-03-30 20:24:30 --> Helper loaded: common_helper
INFO - 2018-03-30 20:24:30 --> Database Driver Class Initialized
INFO - 2018-03-30 20:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:24:30 --> Email Class Initialized
INFO - 2018-03-30 20:24:30 --> Controller Class Initialized
INFO - 2018-03-30 20:24:30 --> Helper loaded: form_helper
INFO - 2018-03-30 20:24:30 --> Form Validation Class Initialized
INFO - 2018-03-30 20:24:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:24:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:24:30 --> Helper loaded: url_helper
INFO - 2018-03-30 20:24:30 --> Model Class Initialized
INFO - 2018-03-30 20:24:30 --> Model Class Initialized
INFO - 2018-03-30 20:24:30 --> Model Class Initialized
INFO - 2018-03-30 20:25:03 --> Config Class Initialized
INFO - 2018-03-30 20:25:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:25:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:25:03 --> Utf8 Class Initialized
INFO - 2018-03-30 20:25:03 --> URI Class Initialized
INFO - 2018-03-30 20:25:03 --> Router Class Initialized
INFO - 2018-03-30 20:25:03 --> Output Class Initialized
INFO - 2018-03-30 20:25:03 --> Security Class Initialized
DEBUG - 2018-03-30 20:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:25:03 --> Input Class Initialized
INFO - 2018-03-30 20:25:03 --> Language Class Initialized
INFO - 2018-03-30 20:25:03 --> Loader Class Initialized
INFO - 2018-03-30 20:25:03 --> Helper loaded: common_helper
INFO - 2018-03-30 20:25:03 --> Database Driver Class Initialized
INFO - 2018-03-30 20:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:25:03 --> Email Class Initialized
INFO - 2018-03-30 20:25:03 --> Controller Class Initialized
INFO - 2018-03-30 20:25:03 --> Helper loaded: form_helper
INFO - 2018-03-30 20:25:03 --> Form Validation Class Initialized
INFO - 2018-03-30 20:25:03 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:25:03 --> Helper loaded: url_helper
INFO - 2018-03-30 20:25:03 --> Model Class Initialized
INFO - 2018-03-30 20:25:03 --> Model Class Initialized
INFO - 2018-03-30 20:25:03 --> Model Class Initialized
INFO - 2018-03-30 23:55:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:55:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:55:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:55:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:55:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:55:03 --> Final output sent to browser
DEBUG - 2018-03-30 23:55:03 --> Total execution time: 0.1350
INFO - 2018-03-30 20:25:59 --> Config Class Initialized
INFO - 2018-03-30 20:25:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:25:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:25:59 --> Utf8 Class Initialized
INFO - 2018-03-30 20:25:59 --> URI Class Initialized
INFO - 2018-03-30 20:25:59 --> Router Class Initialized
INFO - 2018-03-30 20:25:59 --> Output Class Initialized
INFO - 2018-03-30 20:25:59 --> Security Class Initialized
DEBUG - 2018-03-30 20:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:25:59 --> Input Class Initialized
INFO - 2018-03-30 20:25:59 --> Language Class Initialized
INFO - 2018-03-30 20:25:59 --> Loader Class Initialized
INFO - 2018-03-30 20:25:59 --> Helper loaded: common_helper
INFO - 2018-03-30 20:25:59 --> Database Driver Class Initialized
INFO - 2018-03-30 20:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:25:59 --> Email Class Initialized
INFO - 2018-03-30 20:25:59 --> Controller Class Initialized
INFO - 2018-03-30 20:25:59 --> Helper loaded: form_helper
INFO - 2018-03-30 20:25:59 --> Form Validation Class Initialized
INFO - 2018-03-30 20:25:59 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:25:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:25:59 --> Helper loaded: url_helper
INFO - 2018-03-30 20:25:59 --> Model Class Initialized
INFO - 2018-03-30 20:25:59 --> Model Class Initialized
INFO - 2018-03-30 20:25:59 --> Model Class Initialized
INFO - 2018-03-30 23:55:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:55:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:55:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:55:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:55:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:55:59 --> Final output sent to browser
DEBUG - 2018-03-30 23:55:59 --> Total execution time: 0.1460
INFO - 2018-03-30 20:26:02 --> Config Class Initialized
INFO - 2018-03-30 20:26:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:26:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:26:02 --> Utf8 Class Initialized
INFO - 2018-03-30 20:26:02 --> URI Class Initialized
INFO - 2018-03-30 20:26:02 --> Router Class Initialized
INFO - 2018-03-30 20:26:02 --> Output Class Initialized
INFO - 2018-03-30 20:26:02 --> Security Class Initialized
DEBUG - 2018-03-30 20:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:26:02 --> Input Class Initialized
INFO - 2018-03-30 20:26:02 --> Language Class Initialized
INFO - 2018-03-30 20:26:02 --> Loader Class Initialized
INFO - 2018-03-30 20:26:02 --> Helper loaded: common_helper
INFO - 2018-03-30 20:26:03 --> Database Driver Class Initialized
INFO - 2018-03-30 20:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:26:03 --> Email Class Initialized
INFO - 2018-03-30 20:26:03 --> Controller Class Initialized
INFO - 2018-03-30 20:26:03 --> Helper loaded: form_helper
INFO - 2018-03-30 20:26:03 --> Form Validation Class Initialized
INFO - 2018-03-30 20:26:03 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:26:03 --> Helper loaded: url_helper
INFO - 2018-03-30 20:26:03 --> Model Class Initialized
INFO - 2018-03-30 20:26:03 --> Model Class Initialized
INFO - 2018-03-30 20:26:03 --> Model Class Initialized
INFO - 2018-03-30 23:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:56:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:56:03 --> Final output sent to browser
DEBUG - 2018-03-30 23:56:03 --> Total execution time: 0.1290
INFO - 2018-03-30 20:26:40 --> Config Class Initialized
INFO - 2018-03-30 20:26:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:26:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:26:40 --> Utf8 Class Initialized
INFO - 2018-03-30 20:26:40 --> URI Class Initialized
INFO - 2018-03-30 20:26:40 --> Router Class Initialized
INFO - 2018-03-30 20:26:40 --> Output Class Initialized
INFO - 2018-03-30 20:26:40 --> Security Class Initialized
DEBUG - 2018-03-30 20:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:26:40 --> Input Class Initialized
INFO - 2018-03-30 20:26:40 --> Language Class Initialized
INFO - 2018-03-30 20:26:40 --> Loader Class Initialized
INFO - 2018-03-30 20:26:40 --> Helper loaded: common_helper
INFO - 2018-03-30 20:26:40 --> Database Driver Class Initialized
INFO - 2018-03-30 20:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:26:40 --> Email Class Initialized
INFO - 2018-03-30 20:26:40 --> Controller Class Initialized
INFO - 2018-03-30 20:26:40 --> Helper loaded: form_helper
INFO - 2018-03-30 20:26:40 --> Form Validation Class Initialized
INFO - 2018-03-30 20:26:40 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:26:40 --> Helper loaded: url_helper
INFO - 2018-03-30 20:26:40 --> Model Class Initialized
INFO - 2018-03-30 20:26:40 --> Model Class Initialized
INFO - 2018-03-30 20:26:40 --> Model Class Initialized
INFO - 2018-03-30 20:27:09 --> Config Class Initialized
INFO - 2018-03-30 20:27:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:27:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:27:09 --> Utf8 Class Initialized
INFO - 2018-03-30 20:27:09 --> URI Class Initialized
INFO - 2018-03-30 20:27:09 --> Router Class Initialized
INFO - 2018-03-30 20:27:09 --> Output Class Initialized
INFO - 2018-03-30 20:27:09 --> Security Class Initialized
DEBUG - 2018-03-30 20:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:27:09 --> Input Class Initialized
INFO - 2018-03-30 20:27:09 --> Language Class Initialized
INFO - 2018-03-30 20:27:09 --> Loader Class Initialized
INFO - 2018-03-30 20:27:09 --> Helper loaded: common_helper
INFO - 2018-03-30 20:27:09 --> Database Driver Class Initialized
INFO - 2018-03-30 20:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:27:09 --> Email Class Initialized
INFO - 2018-03-30 20:27:09 --> Controller Class Initialized
INFO - 2018-03-30 20:27:09 --> Helper loaded: form_helper
INFO - 2018-03-30 20:27:09 --> Form Validation Class Initialized
INFO - 2018-03-30 20:27:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:27:09 --> Helper loaded: url_helper
INFO - 2018-03-30 20:27:09 --> Model Class Initialized
INFO - 2018-03-30 20:27:09 --> Model Class Initialized
INFO - 2018-03-30 20:27:09 --> Model Class Initialized
INFO - 2018-03-30 20:27:27 --> Config Class Initialized
INFO - 2018-03-30 20:27:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:27:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:27:27 --> Utf8 Class Initialized
INFO - 2018-03-30 20:27:27 --> URI Class Initialized
INFO - 2018-03-30 20:27:27 --> Router Class Initialized
INFO - 2018-03-30 20:27:27 --> Output Class Initialized
INFO - 2018-03-30 20:27:27 --> Security Class Initialized
DEBUG - 2018-03-30 20:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:27:27 --> Input Class Initialized
INFO - 2018-03-30 20:27:27 --> Language Class Initialized
INFO - 2018-03-30 20:27:27 --> Loader Class Initialized
INFO - 2018-03-30 20:27:27 --> Helper loaded: common_helper
INFO - 2018-03-30 20:27:27 --> Database Driver Class Initialized
INFO - 2018-03-30 20:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:27:27 --> Email Class Initialized
INFO - 2018-03-30 20:27:27 --> Controller Class Initialized
INFO - 2018-03-30 20:27:27 --> Helper loaded: form_helper
INFO - 2018-03-30 20:27:27 --> Form Validation Class Initialized
INFO - 2018-03-30 20:27:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:27:27 --> Helper loaded: url_helper
INFO - 2018-03-30 20:27:27 --> Model Class Initialized
INFO - 2018-03-30 20:27:27 --> Model Class Initialized
INFO - 2018-03-30 20:27:27 --> Model Class Initialized
INFO - 2018-03-30 20:28:11 --> Config Class Initialized
INFO - 2018-03-30 20:28:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:28:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:28:11 --> Utf8 Class Initialized
INFO - 2018-03-30 20:28:11 --> URI Class Initialized
INFO - 2018-03-30 20:28:11 --> Router Class Initialized
INFO - 2018-03-30 20:28:11 --> Output Class Initialized
INFO - 2018-03-30 20:28:11 --> Security Class Initialized
DEBUG - 2018-03-30 20:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:28:11 --> Input Class Initialized
INFO - 2018-03-30 20:28:11 --> Language Class Initialized
INFO - 2018-03-30 20:28:11 --> Loader Class Initialized
INFO - 2018-03-30 20:28:11 --> Helper loaded: common_helper
INFO - 2018-03-30 20:28:11 --> Database Driver Class Initialized
INFO - 2018-03-30 20:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:28:11 --> Email Class Initialized
INFO - 2018-03-30 20:28:11 --> Controller Class Initialized
INFO - 2018-03-30 20:28:11 --> Helper loaded: form_helper
INFO - 2018-03-30 20:28:11 --> Form Validation Class Initialized
INFO - 2018-03-30 20:28:11 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:28:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:28:11 --> Helper loaded: url_helper
INFO - 2018-03-30 20:28:11 --> Model Class Initialized
INFO - 2018-03-30 20:28:11 --> Model Class Initialized
INFO - 2018-03-30 20:28:11 --> Model Class Initialized
INFO - 2018-03-30 20:28:23 --> Config Class Initialized
INFO - 2018-03-30 20:28:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:28:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:28:23 --> Utf8 Class Initialized
INFO - 2018-03-30 20:28:23 --> URI Class Initialized
INFO - 2018-03-30 20:28:23 --> Router Class Initialized
INFO - 2018-03-30 20:28:23 --> Output Class Initialized
INFO - 2018-03-30 20:28:23 --> Security Class Initialized
DEBUG - 2018-03-30 20:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:28:23 --> Input Class Initialized
INFO - 2018-03-30 20:28:24 --> Language Class Initialized
INFO - 2018-03-30 20:28:24 --> Loader Class Initialized
INFO - 2018-03-30 20:28:24 --> Helper loaded: common_helper
INFO - 2018-03-30 20:28:24 --> Database Driver Class Initialized
INFO - 2018-03-30 20:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:28:24 --> Email Class Initialized
INFO - 2018-03-30 20:28:24 --> Controller Class Initialized
INFO - 2018-03-30 20:28:24 --> Helper loaded: form_helper
INFO - 2018-03-30 20:28:24 --> Form Validation Class Initialized
INFO - 2018-03-30 20:28:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:28:24 --> Helper loaded: url_helper
INFO - 2018-03-30 20:28:24 --> Model Class Initialized
INFO - 2018-03-30 20:28:24 --> Model Class Initialized
INFO - 2018-03-30 20:28:24 --> Model Class Initialized
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-30 23:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 23:58:24 --> Final output sent to browser
DEBUG - 2018-03-30 23:58:24 --> Total execution time: 0.1440
INFO - 2018-03-30 20:29:40 --> Config Class Initialized
INFO - 2018-03-30 20:29:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:29:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:29:40 --> Utf8 Class Initialized
INFO - 2018-03-30 20:29:40 --> URI Class Initialized
INFO - 2018-03-30 20:29:40 --> Router Class Initialized
INFO - 2018-03-30 20:29:40 --> Output Class Initialized
INFO - 2018-03-30 20:29:40 --> Security Class Initialized
DEBUG - 2018-03-30 20:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:29:40 --> Input Class Initialized
INFO - 2018-03-30 20:29:40 --> Language Class Initialized
INFO - 2018-03-30 20:29:40 --> Loader Class Initialized
INFO - 2018-03-30 20:29:40 --> Helper loaded: common_helper
INFO - 2018-03-30 20:29:40 --> Database Driver Class Initialized
INFO - 2018-03-30 20:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:29:40 --> Email Class Initialized
INFO - 2018-03-30 20:29:40 --> Controller Class Initialized
INFO - 2018-03-30 20:29:40 --> Helper loaded: form_helper
INFO - 2018-03-30 20:29:40 --> Form Validation Class Initialized
INFO - 2018-03-30 20:29:40 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:29:40 --> Helper loaded: url_helper
INFO - 2018-03-30 20:29:40 --> Model Class Initialized
INFO - 2018-03-30 20:29:40 --> Model Class Initialized
INFO - 2018-03-30 20:29:40 --> Model Class Initialized
INFO - 2018-03-30 20:48:11 --> Config Class Initialized
INFO - 2018-03-30 20:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:48:11 --> Utf8 Class Initialized
INFO - 2018-03-30 20:48:11 --> URI Class Initialized
INFO - 2018-03-30 20:48:11 --> Router Class Initialized
INFO - 2018-03-30 20:48:11 --> Output Class Initialized
INFO - 2018-03-30 20:48:11 --> Security Class Initialized
DEBUG - 2018-03-30 20:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:48:11 --> Input Class Initialized
INFO - 2018-03-30 20:48:11 --> Language Class Initialized
INFO - 2018-03-30 20:48:11 --> Loader Class Initialized
INFO - 2018-03-30 20:48:11 --> Helper loaded: common_helper
INFO - 2018-03-30 20:48:11 --> Database Driver Class Initialized
INFO - 2018-03-30 20:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:48:11 --> Email Class Initialized
INFO - 2018-03-30 20:48:11 --> Controller Class Initialized
INFO - 2018-03-30 20:48:11 --> Helper loaded: form_helper
INFO - 2018-03-30 20:48:11 --> Form Validation Class Initialized
INFO - 2018-03-30 20:48:11 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:48:11 --> Helper loaded: url_helper
INFO - 2018-03-30 20:48:11 --> Model Class Initialized
INFO - 2018-03-30 20:48:11 --> Model Class Initialized
INFO - 2018-03-30 20:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-30 20:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-30 20:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-30 20:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-30 20:48:11 --> Final output sent to browser
DEBUG - 2018-03-30 20:48:11 --> Total execution time: 0.0650
INFO - 2018-03-30 20:48:20 --> Config Class Initialized
INFO - 2018-03-30 20:48:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:48:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:48:20 --> Utf8 Class Initialized
INFO - 2018-03-30 20:48:20 --> URI Class Initialized
INFO - 2018-03-30 20:48:20 --> Router Class Initialized
INFO - 2018-03-30 20:48:20 --> Output Class Initialized
INFO - 2018-03-30 20:48:20 --> Security Class Initialized
DEBUG - 2018-03-30 20:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:48:20 --> Input Class Initialized
INFO - 2018-03-30 20:48:20 --> Language Class Initialized
INFO - 2018-03-30 20:48:20 --> Loader Class Initialized
INFO - 2018-03-30 20:48:20 --> Helper loaded: common_helper
INFO - 2018-03-30 20:48:20 --> Database Driver Class Initialized
INFO - 2018-03-30 20:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:48:20 --> Email Class Initialized
INFO - 2018-03-30 20:48:20 --> Controller Class Initialized
INFO - 2018-03-30 20:48:20 --> Helper loaded: form_helper
INFO - 2018-03-30 20:48:20 --> Form Validation Class Initialized
INFO - 2018-03-30 20:48:20 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:48:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:48:20 --> Helper loaded: url_helper
INFO - 2018-03-30 20:48:20 --> Model Class Initialized
INFO - 2018-03-30 20:48:20 --> Model Class Initialized
INFO - 2018-03-30 20:48:20 --> Model Class Initialized
INFO - 2018-03-30 20:51:34 --> Config Class Initialized
INFO - 2018-03-30 20:51:34 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:51:34 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:51:34 --> Utf8 Class Initialized
INFO - 2018-03-30 20:51:34 --> URI Class Initialized
INFO - 2018-03-30 20:51:34 --> Router Class Initialized
INFO - 2018-03-30 20:51:34 --> Output Class Initialized
INFO - 2018-03-30 20:51:34 --> Security Class Initialized
DEBUG - 2018-03-30 20:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:51:34 --> Input Class Initialized
INFO - 2018-03-30 20:51:34 --> Language Class Initialized
INFO - 2018-03-30 20:51:34 --> Loader Class Initialized
INFO - 2018-03-30 20:51:34 --> Helper loaded: common_helper
INFO - 2018-03-30 20:51:34 --> Database Driver Class Initialized
INFO - 2018-03-30 20:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:51:34 --> Email Class Initialized
INFO - 2018-03-30 20:51:34 --> Controller Class Initialized
INFO - 2018-03-30 20:51:34 --> Helper loaded: form_helper
INFO - 2018-03-30 20:51:34 --> Form Validation Class Initialized
INFO - 2018-03-30 20:51:34 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:51:34 --> Helper loaded: url_helper
INFO - 2018-03-30 20:51:34 --> Model Class Initialized
INFO - 2018-03-30 20:51:34 --> Model Class Initialized
INFO - 2018-03-30 20:51:34 --> Model Class Initialized
INFO - 2018-03-30 20:51:56 --> Config Class Initialized
INFO - 2018-03-30 20:51:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:51:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:51:56 --> Utf8 Class Initialized
INFO - 2018-03-30 20:51:56 --> URI Class Initialized
INFO - 2018-03-30 20:51:56 --> Router Class Initialized
INFO - 2018-03-30 20:51:56 --> Output Class Initialized
INFO - 2018-03-30 20:51:56 --> Security Class Initialized
DEBUG - 2018-03-30 20:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:51:56 --> Input Class Initialized
INFO - 2018-03-30 20:51:56 --> Language Class Initialized
INFO - 2018-03-30 20:51:56 --> Loader Class Initialized
INFO - 2018-03-30 20:51:56 --> Helper loaded: common_helper
INFO - 2018-03-30 20:51:56 --> Database Driver Class Initialized
INFO - 2018-03-30 20:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:51:56 --> Email Class Initialized
INFO - 2018-03-30 20:51:56 --> Controller Class Initialized
INFO - 2018-03-30 20:51:56 --> Helper loaded: form_helper
INFO - 2018-03-30 20:51:56 --> Form Validation Class Initialized
INFO - 2018-03-30 20:51:56 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:51:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:51:56 --> Helper loaded: url_helper
INFO - 2018-03-30 20:51:56 --> Model Class Initialized
INFO - 2018-03-30 20:51:56 --> Model Class Initialized
INFO - 2018-03-30 20:51:56 --> Model Class Initialized
INFO - 2018-03-30 20:52:22 --> Config Class Initialized
INFO - 2018-03-30 20:52:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:52:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:52:22 --> Utf8 Class Initialized
INFO - 2018-03-30 20:52:22 --> URI Class Initialized
INFO - 2018-03-30 20:52:22 --> Router Class Initialized
INFO - 2018-03-30 20:52:22 --> Output Class Initialized
INFO - 2018-03-30 20:52:22 --> Security Class Initialized
DEBUG - 2018-03-30 20:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:52:22 --> Input Class Initialized
INFO - 2018-03-30 20:52:22 --> Language Class Initialized
INFO - 2018-03-30 20:52:22 --> Loader Class Initialized
INFO - 2018-03-30 20:52:22 --> Helper loaded: common_helper
INFO - 2018-03-30 20:52:22 --> Database Driver Class Initialized
INFO - 2018-03-30 20:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:52:22 --> Email Class Initialized
INFO - 2018-03-30 20:52:22 --> Controller Class Initialized
INFO - 2018-03-30 20:52:22 --> Helper loaded: form_helper
INFO - 2018-03-30 20:52:22 --> Form Validation Class Initialized
INFO - 2018-03-30 20:52:22 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:52:22 --> Helper loaded: url_helper
INFO - 2018-03-30 20:52:22 --> Model Class Initialized
INFO - 2018-03-30 20:52:22 --> Model Class Initialized
INFO - 2018-03-30 20:52:22 --> Model Class Initialized
INFO - 2018-03-30 20:52:40 --> Config Class Initialized
INFO - 2018-03-30 20:52:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:52:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:52:40 --> Utf8 Class Initialized
INFO - 2018-03-30 20:52:40 --> URI Class Initialized
INFO - 2018-03-30 20:52:40 --> Router Class Initialized
INFO - 2018-03-30 20:52:40 --> Output Class Initialized
INFO - 2018-03-30 20:52:40 --> Security Class Initialized
DEBUG - 2018-03-30 20:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:52:40 --> Input Class Initialized
INFO - 2018-03-30 20:52:40 --> Language Class Initialized
INFO - 2018-03-30 20:52:40 --> Loader Class Initialized
INFO - 2018-03-30 20:52:40 --> Helper loaded: common_helper
INFO - 2018-03-30 20:52:40 --> Database Driver Class Initialized
INFO - 2018-03-30 20:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:52:40 --> Email Class Initialized
INFO - 2018-03-30 20:52:40 --> Controller Class Initialized
INFO - 2018-03-30 20:52:40 --> Helper loaded: form_helper
INFO - 2018-03-30 20:52:40 --> Form Validation Class Initialized
INFO - 2018-03-30 20:52:40 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:52:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:52:40 --> Helper loaded: url_helper
INFO - 2018-03-30 20:52:40 --> Model Class Initialized
INFO - 2018-03-30 20:52:40 --> Model Class Initialized
INFO - 2018-03-30 20:52:40 --> Model Class Initialized
INFO - 2018-03-30 20:53:06 --> Config Class Initialized
INFO - 2018-03-30 20:53:06 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:53:06 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:53:06 --> Utf8 Class Initialized
INFO - 2018-03-30 20:53:06 --> URI Class Initialized
INFO - 2018-03-30 20:53:06 --> Router Class Initialized
INFO - 2018-03-30 20:53:06 --> Output Class Initialized
INFO - 2018-03-30 20:53:06 --> Security Class Initialized
DEBUG - 2018-03-30 20:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:53:06 --> Input Class Initialized
INFO - 2018-03-30 20:53:06 --> Language Class Initialized
INFO - 2018-03-30 20:53:06 --> Loader Class Initialized
INFO - 2018-03-30 20:53:06 --> Helper loaded: common_helper
INFO - 2018-03-30 20:53:06 --> Database Driver Class Initialized
INFO - 2018-03-30 20:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:53:06 --> Email Class Initialized
INFO - 2018-03-30 20:53:06 --> Controller Class Initialized
INFO - 2018-03-30 20:53:06 --> Helper loaded: form_helper
INFO - 2018-03-30 20:53:06 --> Form Validation Class Initialized
INFO - 2018-03-30 20:53:06 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:53:06 --> Helper loaded: url_helper
INFO - 2018-03-30 20:53:06 --> Model Class Initialized
INFO - 2018-03-30 20:53:06 --> Model Class Initialized
INFO - 2018-03-30 20:53:06 --> Model Class Initialized
INFO - 2018-03-30 20:53:29 --> Config Class Initialized
INFO - 2018-03-30 20:53:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:53:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:53:30 --> Utf8 Class Initialized
INFO - 2018-03-30 20:53:30 --> URI Class Initialized
INFO - 2018-03-30 20:53:30 --> Router Class Initialized
INFO - 2018-03-30 20:53:30 --> Output Class Initialized
INFO - 2018-03-30 20:53:30 --> Security Class Initialized
DEBUG - 2018-03-30 20:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:53:30 --> Input Class Initialized
INFO - 2018-03-30 20:53:30 --> Language Class Initialized
INFO - 2018-03-30 20:53:30 --> Loader Class Initialized
INFO - 2018-03-30 20:53:30 --> Helper loaded: common_helper
INFO - 2018-03-30 20:53:30 --> Database Driver Class Initialized
INFO - 2018-03-30 20:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:53:30 --> Email Class Initialized
INFO - 2018-03-30 20:53:30 --> Controller Class Initialized
INFO - 2018-03-30 20:53:30 --> Helper loaded: form_helper
INFO - 2018-03-30 20:53:30 --> Form Validation Class Initialized
INFO - 2018-03-30 20:53:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:53:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:53:30 --> Helper loaded: url_helper
INFO - 2018-03-30 20:53:30 --> Model Class Initialized
INFO - 2018-03-30 20:53:30 --> Model Class Initialized
INFO - 2018-03-30 20:53:30 --> Model Class Initialized
INFO - 2018-03-30 20:54:13 --> Config Class Initialized
INFO - 2018-03-30 20:54:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:54:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:54:13 --> Utf8 Class Initialized
INFO - 2018-03-30 20:54:13 --> URI Class Initialized
INFO - 2018-03-30 20:54:13 --> Router Class Initialized
INFO - 2018-03-30 20:54:13 --> Output Class Initialized
INFO - 2018-03-30 20:54:13 --> Security Class Initialized
DEBUG - 2018-03-30 20:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:54:13 --> Input Class Initialized
INFO - 2018-03-30 20:54:13 --> Language Class Initialized
INFO - 2018-03-30 20:54:13 --> Loader Class Initialized
INFO - 2018-03-30 20:54:13 --> Helper loaded: common_helper
INFO - 2018-03-30 20:54:13 --> Database Driver Class Initialized
INFO - 2018-03-30 20:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:54:13 --> Email Class Initialized
INFO - 2018-03-30 20:54:13 --> Controller Class Initialized
INFO - 2018-03-30 20:54:13 --> Helper loaded: form_helper
INFO - 2018-03-30 20:54:13 --> Form Validation Class Initialized
INFO - 2018-03-30 20:54:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:54:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:54:13 --> Helper loaded: url_helper
INFO - 2018-03-30 20:54:13 --> Model Class Initialized
INFO - 2018-03-30 20:54:13 --> Model Class Initialized
INFO - 2018-03-30 20:54:13 --> Model Class Initialized
INFO - 2018-03-30 20:54:27 --> Config Class Initialized
INFO - 2018-03-30 20:54:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:54:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:54:27 --> Utf8 Class Initialized
INFO - 2018-03-30 20:54:27 --> URI Class Initialized
INFO - 2018-03-30 20:54:27 --> Router Class Initialized
INFO - 2018-03-30 20:54:27 --> Output Class Initialized
INFO - 2018-03-30 20:54:27 --> Security Class Initialized
DEBUG - 2018-03-30 20:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:54:27 --> Input Class Initialized
INFO - 2018-03-30 20:54:27 --> Language Class Initialized
INFO - 2018-03-30 20:54:27 --> Loader Class Initialized
INFO - 2018-03-30 20:54:27 --> Helper loaded: common_helper
INFO - 2018-03-30 20:54:27 --> Database Driver Class Initialized
INFO - 2018-03-30 20:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:54:27 --> Email Class Initialized
INFO - 2018-03-30 20:54:27 --> Controller Class Initialized
INFO - 2018-03-30 20:54:27 --> Helper loaded: form_helper
INFO - 2018-03-30 20:54:27 --> Form Validation Class Initialized
INFO - 2018-03-30 20:54:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:54:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:54:27 --> Helper loaded: url_helper
INFO - 2018-03-30 20:54:27 --> Model Class Initialized
INFO - 2018-03-30 20:54:27 --> Model Class Initialized
INFO - 2018-03-30 20:54:27 --> Model Class Initialized
INFO - 2018-03-30 20:57:13 --> Config Class Initialized
INFO - 2018-03-30 20:57:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:57:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:57:13 --> Utf8 Class Initialized
INFO - 2018-03-30 20:57:13 --> URI Class Initialized
INFO - 2018-03-30 20:57:13 --> Router Class Initialized
INFO - 2018-03-30 20:57:13 --> Output Class Initialized
INFO - 2018-03-30 20:57:13 --> Security Class Initialized
DEBUG - 2018-03-30 20:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:57:13 --> Input Class Initialized
INFO - 2018-03-30 20:57:13 --> Language Class Initialized
INFO - 2018-03-30 20:57:13 --> Loader Class Initialized
INFO - 2018-03-30 20:57:13 --> Helper loaded: common_helper
INFO - 2018-03-30 20:57:13 --> Database Driver Class Initialized
INFO - 2018-03-30 20:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:57:13 --> Email Class Initialized
INFO - 2018-03-30 20:57:13 --> Controller Class Initialized
INFO - 2018-03-30 20:57:13 --> Helper loaded: form_helper
INFO - 2018-03-30 20:57:13 --> Form Validation Class Initialized
INFO - 2018-03-30 20:57:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:57:13 --> Helper loaded: url_helper
INFO - 2018-03-30 20:57:13 --> Model Class Initialized
INFO - 2018-03-30 20:57:13 --> Model Class Initialized
INFO - 2018-03-30 20:57:13 --> Model Class Initialized
INFO - 2018-03-30 20:57:56 --> Config Class Initialized
INFO - 2018-03-30 20:57:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:57:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:57:56 --> Utf8 Class Initialized
INFO - 2018-03-30 20:57:56 --> URI Class Initialized
INFO - 2018-03-30 20:57:56 --> Router Class Initialized
INFO - 2018-03-30 20:57:56 --> Output Class Initialized
INFO - 2018-03-30 20:57:56 --> Security Class Initialized
DEBUG - 2018-03-30 20:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:57:56 --> Input Class Initialized
INFO - 2018-03-30 20:57:56 --> Language Class Initialized
INFO - 2018-03-30 20:57:56 --> Loader Class Initialized
INFO - 2018-03-30 20:57:56 --> Helper loaded: common_helper
INFO - 2018-03-30 20:57:56 --> Database Driver Class Initialized
INFO - 2018-03-30 20:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:57:56 --> Email Class Initialized
INFO - 2018-03-30 20:57:56 --> Controller Class Initialized
INFO - 2018-03-30 20:57:56 --> Helper loaded: form_helper
INFO - 2018-03-30 20:57:56 --> Form Validation Class Initialized
INFO - 2018-03-30 20:57:56 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:57:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:57:56 --> Helper loaded: url_helper
INFO - 2018-03-30 20:57:56 --> Model Class Initialized
INFO - 2018-03-30 20:57:56 --> Model Class Initialized
INFO - 2018-03-30 20:57:56 --> Model Class Initialized
INFO - 2018-03-30 20:58:10 --> Config Class Initialized
INFO - 2018-03-30 20:58:10 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:58:11 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:58:11 --> Utf8 Class Initialized
INFO - 2018-03-30 20:58:11 --> URI Class Initialized
INFO - 2018-03-30 20:58:11 --> Router Class Initialized
INFO - 2018-03-30 20:58:11 --> Output Class Initialized
INFO - 2018-03-30 20:58:11 --> Security Class Initialized
DEBUG - 2018-03-30 20:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:58:11 --> Input Class Initialized
INFO - 2018-03-30 20:58:11 --> Language Class Initialized
INFO - 2018-03-30 20:58:11 --> Loader Class Initialized
INFO - 2018-03-30 20:58:11 --> Helper loaded: common_helper
INFO - 2018-03-30 20:58:11 --> Database Driver Class Initialized
INFO - 2018-03-30 20:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:58:11 --> Email Class Initialized
INFO - 2018-03-30 20:58:11 --> Controller Class Initialized
INFO - 2018-03-30 20:58:11 --> Helper loaded: form_helper
INFO - 2018-03-30 20:58:11 --> Form Validation Class Initialized
INFO - 2018-03-30 20:58:11 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:58:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:58:11 --> Helper loaded: url_helper
INFO - 2018-03-30 20:58:11 --> Model Class Initialized
INFO - 2018-03-30 20:58:11 --> Model Class Initialized
INFO - 2018-03-30 20:58:11 --> Model Class Initialized
INFO - 2018-03-30 20:58:22 --> Config Class Initialized
INFO - 2018-03-30 20:58:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:58:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:58:22 --> Utf8 Class Initialized
INFO - 2018-03-30 20:58:22 --> URI Class Initialized
INFO - 2018-03-30 20:58:22 --> Router Class Initialized
INFO - 2018-03-30 20:58:22 --> Output Class Initialized
INFO - 2018-03-30 20:58:22 --> Security Class Initialized
DEBUG - 2018-03-30 20:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:58:22 --> Input Class Initialized
INFO - 2018-03-30 20:58:22 --> Language Class Initialized
INFO - 2018-03-30 20:58:22 --> Loader Class Initialized
INFO - 2018-03-30 20:58:22 --> Helper loaded: common_helper
INFO - 2018-03-30 20:58:22 --> Database Driver Class Initialized
INFO - 2018-03-30 20:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:58:22 --> Email Class Initialized
INFO - 2018-03-30 20:58:22 --> Controller Class Initialized
INFO - 2018-03-30 20:58:22 --> Helper loaded: form_helper
INFO - 2018-03-30 20:58:22 --> Form Validation Class Initialized
INFO - 2018-03-30 20:58:22 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:58:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:58:22 --> Helper loaded: url_helper
INFO - 2018-03-30 20:58:22 --> Model Class Initialized
INFO - 2018-03-30 20:58:22 --> Model Class Initialized
INFO - 2018-03-30 20:58:22 --> Model Class Initialized
INFO - 2018-03-30 20:59:29 --> Config Class Initialized
INFO - 2018-03-30 20:59:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 20:59:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 20:59:29 --> Utf8 Class Initialized
INFO - 2018-03-30 20:59:29 --> URI Class Initialized
INFO - 2018-03-30 20:59:29 --> Router Class Initialized
INFO - 2018-03-30 20:59:29 --> Output Class Initialized
INFO - 2018-03-30 20:59:29 --> Security Class Initialized
DEBUG - 2018-03-30 20:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 20:59:29 --> Input Class Initialized
INFO - 2018-03-30 20:59:29 --> Language Class Initialized
INFO - 2018-03-30 20:59:29 --> Loader Class Initialized
INFO - 2018-03-30 20:59:29 --> Helper loaded: common_helper
INFO - 2018-03-30 20:59:29 --> Database Driver Class Initialized
INFO - 2018-03-30 20:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 20:59:29 --> Email Class Initialized
INFO - 2018-03-30 20:59:29 --> Controller Class Initialized
INFO - 2018-03-30 20:59:29 --> Helper loaded: form_helper
INFO - 2018-03-30 20:59:29 --> Form Validation Class Initialized
INFO - 2018-03-30 20:59:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 20:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 20:59:29 --> Helper loaded: url_helper
INFO - 2018-03-30 20:59:29 --> Model Class Initialized
INFO - 2018-03-30 20:59:29 --> Model Class Initialized
INFO - 2018-03-30 20:59:29 --> Model Class Initialized
INFO - 2018-03-30 21:01:23 --> Config Class Initialized
INFO - 2018-03-30 21:01:23 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:01:23 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:23 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:23 --> URI Class Initialized
INFO - 2018-03-30 21:01:23 --> Router Class Initialized
INFO - 2018-03-30 21:01:23 --> Output Class Initialized
INFO - 2018-03-30 21:01:23 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:23 --> Input Class Initialized
INFO - 2018-03-30 21:01:23 --> Language Class Initialized
INFO - 2018-03-30 21:01:23 --> Loader Class Initialized
INFO - 2018-03-30 21:01:23 --> Helper loaded: common_helper
INFO - 2018-03-30 21:01:23 --> Database Driver Class Initialized
INFO - 2018-03-30 21:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:23 --> Email Class Initialized
INFO - 2018-03-30 21:01:23 --> Controller Class Initialized
INFO - 2018-03-30 21:01:23 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:23 --> Form Validation Class Initialized
INFO - 2018-03-30 21:01:23 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:01:23 --> Helper loaded: url_helper
INFO - 2018-03-30 21:01:23 --> Model Class Initialized
INFO - 2018-03-30 21:01:23 --> Model Class Initialized
INFO - 2018-03-30 21:01:23 --> Model Class Initialized
INFO - 2018-03-30 21:01:40 --> Config Class Initialized
INFO - 2018-03-30 21:01:40 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:01:40 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:01:40 --> Utf8 Class Initialized
INFO - 2018-03-30 21:01:40 --> URI Class Initialized
INFO - 2018-03-30 21:01:40 --> Router Class Initialized
INFO - 2018-03-30 21:01:40 --> Output Class Initialized
INFO - 2018-03-30 21:01:40 --> Security Class Initialized
DEBUG - 2018-03-30 21:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:01:40 --> Input Class Initialized
INFO - 2018-03-30 21:01:40 --> Language Class Initialized
INFO - 2018-03-30 21:01:40 --> Loader Class Initialized
INFO - 2018-03-30 21:01:40 --> Helper loaded: common_helper
INFO - 2018-03-30 21:01:40 --> Database Driver Class Initialized
INFO - 2018-03-30 21:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:01:40 --> Email Class Initialized
INFO - 2018-03-30 21:01:40 --> Controller Class Initialized
INFO - 2018-03-30 21:01:40 --> Helper loaded: form_helper
INFO - 2018-03-30 21:01:40 --> Form Validation Class Initialized
INFO - 2018-03-30 21:01:40 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:01:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:01:40 --> Helper loaded: url_helper
INFO - 2018-03-30 21:01:40 --> Model Class Initialized
INFO - 2018-03-30 21:01:40 --> Model Class Initialized
INFO - 2018-03-30 21:01:40 --> Model Class Initialized
INFO - 2018-03-30 21:02:14 --> Config Class Initialized
INFO - 2018-03-30 21:02:14 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:02:14 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:02:14 --> Utf8 Class Initialized
INFO - 2018-03-30 21:02:14 --> URI Class Initialized
INFO - 2018-03-30 21:02:14 --> Router Class Initialized
INFO - 2018-03-30 21:02:14 --> Output Class Initialized
INFO - 2018-03-30 21:02:14 --> Security Class Initialized
DEBUG - 2018-03-30 21:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:02:14 --> Input Class Initialized
INFO - 2018-03-30 21:02:14 --> Language Class Initialized
INFO - 2018-03-30 21:02:14 --> Loader Class Initialized
INFO - 2018-03-30 21:02:14 --> Helper loaded: common_helper
INFO - 2018-03-30 21:02:14 --> Database Driver Class Initialized
INFO - 2018-03-30 21:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:02:14 --> Email Class Initialized
INFO - 2018-03-30 21:02:14 --> Controller Class Initialized
INFO - 2018-03-30 21:02:14 --> Helper loaded: form_helper
INFO - 2018-03-30 21:02:14 --> Form Validation Class Initialized
INFO - 2018-03-30 21:02:14 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:02:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:02:14 --> Helper loaded: url_helper
INFO - 2018-03-30 21:02:14 --> Model Class Initialized
INFO - 2018-03-30 21:02:14 --> Model Class Initialized
INFO - 2018-03-30 21:02:14 --> Model Class Initialized
INFO - 2018-03-30 21:03:15 --> Config Class Initialized
INFO - 2018-03-30 21:03:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:03:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:03:15 --> Utf8 Class Initialized
INFO - 2018-03-30 21:03:15 --> URI Class Initialized
INFO - 2018-03-30 21:03:15 --> Router Class Initialized
INFO - 2018-03-30 21:03:15 --> Output Class Initialized
INFO - 2018-03-30 21:03:15 --> Security Class Initialized
DEBUG - 2018-03-30 21:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:03:15 --> Input Class Initialized
INFO - 2018-03-30 21:03:15 --> Language Class Initialized
INFO - 2018-03-30 21:03:15 --> Loader Class Initialized
INFO - 2018-03-30 21:03:15 --> Helper loaded: common_helper
INFO - 2018-03-30 21:03:15 --> Database Driver Class Initialized
INFO - 2018-03-30 21:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:03:15 --> Email Class Initialized
INFO - 2018-03-30 21:03:15 --> Controller Class Initialized
INFO - 2018-03-30 21:03:15 --> Helper loaded: form_helper
INFO - 2018-03-30 21:03:15 --> Form Validation Class Initialized
INFO - 2018-03-30 21:03:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:03:15 --> Helper loaded: url_helper
INFO - 2018-03-30 21:03:15 --> Model Class Initialized
INFO - 2018-03-30 21:03:15 --> Model Class Initialized
INFO - 2018-03-30 21:03:15 --> Model Class Initialized
INFO - 2018-03-30 21:03:51 --> Config Class Initialized
INFO - 2018-03-30 21:03:51 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:03:51 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:03:51 --> Utf8 Class Initialized
INFO - 2018-03-30 21:03:51 --> URI Class Initialized
INFO - 2018-03-30 21:03:51 --> Router Class Initialized
INFO - 2018-03-30 21:03:51 --> Output Class Initialized
INFO - 2018-03-30 21:03:51 --> Security Class Initialized
DEBUG - 2018-03-30 21:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:03:51 --> Input Class Initialized
INFO - 2018-03-30 21:03:51 --> Language Class Initialized
INFO - 2018-03-30 21:03:51 --> Loader Class Initialized
INFO - 2018-03-30 21:03:51 --> Helper loaded: common_helper
INFO - 2018-03-30 21:03:51 --> Database Driver Class Initialized
INFO - 2018-03-30 21:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:03:51 --> Email Class Initialized
INFO - 2018-03-30 21:03:51 --> Controller Class Initialized
INFO - 2018-03-30 21:03:51 --> Helper loaded: form_helper
INFO - 2018-03-30 21:03:51 --> Form Validation Class Initialized
INFO - 2018-03-30 21:03:51 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:03:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:03:51 --> Helper loaded: url_helper
INFO - 2018-03-30 21:03:51 --> Model Class Initialized
INFO - 2018-03-30 21:03:51 --> Model Class Initialized
INFO - 2018-03-30 21:03:51 --> Model Class Initialized
INFO - 2018-03-30 21:04:24 --> Config Class Initialized
INFO - 2018-03-30 21:04:24 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:04:24 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:04:24 --> Utf8 Class Initialized
INFO - 2018-03-30 21:04:24 --> URI Class Initialized
INFO - 2018-03-30 21:04:24 --> Router Class Initialized
INFO - 2018-03-30 21:04:24 --> Output Class Initialized
INFO - 2018-03-30 21:04:24 --> Security Class Initialized
DEBUG - 2018-03-30 21:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:04:24 --> Input Class Initialized
INFO - 2018-03-30 21:04:24 --> Language Class Initialized
INFO - 2018-03-30 21:04:24 --> Loader Class Initialized
INFO - 2018-03-30 21:04:24 --> Helper loaded: common_helper
INFO - 2018-03-30 21:04:24 --> Database Driver Class Initialized
INFO - 2018-03-30 21:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:04:24 --> Email Class Initialized
INFO - 2018-03-30 21:04:24 --> Controller Class Initialized
INFO - 2018-03-30 21:04:24 --> Helper loaded: form_helper
INFO - 2018-03-30 21:04:24 --> Form Validation Class Initialized
INFO - 2018-03-30 21:04:24 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:04:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:04:24 --> Helper loaded: url_helper
INFO - 2018-03-30 21:04:24 --> Model Class Initialized
INFO - 2018-03-30 21:04:24 --> Model Class Initialized
INFO - 2018-03-30 21:04:24 --> Model Class Initialized
INFO - 2018-03-30 21:04:45 --> Config Class Initialized
INFO - 2018-03-30 21:04:45 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:04:45 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:04:45 --> Utf8 Class Initialized
INFO - 2018-03-30 21:04:45 --> URI Class Initialized
INFO - 2018-03-30 21:04:45 --> Router Class Initialized
INFO - 2018-03-30 21:04:45 --> Output Class Initialized
INFO - 2018-03-30 21:04:45 --> Security Class Initialized
DEBUG - 2018-03-30 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:04:45 --> Input Class Initialized
INFO - 2018-03-30 21:04:45 --> Language Class Initialized
INFO - 2018-03-30 21:04:45 --> Loader Class Initialized
INFO - 2018-03-30 21:04:45 --> Helper loaded: common_helper
INFO - 2018-03-30 21:04:45 --> Database Driver Class Initialized
INFO - 2018-03-30 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:04:45 --> Email Class Initialized
INFO - 2018-03-30 21:04:45 --> Controller Class Initialized
INFO - 2018-03-30 21:04:45 --> Helper loaded: form_helper
INFO - 2018-03-30 21:04:45 --> Form Validation Class Initialized
INFO - 2018-03-30 21:04:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:04:45 --> Helper loaded: url_helper
INFO - 2018-03-30 21:04:45 --> Model Class Initialized
INFO - 2018-03-30 21:04:45 --> Model Class Initialized
INFO - 2018-03-30 21:04:45 --> Model Class Initialized
INFO - 2018-03-30 21:05:08 --> Config Class Initialized
INFO - 2018-03-30 21:05:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:05:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:05:08 --> Utf8 Class Initialized
INFO - 2018-03-30 21:05:08 --> URI Class Initialized
INFO - 2018-03-30 21:05:08 --> Router Class Initialized
INFO - 2018-03-30 21:05:08 --> Output Class Initialized
INFO - 2018-03-30 21:05:08 --> Security Class Initialized
DEBUG - 2018-03-30 21:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:05:08 --> Input Class Initialized
INFO - 2018-03-30 21:05:08 --> Language Class Initialized
INFO - 2018-03-30 21:05:08 --> Loader Class Initialized
INFO - 2018-03-30 21:05:08 --> Helper loaded: common_helper
INFO - 2018-03-30 21:05:08 --> Database Driver Class Initialized
INFO - 2018-03-30 21:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:05:08 --> Email Class Initialized
INFO - 2018-03-30 21:05:08 --> Controller Class Initialized
INFO - 2018-03-30 21:05:08 --> Helper loaded: form_helper
INFO - 2018-03-30 21:05:08 --> Form Validation Class Initialized
INFO - 2018-03-30 21:05:08 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:05:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:05:08 --> Helper loaded: url_helper
INFO - 2018-03-30 21:05:08 --> Model Class Initialized
INFO - 2018-03-30 21:05:08 --> Model Class Initialized
INFO - 2018-03-30 21:05:08 --> Model Class Initialized
INFO - 2018-03-30 21:05:26 --> Config Class Initialized
INFO - 2018-03-30 21:05:26 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:05:26 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:05:26 --> Utf8 Class Initialized
INFO - 2018-03-30 21:05:26 --> URI Class Initialized
INFO - 2018-03-30 21:05:26 --> Router Class Initialized
INFO - 2018-03-30 21:05:26 --> Output Class Initialized
INFO - 2018-03-30 21:05:26 --> Security Class Initialized
DEBUG - 2018-03-30 21:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:05:26 --> Input Class Initialized
INFO - 2018-03-30 21:05:26 --> Language Class Initialized
INFO - 2018-03-30 21:05:26 --> Loader Class Initialized
INFO - 2018-03-30 21:05:26 --> Helper loaded: common_helper
INFO - 2018-03-30 21:05:26 --> Database Driver Class Initialized
INFO - 2018-03-30 21:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:05:26 --> Email Class Initialized
INFO - 2018-03-30 21:05:26 --> Controller Class Initialized
INFO - 2018-03-30 21:05:26 --> Helper loaded: form_helper
INFO - 2018-03-30 21:05:26 --> Form Validation Class Initialized
INFO - 2018-03-30 21:05:26 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:05:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:05:26 --> Helper loaded: url_helper
INFO - 2018-03-30 21:05:26 --> Model Class Initialized
INFO - 2018-03-30 21:05:26 --> Model Class Initialized
INFO - 2018-03-30 21:05:26 --> Model Class Initialized
INFO - 2018-03-30 21:06:18 --> Config Class Initialized
INFO - 2018-03-30 21:06:18 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:06:18 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:06:18 --> Utf8 Class Initialized
INFO - 2018-03-30 21:06:18 --> URI Class Initialized
INFO - 2018-03-30 21:06:18 --> Router Class Initialized
INFO - 2018-03-30 21:06:18 --> Output Class Initialized
INFO - 2018-03-30 21:06:18 --> Security Class Initialized
DEBUG - 2018-03-30 21:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:06:18 --> Input Class Initialized
INFO - 2018-03-30 21:06:18 --> Language Class Initialized
INFO - 2018-03-30 21:06:18 --> Loader Class Initialized
INFO - 2018-03-30 21:06:18 --> Helper loaded: common_helper
INFO - 2018-03-30 21:06:18 --> Database Driver Class Initialized
INFO - 2018-03-30 21:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:06:18 --> Email Class Initialized
INFO - 2018-03-30 21:06:18 --> Controller Class Initialized
INFO - 2018-03-30 21:06:18 --> Helper loaded: form_helper
INFO - 2018-03-30 21:06:18 --> Form Validation Class Initialized
INFO - 2018-03-30 21:06:18 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:06:18 --> Helper loaded: url_helper
INFO - 2018-03-30 21:06:18 --> Model Class Initialized
INFO - 2018-03-30 21:06:18 --> Model Class Initialized
INFO - 2018-03-30 21:06:18 --> Model Class Initialized
INFO - 2018-03-30 21:06:28 --> Config Class Initialized
INFO - 2018-03-30 21:06:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:06:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:06:28 --> Utf8 Class Initialized
INFO - 2018-03-30 21:06:28 --> URI Class Initialized
INFO - 2018-03-30 21:06:28 --> Router Class Initialized
INFO - 2018-03-30 21:06:28 --> Output Class Initialized
INFO - 2018-03-30 21:06:28 --> Security Class Initialized
DEBUG - 2018-03-30 21:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:06:28 --> Input Class Initialized
INFO - 2018-03-30 21:06:28 --> Language Class Initialized
INFO - 2018-03-30 21:06:28 --> Loader Class Initialized
INFO - 2018-03-30 21:06:28 --> Helper loaded: common_helper
INFO - 2018-03-30 21:06:28 --> Database Driver Class Initialized
INFO - 2018-03-30 21:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:06:28 --> Email Class Initialized
INFO - 2018-03-30 21:06:28 --> Controller Class Initialized
INFO - 2018-03-30 21:06:28 --> Helper loaded: form_helper
INFO - 2018-03-30 21:06:28 --> Form Validation Class Initialized
INFO - 2018-03-30 21:06:28 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:06:28 --> Helper loaded: url_helper
INFO - 2018-03-30 21:06:28 --> Model Class Initialized
INFO - 2018-03-30 21:06:28 --> Model Class Initialized
INFO - 2018-03-30 21:06:28 --> Model Class Initialized
INFO - 2018-03-30 21:06:57 --> Config Class Initialized
INFO - 2018-03-30 21:06:57 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:06:57 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:06:57 --> Utf8 Class Initialized
INFO - 2018-03-30 21:06:57 --> URI Class Initialized
INFO - 2018-03-30 21:06:57 --> Router Class Initialized
INFO - 2018-03-30 21:06:57 --> Output Class Initialized
INFO - 2018-03-30 21:06:57 --> Security Class Initialized
DEBUG - 2018-03-30 21:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:06:57 --> Input Class Initialized
INFO - 2018-03-30 21:06:57 --> Language Class Initialized
INFO - 2018-03-30 21:06:57 --> Loader Class Initialized
INFO - 2018-03-30 21:06:57 --> Helper loaded: common_helper
INFO - 2018-03-30 21:06:57 --> Database Driver Class Initialized
INFO - 2018-03-30 21:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:06:57 --> Email Class Initialized
INFO - 2018-03-30 21:06:57 --> Controller Class Initialized
INFO - 2018-03-30 21:06:57 --> Helper loaded: form_helper
INFO - 2018-03-30 21:06:57 --> Form Validation Class Initialized
INFO - 2018-03-30 21:06:57 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:06:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:06:57 --> Helper loaded: url_helper
INFO - 2018-03-30 21:06:57 --> Model Class Initialized
INFO - 2018-03-30 21:06:57 --> Model Class Initialized
INFO - 2018-03-30 21:06:57 --> Model Class Initialized
INFO - 2018-03-30 21:07:59 --> Config Class Initialized
INFO - 2018-03-30 21:07:59 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:07:59 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:07:59 --> Utf8 Class Initialized
INFO - 2018-03-30 21:07:59 --> URI Class Initialized
INFO - 2018-03-30 21:07:59 --> Router Class Initialized
INFO - 2018-03-30 21:07:59 --> Output Class Initialized
INFO - 2018-03-30 21:07:59 --> Security Class Initialized
DEBUG - 2018-03-30 21:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:07:59 --> Input Class Initialized
INFO - 2018-03-30 21:07:59 --> Language Class Initialized
INFO - 2018-03-30 21:07:59 --> Loader Class Initialized
INFO - 2018-03-30 21:07:59 --> Helper loaded: common_helper
INFO - 2018-03-30 21:07:59 --> Database Driver Class Initialized
INFO - 2018-03-30 21:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:07:59 --> Email Class Initialized
INFO - 2018-03-30 21:07:59 --> Controller Class Initialized
INFO - 2018-03-30 21:07:59 --> Helper loaded: form_helper
INFO - 2018-03-30 21:07:59 --> Form Validation Class Initialized
INFO - 2018-03-30 21:07:59 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:07:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:07:59 --> Helper loaded: url_helper
INFO - 2018-03-30 21:07:59 --> Model Class Initialized
INFO - 2018-03-30 21:07:59 --> Model Class Initialized
INFO - 2018-03-30 21:07:59 --> Model Class Initialized
INFO - 2018-03-30 21:08:08 --> Config Class Initialized
INFO - 2018-03-30 21:08:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:08:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:08:08 --> Utf8 Class Initialized
INFO - 2018-03-30 21:08:08 --> URI Class Initialized
INFO - 2018-03-30 21:08:08 --> Router Class Initialized
INFO - 2018-03-30 21:08:08 --> Output Class Initialized
INFO - 2018-03-30 21:08:08 --> Security Class Initialized
DEBUG - 2018-03-30 21:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:08:08 --> Input Class Initialized
INFO - 2018-03-30 21:08:08 --> Language Class Initialized
INFO - 2018-03-30 21:08:08 --> Loader Class Initialized
INFO - 2018-03-30 21:08:08 --> Helper loaded: common_helper
INFO - 2018-03-30 21:08:08 --> Database Driver Class Initialized
INFO - 2018-03-30 21:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:08:09 --> Email Class Initialized
INFO - 2018-03-30 21:08:09 --> Controller Class Initialized
INFO - 2018-03-30 21:08:09 --> Helper loaded: form_helper
INFO - 2018-03-30 21:08:09 --> Form Validation Class Initialized
INFO - 2018-03-30 21:08:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:08:09 --> Helper loaded: url_helper
INFO - 2018-03-30 21:08:09 --> Model Class Initialized
INFO - 2018-03-30 21:08:09 --> Model Class Initialized
INFO - 2018-03-30 21:08:09 --> Model Class Initialized
INFO - 2018-03-30 21:08:32 --> Config Class Initialized
INFO - 2018-03-30 21:08:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:08:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:08:32 --> Utf8 Class Initialized
INFO - 2018-03-30 21:08:32 --> URI Class Initialized
INFO - 2018-03-30 21:08:32 --> Router Class Initialized
INFO - 2018-03-30 21:08:32 --> Output Class Initialized
INFO - 2018-03-30 21:08:32 --> Security Class Initialized
DEBUG - 2018-03-30 21:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:08:32 --> Input Class Initialized
INFO - 2018-03-30 21:08:32 --> Language Class Initialized
INFO - 2018-03-30 21:08:32 --> Loader Class Initialized
INFO - 2018-03-30 21:08:32 --> Helper loaded: common_helper
INFO - 2018-03-30 21:08:32 --> Database Driver Class Initialized
INFO - 2018-03-30 21:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:08:32 --> Email Class Initialized
INFO - 2018-03-30 21:08:32 --> Controller Class Initialized
INFO - 2018-03-30 21:08:32 --> Helper loaded: form_helper
INFO - 2018-03-30 21:08:32 --> Form Validation Class Initialized
INFO - 2018-03-30 21:08:32 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:08:32 --> Helper loaded: url_helper
INFO - 2018-03-30 21:08:32 --> Model Class Initialized
INFO - 2018-03-30 21:08:32 --> Model Class Initialized
INFO - 2018-03-30 21:08:32 --> Model Class Initialized
INFO - 2018-03-30 21:09:03 --> Config Class Initialized
INFO - 2018-03-30 21:09:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:09:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:09:03 --> Utf8 Class Initialized
INFO - 2018-03-30 21:09:03 --> URI Class Initialized
INFO - 2018-03-30 21:09:03 --> Router Class Initialized
INFO - 2018-03-30 21:09:03 --> Output Class Initialized
INFO - 2018-03-30 21:09:03 --> Security Class Initialized
DEBUG - 2018-03-30 21:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:09:03 --> Input Class Initialized
INFO - 2018-03-30 21:09:03 --> Language Class Initialized
INFO - 2018-03-30 21:09:03 --> Loader Class Initialized
INFO - 2018-03-30 21:09:03 --> Helper loaded: common_helper
INFO - 2018-03-30 21:09:03 --> Database Driver Class Initialized
INFO - 2018-03-30 21:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:09:03 --> Email Class Initialized
INFO - 2018-03-30 21:09:03 --> Controller Class Initialized
INFO - 2018-03-30 21:09:03 --> Helper loaded: form_helper
INFO - 2018-03-30 21:09:03 --> Form Validation Class Initialized
INFO - 2018-03-30 21:09:03 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:09:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:09:03 --> Helper loaded: url_helper
INFO - 2018-03-30 21:09:03 --> Model Class Initialized
INFO - 2018-03-30 21:09:03 --> Model Class Initialized
INFO - 2018-03-30 21:09:03 --> Model Class Initialized
INFO - 2018-03-30 21:09:54 --> Config Class Initialized
INFO - 2018-03-30 21:09:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:09:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:09:54 --> Utf8 Class Initialized
INFO - 2018-03-30 21:09:54 --> URI Class Initialized
INFO - 2018-03-30 21:09:54 --> Router Class Initialized
INFO - 2018-03-30 21:09:54 --> Output Class Initialized
INFO - 2018-03-30 21:09:54 --> Security Class Initialized
DEBUG - 2018-03-30 21:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:09:54 --> Input Class Initialized
INFO - 2018-03-30 21:09:54 --> Language Class Initialized
INFO - 2018-03-30 21:09:54 --> Loader Class Initialized
INFO - 2018-03-30 21:09:54 --> Helper loaded: common_helper
INFO - 2018-03-30 21:09:54 --> Database Driver Class Initialized
INFO - 2018-03-30 21:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:09:54 --> Email Class Initialized
INFO - 2018-03-30 21:09:54 --> Controller Class Initialized
INFO - 2018-03-30 21:09:54 --> Helper loaded: form_helper
INFO - 2018-03-30 21:09:54 --> Form Validation Class Initialized
INFO - 2018-03-30 21:09:54 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:09:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:09:54 --> Helper loaded: url_helper
INFO - 2018-03-30 21:09:54 --> Model Class Initialized
INFO - 2018-03-30 21:09:54 --> Model Class Initialized
INFO - 2018-03-30 21:09:54 --> Model Class Initialized
INFO - 2018-03-30 21:10:27 --> Config Class Initialized
INFO - 2018-03-30 21:10:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:10:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:10:27 --> Utf8 Class Initialized
INFO - 2018-03-30 21:10:27 --> URI Class Initialized
INFO - 2018-03-30 21:10:27 --> Router Class Initialized
INFO - 2018-03-30 21:10:27 --> Output Class Initialized
INFO - 2018-03-30 21:10:27 --> Security Class Initialized
DEBUG - 2018-03-30 21:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:10:27 --> Input Class Initialized
INFO - 2018-03-30 21:10:27 --> Language Class Initialized
INFO - 2018-03-30 21:10:27 --> Loader Class Initialized
INFO - 2018-03-30 21:10:27 --> Helper loaded: common_helper
INFO - 2018-03-30 21:10:27 --> Database Driver Class Initialized
INFO - 2018-03-30 21:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:10:27 --> Email Class Initialized
INFO - 2018-03-30 21:10:27 --> Controller Class Initialized
INFO - 2018-03-30 21:10:27 --> Helper loaded: form_helper
INFO - 2018-03-30 21:10:27 --> Form Validation Class Initialized
INFO - 2018-03-30 21:10:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:10:27 --> Helper loaded: url_helper
INFO - 2018-03-30 21:10:27 --> Model Class Initialized
INFO - 2018-03-30 21:10:27 --> Model Class Initialized
INFO - 2018-03-30 21:10:27 --> Model Class Initialized
INFO - 2018-03-30 21:12:27 --> Config Class Initialized
INFO - 2018-03-30 21:12:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:12:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:12:27 --> Utf8 Class Initialized
INFO - 2018-03-30 21:12:27 --> URI Class Initialized
INFO - 2018-03-30 21:12:27 --> Router Class Initialized
INFO - 2018-03-30 21:12:27 --> Output Class Initialized
INFO - 2018-03-30 21:12:27 --> Security Class Initialized
DEBUG - 2018-03-30 21:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:12:27 --> Input Class Initialized
INFO - 2018-03-30 21:12:27 --> Language Class Initialized
INFO - 2018-03-30 21:12:27 --> Loader Class Initialized
INFO - 2018-03-30 21:12:27 --> Helper loaded: common_helper
INFO - 2018-03-30 21:12:27 --> Database Driver Class Initialized
INFO - 2018-03-30 21:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:12:27 --> Email Class Initialized
INFO - 2018-03-30 21:12:27 --> Controller Class Initialized
INFO - 2018-03-30 21:12:27 --> Helper loaded: form_helper
INFO - 2018-03-30 21:12:27 --> Form Validation Class Initialized
INFO - 2018-03-30 21:12:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:12:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:12:27 --> Helper loaded: url_helper
INFO - 2018-03-30 21:12:27 --> Model Class Initialized
INFO - 2018-03-30 21:12:27 --> Model Class Initialized
INFO - 2018-03-30 21:12:27 --> Model Class Initialized
INFO - 2018-03-30 21:12:36 --> Config Class Initialized
INFO - 2018-03-30 21:12:36 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:12:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:12:36 --> Utf8 Class Initialized
INFO - 2018-03-30 21:12:36 --> URI Class Initialized
INFO - 2018-03-30 21:12:36 --> Router Class Initialized
INFO - 2018-03-30 21:12:36 --> Output Class Initialized
INFO - 2018-03-30 21:12:36 --> Security Class Initialized
DEBUG - 2018-03-30 21:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:12:36 --> Input Class Initialized
INFO - 2018-03-30 21:12:36 --> Language Class Initialized
INFO - 2018-03-30 21:12:36 --> Loader Class Initialized
INFO - 2018-03-30 21:12:36 --> Helper loaded: common_helper
INFO - 2018-03-30 21:12:36 --> Database Driver Class Initialized
INFO - 2018-03-30 21:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:12:36 --> Email Class Initialized
INFO - 2018-03-30 21:12:36 --> Controller Class Initialized
INFO - 2018-03-30 21:12:36 --> Helper loaded: form_helper
INFO - 2018-03-30 21:12:36 --> Form Validation Class Initialized
INFO - 2018-03-30 21:12:36 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:12:36 --> Helper loaded: url_helper
INFO - 2018-03-30 21:12:36 --> Model Class Initialized
INFO - 2018-03-30 21:12:36 --> Model Class Initialized
INFO - 2018-03-30 21:12:36 --> Model Class Initialized
INFO - 2018-03-30 21:13:22 --> Config Class Initialized
INFO - 2018-03-30 21:13:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:13:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:13:22 --> Utf8 Class Initialized
INFO - 2018-03-30 21:13:22 --> URI Class Initialized
INFO - 2018-03-30 21:13:22 --> Router Class Initialized
INFO - 2018-03-30 21:13:22 --> Output Class Initialized
INFO - 2018-03-30 21:13:22 --> Security Class Initialized
DEBUG - 2018-03-30 21:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:13:22 --> Input Class Initialized
INFO - 2018-03-30 21:13:22 --> Language Class Initialized
INFO - 2018-03-30 21:13:22 --> Loader Class Initialized
INFO - 2018-03-30 21:13:22 --> Helper loaded: common_helper
INFO - 2018-03-30 21:13:22 --> Database Driver Class Initialized
INFO - 2018-03-30 21:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:13:22 --> Email Class Initialized
INFO - 2018-03-30 21:13:22 --> Controller Class Initialized
INFO - 2018-03-30 21:13:22 --> Helper loaded: form_helper
INFO - 2018-03-30 21:13:22 --> Form Validation Class Initialized
INFO - 2018-03-30 21:13:22 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:13:22 --> Helper loaded: url_helper
INFO - 2018-03-30 21:13:22 --> Model Class Initialized
INFO - 2018-03-30 21:13:22 --> Model Class Initialized
INFO - 2018-03-30 21:13:22 --> Model Class Initialized
INFO - 2018-03-30 21:14:05 --> Config Class Initialized
INFO - 2018-03-30 21:14:05 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:14:05 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:14:05 --> Utf8 Class Initialized
INFO - 2018-03-30 21:14:05 --> URI Class Initialized
INFO - 2018-03-30 21:14:05 --> Router Class Initialized
INFO - 2018-03-30 21:14:05 --> Output Class Initialized
INFO - 2018-03-30 21:14:05 --> Security Class Initialized
DEBUG - 2018-03-30 21:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:14:05 --> Input Class Initialized
INFO - 2018-03-30 21:14:05 --> Language Class Initialized
INFO - 2018-03-30 21:14:05 --> Loader Class Initialized
INFO - 2018-03-30 21:14:05 --> Helper loaded: common_helper
INFO - 2018-03-30 21:14:05 --> Database Driver Class Initialized
INFO - 2018-03-30 21:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:14:05 --> Email Class Initialized
INFO - 2018-03-30 21:14:05 --> Controller Class Initialized
INFO - 2018-03-30 21:14:05 --> Helper loaded: form_helper
INFO - 2018-03-30 21:14:05 --> Form Validation Class Initialized
INFO - 2018-03-30 21:14:05 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:14:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:14:05 --> Helper loaded: url_helper
INFO - 2018-03-30 21:14:05 --> Model Class Initialized
INFO - 2018-03-30 21:14:05 --> Model Class Initialized
INFO - 2018-03-30 21:14:05 --> Model Class Initialized
INFO - 2018-03-30 21:14:07 --> Config Class Initialized
INFO - 2018-03-30 21:14:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:14:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:14:08 --> Utf8 Class Initialized
INFO - 2018-03-30 21:14:08 --> URI Class Initialized
INFO - 2018-03-30 21:14:08 --> Router Class Initialized
INFO - 2018-03-30 21:14:08 --> Output Class Initialized
INFO - 2018-03-30 21:14:08 --> Security Class Initialized
DEBUG - 2018-03-30 21:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:14:08 --> Input Class Initialized
INFO - 2018-03-30 21:14:08 --> Language Class Initialized
INFO - 2018-03-30 21:14:08 --> Loader Class Initialized
INFO - 2018-03-30 21:14:08 --> Helper loaded: common_helper
INFO - 2018-03-30 21:14:08 --> Database Driver Class Initialized
INFO - 2018-03-30 21:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:14:08 --> Email Class Initialized
INFO - 2018-03-30 21:14:08 --> Controller Class Initialized
INFO - 2018-03-30 21:14:08 --> Helper loaded: form_helper
INFO - 2018-03-30 21:14:08 --> Form Validation Class Initialized
INFO - 2018-03-30 21:14:08 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:14:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:14:08 --> Helper loaded: url_helper
INFO - 2018-03-30 21:14:08 --> Model Class Initialized
INFO - 2018-03-30 21:14:08 --> Model Class Initialized
INFO - 2018-03-30 21:14:08 --> Model Class Initialized
INFO - 2018-03-30 21:14:30 --> Config Class Initialized
INFO - 2018-03-30 21:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:14:30 --> Utf8 Class Initialized
INFO - 2018-03-30 21:14:30 --> URI Class Initialized
INFO - 2018-03-30 21:14:30 --> Router Class Initialized
INFO - 2018-03-30 21:14:30 --> Output Class Initialized
INFO - 2018-03-30 21:14:30 --> Security Class Initialized
DEBUG - 2018-03-30 21:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:14:30 --> Input Class Initialized
INFO - 2018-03-30 21:14:30 --> Language Class Initialized
INFO - 2018-03-30 21:14:30 --> Loader Class Initialized
INFO - 2018-03-30 21:14:30 --> Helper loaded: common_helper
INFO - 2018-03-30 21:14:30 --> Database Driver Class Initialized
INFO - 2018-03-30 21:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:14:30 --> Email Class Initialized
INFO - 2018-03-30 21:14:30 --> Controller Class Initialized
INFO - 2018-03-30 21:14:30 --> Helper loaded: form_helper
INFO - 2018-03-30 21:14:30 --> Form Validation Class Initialized
INFO - 2018-03-30 21:14:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:14:30 --> Helper loaded: url_helper
INFO - 2018-03-30 21:14:30 --> Model Class Initialized
INFO - 2018-03-30 21:14:30 --> Model Class Initialized
INFO - 2018-03-30 21:14:30 --> Model Class Initialized
INFO - 2018-03-30 21:14:30 --> Config Class Initialized
INFO - 2018-03-30 21:14:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:14:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:14:30 --> Utf8 Class Initialized
INFO - 2018-03-30 21:14:30 --> URI Class Initialized
INFO - 2018-03-30 21:14:30 --> Router Class Initialized
INFO - 2018-03-30 21:14:30 --> Output Class Initialized
INFO - 2018-03-30 21:14:30 --> Security Class Initialized
DEBUG - 2018-03-30 21:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:14:30 --> Input Class Initialized
INFO - 2018-03-30 21:14:30 --> Language Class Initialized
INFO - 2018-03-30 21:14:30 --> Loader Class Initialized
INFO - 2018-03-30 21:14:30 --> Helper loaded: common_helper
INFO - 2018-03-30 21:14:30 --> Database Driver Class Initialized
INFO - 2018-03-30 21:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:14:30 --> Email Class Initialized
INFO - 2018-03-30 21:14:30 --> Controller Class Initialized
INFO - 2018-03-30 21:14:30 --> Helper loaded: form_helper
INFO - 2018-03-30 21:14:30 --> Form Validation Class Initialized
INFO - 2018-03-30 21:14:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:14:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:14:30 --> Helper loaded: url_helper
INFO - 2018-03-30 21:14:30 --> Model Class Initialized
INFO - 2018-03-30 21:14:30 --> Model Class Initialized
INFO - 2018-03-30 21:14:30 --> Model Class Initialized
INFO - 2018-03-30 21:14:34 --> Config Class Initialized
INFO - 2018-03-30 21:14:34 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:14:34 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:14:34 --> Utf8 Class Initialized
INFO - 2018-03-30 21:14:34 --> URI Class Initialized
INFO - 2018-03-30 21:14:34 --> Router Class Initialized
INFO - 2018-03-30 21:14:35 --> Output Class Initialized
INFO - 2018-03-30 21:14:35 --> Security Class Initialized
DEBUG - 2018-03-30 21:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:14:35 --> Input Class Initialized
INFO - 2018-03-30 21:14:35 --> Language Class Initialized
INFO - 2018-03-30 21:14:35 --> Loader Class Initialized
INFO - 2018-03-30 21:14:35 --> Helper loaded: common_helper
INFO - 2018-03-30 21:14:35 --> Database Driver Class Initialized
INFO - 2018-03-30 21:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:14:35 --> Email Class Initialized
INFO - 2018-03-30 21:14:35 --> Controller Class Initialized
INFO - 2018-03-30 21:14:35 --> Helper loaded: form_helper
INFO - 2018-03-30 21:14:35 --> Form Validation Class Initialized
INFO - 2018-03-30 21:14:35 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:14:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:14:35 --> Helper loaded: url_helper
INFO - 2018-03-30 21:14:35 --> Model Class Initialized
INFO - 2018-03-30 21:14:35 --> Model Class Initialized
INFO - 2018-03-30 21:14:35 --> Model Class Initialized
INFO - 2018-03-30 21:16:27 --> Config Class Initialized
INFO - 2018-03-30 21:16:27 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:16:27 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:16:27 --> Utf8 Class Initialized
INFO - 2018-03-30 21:16:27 --> URI Class Initialized
INFO - 2018-03-30 21:16:27 --> Router Class Initialized
INFO - 2018-03-30 21:16:27 --> Output Class Initialized
INFO - 2018-03-30 21:16:27 --> Security Class Initialized
DEBUG - 2018-03-30 21:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:16:27 --> Input Class Initialized
INFO - 2018-03-30 21:16:27 --> Language Class Initialized
INFO - 2018-03-30 21:16:27 --> Loader Class Initialized
INFO - 2018-03-30 21:16:27 --> Helper loaded: common_helper
INFO - 2018-03-30 21:16:27 --> Database Driver Class Initialized
INFO - 2018-03-30 21:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:16:27 --> Email Class Initialized
INFO - 2018-03-30 21:16:27 --> Controller Class Initialized
INFO - 2018-03-30 21:16:27 --> Helper loaded: form_helper
INFO - 2018-03-30 21:16:27 --> Form Validation Class Initialized
INFO - 2018-03-30 21:16:27 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:16:27 --> Helper loaded: url_helper
INFO - 2018-03-30 21:16:27 --> Model Class Initialized
INFO - 2018-03-30 21:16:27 --> Model Class Initialized
INFO - 2018-03-30 21:16:27 --> Model Class Initialized
INFO - 2018-03-30 21:16:32 --> Config Class Initialized
INFO - 2018-03-30 21:16:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:16:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:16:32 --> Utf8 Class Initialized
INFO - 2018-03-30 21:16:32 --> URI Class Initialized
INFO - 2018-03-30 21:16:32 --> Router Class Initialized
INFO - 2018-03-30 21:16:32 --> Output Class Initialized
INFO - 2018-03-30 21:16:32 --> Security Class Initialized
DEBUG - 2018-03-30 21:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:16:32 --> Input Class Initialized
INFO - 2018-03-30 21:16:32 --> Language Class Initialized
INFO - 2018-03-30 21:16:32 --> Loader Class Initialized
INFO - 2018-03-30 21:16:32 --> Helper loaded: common_helper
INFO - 2018-03-30 21:16:32 --> Database Driver Class Initialized
INFO - 2018-03-30 21:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:16:32 --> Email Class Initialized
INFO - 2018-03-30 21:16:32 --> Controller Class Initialized
INFO - 2018-03-30 21:16:32 --> Helper loaded: form_helper
INFO - 2018-03-30 21:16:32 --> Form Validation Class Initialized
INFO - 2018-03-30 21:16:32 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:16:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:16:32 --> Helper loaded: url_helper
INFO - 2018-03-30 21:16:32 --> Model Class Initialized
INFO - 2018-03-30 21:16:32 --> Model Class Initialized
INFO - 2018-03-30 21:16:32 --> Model Class Initialized
INFO - 2018-03-30 21:16:33 --> Config Class Initialized
INFO - 2018-03-30 21:16:33 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:16:33 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:16:33 --> Utf8 Class Initialized
INFO - 2018-03-30 21:16:33 --> URI Class Initialized
INFO - 2018-03-30 21:16:33 --> Router Class Initialized
INFO - 2018-03-30 21:16:33 --> Output Class Initialized
INFO - 2018-03-30 21:16:33 --> Security Class Initialized
DEBUG - 2018-03-30 21:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:16:33 --> Input Class Initialized
INFO - 2018-03-30 21:16:33 --> Language Class Initialized
INFO - 2018-03-30 21:16:33 --> Loader Class Initialized
INFO - 2018-03-30 21:16:33 --> Helper loaded: common_helper
INFO - 2018-03-30 21:16:33 --> Database Driver Class Initialized
INFO - 2018-03-30 21:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:16:33 --> Email Class Initialized
INFO - 2018-03-30 21:16:33 --> Controller Class Initialized
INFO - 2018-03-30 21:16:33 --> Helper loaded: form_helper
INFO - 2018-03-30 21:16:33 --> Form Validation Class Initialized
INFO - 2018-03-30 21:16:33 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:16:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:16:33 --> Helper loaded: url_helper
INFO - 2018-03-30 21:16:33 --> Model Class Initialized
INFO - 2018-03-30 21:16:33 --> Model Class Initialized
INFO - 2018-03-30 21:16:33 --> Model Class Initialized
INFO - 2018-03-30 21:16:35 --> Config Class Initialized
INFO - 2018-03-30 21:16:35 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:16:35 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:16:35 --> Utf8 Class Initialized
INFO - 2018-03-30 21:16:35 --> URI Class Initialized
INFO - 2018-03-30 21:16:35 --> Router Class Initialized
INFO - 2018-03-30 21:16:35 --> Output Class Initialized
INFO - 2018-03-30 21:16:35 --> Security Class Initialized
DEBUG - 2018-03-30 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:16:35 --> Input Class Initialized
INFO - 2018-03-30 21:16:35 --> Language Class Initialized
INFO - 2018-03-30 21:16:35 --> Loader Class Initialized
INFO - 2018-03-30 21:16:35 --> Helper loaded: common_helper
INFO - 2018-03-30 21:16:35 --> Database Driver Class Initialized
INFO - 2018-03-30 21:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:16:35 --> Email Class Initialized
INFO - 2018-03-30 21:16:35 --> Controller Class Initialized
INFO - 2018-03-30 21:16:35 --> Helper loaded: form_helper
INFO - 2018-03-30 21:16:35 --> Form Validation Class Initialized
INFO - 2018-03-30 21:16:35 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:16:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:16:35 --> Helper loaded: url_helper
INFO - 2018-03-30 21:16:35 --> Model Class Initialized
INFO - 2018-03-30 21:16:35 --> Model Class Initialized
INFO - 2018-03-30 21:16:35 --> Model Class Initialized
INFO - 2018-03-30 21:16:54 --> Config Class Initialized
INFO - 2018-03-30 21:16:54 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:16:54 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:16:54 --> Utf8 Class Initialized
INFO - 2018-03-30 21:16:54 --> URI Class Initialized
INFO - 2018-03-30 21:16:54 --> Router Class Initialized
INFO - 2018-03-30 21:16:54 --> Output Class Initialized
INFO - 2018-03-30 21:16:54 --> Security Class Initialized
DEBUG - 2018-03-30 21:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:16:54 --> Input Class Initialized
INFO - 2018-03-30 21:16:54 --> Language Class Initialized
INFO - 2018-03-30 21:16:54 --> Loader Class Initialized
INFO - 2018-03-30 21:16:54 --> Helper loaded: common_helper
INFO - 2018-03-30 21:16:54 --> Database Driver Class Initialized
INFO - 2018-03-30 21:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:16:54 --> Email Class Initialized
INFO - 2018-03-30 21:16:54 --> Controller Class Initialized
INFO - 2018-03-30 21:16:54 --> Helper loaded: form_helper
INFO - 2018-03-30 21:16:54 --> Form Validation Class Initialized
INFO - 2018-03-30 21:16:54 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:16:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:16:54 --> Helper loaded: url_helper
INFO - 2018-03-30 21:16:54 --> Model Class Initialized
INFO - 2018-03-30 21:16:54 --> Model Class Initialized
INFO - 2018-03-30 21:16:54 --> Model Class Initialized
INFO - 2018-03-30 21:16:56 --> Config Class Initialized
INFO - 2018-03-30 21:16:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:16:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:16:56 --> Utf8 Class Initialized
INFO - 2018-03-30 21:16:56 --> URI Class Initialized
INFO - 2018-03-30 21:16:56 --> Router Class Initialized
INFO - 2018-03-30 21:16:56 --> Output Class Initialized
INFO - 2018-03-30 21:16:56 --> Security Class Initialized
DEBUG - 2018-03-30 21:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:16:56 --> Input Class Initialized
INFO - 2018-03-30 21:16:56 --> Language Class Initialized
INFO - 2018-03-30 21:16:56 --> Loader Class Initialized
INFO - 2018-03-30 21:16:56 --> Helper loaded: common_helper
INFO - 2018-03-30 21:16:56 --> Database Driver Class Initialized
INFO - 2018-03-30 21:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:16:56 --> Email Class Initialized
INFO - 2018-03-30 21:16:56 --> Controller Class Initialized
INFO - 2018-03-30 21:16:56 --> Helper loaded: form_helper
INFO - 2018-03-30 21:16:56 --> Form Validation Class Initialized
INFO - 2018-03-30 21:16:56 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:16:56 --> Helper loaded: url_helper
INFO - 2018-03-30 21:16:56 --> Model Class Initialized
INFO - 2018-03-30 21:16:56 --> Model Class Initialized
INFO - 2018-03-30 21:16:56 --> Model Class Initialized
INFO - 2018-03-30 21:17:01 --> Config Class Initialized
INFO - 2018-03-30 21:17:01 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:17:01 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:17:01 --> Utf8 Class Initialized
INFO - 2018-03-30 21:17:01 --> URI Class Initialized
INFO - 2018-03-30 21:17:01 --> Router Class Initialized
INFO - 2018-03-30 21:17:01 --> Output Class Initialized
INFO - 2018-03-30 21:17:01 --> Security Class Initialized
DEBUG - 2018-03-30 21:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:17:01 --> Input Class Initialized
INFO - 2018-03-30 21:17:01 --> Language Class Initialized
INFO - 2018-03-30 21:17:01 --> Loader Class Initialized
INFO - 2018-03-30 21:17:01 --> Helper loaded: common_helper
INFO - 2018-03-30 21:17:01 --> Database Driver Class Initialized
INFO - 2018-03-30 21:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:17:01 --> Email Class Initialized
INFO - 2018-03-30 21:17:01 --> Controller Class Initialized
INFO - 2018-03-30 21:17:01 --> Helper loaded: form_helper
INFO - 2018-03-30 21:17:01 --> Form Validation Class Initialized
INFO - 2018-03-30 21:17:01 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:17:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:17:01 --> Helper loaded: url_helper
INFO - 2018-03-30 21:17:01 --> Model Class Initialized
INFO - 2018-03-30 21:17:01 --> Model Class Initialized
INFO - 2018-03-30 21:17:01 --> Model Class Initialized
INFO - 2018-03-30 21:17:07 --> Config Class Initialized
INFO - 2018-03-30 21:17:07 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:17:07 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:17:07 --> Utf8 Class Initialized
INFO - 2018-03-30 21:17:07 --> URI Class Initialized
INFO - 2018-03-30 21:17:07 --> Router Class Initialized
INFO - 2018-03-30 21:17:07 --> Output Class Initialized
INFO - 2018-03-30 21:17:07 --> Security Class Initialized
DEBUG - 2018-03-30 21:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:17:07 --> Input Class Initialized
INFO - 2018-03-30 21:17:07 --> Language Class Initialized
INFO - 2018-03-30 21:17:07 --> Loader Class Initialized
INFO - 2018-03-30 21:17:07 --> Helper loaded: common_helper
INFO - 2018-03-30 21:17:07 --> Database Driver Class Initialized
INFO - 2018-03-30 21:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:17:07 --> Email Class Initialized
INFO - 2018-03-30 21:17:07 --> Controller Class Initialized
INFO - 2018-03-30 21:17:07 --> Helper loaded: form_helper
INFO - 2018-03-30 21:17:07 --> Form Validation Class Initialized
INFO - 2018-03-30 21:17:07 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:17:07 --> Helper loaded: url_helper
INFO - 2018-03-30 21:17:07 --> Model Class Initialized
INFO - 2018-03-30 21:17:07 --> Model Class Initialized
INFO - 2018-03-30 21:17:07 --> Model Class Initialized
INFO - 2018-03-30 21:17:09 --> Config Class Initialized
INFO - 2018-03-30 21:17:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:17:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:17:09 --> Utf8 Class Initialized
INFO - 2018-03-30 21:17:09 --> URI Class Initialized
INFO - 2018-03-30 21:17:09 --> Router Class Initialized
INFO - 2018-03-30 21:17:09 --> Output Class Initialized
INFO - 2018-03-30 21:17:09 --> Security Class Initialized
DEBUG - 2018-03-30 21:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:17:09 --> Input Class Initialized
INFO - 2018-03-30 21:17:09 --> Language Class Initialized
INFO - 2018-03-30 21:17:09 --> Loader Class Initialized
INFO - 2018-03-30 21:17:09 --> Helper loaded: common_helper
INFO - 2018-03-30 21:17:09 --> Database Driver Class Initialized
INFO - 2018-03-30 21:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:17:09 --> Email Class Initialized
INFO - 2018-03-30 21:17:09 --> Controller Class Initialized
INFO - 2018-03-30 21:17:09 --> Helper loaded: form_helper
INFO - 2018-03-30 21:17:09 --> Form Validation Class Initialized
INFO - 2018-03-30 21:17:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:17:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:17:09 --> Helper loaded: url_helper
INFO - 2018-03-30 21:17:09 --> Model Class Initialized
INFO - 2018-03-30 21:17:09 --> Model Class Initialized
INFO - 2018-03-30 21:17:09 --> Model Class Initialized
INFO - 2018-03-30 21:17:11 --> Config Class Initialized
INFO - 2018-03-30 21:17:11 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:17:12 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:17:12 --> Utf8 Class Initialized
INFO - 2018-03-30 21:17:12 --> URI Class Initialized
INFO - 2018-03-30 21:17:12 --> Router Class Initialized
INFO - 2018-03-30 21:17:12 --> Output Class Initialized
INFO - 2018-03-30 21:17:12 --> Security Class Initialized
DEBUG - 2018-03-30 21:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:17:12 --> Input Class Initialized
INFO - 2018-03-30 21:17:12 --> Language Class Initialized
INFO - 2018-03-30 21:17:12 --> Loader Class Initialized
INFO - 2018-03-30 21:17:12 --> Helper loaded: common_helper
INFO - 2018-03-30 21:17:12 --> Database Driver Class Initialized
INFO - 2018-03-30 21:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:17:12 --> Email Class Initialized
INFO - 2018-03-30 21:17:12 --> Controller Class Initialized
INFO - 2018-03-30 21:17:12 --> Helper loaded: form_helper
INFO - 2018-03-30 21:17:12 --> Form Validation Class Initialized
INFO - 2018-03-30 21:17:12 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:17:12 --> Helper loaded: url_helper
INFO - 2018-03-30 21:17:12 --> Model Class Initialized
INFO - 2018-03-30 21:17:12 --> Model Class Initialized
INFO - 2018-03-30 21:17:12 --> Model Class Initialized
INFO - 2018-03-30 21:17:25 --> Config Class Initialized
INFO - 2018-03-30 21:17:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:17:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:17:25 --> Utf8 Class Initialized
INFO - 2018-03-30 21:17:25 --> URI Class Initialized
INFO - 2018-03-30 21:17:25 --> Router Class Initialized
INFO - 2018-03-30 21:17:25 --> Output Class Initialized
INFO - 2018-03-30 21:17:25 --> Security Class Initialized
DEBUG - 2018-03-30 21:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:17:25 --> Input Class Initialized
INFO - 2018-03-30 21:17:25 --> Language Class Initialized
INFO - 2018-03-30 21:17:25 --> Loader Class Initialized
INFO - 2018-03-30 21:17:25 --> Helper loaded: common_helper
INFO - 2018-03-30 21:17:25 --> Database Driver Class Initialized
INFO - 2018-03-30 21:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:17:25 --> Email Class Initialized
INFO - 2018-03-30 21:17:25 --> Controller Class Initialized
INFO - 2018-03-30 21:17:25 --> Helper loaded: form_helper
INFO - 2018-03-30 21:17:25 --> Form Validation Class Initialized
INFO - 2018-03-30 21:17:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:17:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:17:25 --> Helper loaded: url_helper
INFO - 2018-03-30 21:17:25 --> Model Class Initialized
INFO - 2018-03-30 21:17:25 --> Model Class Initialized
INFO - 2018-03-30 21:17:25 --> Model Class Initialized
INFO - 2018-03-30 21:18:02 --> Config Class Initialized
INFO - 2018-03-30 21:18:02 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:18:02 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:18:02 --> Utf8 Class Initialized
INFO - 2018-03-30 21:18:02 --> URI Class Initialized
INFO - 2018-03-30 21:18:02 --> Router Class Initialized
INFO - 2018-03-30 21:18:02 --> Output Class Initialized
INFO - 2018-03-30 21:18:02 --> Security Class Initialized
DEBUG - 2018-03-30 21:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:18:02 --> Input Class Initialized
INFO - 2018-03-30 21:18:02 --> Language Class Initialized
INFO - 2018-03-30 21:18:02 --> Loader Class Initialized
INFO - 2018-03-30 21:18:02 --> Helper loaded: common_helper
INFO - 2018-03-30 21:18:02 --> Database Driver Class Initialized
INFO - 2018-03-30 21:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:18:02 --> Email Class Initialized
INFO - 2018-03-30 21:18:02 --> Controller Class Initialized
INFO - 2018-03-30 21:18:02 --> Helper loaded: form_helper
INFO - 2018-03-30 21:18:02 --> Form Validation Class Initialized
INFO - 2018-03-30 21:18:02 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:18:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:18:02 --> Helper loaded: url_helper
INFO - 2018-03-30 21:18:02 --> Model Class Initialized
INFO - 2018-03-30 21:18:02 --> Model Class Initialized
INFO - 2018-03-30 21:18:02 --> Model Class Initialized
INFO - 2018-03-30 21:18:03 --> Config Class Initialized
INFO - 2018-03-30 21:18:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:18:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:18:03 --> Utf8 Class Initialized
INFO - 2018-03-30 21:18:03 --> URI Class Initialized
INFO - 2018-03-30 21:18:03 --> Router Class Initialized
INFO - 2018-03-30 21:18:03 --> Output Class Initialized
INFO - 2018-03-30 21:18:03 --> Security Class Initialized
DEBUG - 2018-03-30 21:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:18:03 --> Input Class Initialized
INFO - 2018-03-30 21:18:03 --> Language Class Initialized
INFO - 2018-03-30 21:18:03 --> Loader Class Initialized
INFO - 2018-03-30 21:18:03 --> Helper loaded: common_helper
INFO - 2018-03-30 21:18:03 --> Database Driver Class Initialized
INFO - 2018-03-30 21:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:18:03 --> Email Class Initialized
INFO - 2018-03-30 21:18:03 --> Controller Class Initialized
INFO - 2018-03-30 21:18:03 --> Helper loaded: form_helper
INFO - 2018-03-30 21:18:03 --> Form Validation Class Initialized
INFO - 2018-03-30 21:18:03 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:18:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:18:03 --> Helper loaded: url_helper
INFO - 2018-03-30 21:18:03 --> Model Class Initialized
INFO - 2018-03-30 21:18:03 --> Model Class Initialized
INFO - 2018-03-30 21:18:03 --> Model Class Initialized
INFO - 2018-03-30 21:18:20 --> Config Class Initialized
INFO - 2018-03-30 21:18:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:18:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:18:20 --> Utf8 Class Initialized
INFO - 2018-03-30 21:18:20 --> URI Class Initialized
INFO - 2018-03-30 21:18:20 --> Router Class Initialized
INFO - 2018-03-30 21:18:20 --> Output Class Initialized
INFO - 2018-03-30 21:18:20 --> Security Class Initialized
DEBUG - 2018-03-30 21:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:18:20 --> Input Class Initialized
INFO - 2018-03-30 21:18:20 --> Language Class Initialized
INFO - 2018-03-30 21:18:20 --> Loader Class Initialized
INFO - 2018-03-30 21:18:20 --> Helper loaded: common_helper
INFO - 2018-03-30 21:18:20 --> Database Driver Class Initialized
INFO - 2018-03-30 21:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:18:20 --> Email Class Initialized
INFO - 2018-03-30 21:18:20 --> Controller Class Initialized
INFO - 2018-03-30 21:18:20 --> Helper loaded: form_helper
INFO - 2018-03-30 21:18:20 --> Form Validation Class Initialized
INFO - 2018-03-30 21:18:20 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:18:20 --> Helper loaded: url_helper
INFO - 2018-03-30 21:18:20 --> Model Class Initialized
INFO - 2018-03-30 21:18:20 --> Model Class Initialized
INFO - 2018-03-30 21:18:20 --> Model Class Initialized
INFO - 2018-03-30 21:20:08 --> Config Class Initialized
INFO - 2018-03-30 21:20:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:20:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:20:08 --> Utf8 Class Initialized
INFO - 2018-03-30 21:20:09 --> URI Class Initialized
INFO - 2018-03-30 21:20:09 --> Router Class Initialized
INFO - 2018-03-30 21:20:09 --> Output Class Initialized
INFO - 2018-03-30 21:20:09 --> Security Class Initialized
DEBUG - 2018-03-30 21:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:20:09 --> Input Class Initialized
INFO - 2018-03-30 21:20:09 --> Language Class Initialized
INFO - 2018-03-30 21:20:09 --> Loader Class Initialized
INFO - 2018-03-30 21:20:09 --> Helper loaded: common_helper
INFO - 2018-03-30 21:20:09 --> Database Driver Class Initialized
INFO - 2018-03-30 21:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:20:09 --> Email Class Initialized
INFO - 2018-03-30 21:20:09 --> Controller Class Initialized
INFO - 2018-03-30 21:20:09 --> Helper loaded: form_helper
INFO - 2018-03-30 21:20:09 --> Form Validation Class Initialized
INFO - 2018-03-30 21:20:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:20:09 --> Helper loaded: url_helper
INFO - 2018-03-30 21:20:09 --> Model Class Initialized
INFO - 2018-03-30 21:20:09 --> Model Class Initialized
INFO - 2018-03-30 21:20:09 --> Model Class Initialized
INFO - 2018-03-30 21:20:13 --> Config Class Initialized
INFO - 2018-03-30 21:20:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:20:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:20:13 --> Utf8 Class Initialized
INFO - 2018-03-30 21:20:13 --> URI Class Initialized
INFO - 2018-03-30 21:20:13 --> Router Class Initialized
INFO - 2018-03-30 21:20:13 --> Output Class Initialized
INFO - 2018-03-30 21:20:13 --> Security Class Initialized
DEBUG - 2018-03-30 21:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:20:13 --> Input Class Initialized
INFO - 2018-03-30 21:20:13 --> Language Class Initialized
INFO - 2018-03-30 21:20:13 --> Loader Class Initialized
INFO - 2018-03-30 21:20:13 --> Helper loaded: common_helper
INFO - 2018-03-30 21:20:13 --> Database Driver Class Initialized
INFO - 2018-03-30 21:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:20:13 --> Email Class Initialized
INFO - 2018-03-30 21:20:13 --> Controller Class Initialized
INFO - 2018-03-30 21:20:13 --> Helper loaded: form_helper
INFO - 2018-03-30 21:20:13 --> Form Validation Class Initialized
INFO - 2018-03-30 21:20:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:20:13 --> Helper loaded: url_helper
INFO - 2018-03-30 21:20:13 --> Model Class Initialized
INFO - 2018-03-30 21:20:13 --> Model Class Initialized
INFO - 2018-03-30 21:20:13 --> Model Class Initialized
INFO - 2018-03-30 21:20:15 --> Config Class Initialized
INFO - 2018-03-30 21:20:15 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:20:15 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:20:15 --> Utf8 Class Initialized
INFO - 2018-03-30 21:20:15 --> URI Class Initialized
INFO - 2018-03-30 21:20:15 --> Router Class Initialized
INFO - 2018-03-30 21:20:15 --> Output Class Initialized
INFO - 2018-03-30 21:20:15 --> Security Class Initialized
DEBUG - 2018-03-30 21:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:20:15 --> Input Class Initialized
INFO - 2018-03-30 21:20:15 --> Language Class Initialized
INFO - 2018-03-30 21:20:15 --> Loader Class Initialized
INFO - 2018-03-30 21:20:15 --> Helper loaded: common_helper
INFO - 2018-03-30 21:20:15 --> Database Driver Class Initialized
INFO - 2018-03-30 21:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:20:15 --> Email Class Initialized
INFO - 2018-03-30 21:20:15 --> Controller Class Initialized
INFO - 2018-03-30 21:20:15 --> Helper loaded: form_helper
INFO - 2018-03-30 21:20:15 --> Form Validation Class Initialized
INFO - 2018-03-30 21:20:15 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:20:15 --> Helper loaded: url_helper
INFO - 2018-03-30 21:20:15 --> Model Class Initialized
INFO - 2018-03-30 21:20:15 --> Model Class Initialized
INFO - 2018-03-30 21:20:15 --> Model Class Initialized
INFO - 2018-03-30 21:20:29 --> Config Class Initialized
INFO - 2018-03-30 21:20:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:20:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:20:29 --> Utf8 Class Initialized
INFO - 2018-03-30 21:20:29 --> URI Class Initialized
INFO - 2018-03-30 21:20:29 --> Router Class Initialized
INFO - 2018-03-30 21:20:29 --> Output Class Initialized
INFO - 2018-03-30 21:20:29 --> Security Class Initialized
DEBUG - 2018-03-30 21:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:20:29 --> Input Class Initialized
INFO - 2018-03-30 21:20:29 --> Language Class Initialized
INFO - 2018-03-30 21:20:29 --> Loader Class Initialized
INFO - 2018-03-30 21:20:29 --> Helper loaded: common_helper
INFO - 2018-03-30 21:20:29 --> Database Driver Class Initialized
INFO - 2018-03-30 21:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:20:29 --> Email Class Initialized
INFO - 2018-03-30 21:20:29 --> Controller Class Initialized
INFO - 2018-03-30 21:20:29 --> Helper loaded: form_helper
INFO - 2018-03-30 21:20:29 --> Form Validation Class Initialized
INFO - 2018-03-30 21:20:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:20:29 --> Helper loaded: url_helper
INFO - 2018-03-30 21:20:29 --> Model Class Initialized
INFO - 2018-03-30 21:20:29 --> Model Class Initialized
INFO - 2018-03-30 21:20:29 --> Model Class Initialized
INFO - 2018-03-30 21:20:29 --> Config Class Initialized
INFO - 2018-03-30 21:20:29 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:20:29 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:20:29 --> Utf8 Class Initialized
INFO - 2018-03-30 21:20:29 --> URI Class Initialized
INFO - 2018-03-30 21:20:29 --> Router Class Initialized
INFO - 2018-03-30 21:20:29 --> Output Class Initialized
INFO - 2018-03-30 21:20:29 --> Security Class Initialized
DEBUG - 2018-03-30 21:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:20:29 --> Input Class Initialized
INFO - 2018-03-30 21:20:29 --> Language Class Initialized
INFO - 2018-03-30 21:20:29 --> Loader Class Initialized
INFO - 2018-03-30 21:20:29 --> Helper loaded: common_helper
INFO - 2018-03-30 21:20:29 --> Database Driver Class Initialized
INFO - 2018-03-30 21:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:20:29 --> Email Class Initialized
INFO - 2018-03-30 21:20:29 --> Controller Class Initialized
INFO - 2018-03-30 21:20:29 --> Helper loaded: form_helper
INFO - 2018-03-30 21:20:29 --> Form Validation Class Initialized
INFO - 2018-03-30 21:20:29 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:20:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:20:29 --> Helper loaded: url_helper
INFO - 2018-03-30 21:20:29 --> Model Class Initialized
INFO - 2018-03-30 21:20:29 --> Model Class Initialized
INFO - 2018-03-30 21:20:29 --> Model Class Initialized
INFO - 2018-03-30 21:21:22 --> Config Class Initialized
INFO - 2018-03-30 21:21:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:21:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:21:22 --> Utf8 Class Initialized
INFO - 2018-03-30 21:21:22 --> URI Class Initialized
INFO - 2018-03-30 21:21:22 --> Router Class Initialized
INFO - 2018-03-30 21:21:22 --> Output Class Initialized
INFO - 2018-03-30 21:21:22 --> Security Class Initialized
DEBUG - 2018-03-30 21:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:21:22 --> Input Class Initialized
INFO - 2018-03-30 21:21:22 --> Language Class Initialized
INFO - 2018-03-30 21:21:22 --> Loader Class Initialized
INFO - 2018-03-30 21:21:22 --> Helper loaded: common_helper
INFO - 2018-03-30 21:21:22 --> Database Driver Class Initialized
INFO - 2018-03-30 21:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:21:22 --> Email Class Initialized
INFO - 2018-03-30 21:21:22 --> Controller Class Initialized
INFO - 2018-03-30 21:21:22 --> Helper loaded: form_helper
INFO - 2018-03-30 21:21:22 --> Form Validation Class Initialized
INFO - 2018-03-30 21:21:22 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:21:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:21:22 --> Helper loaded: url_helper
INFO - 2018-03-30 21:21:22 --> Model Class Initialized
INFO - 2018-03-30 21:21:22 --> Model Class Initialized
INFO - 2018-03-30 21:21:22 --> Model Class Initialized
INFO - 2018-03-30 21:21:25 --> Config Class Initialized
INFO - 2018-03-30 21:21:25 --> Hooks Class Initialized
DEBUG - 2018-03-30 21:21:25 --> UTF-8 Support Enabled
INFO - 2018-03-30 21:21:25 --> Utf8 Class Initialized
INFO - 2018-03-30 21:21:25 --> URI Class Initialized
INFO - 2018-03-30 21:21:25 --> Router Class Initialized
INFO - 2018-03-30 21:21:25 --> Output Class Initialized
INFO - 2018-03-30 21:21:25 --> Security Class Initialized
DEBUG - 2018-03-30 21:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 21:21:25 --> Input Class Initialized
INFO - 2018-03-30 21:21:25 --> Language Class Initialized
INFO - 2018-03-30 21:21:25 --> Loader Class Initialized
INFO - 2018-03-30 21:21:25 --> Helper loaded: common_helper
INFO - 2018-03-30 21:21:25 --> Database Driver Class Initialized
INFO - 2018-03-30 21:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 21:21:25 --> Email Class Initialized
INFO - 2018-03-30 21:21:25 --> Controller Class Initialized
INFO - 2018-03-30 21:21:25 --> Helper loaded: form_helper
INFO - 2018-03-30 21:21:25 --> Form Validation Class Initialized
INFO - 2018-03-30 21:21:25 --> Helper loaded: email_helper
DEBUG - 2018-03-30 21:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 21:21:25 --> Helper loaded: url_helper
INFO - 2018-03-30 21:21:25 --> Model Class Initialized
INFO - 2018-03-30 21:21:25 --> Model Class Initialized
INFO - 2018-03-30 21:21:25 --> Model Class Initialized
INFO - 2018-03-30 22:49:57 --> Config Class Initialized
INFO - 2018-03-30 22:49:57 --> Hooks Class Initialized
DEBUG - 2018-03-30 22:49:57 --> UTF-8 Support Enabled
INFO - 2018-03-30 22:49:57 --> Utf8 Class Initialized
INFO - 2018-03-30 22:49:57 --> URI Class Initialized
INFO - 2018-03-30 22:49:57 --> Router Class Initialized
INFO - 2018-03-30 22:49:57 --> Output Class Initialized
INFO - 2018-03-30 22:49:57 --> Security Class Initialized
DEBUG - 2018-03-30 22:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 22:49:57 --> Input Class Initialized
INFO - 2018-03-30 22:49:57 --> Language Class Initialized
INFO - 2018-03-30 22:49:57 --> Loader Class Initialized
INFO - 2018-03-30 22:49:57 --> Helper loaded: common_helper
INFO - 2018-03-30 22:49:57 --> Database Driver Class Initialized
INFO - 2018-03-30 22:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 22:49:57 --> Email Class Initialized
INFO - 2018-03-30 22:49:57 --> Controller Class Initialized
INFO - 2018-03-30 22:49:57 --> Helper loaded: form_helper
INFO - 2018-03-30 22:49:57 --> Form Validation Class Initialized
INFO - 2018-03-30 22:49:57 --> Helper loaded: email_helper
DEBUG - 2018-03-30 22:49:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 22:49:57 --> Helper loaded: url_helper
INFO - 2018-03-30 22:49:57 --> Model Class Initialized
INFO - 2018-03-30 22:49:57 --> Model Class Initialized
INFO - 2018-03-30 22:49:57 --> Model Class Initialized
INFO - 2018-03-30 22:50:30 --> Config Class Initialized
INFO - 2018-03-30 22:50:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 22:50:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 22:50:30 --> Utf8 Class Initialized
INFO - 2018-03-30 22:50:30 --> URI Class Initialized
INFO - 2018-03-30 22:50:30 --> Router Class Initialized
INFO - 2018-03-30 22:50:30 --> Output Class Initialized
INFO - 2018-03-30 22:50:30 --> Security Class Initialized
DEBUG - 2018-03-30 22:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 22:50:30 --> Input Class Initialized
INFO - 2018-03-30 22:50:30 --> Language Class Initialized
INFO - 2018-03-30 22:50:30 --> Loader Class Initialized
INFO - 2018-03-30 22:50:30 --> Helper loaded: common_helper
INFO - 2018-03-30 22:50:30 --> Database Driver Class Initialized
INFO - 2018-03-30 22:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 22:50:30 --> Email Class Initialized
INFO - 2018-03-30 22:50:30 --> Controller Class Initialized
INFO - 2018-03-30 22:50:30 --> Helper loaded: form_helper
INFO - 2018-03-30 22:50:30 --> Form Validation Class Initialized
INFO - 2018-03-30 22:50:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 22:50:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 22:50:30 --> Helper loaded: url_helper
INFO - 2018-03-30 22:50:30 --> Model Class Initialized
INFO - 2018-03-30 22:50:30 --> Model Class Initialized
INFO - 2018-03-30 22:50:30 --> Model Class Initialized
INFO - 2018-03-30 22:50:55 --> Config Class Initialized
INFO - 2018-03-30 22:50:55 --> Hooks Class Initialized
DEBUG - 2018-03-30 22:50:55 --> UTF-8 Support Enabled
INFO - 2018-03-30 22:50:55 --> Utf8 Class Initialized
INFO - 2018-03-30 22:50:55 --> URI Class Initialized
INFO - 2018-03-30 22:50:55 --> Router Class Initialized
INFO - 2018-03-30 22:50:55 --> Output Class Initialized
INFO - 2018-03-30 22:50:55 --> Security Class Initialized
DEBUG - 2018-03-30 22:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 22:50:55 --> Input Class Initialized
INFO - 2018-03-30 22:50:55 --> Language Class Initialized
INFO - 2018-03-30 22:50:55 --> Loader Class Initialized
INFO - 2018-03-30 22:50:55 --> Helper loaded: common_helper
INFO - 2018-03-30 22:50:55 --> Database Driver Class Initialized
INFO - 2018-03-30 22:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 22:50:55 --> Email Class Initialized
INFO - 2018-03-30 22:50:55 --> Controller Class Initialized
INFO - 2018-03-30 22:50:55 --> Helper loaded: form_helper
INFO - 2018-03-30 22:50:55 --> Form Validation Class Initialized
INFO - 2018-03-30 22:50:55 --> Helper loaded: email_helper
DEBUG - 2018-03-30 22:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 22:50:55 --> Helper loaded: url_helper
INFO - 2018-03-30 22:50:55 --> Model Class Initialized
INFO - 2018-03-30 22:50:55 --> Model Class Initialized
INFO - 2018-03-30 22:50:55 --> Model Class Initialized
INFO - 2018-03-30 23:04:09 --> Config Class Initialized
INFO - 2018-03-30 23:04:09 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:04:09 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:04:09 --> Utf8 Class Initialized
INFO - 2018-03-30 23:04:09 --> URI Class Initialized
INFO - 2018-03-30 23:04:09 --> Router Class Initialized
INFO - 2018-03-30 23:04:09 --> Output Class Initialized
INFO - 2018-03-30 23:04:09 --> Security Class Initialized
DEBUG - 2018-03-30 23:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:04:09 --> Input Class Initialized
INFO - 2018-03-30 23:04:09 --> Language Class Initialized
INFO - 2018-03-30 23:04:09 --> Loader Class Initialized
INFO - 2018-03-30 23:04:09 --> Helper loaded: common_helper
INFO - 2018-03-30 23:04:09 --> Database Driver Class Initialized
INFO - 2018-03-30 23:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:04:09 --> Email Class Initialized
INFO - 2018-03-30 23:04:09 --> Controller Class Initialized
INFO - 2018-03-30 23:04:09 --> Helper loaded: form_helper
INFO - 2018-03-30 23:04:09 --> Form Validation Class Initialized
INFO - 2018-03-30 23:04:09 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:04:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:04:09 --> Helper loaded: url_helper
INFO - 2018-03-30 23:04:09 --> Model Class Initialized
INFO - 2018-03-30 23:04:09 --> Model Class Initialized
INFO - 2018-03-30 23:04:09 --> Model Class Initialized
INFO - 2018-03-30 23:04:56 --> Config Class Initialized
INFO - 2018-03-30 23:04:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:04:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:04:56 --> Utf8 Class Initialized
INFO - 2018-03-30 23:04:56 --> URI Class Initialized
INFO - 2018-03-30 23:04:56 --> Router Class Initialized
INFO - 2018-03-30 23:04:56 --> Output Class Initialized
INFO - 2018-03-30 23:04:56 --> Security Class Initialized
DEBUG - 2018-03-30 23:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:04:56 --> Input Class Initialized
INFO - 2018-03-30 23:04:56 --> Language Class Initialized
INFO - 2018-03-30 23:04:56 --> Loader Class Initialized
INFO - 2018-03-30 23:04:56 --> Helper loaded: common_helper
INFO - 2018-03-30 23:04:56 --> Database Driver Class Initialized
INFO - 2018-03-30 23:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:04:56 --> Email Class Initialized
INFO - 2018-03-30 23:04:56 --> Controller Class Initialized
INFO - 2018-03-30 23:04:56 --> Helper loaded: form_helper
INFO - 2018-03-30 23:04:56 --> Form Validation Class Initialized
INFO - 2018-03-30 23:04:56 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:04:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:04:56 --> Helper loaded: url_helper
INFO - 2018-03-30 23:04:56 --> Model Class Initialized
INFO - 2018-03-30 23:04:56 --> Model Class Initialized
INFO - 2018-03-30 23:04:56 --> Model Class Initialized
INFO - 2018-03-30 23:06:00 --> Config Class Initialized
INFO - 2018-03-30 23:06:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:06:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:06:00 --> Utf8 Class Initialized
INFO - 2018-03-30 23:06:00 --> URI Class Initialized
INFO - 2018-03-30 23:06:00 --> Router Class Initialized
INFO - 2018-03-30 23:06:00 --> Output Class Initialized
INFO - 2018-03-30 23:06:00 --> Security Class Initialized
DEBUG - 2018-03-30 23:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:06:00 --> Input Class Initialized
INFO - 2018-03-30 23:06:00 --> Language Class Initialized
INFO - 2018-03-30 23:06:00 --> Loader Class Initialized
INFO - 2018-03-30 23:06:00 --> Helper loaded: common_helper
INFO - 2018-03-30 23:06:00 --> Database Driver Class Initialized
INFO - 2018-03-30 23:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:06:00 --> Email Class Initialized
INFO - 2018-03-30 23:06:00 --> Controller Class Initialized
INFO - 2018-03-30 23:06:00 --> Helper loaded: form_helper
INFO - 2018-03-30 23:06:00 --> Form Validation Class Initialized
INFO - 2018-03-30 23:06:00 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:06:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:06:00 --> Helper loaded: url_helper
INFO - 2018-03-30 23:06:00 --> Model Class Initialized
INFO - 2018-03-30 23:06:00 --> Model Class Initialized
INFO - 2018-03-30 23:06:00 --> Model Class Initialized
INFO - 2018-03-30 23:06:04 --> Config Class Initialized
INFO - 2018-03-30 23:06:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:06:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:06:04 --> Utf8 Class Initialized
INFO - 2018-03-30 23:06:04 --> URI Class Initialized
INFO - 2018-03-30 23:06:04 --> Router Class Initialized
INFO - 2018-03-30 23:06:04 --> Output Class Initialized
INFO - 2018-03-30 23:06:04 --> Security Class Initialized
DEBUG - 2018-03-30 23:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:06:04 --> Input Class Initialized
INFO - 2018-03-30 23:06:04 --> Language Class Initialized
INFO - 2018-03-30 23:06:04 --> Loader Class Initialized
INFO - 2018-03-30 23:06:04 --> Helper loaded: common_helper
INFO - 2018-03-30 23:06:04 --> Database Driver Class Initialized
INFO - 2018-03-30 23:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:06:04 --> Email Class Initialized
INFO - 2018-03-30 23:06:04 --> Controller Class Initialized
INFO - 2018-03-30 23:06:04 --> Helper loaded: form_helper
INFO - 2018-03-30 23:06:04 --> Form Validation Class Initialized
INFO - 2018-03-30 23:06:04 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:06:04 --> Helper loaded: url_helper
INFO - 2018-03-30 23:06:05 --> Model Class Initialized
INFO - 2018-03-30 23:06:05 --> Model Class Initialized
INFO - 2018-03-30 23:06:05 --> Model Class Initialized
INFO - 2018-03-30 23:06:19 --> Config Class Initialized
INFO - 2018-03-30 23:06:19 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:06:19 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:06:19 --> Utf8 Class Initialized
INFO - 2018-03-30 23:06:19 --> URI Class Initialized
INFO - 2018-03-30 23:06:19 --> Router Class Initialized
INFO - 2018-03-30 23:06:19 --> Output Class Initialized
INFO - 2018-03-30 23:06:19 --> Security Class Initialized
DEBUG - 2018-03-30 23:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:06:19 --> Input Class Initialized
INFO - 2018-03-30 23:06:19 --> Language Class Initialized
INFO - 2018-03-30 23:06:19 --> Loader Class Initialized
INFO - 2018-03-30 23:06:19 --> Helper loaded: common_helper
INFO - 2018-03-30 23:06:19 --> Database Driver Class Initialized
INFO - 2018-03-30 23:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:06:19 --> Email Class Initialized
INFO - 2018-03-30 23:06:19 --> Controller Class Initialized
INFO - 2018-03-30 23:06:19 --> Helper loaded: form_helper
INFO - 2018-03-30 23:06:19 --> Form Validation Class Initialized
INFO - 2018-03-30 23:06:19 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:06:19 --> Helper loaded: url_helper
INFO - 2018-03-30 23:06:19 --> Model Class Initialized
INFO - 2018-03-30 23:06:19 --> Model Class Initialized
INFO - 2018-03-30 23:06:19 --> Model Class Initialized
INFO - 2018-03-30 23:06:21 --> Config Class Initialized
INFO - 2018-03-30 23:06:21 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:06:21 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:06:21 --> Utf8 Class Initialized
INFO - 2018-03-30 23:06:21 --> URI Class Initialized
INFO - 2018-03-30 23:06:21 --> Router Class Initialized
INFO - 2018-03-30 23:06:21 --> Output Class Initialized
INFO - 2018-03-30 23:06:21 --> Security Class Initialized
DEBUG - 2018-03-30 23:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:06:21 --> Input Class Initialized
INFO - 2018-03-30 23:06:21 --> Language Class Initialized
INFO - 2018-03-30 23:06:21 --> Loader Class Initialized
INFO - 2018-03-30 23:06:21 --> Helper loaded: common_helper
INFO - 2018-03-30 23:06:21 --> Database Driver Class Initialized
INFO - 2018-03-30 23:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:06:21 --> Email Class Initialized
INFO - 2018-03-30 23:06:21 --> Controller Class Initialized
INFO - 2018-03-30 23:06:21 --> Helper loaded: form_helper
INFO - 2018-03-30 23:06:21 --> Form Validation Class Initialized
INFO - 2018-03-30 23:06:21 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:06:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:06:21 --> Helper loaded: url_helper
INFO - 2018-03-30 23:06:21 --> Model Class Initialized
INFO - 2018-03-30 23:06:21 --> Model Class Initialized
INFO - 2018-03-30 23:06:21 --> Model Class Initialized
INFO - 2018-03-30 23:06:52 --> Config Class Initialized
INFO - 2018-03-30 23:06:52 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:06:52 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:06:52 --> Utf8 Class Initialized
INFO - 2018-03-30 23:06:52 --> URI Class Initialized
INFO - 2018-03-30 23:06:52 --> Router Class Initialized
INFO - 2018-03-30 23:06:52 --> Output Class Initialized
INFO - 2018-03-30 23:06:52 --> Security Class Initialized
DEBUG - 2018-03-30 23:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:06:52 --> Input Class Initialized
INFO - 2018-03-30 23:06:52 --> Language Class Initialized
INFO - 2018-03-30 23:06:52 --> Loader Class Initialized
INFO - 2018-03-30 23:06:52 --> Helper loaded: common_helper
INFO - 2018-03-30 23:06:52 --> Database Driver Class Initialized
INFO - 2018-03-30 23:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:06:53 --> Email Class Initialized
INFO - 2018-03-30 23:06:53 --> Controller Class Initialized
INFO - 2018-03-30 23:06:53 --> Helper loaded: form_helper
INFO - 2018-03-30 23:06:53 --> Form Validation Class Initialized
INFO - 2018-03-30 23:06:53 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:06:53 --> Helper loaded: url_helper
INFO - 2018-03-30 23:06:53 --> Model Class Initialized
INFO - 2018-03-30 23:06:53 --> Model Class Initialized
INFO - 2018-03-30 23:06:53 --> Model Class Initialized
INFO - 2018-03-30 23:07:00 --> Config Class Initialized
INFO - 2018-03-30 23:07:00 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:07:00 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:07:00 --> Utf8 Class Initialized
INFO - 2018-03-30 23:07:00 --> URI Class Initialized
INFO - 2018-03-30 23:07:00 --> Router Class Initialized
INFO - 2018-03-30 23:07:00 --> Output Class Initialized
INFO - 2018-03-30 23:07:00 --> Security Class Initialized
DEBUG - 2018-03-30 23:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:07:00 --> Input Class Initialized
INFO - 2018-03-30 23:07:00 --> Language Class Initialized
INFO - 2018-03-30 23:07:00 --> Loader Class Initialized
INFO - 2018-03-30 23:07:00 --> Helper loaded: common_helper
INFO - 2018-03-30 23:07:00 --> Database Driver Class Initialized
INFO - 2018-03-30 23:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:07:00 --> Email Class Initialized
INFO - 2018-03-30 23:07:00 --> Controller Class Initialized
INFO - 2018-03-30 23:07:00 --> Helper loaded: form_helper
INFO - 2018-03-30 23:07:00 --> Form Validation Class Initialized
INFO - 2018-03-30 23:07:00 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:07:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:07:00 --> Helper loaded: url_helper
INFO - 2018-03-30 23:07:00 --> Model Class Initialized
INFO - 2018-03-30 23:07:00 --> Model Class Initialized
INFO - 2018-03-30 23:07:00 --> Model Class Initialized
INFO - 2018-03-30 23:07:03 --> Config Class Initialized
INFO - 2018-03-30 23:07:03 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:07:03 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:07:03 --> Utf8 Class Initialized
INFO - 2018-03-30 23:07:03 --> URI Class Initialized
INFO - 2018-03-30 23:07:03 --> Router Class Initialized
INFO - 2018-03-30 23:07:03 --> Output Class Initialized
INFO - 2018-03-30 23:07:03 --> Security Class Initialized
DEBUG - 2018-03-30 23:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:07:03 --> Input Class Initialized
INFO - 2018-03-30 23:07:03 --> Language Class Initialized
INFO - 2018-03-30 23:07:03 --> Loader Class Initialized
INFO - 2018-03-30 23:07:03 --> Helper loaded: common_helper
INFO - 2018-03-30 23:07:03 --> Database Driver Class Initialized
INFO - 2018-03-30 23:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:07:03 --> Email Class Initialized
INFO - 2018-03-30 23:07:03 --> Controller Class Initialized
INFO - 2018-03-30 23:07:03 --> Helper loaded: form_helper
INFO - 2018-03-30 23:07:03 --> Form Validation Class Initialized
INFO - 2018-03-30 23:07:03 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:07:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:07:03 --> Helper loaded: url_helper
INFO - 2018-03-30 23:07:03 --> Model Class Initialized
INFO - 2018-03-30 23:07:03 --> Model Class Initialized
INFO - 2018-03-30 23:07:03 --> Model Class Initialized
INFO - 2018-03-30 23:07:28 --> Config Class Initialized
INFO - 2018-03-30 23:07:28 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:07:28 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:07:28 --> Utf8 Class Initialized
INFO - 2018-03-30 23:07:28 --> URI Class Initialized
INFO - 2018-03-30 23:07:28 --> Router Class Initialized
INFO - 2018-03-30 23:07:28 --> Output Class Initialized
INFO - 2018-03-30 23:07:28 --> Security Class Initialized
DEBUG - 2018-03-30 23:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:07:28 --> Input Class Initialized
INFO - 2018-03-30 23:07:28 --> Language Class Initialized
INFO - 2018-03-30 23:07:28 --> Loader Class Initialized
INFO - 2018-03-30 23:07:28 --> Helper loaded: common_helper
INFO - 2018-03-30 23:07:28 --> Database Driver Class Initialized
INFO - 2018-03-30 23:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:07:28 --> Email Class Initialized
INFO - 2018-03-30 23:07:28 --> Controller Class Initialized
INFO - 2018-03-30 23:07:28 --> Helper loaded: form_helper
INFO - 2018-03-30 23:07:28 --> Form Validation Class Initialized
INFO - 2018-03-30 23:07:28 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:07:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:07:28 --> Helper loaded: url_helper
INFO - 2018-03-30 23:07:28 --> Model Class Initialized
INFO - 2018-03-30 23:07:28 --> Model Class Initialized
INFO - 2018-03-30 23:07:28 --> Model Class Initialized
INFO - 2018-03-30 23:07:30 --> Config Class Initialized
INFO - 2018-03-30 23:07:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:07:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:07:30 --> Utf8 Class Initialized
INFO - 2018-03-30 23:07:30 --> URI Class Initialized
INFO - 2018-03-30 23:07:30 --> Router Class Initialized
INFO - 2018-03-30 23:07:30 --> Output Class Initialized
INFO - 2018-03-30 23:07:30 --> Security Class Initialized
DEBUG - 2018-03-30 23:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:07:30 --> Input Class Initialized
INFO - 2018-03-30 23:07:30 --> Language Class Initialized
INFO - 2018-03-30 23:07:30 --> Loader Class Initialized
INFO - 2018-03-30 23:07:30 --> Helper loaded: common_helper
INFO - 2018-03-30 23:07:30 --> Database Driver Class Initialized
INFO - 2018-03-30 23:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:07:30 --> Email Class Initialized
INFO - 2018-03-30 23:07:30 --> Controller Class Initialized
INFO - 2018-03-30 23:07:30 --> Helper loaded: form_helper
INFO - 2018-03-30 23:07:30 --> Form Validation Class Initialized
INFO - 2018-03-30 23:07:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:07:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:07:30 --> Helper loaded: url_helper
INFO - 2018-03-30 23:07:30 --> Model Class Initialized
INFO - 2018-03-30 23:07:30 --> Model Class Initialized
INFO - 2018-03-30 23:07:30 --> Model Class Initialized
INFO - 2018-03-30 23:10:37 --> Config Class Initialized
INFO - 2018-03-30 23:10:37 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:10:37 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:10:37 --> Utf8 Class Initialized
INFO - 2018-03-30 23:10:37 --> URI Class Initialized
INFO - 2018-03-30 23:10:37 --> Router Class Initialized
INFO - 2018-03-30 23:10:37 --> Output Class Initialized
INFO - 2018-03-30 23:10:37 --> Security Class Initialized
DEBUG - 2018-03-30 23:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:10:37 --> Input Class Initialized
INFO - 2018-03-30 23:10:37 --> Language Class Initialized
INFO - 2018-03-30 23:10:38 --> Loader Class Initialized
INFO - 2018-03-30 23:10:38 --> Helper loaded: common_helper
INFO - 2018-03-30 23:10:38 --> Database Driver Class Initialized
INFO - 2018-03-30 23:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:10:38 --> Email Class Initialized
INFO - 2018-03-30 23:10:38 --> Controller Class Initialized
INFO - 2018-03-30 23:10:38 --> Helper loaded: form_helper
INFO - 2018-03-30 23:10:38 --> Form Validation Class Initialized
INFO - 2018-03-30 23:10:38 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:10:38 --> Helper loaded: url_helper
INFO - 2018-03-30 23:10:38 --> Model Class Initialized
INFO - 2018-03-30 23:10:38 --> Model Class Initialized
INFO - 2018-03-30 23:10:38 --> Model Class Initialized
INFO - 2018-03-30 23:10:44 --> Config Class Initialized
INFO - 2018-03-30 23:10:44 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:10:44 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:10:44 --> Utf8 Class Initialized
INFO - 2018-03-30 23:10:44 --> URI Class Initialized
INFO - 2018-03-30 23:10:44 --> Router Class Initialized
INFO - 2018-03-30 23:10:44 --> Output Class Initialized
INFO - 2018-03-30 23:10:44 --> Security Class Initialized
DEBUG - 2018-03-30 23:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:10:44 --> Input Class Initialized
INFO - 2018-03-30 23:10:44 --> Language Class Initialized
INFO - 2018-03-30 23:10:44 --> Loader Class Initialized
INFO - 2018-03-30 23:10:44 --> Helper loaded: common_helper
INFO - 2018-03-30 23:10:45 --> Database Driver Class Initialized
INFO - 2018-03-30 23:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:10:45 --> Email Class Initialized
INFO - 2018-03-30 23:10:45 --> Controller Class Initialized
INFO - 2018-03-30 23:10:45 --> Helper loaded: form_helper
INFO - 2018-03-30 23:10:45 --> Form Validation Class Initialized
INFO - 2018-03-30 23:10:45 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:10:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:10:45 --> Helper loaded: url_helper
INFO - 2018-03-30 23:10:45 --> Model Class Initialized
INFO - 2018-03-30 23:10:45 --> Model Class Initialized
INFO - 2018-03-30 23:10:45 --> Model Class Initialized
INFO - 2018-03-30 23:10:46 --> Config Class Initialized
INFO - 2018-03-30 23:10:46 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:10:46 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:10:46 --> Utf8 Class Initialized
INFO - 2018-03-30 23:10:46 --> URI Class Initialized
INFO - 2018-03-30 23:10:46 --> Router Class Initialized
INFO - 2018-03-30 23:10:46 --> Output Class Initialized
INFO - 2018-03-30 23:10:46 --> Security Class Initialized
DEBUG - 2018-03-30 23:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:10:46 --> Input Class Initialized
INFO - 2018-03-30 23:10:46 --> Language Class Initialized
INFO - 2018-03-30 23:10:46 --> Loader Class Initialized
INFO - 2018-03-30 23:10:46 --> Helper loaded: common_helper
INFO - 2018-03-30 23:10:46 --> Database Driver Class Initialized
INFO - 2018-03-30 23:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:10:46 --> Email Class Initialized
INFO - 2018-03-30 23:10:46 --> Controller Class Initialized
INFO - 2018-03-30 23:10:46 --> Helper loaded: form_helper
INFO - 2018-03-30 23:10:46 --> Form Validation Class Initialized
INFO - 2018-03-30 23:10:46 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:10:46 --> Helper loaded: url_helper
INFO - 2018-03-30 23:10:46 --> Model Class Initialized
INFO - 2018-03-30 23:10:46 --> Model Class Initialized
INFO - 2018-03-30 23:10:46 --> Model Class Initialized
INFO - 2018-03-30 23:12:04 --> Config Class Initialized
INFO - 2018-03-30 23:12:04 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:12:04 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:12:04 --> Utf8 Class Initialized
INFO - 2018-03-30 23:12:04 --> URI Class Initialized
INFO - 2018-03-30 23:12:04 --> Router Class Initialized
INFO - 2018-03-30 23:12:04 --> Output Class Initialized
INFO - 2018-03-30 23:12:04 --> Security Class Initialized
DEBUG - 2018-03-30 23:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:12:04 --> Input Class Initialized
INFO - 2018-03-30 23:12:04 --> Language Class Initialized
INFO - 2018-03-30 23:12:04 --> Loader Class Initialized
INFO - 2018-03-30 23:12:04 --> Helper loaded: common_helper
INFO - 2018-03-30 23:12:04 --> Database Driver Class Initialized
INFO - 2018-03-30 23:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:12:04 --> Email Class Initialized
INFO - 2018-03-30 23:12:04 --> Controller Class Initialized
INFO - 2018-03-30 23:12:04 --> Helper loaded: form_helper
INFO - 2018-03-30 23:12:04 --> Form Validation Class Initialized
INFO - 2018-03-30 23:12:04 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:12:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:12:04 --> Helper loaded: url_helper
INFO - 2018-03-30 23:12:04 --> Model Class Initialized
INFO - 2018-03-30 23:12:04 --> Model Class Initialized
INFO - 2018-03-30 23:12:04 --> Model Class Initialized
INFO - 2018-03-30 23:15:30 --> Config Class Initialized
INFO - 2018-03-30 23:15:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:15:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:15:30 --> Utf8 Class Initialized
INFO - 2018-03-30 23:15:30 --> URI Class Initialized
INFO - 2018-03-30 23:15:30 --> Router Class Initialized
INFO - 2018-03-30 23:15:30 --> Output Class Initialized
INFO - 2018-03-30 23:15:30 --> Security Class Initialized
DEBUG - 2018-03-30 23:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:15:30 --> Input Class Initialized
INFO - 2018-03-30 23:15:30 --> Language Class Initialized
INFO - 2018-03-30 23:15:30 --> Loader Class Initialized
INFO - 2018-03-30 23:15:30 --> Helper loaded: common_helper
INFO - 2018-03-30 23:15:30 --> Database Driver Class Initialized
INFO - 2018-03-30 23:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:15:30 --> Email Class Initialized
INFO - 2018-03-30 23:15:30 --> Controller Class Initialized
INFO - 2018-03-30 23:15:30 --> Helper loaded: form_helper
INFO - 2018-03-30 23:15:30 --> Form Validation Class Initialized
INFO - 2018-03-30 23:15:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:15:30 --> Helper loaded: url_helper
INFO - 2018-03-30 23:15:30 --> Model Class Initialized
INFO - 2018-03-30 23:15:30 --> Model Class Initialized
INFO - 2018-03-30 23:15:30 --> Model Class Initialized
INFO - 2018-03-30 23:15:42 --> Config Class Initialized
INFO - 2018-03-30 23:15:42 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:15:42 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:15:42 --> Utf8 Class Initialized
INFO - 2018-03-30 23:15:42 --> URI Class Initialized
INFO - 2018-03-30 23:15:42 --> Router Class Initialized
INFO - 2018-03-30 23:15:42 --> Output Class Initialized
INFO - 2018-03-30 23:15:42 --> Security Class Initialized
DEBUG - 2018-03-30 23:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:15:42 --> Input Class Initialized
INFO - 2018-03-30 23:15:42 --> Language Class Initialized
INFO - 2018-03-30 23:15:42 --> Loader Class Initialized
INFO - 2018-03-30 23:15:42 --> Helper loaded: common_helper
INFO - 2018-03-30 23:15:42 --> Database Driver Class Initialized
INFO - 2018-03-30 23:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:15:42 --> Email Class Initialized
INFO - 2018-03-30 23:15:42 --> Controller Class Initialized
INFO - 2018-03-30 23:15:42 --> Helper loaded: form_helper
INFO - 2018-03-30 23:15:42 --> Form Validation Class Initialized
INFO - 2018-03-30 23:15:42 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:15:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:15:42 --> Helper loaded: url_helper
INFO - 2018-03-30 23:15:42 --> Model Class Initialized
INFO - 2018-03-30 23:15:42 --> Model Class Initialized
INFO - 2018-03-30 23:15:42 --> Model Class Initialized
INFO - 2018-03-30 23:15:47 --> Config Class Initialized
INFO - 2018-03-30 23:15:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:15:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:15:47 --> Utf8 Class Initialized
INFO - 2018-03-30 23:15:47 --> URI Class Initialized
INFO - 2018-03-30 23:15:47 --> Router Class Initialized
INFO - 2018-03-30 23:15:47 --> Output Class Initialized
INFO - 2018-03-30 23:15:47 --> Security Class Initialized
DEBUG - 2018-03-30 23:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:15:47 --> Input Class Initialized
INFO - 2018-03-30 23:15:47 --> Language Class Initialized
INFO - 2018-03-30 23:15:47 --> Loader Class Initialized
INFO - 2018-03-30 23:15:47 --> Helper loaded: common_helper
INFO - 2018-03-30 23:15:47 --> Database Driver Class Initialized
INFO - 2018-03-30 23:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:15:47 --> Email Class Initialized
INFO - 2018-03-30 23:15:47 --> Controller Class Initialized
INFO - 2018-03-30 23:15:47 --> Helper loaded: form_helper
INFO - 2018-03-30 23:15:47 --> Form Validation Class Initialized
INFO - 2018-03-30 23:15:47 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:15:47 --> Helper loaded: url_helper
INFO - 2018-03-30 23:15:47 --> Model Class Initialized
INFO - 2018-03-30 23:15:47 --> Model Class Initialized
INFO - 2018-03-30 23:15:47 --> Model Class Initialized
INFO - 2018-03-30 23:15:49 --> Config Class Initialized
INFO - 2018-03-30 23:15:49 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:15:49 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:15:49 --> Utf8 Class Initialized
INFO - 2018-03-30 23:15:49 --> URI Class Initialized
INFO - 2018-03-30 23:15:49 --> Router Class Initialized
INFO - 2018-03-30 23:15:49 --> Output Class Initialized
INFO - 2018-03-30 23:15:49 --> Security Class Initialized
DEBUG - 2018-03-30 23:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:15:49 --> Input Class Initialized
INFO - 2018-03-30 23:15:49 --> Language Class Initialized
INFO - 2018-03-30 23:15:49 --> Loader Class Initialized
INFO - 2018-03-30 23:15:49 --> Helper loaded: common_helper
INFO - 2018-03-30 23:15:49 --> Database Driver Class Initialized
INFO - 2018-03-30 23:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:15:49 --> Email Class Initialized
INFO - 2018-03-30 23:15:49 --> Controller Class Initialized
INFO - 2018-03-30 23:15:49 --> Helper loaded: form_helper
INFO - 2018-03-30 23:15:49 --> Form Validation Class Initialized
INFO - 2018-03-30 23:15:49 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:15:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:15:49 --> Helper loaded: url_helper
INFO - 2018-03-30 23:15:49 --> Model Class Initialized
INFO - 2018-03-30 23:15:49 --> Model Class Initialized
INFO - 2018-03-30 23:15:49 --> Model Class Initialized
INFO - 2018-03-30 23:16:13 --> Config Class Initialized
INFO - 2018-03-30 23:16:13 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:16:13 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:16:13 --> Utf8 Class Initialized
INFO - 2018-03-30 23:16:13 --> URI Class Initialized
INFO - 2018-03-30 23:16:13 --> Router Class Initialized
INFO - 2018-03-30 23:16:13 --> Output Class Initialized
INFO - 2018-03-30 23:16:13 --> Security Class Initialized
DEBUG - 2018-03-30 23:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:16:13 --> Input Class Initialized
INFO - 2018-03-30 23:16:13 --> Language Class Initialized
INFO - 2018-03-30 23:16:13 --> Loader Class Initialized
INFO - 2018-03-30 23:16:13 --> Helper loaded: common_helper
INFO - 2018-03-30 23:16:13 --> Database Driver Class Initialized
INFO - 2018-03-30 23:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:16:13 --> Email Class Initialized
INFO - 2018-03-30 23:16:13 --> Controller Class Initialized
INFO - 2018-03-30 23:16:13 --> Helper loaded: form_helper
INFO - 2018-03-30 23:16:13 --> Form Validation Class Initialized
INFO - 2018-03-30 23:16:13 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:16:13 --> Helper loaded: url_helper
INFO - 2018-03-30 23:16:13 --> Model Class Initialized
INFO - 2018-03-30 23:16:13 --> Model Class Initialized
INFO - 2018-03-30 23:16:13 --> Model Class Initialized
INFO - 2018-03-30 23:16:56 --> Config Class Initialized
INFO - 2018-03-30 23:16:56 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:16:56 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:16:56 --> Utf8 Class Initialized
INFO - 2018-03-30 23:16:56 --> URI Class Initialized
INFO - 2018-03-30 23:16:56 --> Router Class Initialized
INFO - 2018-03-30 23:16:56 --> Output Class Initialized
INFO - 2018-03-30 23:16:56 --> Security Class Initialized
DEBUG - 2018-03-30 23:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:16:56 --> Input Class Initialized
INFO - 2018-03-30 23:16:56 --> Language Class Initialized
INFO - 2018-03-30 23:16:56 --> Loader Class Initialized
INFO - 2018-03-30 23:16:56 --> Helper loaded: common_helper
INFO - 2018-03-30 23:16:56 --> Database Driver Class Initialized
INFO - 2018-03-30 23:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:16:56 --> Email Class Initialized
INFO - 2018-03-30 23:16:56 --> Controller Class Initialized
INFO - 2018-03-30 23:16:56 --> Helper loaded: form_helper
INFO - 2018-03-30 23:16:56 --> Form Validation Class Initialized
INFO - 2018-03-30 23:16:56 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:16:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:16:56 --> Helper loaded: url_helper
INFO - 2018-03-30 23:16:56 --> Model Class Initialized
INFO - 2018-03-30 23:16:56 --> Model Class Initialized
INFO - 2018-03-30 23:16:56 --> Model Class Initialized
INFO - 2018-03-30 23:17:17 --> Config Class Initialized
INFO - 2018-03-30 23:17:17 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:17:17 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:17:17 --> Utf8 Class Initialized
INFO - 2018-03-30 23:17:17 --> URI Class Initialized
INFO - 2018-03-30 23:17:17 --> Router Class Initialized
INFO - 2018-03-30 23:17:17 --> Output Class Initialized
INFO - 2018-03-30 23:17:17 --> Security Class Initialized
DEBUG - 2018-03-30 23:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:17:17 --> Input Class Initialized
INFO - 2018-03-30 23:17:17 --> Language Class Initialized
INFO - 2018-03-30 23:17:17 --> Loader Class Initialized
INFO - 2018-03-30 23:17:17 --> Helper loaded: common_helper
INFO - 2018-03-30 23:17:17 --> Database Driver Class Initialized
INFO - 2018-03-30 23:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:17:17 --> Email Class Initialized
INFO - 2018-03-30 23:17:17 --> Controller Class Initialized
INFO - 2018-03-30 23:17:17 --> Helper loaded: form_helper
INFO - 2018-03-30 23:17:17 --> Form Validation Class Initialized
INFO - 2018-03-30 23:17:17 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:17:17 --> Helper loaded: url_helper
INFO - 2018-03-30 23:17:17 --> Model Class Initialized
INFO - 2018-03-30 23:17:17 --> Model Class Initialized
INFO - 2018-03-30 23:17:17 --> Model Class Initialized
INFO - 2018-03-30 23:17:47 --> Config Class Initialized
INFO - 2018-03-30 23:17:47 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:17:47 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:17:47 --> Utf8 Class Initialized
INFO - 2018-03-30 23:17:47 --> URI Class Initialized
INFO - 2018-03-30 23:17:47 --> Router Class Initialized
INFO - 2018-03-30 23:17:47 --> Output Class Initialized
INFO - 2018-03-30 23:17:47 --> Security Class Initialized
DEBUG - 2018-03-30 23:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:17:47 --> Input Class Initialized
INFO - 2018-03-30 23:17:47 --> Language Class Initialized
INFO - 2018-03-30 23:17:47 --> Loader Class Initialized
INFO - 2018-03-30 23:17:47 --> Helper loaded: common_helper
INFO - 2018-03-30 23:17:47 --> Database Driver Class Initialized
INFO - 2018-03-30 23:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:17:47 --> Email Class Initialized
INFO - 2018-03-30 23:17:47 --> Controller Class Initialized
INFO - 2018-03-30 23:17:47 --> Helper loaded: form_helper
INFO - 2018-03-30 23:17:47 --> Form Validation Class Initialized
INFO - 2018-03-30 23:17:47 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:17:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:17:47 --> Helper loaded: url_helper
INFO - 2018-03-30 23:17:47 --> Model Class Initialized
INFO - 2018-03-30 23:17:47 --> Model Class Initialized
INFO - 2018-03-30 23:17:47 --> Model Class Initialized
INFO - 2018-03-30 23:18:20 --> Config Class Initialized
INFO - 2018-03-30 23:18:20 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:18:20 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:18:20 --> Utf8 Class Initialized
INFO - 2018-03-30 23:18:20 --> URI Class Initialized
INFO - 2018-03-30 23:18:20 --> Router Class Initialized
INFO - 2018-03-30 23:18:20 --> Output Class Initialized
INFO - 2018-03-30 23:18:20 --> Security Class Initialized
DEBUG - 2018-03-30 23:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:18:20 --> Input Class Initialized
INFO - 2018-03-30 23:18:20 --> Language Class Initialized
INFO - 2018-03-30 23:18:20 --> Loader Class Initialized
INFO - 2018-03-30 23:18:20 --> Helper loaded: common_helper
INFO - 2018-03-30 23:18:20 --> Database Driver Class Initialized
INFO - 2018-03-30 23:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:18:20 --> Email Class Initialized
INFO - 2018-03-30 23:18:20 --> Controller Class Initialized
INFO - 2018-03-30 23:18:20 --> Helper loaded: form_helper
INFO - 2018-03-30 23:18:20 --> Form Validation Class Initialized
INFO - 2018-03-30 23:18:20 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:18:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:18:20 --> Helper loaded: url_helper
INFO - 2018-03-30 23:18:20 --> Model Class Initialized
INFO - 2018-03-30 23:18:20 --> Model Class Initialized
INFO - 2018-03-30 23:18:20 --> Model Class Initialized
INFO - 2018-03-30 23:18:22 --> Config Class Initialized
INFO - 2018-03-30 23:18:22 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:18:22 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:18:22 --> Utf8 Class Initialized
INFO - 2018-03-30 23:18:22 --> URI Class Initialized
INFO - 2018-03-30 23:18:22 --> Router Class Initialized
INFO - 2018-03-30 23:18:22 --> Output Class Initialized
INFO - 2018-03-30 23:18:22 --> Security Class Initialized
DEBUG - 2018-03-30 23:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:18:22 --> Input Class Initialized
INFO - 2018-03-30 23:18:22 --> Language Class Initialized
INFO - 2018-03-30 23:18:22 --> Loader Class Initialized
INFO - 2018-03-30 23:18:22 --> Helper loaded: common_helper
INFO - 2018-03-30 23:18:22 --> Database Driver Class Initialized
INFO - 2018-03-30 23:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:18:22 --> Email Class Initialized
INFO - 2018-03-30 23:18:22 --> Controller Class Initialized
INFO - 2018-03-30 23:18:22 --> Helper loaded: form_helper
INFO - 2018-03-30 23:18:22 --> Form Validation Class Initialized
INFO - 2018-03-30 23:18:22 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:18:22 --> Helper loaded: url_helper
INFO - 2018-03-30 23:18:22 --> Model Class Initialized
INFO - 2018-03-30 23:18:22 --> Model Class Initialized
INFO - 2018-03-30 23:18:22 --> Model Class Initialized
INFO - 2018-03-30 23:21:06 --> Config Class Initialized
INFO - 2018-03-30 23:21:06 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:21:06 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:21:06 --> Utf8 Class Initialized
INFO - 2018-03-30 23:21:06 --> URI Class Initialized
INFO - 2018-03-30 23:21:06 --> Router Class Initialized
INFO - 2018-03-30 23:21:06 --> Output Class Initialized
INFO - 2018-03-30 23:21:06 --> Security Class Initialized
DEBUG - 2018-03-30 23:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:21:06 --> Input Class Initialized
INFO - 2018-03-30 23:21:06 --> Language Class Initialized
INFO - 2018-03-30 23:21:06 --> Loader Class Initialized
INFO - 2018-03-30 23:21:06 --> Helper loaded: common_helper
INFO - 2018-03-30 23:21:06 --> Database Driver Class Initialized
INFO - 2018-03-30 23:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:21:06 --> Email Class Initialized
INFO - 2018-03-30 23:21:06 --> Controller Class Initialized
INFO - 2018-03-30 23:21:06 --> Helper loaded: form_helper
INFO - 2018-03-30 23:21:06 --> Form Validation Class Initialized
INFO - 2018-03-30 23:21:06 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:21:06 --> Helper loaded: url_helper
INFO - 2018-03-30 23:21:06 --> Model Class Initialized
INFO - 2018-03-30 23:21:06 --> Model Class Initialized
INFO - 2018-03-30 23:21:06 --> Model Class Initialized
INFO - 2018-03-30 23:21:08 --> Config Class Initialized
INFO - 2018-03-30 23:21:08 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:21:08 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:21:08 --> Utf8 Class Initialized
INFO - 2018-03-30 23:21:08 --> URI Class Initialized
INFO - 2018-03-30 23:21:08 --> Router Class Initialized
INFO - 2018-03-30 23:21:08 --> Output Class Initialized
INFO - 2018-03-30 23:21:08 --> Security Class Initialized
DEBUG - 2018-03-30 23:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:21:08 --> Input Class Initialized
INFO - 2018-03-30 23:21:08 --> Language Class Initialized
INFO - 2018-03-30 23:21:08 --> Loader Class Initialized
INFO - 2018-03-30 23:21:08 --> Helper loaded: common_helper
INFO - 2018-03-30 23:21:08 --> Database Driver Class Initialized
INFO - 2018-03-30 23:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:21:08 --> Email Class Initialized
INFO - 2018-03-30 23:21:08 --> Controller Class Initialized
INFO - 2018-03-30 23:21:08 --> Helper loaded: form_helper
INFO - 2018-03-30 23:21:08 --> Form Validation Class Initialized
INFO - 2018-03-30 23:21:08 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:21:08 --> Helper loaded: url_helper
INFO - 2018-03-30 23:21:08 --> Model Class Initialized
INFO - 2018-03-30 23:21:08 --> Model Class Initialized
INFO - 2018-03-30 23:21:08 --> Model Class Initialized
INFO - 2018-03-30 23:21:30 --> Config Class Initialized
INFO - 2018-03-30 23:21:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:21:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:21:30 --> Utf8 Class Initialized
INFO - 2018-03-30 23:21:30 --> URI Class Initialized
INFO - 2018-03-30 23:21:30 --> Router Class Initialized
INFO - 2018-03-30 23:21:30 --> Output Class Initialized
INFO - 2018-03-30 23:21:30 --> Security Class Initialized
DEBUG - 2018-03-30 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:21:30 --> Input Class Initialized
INFO - 2018-03-30 23:21:30 --> Language Class Initialized
INFO - 2018-03-30 23:21:30 --> Loader Class Initialized
INFO - 2018-03-30 23:21:30 --> Helper loaded: common_helper
INFO - 2018-03-30 23:21:30 --> Database Driver Class Initialized
INFO - 2018-03-30 23:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:21:30 --> Email Class Initialized
INFO - 2018-03-30 23:21:30 --> Controller Class Initialized
INFO - 2018-03-30 23:21:30 --> Helper loaded: form_helper
INFO - 2018-03-30 23:21:30 --> Form Validation Class Initialized
INFO - 2018-03-30 23:21:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:21:30 --> Helper loaded: url_helper
INFO - 2018-03-30 23:21:30 --> Model Class Initialized
INFO - 2018-03-30 23:21:30 --> Model Class Initialized
INFO - 2018-03-30 23:21:30 --> Model Class Initialized
INFO - 2018-03-30 23:21:30 --> Config Class Initialized
INFO - 2018-03-30 23:21:30 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:21:30 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:21:30 --> Utf8 Class Initialized
INFO - 2018-03-30 23:21:30 --> URI Class Initialized
INFO - 2018-03-30 23:21:30 --> Router Class Initialized
INFO - 2018-03-30 23:21:30 --> Output Class Initialized
INFO - 2018-03-30 23:21:30 --> Security Class Initialized
DEBUG - 2018-03-30 23:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:21:30 --> Input Class Initialized
INFO - 2018-03-30 23:21:30 --> Language Class Initialized
INFO - 2018-03-30 23:21:30 --> Loader Class Initialized
INFO - 2018-03-30 23:21:30 --> Helper loaded: common_helper
INFO - 2018-03-30 23:21:30 --> Database Driver Class Initialized
INFO - 2018-03-30 23:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:21:30 --> Email Class Initialized
INFO - 2018-03-30 23:21:30 --> Controller Class Initialized
INFO - 2018-03-30 23:21:30 --> Helper loaded: form_helper
INFO - 2018-03-30 23:21:30 --> Form Validation Class Initialized
INFO - 2018-03-30 23:21:30 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:21:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:21:30 --> Helper loaded: url_helper
INFO - 2018-03-30 23:21:30 --> Model Class Initialized
INFO - 2018-03-30 23:21:30 --> Model Class Initialized
INFO - 2018-03-30 23:21:30 --> Model Class Initialized
INFO - 2018-03-30 23:21:36 --> Config Class Initialized
INFO - 2018-03-30 23:21:36 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:21:36 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:21:36 --> Utf8 Class Initialized
INFO - 2018-03-30 23:21:36 --> URI Class Initialized
INFO - 2018-03-30 23:21:36 --> Router Class Initialized
INFO - 2018-03-30 23:21:36 --> Output Class Initialized
INFO - 2018-03-30 23:21:36 --> Security Class Initialized
DEBUG - 2018-03-30 23:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:21:36 --> Input Class Initialized
INFO - 2018-03-30 23:21:36 --> Language Class Initialized
INFO - 2018-03-30 23:21:36 --> Loader Class Initialized
INFO - 2018-03-30 23:21:36 --> Helper loaded: common_helper
INFO - 2018-03-30 23:21:36 --> Database Driver Class Initialized
INFO - 2018-03-30 23:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:21:36 --> Email Class Initialized
INFO - 2018-03-30 23:21:36 --> Controller Class Initialized
INFO - 2018-03-30 23:21:36 --> Helper loaded: form_helper
INFO - 2018-03-30 23:21:36 --> Form Validation Class Initialized
INFO - 2018-03-30 23:21:36 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:21:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:21:36 --> Helper loaded: url_helper
INFO - 2018-03-30 23:21:36 --> Model Class Initialized
INFO - 2018-03-30 23:21:36 --> Model Class Initialized
INFO - 2018-03-30 23:21:36 --> Model Class Initialized
INFO - 2018-03-30 23:22:32 --> Config Class Initialized
INFO - 2018-03-30 23:22:32 --> Hooks Class Initialized
DEBUG - 2018-03-30 23:22:32 --> UTF-8 Support Enabled
INFO - 2018-03-30 23:22:32 --> Utf8 Class Initialized
INFO - 2018-03-30 23:22:32 --> URI Class Initialized
INFO - 2018-03-30 23:22:32 --> Router Class Initialized
INFO - 2018-03-30 23:22:32 --> Output Class Initialized
INFO - 2018-03-30 23:22:32 --> Security Class Initialized
DEBUG - 2018-03-30 23:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-30 23:22:32 --> Input Class Initialized
INFO - 2018-03-30 23:22:32 --> Language Class Initialized
INFO - 2018-03-30 23:22:32 --> Loader Class Initialized
INFO - 2018-03-30 23:22:32 --> Helper loaded: common_helper
INFO - 2018-03-30 23:22:32 --> Database Driver Class Initialized
INFO - 2018-03-30 23:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-30 23:22:32 --> Email Class Initialized
INFO - 2018-03-30 23:22:32 --> Controller Class Initialized
INFO - 2018-03-30 23:22:32 --> Helper loaded: form_helper
INFO - 2018-03-30 23:22:32 --> Form Validation Class Initialized
INFO - 2018-03-30 23:22:32 --> Helper loaded: email_helper
DEBUG - 2018-03-30 23:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-30 23:22:32 --> Helper loaded: url_helper
INFO - 2018-03-30 23:22:32 --> Model Class Initialized
INFO - 2018-03-30 23:22:32 --> Model Class Initialized
INFO - 2018-03-30 23:22:32 --> Model Class Initialized
