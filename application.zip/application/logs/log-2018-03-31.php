<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-03-31 00:18:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:18:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:18:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:18:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:18:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:18:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:18:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:18:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:18:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:18:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:18:21 --> Final output sent to browser
DEBUG - 2018-03-31 00:18:21 --> Total execution time: 0.0910
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:21:34 --> Trying to get property of non-object
ERROR - 2018-03-31 00:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:21:34 --> Trying to get property of non-object
ERROR - 2018-03-31 00:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:21:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:21:34 --> Final output sent to browser
DEBUG - 2018-03-31 00:21:34 --> Total execution time: 0.1470
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:21:56 --> Trying to get property of non-object
ERROR - 2018-03-31 00:21:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:21:56 --> Trying to get property of non-object
ERROR - 2018-03-31 00:21:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:21:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:21:56 --> Final output sent to browser
DEBUG - 2018-03-31 00:21:56 --> Total execution time: 0.1490
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:22:22 --> Trying to get property of non-object
ERROR - 2018-03-31 00:22:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:22:22 --> Trying to get property of non-object
ERROR - 2018-03-31 00:22:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:22:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:22:22 --> Final output sent to browser
DEBUG - 2018-03-31 00:22:22 --> Total execution time: 0.1440
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:22:40 --> Trying to get property of non-object
ERROR - 2018-03-31 00:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:22:40 --> Trying to get property of non-object
ERROR - 2018-03-31 00:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 29
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:22:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:22:40 --> Final output sent to browser
DEBUG - 2018-03-31 00:22:40 --> Total execution time: 0.1520
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:06 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:23:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:23:06 --> Final output sent to browser
DEBUG - 2018-03-31 00:23:06 --> Total execution time: 0.1770
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
ERROR - 2018-03-31 00:23:30 --> Trying to get property of non-object
ERROR - 2018-03-31 00:23:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 48
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:23:30 --> Final output sent to browser
DEBUG - 2018-03-31 00:23:30 --> Total execution time: 0.1750
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:24:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:24:13 --> Final output sent to browser
DEBUG - 2018-03-31 00:24:13 --> Total execution time: 0.1390
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:24:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:24:27 --> Final output sent to browser
DEBUG - 2018-03-31 00:24:27 --> Total execution time: 0.1490
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:27:13 --> Final output sent to browser
DEBUG - 2018-03-31 00:27:13 --> Total execution time: 0.1460
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:27:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:27:56 --> Final output sent to browser
DEBUG - 2018-03-31 00:27:56 --> Total execution time: 0.1370
INFO - 2018-03-31 00:28:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:28:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:28:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:28:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 00:28:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:28:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:28:11 --> Final output sent to browser
DEBUG - 2018-03-31 00:28:11 --> Total execution time: 0.1460
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:28:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:28:22 --> Final output sent to browser
DEBUG - 2018-03-31 00:28:22 --> Total execution time: 0.1410
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:29:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:29:29 --> Final output sent to browser
DEBUG - 2018-03-31 00:29:29 --> Total execution time: 0.1450
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:31:23 --> Final output sent to browser
DEBUG - 2018-03-31 00:31:23 --> Total execution time: 0.1390
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:31:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:31:41 --> Final output sent to browser
DEBUG - 2018-03-31 00:31:41 --> Total execution time: 0.1420
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:32:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:32:14 --> Final output sent to browser
DEBUG - 2018-03-31 00:32:14 --> Total execution time: 0.1430
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:33:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:33:15 --> Final output sent to browser
DEBUG - 2018-03-31 00:33:15 --> Total execution time: 0.1490
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:33:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:33:51 --> Final output sent to browser
DEBUG - 2018-03-31 00:33:51 --> Total execution time: 0.1450
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:34:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:34:24 --> Final output sent to browser
DEBUG - 2018-03-31 00:34:24 --> Total execution time: 0.1480
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:34:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:34:45 --> Final output sent to browser
DEBUG - 2018-03-31 00:34:45 --> Total execution time: 0.1460
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:35:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:35:08 --> Final output sent to browser
DEBUG - 2018-03-31 00:35:08 --> Total execution time: 0.1450
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:35:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:35:26 --> Final output sent to browser
DEBUG - 2018-03-31 00:35:26 --> Total execution time: 0.1440
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:36:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:36:18 --> Final output sent to browser
DEBUG - 2018-03-31 00:36:18 --> Total execution time: 0.1450
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:36:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:36:28 --> Final output sent to browser
DEBUG - 2018-03-31 00:36:28 --> Total execution time: 0.1420
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:36:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:36:57 --> Final output sent to browser
DEBUG - 2018-03-31 00:36:57 --> Total execution time: 0.1430
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:37:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:37:59 --> Final output sent to browser
DEBUG - 2018-03-31 00:37:59 --> Total execution time: 0.1450
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:38:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:38:09 --> Final output sent to browser
DEBUG - 2018-03-31 00:38:09 --> Total execution time: 0.1420
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:38:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:38:32 --> Final output sent to browser
DEBUG - 2018-03-31 00:38:32 --> Total execution time: 0.1390
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:39:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:39:03 --> Final output sent to browser
DEBUG - 2018-03-31 00:39:03 --> Total execution time: 0.1370
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:39:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:39:54 --> Final output sent to browser
DEBUG - 2018-03-31 00:39:54 --> Total execution time: 0.1510
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:40:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:40:27 --> Final output sent to browser
DEBUG - 2018-03-31 00:40:27 --> Total execution time: 0.1460
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:42:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:42:27 --> Final output sent to browser
DEBUG - 2018-03-31 00:42:27 --> Total execution time: 0.1650
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:42:36 --> Undefined variable: image
ERROR - 2018-03-31 00:42:36 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:42:36 --> Undefined variable: image
ERROR - 2018-03-31 00:42:36 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:42:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:42:36 --> Final output sent to browser
DEBUG - 2018-03-31 00:42:36 --> Total execution time: 0.1500
INFO - 2018-03-31 00:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:43:22 --> Final output sent to browser
DEBUG - 2018-03-31 00:43:22 --> Total execution time: 0.1410
INFO - 2018-03-31 00:44:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:44:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:44:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:44:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:44:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:44:06 --> Final output sent to browser
DEBUG - 2018-03-31 00:44:06 --> Total execution time: 0.1290
INFO - 2018-03-31 00:44:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:44:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:44:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:44:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 00:44:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:44:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:44:08 --> Final output sent to browser
DEBUG - 2018-03-31 00:44:08 --> Total execution time: 0.1290
DEBUG - 2018-03-31 00:44:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 00:44:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 00:44:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:44:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:44:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:44:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:44:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:44:30 --> Final output sent to browser
DEBUG - 2018-03-31 00:44:30 --> Total execution time: 0.1390
INFO - 2018-03-31 00:44:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:44:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:44:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:44:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:44:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:44:35 --> Final output sent to browser
DEBUG - 2018-03-31 00:44:35 --> Total execution time: 0.1670
INFO - 2018-03-31 00:46:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:46:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:46:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:46:27 --> Undefined variable: image
ERROR - 2018-03-31 00:46:27 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:46:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:46:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:46:27 --> Final output sent to browser
DEBUG - 2018-03-31 00:46:27 --> Total execution time: 0.1390
INFO - 2018-03-31 00:46:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:46:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:46:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:46:32 --> Undefined variable: image
ERROR - 2018-03-31 00:46:32 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:46:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:46:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:46:32 --> Final output sent to browser
DEBUG - 2018-03-31 00:46:32 --> Total execution time: 0.1610
INFO - 2018-03-31 00:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:46:33 --> Undefined variable: image
ERROR - 2018-03-31 00:46:33 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:46:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:46:33 --> Final output sent to browser
DEBUG - 2018-03-31 00:46:33 --> Total execution time: 0.1360
INFO - 2018-03-31 00:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:46:35 --> Undefined variable: image
ERROR - 2018-03-31 00:46:35 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:46:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:46:35 --> Final output sent to browser
DEBUG - 2018-03-31 00:46:35 --> Total execution time: 0.1330
INFO - 2018-03-31 00:46:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:46:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:46:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:46:54 --> Undefined variable: image
ERROR - 2018-03-31 00:46:54 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:46:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:46:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:46:54 --> Final output sent to browser
DEBUG - 2018-03-31 00:46:54 --> Total execution time: 0.1420
INFO - 2018-03-31 00:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-03-31 00:46:56 --> Undefined variable: image
ERROR - 2018-03-31 00:46:56 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 69
INFO - 2018-03-31 00:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:46:56 --> Final output sent to browser
DEBUG - 2018-03-31 00:46:56 --> Total execution time: 0.1300
INFO - 2018-03-31 00:47:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:47:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:47:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:47:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:47:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:47:01 --> Final output sent to browser
DEBUG - 2018-03-31 00:47:01 --> Total execution time: 0.1790
INFO - 2018-03-31 00:47:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:47:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:47:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:47:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:47:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:47:09 --> Final output sent to browser
DEBUG - 2018-03-31 00:47:09 --> Total execution time: 0.1340
INFO - 2018-03-31 00:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 00:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:47:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:47:12 --> Final output sent to browser
DEBUG - 2018-03-31 00:47:12 --> Total execution time: 0.1290
DEBUG - 2018-03-31 00:47:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 00:47:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-03-31 00:47:25 --> mkdir(): File exists
ERROR - 2018-03-31 00:47:25 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 89
DEBUG - 2018-03-31 00:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 00:48:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-03-31 00:48:02 --> mkdir(): File exists
ERROR - 2018-03-31 00:48:02 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 89
INFO - 2018-03-31 00:48:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:48:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:48:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:48:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:48:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:48:03 --> Final output sent to browser
DEBUG - 2018-03-31 00:48:03 --> Total execution time: 0.1320
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:48:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:48:20 --> Final output sent to browser
DEBUG - 2018-03-31 00:48:20 --> Total execution time: 0.1690
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:50:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:50:09 --> Final output sent to browser
DEBUG - 2018-03-31 00:50:09 --> Total execution time: 0.1460
INFO - 2018-03-31 00:50:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:50:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:50:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 00:50:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:50:13 --> Final output sent to browser
DEBUG - 2018-03-31 00:50:13 --> Total execution time: 0.1670
INFO - 2018-03-31 00:50:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:50:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:50:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 00:50:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:50:15 --> Final output sent to browser
DEBUG - 2018-03-31 00:50:15 --> Total execution time: 0.1280
DEBUG - 2018-03-31 00:50:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 00:50:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-03-31 00:50:29 --> mkdir(): File exists
ERROR - 2018-03-31 00:50:29 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 89
INFO - 2018-03-31 00:50:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:50:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:50:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 00:50:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:50:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:50:29 --> Final output sent to browser
DEBUG - 2018-03-31 00:50:29 --> Total execution time: 0.1275
INFO - 2018-03-31 00:51:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:51:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:51:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:51:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:51:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:51:23 --> Final output sent to browser
DEBUG - 2018-03-31 00:51:23 --> Total execution time: 0.1500
INFO - 2018-03-31 00:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 00:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 00:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 00:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 00:51:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 00:51:25 --> Final output sent to browser
DEBUG - 2018-03-31 00:51:25 --> Total execution time: 0.1500
INFO - 2018-03-31 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:19:57 --> Final output sent to browser
DEBUG - 2018-03-31 02:19:57 --> Total execution time: 0.0950
INFO - 2018-03-31 02:20:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:20:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:20:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:20:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:20:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:20:30 --> Final output sent to browser
DEBUG - 2018-03-31 02:20:30 --> Total execution time: 0.0740
INFO - 2018-03-31 02:20:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:20:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:20:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:20:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:20:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:20:55 --> Final output sent to browser
DEBUG - 2018-03-31 02:20:55 --> Total execution time: 0.0670
INFO - 2018-03-31 02:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:34:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:34:09 --> Final output sent to browser
DEBUG - 2018-03-31 02:34:09 --> Total execution time: 0.1430
INFO - 2018-03-31 02:34:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:34:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:34:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:34:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:34:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:34:56 --> Final output sent to browser
DEBUG - 2018-03-31 02:34:56 --> Total execution time: 0.1330
INFO - 2018-03-31 02:36:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:36:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:36:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:36:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:36:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:36:05 --> Final output sent to browser
DEBUG - 2018-03-31 02:36:05 --> Total execution time: 0.1380
INFO - 2018-03-31 02:36:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:36:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:36:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:36:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:36:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:36:21 --> Final output sent to browser
DEBUG - 2018-03-31 02:36:21 --> Total execution time: 0.1460
INFO - 2018-03-31 02:36:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:36:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:36:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:36:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:36:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:36:53 --> Final output sent to browser
DEBUG - 2018-03-31 02:36:53 --> Total execution time: 0.1730
INFO - 2018-03-31 02:37:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:37:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:37:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:37:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:37:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:37:03 --> Final output sent to browser
DEBUG - 2018-03-31 02:37:03 --> Total execution time: 0.1440
INFO - 2018-03-31 02:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:37:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:37:30 --> Final output sent to browser
DEBUG - 2018-03-31 02:37:30 --> Total execution time: 0.1620
INFO - 2018-03-31 02:40:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:40:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:40:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:40:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:40:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:40:38 --> Final output sent to browser
DEBUG - 2018-03-31 02:40:38 --> Total execution time: 0.1430
INFO - 2018-03-31 02:40:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:40:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:40:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:40:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:40:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:40:46 --> Final output sent to browser
DEBUG - 2018-03-31 02:40:46 --> Total execution time: 0.1500
INFO - 2018-03-31 02:42:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:42:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:42:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:42:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:42:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:42:04 --> Final output sent to browser
DEBUG - 2018-03-31 02:42:04 --> Total execution time: 0.1310
INFO - 2018-03-31 02:45:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-03-31 02:45:30 --> syntax error, unexpected '.'
ERROR - 2018-03-31 02:45:30 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\FlickNews\admin\application\views\galery\image.php 49
INFO - 2018-03-31 02:45:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:45:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:45:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:45:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:45:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:45:42 --> Final output sent to browser
DEBUG - 2018-03-31 02:45:42 --> Total execution time: 0.1400
INFO - 2018-03-31 02:45:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:45:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:45:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:45:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:45:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:45:49 --> Final output sent to browser
DEBUG - 2018-03-31 02:45:49 --> Total execution time: 0.1350
INFO - 2018-03-31 02:46:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:46:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:46:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:46:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:46:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:46:13 --> Final output sent to browser
DEBUG - 2018-03-31 02:46:13 --> Total execution time: 0.1310
INFO - 2018-03-31 02:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:46:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:46:56 --> Final output sent to browser
DEBUG - 2018-03-31 02:46:56 --> Total execution time: 0.1390
INFO - 2018-03-31 02:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:47:17 --> Final output sent to browser
DEBUG - 2018-03-31 02:47:17 --> Total execution time: 0.1480
INFO - 2018-03-31 02:47:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:47:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:47:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:47:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:47:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:47:47 --> Final output sent to browser
DEBUG - 2018-03-31 02:47:47 --> Total execution time: 0.1360
INFO - 2018-03-31 02:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:48:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:48:22 --> Final output sent to browser
DEBUG - 2018-03-31 02:48:22 --> Total execution time: 0.1490
INFO - 2018-03-31 02:51:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:51:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:51:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:51:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 02:51:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:51:06 --> Final output sent to browser
DEBUG - 2018-03-31 02:51:06 --> Total execution time: 0.1450
INFO - 2018-03-31 02:51:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:51:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:51:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:51:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 02:51:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:51:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:51:09 --> Final output sent to browser
DEBUG - 2018-03-31 02:51:09 --> Total execution time: 0.1270
DEBUG - 2018-03-31 02:51:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 02:51:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 02:51:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:51:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:51:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:51:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 02:51:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:51:30 --> Final output sent to browser
DEBUG - 2018-03-31 02:51:30 --> Total execution time: 0.1430
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:51:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:51:36 --> Final output sent to browser
DEBUG - 2018-03-31 02:51:36 --> Total execution time: 0.1670
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 02:52:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 02:52:32 --> Final output sent to browser
DEBUG - 2018-03-31 02:52:32 --> Total execution time: 0.1370
INFO - 2018-03-31 12:34:03 --> Config Class Initialized
INFO - 2018-03-31 12:34:03 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:34:03 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:34:03 --> Utf8 Class Initialized
INFO - 2018-03-31 12:34:03 --> URI Class Initialized
INFO - 2018-03-31 12:34:03 --> Router Class Initialized
INFO - 2018-03-31 12:34:03 --> Output Class Initialized
INFO - 2018-03-31 12:34:03 --> Security Class Initialized
DEBUG - 2018-03-31 12:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:34:03 --> Input Class Initialized
INFO - 2018-03-31 12:34:03 --> Language Class Initialized
INFO - 2018-03-31 12:34:03 --> Loader Class Initialized
INFO - 2018-03-31 12:34:03 --> Helper loaded: common_helper
INFO - 2018-03-31 12:34:04 --> Database Driver Class Initialized
ERROR - 2018-03-31 12:34:04 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-31 12:34:04 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-31 12:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:34:04 --> Email Class Initialized
INFO - 2018-03-31 12:34:04 --> Controller Class Initialized
INFO - 2018-03-31 12:34:04 --> Helper loaded: form_helper
INFO - 2018-03-31 12:34:04 --> Form Validation Class Initialized
INFO - 2018-03-31 12:34:04 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:34:04 --> Helper loaded: url_helper
INFO - 2018-03-31 12:34:04 --> Model Class Initialized
INFO - 2018-03-31 12:34:04 --> Model Class Initialized
INFO - 2018-03-31 12:34:04 --> Model Class Initialized
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:04:04 --> Final output sent to browser
DEBUG - 2018-03-31 16:04:04 --> Total execution time: 0.2000
INFO - 2018-03-31 12:34:04 --> Config Class Initialized
INFO - 2018-03-31 12:34:04 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:34:04 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:34:04 --> Utf8 Class Initialized
INFO - 2018-03-31 12:34:04 --> URI Class Initialized
INFO - 2018-03-31 12:34:04 --> Router Class Initialized
INFO - 2018-03-31 12:34:04 --> Output Class Initialized
INFO - 2018-03-31 12:34:04 --> Security Class Initialized
DEBUG - 2018-03-31 12:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:34:04 --> Input Class Initialized
INFO - 2018-03-31 12:34:04 --> Language Class Initialized
INFO - 2018-03-31 12:34:04 --> Loader Class Initialized
INFO - 2018-03-31 12:34:04 --> Helper loaded: common_helper
INFO - 2018-03-31 12:34:04 --> Database Driver Class Initialized
INFO - 2018-03-31 12:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:34:04 --> Email Class Initialized
INFO - 2018-03-31 12:34:04 --> Controller Class Initialized
INFO - 2018-03-31 12:34:04 --> Helper loaded: form_helper
INFO - 2018-03-31 12:34:04 --> Form Validation Class Initialized
INFO - 2018-03-31 12:34:04 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:34:04 --> Helper loaded: url_helper
INFO - 2018-03-31 12:34:04 --> Model Class Initialized
INFO - 2018-03-31 12:34:04 --> Model Class Initialized
INFO - 2018-03-31 12:34:04 --> Model Class Initialized
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:04:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:04:04 --> Final output sent to browser
DEBUG - 2018-03-31 16:04:04 --> Total execution time: 0.1250
INFO - 2018-03-31 12:38:54 --> Config Class Initialized
INFO - 2018-03-31 12:38:54 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:38:54 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:38:54 --> Utf8 Class Initialized
INFO - 2018-03-31 12:38:54 --> URI Class Initialized
INFO - 2018-03-31 12:38:54 --> Router Class Initialized
INFO - 2018-03-31 12:38:54 --> Output Class Initialized
INFO - 2018-03-31 12:38:54 --> Security Class Initialized
DEBUG - 2018-03-31 12:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:38:54 --> Input Class Initialized
INFO - 2018-03-31 12:38:54 --> Language Class Initialized
ERROR - 2018-03-31 12:38:54 --> syntax error, unexpected '}'
ERROR - 2018-03-31 12:38:54 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\FlickNews\admin\application\controllers\Galery.php 55
INFO - 2018-03-31 12:39:40 --> Config Class Initialized
INFO - 2018-03-31 12:39:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:39:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:39:40 --> Utf8 Class Initialized
INFO - 2018-03-31 12:39:40 --> URI Class Initialized
INFO - 2018-03-31 12:39:40 --> Router Class Initialized
INFO - 2018-03-31 12:39:40 --> Output Class Initialized
INFO - 2018-03-31 12:39:40 --> Security Class Initialized
DEBUG - 2018-03-31 12:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:39:40 --> Input Class Initialized
INFO - 2018-03-31 12:39:40 --> Language Class Initialized
INFO - 2018-03-31 12:39:40 --> Loader Class Initialized
INFO - 2018-03-31 12:39:40 --> Helper loaded: common_helper
INFO - 2018-03-31 12:39:40 --> Database Driver Class Initialized
ERROR - 2018-03-31 12:39:40 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-31 12:39:40 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-31 12:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:39:40 --> Email Class Initialized
INFO - 2018-03-31 12:39:40 --> Controller Class Initialized
INFO - 2018-03-31 12:39:40 --> Helper loaded: form_helper
INFO - 2018-03-31 12:39:40 --> Form Validation Class Initialized
INFO - 2018-03-31 12:39:40 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:39:40 --> Helper loaded: url_helper
INFO - 2018-03-31 12:39:40 --> Model Class Initialized
INFO - 2018-03-31 12:39:40 --> Model Class Initialized
INFO - 2018-03-31 12:39:40 --> Model Class Initialized
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:09:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:09:40 --> Final output sent to browser
DEBUG - 2018-03-31 16:09:40 --> Total execution time: 0.2175
INFO - 2018-03-31 12:39:41 --> Config Class Initialized
INFO - 2018-03-31 12:39:41 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:39:41 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:39:41 --> Utf8 Class Initialized
INFO - 2018-03-31 12:39:41 --> URI Class Initialized
INFO - 2018-03-31 12:39:41 --> Router Class Initialized
INFO - 2018-03-31 12:39:41 --> Output Class Initialized
INFO - 2018-03-31 12:39:41 --> Security Class Initialized
DEBUG - 2018-03-31 12:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:39:41 --> Input Class Initialized
INFO - 2018-03-31 12:39:41 --> Language Class Initialized
INFO - 2018-03-31 12:39:41 --> Loader Class Initialized
INFO - 2018-03-31 12:39:41 --> Helper loaded: common_helper
INFO - 2018-03-31 12:39:41 --> Database Driver Class Initialized
INFO - 2018-03-31 12:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:39:41 --> Email Class Initialized
INFO - 2018-03-31 12:39:41 --> Controller Class Initialized
INFO - 2018-03-31 12:39:41 --> Helper loaded: form_helper
INFO - 2018-03-31 12:39:41 --> Form Validation Class Initialized
INFO - 2018-03-31 12:39:41 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:39:41 --> Helper loaded: url_helper
INFO - 2018-03-31 12:39:41 --> Model Class Initialized
INFO - 2018-03-31 12:39:41 --> Model Class Initialized
INFO - 2018-03-31 12:39:41 --> Model Class Initialized
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:09:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:09:41 --> Final output sent to browser
DEBUG - 2018-03-31 16:09:41 --> Total execution time: 0.1350
INFO - 2018-03-31 12:39:55 --> Config Class Initialized
INFO - 2018-03-31 12:39:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:39:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:39:55 --> Utf8 Class Initialized
INFO - 2018-03-31 12:39:55 --> URI Class Initialized
INFO - 2018-03-31 12:39:55 --> Router Class Initialized
INFO - 2018-03-31 12:39:55 --> Output Class Initialized
INFO - 2018-03-31 12:39:55 --> Security Class Initialized
DEBUG - 2018-03-31 12:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:39:55 --> Input Class Initialized
INFO - 2018-03-31 12:39:55 --> Language Class Initialized
INFO - 2018-03-31 12:39:55 --> Loader Class Initialized
INFO - 2018-03-31 12:39:55 --> Helper loaded: common_helper
INFO - 2018-03-31 12:39:55 --> Database Driver Class Initialized
INFO - 2018-03-31 12:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:39:55 --> Email Class Initialized
INFO - 2018-03-31 12:39:55 --> Controller Class Initialized
INFO - 2018-03-31 12:39:55 --> Helper loaded: form_helper
INFO - 2018-03-31 12:39:55 --> Form Validation Class Initialized
INFO - 2018-03-31 12:39:55 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:39:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:39:55 --> Helper loaded: url_helper
INFO - 2018-03-31 12:39:55 --> Model Class Initialized
INFO - 2018-03-31 12:39:55 --> Model Class Initialized
INFO - 2018-03-31 12:39:55 --> Model Class Initialized
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:09:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:09:55 --> Final output sent to browser
DEBUG - 2018-03-31 16:09:55 --> Total execution time: 0.1650
INFO - 2018-03-31 12:41:25 --> Config Class Initialized
INFO - 2018-03-31 12:41:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:41:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:41:25 --> Utf8 Class Initialized
INFO - 2018-03-31 12:41:25 --> URI Class Initialized
INFO - 2018-03-31 12:41:25 --> Router Class Initialized
INFO - 2018-03-31 12:41:25 --> Output Class Initialized
INFO - 2018-03-31 12:41:25 --> Security Class Initialized
DEBUG - 2018-03-31 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:41:25 --> Input Class Initialized
INFO - 2018-03-31 12:41:25 --> Language Class Initialized
INFO - 2018-03-31 12:41:25 --> Loader Class Initialized
INFO - 2018-03-31 12:41:25 --> Helper loaded: common_helper
INFO - 2018-03-31 12:41:25 --> Database Driver Class Initialized
INFO - 2018-03-31 12:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:41:25 --> Email Class Initialized
INFO - 2018-03-31 12:41:25 --> Controller Class Initialized
INFO - 2018-03-31 12:41:25 --> Helper loaded: form_helper
INFO - 2018-03-31 12:41:25 --> Form Validation Class Initialized
INFO - 2018-03-31 12:41:25 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:41:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:41:25 --> Helper loaded: url_helper
INFO - 2018-03-31 12:41:25 --> Model Class Initialized
INFO - 2018-03-31 12:41:25 --> Model Class Initialized
INFO - 2018-03-31 12:41:26 --> Model Class Initialized
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:11:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:11:26 --> Final output sent to browser
DEBUG - 2018-03-31 16:11:26 --> Total execution time: 0.1400
INFO - 2018-03-31 12:42:38 --> Config Class Initialized
INFO - 2018-03-31 12:42:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:42:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:42:38 --> Utf8 Class Initialized
INFO - 2018-03-31 12:42:38 --> URI Class Initialized
INFO - 2018-03-31 12:42:38 --> Router Class Initialized
INFO - 2018-03-31 12:42:38 --> Output Class Initialized
INFO - 2018-03-31 12:42:38 --> Security Class Initialized
DEBUG - 2018-03-31 12:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:42:38 --> Input Class Initialized
INFO - 2018-03-31 12:42:38 --> Language Class Initialized
INFO - 2018-03-31 12:42:38 --> Loader Class Initialized
INFO - 2018-03-31 12:42:38 --> Helper loaded: common_helper
INFO - 2018-03-31 12:42:38 --> Database Driver Class Initialized
INFO - 2018-03-31 12:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:42:38 --> Email Class Initialized
INFO - 2018-03-31 12:42:38 --> Controller Class Initialized
INFO - 2018-03-31 12:42:38 --> Helper loaded: form_helper
INFO - 2018-03-31 12:42:38 --> Form Validation Class Initialized
INFO - 2018-03-31 12:42:38 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:42:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:42:38 --> Helper loaded: url_helper
INFO - 2018-03-31 12:42:38 --> Model Class Initialized
INFO - 2018-03-31 12:42:38 --> Model Class Initialized
INFO - 2018-03-31 12:42:38 --> Model Class Initialized
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:12:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:12:38 --> Final output sent to browser
DEBUG - 2018-03-31 16:12:38 --> Total execution time: 0.1681
INFO - 2018-03-31 12:43:09 --> Config Class Initialized
INFO - 2018-03-31 12:43:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:09 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:09 --> URI Class Initialized
INFO - 2018-03-31 12:43:09 --> Router Class Initialized
INFO - 2018-03-31 12:43:09 --> Output Class Initialized
INFO - 2018-03-31 12:43:09 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:09 --> Input Class Initialized
INFO - 2018-03-31 12:43:09 --> Language Class Initialized
INFO - 2018-03-31 12:43:09 --> Loader Class Initialized
INFO - 2018-03-31 12:43:09 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:09 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:10 --> Email Class Initialized
INFO - 2018-03-31 12:43:10 --> Controller Class Initialized
INFO - 2018-03-31 12:43:10 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:10 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:10 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:10 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:10 --> Model Class Initialized
INFO - 2018-03-31 12:43:10 --> Model Class Initialized
INFO - 2018-03-31 12:43:10 --> Model Class Initialized
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:13:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:13:10 --> Final output sent to browser
DEBUG - 2018-03-31 16:13:10 --> Total execution time: 0.1375
INFO - 2018-03-31 12:43:13 --> Config Class Initialized
INFO - 2018-03-31 12:43:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:13 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:13 --> URI Class Initialized
INFO - 2018-03-31 12:43:13 --> Router Class Initialized
INFO - 2018-03-31 12:43:13 --> Output Class Initialized
INFO - 2018-03-31 12:43:13 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:13 --> Input Class Initialized
INFO - 2018-03-31 12:43:13 --> Language Class Initialized
INFO - 2018-03-31 12:43:13 --> Loader Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:13 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:13 --> Email Class Initialized
INFO - 2018-03-31 12:43:13 --> Controller Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:13 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:13 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:13 --> Model Class Initialized
INFO - 2018-03-31 12:43:13 --> Model Class Initialized
INFO - 2018-03-31 12:43:13 --> Config Class Initialized
INFO - 2018-03-31 12:43:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:13 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:13 --> URI Class Initialized
INFO - 2018-03-31 12:43:13 --> Router Class Initialized
INFO - 2018-03-31 12:43:13 --> Output Class Initialized
INFO - 2018-03-31 12:43:13 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:13 --> Input Class Initialized
INFO - 2018-03-31 12:43:13 --> Language Class Initialized
INFO - 2018-03-31 12:43:13 --> Loader Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:13 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:13 --> Email Class Initialized
INFO - 2018-03-31 12:43:13 --> Controller Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:13 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:13 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:13 --> Model Class Initialized
INFO - 2018-03-31 12:43:13 --> Model Class Initialized
INFO - 2018-03-31 12:43:13 --> Config Class Initialized
INFO - 2018-03-31 12:43:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:13 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:13 --> URI Class Initialized
DEBUG - 2018-03-31 12:43:13 --> No URI present. Default controller set.
INFO - 2018-03-31 12:43:13 --> Router Class Initialized
INFO - 2018-03-31 12:43:13 --> Output Class Initialized
INFO - 2018-03-31 12:43:13 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:13 --> Input Class Initialized
INFO - 2018-03-31 12:43:13 --> Language Class Initialized
INFO - 2018-03-31 12:43:13 --> Loader Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:13 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:13 --> Email Class Initialized
INFO - 2018-03-31 12:43:13 --> Controller Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:13 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:13 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:13 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:13 --> Model Class Initialized
INFO - 2018-03-31 12:43:13 --> Model Class Initialized
INFO - 2018-03-31 12:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-31 12:43:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 12:43:13 --> Final output sent to browser
DEBUG - 2018-03-31 12:43:13 --> Total execution time: 0.1625
INFO - 2018-03-31 12:43:17 --> Config Class Initialized
INFO - 2018-03-31 12:43:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:17 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:17 --> URI Class Initialized
DEBUG - 2018-03-31 12:43:17 --> No URI present. Default controller set.
INFO - 2018-03-31 12:43:17 --> Router Class Initialized
INFO - 2018-03-31 12:43:17 --> Output Class Initialized
INFO - 2018-03-31 12:43:17 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:17 --> Input Class Initialized
INFO - 2018-03-31 12:43:17 --> Language Class Initialized
INFO - 2018-03-31 12:43:17 --> Loader Class Initialized
INFO - 2018-03-31 12:43:17 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:17 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:17 --> Email Class Initialized
INFO - 2018-03-31 12:43:17 --> Controller Class Initialized
INFO - 2018-03-31 12:43:17 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:17 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:17 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:17 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:17 --> Model Class Initialized
INFO - 2018-03-31 12:43:17 --> Model Class Initialized
DEBUG - 2018-03-31 12:43:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 12:43:17 --> Config Class Initialized
INFO - 2018-03-31 12:43:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:17 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:17 --> URI Class Initialized
INFO - 2018-03-31 12:43:17 --> Router Class Initialized
INFO - 2018-03-31 12:43:17 --> Output Class Initialized
INFO - 2018-03-31 12:43:17 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:17 --> Input Class Initialized
INFO - 2018-03-31 12:43:17 --> Language Class Initialized
INFO - 2018-03-31 12:43:17 --> Loader Class Initialized
INFO - 2018-03-31 12:43:17 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:17 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:17 --> Email Class Initialized
INFO - 2018-03-31 12:43:17 --> Controller Class Initialized
INFO - 2018-03-31 12:43:17 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:17 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:17 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:17 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:17 --> Model Class Initialized
INFO - 2018-03-31 12:43:17 --> Model Class Initialized
INFO - 2018-03-31 12:43:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 12:43:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 12:43:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-31 12:43:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 12:43:17 --> Final output sent to browser
DEBUG - 2018-03-31 12:43:17 --> Total execution time: 0.1450
INFO - 2018-03-31 12:43:20 --> Config Class Initialized
INFO - 2018-03-31 12:43:20 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:20 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:20 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:20 --> URI Class Initialized
INFO - 2018-03-31 12:43:20 --> Router Class Initialized
INFO - 2018-03-31 12:43:20 --> Output Class Initialized
INFO - 2018-03-31 12:43:20 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:20 --> Input Class Initialized
INFO - 2018-03-31 12:43:20 --> Language Class Initialized
INFO - 2018-03-31 12:43:20 --> Loader Class Initialized
INFO - 2018-03-31 12:43:20 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:20 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:20 --> Email Class Initialized
INFO - 2018-03-31 12:43:20 --> Controller Class Initialized
INFO - 2018-03-31 12:43:20 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:20 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:20 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:20 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:20 --> Model Class Initialized
INFO - 2018-03-31 12:43:20 --> Model Class Initialized
INFO - 2018-03-31 12:43:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 12:43:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 12:43:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-31 12:43:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 12:43:20 --> Final output sent to browser
DEBUG - 2018-03-31 12:43:20 --> Total execution time: 0.1350
INFO - 2018-03-31 12:43:22 --> Config Class Initialized
INFO - 2018-03-31 12:43:22 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:22 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:22 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:22 --> URI Class Initialized
INFO - 2018-03-31 12:43:22 --> Router Class Initialized
INFO - 2018-03-31 12:43:22 --> Output Class Initialized
INFO - 2018-03-31 12:43:22 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:22 --> Input Class Initialized
INFO - 2018-03-31 12:43:22 --> Language Class Initialized
INFO - 2018-03-31 12:43:22 --> Loader Class Initialized
INFO - 2018-03-31 12:43:22 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:22 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:22 --> Email Class Initialized
INFO - 2018-03-31 12:43:22 --> Controller Class Initialized
INFO - 2018-03-31 12:43:22 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:22 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:22 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:22 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:22 --> Model Class Initialized
INFO - 2018-03-31 12:43:22 --> Model Class Initialized
INFO - 2018-03-31 12:43:22 --> Model Class Initialized
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:13:22 --> Final output sent to browser
DEBUG - 2018-03-31 16:13:22 --> Total execution time: 0.1600
INFO - 2018-03-31 12:43:25 --> Config Class Initialized
INFO - 2018-03-31 12:43:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:25 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:25 --> URI Class Initialized
INFO - 2018-03-31 12:43:25 --> Router Class Initialized
INFO - 2018-03-31 12:43:25 --> Output Class Initialized
INFO - 2018-03-31 12:43:25 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:25 --> Input Class Initialized
INFO - 2018-03-31 12:43:25 --> Language Class Initialized
INFO - 2018-03-31 12:43:25 --> Loader Class Initialized
INFO - 2018-03-31 12:43:25 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:25 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:25 --> Email Class Initialized
INFO - 2018-03-31 12:43:25 --> Controller Class Initialized
INFO - 2018-03-31 12:43:25 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:25 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:25 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:25 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:25 --> Model Class Initialized
INFO - 2018-03-31 12:43:25 --> Model Class Initialized
INFO - 2018-03-31 12:43:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 12:43:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 12:43:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-31 12:43:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 12:43:25 --> Final output sent to browser
DEBUG - 2018-03-31 12:43:25 --> Total execution time: 0.1300
INFO - 2018-03-31 12:43:27 --> Config Class Initialized
INFO - 2018-03-31 12:43:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:43:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:43:27 --> Utf8 Class Initialized
INFO - 2018-03-31 12:43:27 --> URI Class Initialized
INFO - 2018-03-31 12:43:27 --> Router Class Initialized
INFO - 2018-03-31 12:43:27 --> Output Class Initialized
INFO - 2018-03-31 12:43:27 --> Security Class Initialized
DEBUG - 2018-03-31 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:43:27 --> Input Class Initialized
INFO - 2018-03-31 12:43:27 --> Language Class Initialized
INFO - 2018-03-31 12:43:27 --> Loader Class Initialized
INFO - 2018-03-31 12:43:27 --> Helper loaded: common_helper
INFO - 2018-03-31 12:43:27 --> Database Driver Class Initialized
INFO - 2018-03-31 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:43:27 --> Email Class Initialized
INFO - 2018-03-31 12:43:27 --> Controller Class Initialized
INFO - 2018-03-31 12:43:27 --> Helper loaded: form_helper
INFO - 2018-03-31 12:43:27 --> Form Validation Class Initialized
INFO - 2018-03-31 12:43:27 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:43:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:43:27 --> Helper loaded: url_helper
INFO - 2018-03-31 12:43:27 --> Model Class Initialized
INFO - 2018-03-31 12:43:27 --> Model Class Initialized
INFO - 2018-03-31 12:43:27 --> Model Class Initialized
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:13:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:13:27 --> Final output sent to browser
DEBUG - 2018-03-31 16:13:27 --> Total execution time: 0.1550
INFO - 2018-03-31 12:48:38 --> Config Class Initialized
INFO - 2018-03-31 12:48:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:48:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:48:38 --> Utf8 Class Initialized
INFO - 2018-03-31 12:48:38 --> URI Class Initialized
INFO - 2018-03-31 12:48:38 --> Router Class Initialized
INFO - 2018-03-31 12:48:38 --> Output Class Initialized
INFO - 2018-03-31 12:48:38 --> Security Class Initialized
DEBUG - 2018-03-31 12:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:48:38 --> Input Class Initialized
INFO - 2018-03-31 12:48:38 --> Language Class Initialized
INFO - 2018-03-31 12:48:38 --> Loader Class Initialized
INFO - 2018-03-31 12:48:38 --> Helper loaded: common_helper
INFO - 2018-03-31 12:48:38 --> Database Driver Class Initialized
INFO - 2018-03-31 12:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:48:38 --> Email Class Initialized
INFO - 2018-03-31 12:48:38 --> Controller Class Initialized
INFO - 2018-03-31 12:48:38 --> Helper loaded: form_helper
INFO - 2018-03-31 12:48:38 --> Form Validation Class Initialized
INFO - 2018-03-31 12:48:38 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:48:38 --> Helper loaded: url_helper
INFO - 2018-03-31 12:48:38 --> Model Class Initialized
INFO - 2018-03-31 12:48:38 --> Model Class Initialized
INFO - 2018-03-31 12:48:38 --> Model Class Initialized
INFO - 2018-03-31 12:49:28 --> Config Class Initialized
INFO - 2018-03-31 12:49:28 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:49:28 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:49:28 --> Utf8 Class Initialized
INFO - 2018-03-31 12:49:28 --> URI Class Initialized
INFO - 2018-03-31 12:49:28 --> Router Class Initialized
INFO - 2018-03-31 12:49:28 --> Output Class Initialized
INFO - 2018-03-31 12:49:28 --> Security Class Initialized
DEBUG - 2018-03-31 12:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:49:28 --> Input Class Initialized
INFO - 2018-03-31 12:49:28 --> Language Class Initialized
INFO - 2018-03-31 12:49:28 --> Loader Class Initialized
INFO - 2018-03-31 12:49:28 --> Helper loaded: common_helper
INFO - 2018-03-31 12:49:28 --> Database Driver Class Initialized
INFO - 2018-03-31 12:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:49:28 --> Email Class Initialized
INFO - 2018-03-31 12:49:28 --> Controller Class Initialized
INFO - 2018-03-31 12:49:28 --> Helper loaded: form_helper
INFO - 2018-03-31 12:49:28 --> Form Validation Class Initialized
INFO - 2018-03-31 12:49:28 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:49:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:49:28 --> Helper loaded: url_helper
INFO - 2018-03-31 12:49:28 --> Model Class Initialized
INFO - 2018-03-31 12:49:28 --> Model Class Initialized
INFO - 2018-03-31 12:49:28 --> Model Class Initialized
INFO - 2018-03-31 12:49:59 --> Config Class Initialized
INFO - 2018-03-31 12:49:59 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:49:59 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:49:59 --> Utf8 Class Initialized
INFO - 2018-03-31 12:49:59 --> URI Class Initialized
INFO - 2018-03-31 12:49:59 --> Router Class Initialized
INFO - 2018-03-31 12:49:59 --> Output Class Initialized
INFO - 2018-03-31 12:49:59 --> Security Class Initialized
DEBUG - 2018-03-31 12:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:49:59 --> Input Class Initialized
INFO - 2018-03-31 12:49:59 --> Language Class Initialized
INFO - 2018-03-31 12:49:59 --> Loader Class Initialized
INFO - 2018-03-31 12:49:59 --> Helper loaded: common_helper
INFO - 2018-03-31 12:49:59 --> Database Driver Class Initialized
INFO - 2018-03-31 12:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:49:59 --> Email Class Initialized
INFO - 2018-03-31 12:49:59 --> Controller Class Initialized
INFO - 2018-03-31 12:49:59 --> Helper loaded: form_helper
INFO - 2018-03-31 12:49:59 --> Form Validation Class Initialized
INFO - 2018-03-31 12:49:59 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:49:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:49:59 --> Helper loaded: url_helper
INFO - 2018-03-31 12:49:59 --> Model Class Initialized
INFO - 2018-03-31 12:49:59 --> Model Class Initialized
INFO - 2018-03-31 12:49:59 --> Model Class Initialized
INFO - 2018-03-31 16:19:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:19:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:19:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:19:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:19:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:19:59 --> Final output sent to browser
DEBUG - 2018-03-31 16:19:59 --> Total execution time: 0.1350
INFO - 2018-03-31 12:51:12 --> Config Class Initialized
INFO - 2018-03-31 12:51:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:51:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:51:12 --> Utf8 Class Initialized
INFO - 2018-03-31 12:51:12 --> URI Class Initialized
INFO - 2018-03-31 12:51:12 --> Router Class Initialized
INFO - 2018-03-31 12:51:12 --> Output Class Initialized
INFO - 2018-03-31 12:51:12 --> Security Class Initialized
DEBUG - 2018-03-31 12:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:51:12 --> Input Class Initialized
INFO - 2018-03-31 12:51:12 --> Language Class Initialized
INFO - 2018-03-31 12:51:12 --> Loader Class Initialized
INFO - 2018-03-31 12:51:12 --> Helper loaded: common_helper
INFO - 2018-03-31 12:51:12 --> Database Driver Class Initialized
INFO - 2018-03-31 12:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:51:12 --> Email Class Initialized
INFO - 2018-03-31 12:51:12 --> Controller Class Initialized
INFO - 2018-03-31 12:51:12 --> Helper loaded: form_helper
INFO - 2018-03-31 12:51:12 --> Form Validation Class Initialized
INFO - 2018-03-31 12:51:12 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:51:12 --> Helper loaded: url_helper
INFO - 2018-03-31 12:51:12 --> Model Class Initialized
INFO - 2018-03-31 12:51:12 --> Model Class Initialized
INFO - 2018-03-31 12:51:12 --> Model Class Initialized
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:21:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:21:12 --> Final output sent to browser
DEBUG - 2018-03-31 16:21:12 --> Total execution time: 0.1420
INFO - 2018-03-31 12:53:49 --> Config Class Initialized
INFO - 2018-03-31 12:53:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:53:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:53:49 --> Utf8 Class Initialized
INFO - 2018-03-31 12:53:49 --> URI Class Initialized
INFO - 2018-03-31 12:53:49 --> Router Class Initialized
INFO - 2018-03-31 12:53:49 --> Output Class Initialized
INFO - 2018-03-31 12:53:49 --> Security Class Initialized
DEBUG - 2018-03-31 12:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:53:49 --> Input Class Initialized
INFO - 2018-03-31 12:53:49 --> Language Class Initialized
INFO - 2018-03-31 12:53:49 --> Loader Class Initialized
INFO - 2018-03-31 12:53:49 --> Helper loaded: common_helper
INFO - 2018-03-31 12:53:49 --> Database Driver Class Initialized
INFO - 2018-03-31 12:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:53:49 --> Email Class Initialized
INFO - 2018-03-31 12:53:49 --> Controller Class Initialized
INFO - 2018-03-31 12:53:49 --> Helper loaded: form_helper
INFO - 2018-03-31 12:53:49 --> Form Validation Class Initialized
INFO - 2018-03-31 12:53:49 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:53:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:53:49 --> Helper loaded: url_helper
INFO - 2018-03-31 12:53:49 --> Model Class Initialized
INFO - 2018-03-31 12:53:49 --> Model Class Initialized
INFO - 2018-03-31 12:53:49 --> Model Class Initialized
INFO - 2018-03-31 16:23:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:23:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:23:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:23:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 16:23:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:23:49 --> Final output sent to browser
DEBUG - 2018-03-31 16:23:49 --> Total execution time: 0.3880
INFO - 2018-03-31 12:57:02 --> Config Class Initialized
INFO - 2018-03-31 12:57:02 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:57:02 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:57:02 --> Utf8 Class Initialized
INFO - 2018-03-31 12:57:02 --> URI Class Initialized
INFO - 2018-03-31 12:57:02 --> Router Class Initialized
INFO - 2018-03-31 12:57:02 --> Output Class Initialized
INFO - 2018-03-31 12:57:02 --> Security Class Initialized
DEBUG - 2018-03-31 12:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:57:02 --> Input Class Initialized
INFO - 2018-03-31 12:57:02 --> Language Class Initialized
INFO - 2018-03-31 12:57:02 --> Loader Class Initialized
INFO - 2018-03-31 12:57:02 --> Helper loaded: common_helper
INFO - 2018-03-31 12:57:02 --> Database Driver Class Initialized
INFO - 2018-03-31 12:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:57:02 --> Email Class Initialized
INFO - 2018-03-31 12:57:02 --> Controller Class Initialized
INFO - 2018-03-31 12:57:02 --> Helper loaded: form_helper
INFO - 2018-03-31 12:57:02 --> Form Validation Class Initialized
INFO - 2018-03-31 12:57:02 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:57:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:57:02 --> Helper loaded: url_helper
INFO - 2018-03-31 12:57:02 --> Model Class Initialized
INFO - 2018-03-31 12:57:02 --> Model Class Initialized
INFO - 2018-03-31 12:57:02 --> Model Class Initialized
INFO - 2018-03-31 16:27:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:27:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:27:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:27:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 16:27:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:27:02 --> Final output sent to browser
DEBUG - 2018-03-31 16:27:02 --> Total execution time: 0.1870
INFO - 2018-03-31 12:57:05 --> Config Class Initialized
INFO - 2018-03-31 12:57:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:57:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:57:05 --> Utf8 Class Initialized
INFO - 2018-03-31 12:57:05 --> URI Class Initialized
INFO - 2018-03-31 12:57:05 --> Router Class Initialized
INFO - 2018-03-31 12:57:05 --> Output Class Initialized
INFO - 2018-03-31 12:57:05 --> Security Class Initialized
DEBUG - 2018-03-31 12:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:57:05 --> Input Class Initialized
INFO - 2018-03-31 12:57:05 --> Language Class Initialized
INFO - 2018-03-31 12:57:05 --> Loader Class Initialized
INFO - 2018-03-31 12:57:05 --> Helper loaded: common_helper
INFO - 2018-03-31 12:57:05 --> Database Driver Class Initialized
INFO - 2018-03-31 12:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:57:05 --> Email Class Initialized
INFO - 2018-03-31 12:57:05 --> Controller Class Initialized
INFO - 2018-03-31 12:57:05 --> Helper loaded: form_helper
INFO - 2018-03-31 12:57:05 --> Form Validation Class Initialized
INFO - 2018-03-31 12:57:05 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:57:05 --> Helper loaded: url_helper
INFO - 2018-03-31 12:57:05 --> Model Class Initialized
INFO - 2018-03-31 12:57:05 --> Model Class Initialized
INFO - 2018-03-31 12:57:05 --> Model Class Initialized
INFO - 2018-03-31 12:57:09 --> Config Class Initialized
INFO - 2018-03-31 12:57:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:57:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:57:09 --> Utf8 Class Initialized
INFO - 2018-03-31 12:57:09 --> URI Class Initialized
INFO - 2018-03-31 12:57:09 --> Router Class Initialized
INFO - 2018-03-31 12:57:09 --> Output Class Initialized
INFO - 2018-03-31 12:57:09 --> Security Class Initialized
DEBUG - 2018-03-31 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:57:09 --> Input Class Initialized
INFO - 2018-03-31 12:57:09 --> Language Class Initialized
INFO - 2018-03-31 12:57:09 --> Loader Class Initialized
INFO - 2018-03-31 12:57:09 --> Helper loaded: common_helper
INFO - 2018-03-31 12:57:09 --> Database Driver Class Initialized
INFO - 2018-03-31 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:57:09 --> Email Class Initialized
INFO - 2018-03-31 12:57:09 --> Controller Class Initialized
INFO - 2018-03-31 12:57:09 --> Helper loaded: form_helper
INFO - 2018-03-31 12:57:09 --> Form Validation Class Initialized
INFO - 2018-03-31 12:57:09 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:57:09 --> Helper loaded: url_helper
INFO - 2018-03-31 12:57:09 --> Model Class Initialized
INFO - 2018-03-31 12:57:09 --> Model Class Initialized
INFO - 2018-03-31 12:57:09 --> Model Class Initialized
INFO - 2018-03-31 16:27:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:27:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:27:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:27:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 16:27:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:27:09 --> Final output sent to browser
DEBUG - 2018-03-31 16:27:09 --> Total execution time: 0.1390
INFO - 2018-03-31 12:57:13 --> Config Class Initialized
INFO - 2018-03-31 12:57:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:57:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:57:13 --> Utf8 Class Initialized
INFO - 2018-03-31 12:57:13 --> URI Class Initialized
INFO - 2018-03-31 12:57:13 --> Router Class Initialized
INFO - 2018-03-31 12:57:13 --> Output Class Initialized
INFO - 2018-03-31 12:57:13 --> Security Class Initialized
DEBUG - 2018-03-31 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:57:13 --> Input Class Initialized
INFO - 2018-03-31 12:57:13 --> Language Class Initialized
INFO - 2018-03-31 12:57:13 --> Loader Class Initialized
INFO - 2018-03-31 12:57:13 --> Helper loaded: common_helper
INFO - 2018-03-31 12:57:13 --> Database Driver Class Initialized
INFO - 2018-03-31 12:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:57:13 --> Email Class Initialized
INFO - 2018-03-31 12:57:13 --> Controller Class Initialized
INFO - 2018-03-31 12:57:13 --> Helper loaded: form_helper
INFO - 2018-03-31 12:57:13 --> Form Validation Class Initialized
INFO - 2018-03-31 12:57:13 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:57:13 --> Helper loaded: url_helper
INFO - 2018-03-31 12:57:13 --> Model Class Initialized
INFO - 2018-03-31 12:57:13 --> Model Class Initialized
INFO - 2018-03-31 12:57:13 --> Model Class Initialized
INFO - 2018-03-31 12:57:15 --> Config Class Initialized
INFO - 2018-03-31 12:57:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:57:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:57:15 --> Utf8 Class Initialized
INFO - 2018-03-31 12:57:15 --> URI Class Initialized
INFO - 2018-03-31 12:57:15 --> Router Class Initialized
INFO - 2018-03-31 12:57:15 --> Output Class Initialized
INFO - 2018-03-31 12:57:15 --> Security Class Initialized
DEBUG - 2018-03-31 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:57:15 --> Input Class Initialized
INFO - 2018-03-31 12:57:15 --> Language Class Initialized
INFO - 2018-03-31 12:57:15 --> Loader Class Initialized
INFO - 2018-03-31 12:57:15 --> Helper loaded: common_helper
INFO - 2018-03-31 12:57:15 --> Database Driver Class Initialized
INFO - 2018-03-31 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:57:15 --> Email Class Initialized
INFO - 2018-03-31 12:57:15 --> Controller Class Initialized
INFO - 2018-03-31 12:57:15 --> Helper loaded: form_helper
INFO - 2018-03-31 12:57:15 --> Form Validation Class Initialized
INFO - 2018-03-31 12:57:15 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:57:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:57:15 --> Helper loaded: url_helper
INFO - 2018-03-31 12:57:15 --> Model Class Initialized
INFO - 2018-03-31 12:57:15 --> Model Class Initialized
INFO - 2018-03-31 12:57:15 --> Model Class Initialized
INFO - 2018-03-31 16:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 16:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:27:15 --> Final output sent to browser
DEBUG - 2018-03-31 16:27:15 --> Total execution time: 0.1520
INFO - 2018-03-31 12:58:28 --> Config Class Initialized
INFO - 2018-03-31 12:58:28 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:58:28 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:58:28 --> Utf8 Class Initialized
INFO - 2018-03-31 12:58:28 --> URI Class Initialized
INFO - 2018-03-31 12:58:28 --> Router Class Initialized
INFO - 2018-03-31 12:58:28 --> Output Class Initialized
INFO - 2018-03-31 12:58:28 --> Security Class Initialized
DEBUG - 2018-03-31 12:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:58:28 --> Input Class Initialized
INFO - 2018-03-31 12:58:28 --> Language Class Initialized
INFO - 2018-03-31 12:58:28 --> Loader Class Initialized
INFO - 2018-03-31 12:58:28 --> Helper loaded: common_helper
INFO - 2018-03-31 12:58:28 --> Database Driver Class Initialized
INFO - 2018-03-31 12:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:58:28 --> Email Class Initialized
INFO - 2018-03-31 12:58:28 --> Controller Class Initialized
INFO - 2018-03-31 12:58:28 --> Helper loaded: form_helper
INFO - 2018-03-31 12:58:28 --> Form Validation Class Initialized
INFO - 2018-03-31 12:58:28 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:58:28 --> Helper loaded: url_helper
INFO - 2018-03-31 12:58:28 --> Model Class Initialized
INFO - 2018-03-31 12:58:28 --> Model Class Initialized
INFO - 2018-03-31 12:58:28 --> Model Class Initialized
INFO - 2018-03-31 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 16:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:28:28 --> Final output sent to browser
DEBUG - 2018-03-31 16:28:28 --> Total execution time: 0.1370
INFO - 2018-03-31 12:58:31 --> Config Class Initialized
INFO - 2018-03-31 12:58:31 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:58:31 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:58:31 --> Utf8 Class Initialized
INFO - 2018-03-31 12:58:31 --> URI Class Initialized
INFO - 2018-03-31 12:58:31 --> Router Class Initialized
INFO - 2018-03-31 12:58:31 --> Output Class Initialized
INFO - 2018-03-31 12:58:31 --> Security Class Initialized
DEBUG - 2018-03-31 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:58:31 --> Input Class Initialized
INFO - 2018-03-31 12:58:31 --> Language Class Initialized
INFO - 2018-03-31 12:58:31 --> Loader Class Initialized
INFO - 2018-03-31 12:58:31 --> Helper loaded: common_helper
INFO - 2018-03-31 12:58:31 --> Database Driver Class Initialized
INFO - 2018-03-31 12:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:58:31 --> Email Class Initialized
INFO - 2018-03-31 12:58:31 --> Controller Class Initialized
INFO - 2018-03-31 12:58:31 --> Helper loaded: form_helper
INFO - 2018-03-31 12:58:31 --> Form Validation Class Initialized
INFO - 2018-03-31 12:58:31 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:58:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:58:31 --> Helper loaded: url_helper
INFO - 2018-03-31 12:58:31 --> Model Class Initialized
INFO - 2018-03-31 12:58:31 --> Model Class Initialized
INFO - 2018-03-31 12:58:31 --> Model Class Initialized
INFO - 2018-03-31 16:28:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:28:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:28:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 16:28:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 16:28:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:28:31 --> Final output sent to browser
DEBUG - 2018-03-31 16:28:31 --> Total execution time: 0.1310
INFO - 2018-03-31 12:58:35 --> Config Class Initialized
INFO - 2018-03-31 12:58:35 --> Hooks Class Initialized
DEBUG - 2018-03-31 12:58:35 --> UTF-8 Support Enabled
INFO - 2018-03-31 12:58:35 --> Utf8 Class Initialized
INFO - 2018-03-31 12:58:35 --> URI Class Initialized
INFO - 2018-03-31 12:58:35 --> Router Class Initialized
INFO - 2018-03-31 12:58:35 --> Output Class Initialized
INFO - 2018-03-31 12:58:35 --> Security Class Initialized
DEBUG - 2018-03-31 12:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 12:58:35 --> Input Class Initialized
INFO - 2018-03-31 12:58:35 --> Language Class Initialized
INFO - 2018-03-31 12:58:35 --> Loader Class Initialized
INFO - 2018-03-31 12:58:35 --> Helper loaded: common_helper
INFO - 2018-03-31 12:58:35 --> Database Driver Class Initialized
INFO - 2018-03-31 12:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 12:58:35 --> Email Class Initialized
INFO - 2018-03-31 12:58:35 --> Controller Class Initialized
INFO - 2018-03-31 12:58:35 --> Helper loaded: form_helper
INFO - 2018-03-31 12:58:35 --> Form Validation Class Initialized
INFO - 2018-03-31 12:58:35 --> Helper loaded: email_helper
DEBUG - 2018-03-31 12:58:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 12:58:35 --> Helper loaded: url_helper
INFO - 2018-03-31 12:58:35 --> Model Class Initialized
INFO - 2018-03-31 12:58:35 --> Model Class Initialized
INFO - 2018-03-31 12:58:35 --> Model Class Initialized
INFO - 2018-03-31 16:32:17 --> Config Class Initialized
INFO - 2018-03-31 16:32:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:32:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:32:17 --> Utf8 Class Initialized
INFO - 2018-03-31 16:32:17 --> URI Class Initialized
INFO - 2018-03-31 16:32:17 --> Router Class Initialized
INFO - 2018-03-31 16:32:17 --> Output Class Initialized
INFO - 2018-03-31 16:32:17 --> Security Class Initialized
DEBUG - 2018-03-31 16:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:32:17 --> Input Class Initialized
INFO - 2018-03-31 16:32:17 --> Language Class Initialized
INFO - 2018-03-31 16:32:17 --> Loader Class Initialized
INFO - 2018-03-31 16:32:17 --> Helper loaded: common_helper
INFO - 2018-03-31 16:32:17 --> Database Driver Class Initialized
INFO - 2018-03-31 16:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:32:17 --> Email Class Initialized
INFO - 2018-03-31 16:32:17 --> Controller Class Initialized
INFO - 2018-03-31 16:32:17 --> Helper loaded: form_helper
INFO - 2018-03-31 16:32:17 --> Form Validation Class Initialized
INFO - 2018-03-31 16:32:17 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:32:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:32:17 --> Helper loaded: url_helper
INFO - 2018-03-31 16:32:17 --> Model Class Initialized
INFO - 2018-03-31 16:32:17 --> Model Class Initialized
INFO - 2018-03-31 16:32:17 --> Model Class Initialized
INFO - 2018-03-31 16:32:42 --> Config Class Initialized
INFO - 2018-03-31 16:32:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:32:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:32:42 --> Utf8 Class Initialized
INFO - 2018-03-31 16:32:42 --> URI Class Initialized
INFO - 2018-03-31 16:32:42 --> Router Class Initialized
INFO - 2018-03-31 16:32:42 --> Output Class Initialized
INFO - 2018-03-31 16:32:42 --> Security Class Initialized
DEBUG - 2018-03-31 16:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:32:42 --> Input Class Initialized
INFO - 2018-03-31 16:32:42 --> Language Class Initialized
INFO - 2018-03-31 16:32:42 --> Loader Class Initialized
INFO - 2018-03-31 16:32:42 --> Helper loaded: common_helper
INFO - 2018-03-31 16:32:42 --> Database Driver Class Initialized
ERROR - 2018-03-31 16:32:42 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-31 16:32:42 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-31 16:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:32:43 --> Email Class Initialized
INFO - 2018-03-31 16:32:43 --> Controller Class Initialized
INFO - 2018-03-31 16:32:43 --> Helper loaded: form_helper
INFO - 2018-03-31 16:32:43 --> Form Validation Class Initialized
INFO - 2018-03-31 16:32:43 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:32:43 --> Helper loaded: url_helper
INFO - 2018-03-31 16:32:43 --> Model Class Initialized
INFO - 2018-03-31 16:32:43 --> Model Class Initialized
INFO - 2018-03-31 16:32:43 --> Model Class Initialized
INFO - 2018-03-31 16:32:47 --> Config Class Initialized
INFO - 2018-03-31 16:32:47 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:32:47 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:32:47 --> Utf8 Class Initialized
INFO - 2018-03-31 16:32:47 --> URI Class Initialized
INFO - 2018-03-31 16:32:47 --> Router Class Initialized
INFO - 2018-03-31 16:32:47 --> Output Class Initialized
INFO - 2018-03-31 16:32:47 --> Security Class Initialized
DEBUG - 2018-03-31 16:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:32:47 --> Input Class Initialized
INFO - 2018-03-31 16:32:47 --> Language Class Initialized
INFO - 2018-03-31 16:32:47 --> Loader Class Initialized
INFO - 2018-03-31 16:32:47 --> Helper loaded: common_helper
INFO - 2018-03-31 16:32:47 --> Database Driver Class Initialized
INFO - 2018-03-31 16:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:32:47 --> Email Class Initialized
INFO - 2018-03-31 16:32:47 --> Controller Class Initialized
INFO - 2018-03-31 16:32:47 --> Helper loaded: form_helper
INFO - 2018-03-31 16:32:47 --> Form Validation Class Initialized
INFO - 2018-03-31 16:32:47 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:32:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:32:47 --> Helper loaded: url_helper
INFO - 2018-03-31 16:32:47 --> Model Class Initialized
INFO - 2018-03-31 16:32:47 --> Model Class Initialized
INFO - 2018-03-31 16:32:47 --> Model Class Initialized
INFO - 2018-03-31 16:32:56 --> Config Class Initialized
INFO - 2018-03-31 16:32:56 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:32:56 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:32:56 --> Utf8 Class Initialized
INFO - 2018-03-31 16:32:56 --> URI Class Initialized
INFO - 2018-03-31 16:32:56 --> Router Class Initialized
INFO - 2018-03-31 16:32:56 --> Output Class Initialized
INFO - 2018-03-31 16:32:56 --> Security Class Initialized
DEBUG - 2018-03-31 16:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:32:56 --> Input Class Initialized
INFO - 2018-03-31 16:32:56 --> Language Class Initialized
INFO - 2018-03-31 16:32:56 --> Loader Class Initialized
INFO - 2018-03-31 16:32:56 --> Helper loaded: common_helper
INFO - 2018-03-31 16:32:56 --> Database Driver Class Initialized
INFO - 2018-03-31 16:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:32:56 --> Email Class Initialized
INFO - 2018-03-31 16:32:56 --> Controller Class Initialized
INFO - 2018-03-31 16:32:56 --> Helper loaded: form_helper
INFO - 2018-03-31 16:32:56 --> Form Validation Class Initialized
INFO - 2018-03-31 16:32:56 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:32:56 --> Helper loaded: url_helper
INFO - 2018-03-31 16:32:56 --> Model Class Initialized
INFO - 2018-03-31 16:32:56 --> Model Class Initialized
INFO - 2018-03-31 16:32:56 --> Model Class Initialized
INFO - 2018-03-31 20:02:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:02:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-03-31 20:02:56 --> Undefined property: stdClass::$sourceImage
ERROR - 2018-03-31 20:02:56 --> Severity: Notice --> Undefined property: stdClass::$sourceImage C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 65
INFO - 2018-03-31 20:02:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:02:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:02:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:02:56 --> Final output sent to browser
DEBUG - 2018-03-31 20:02:56 --> Total execution time: 0.1870
INFO - 2018-03-31 16:32:56 --> Config Class Initialized
INFO - 2018-03-31 16:32:56 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:32:56 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:32:56 --> Utf8 Class Initialized
INFO - 2018-03-31 16:32:56 --> URI Class Initialized
INFO - 2018-03-31 16:32:56 --> Router Class Initialized
INFO - 2018-03-31 16:32:56 --> Output Class Initialized
INFO - 2018-03-31 16:32:56 --> Security Class Initialized
DEBUG - 2018-03-31 16:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:32:56 --> Input Class Initialized
INFO - 2018-03-31 16:32:56 --> Language Class Initialized
INFO - 2018-03-31 16:32:56 --> Loader Class Initialized
INFO - 2018-03-31 16:32:56 --> Helper loaded: common_helper
INFO - 2018-03-31 16:32:56 --> Database Driver Class Initialized
INFO - 2018-03-31 16:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:32:56 --> Email Class Initialized
INFO - 2018-03-31 16:32:56 --> Controller Class Initialized
INFO - 2018-03-31 16:32:56 --> Helper loaded: form_helper
INFO - 2018-03-31 16:32:56 --> Form Validation Class Initialized
INFO - 2018-03-31 16:32:56 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:32:56 --> Helper loaded: url_helper
INFO - 2018-03-31 16:32:56 --> Model Class Initialized
INFO - 2018-03-31 16:32:56 --> Model Class Initialized
INFO - 2018-03-31 16:32:56 --> Model Class Initialized
ERROR - 2018-03-31 20:02:56 --> Creating default object from empty value
ERROR - 2018-03-31 20:02:56 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-03-31 20:02:56 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:56 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-03-31 20:02:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:02:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$sourceImage
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$sourceImage C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 65
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 95
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 104
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 110
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 127
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 128
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 128
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 149
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 220
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 310
ERROR - 2018-03-31 20:02:57 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:02:57 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 337
INFO - 2018-03-31 20:02:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:02:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:02:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:02:57 --> Final output sent to browser
DEBUG - 2018-03-31 20:02:57 --> Total execution time: 0.3490
INFO - 2018-03-31 16:35:18 --> Config Class Initialized
INFO - 2018-03-31 16:35:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:35:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:35:18 --> Utf8 Class Initialized
INFO - 2018-03-31 16:35:18 --> URI Class Initialized
INFO - 2018-03-31 16:35:18 --> Router Class Initialized
INFO - 2018-03-31 16:35:18 --> Output Class Initialized
INFO - 2018-03-31 16:35:18 --> Security Class Initialized
DEBUG - 2018-03-31 16:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:35:18 --> Input Class Initialized
INFO - 2018-03-31 16:35:18 --> Language Class Initialized
INFO - 2018-03-31 16:35:18 --> Loader Class Initialized
INFO - 2018-03-31 16:35:18 --> Helper loaded: common_helper
INFO - 2018-03-31 16:35:18 --> Database Driver Class Initialized
ERROR - 2018-03-31 16:35:18 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-03-31 16:35:18 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-03-31 16:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:35:18 --> Email Class Initialized
INFO - 2018-03-31 16:35:18 --> Controller Class Initialized
INFO - 2018-03-31 16:35:18 --> Helper loaded: form_helper
INFO - 2018-03-31 16:35:18 --> Form Validation Class Initialized
INFO - 2018-03-31 16:35:18 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:35:18 --> Helper loaded: url_helper
INFO - 2018-03-31 16:35:18 --> Model Class Initialized
INFO - 2018-03-31 16:35:18 --> Model Class Initialized
INFO - 2018-03-31 16:35:18 --> Model Class Initialized
INFO - 2018-03-31 20:05:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:05:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-03-31 20:05:18 --> Undefined property: stdClass::$sourceImage
ERROR - 2018-03-31 20:05:18 --> Severity: Notice --> Undefined property: stdClass::$sourceImage C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 61
INFO - 2018-03-31 20:05:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:05:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:05:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:05:18 --> Final output sent to browser
DEBUG - 2018-03-31 20:05:18 --> Total execution time: 0.1560
INFO - 2018-03-31 16:35:19 --> Config Class Initialized
INFO - 2018-03-31 16:35:19 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:35:19 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:35:19 --> Utf8 Class Initialized
INFO - 2018-03-31 16:35:19 --> URI Class Initialized
INFO - 2018-03-31 16:35:19 --> Router Class Initialized
INFO - 2018-03-31 16:35:19 --> Output Class Initialized
INFO - 2018-03-31 16:35:19 --> Security Class Initialized
DEBUG - 2018-03-31 16:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:35:19 --> Input Class Initialized
INFO - 2018-03-31 16:35:19 --> Language Class Initialized
INFO - 2018-03-31 16:35:19 --> Loader Class Initialized
INFO - 2018-03-31 16:35:19 --> Helper loaded: common_helper
INFO - 2018-03-31 16:35:19 --> Database Driver Class Initialized
INFO - 2018-03-31 16:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:35:19 --> Email Class Initialized
INFO - 2018-03-31 16:35:19 --> Controller Class Initialized
INFO - 2018-03-31 16:35:19 --> Helper loaded: form_helper
INFO - 2018-03-31 16:35:19 --> Form Validation Class Initialized
INFO - 2018-03-31 16:35:19 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:35:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:35:19 --> Helper loaded: url_helper
INFO - 2018-03-31 16:35:19 --> Model Class Initialized
INFO - 2018-03-31 16:35:19 --> Model Class Initialized
INFO - 2018-03-31 16:35:19 --> Model Class Initialized
INFO - 2018-03-31 20:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-03-31 20:05:19 --> Undefined property: stdClass::$sourceImage
ERROR - 2018-03-31 20:05:19 --> Severity: Notice --> Undefined property: stdClass::$sourceImage C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 61
INFO - 2018-03-31 20:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:05:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:05:19 --> Final output sent to browser
DEBUG - 2018-03-31 20:05:19 --> Total execution time: 0.1410
INFO - 2018-03-31 16:41:16 --> Config Class Initialized
INFO - 2018-03-31 16:41:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:41:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:41:16 --> Utf8 Class Initialized
INFO - 2018-03-31 16:41:16 --> URI Class Initialized
INFO - 2018-03-31 16:41:16 --> Router Class Initialized
INFO - 2018-03-31 16:41:16 --> Output Class Initialized
INFO - 2018-03-31 16:41:16 --> Security Class Initialized
DEBUG - 2018-03-31 16:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:41:16 --> Input Class Initialized
INFO - 2018-03-31 16:41:16 --> Language Class Initialized
INFO - 2018-03-31 16:41:16 --> Loader Class Initialized
INFO - 2018-03-31 16:41:16 --> Helper loaded: common_helper
INFO - 2018-03-31 16:41:16 --> Database Driver Class Initialized
INFO - 2018-03-31 16:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:41:16 --> Email Class Initialized
INFO - 2018-03-31 16:41:16 --> Controller Class Initialized
INFO - 2018-03-31 16:41:16 --> Helper loaded: form_helper
INFO - 2018-03-31 16:41:16 --> Form Validation Class Initialized
INFO - 2018-03-31 16:41:16 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:41:16 --> Helper loaded: url_helper
INFO - 2018-03-31 16:41:16 --> Model Class Initialized
INFO - 2018-03-31 16:41:16 --> Model Class Initialized
INFO - 2018-03-31 16:41:16 --> Model Class Initialized
INFO - 2018-03-31 20:11:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-03-31 20:11:16 --> syntax error, unexpected end of file
ERROR - 2018-03-31 20:11:16 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 381
INFO - 2018-03-31 16:41:34 --> Config Class Initialized
INFO - 2018-03-31 16:41:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:41:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:41:34 --> Utf8 Class Initialized
INFO - 2018-03-31 16:41:34 --> URI Class Initialized
INFO - 2018-03-31 16:41:34 --> Router Class Initialized
INFO - 2018-03-31 16:41:34 --> Output Class Initialized
INFO - 2018-03-31 16:41:34 --> Security Class Initialized
DEBUG - 2018-03-31 16:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:41:34 --> Input Class Initialized
INFO - 2018-03-31 16:41:34 --> Language Class Initialized
INFO - 2018-03-31 16:41:34 --> Loader Class Initialized
INFO - 2018-03-31 16:41:34 --> Helper loaded: common_helper
INFO - 2018-03-31 16:41:34 --> Database Driver Class Initialized
INFO - 2018-03-31 16:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:41:34 --> Email Class Initialized
INFO - 2018-03-31 16:41:34 --> Controller Class Initialized
INFO - 2018-03-31 16:41:34 --> Helper loaded: form_helper
INFO - 2018-03-31 16:41:34 --> Form Validation Class Initialized
INFO - 2018-03-31 16:41:34 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:41:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:41:34 --> Helper loaded: url_helper
INFO - 2018-03-31 16:41:34 --> Model Class Initialized
INFO - 2018-03-31 16:41:34 --> Model Class Initialized
INFO - 2018-03-31 16:41:34 --> Model Class Initialized
INFO - 2018-03-31 20:11:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:11:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:11:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:11:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:11:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:11:34 --> Final output sent to browser
DEBUG - 2018-03-31 20:11:34 --> Total execution time: 0.1490
INFO - 2018-03-31 16:42:12 --> Config Class Initialized
INFO - 2018-03-31 16:42:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:12 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:12 --> URI Class Initialized
INFO - 2018-03-31 16:42:12 --> Router Class Initialized
INFO - 2018-03-31 16:42:12 --> Output Class Initialized
INFO - 2018-03-31 16:42:12 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:12 --> Input Class Initialized
INFO - 2018-03-31 16:42:12 --> Language Class Initialized
INFO - 2018-03-31 16:42:12 --> Loader Class Initialized
INFO - 2018-03-31 16:42:12 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:12 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:12 --> Email Class Initialized
INFO - 2018-03-31 16:42:12 --> Controller Class Initialized
INFO - 2018-03-31 16:42:12 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:12 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:12 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:12 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:12 --> Model Class Initialized
INFO - 2018-03-31 16:42:12 --> Model Class Initialized
INFO - 2018-03-31 16:42:12 --> Model Class Initialized
INFO - 2018-03-31 16:42:12 --> Config Class Initialized
INFO - 2018-03-31 16:42:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:12 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:12 --> URI Class Initialized
INFO - 2018-03-31 16:42:12 --> Router Class Initialized
INFO - 2018-03-31 16:42:12 --> Output Class Initialized
INFO - 2018-03-31 16:42:12 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:12 --> Input Class Initialized
INFO - 2018-03-31 16:42:12 --> Language Class Initialized
INFO - 2018-03-31 16:42:12 --> Loader Class Initialized
INFO - 2018-03-31 16:42:12 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:13 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:13 --> Email Class Initialized
INFO - 2018-03-31 16:42:13 --> Controller Class Initialized
INFO - 2018-03-31 16:42:13 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:13 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:13 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:13 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:13 --> Model Class Initialized
INFO - 2018-03-31 16:42:13 --> Model Class Initialized
INFO - 2018-03-31 16:42:13 --> Config Class Initialized
INFO - 2018-03-31 16:42:13 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:13 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:13 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:13 --> URI Class Initialized
DEBUG - 2018-03-31 16:42:13 --> No URI present. Default controller set.
INFO - 2018-03-31 16:42:13 --> Router Class Initialized
INFO - 2018-03-31 16:42:13 --> Output Class Initialized
INFO - 2018-03-31 16:42:13 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:13 --> Input Class Initialized
INFO - 2018-03-31 16:42:13 --> Language Class Initialized
INFO - 2018-03-31 16:42:13 --> Loader Class Initialized
INFO - 2018-03-31 16:42:13 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:13 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:13 --> Email Class Initialized
INFO - 2018-03-31 16:42:13 --> Controller Class Initialized
INFO - 2018-03-31 16:42:13 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:13 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:13 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:13 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:13 --> Model Class Initialized
INFO - 2018-03-31 16:42:13 --> Model Class Initialized
INFO - 2018-03-31 16:42:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-31 16:42:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:42:13 --> Final output sent to browser
DEBUG - 2018-03-31 16:42:13 --> Total execution time: 0.1270
INFO - 2018-03-31 16:42:15 --> Config Class Initialized
INFO - 2018-03-31 16:42:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:15 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:15 --> URI Class Initialized
DEBUG - 2018-03-31 16:42:15 --> No URI present. Default controller set.
INFO - 2018-03-31 16:42:15 --> Router Class Initialized
INFO - 2018-03-31 16:42:15 --> Output Class Initialized
INFO - 2018-03-31 16:42:15 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:15 --> Input Class Initialized
INFO - 2018-03-31 16:42:16 --> Language Class Initialized
INFO - 2018-03-31 16:42:16 --> Loader Class Initialized
INFO - 2018-03-31 16:42:16 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:16 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:16 --> Email Class Initialized
INFO - 2018-03-31 16:42:16 --> Controller Class Initialized
INFO - 2018-03-31 16:42:16 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:16 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:16 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:16 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:16 --> Model Class Initialized
INFO - 2018-03-31 16:42:16 --> Model Class Initialized
DEBUG - 2018-03-31 16:42:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 16:42:16 --> Config Class Initialized
INFO - 2018-03-31 16:42:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:16 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:16 --> URI Class Initialized
INFO - 2018-03-31 16:42:16 --> Router Class Initialized
INFO - 2018-03-31 16:42:16 --> Output Class Initialized
INFO - 2018-03-31 16:42:16 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:16 --> Input Class Initialized
INFO - 2018-03-31 16:42:16 --> Language Class Initialized
INFO - 2018-03-31 16:42:16 --> Loader Class Initialized
INFO - 2018-03-31 16:42:16 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:16 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:16 --> Email Class Initialized
INFO - 2018-03-31 16:42:16 --> Controller Class Initialized
INFO - 2018-03-31 16:42:16 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:16 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:16 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:16 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:16 --> Model Class Initialized
INFO - 2018-03-31 16:42:16 --> Model Class Initialized
INFO - 2018-03-31 16:42:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 16:42:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 16:42:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-31 16:42:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 16:42:16 --> Final output sent to browser
DEBUG - 2018-03-31 16:42:16 --> Total execution time: 0.1320
INFO - 2018-03-31 16:42:18 --> Config Class Initialized
INFO - 2018-03-31 16:42:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:18 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:18 --> URI Class Initialized
INFO - 2018-03-31 16:42:18 --> Router Class Initialized
INFO - 2018-03-31 16:42:18 --> Output Class Initialized
INFO - 2018-03-31 16:42:18 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:18 --> Input Class Initialized
INFO - 2018-03-31 16:42:18 --> Language Class Initialized
INFO - 2018-03-31 16:42:18 --> Loader Class Initialized
INFO - 2018-03-31 16:42:18 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:18 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:18 --> Email Class Initialized
INFO - 2018-03-31 16:42:18 --> Controller Class Initialized
INFO - 2018-03-31 16:42:18 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:18 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:18 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:18 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:18 --> Model Class Initialized
INFO - 2018-03-31 16:42:18 --> Model Class Initialized
INFO - 2018-03-31 16:42:18 --> Model Class Initialized
INFO - 2018-03-31 20:12:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:12:19 --> Final output sent to browser
DEBUG - 2018-03-31 20:12:19 --> Total execution time: 0.1670
INFO - 2018-03-31 16:42:21 --> Config Class Initialized
INFO - 2018-03-31 16:42:21 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:21 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:21 --> URI Class Initialized
INFO - 2018-03-31 16:42:21 --> Router Class Initialized
INFO - 2018-03-31 16:42:22 --> Output Class Initialized
INFO - 2018-03-31 16:42:22 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:22 --> Input Class Initialized
INFO - 2018-03-31 16:42:22 --> Language Class Initialized
INFO - 2018-03-31 16:42:22 --> Loader Class Initialized
INFO - 2018-03-31 16:42:22 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:22 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:22 --> Email Class Initialized
INFO - 2018-03-31 16:42:22 --> Controller Class Initialized
INFO - 2018-03-31 16:42:22 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:22 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:22 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:22 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:22 --> Model Class Initialized
INFO - 2018-03-31 16:42:22 --> Model Class Initialized
INFO - 2018-03-31 16:42:22 --> Model Class Initialized
INFO - 2018-03-31 20:12:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:12:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:12:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:12:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-03-31 20:12:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:12:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:12:22 --> Final output sent to browser
DEBUG - 2018-03-31 20:12:22 --> Total execution time: 0.1350
INFO - 2018-03-31 16:42:29 --> Config Class Initialized
INFO - 2018-03-31 16:42:29 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:29 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:29 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:29 --> URI Class Initialized
INFO - 2018-03-31 16:42:29 --> Router Class Initialized
INFO - 2018-03-31 16:42:29 --> Output Class Initialized
INFO - 2018-03-31 16:42:29 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:29 --> Input Class Initialized
INFO - 2018-03-31 16:42:29 --> Language Class Initialized
INFO - 2018-03-31 16:42:29 --> Loader Class Initialized
INFO - 2018-03-31 16:42:29 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:29 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:30 --> Email Class Initialized
INFO - 2018-03-31 16:42:30 --> Controller Class Initialized
INFO - 2018-03-31 16:42:30 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:30 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:30 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:30 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:30 --> Model Class Initialized
INFO - 2018-03-31 16:42:30 --> Model Class Initialized
INFO - 2018-03-31 16:42:30 --> Model Class Initialized
INFO - 2018-03-31 20:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:12:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:12:30 --> Final output sent to browser
DEBUG - 2018-03-31 20:12:30 --> Total execution time: 0.1370
INFO - 2018-03-31 16:42:32 --> Config Class Initialized
INFO - 2018-03-31 16:42:32 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:32 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:32 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:32 --> URI Class Initialized
INFO - 2018-03-31 16:42:32 --> Router Class Initialized
INFO - 2018-03-31 16:42:32 --> Output Class Initialized
INFO - 2018-03-31 16:42:32 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:32 --> Input Class Initialized
INFO - 2018-03-31 16:42:32 --> Language Class Initialized
INFO - 2018-03-31 16:42:32 --> Loader Class Initialized
INFO - 2018-03-31 16:42:32 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:32 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:32 --> Email Class Initialized
INFO - 2018-03-31 16:42:32 --> Controller Class Initialized
INFO - 2018-03-31 16:42:32 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:32 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:32 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:32 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:32 --> Model Class Initialized
INFO - 2018-03-31 16:42:32 --> Model Class Initialized
INFO - 2018-03-31 16:42:32 --> Model Class Initialized
INFO - 2018-03-31 20:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:12:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:12:32 --> Final output sent to browser
DEBUG - 2018-03-31 20:12:32 --> Total execution time: 0.1390
INFO - 2018-03-31 16:42:47 --> Config Class Initialized
INFO - 2018-03-31 16:42:47 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:47 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:47 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:47 --> URI Class Initialized
INFO - 2018-03-31 16:42:47 --> Router Class Initialized
INFO - 2018-03-31 16:42:47 --> Output Class Initialized
INFO - 2018-03-31 16:42:47 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:47 --> Input Class Initialized
INFO - 2018-03-31 16:42:47 --> Language Class Initialized
INFO - 2018-03-31 16:42:47 --> Loader Class Initialized
INFO - 2018-03-31 16:42:47 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:47 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:47 --> Email Class Initialized
INFO - 2018-03-31 16:42:47 --> Controller Class Initialized
INFO - 2018-03-31 16:42:47 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:47 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:47 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:47 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:47 --> Model Class Initialized
INFO - 2018-03-31 16:42:47 --> Model Class Initialized
INFO - 2018-03-31 16:42:47 --> Model Class Initialized
ERROR - 2018-03-31 20:12:48 --> Undefined index: edit_source_Image
ERROR - 2018-03-31 20:12:48 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 538
INFO - 2018-03-31 16:42:48 --> Config Class Initialized
INFO - 2018-03-31 16:42:48 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:42:48 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:42:48 --> Utf8 Class Initialized
INFO - 2018-03-31 16:42:48 --> URI Class Initialized
INFO - 2018-03-31 16:42:48 --> Router Class Initialized
INFO - 2018-03-31 16:42:48 --> Output Class Initialized
INFO - 2018-03-31 16:42:48 --> Security Class Initialized
DEBUG - 2018-03-31 16:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:42:48 --> Input Class Initialized
INFO - 2018-03-31 16:42:48 --> Language Class Initialized
INFO - 2018-03-31 16:42:48 --> Loader Class Initialized
INFO - 2018-03-31 16:42:48 --> Helper loaded: common_helper
INFO - 2018-03-31 16:42:48 --> Database Driver Class Initialized
INFO - 2018-03-31 16:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:42:48 --> Email Class Initialized
INFO - 2018-03-31 16:42:48 --> Controller Class Initialized
INFO - 2018-03-31 16:42:48 --> Helper loaded: form_helper
INFO - 2018-03-31 16:42:48 --> Form Validation Class Initialized
INFO - 2018-03-31 16:42:48 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:42:48 --> Helper loaded: url_helper
INFO - 2018-03-31 16:42:48 --> Model Class Initialized
INFO - 2018-03-31 16:42:48 --> Model Class Initialized
INFO - 2018-03-31 16:42:48 --> Model Class Initialized
INFO - 2018-03-31 20:12:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:12:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:12:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:12:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:12:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:12:48 --> Final output sent to browser
DEBUG - 2018-03-31 20:12:48 --> Total execution time: 0.1430
INFO - 2018-03-31 16:43:04 --> Config Class Initialized
INFO - 2018-03-31 16:43:04 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:43:04 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:43:04 --> Utf8 Class Initialized
INFO - 2018-03-31 16:43:04 --> URI Class Initialized
INFO - 2018-03-31 16:43:04 --> Router Class Initialized
INFO - 2018-03-31 16:43:04 --> Output Class Initialized
INFO - 2018-03-31 16:43:04 --> Security Class Initialized
DEBUG - 2018-03-31 16:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:43:04 --> Input Class Initialized
INFO - 2018-03-31 16:43:04 --> Language Class Initialized
INFO - 2018-03-31 16:43:04 --> Loader Class Initialized
INFO - 2018-03-31 16:43:04 --> Helper loaded: common_helper
INFO - 2018-03-31 16:43:04 --> Database Driver Class Initialized
INFO - 2018-03-31 16:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:43:04 --> Email Class Initialized
INFO - 2018-03-31 16:43:04 --> Controller Class Initialized
INFO - 2018-03-31 16:43:04 --> Helper loaded: form_helper
INFO - 2018-03-31 16:43:04 --> Form Validation Class Initialized
INFO - 2018-03-31 16:43:04 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:43:04 --> Helper loaded: url_helper
INFO - 2018-03-31 16:43:04 --> Model Class Initialized
INFO - 2018-03-31 16:43:04 --> Model Class Initialized
INFO - 2018-03-31 16:43:04 --> Model Class Initialized
INFO - 2018-03-31 20:13:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:13:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:13:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:13:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:13:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:13:04 --> Final output sent to browser
DEBUG - 2018-03-31 20:13:04 --> Total execution time: 0.1280
INFO - 2018-03-31 16:43:21 --> Config Class Initialized
INFO - 2018-03-31 16:43:21 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:43:21 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:43:21 --> Utf8 Class Initialized
INFO - 2018-03-31 16:43:21 --> URI Class Initialized
INFO - 2018-03-31 16:43:21 --> Router Class Initialized
INFO - 2018-03-31 16:43:21 --> Output Class Initialized
INFO - 2018-03-31 16:43:21 --> Security Class Initialized
DEBUG - 2018-03-31 16:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:43:21 --> Input Class Initialized
INFO - 2018-03-31 16:43:21 --> Language Class Initialized
INFO - 2018-03-31 16:43:21 --> Loader Class Initialized
INFO - 2018-03-31 16:43:21 --> Helper loaded: common_helper
INFO - 2018-03-31 16:43:22 --> Database Driver Class Initialized
INFO - 2018-03-31 16:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:43:22 --> Email Class Initialized
INFO - 2018-03-31 16:43:22 --> Controller Class Initialized
INFO - 2018-03-31 16:43:22 --> Helper loaded: form_helper
INFO - 2018-03-31 16:43:22 --> Form Validation Class Initialized
INFO - 2018-03-31 16:43:22 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:43:22 --> Helper loaded: url_helper
INFO - 2018-03-31 16:43:22 --> Model Class Initialized
INFO - 2018-03-31 16:43:22 --> Model Class Initialized
INFO - 2018-03-31 16:43:22 --> Model Class Initialized
INFO - 2018-03-31 20:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:13:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:13:22 --> Final output sent to browser
DEBUG - 2018-03-31 20:13:22 --> Total execution time: 0.1310
INFO - 2018-03-31 16:44:25 --> Config Class Initialized
INFO - 2018-03-31 16:44:25 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:44:25 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:44:25 --> Utf8 Class Initialized
INFO - 2018-03-31 16:44:25 --> URI Class Initialized
INFO - 2018-03-31 16:44:25 --> Router Class Initialized
INFO - 2018-03-31 16:44:25 --> Output Class Initialized
INFO - 2018-03-31 16:44:25 --> Security Class Initialized
DEBUG - 2018-03-31 16:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:44:25 --> Input Class Initialized
INFO - 2018-03-31 16:44:25 --> Language Class Initialized
INFO - 2018-03-31 16:44:25 --> Loader Class Initialized
INFO - 2018-03-31 16:44:25 --> Helper loaded: common_helper
INFO - 2018-03-31 16:44:25 --> Database Driver Class Initialized
INFO - 2018-03-31 16:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:44:25 --> Email Class Initialized
INFO - 2018-03-31 16:44:25 --> Controller Class Initialized
INFO - 2018-03-31 16:44:25 --> Helper loaded: form_helper
INFO - 2018-03-31 16:44:25 --> Form Validation Class Initialized
INFO - 2018-03-31 16:44:25 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:44:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:44:25 --> Helper loaded: url_helper
INFO - 2018-03-31 16:44:25 --> Model Class Initialized
INFO - 2018-03-31 16:44:25 --> Model Class Initialized
INFO - 2018-03-31 16:44:25 --> Model Class Initialized
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:14:25 --> Final output sent to browser
DEBUG - 2018-03-31 20:14:25 --> Total execution time: 0.1590
INFO - 2018-03-31 16:46:43 --> Config Class Initialized
INFO - 2018-03-31 16:46:43 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:46:43 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:46:43 --> Utf8 Class Initialized
INFO - 2018-03-31 16:46:43 --> URI Class Initialized
INFO - 2018-03-31 16:46:43 --> Router Class Initialized
INFO - 2018-03-31 16:46:43 --> Output Class Initialized
INFO - 2018-03-31 16:46:43 --> Security Class Initialized
DEBUG - 2018-03-31 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:46:43 --> Input Class Initialized
INFO - 2018-03-31 16:46:43 --> Language Class Initialized
INFO - 2018-03-31 16:46:43 --> Loader Class Initialized
INFO - 2018-03-31 16:46:43 --> Helper loaded: common_helper
INFO - 2018-03-31 16:46:43 --> Database Driver Class Initialized
INFO - 2018-03-31 16:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:46:43 --> Email Class Initialized
INFO - 2018-03-31 16:46:43 --> Controller Class Initialized
INFO - 2018-03-31 16:46:43 --> Helper loaded: form_helper
INFO - 2018-03-31 16:46:43 --> Form Validation Class Initialized
INFO - 2018-03-31 16:46:43 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:46:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:46:43 --> Helper loaded: url_helper
INFO - 2018-03-31 16:46:43 --> Model Class Initialized
INFO - 2018-03-31 16:46:43 --> Model Class Initialized
INFO - 2018-03-31 16:46:43 --> Model Class Initialized
INFO - 2018-03-31 20:16:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:16:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:16:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:16:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:16:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:16:43 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:43 --> Total execution time: 0.1730
INFO - 2018-03-31 16:46:49 --> Config Class Initialized
INFO - 2018-03-31 16:46:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:46:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:46:49 --> Utf8 Class Initialized
INFO - 2018-03-31 16:46:49 --> URI Class Initialized
INFO - 2018-03-31 16:46:49 --> Router Class Initialized
INFO - 2018-03-31 16:46:49 --> Output Class Initialized
INFO - 2018-03-31 16:46:49 --> Security Class Initialized
DEBUG - 2018-03-31 16:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:46:49 --> Input Class Initialized
INFO - 2018-03-31 16:46:49 --> Language Class Initialized
INFO - 2018-03-31 16:46:49 --> Loader Class Initialized
INFO - 2018-03-31 16:46:49 --> Helper loaded: common_helper
INFO - 2018-03-31 16:46:49 --> Database Driver Class Initialized
INFO - 2018-03-31 16:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:46:49 --> Email Class Initialized
INFO - 2018-03-31 16:46:49 --> Controller Class Initialized
INFO - 2018-03-31 16:46:49 --> Helper loaded: form_helper
INFO - 2018-03-31 16:46:49 --> Form Validation Class Initialized
INFO - 2018-03-31 16:46:49 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:46:49 --> Helper loaded: url_helper
INFO - 2018-03-31 16:46:49 --> Model Class Initialized
INFO - 2018-03-31 16:46:49 --> Model Class Initialized
INFO - 2018-03-31 16:46:49 --> Model Class Initialized
INFO - 2018-03-31 20:16:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:16:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:16:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:16:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:16:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:16:49 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:49 --> Total execution time: 0.1780
INFO - 2018-03-31 16:46:54 --> Config Class Initialized
INFO - 2018-03-31 16:46:54 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:46:54 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:46:54 --> Utf8 Class Initialized
INFO - 2018-03-31 16:46:54 --> URI Class Initialized
INFO - 2018-03-31 16:46:54 --> Router Class Initialized
INFO - 2018-03-31 16:46:54 --> Output Class Initialized
INFO - 2018-03-31 16:46:54 --> Security Class Initialized
DEBUG - 2018-03-31 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:46:54 --> Input Class Initialized
INFO - 2018-03-31 16:46:54 --> Language Class Initialized
INFO - 2018-03-31 16:46:54 --> Loader Class Initialized
INFO - 2018-03-31 16:46:54 --> Helper loaded: common_helper
INFO - 2018-03-31 16:46:54 --> Database Driver Class Initialized
INFO - 2018-03-31 16:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:46:54 --> Email Class Initialized
INFO - 2018-03-31 16:46:54 --> Controller Class Initialized
INFO - 2018-03-31 16:46:54 --> Helper loaded: form_helper
INFO - 2018-03-31 16:46:54 --> Form Validation Class Initialized
INFO - 2018-03-31 16:46:54 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:46:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:46:54 --> Helper loaded: url_helper
INFO - 2018-03-31 16:46:54 --> Model Class Initialized
INFO - 2018-03-31 16:46:54 --> Model Class Initialized
INFO - 2018-03-31 16:46:54 --> Model Class Initialized
INFO - 2018-03-31 20:16:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:16:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:16:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:16:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:16:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:16:54 --> Final output sent to browser
DEBUG - 2018-03-31 20:16:54 --> Total execution time: 0.1320
INFO - 2018-03-31 16:47:04 --> Config Class Initialized
INFO - 2018-03-31 16:47:04 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:04 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:04 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:04 --> URI Class Initialized
INFO - 2018-03-31 16:47:04 --> Router Class Initialized
INFO - 2018-03-31 16:47:04 --> Output Class Initialized
INFO - 2018-03-31 16:47:04 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:04 --> Input Class Initialized
INFO - 2018-03-31 16:47:04 --> Language Class Initialized
INFO - 2018-03-31 16:47:04 --> Loader Class Initialized
INFO - 2018-03-31 16:47:04 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:04 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:04 --> Email Class Initialized
INFO - 2018-03-31 16:47:04 --> Controller Class Initialized
INFO - 2018-03-31 16:47:04 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:04 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:04 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:04 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:04 --> Model Class Initialized
INFO - 2018-03-31 16:47:04 --> Model Class Initialized
INFO - 2018-03-31 16:47:04 --> Model Class Initialized
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:04 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:04 --> Total execution time: 0.1320
INFO - 2018-03-31 16:47:26 --> Config Class Initialized
INFO - 2018-03-31 16:47:26 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:26 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:26 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:26 --> URI Class Initialized
INFO - 2018-03-31 16:47:26 --> Router Class Initialized
INFO - 2018-03-31 16:47:26 --> Output Class Initialized
INFO - 2018-03-31 16:47:26 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:26 --> Input Class Initialized
INFO - 2018-03-31 16:47:26 --> Language Class Initialized
INFO - 2018-03-31 16:47:26 --> Loader Class Initialized
INFO - 2018-03-31 16:47:26 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:26 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:26 --> Email Class Initialized
INFO - 2018-03-31 16:47:26 --> Controller Class Initialized
INFO - 2018-03-31 16:47:26 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:26 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:26 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:26 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:26 --> Model Class Initialized
INFO - 2018-03-31 16:47:26 --> Model Class Initialized
INFO - 2018-03-31 16:47:26 --> Model Class Initialized
INFO - 2018-03-31 20:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:26 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:26 --> Total execution time: 0.1830
INFO - 2018-03-31 16:47:30 --> Config Class Initialized
INFO - 2018-03-31 16:47:30 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:30 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:30 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:30 --> URI Class Initialized
INFO - 2018-03-31 16:47:30 --> Router Class Initialized
INFO - 2018-03-31 16:47:30 --> Output Class Initialized
INFO - 2018-03-31 16:47:30 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:30 --> Input Class Initialized
INFO - 2018-03-31 16:47:30 --> Language Class Initialized
INFO - 2018-03-31 16:47:30 --> Loader Class Initialized
INFO - 2018-03-31 16:47:30 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:30 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:30 --> Email Class Initialized
INFO - 2018-03-31 16:47:30 --> Controller Class Initialized
INFO - 2018-03-31 16:47:30 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:30 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:30 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:30 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:30 --> Model Class Initialized
INFO - 2018-03-31 16:47:30 --> Model Class Initialized
INFO - 2018-03-31 16:47:30 --> Model Class Initialized
INFO - 2018-03-31 20:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:30 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:30 --> Total execution time: 0.1320
INFO - 2018-03-31 16:47:39 --> Config Class Initialized
INFO - 2018-03-31 16:47:39 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:39 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:39 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:39 --> URI Class Initialized
INFO - 2018-03-31 16:47:39 --> Router Class Initialized
INFO - 2018-03-31 16:47:39 --> Output Class Initialized
INFO - 2018-03-31 16:47:39 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:39 --> Input Class Initialized
INFO - 2018-03-31 16:47:39 --> Language Class Initialized
INFO - 2018-03-31 16:47:39 --> Loader Class Initialized
INFO - 2018-03-31 16:47:39 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:39 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:39 --> Email Class Initialized
INFO - 2018-03-31 16:47:39 --> Controller Class Initialized
INFO - 2018-03-31 16:47:39 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:39 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:39 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:39 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:39 --> Model Class Initialized
INFO - 2018-03-31 16:47:39 --> Model Class Initialized
INFO - 2018-03-31 16:47:39 --> Model Class Initialized
INFO - 2018-03-31 16:47:39 --> Config Class Initialized
INFO - 2018-03-31 16:47:39 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:39 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:39 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:39 --> URI Class Initialized
INFO - 2018-03-31 16:47:39 --> Router Class Initialized
INFO - 2018-03-31 16:47:39 --> Output Class Initialized
INFO - 2018-03-31 16:47:39 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:39 --> Input Class Initialized
INFO - 2018-03-31 16:47:39 --> Language Class Initialized
INFO - 2018-03-31 16:47:39 --> Loader Class Initialized
INFO - 2018-03-31 16:47:39 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:39 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:39 --> Email Class Initialized
INFO - 2018-03-31 16:47:39 --> Controller Class Initialized
INFO - 2018-03-31 16:47:39 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:39 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:39 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:39 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:39 --> Model Class Initialized
INFO - 2018-03-31 16:47:39 --> Model Class Initialized
INFO - 2018-03-31 16:47:39 --> Model Class Initialized
INFO - 2018-03-31 20:17:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:17:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:39 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:39 --> Total execution time: 0.1330
INFO - 2018-03-31 16:47:45 --> Config Class Initialized
INFO - 2018-03-31 16:47:45 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:45 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:45 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:45 --> URI Class Initialized
INFO - 2018-03-31 16:47:45 --> Router Class Initialized
INFO - 2018-03-31 16:47:45 --> Output Class Initialized
INFO - 2018-03-31 16:47:45 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:45 --> Input Class Initialized
INFO - 2018-03-31 16:47:45 --> Language Class Initialized
INFO - 2018-03-31 16:47:45 --> Loader Class Initialized
INFO - 2018-03-31 16:47:45 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:45 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:45 --> Email Class Initialized
INFO - 2018-03-31 16:47:45 --> Controller Class Initialized
INFO - 2018-03-31 16:47:45 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:45 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:45 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:45 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:45 --> Model Class Initialized
INFO - 2018-03-31 16:47:45 --> Model Class Initialized
INFO - 2018-03-31 16:47:45 --> Model Class Initialized
ERROR - 2018-03-31 20:17:45 --> Undefined index: edit_source_Image
ERROR - 2018-03-31 20:17:45 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 538
INFO - 2018-03-31 16:47:46 --> Config Class Initialized
INFO - 2018-03-31 16:47:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:46 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:46 --> URI Class Initialized
INFO - 2018-03-31 16:47:46 --> Router Class Initialized
INFO - 2018-03-31 16:47:46 --> Output Class Initialized
INFO - 2018-03-31 16:47:46 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:46 --> Input Class Initialized
INFO - 2018-03-31 16:47:46 --> Language Class Initialized
INFO - 2018-03-31 16:47:46 --> Loader Class Initialized
INFO - 2018-03-31 16:47:46 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:46 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:46 --> Email Class Initialized
INFO - 2018-03-31 16:47:46 --> Controller Class Initialized
INFO - 2018-03-31 16:47:46 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:46 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:46 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:46 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:46 --> Model Class Initialized
INFO - 2018-03-31 16:47:46 --> Model Class Initialized
INFO - 2018-03-31 16:47:46 --> Model Class Initialized
INFO - 2018-03-31 20:17:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:17:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:46 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:46 --> Total execution time: 0.1290
INFO - 2018-03-31 16:47:50 --> Config Class Initialized
INFO - 2018-03-31 16:47:50 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:47:50 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:47:50 --> Utf8 Class Initialized
INFO - 2018-03-31 16:47:50 --> URI Class Initialized
INFO - 2018-03-31 16:47:50 --> Router Class Initialized
INFO - 2018-03-31 16:47:50 --> Output Class Initialized
INFO - 2018-03-31 16:47:50 --> Security Class Initialized
DEBUG - 2018-03-31 16:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:47:50 --> Input Class Initialized
INFO - 2018-03-31 16:47:50 --> Language Class Initialized
INFO - 2018-03-31 16:47:51 --> Loader Class Initialized
INFO - 2018-03-31 16:47:51 --> Helper loaded: common_helper
INFO - 2018-03-31 16:47:51 --> Database Driver Class Initialized
INFO - 2018-03-31 16:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:47:51 --> Email Class Initialized
INFO - 2018-03-31 16:47:51 --> Controller Class Initialized
INFO - 2018-03-31 16:47:51 --> Helper loaded: form_helper
INFO - 2018-03-31 16:47:51 --> Form Validation Class Initialized
INFO - 2018-03-31 16:47:51 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:47:51 --> Helper loaded: url_helper
INFO - 2018-03-31 16:47:51 --> Model Class Initialized
INFO - 2018-03-31 16:47:51 --> Model Class Initialized
INFO - 2018-03-31 16:47:51 --> Model Class Initialized
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:17:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:17:51 --> Final output sent to browser
DEBUG - 2018-03-31 20:17:51 --> Total execution time: 0.1300
INFO - 2018-03-31 16:48:06 --> Config Class Initialized
INFO - 2018-03-31 16:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:48:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:48:06 --> Utf8 Class Initialized
INFO - 2018-03-31 16:48:06 --> URI Class Initialized
INFO - 2018-03-31 16:48:06 --> Router Class Initialized
INFO - 2018-03-31 16:48:06 --> Output Class Initialized
INFO - 2018-03-31 16:48:06 --> Security Class Initialized
DEBUG - 2018-03-31 16:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:48:06 --> Input Class Initialized
INFO - 2018-03-31 16:48:06 --> Language Class Initialized
INFO - 2018-03-31 16:48:06 --> Loader Class Initialized
INFO - 2018-03-31 16:48:06 --> Helper loaded: common_helper
INFO - 2018-03-31 16:48:06 --> Database Driver Class Initialized
INFO - 2018-03-31 16:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:48:06 --> Email Class Initialized
INFO - 2018-03-31 16:48:06 --> Controller Class Initialized
INFO - 2018-03-31 16:48:06 --> Helper loaded: form_helper
INFO - 2018-03-31 16:48:06 --> Form Validation Class Initialized
INFO - 2018-03-31 16:48:06 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:48:06 --> Helper loaded: url_helper
INFO - 2018-03-31 16:48:06 --> Model Class Initialized
INFO - 2018-03-31 16:48:06 --> Model Class Initialized
INFO - 2018-03-31 16:48:06 --> Model Class Initialized
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:18:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:18:06 --> Final output sent to browser
DEBUG - 2018-03-31 20:18:06 --> Total execution time: 0.1360
INFO - 2018-03-31 16:55:00 --> Config Class Initialized
INFO - 2018-03-31 16:55:00 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:55:00 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:55:00 --> Utf8 Class Initialized
INFO - 2018-03-31 16:55:00 --> URI Class Initialized
INFO - 2018-03-31 16:55:00 --> Router Class Initialized
INFO - 2018-03-31 16:55:00 --> Output Class Initialized
INFO - 2018-03-31 16:55:00 --> Security Class Initialized
DEBUG - 2018-03-31 16:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:55:00 --> Input Class Initialized
INFO - 2018-03-31 16:55:00 --> Language Class Initialized
INFO - 2018-03-31 16:55:00 --> Loader Class Initialized
INFO - 2018-03-31 16:55:00 --> Helper loaded: common_helper
INFO - 2018-03-31 16:55:00 --> Database Driver Class Initialized
INFO - 2018-03-31 16:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:55:00 --> Email Class Initialized
INFO - 2018-03-31 16:55:00 --> Controller Class Initialized
INFO - 2018-03-31 16:55:00 --> Helper loaded: form_helper
INFO - 2018-03-31 16:55:00 --> Form Validation Class Initialized
INFO - 2018-03-31 16:55:00 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:55:00 --> Helper loaded: url_helper
INFO - 2018-03-31 16:55:00 --> Model Class Initialized
INFO - 2018-03-31 16:55:00 --> Model Class Initialized
INFO - 2018-03-31 16:55:00 --> Model Class Initialized
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:25:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:25:00 --> Final output sent to browser
DEBUG - 2018-03-31 20:25:00 --> Total execution time: 0.1520
INFO - 2018-03-31 16:55:40 --> Config Class Initialized
INFO - 2018-03-31 16:55:40 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:55:40 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:55:40 --> Utf8 Class Initialized
INFO - 2018-03-31 16:55:40 --> URI Class Initialized
INFO - 2018-03-31 16:55:40 --> Router Class Initialized
INFO - 2018-03-31 16:55:40 --> Output Class Initialized
INFO - 2018-03-31 16:55:40 --> Security Class Initialized
DEBUG - 2018-03-31 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:55:40 --> Input Class Initialized
INFO - 2018-03-31 16:55:40 --> Language Class Initialized
INFO - 2018-03-31 16:55:40 --> Loader Class Initialized
INFO - 2018-03-31 16:55:40 --> Helper loaded: common_helper
INFO - 2018-03-31 16:55:40 --> Database Driver Class Initialized
INFO - 2018-03-31 16:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:55:40 --> Email Class Initialized
INFO - 2018-03-31 16:55:40 --> Controller Class Initialized
INFO - 2018-03-31 16:55:40 --> Helper loaded: form_helper
INFO - 2018-03-31 16:55:40 --> Form Validation Class Initialized
INFO - 2018-03-31 16:55:40 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:55:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:55:40 --> Helper loaded: url_helper
INFO - 2018-03-31 16:55:40 --> Model Class Initialized
INFO - 2018-03-31 16:55:40 --> Model Class Initialized
INFO - 2018-03-31 16:55:40 --> Model Class Initialized
INFO - 2018-03-31 20:25:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:25:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:25:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:25:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:25:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:25:40 --> Final output sent to browser
DEBUG - 2018-03-31 20:25:40 --> Total execution time: 0.1740
INFO - 2018-03-31 16:55:47 --> Config Class Initialized
INFO - 2018-03-31 16:55:47 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:55:47 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:55:47 --> Utf8 Class Initialized
INFO - 2018-03-31 16:55:47 --> URI Class Initialized
INFO - 2018-03-31 16:55:47 --> Router Class Initialized
INFO - 2018-03-31 16:55:47 --> Output Class Initialized
INFO - 2018-03-31 16:55:47 --> Security Class Initialized
DEBUG - 2018-03-31 16:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:55:47 --> Input Class Initialized
INFO - 2018-03-31 16:55:47 --> Language Class Initialized
INFO - 2018-03-31 16:55:47 --> Loader Class Initialized
INFO - 2018-03-31 16:55:47 --> Helper loaded: common_helper
INFO - 2018-03-31 16:55:47 --> Database Driver Class Initialized
INFO - 2018-03-31 16:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:55:47 --> Email Class Initialized
INFO - 2018-03-31 16:55:47 --> Controller Class Initialized
INFO - 2018-03-31 16:55:47 --> Helper loaded: form_helper
INFO - 2018-03-31 16:55:47 --> Form Validation Class Initialized
INFO - 2018-03-31 16:55:47 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:55:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:55:47 --> Helper loaded: url_helper
INFO - 2018-03-31 16:55:47 --> Model Class Initialized
INFO - 2018-03-31 16:55:47 --> Model Class Initialized
INFO - 2018-03-31 16:55:47 --> Model Class Initialized
INFO - 2018-03-31 20:25:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:25:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:25:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:25:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:25:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:25:47 --> Final output sent to browser
DEBUG - 2018-03-31 20:25:47 --> Total execution time: 0.1340
INFO - 2018-03-31 16:55:57 --> Config Class Initialized
INFO - 2018-03-31 16:55:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:55:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:55:57 --> Utf8 Class Initialized
INFO - 2018-03-31 16:55:57 --> URI Class Initialized
INFO - 2018-03-31 16:55:57 --> Router Class Initialized
INFO - 2018-03-31 16:55:57 --> Output Class Initialized
INFO - 2018-03-31 16:55:57 --> Security Class Initialized
DEBUG - 2018-03-31 16:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:55:57 --> Input Class Initialized
INFO - 2018-03-31 16:55:57 --> Language Class Initialized
INFO - 2018-03-31 16:55:57 --> Loader Class Initialized
INFO - 2018-03-31 16:55:57 --> Helper loaded: common_helper
INFO - 2018-03-31 16:55:57 --> Database Driver Class Initialized
INFO - 2018-03-31 16:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:55:57 --> Email Class Initialized
INFO - 2018-03-31 16:55:57 --> Controller Class Initialized
INFO - 2018-03-31 16:55:57 --> Helper loaded: form_helper
INFO - 2018-03-31 16:55:57 --> Form Validation Class Initialized
INFO - 2018-03-31 16:55:58 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:55:58 --> Helper loaded: url_helper
INFO - 2018-03-31 16:55:58 --> Model Class Initialized
INFO - 2018-03-31 16:55:58 --> Model Class Initialized
INFO - 2018-03-31 16:55:58 --> Model Class Initialized
INFO - 2018-03-31 16:55:58 --> Config Class Initialized
INFO - 2018-03-31 16:55:58 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:55:58 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:55:58 --> Utf8 Class Initialized
INFO - 2018-03-31 16:55:58 --> URI Class Initialized
INFO - 2018-03-31 16:55:58 --> Router Class Initialized
INFO - 2018-03-31 16:55:58 --> Output Class Initialized
INFO - 2018-03-31 16:55:58 --> Security Class Initialized
DEBUG - 2018-03-31 16:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:55:58 --> Input Class Initialized
INFO - 2018-03-31 16:55:58 --> Language Class Initialized
INFO - 2018-03-31 16:55:58 --> Loader Class Initialized
INFO - 2018-03-31 16:55:58 --> Helper loaded: common_helper
INFO - 2018-03-31 16:55:58 --> Database Driver Class Initialized
INFO - 2018-03-31 16:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:55:58 --> Email Class Initialized
INFO - 2018-03-31 16:55:58 --> Controller Class Initialized
INFO - 2018-03-31 16:55:58 --> Helper loaded: form_helper
INFO - 2018-03-31 16:55:58 --> Form Validation Class Initialized
INFO - 2018-03-31 16:55:58 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:55:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:55:58 --> Helper loaded: url_helper
INFO - 2018-03-31 16:55:58 --> Model Class Initialized
INFO - 2018-03-31 16:55:58 --> Model Class Initialized
INFO - 2018-03-31 16:55:58 --> Model Class Initialized
INFO - 2018-03-31 20:25:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:25:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:25:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:25:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:25:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:25:58 --> Final output sent to browser
DEBUG - 2018-03-31 20:25:58 --> Total execution time: 0.1340
INFO - 2018-03-31 16:56:05 --> Config Class Initialized
INFO - 2018-03-31 16:56:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:56:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:56:05 --> Utf8 Class Initialized
INFO - 2018-03-31 16:56:05 --> URI Class Initialized
INFO - 2018-03-31 16:56:05 --> Router Class Initialized
INFO - 2018-03-31 16:56:05 --> Output Class Initialized
INFO - 2018-03-31 16:56:05 --> Security Class Initialized
DEBUG - 2018-03-31 16:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:56:05 --> Input Class Initialized
INFO - 2018-03-31 16:56:05 --> Language Class Initialized
INFO - 2018-03-31 16:56:05 --> Loader Class Initialized
INFO - 2018-03-31 16:56:05 --> Helper loaded: common_helper
INFO - 2018-03-31 16:56:05 --> Database Driver Class Initialized
INFO - 2018-03-31 16:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:56:05 --> Email Class Initialized
INFO - 2018-03-31 16:56:05 --> Controller Class Initialized
INFO - 2018-03-31 16:56:05 --> Helper loaded: form_helper
INFO - 2018-03-31 16:56:05 --> Form Validation Class Initialized
INFO - 2018-03-31 16:56:05 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:56:05 --> Helper loaded: url_helper
INFO - 2018-03-31 16:56:05 --> Model Class Initialized
INFO - 2018-03-31 16:56:05 --> Model Class Initialized
INFO - 2018-03-31 16:56:05 --> Model Class Initialized
ERROR - 2018-03-31 20:26:06 --> Undefined index: edit_source_Image
ERROR - 2018-03-31 20:26:06 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 538
INFO - 2018-03-31 16:56:06 --> Config Class Initialized
INFO - 2018-03-31 16:56:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:56:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:56:06 --> Utf8 Class Initialized
INFO - 2018-03-31 16:56:06 --> URI Class Initialized
INFO - 2018-03-31 16:56:06 --> Router Class Initialized
INFO - 2018-03-31 16:56:06 --> Output Class Initialized
INFO - 2018-03-31 16:56:06 --> Security Class Initialized
DEBUG - 2018-03-31 16:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:56:06 --> Input Class Initialized
INFO - 2018-03-31 16:56:06 --> Language Class Initialized
INFO - 2018-03-31 16:56:06 --> Loader Class Initialized
INFO - 2018-03-31 16:56:06 --> Helper loaded: common_helper
INFO - 2018-03-31 16:56:06 --> Database Driver Class Initialized
INFO - 2018-03-31 16:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:56:06 --> Email Class Initialized
INFO - 2018-03-31 16:56:06 --> Controller Class Initialized
INFO - 2018-03-31 16:56:06 --> Helper loaded: form_helper
INFO - 2018-03-31 16:56:06 --> Form Validation Class Initialized
INFO - 2018-03-31 16:56:06 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:56:06 --> Helper loaded: url_helper
INFO - 2018-03-31 16:56:06 --> Model Class Initialized
INFO - 2018-03-31 16:56:06 --> Model Class Initialized
INFO - 2018-03-31 16:56:06 --> Model Class Initialized
INFO - 2018-03-31 20:26:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:26:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:26:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:26:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:26:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:26:06 --> Final output sent to browser
DEBUG - 2018-03-31 20:26:06 --> Total execution time: 0.1300
INFO - 2018-03-31 16:56:44 --> Config Class Initialized
INFO - 2018-03-31 16:56:44 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:56:44 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:56:44 --> Utf8 Class Initialized
INFO - 2018-03-31 16:56:44 --> URI Class Initialized
INFO - 2018-03-31 16:56:44 --> Router Class Initialized
INFO - 2018-03-31 16:56:44 --> Output Class Initialized
INFO - 2018-03-31 16:56:44 --> Security Class Initialized
DEBUG - 2018-03-31 16:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:56:44 --> Input Class Initialized
INFO - 2018-03-31 16:56:44 --> Language Class Initialized
INFO - 2018-03-31 16:56:44 --> Loader Class Initialized
INFO - 2018-03-31 16:56:44 --> Helper loaded: common_helper
INFO - 2018-03-31 16:56:44 --> Database Driver Class Initialized
INFO - 2018-03-31 16:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:56:44 --> Email Class Initialized
INFO - 2018-03-31 16:56:44 --> Controller Class Initialized
INFO - 2018-03-31 16:56:44 --> Helper loaded: form_helper
INFO - 2018-03-31 16:56:44 --> Form Validation Class Initialized
INFO - 2018-03-31 16:56:44 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:56:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:56:44 --> Helper loaded: url_helper
INFO - 2018-03-31 16:56:44 --> Model Class Initialized
INFO - 2018-03-31 16:56:44 --> Model Class Initialized
INFO - 2018-03-31 16:56:44 --> Model Class Initialized
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:26:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:26:44 --> Final output sent to browser
DEBUG - 2018-03-31 20:26:44 --> Total execution time: 0.1370
INFO - 2018-03-31 16:58:49 --> Config Class Initialized
INFO - 2018-03-31 16:58:49 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:58:49 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:58:49 --> Utf8 Class Initialized
INFO - 2018-03-31 16:58:49 --> URI Class Initialized
INFO - 2018-03-31 16:58:49 --> Router Class Initialized
INFO - 2018-03-31 16:58:49 --> Output Class Initialized
INFO - 2018-03-31 16:58:49 --> Security Class Initialized
DEBUG - 2018-03-31 16:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:58:49 --> Input Class Initialized
INFO - 2018-03-31 16:58:49 --> Language Class Initialized
INFO - 2018-03-31 16:58:49 --> Loader Class Initialized
INFO - 2018-03-31 16:58:49 --> Helper loaded: common_helper
INFO - 2018-03-31 16:58:49 --> Database Driver Class Initialized
INFO - 2018-03-31 16:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:58:49 --> Email Class Initialized
INFO - 2018-03-31 16:58:49 --> Controller Class Initialized
INFO - 2018-03-31 16:58:49 --> Helper loaded: form_helper
INFO - 2018-03-31 16:58:49 --> Form Validation Class Initialized
INFO - 2018-03-31 16:58:49 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:58:49 --> Helper loaded: url_helper
INFO - 2018-03-31 16:58:49 --> Model Class Initialized
INFO - 2018-03-31 16:58:49 --> Model Class Initialized
INFO - 2018-03-31 16:58:49 --> Model Class Initialized
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:28:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:28:49 --> Final output sent to browser
DEBUG - 2018-03-31 20:28:49 --> Total execution time: 0.1570
INFO - 2018-03-31 16:58:53 --> Config Class Initialized
INFO - 2018-03-31 16:58:53 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:58:53 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:58:53 --> Utf8 Class Initialized
INFO - 2018-03-31 16:58:53 --> URI Class Initialized
INFO - 2018-03-31 16:58:53 --> Router Class Initialized
INFO - 2018-03-31 16:58:53 --> Output Class Initialized
INFO - 2018-03-31 16:58:53 --> Security Class Initialized
DEBUG - 2018-03-31 16:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:58:53 --> Input Class Initialized
INFO - 2018-03-31 16:58:53 --> Language Class Initialized
INFO - 2018-03-31 16:58:53 --> Loader Class Initialized
INFO - 2018-03-31 16:58:53 --> Helper loaded: common_helper
INFO - 2018-03-31 16:58:53 --> Database Driver Class Initialized
INFO - 2018-03-31 16:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:58:53 --> Email Class Initialized
INFO - 2018-03-31 16:58:53 --> Controller Class Initialized
INFO - 2018-03-31 16:58:53 --> Helper loaded: form_helper
INFO - 2018-03-31 16:58:53 --> Form Validation Class Initialized
INFO - 2018-03-31 16:58:53 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:58:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:58:53 --> Helper loaded: url_helper
INFO - 2018-03-31 16:58:53 --> Model Class Initialized
INFO - 2018-03-31 16:58:53 --> Model Class Initialized
INFO - 2018-03-31 16:58:53 --> Model Class Initialized
INFO - 2018-03-31 20:28:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:28:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:28:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:28:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:28:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:28:53 --> Final output sent to browser
DEBUG - 2018-03-31 20:28:53 --> Total execution time: 0.1320
INFO - 2018-03-31 16:58:55 --> Config Class Initialized
INFO - 2018-03-31 16:58:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:58:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:58:55 --> Utf8 Class Initialized
INFO - 2018-03-31 16:58:55 --> URI Class Initialized
INFO - 2018-03-31 16:58:55 --> Router Class Initialized
INFO - 2018-03-31 16:58:55 --> Output Class Initialized
INFO - 2018-03-31 16:58:55 --> Security Class Initialized
DEBUG - 2018-03-31 16:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:58:55 --> Input Class Initialized
INFO - 2018-03-31 16:58:55 --> Language Class Initialized
INFO - 2018-03-31 16:58:55 --> Loader Class Initialized
INFO - 2018-03-31 16:58:55 --> Helper loaded: common_helper
INFO - 2018-03-31 16:58:55 --> Database Driver Class Initialized
INFO - 2018-03-31 16:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:58:55 --> Email Class Initialized
INFO - 2018-03-31 16:58:55 --> Controller Class Initialized
INFO - 2018-03-31 16:58:55 --> Helper loaded: form_helper
INFO - 2018-03-31 16:58:55 --> Form Validation Class Initialized
INFO - 2018-03-31 16:58:55 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:58:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:58:55 --> Helper loaded: url_helper
INFO - 2018-03-31 16:58:55 --> Model Class Initialized
INFO - 2018-03-31 16:58:55 --> Model Class Initialized
INFO - 2018-03-31 16:58:55 --> Model Class Initialized
INFO - 2018-03-31 20:28:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:28:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:28:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:28:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:28:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:28:55 --> Final output sent to browser
DEBUG - 2018-03-31 20:28:55 --> Total execution time: 0.1360
INFO - 2018-03-31 16:58:58 --> Config Class Initialized
INFO - 2018-03-31 16:58:58 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:58:58 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:58:58 --> Utf8 Class Initialized
INFO - 2018-03-31 16:58:58 --> URI Class Initialized
INFO - 2018-03-31 16:58:58 --> Router Class Initialized
INFO - 2018-03-31 16:58:58 --> Output Class Initialized
INFO - 2018-03-31 16:58:58 --> Security Class Initialized
DEBUG - 2018-03-31 16:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:58:58 --> Input Class Initialized
INFO - 2018-03-31 16:58:58 --> Language Class Initialized
INFO - 2018-03-31 16:58:58 --> Loader Class Initialized
INFO - 2018-03-31 16:58:58 --> Helper loaded: common_helper
INFO - 2018-03-31 16:58:58 --> Database Driver Class Initialized
INFO - 2018-03-31 16:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:58:58 --> Email Class Initialized
INFO - 2018-03-31 16:58:58 --> Controller Class Initialized
INFO - 2018-03-31 16:58:58 --> Helper loaded: form_helper
INFO - 2018-03-31 16:58:58 --> Form Validation Class Initialized
INFO - 2018-03-31 16:58:58 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:58:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:58:58 --> Helper loaded: url_helper
INFO - 2018-03-31 16:58:58 --> Model Class Initialized
INFO - 2018-03-31 16:58:58 --> Model Class Initialized
INFO - 2018-03-31 16:58:58 --> Model Class Initialized
INFO - 2018-03-31 20:28:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:28:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:28:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:28:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:28:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:28:58 --> Final output sent to browser
DEBUG - 2018-03-31 20:28:58 --> Total execution time: 0.1360
INFO - 2018-03-31 16:59:00 --> Config Class Initialized
INFO - 2018-03-31 16:59:00 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:59:00 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:59:00 --> Utf8 Class Initialized
INFO - 2018-03-31 16:59:00 --> URI Class Initialized
INFO - 2018-03-31 16:59:00 --> Router Class Initialized
INFO - 2018-03-31 16:59:00 --> Output Class Initialized
INFO - 2018-03-31 16:59:00 --> Security Class Initialized
DEBUG - 2018-03-31 16:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:59:00 --> Input Class Initialized
INFO - 2018-03-31 16:59:00 --> Language Class Initialized
INFO - 2018-03-31 16:59:00 --> Loader Class Initialized
INFO - 2018-03-31 16:59:00 --> Helper loaded: common_helper
INFO - 2018-03-31 16:59:00 --> Database Driver Class Initialized
INFO - 2018-03-31 16:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:59:00 --> Email Class Initialized
INFO - 2018-03-31 16:59:00 --> Controller Class Initialized
INFO - 2018-03-31 16:59:00 --> Helper loaded: form_helper
INFO - 2018-03-31 16:59:00 --> Form Validation Class Initialized
INFO - 2018-03-31 16:59:00 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:59:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:59:00 --> Helper loaded: url_helper
INFO - 2018-03-31 16:59:00 --> Model Class Initialized
INFO - 2018-03-31 16:59:00 --> Model Class Initialized
INFO - 2018-03-31 16:59:00 --> Model Class Initialized
INFO - 2018-03-31 20:29:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:29:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:29:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:29:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:29:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:29:00 --> Final output sent to browser
DEBUG - 2018-03-31 20:29:00 --> Total execution time: 0.1410
INFO - 2018-03-31 16:59:09 --> Config Class Initialized
INFO - 2018-03-31 16:59:09 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:59:09 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:59:09 --> Utf8 Class Initialized
INFO - 2018-03-31 16:59:09 --> URI Class Initialized
INFO - 2018-03-31 16:59:09 --> Router Class Initialized
INFO - 2018-03-31 16:59:09 --> Output Class Initialized
INFO - 2018-03-31 16:59:09 --> Security Class Initialized
DEBUG - 2018-03-31 16:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:59:09 --> Input Class Initialized
INFO - 2018-03-31 16:59:09 --> Language Class Initialized
INFO - 2018-03-31 16:59:09 --> Loader Class Initialized
INFO - 2018-03-31 16:59:09 --> Helper loaded: common_helper
INFO - 2018-03-31 16:59:09 --> Database Driver Class Initialized
INFO - 2018-03-31 16:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:59:09 --> Email Class Initialized
INFO - 2018-03-31 16:59:09 --> Controller Class Initialized
INFO - 2018-03-31 16:59:09 --> Helper loaded: form_helper
INFO - 2018-03-31 16:59:09 --> Form Validation Class Initialized
INFO - 2018-03-31 16:59:09 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:59:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:59:09 --> Helper loaded: url_helper
INFO - 2018-03-31 16:59:09 --> Model Class Initialized
INFO - 2018-03-31 16:59:09 --> Model Class Initialized
INFO - 2018-03-31 16:59:09 --> Model Class Initialized
INFO - 2018-03-31 20:29:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:29:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:29:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:29:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:29:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:29:09 --> Final output sent to browser
DEBUG - 2018-03-31 20:29:09 --> Total execution time: 0.1360
INFO - 2018-03-31 16:59:12 --> Config Class Initialized
INFO - 2018-03-31 16:59:12 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:59:12 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:59:12 --> Utf8 Class Initialized
INFO - 2018-03-31 16:59:12 --> URI Class Initialized
INFO - 2018-03-31 16:59:12 --> Router Class Initialized
INFO - 2018-03-31 16:59:12 --> Output Class Initialized
INFO - 2018-03-31 16:59:12 --> Security Class Initialized
DEBUG - 2018-03-31 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:59:12 --> Input Class Initialized
INFO - 2018-03-31 16:59:12 --> Language Class Initialized
INFO - 2018-03-31 16:59:12 --> Loader Class Initialized
INFO - 2018-03-31 16:59:12 --> Helper loaded: common_helper
INFO - 2018-03-31 16:59:12 --> Database Driver Class Initialized
INFO - 2018-03-31 16:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:59:12 --> Email Class Initialized
INFO - 2018-03-31 16:59:12 --> Controller Class Initialized
INFO - 2018-03-31 16:59:12 --> Helper loaded: form_helper
INFO - 2018-03-31 16:59:12 --> Form Validation Class Initialized
INFO - 2018-03-31 16:59:12 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:59:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:59:12 --> Helper loaded: url_helper
INFO - 2018-03-31 16:59:12 --> Model Class Initialized
INFO - 2018-03-31 16:59:12 --> Model Class Initialized
INFO - 2018-03-31 16:59:12 --> Model Class Initialized
INFO - 2018-03-31 20:29:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:29:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:29:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:29:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:29:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:29:12 --> Final output sent to browser
DEBUG - 2018-03-31 20:29:12 --> Total execution time: 0.1320
INFO - 2018-03-31 16:59:59 --> Config Class Initialized
INFO - 2018-03-31 16:59:59 --> Hooks Class Initialized
DEBUG - 2018-03-31 16:59:59 --> UTF-8 Support Enabled
INFO - 2018-03-31 16:59:59 --> Utf8 Class Initialized
INFO - 2018-03-31 16:59:59 --> URI Class Initialized
INFO - 2018-03-31 16:59:59 --> Router Class Initialized
INFO - 2018-03-31 16:59:59 --> Output Class Initialized
INFO - 2018-03-31 16:59:59 --> Security Class Initialized
DEBUG - 2018-03-31 16:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 16:59:59 --> Input Class Initialized
INFO - 2018-03-31 16:59:59 --> Language Class Initialized
INFO - 2018-03-31 16:59:59 --> Loader Class Initialized
INFO - 2018-03-31 16:59:59 --> Helper loaded: common_helper
INFO - 2018-03-31 16:59:59 --> Database Driver Class Initialized
INFO - 2018-03-31 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 16:59:59 --> Email Class Initialized
INFO - 2018-03-31 16:59:59 --> Controller Class Initialized
INFO - 2018-03-31 16:59:59 --> Helper loaded: form_helper
INFO - 2018-03-31 16:59:59 --> Form Validation Class Initialized
INFO - 2018-03-31 16:59:59 --> Helper loaded: email_helper
DEBUG - 2018-03-31 16:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 16:59:59 --> Helper loaded: url_helper
INFO - 2018-03-31 16:59:59 --> Model Class Initialized
INFO - 2018-03-31 16:59:59 --> Model Class Initialized
INFO - 2018-03-31 16:59:59 --> Model Class Initialized
INFO - 2018-03-31 20:29:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:29:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:29:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:29:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:29:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:29:59 --> Final output sent to browser
DEBUG - 2018-03-31 20:29:59 --> Total execution time: 0.1410
INFO - 2018-03-31 17:00:03 --> Config Class Initialized
INFO - 2018-03-31 17:00:03 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:03 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:03 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:03 --> URI Class Initialized
INFO - 2018-03-31 17:00:03 --> Router Class Initialized
INFO - 2018-03-31 17:00:03 --> Output Class Initialized
INFO - 2018-03-31 17:00:03 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:03 --> Input Class Initialized
INFO - 2018-03-31 17:00:03 --> Language Class Initialized
INFO - 2018-03-31 17:00:03 --> Loader Class Initialized
INFO - 2018-03-31 17:00:03 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:03 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:03 --> Email Class Initialized
INFO - 2018-03-31 17:00:03 --> Controller Class Initialized
INFO - 2018-03-31 17:00:03 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:03 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:03 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:03 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:03 --> Model Class Initialized
INFO - 2018-03-31 17:00:03 --> Model Class Initialized
INFO - 2018-03-31 17:00:03 --> Model Class Initialized
INFO - 2018-03-31 20:30:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:30:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:03 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:03 --> Total execution time: 0.1370
INFO - 2018-03-31 17:00:27 --> Config Class Initialized
INFO - 2018-03-31 17:00:27 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:27 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:27 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:27 --> URI Class Initialized
INFO - 2018-03-31 17:00:27 --> Router Class Initialized
INFO - 2018-03-31 17:00:27 --> Output Class Initialized
INFO - 2018-03-31 17:00:27 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:27 --> Input Class Initialized
INFO - 2018-03-31 17:00:27 --> Language Class Initialized
INFO - 2018-03-31 17:00:27 --> Loader Class Initialized
INFO - 2018-03-31 17:00:27 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:27 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:27 --> Email Class Initialized
INFO - 2018-03-31 17:00:27 --> Controller Class Initialized
INFO - 2018-03-31 17:00:28 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:28 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:28 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:28 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:28 --> Model Class Initialized
INFO - 2018-03-31 17:00:28 --> Model Class Initialized
INFO - 2018-03-31 17:00:28 --> Model Class Initialized
INFO - 2018-03-31 20:30:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:30:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:28 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:28 --> Total execution time: 0.1420
INFO - 2018-03-31 17:00:31 --> Config Class Initialized
INFO - 2018-03-31 17:00:31 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:31 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:31 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:31 --> URI Class Initialized
INFO - 2018-03-31 17:00:31 --> Router Class Initialized
INFO - 2018-03-31 17:00:31 --> Output Class Initialized
INFO - 2018-03-31 17:00:31 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:31 --> Input Class Initialized
INFO - 2018-03-31 17:00:31 --> Language Class Initialized
INFO - 2018-03-31 17:00:31 --> Loader Class Initialized
INFO - 2018-03-31 17:00:31 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:31 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:31 --> Email Class Initialized
INFO - 2018-03-31 17:00:31 --> Controller Class Initialized
INFO - 2018-03-31 17:00:31 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:31 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:31 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:32 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:32 --> Model Class Initialized
INFO - 2018-03-31 17:00:32 --> Model Class Initialized
INFO - 2018-03-31 17:00:32 --> Model Class Initialized
INFO - 2018-03-31 20:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:30:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:32 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:32 --> Total execution time: 0.1580
INFO - 2018-03-31 17:00:34 --> Config Class Initialized
INFO - 2018-03-31 17:00:34 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:34 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:34 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:34 --> URI Class Initialized
INFO - 2018-03-31 17:00:34 --> Router Class Initialized
INFO - 2018-03-31 17:00:34 --> Output Class Initialized
INFO - 2018-03-31 17:00:34 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:34 --> Input Class Initialized
INFO - 2018-03-31 17:00:34 --> Language Class Initialized
INFO - 2018-03-31 17:00:34 --> Loader Class Initialized
INFO - 2018-03-31 17:00:34 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:34 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:34 --> Email Class Initialized
INFO - 2018-03-31 17:00:34 --> Controller Class Initialized
INFO - 2018-03-31 17:00:34 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:34 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:34 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:34 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:34 --> Model Class Initialized
INFO - 2018-03-31 17:00:34 --> Model Class Initialized
INFO - 2018-03-31 17:00:34 --> Model Class Initialized
INFO - 2018-03-31 20:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:34 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:34 --> Total execution time: 0.1820
INFO - 2018-03-31 17:00:37 --> Config Class Initialized
INFO - 2018-03-31 17:00:37 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:37 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:37 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:37 --> URI Class Initialized
INFO - 2018-03-31 17:00:37 --> Router Class Initialized
INFO - 2018-03-31 17:00:37 --> Output Class Initialized
INFO - 2018-03-31 17:00:37 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:37 --> Input Class Initialized
INFO - 2018-03-31 17:00:37 --> Language Class Initialized
INFO - 2018-03-31 17:00:37 --> Loader Class Initialized
INFO - 2018-03-31 17:00:37 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:37 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:37 --> Email Class Initialized
INFO - 2018-03-31 17:00:37 --> Controller Class Initialized
INFO - 2018-03-31 17:00:37 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:37 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:37 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:37 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:37 --> Model Class Initialized
INFO - 2018-03-31 17:00:37 --> Model Class Initialized
INFO - 2018-03-31 17:00:37 --> Model Class Initialized
INFO - 2018-03-31 20:30:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:30:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:37 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:37 --> Total execution time: 0.1400
INFO - 2018-03-31 17:00:39 --> Config Class Initialized
INFO - 2018-03-31 17:00:39 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:39 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:39 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:39 --> URI Class Initialized
INFO - 2018-03-31 17:00:39 --> Router Class Initialized
INFO - 2018-03-31 17:00:39 --> Output Class Initialized
INFO - 2018-03-31 17:00:39 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:39 --> Input Class Initialized
INFO - 2018-03-31 17:00:39 --> Language Class Initialized
INFO - 2018-03-31 17:00:39 --> Loader Class Initialized
INFO - 2018-03-31 17:00:39 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:39 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:39 --> Email Class Initialized
INFO - 2018-03-31 17:00:39 --> Controller Class Initialized
INFO - 2018-03-31 17:00:39 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:39 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:39 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:39 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:39 --> Model Class Initialized
INFO - 2018-03-31 17:00:39 --> Model Class Initialized
INFO - 2018-03-31 17:00:39 --> Model Class Initialized
INFO - 2018-03-31 20:30:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:30:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:39 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:39 --> Total execution time: 0.1350
INFO - 2018-03-31 17:00:42 --> Config Class Initialized
INFO - 2018-03-31 17:00:42 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:42 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:42 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:42 --> URI Class Initialized
INFO - 2018-03-31 17:00:42 --> Router Class Initialized
INFO - 2018-03-31 17:00:42 --> Output Class Initialized
INFO - 2018-03-31 17:00:42 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:42 --> Input Class Initialized
INFO - 2018-03-31 17:00:42 --> Language Class Initialized
INFO - 2018-03-31 17:00:42 --> Loader Class Initialized
INFO - 2018-03-31 17:00:42 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:42 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:42 --> Email Class Initialized
INFO - 2018-03-31 17:00:42 --> Controller Class Initialized
INFO - 2018-03-31 17:00:42 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:42 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:42 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:42 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:42 --> Model Class Initialized
INFO - 2018-03-31 17:00:42 --> Model Class Initialized
INFO - 2018-03-31 17:00:42 --> Model Class Initialized
INFO - 2018-03-31 20:30:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:30:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:42 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:42 --> Total execution time: 0.1580
INFO - 2018-03-31 17:00:46 --> Config Class Initialized
INFO - 2018-03-31 17:00:46 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:00:46 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:00:46 --> Utf8 Class Initialized
INFO - 2018-03-31 17:00:46 --> URI Class Initialized
INFO - 2018-03-31 17:00:46 --> Router Class Initialized
INFO - 2018-03-31 17:00:46 --> Output Class Initialized
INFO - 2018-03-31 17:00:46 --> Security Class Initialized
DEBUG - 2018-03-31 17:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:00:46 --> Input Class Initialized
INFO - 2018-03-31 17:00:46 --> Language Class Initialized
INFO - 2018-03-31 17:00:46 --> Loader Class Initialized
INFO - 2018-03-31 17:00:46 --> Helper loaded: common_helper
INFO - 2018-03-31 17:00:46 --> Database Driver Class Initialized
INFO - 2018-03-31 17:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:00:46 --> Email Class Initialized
INFO - 2018-03-31 17:00:46 --> Controller Class Initialized
INFO - 2018-03-31 17:00:46 --> Helper loaded: form_helper
INFO - 2018-03-31 17:00:46 --> Form Validation Class Initialized
INFO - 2018-03-31 17:00:46 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:00:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:00:46 --> Helper loaded: url_helper
INFO - 2018-03-31 17:00:46 --> Model Class Initialized
INFO - 2018-03-31 17:00:46 --> Model Class Initialized
INFO - 2018-03-31 17:00:46 --> Model Class Initialized
INFO - 2018-03-31 20:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:30:46 --> Final output sent to browser
DEBUG - 2018-03-31 20:30:46 --> Total execution time: 0.1370
INFO - 2018-03-31 17:04:38 --> Config Class Initialized
INFO - 2018-03-31 17:04:38 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:04:38 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:04:38 --> Utf8 Class Initialized
INFO - 2018-03-31 17:04:38 --> URI Class Initialized
INFO - 2018-03-31 17:04:38 --> Router Class Initialized
INFO - 2018-03-31 17:04:38 --> Output Class Initialized
INFO - 2018-03-31 17:04:38 --> Security Class Initialized
DEBUG - 2018-03-31 17:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:04:38 --> Input Class Initialized
INFO - 2018-03-31 17:04:38 --> Language Class Initialized
INFO - 2018-03-31 17:04:38 --> Loader Class Initialized
INFO - 2018-03-31 17:04:38 --> Helper loaded: common_helper
INFO - 2018-03-31 17:04:38 --> Database Driver Class Initialized
INFO - 2018-03-31 17:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:04:38 --> Email Class Initialized
INFO - 2018-03-31 17:04:38 --> Controller Class Initialized
INFO - 2018-03-31 17:04:38 --> Helper loaded: form_helper
INFO - 2018-03-31 17:04:38 --> Form Validation Class Initialized
INFO - 2018-03-31 17:04:38 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:04:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:04:38 --> Helper loaded: url_helper
INFO - 2018-03-31 17:04:38 --> Model Class Initialized
INFO - 2018-03-31 17:04:38 --> Model Class Initialized
INFO - 2018-03-31 17:04:38 --> Model Class Initialized
INFO - 2018-03-31 20:34:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:34:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:34:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:34:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:34:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:34:38 --> Final output sent to browser
DEBUG - 2018-03-31 20:34:38 --> Total execution time: 0.1370
INFO - 2018-03-31 17:04:41 --> Config Class Initialized
INFO - 2018-03-31 17:04:41 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:04:41 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:04:41 --> Utf8 Class Initialized
INFO - 2018-03-31 17:04:41 --> URI Class Initialized
INFO - 2018-03-31 17:04:41 --> Router Class Initialized
INFO - 2018-03-31 17:04:41 --> Output Class Initialized
INFO - 2018-03-31 17:04:41 --> Security Class Initialized
DEBUG - 2018-03-31 17:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:04:41 --> Input Class Initialized
INFO - 2018-03-31 17:04:41 --> Language Class Initialized
INFO - 2018-03-31 17:04:41 --> Loader Class Initialized
INFO - 2018-03-31 17:04:41 --> Helper loaded: common_helper
INFO - 2018-03-31 17:04:41 --> Database Driver Class Initialized
INFO - 2018-03-31 17:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:04:41 --> Email Class Initialized
INFO - 2018-03-31 17:04:41 --> Controller Class Initialized
INFO - 2018-03-31 17:04:41 --> Helper loaded: form_helper
INFO - 2018-03-31 17:04:41 --> Form Validation Class Initialized
INFO - 2018-03-31 17:04:41 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:04:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:04:41 --> Helper loaded: url_helper
INFO - 2018-03-31 17:04:41 --> Model Class Initialized
INFO - 2018-03-31 17:04:41 --> Model Class Initialized
INFO - 2018-03-31 17:04:41 --> Model Class Initialized
INFO - 2018-03-31 20:34:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:34:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:34:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:34:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:34:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:34:41 --> Final output sent to browser
DEBUG - 2018-03-31 20:34:41 --> Total execution time: 0.1580
INFO - 2018-03-31 17:08:16 --> Config Class Initialized
INFO - 2018-03-31 17:08:16 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:08:16 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:08:16 --> Utf8 Class Initialized
INFO - 2018-03-31 17:08:16 --> URI Class Initialized
INFO - 2018-03-31 17:08:16 --> Router Class Initialized
INFO - 2018-03-31 17:08:16 --> Output Class Initialized
INFO - 2018-03-31 17:08:16 --> Security Class Initialized
DEBUG - 2018-03-31 17:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:08:16 --> Input Class Initialized
INFO - 2018-03-31 17:08:16 --> Language Class Initialized
INFO - 2018-03-31 17:08:16 --> Loader Class Initialized
INFO - 2018-03-31 17:08:16 --> Helper loaded: common_helper
INFO - 2018-03-31 17:08:16 --> Database Driver Class Initialized
INFO - 2018-03-31 17:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:08:16 --> Email Class Initialized
INFO - 2018-03-31 17:08:16 --> Controller Class Initialized
INFO - 2018-03-31 17:08:16 --> Helper loaded: form_helper
INFO - 2018-03-31 17:08:16 --> Form Validation Class Initialized
INFO - 2018-03-31 17:08:16 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:08:16 --> Helper loaded: url_helper
INFO - 2018-03-31 17:08:16 --> Model Class Initialized
INFO - 2018-03-31 17:08:16 --> Model Class Initialized
INFO - 2018-03-31 17:08:16 --> Model Class Initialized
INFO - 2018-03-31 20:38:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:38:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:38:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:38:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:38:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:38:16 --> Final output sent to browser
DEBUG - 2018-03-31 20:38:16 --> Total execution time: 0.1810
INFO - 2018-03-31 17:08:18 --> Config Class Initialized
INFO - 2018-03-31 17:08:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:08:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:08:18 --> Utf8 Class Initialized
INFO - 2018-03-31 17:08:18 --> URI Class Initialized
INFO - 2018-03-31 17:08:18 --> Router Class Initialized
INFO - 2018-03-31 17:08:18 --> Output Class Initialized
INFO - 2018-03-31 17:08:18 --> Security Class Initialized
DEBUG - 2018-03-31 17:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:08:18 --> Input Class Initialized
INFO - 2018-03-31 17:08:18 --> Language Class Initialized
INFO - 2018-03-31 17:08:18 --> Loader Class Initialized
INFO - 2018-03-31 17:08:18 --> Helper loaded: common_helper
INFO - 2018-03-31 17:08:18 --> Database Driver Class Initialized
INFO - 2018-03-31 17:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:08:18 --> Email Class Initialized
INFO - 2018-03-31 17:08:18 --> Controller Class Initialized
INFO - 2018-03-31 17:08:18 --> Helper loaded: form_helper
INFO - 2018-03-31 17:08:18 --> Form Validation Class Initialized
INFO - 2018-03-31 17:08:18 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:08:18 --> Helper loaded: url_helper
INFO - 2018-03-31 17:08:18 --> Model Class Initialized
INFO - 2018-03-31 17:08:18 --> Model Class Initialized
INFO - 2018-03-31 17:08:18 --> Model Class Initialized
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-03-31 20:38:18 --> Undefined variable: newtitle
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined variable: newtitle C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 206
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:38:18 --> Final output sent to browser
DEBUG - 2018-03-31 20:38:18 --> Total execution time: 0.1390
INFO - 2018-03-31 17:08:18 --> Config Class Initialized
INFO - 2018-03-31 17:08:18 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:08:18 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:08:18 --> Utf8 Class Initialized
INFO - 2018-03-31 17:08:18 --> URI Class Initialized
INFO - 2018-03-31 17:08:18 --> Router Class Initialized
INFO - 2018-03-31 17:08:18 --> Output Class Initialized
INFO - 2018-03-31 17:08:18 --> Security Class Initialized
DEBUG - 2018-03-31 17:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:08:18 --> Input Class Initialized
INFO - 2018-03-31 17:08:18 --> Language Class Initialized
INFO - 2018-03-31 17:08:18 --> Loader Class Initialized
INFO - 2018-03-31 17:08:18 --> Helper loaded: common_helper
INFO - 2018-03-31 17:08:18 --> Database Driver Class Initialized
INFO - 2018-03-31 17:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:08:18 --> Email Class Initialized
INFO - 2018-03-31 17:08:18 --> Controller Class Initialized
INFO - 2018-03-31 17:08:18 --> Helper loaded: form_helper
INFO - 2018-03-31 17:08:18 --> Form Validation Class Initialized
INFO - 2018-03-31 17:08:18 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:08:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:08:18 --> Helper loaded: url_helper
INFO - 2018-03-31 17:08:18 --> Model Class Initialized
INFO - 2018-03-31 17:08:18 --> Model Class Initialized
INFO - 2018-03-31 17:08:18 --> Model Class Initialized
ERROR - 2018-03-31 20:38:18 --> Creating default object from empty value
ERROR - 2018-03-31 20:38:18 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_title
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_category_id
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_category_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 108
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 114
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 131
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 152
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 223
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 313
ERROR - 2018-03-31 20:38:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-03-31 20:38:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 340
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:38:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:38:18 --> Final output sent to browser
DEBUG - 2018-03-31 20:38:18 --> Total execution time: 0.2240
INFO - 2018-03-31 17:08:55 --> Config Class Initialized
INFO - 2018-03-31 17:08:55 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:08:55 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:08:55 --> Utf8 Class Initialized
INFO - 2018-03-31 17:08:55 --> URI Class Initialized
INFO - 2018-03-31 17:08:55 --> Router Class Initialized
INFO - 2018-03-31 17:08:55 --> Output Class Initialized
INFO - 2018-03-31 17:08:55 --> Security Class Initialized
DEBUG - 2018-03-31 17:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:08:55 --> Input Class Initialized
INFO - 2018-03-31 17:08:55 --> Language Class Initialized
INFO - 2018-03-31 17:08:55 --> Loader Class Initialized
INFO - 2018-03-31 17:08:55 --> Helper loaded: common_helper
INFO - 2018-03-31 17:08:55 --> Database Driver Class Initialized
INFO - 2018-03-31 17:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:08:55 --> Email Class Initialized
INFO - 2018-03-31 17:08:55 --> Controller Class Initialized
INFO - 2018-03-31 17:08:55 --> Helper loaded: form_helper
INFO - 2018-03-31 17:08:55 --> Form Validation Class Initialized
INFO - 2018-03-31 17:08:55 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:08:55 --> Helper loaded: url_helper
INFO - 2018-03-31 17:08:55 --> Model Class Initialized
INFO - 2018-03-31 17:08:55 --> Model Class Initialized
INFO - 2018-03-31 17:08:55 --> Model Class Initialized
INFO - 2018-03-31 20:38:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:38:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:38:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:38:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:38:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:38:55 --> Final output sent to browser
DEBUG - 2018-03-31 20:38:55 --> Total execution time: 0.1380
INFO - 2018-03-31 17:08:58 --> Config Class Initialized
INFO - 2018-03-31 17:08:58 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:08:58 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:08:58 --> Utf8 Class Initialized
INFO - 2018-03-31 17:08:58 --> URI Class Initialized
INFO - 2018-03-31 17:08:58 --> Router Class Initialized
INFO - 2018-03-31 17:08:58 --> Output Class Initialized
INFO - 2018-03-31 17:08:58 --> Security Class Initialized
DEBUG - 2018-03-31 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:08:58 --> Input Class Initialized
INFO - 2018-03-31 17:08:58 --> Language Class Initialized
INFO - 2018-03-31 17:08:58 --> Loader Class Initialized
INFO - 2018-03-31 17:08:58 --> Helper loaded: common_helper
INFO - 2018-03-31 17:08:58 --> Database Driver Class Initialized
INFO - 2018-03-31 17:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:08:58 --> Email Class Initialized
INFO - 2018-03-31 17:08:58 --> Controller Class Initialized
INFO - 2018-03-31 17:08:58 --> Helper loaded: form_helper
INFO - 2018-03-31 17:08:58 --> Form Validation Class Initialized
INFO - 2018-03-31 17:08:58 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:08:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:08:58 --> Helper loaded: url_helper
INFO - 2018-03-31 17:08:58 --> Model Class Initialized
INFO - 2018-03-31 17:08:58 --> Model Class Initialized
INFO - 2018-03-31 17:08:58 --> Model Class Initialized
INFO - 2018-03-31 20:38:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:38:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:38:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:38:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-03-31 20:38:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:38:58 --> Final output sent to browser
DEBUG - 2018-03-31 20:38:58 --> Total execution time: 0.1510
INFO - 2018-03-31 17:09:01 --> Config Class Initialized
INFO - 2018-03-31 17:09:01 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:01 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:01 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:01 --> URI Class Initialized
INFO - 2018-03-31 17:09:01 --> Router Class Initialized
INFO - 2018-03-31 17:09:01 --> Output Class Initialized
INFO - 2018-03-31 17:09:01 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:01 --> Input Class Initialized
INFO - 2018-03-31 17:09:01 --> Language Class Initialized
INFO - 2018-03-31 17:09:01 --> Loader Class Initialized
INFO - 2018-03-31 17:09:01 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:01 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:01 --> Email Class Initialized
INFO - 2018-03-31 17:09:01 --> Controller Class Initialized
INFO - 2018-03-31 17:09:01 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:01 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:01 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:01 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:01 --> Model Class Initialized
INFO - 2018-03-31 17:09:01 --> Model Class Initialized
INFO - 2018-03-31 17:09:01 --> Model Class Initialized
INFO - 2018-03-31 20:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:39:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:39:02 --> Final output sent to browser
DEBUG - 2018-03-31 20:39:02 --> Total execution time: 0.1810
INFO - 2018-03-31 17:09:06 --> Config Class Initialized
INFO - 2018-03-31 17:09:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:06 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:06 --> URI Class Initialized
INFO - 2018-03-31 17:09:06 --> Router Class Initialized
INFO - 2018-03-31 17:09:06 --> Output Class Initialized
INFO - 2018-03-31 17:09:06 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:06 --> Input Class Initialized
INFO - 2018-03-31 17:09:06 --> Language Class Initialized
INFO - 2018-03-31 17:09:06 --> Loader Class Initialized
INFO - 2018-03-31 17:09:06 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:06 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:06 --> Email Class Initialized
INFO - 2018-03-31 17:09:06 --> Controller Class Initialized
INFO - 2018-03-31 17:09:06 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:06 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:06 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:06 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:06 --> Model Class Initialized
INFO - 2018-03-31 17:09:06 --> Model Class Initialized
INFO - 2018-03-31 17:09:06 --> Model Class Initialized
INFO - 2018-03-31 17:09:06 --> Config Class Initialized
INFO - 2018-03-31 17:09:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:06 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:06 --> URI Class Initialized
INFO - 2018-03-31 17:09:06 --> Router Class Initialized
INFO - 2018-03-31 17:09:06 --> Output Class Initialized
INFO - 2018-03-31 17:09:06 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:06 --> Input Class Initialized
INFO - 2018-03-31 17:09:06 --> Language Class Initialized
INFO - 2018-03-31 17:09:06 --> Loader Class Initialized
INFO - 2018-03-31 17:09:06 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:06 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:06 --> Email Class Initialized
INFO - 2018-03-31 17:09:06 --> Controller Class Initialized
INFO - 2018-03-31 17:09:06 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:06 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:06 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:06 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:06 --> Model Class Initialized
INFO - 2018-03-31 17:09:06 --> Model Class Initialized
INFO - 2018-03-31 17:09:06 --> Model Class Initialized
INFO - 2018-03-31 20:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:39:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:39:06 --> Final output sent to browser
DEBUG - 2018-03-31 20:39:06 --> Total execution time: 0.1280
INFO - 2018-03-31 17:09:14 --> Config Class Initialized
INFO - 2018-03-31 17:09:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:14 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:14 --> URI Class Initialized
INFO - 2018-03-31 17:09:14 --> Router Class Initialized
INFO - 2018-03-31 17:09:14 --> Output Class Initialized
INFO - 2018-03-31 17:09:14 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:14 --> Input Class Initialized
INFO - 2018-03-31 17:09:14 --> Language Class Initialized
INFO - 2018-03-31 17:09:14 --> Loader Class Initialized
INFO - 2018-03-31 17:09:14 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:14 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:14 --> Email Class Initialized
INFO - 2018-03-31 17:09:14 --> Controller Class Initialized
INFO - 2018-03-31 17:09:14 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:14 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:14 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:14 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:14 --> Model Class Initialized
INFO - 2018-03-31 17:09:14 --> Model Class Initialized
INFO - 2018-03-31 17:09:14 --> Model Class Initialized
ERROR - 2018-03-31 20:39:14 --> Undefined index: edit_source_Image
ERROR - 2018-03-31 20:39:14 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 538
INFO - 2018-03-31 17:09:14 --> Config Class Initialized
INFO - 2018-03-31 17:09:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:14 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:14 --> URI Class Initialized
INFO - 2018-03-31 17:09:14 --> Router Class Initialized
INFO - 2018-03-31 17:09:14 --> Output Class Initialized
INFO - 2018-03-31 17:09:14 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:14 --> Input Class Initialized
INFO - 2018-03-31 17:09:14 --> Language Class Initialized
INFO - 2018-03-31 17:09:14 --> Loader Class Initialized
INFO - 2018-03-31 17:09:14 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:14 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:14 --> Email Class Initialized
INFO - 2018-03-31 17:09:14 --> Controller Class Initialized
INFO - 2018-03-31 17:09:14 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:14 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:14 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:14 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:14 --> Model Class Initialized
INFO - 2018-03-31 17:09:14 --> Model Class Initialized
INFO - 2018-03-31 17:09:14 --> Model Class Initialized
INFO - 2018-03-31 20:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:39:14 --> Final output sent to browser
DEBUG - 2018-03-31 20:39:14 --> Total execution time: 0.1380
INFO - 2018-03-31 17:09:19 --> Config Class Initialized
INFO - 2018-03-31 17:09:19 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:19 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:19 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:19 --> URI Class Initialized
INFO - 2018-03-31 17:09:19 --> Router Class Initialized
INFO - 2018-03-31 17:09:19 --> Output Class Initialized
INFO - 2018-03-31 17:09:19 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:19 --> Input Class Initialized
INFO - 2018-03-31 17:09:19 --> Language Class Initialized
INFO - 2018-03-31 17:09:19 --> Loader Class Initialized
INFO - 2018-03-31 17:09:19 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:19 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:19 --> Email Class Initialized
INFO - 2018-03-31 17:09:19 --> Controller Class Initialized
INFO - 2018-03-31 17:09:19 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:19 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:19 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:19 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:19 --> Model Class Initialized
INFO - 2018-03-31 17:09:19 --> Model Class Initialized
INFO - 2018-03-31 17:09:19 --> Model Class Initialized
ERROR - 2018-03-31 20:39:20 --> Undefined index: edit_source_Image
ERROR - 2018-03-31 20:39:20 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 538
INFO - 2018-03-31 17:09:20 --> Config Class Initialized
INFO - 2018-03-31 17:09:20 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:20 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:20 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:20 --> URI Class Initialized
INFO - 2018-03-31 17:09:20 --> Router Class Initialized
INFO - 2018-03-31 17:09:20 --> Output Class Initialized
INFO - 2018-03-31 17:09:20 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:20 --> Input Class Initialized
INFO - 2018-03-31 17:09:20 --> Language Class Initialized
INFO - 2018-03-31 17:09:20 --> Loader Class Initialized
INFO - 2018-03-31 17:09:20 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:20 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:20 --> Email Class Initialized
INFO - 2018-03-31 17:09:20 --> Controller Class Initialized
INFO - 2018-03-31 17:09:20 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:20 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:20 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:20 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:20 --> Model Class Initialized
INFO - 2018-03-31 17:09:20 --> Model Class Initialized
INFO - 2018-03-31 17:09:20 --> Model Class Initialized
INFO - 2018-03-31 20:39:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:39:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:39:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-03-31 20:39:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:39:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:39:20 --> Final output sent to browser
DEBUG - 2018-03-31 20:39:20 --> Total execution time: 0.1280
INFO - 2018-03-31 17:09:23 --> Config Class Initialized
INFO - 2018-03-31 17:09:23 --> Hooks Class Initialized
DEBUG - 2018-03-31 17:09:23 --> UTF-8 Support Enabled
INFO - 2018-03-31 17:09:23 --> Utf8 Class Initialized
INFO - 2018-03-31 17:09:23 --> URI Class Initialized
INFO - 2018-03-31 17:09:23 --> Router Class Initialized
INFO - 2018-03-31 17:09:23 --> Output Class Initialized
INFO - 2018-03-31 17:09:23 --> Security Class Initialized
DEBUG - 2018-03-31 17:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 17:09:23 --> Input Class Initialized
INFO - 2018-03-31 17:09:23 --> Language Class Initialized
INFO - 2018-03-31 17:09:23 --> Loader Class Initialized
INFO - 2018-03-31 17:09:23 --> Helper loaded: common_helper
INFO - 2018-03-31 17:09:23 --> Database Driver Class Initialized
INFO - 2018-03-31 17:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 17:09:23 --> Email Class Initialized
INFO - 2018-03-31 17:09:23 --> Controller Class Initialized
INFO - 2018-03-31 17:09:23 --> Helper loaded: form_helper
INFO - 2018-03-31 17:09:23 --> Form Validation Class Initialized
INFO - 2018-03-31 17:09:23 --> Helper loaded: email_helper
DEBUG - 2018-03-31 17:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 17:09:23 --> Helper loaded: url_helper
INFO - 2018-03-31 17:09:23 --> Model Class Initialized
INFO - 2018-03-31 17:09:23 --> Model Class Initialized
INFO - 2018-03-31 17:09:23 --> Model Class Initialized
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-03-31 20:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 20:39:23 --> Final output sent to browser
DEBUG - 2018-03-31 20:39:23 --> Total execution time: 0.1310
INFO - 2018-03-31 22:48:02 --> Config Class Initialized
INFO - 2018-03-31 22:48:02 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:02 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:02 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:02 --> URI Class Initialized
INFO - 2018-03-31 22:48:02 --> Router Class Initialized
INFO - 2018-03-31 22:48:02 --> Output Class Initialized
INFO - 2018-03-31 22:48:02 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:02 --> Input Class Initialized
INFO - 2018-03-31 22:48:02 --> Language Class Initialized
INFO - 2018-03-31 22:48:02 --> Loader Class Initialized
INFO - 2018-03-31 22:48:02 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:02 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:02 --> Email Class Initialized
INFO - 2018-03-31 22:48:02 --> Controller Class Initialized
INFO - 2018-03-31 22:48:02 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:02 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:02 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:02 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:02 --> Model Class Initialized
INFO - 2018-03-31 22:48:02 --> Model Class Initialized
INFO - 2018-03-31 22:48:02 --> Model Class Initialized
INFO - 2018-03-31 22:48:06 --> Config Class Initialized
INFO - 2018-03-31 22:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:06 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:06 --> URI Class Initialized
INFO - 2018-03-31 22:48:06 --> Router Class Initialized
INFO - 2018-03-31 22:48:06 --> Output Class Initialized
INFO - 2018-03-31 22:48:06 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:06 --> Input Class Initialized
INFO - 2018-03-31 22:48:06 --> Language Class Initialized
INFO - 2018-03-31 22:48:06 --> Loader Class Initialized
INFO - 2018-03-31 22:48:06 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:06 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:06 --> Email Class Initialized
INFO - 2018-03-31 22:48:06 --> Controller Class Initialized
INFO - 2018-03-31 22:48:06 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:06 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:06 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:06 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:06 --> Model Class Initialized
INFO - 2018-03-31 22:48:06 --> Model Class Initialized
INFO - 2018-03-31 22:48:06 --> Model Class Initialized
INFO - 2018-03-31 22:48:06 --> Config Class Initialized
INFO - 2018-03-31 22:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:06 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:06 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:06 --> URI Class Initialized
INFO - 2018-03-31 22:48:06 --> Router Class Initialized
INFO - 2018-03-31 22:48:06 --> Output Class Initialized
INFO - 2018-03-31 22:48:06 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:06 --> Input Class Initialized
INFO - 2018-03-31 22:48:06 --> Language Class Initialized
INFO - 2018-03-31 22:48:06 --> Loader Class Initialized
INFO - 2018-03-31 22:48:06 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:06 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:06 --> Email Class Initialized
INFO - 2018-03-31 22:48:06 --> Controller Class Initialized
INFO - 2018-03-31 22:48:06 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:06 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:06 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:06 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:06 --> Model Class Initialized
INFO - 2018-03-31 22:48:06 --> Model Class Initialized
INFO - 2018-03-31 22:48:06 --> Config Class Initialized
INFO - 2018-03-31 22:48:06 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:07 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:07 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:07 --> URI Class Initialized
DEBUG - 2018-03-31 22:48:07 --> No URI present. Default controller set.
INFO - 2018-03-31 22:48:07 --> Router Class Initialized
INFO - 2018-03-31 22:48:07 --> Output Class Initialized
INFO - 2018-03-31 22:48:07 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:07 --> Input Class Initialized
INFO - 2018-03-31 22:48:07 --> Language Class Initialized
INFO - 2018-03-31 22:48:07 --> Loader Class Initialized
INFO - 2018-03-31 22:48:07 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:07 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:07 --> Email Class Initialized
INFO - 2018-03-31 22:48:07 --> Controller Class Initialized
INFO - 2018-03-31 22:48:07 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:07 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:07 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:07 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:07 --> Model Class Initialized
INFO - 2018-03-31 22:48:07 --> Model Class Initialized
INFO - 2018-03-31 22:48:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-03-31 22:48:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 22:48:07 --> Final output sent to browser
DEBUG - 2018-03-31 22:48:07 --> Total execution time: 0.1410
INFO - 2018-03-31 22:48:10 --> Config Class Initialized
INFO - 2018-03-31 22:48:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:10 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:10 --> URI Class Initialized
DEBUG - 2018-03-31 22:48:10 --> No URI present. Default controller set.
INFO - 2018-03-31 22:48:10 --> Router Class Initialized
INFO - 2018-03-31 22:48:10 --> Output Class Initialized
INFO - 2018-03-31 22:48:10 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:10 --> Input Class Initialized
INFO - 2018-03-31 22:48:10 --> Language Class Initialized
INFO - 2018-03-31 22:48:10 --> Loader Class Initialized
INFO - 2018-03-31 22:48:10 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:10 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:10 --> Email Class Initialized
INFO - 2018-03-31 22:48:10 --> Controller Class Initialized
INFO - 2018-03-31 22:48:10 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:10 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:10 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:10 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:10 --> Model Class Initialized
INFO - 2018-03-31 22:48:10 --> Model Class Initialized
DEBUG - 2018-03-31 22:48:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-03-31 22:48:11 --> Config Class Initialized
INFO - 2018-03-31 22:48:11 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:11 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:11 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:11 --> URI Class Initialized
INFO - 2018-03-31 22:48:11 --> Router Class Initialized
INFO - 2018-03-31 22:48:11 --> Output Class Initialized
INFO - 2018-03-31 22:48:11 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:11 --> Input Class Initialized
INFO - 2018-03-31 22:48:11 --> Language Class Initialized
INFO - 2018-03-31 22:48:11 --> Loader Class Initialized
INFO - 2018-03-31 22:48:11 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:11 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:11 --> Email Class Initialized
INFO - 2018-03-31 22:48:11 --> Controller Class Initialized
INFO - 2018-03-31 22:48:11 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:11 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:11 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:11 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:11 --> Model Class Initialized
INFO - 2018-03-31 22:48:11 --> Model Class Initialized
INFO - 2018-03-31 22:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-03-31 22:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-03-31 22:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-03-31 22:48:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-03-31 22:48:11 --> Final output sent to browser
DEBUG - 2018-03-31 22:48:11 --> Total execution time: 0.1560
INFO - 2018-03-31 22:48:14 --> Config Class Initialized
INFO - 2018-03-31 22:48:14 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:14 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:14 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:14 --> URI Class Initialized
INFO - 2018-03-31 22:48:14 --> Router Class Initialized
INFO - 2018-03-31 22:48:14 --> Output Class Initialized
INFO - 2018-03-31 22:48:14 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:14 --> Input Class Initialized
INFO - 2018-03-31 22:48:14 --> Language Class Initialized
INFO - 2018-03-31 22:48:14 --> Loader Class Initialized
INFO - 2018-03-31 22:48:14 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:14 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:14 --> Email Class Initialized
INFO - 2018-03-31 22:48:14 --> Controller Class Initialized
INFO - 2018-03-31 22:48:14 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:14 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:14 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:14 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:14 --> Model Class Initialized
INFO - 2018-03-31 22:48:14 --> Model Class Initialized
INFO - 2018-03-31 22:48:14 --> Model Class Initialized
INFO - 2018-03-31 22:48:17 --> Config Class Initialized
INFO - 2018-03-31 22:48:17 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:17 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:17 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:17 --> URI Class Initialized
INFO - 2018-03-31 22:48:17 --> Router Class Initialized
INFO - 2018-03-31 22:48:17 --> Output Class Initialized
INFO - 2018-03-31 22:48:17 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:17 --> Input Class Initialized
INFO - 2018-03-31 22:48:17 --> Language Class Initialized
INFO - 2018-03-31 22:48:17 --> Loader Class Initialized
INFO - 2018-03-31 22:48:17 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:17 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:17 --> Email Class Initialized
INFO - 2018-03-31 22:48:17 --> Controller Class Initialized
INFO - 2018-03-31 22:48:17 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:17 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:17 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:17 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:17 --> Model Class Initialized
INFO - 2018-03-31 22:48:17 --> Model Class Initialized
INFO - 2018-03-31 22:48:17 --> Model Class Initialized
INFO - 2018-03-31 22:48:54 --> Config Class Initialized
INFO - 2018-03-31 22:48:54 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:54 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:54 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:54 --> URI Class Initialized
INFO - 2018-03-31 22:48:54 --> Router Class Initialized
INFO - 2018-03-31 22:48:54 --> Output Class Initialized
INFO - 2018-03-31 22:48:54 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:54 --> Input Class Initialized
INFO - 2018-03-31 22:48:54 --> Language Class Initialized
INFO - 2018-03-31 22:48:54 --> Loader Class Initialized
INFO - 2018-03-31 22:48:54 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:54 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:54 --> Email Class Initialized
INFO - 2018-03-31 22:48:54 --> Controller Class Initialized
INFO - 2018-03-31 22:48:54 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:54 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:54 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:54 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:54 --> Model Class Initialized
INFO - 2018-03-31 22:48:54 --> Model Class Initialized
INFO - 2018-03-31 22:48:54 --> Model Class Initialized
INFO - 2018-03-31 22:48:57 --> Config Class Initialized
INFO - 2018-03-31 22:48:57 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:57 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:57 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:57 --> URI Class Initialized
INFO - 2018-03-31 22:48:57 --> Router Class Initialized
INFO - 2018-03-31 22:48:57 --> Output Class Initialized
INFO - 2018-03-31 22:48:57 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:57 --> Input Class Initialized
INFO - 2018-03-31 22:48:57 --> Language Class Initialized
INFO - 2018-03-31 22:48:57 --> Loader Class Initialized
INFO - 2018-03-31 22:48:57 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:57 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:57 --> Email Class Initialized
INFO - 2018-03-31 22:48:57 --> Controller Class Initialized
INFO - 2018-03-31 22:48:57 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:57 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:57 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:57 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:57 --> Model Class Initialized
INFO - 2018-03-31 22:48:57 --> Model Class Initialized
INFO - 2018-03-31 22:48:57 --> Model Class Initialized
INFO - 2018-03-31 22:48:58 --> Config Class Initialized
INFO - 2018-03-31 22:48:58 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:48:58 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:48:58 --> Utf8 Class Initialized
INFO - 2018-03-31 22:48:58 --> URI Class Initialized
INFO - 2018-03-31 22:48:58 --> Router Class Initialized
INFO - 2018-03-31 22:48:58 --> Output Class Initialized
INFO - 2018-03-31 22:48:58 --> Security Class Initialized
DEBUG - 2018-03-31 22:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:48:58 --> Input Class Initialized
INFO - 2018-03-31 22:48:58 --> Language Class Initialized
INFO - 2018-03-31 22:48:58 --> Loader Class Initialized
INFO - 2018-03-31 22:48:58 --> Helper loaded: common_helper
INFO - 2018-03-31 22:48:58 --> Database Driver Class Initialized
INFO - 2018-03-31 22:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:48:58 --> Email Class Initialized
INFO - 2018-03-31 22:48:58 --> Controller Class Initialized
INFO - 2018-03-31 22:48:58 --> Helper loaded: form_helper
INFO - 2018-03-31 22:48:58 --> Form Validation Class Initialized
INFO - 2018-03-31 22:48:58 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:48:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:48:58 --> Helper loaded: url_helper
INFO - 2018-03-31 22:48:59 --> Model Class Initialized
INFO - 2018-03-31 22:48:59 --> Model Class Initialized
INFO - 2018-03-31 22:48:59 --> Model Class Initialized
INFO - 2018-03-31 22:49:00 --> Config Class Initialized
INFO - 2018-03-31 22:49:00 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:00 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:00 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:00 --> URI Class Initialized
INFO - 2018-03-31 22:49:00 --> Router Class Initialized
INFO - 2018-03-31 22:49:00 --> Output Class Initialized
INFO - 2018-03-31 22:49:00 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:00 --> Input Class Initialized
INFO - 2018-03-31 22:49:00 --> Language Class Initialized
INFO - 2018-03-31 22:49:00 --> Loader Class Initialized
INFO - 2018-03-31 22:49:00 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:00 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:01 --> Email Class Initialized
INFO - 2018-03-31 22:49:01 --> Controller Class Initialized
INFO - 2018-03-31 22:49:01 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:01 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:01 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:01 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:01 --> Model Class Initialized
INFO - 2018-03-31 22:49:01 --> Model Class Initialized
INFO - 2018-03-31 22:49:01 --> Model Class Initialized
INFO - 2018-03-31 22:49:03 --> Config Class Initialized
INFO - 2018-03-31 22:49:03 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:03 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:03 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:03 --> URI Class Initialized
INFO - 2018-03-31 22:49:03 --> Router Class Initialized
INFO - 2018-03-31 22:49:03 --> Output Class Initialized
INFO - 2018-03-31 22:49:03 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:03 --> Input Class Initialized
INFO - 2018-03-31 22:49:03 --> Language Class Initialized
INFO - 2018-03-31 22:49:03 --> Loader Class Initialized
INFO - 2018-03-31 22:49:03 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:03 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:03 --> Email Class Initialized
INFO - 2018-03-31 22:49:03 --> Controller Class Initialized
INFO - 2018-03-31 22:49:03 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:03 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:03 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:03 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:03 --> Model Class Initialized
INFO - 2018-03-31 22:49:03 --> Model Class Initialized
INFO - 2018-03-31 22:49:03 --> Model Class Initialized
INFO - 2018-03-31 22:49:05 --> Config Class Initialized
INFO - 2018-03-31 22:49:05 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:05 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:05 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:05 --> URI Class Initialized
INFO - 2018-03-31 22:49:05 --> Router Class Initialized
INFO - 2018-03-31 22:49:05 --> Output Class Initialized
INFO - 2018-03-31 22:49:05 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:05 --> Input Class Initialized
INFO - 2018-03-31 22:49:05 --> Language Class Initialized
INFO - 2018-03-31 22:49:05 --> Loader Class Initialized
INFO - 2018-03-31 22:49:05 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:05 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:05 --> Email Class Initialized
INFO - 2018-03-31 22:49:05 --> Controller Class Initialized
INFO - 2018-03-31 22:49:05 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:05 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:05 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:05 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:05 --> Model Class Initialized
INFO - 2018-03-31 22:49:05 --> Model Class Initialized
INFO - 2018-03-31 22:49:05 --> Model Class Initialized
INFO - 2018-03-31 22:49:08 --> Config Class Initialized
INFO - 2018-03-31 22:49:08 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:08 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:08 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:08 --> URI Class Initialized
INFO - 2018-03-31 22:49:08 --> Router Class Initialized
INFO - 2018-03-31 22:49:08 --> Output Class Initialized
INFO - 2018-03-31 22:49:08 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:08 --> Input Class Initialized
INFO - 2018-03-31 22:49:08 --> Language Class Initialized
INFO - 2018-03-31 22:49:08 --> Loader Class Initialized
INFO - 2018-03-31 22:49:08 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:08 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:08 --> Email Class Initialized
INFO - 2018-03-31 22:49:08 --> Controller Class Initialized
INFO - 2018-03-31 22:49:08 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:08 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:08 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:08 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:08 --> Model Class Initialized
INFO - 2018-03-31 22:49:08 --> Model Class Initialized
INFO - 2018-03-31 22:49:08 --> Model Class Initialized
INFO - 2018-03-31 22:49:10 --> Config Class Initialized
INFO - 2018-03-31 22:49:10 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:10 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:10 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:10 --> URI Class Initialized
INFO - 2018-03-31 22:49:10 --> Router Class Initialized
INFO - 2018-03-31 22:49:10 --> Output Class Initialized
INFO - 2018-03-31 22:49:10 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:10 --> Input Class Initialized
INFO - 2018-03-31 22:49:10 --> Language Class Initialized
INFO - 2018-03-31 22:49:10 --> Loader Class Initialized
INFO - 2018-03-31 22:49:10 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:10 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:10 --> Email Class Initialized
INFO - 2018-03-31 22:49:10 --> Controller Class Initialized
INFO - 2018-03-31 22:49:11 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:11 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:11 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:11 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:11 --> Model Class Initialized
INFO - 2018-03-31 22:49:11 --> Model Class Initialized
INFO - 2018-03-31 22:49:11 --> Model Class Initialized
INFO - 2018-03-31 22:49:15 --> Config Class Initialized
INFO - 2018-03-31 22:49:15 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:15 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:15 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:15 --> URI Class Initialized
INFO - 2018-03-31 22:49:15 --> Router Class Initialized
INFO - 2018-03-31 22:49:15 --> Output Class Initialized
INFO - 2018-03-31 22:49:15 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:15 --> Input Class Initialized
INFO - 2018-03-31 22:49:15 --> Language Class Initialized
INFO - 2018-03-31 22:49:15 --> Loader Class Initialized
INFO - 2018-03-31 22:49:15 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:15 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:15 --> Email Class Initialized
INFO - 2018-03-31 22:49:15 --> Controller Class Initialized
INFO - 2018-03-31 22:49:15 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:15 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:15 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:15 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:15 --> Model Class Initialized
INFO - 2018-03-31 22:49:15 --> Model Class Initialized
INFO - 2018-03-31 22:49:15 --> Model Class Initialized
INFO - 2018-03-31 22:49:33 --> Config Class Initialized
INFO - 2018-03-31 22:49:33 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:33 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:33 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:33 --> URI Class Initialized
INFO - 2018-03-31 22:49:33 --> Router Class Initialized
INFO - 2018-03-31 22:49:33 --> Output Class Initialized
INFO - 2018-03-31 22:49:33 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:33 --> Input Class Initialized
INFO - 2018-03-31 22:49:33 --> Language Class Initialized
INFO - 2018-03-31 22:49:33 --> Loader Class Initialized
INFO - 2018-03-31 22:49:33 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:33 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:33 --> Email Class Initialized
INFO - 2018-03-31 22:49:33 --> Controller Class Initialized
INFO - 2018-03-31 22:49:33 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:33 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:33 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:33 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:33 --> Model Class Initialized
INFO - 2018-03-31 22:49:33 --> Model Class Initialized
INFO - 2018-03-31 22:49:33 --> Model Class Initialized
INFO - 2018-03-31 22:49:35 --> Config Class Initialized
INFO - 2018-03-31 22:49:35 --> Hooks Class Initialized
DEBUG - 2018-03-31 22:49:35 --> UTF-8 Support Enabled
INFO - 2018-03-31 22:49:35 --> Utf8 Class Initialized
INFO - 2018-03-31 22:49:35 --> URI Class Initialized
INFO - 2018-03-31 22:49:35 --> Router Class Initialized
INFO - 2018-03-31 22:49:35 --> Output Class Initialized
INFO - 2018-03-31 22:49:35 --> Security Class Initialized
DEBUG - 2018-03-31 22:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-03-31 22:49:35 --> Input Class Initialized
INFO - 2018-03-31 22:49:35 --> Language Class Initialized
INFO - 2018-03-31 22:49:35 --> Loader Class Initialized
INFO - 2018-03-31 22:49:35 --> Helper loaded: common_helper
INFO - 2018-03-31 22:49:35 --> Database Driver Class Initialized
INFO - 2018-03-31 22:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-03-31 22:49:35 --> Email Class Initialized
INFO - 2018-03-31 22:49:35 --> Controller Class Initialized
INFO - 2018-03-31 22:49:35 --> Helper loaded: form_helper
INFO - 2018-03-31 22:49:35 --> Form Validation Class Initialized
INFO - 2018-03-31 22:49:35 --> Helper loaded: email_helper
DEBUG - 2018-03-31 22:49:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-03-31 22:49:35 --> Helper loaded: url_helper
INFO - 2018-03-31 22:49:35 --> Model Class Initialized
INFO - 2018-03-31 22:49:35 --> Model Class Initialized
INFO - 2018-03-31 22:49:35 --> Model Class Initialized
