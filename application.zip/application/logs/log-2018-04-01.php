<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:02 --> Final output sent to browser
DEBUG - 2018-04-01 02:18:02 --> Total execution time: 0.2770
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:18:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:14 --> Final output sent to browser
DEBUG - 2018-04-01 02:18:14 --> Total execution time: 0.2230
INFO - 2018-04-01 02:18:17 --> Helper loaded: download_helper
INFO - 2018-04-01 02:18:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2018-04-01 02:18:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:17 --> Final output sent to browser
DEBUG - 2018-04-01 02:18:17 --> Total execution time: 0.2540
INFO - 2018-04-01 02:18:54 --> Helper loaded: download_helper
INFO - 2018-04-01 02:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2018-04-01 02:18:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:54 --> Final output sent to browser
DEBUG - 2018-04-01 02:18:54 --> Total execution time: 0.1350
INFO - 2018-04-01 02:18:57 --> Helper loaded: download_helper
INFO - 2018-04-01 02:18:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2018-04-01 02:18:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:57 --> Final output sent to browser
DEBUG - 2018-04-01 02:18:57 --> Total execution time: 0.1840
INFO - 2018-04-01 02:18:59 --> Helper loaded: download_helper
INFO - 2018-04-01 02:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2018-04-01 02:18:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:18:59 --> Final output sent to browser
DEBUG - 2018-04-01 02:18:59 --> Total execution time: 0.1480
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:01 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:01 --> Total execution time: 0.1380
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:03 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:03 --> Total execution time: 0.2390
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:05 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:05 --> Total execution time: 0.2450
INFO - 2018-04-01 02:19:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-01 02:19:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:08 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:08 --> Total execution time: 0.1950
INFO - 2018-04-01 02:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-01 02:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:11 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:11 --> Total execution time: 0.1290
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:15 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:15 --> Total execution time: 0.1360
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 02:19:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 02:19:35 --> Final output sent to browser
DEBUG - 2018-04-01 02:19:35 --> Total execution time: 0.1550
INFO - 2018-04-01 15:23:22 --> Config Class Initialized
INFO - 2018-04-01 15:23:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:22 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:22 --> URI Class Initialized
INFO - 2018-04-01 15:23:22 --> Router Class Initialized
INFO - 2018-04-01 15:23:22 --> Output Class Initialized
INFO - 2018-04-01 15:23:22 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:22 --> Input Class Initialized
INFO - 2018-04-01 15:23:22 --> Language Class Initialized
INFO - 2018-04-01 15:23:22 --> Loader Class Initialized
INFO - 2018-04-01 15:23:22 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:22 --> Database Driver Class Initialized
ERROR - 2018-04-01 15:23:22 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-01 15:23:22 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-01 15:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:22 --> Email Class Initialized
INFO - 2018-04-01 15:23:22 --> Controller Class Initialized
INFO - 2018-04-01 15:23:22 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:22 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:22 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:22 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:22 --> Model Class Initialized
INFO - 2018-04-01 15:23:22 --> Model Class Initialized
INFO - 2018-04-01 15:23:22 --> Model Class Initialized
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:22 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:22 --> Total execution time: 0.1950
INFO - 2018-04-01 15:23:22 --> Config Class Initialized
INFO - 2018-04-01 15:23:22 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:22 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:22 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:22 --> URI Class Initialized
INFO - 2018-04-01 15:23:22 --> Router Class Initialized
INFO - 2018-04-01 15:23:22 --> Output Class Initialized
INFO - 2018-04-01 15:23:22 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:22 --> Input Class Initialized
INFO - 2018-04-01 15:23:22 --> Language Class Initialized
INFO - 2018-04-01 15:23:22 --> Loader Class Initialized
INFO - 2018-04-01 15:23:22 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:22 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:22 --> Email Class Initialized
INFO - 2018-04-01 15:23:22 --> Controller Class Initialized
INFO - 2018-04-01 15:23:22 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:22 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:22 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:22 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:22 --> Model Class Initialized
INFO - 2018-04-01 15:23:22 --> Model Class Initialized
INFO - 2018-04-01 15:23:22 --> Model Class Initialized
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:22 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:22 --> Total execution time: 0.1090
INFO - 2018-04-01 15:23:27 --> Config Class Initialized
INFO - 2018-04-01 15:23:27 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:27 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:27 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:27 --> URI Class Initialized
INFO - 2018-04-01 15:23:27 --> Router Class Initialized
INFO - 2018-04-01 15:23:27 --> Output Class Initialized
INFO - 2018-04-01 15:23:27 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:27 --> Input Class Initialized
INFO - 2018-04-01 15:23:27 --> Language Class Initialized
INFO - 2018-04-01 15:23:27 --> Loader Class Initialized
INFO - 2018-04-01 15:23:27 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:27 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:27 --> Email Class Initialized
INFO - 2018-04-01 15:23:27 --> Controller Class Initialized
INFO - 2018-04-01 15:23:27 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:27 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:27 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:27 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:27 --> Model Class Initialized
INFO - 2018-04-01 15:23:27 --> Model Class Initialized
INFO - 2018-04-01 15:23:27 --> Model Class Initialized
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:27 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:27 --> Total execution time: 0.0850
INFO - 2018-04-01 15:23:29 --> Config Class Initialized
INFO - 2018-04-01 15:23:29 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:29 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:29 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:29 --> URI Class Initialized
INFO - 2018-04-01 15:23:29 --> Router Class Initialized
INFO - 2018-04-01 15:23:29 --> Output Class Initialized
INFO - 2018-04-01 15:23:29 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:29 --> Input Class Initialized
INFO - 2018-04-01 15:23:29 --> Language Class Initialized
INFO - 2018-04-01 15:23:29 --> Loader Class Initialized
INFO - 2018-04-01 15:23:29 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:29 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:29 --> Email Class Initialized
INFO - 2018-04-01 15:23:29 --> Controller Class Initialized
INFO - 2018-04-01 15:23:29 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:29 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:29 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:29 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:29 --> Model Class Initialized
INFO - 2018-04-01 15:23:29 --> Model Class Initialized
INFO - 2018-04-01 15:23:29 --> Model Class Initialized
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:29 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:29 --> Total execution time: 0.1090
INFO - 2018-04-01 15:23:31 --> Config Class Initialized
INFO - 2018-04-01 15:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:31 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:31 --> URI Class Initialized
INFO - 2018-04-01 15:23:31 --> Router Class Initialized
INFO - 2018-04-01 15:23:31 --> Output Class Initialized
INFO - 2018-04-01 15:23:31 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:31 --> Input Class Initialized
INFO - 2018-04-01 15:23:31 --> Language Class Initialized
INFO - 2018-04-01 15:23:31 --> Loader Class Initialized
INFO - 2018-04-01 15:23:31 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:31 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:31 --> Email Class Initialized
INFO - 2018-04-01 15:23:31 --> Controller Class Initialized
INFO - 2018-04-01 15:23:31 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:31 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:31 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:31 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:31 --> Model Class Initialized
INFO - 2018-04-01 15:23:31 --> Model Class Initialized
INFO - 2018-04-01 15:23:31 --> Model Class Initialized
INFO - 2018-04-01 15:23:31 --> Config Class Initialized
INFO - 2018-04-01 15:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:31 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:31 --> URI Class Initialized
INFO - 2018-04-01 15:23:31 --> Router Class Initialized
INFO - 2018-04-01 15:23:31 --> Output Class Initialized
INFO - 2018-04-01 15:23:31 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:31 --> Input Class Initialized
INFO - 2018-04-01 15:23:31 --> Language Class Initialized
INFO - 2018-04-01 15:23:31 --> Loader Class Initialized
INFO - 2018-04-01 15:23:31 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:31 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:31 --> Email Class Initialized
INFO - 2018-04-01 15:23:31 --> Controller Class Initialized
INFO - 2018-04-01 15:23:31 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:31 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:31 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:31 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:31 --> Model Class Initialized
INFO - 2018-04-01 15:23:31 --> Model Class Initialized
INFO - 2018-04-01 15:23:31 --> Config Class Initialized
INFO - 2018-04-01 15:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:31 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:31 --> URI Class Initialized
DEBUG - 2018-04-01 15:23:31 --> No URI present. Default controller set.
INFO - 2018-04-01 15:23:31 --> Router Class Initialized
INFO - 2018-04-01 15:23:31 --> Output Class Initialized
INFO - 2018-04-01 15:23:31 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:31 --> Input Class Initialized
INFO - 2018-04-01 15:23:31 --> Language Class Initialized
INFO - 2018-04-01 15:23:32 --> Loader Class Initialized
INFO - 2018-04-01 15:23:32 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:32 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:32 --> Email Class Initialized
INFO - 2018-04-01 15:23:32 --> Controller Class Initialized
INFO - 2018-04-01 15:23:32 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:32 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:32 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:32 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:32 --> Model Class Initialized
INFO - 2018-04-01 15:23:32 --> Model Class Initialized
INFO - 2018-04-01 15:23:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-01 15:23:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 15:23:32 --> Final output sent to browser
DEBUG - 2018-04-01 15:23:32 --> Total execution time: 0.0680
INFO - 2018-04-01 15:23:35 --> Config Class Initialized
INFO - 2018-04-01 15:23:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:35 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:35 --> URI Class Initialized
DEBUG - 2018-04-01 15:23:35 --> No URI present. Default controller set.
INFO - 2018-04-01 15:23:35 --> Router Class Initialized
INFO - 2018-04-01 15:23:35 --> Output Class Initialized
INFO - 2018-04-01 15:23:35 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:35 --> Input Class Initialized
INFO - 2018-04-01 15:23:35 --> Language Class Initialized
INFO - 2018-04-01 15:23:35 --> Loader Class Initialized
INFO - 2018-04-01 15:23:35 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:35 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:35 --> Email Class Initialized
INFO - 2018-04-01 15:23:35 --> Controller Class Initialized
INFO - 2018-04-01 15:23:35 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:35 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:35 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:35 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:35 --> Model Class Initialized
INFO - 2018-04-01 15:23:35 --> Model Class Initialized
DEBUG - 2018-04-01 15:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-01 15:23:35 --> Config Class Initialized
INFO - 2018-04-01 15:23:35 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:35 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:35 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:35 --> URI Class Initialized
INFO - 2018-04-01 15:23:35 --> Router Class Initialized
INFO - 2018-04-01 15:23:35 --> Output Class Initialized
INFO - 2018-04-01 15:23:35 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:35 --> Input Class Initialized
INFO - 2018-04-01 15:23:35 --> Language Class Initialized
INFO - 2018-04-01 15:23:35 --> Loader Class Initialized
INFO - 2018-04-01 15:23:35 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:35 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:35 --> Email Class Initialized
INFO - 2018-04-01 15:23:35 --> Controller Class Initialized
INFO - 2018-04-01 15:23:35 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:35 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:35 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:35 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:35 --> Model Class Initialized
INFO - 2018-04-01 15:23:35 --> Model Class Initialized
INFO - 2018-04-01 15:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 15:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 15:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-01 15:23:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 15:23:35 --> Final output sent to browser
DEBUG - 2018-04-01 15:23:35 --> Total execution time: 0.0800
INFO - 2018-04-01 15:23:38 --> Config Class Initialized
INFO - 2018-04-01 15:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:23:38 --> Utf8 Class Initialized
INFO - 2018-04-01 15:23:38 --> URI Class Initialized
INFO - 2018-04-01 15:23:38 --> Router Class Initialized
INFO - 2018-04-01 15:23:38 --> Output Class Initialized
INFO - 2018-04-01 15:23:38 --> Security Class Initialized
DEBUG - 2018-04-01 15:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:23:38 --> Input Class Initialized
INFO - 2018-04-01 15:23:38 --> Language Class Initialized
INFO - 2018-04-01 15:23:38 --> Loader Class Initialized
INFO - 2018-04-01 15:23:38 --> Helper loaded: common_helper
INFO - 2018-04-01 15:23:38 --> Database Driver Class Initialized
INFO - 2018-04-01 15:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:23:38 --> Email Class Initialized
INFO - 2018-04-01 15:23:38 --> Controller Class Initialized
INFO - 2018-04-01 15:23:38 --> Helper loaded: form_helper
INFO - 2018-04-01 15:23:38 --> Form Validation Class Initialized
INFO - 2018-04-01 15:23:38 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:23:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:23:38 --> Helper loaded: url_helper
INFO - 2018-04-01 15:23:38 --> Model Class Initialized
INFO - 2018-04-01 15:23:38 --> Model Class Initialized
INFO - 2018-04-01 15:23:38 --> Model Class Initialized
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:53:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:53:38 --> Final output sent to browser
DEBUG - 2018-04-01 18:53:38 --> Total execution time: 0.0870
INFO - 2018-04-01 15:26:15 --> Config Class Initialized
INFO - 2018-04-01 15:26:15 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:26:15 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:26:15 --> Utf8 Class Initialized
INFO - 2018-04-01 15:26:15 --> URI Class Initialized
INFO - 2018-04-01 15:26:15 --> Router Class Initialized
INFO - 2018-04-01 15:26:15 --> Output Class Initialized
INFO - 2018-04-01 15:26:15 --> Security Class Initialized
DEBUG - 2018-04-01 15:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:26:15 --> Input Class Initialized
INFO - 2018-04-01 15:26:15 --> Language Class Initialized
INFO - 2018-04-01 15:26:15 --> Loader Class Initialized
INFO - 2018-04-01 15:26:15 --> Helper loaded: common_helper
INFO - 2018-04-01 15:26:15 --> Database Driver Class Initialized
INFO - 2018-04-01 15:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:26:16 --> Email Class Initialized
INFO - 2018-04-01 15:26:16 --> Controller Class Initialized
INFO - 2018-04-01 15:26:16 --> Helper loaded: form_helper
INFO - 2018-04-01 15:26:16 --> Form Validation Class Initialized
INFO - 2018-04-01 15:26:16 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:26:16 --> Helper loaded: url_helper
INFO - 2018-04-01 15:26:16 --> Model Class Initialized
INFO - 2018-04-01 15:26:16 --> Model Class Initialized
INFO - 2018-04-01 15:26:16 --> Model Class Initialized
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:56:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:56:16 --> Final output sent to browser
DEBUG - 2018-04-01 18:56:16 --> Total execution time: 0.1540
INFO - 2018-04-01 15:27:38 --> Config Class Initialized
INFO - 2018-04-01 15:27:38 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:27:38 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:27:38 --> Utf8 Class Initialized
INFO - 2018-04-01 15:27:38 --> URI Class Initialized
INFO - 2018-04-01 15:27:38 --> Router Class Initialized
INFO - 2018-04-01 15:27:38 --> Output Class Initialized
INFO - 2018-04-01 15:27:38 --> Security Class Initialized
DEBUG - 2018-04-01 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:27:38 --> Input Class Initialized
INFO - 2018-04-01 15:27:38 --> Language Class Initialized
INFO - 2018-04-01 15:27:38 --> Loader Class Initialized
INFO - 2018-04-01 15:27:38 --> Helper loaded: common_helper
INFO - 2018-04-01 15:27:38 --> Database Driver Class Initialized
INFO - 2018-04-01 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:27:38 --> Email Class Initialized
INFO - 2018-04-01 15:27:38 --> Controller Class Initialized
INFO - 2018-04-01 15:27:38 --> Helper loaded: form_helper
INFO - 2018-04-01 15:27:38 --> Form Validation Class Initialized
INFO - 2018-04-01 15:27:38 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:27:38 --> Helper loaded: url_helper
INFO - 2018-04-01 15:27:38 --> Model Class Initialized
INFO - 2018-04-01 15:27:38 --> Model Class Initialized
INFO - 2018-04-01 15:27:38 --> Model Class Initialized
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:57:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:57:38 --> Final output sent to browser
DEBUG - 2018-04-01 18:57:38 --> Total execution time: 0.1670
INFO - 2018-04-01 15:27:40 --> Config Class Initialized
INFO - 2018-04-01 15:27:40 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:27:40 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:27:40 --> Utf8 Class Initialized
INFO - 2018-04-01 15:27:40 --> URI Class Initialized
INFO - 2018-04-01 15:27:40 --> Router Class Initialized
INFO - 2018-04-01 15:27:40 --> Output Class Initialized
INFO - 2018-04-01 15:27:40 --> Security Class Initialized
DEBUG - 2018-04-01 15:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:27:40 --> Input Class Initialized
INFO - 2018-04-01 15:27:40 --> Language Class Initialized
INFO - 2018-04-01 15:27:40 --> Loader Class Initialized
INFO - 2018-04-01 15:27:40 --> Helper loaded: common_helper
INFO - 2018-04-01 15:27:40 --> Database Driver Class Initialized
INFO - 2018-04-01 15:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:27:40 --> Email Class Initialized
INFO - 2018-04-01 15:27:40 --> Controller Class Initialized
INFO - 2018-04-01 15:27:40 --> Helper loaded: form_helper
INFO - 2018-04-01 15:27:40 --> Form Validation Class Initialized
INFO - 2018-04-01 15:27:40 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:27:40 --> Helper loaded: url_helper
INFO - 2018-04-01 15:27:40 --> Model Class Initialized
INFO - 2018-04-01 15:27:40 --> Model Class Initialized
INFO - 2018-04-01 18:57:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:57:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:57:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:57:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2018-04-01 18:57:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:57:40 --> Final output sent to browser
DEBUG - 2018-04-01 18:57:40 --> Total execution time: 0.2600
INFO - 2018-04-01 15:28:09 --> Config Class Initialized
INFO - 2018-04-01 15:28:09 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:28:09 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:28:09 --> Utf8 Class Initialized
INFO - 2018-04-01 15:28:09 --> URI Class Initialized
INFO - 2018-04-01 15:28:09 --> Router Class Initialized
INFO - 2018-04-01 15:28:09 --> Output Class Initialized
INFO - 2018-04-01 15:28:09 --> Security Class Initialized
DEBUG - 2018-04-01 15:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:28:09 --> Input Class Initialized
INFO - 2018-04-01 15:28:09 --> Language Class Initialized
INFO - 2018-04-01 15:28:09 --> Loader Class Initialized
INFO - 2018-04-01 15:28:09 --> Helper loaded: common_helper
INFO - 2018-04-01 15:28:09 --> Database Driver Class Initialized
INFO - 2018-04-01 15:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:28:09 --> Email Class Initialized
INFO - 2018-04-01 15:28:09 --> Controller Class Initialized
INFO - 2018-04-01 15:28:09 --> Helper loaded: form_helper
INFO - 2018-04-01 15:28:09 --> Form Validation Class Initialized
INFO - 2018-04-01 15:28:09 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:28:09 --> Helper loaded: url_helper
INFO - 2018-04-01 15:28:09 --> Model Class Initialized
INFO - 2018-04-01 15:28:09 --> Model Class Initialized
INFO - 2018-04-01 15:28:09 --> Model Class Initialized
INFO - 2018-04-01 18:58:09 --> Helper loaded: download_helper
INFO - 2018-04-01 18:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\users/users.php
INFO - 2018-04-01 18:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:58:09 --> Final output sent to browser
DEBUG - 2018-04-01 18:58:09 --> Total execution time: 0.1270
INFO - 2018-04-01 15:28:26 --> Config Class Initialized
INFO - 2018-04-01 15:28:26 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:28:26 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:28:26 --> Utf8 Class Initialized
INFO - 2018-04-01 15:28:26 --> URI Class Initialized
INFO - 2018-04-01 15:28:26 --> Router Class Initialized
INFO - 2018-04-01 15:28:26 --> Output Class Initialized
INFO - 2018-04-01 15:28:26 --> Security Class Initialized
DEBUG - 2018-04-01 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:28:26 --> Input Class Initialized
INFO - 2018-04-01 15:28:26 --> Language Class Initialized
INFO - 2018-04-01 15:28:27 --> Loader Class Initialized
INFO - 2018-04-01 15:28:27 --> Helper loaded: common_helper
INFO - 2018-04-01 15:28:27 --> Database Driver Class Initialized
INFO - 2018-04-01 15:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:28:27 --> Email Class Initialized
INFO - 2018-04-01 15:28:27 --> Controller Class Initialized
INFO - 2018-04-01 15:28:27 --> Helper loaded: form_helper
INFO - 2018-04-01 15:28:27 --> Form Validation Class Initialized
INFO - 2018-04-01 15:28:27 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:28:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:28:27 --> Helper loaded: url_helper
INFO - 2018-04-01 15:28:27 --> Model Class Initialized
INFO - 2018-04-01 15:28:27 --> Model Class Initialized
INFO - 2018-04-01 18:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Categories/categories.php
INFO - 2018-04-01 18:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:58:27 --> Final output sent to browser
DEBUG - 2018-04-01 18:58:27 --> Total execution time: 0.1980
INFO - 2018-04-01 15:28:56 --> Config Class Initialized
INFO - 2018-04-01 15:28:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:28:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:28:56 --> Utf8 Class Initialized
INFO - 2018-04-01 15:28:56 --> URI Class Initialized
INFO - 2018-04-01 15:28:56 --> Router Class Initialized
INFO - 2018-04-01 15:28:56 --> Output Class Initialized
INFO - 2018-04-01 15:28:56 --> Security Class Initialized
DEBUG - 2018-04-01 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:28:56 --> Input Class Initialized
INFO - 2018-04-01 15:28:56 --> Language Class Initialized
INFO - 2018-04-01 15:28:56 --> Loader Class Initialized
INFO - 2018-04-01 15:28:56 --> Helper loaded: common_helper
INFO - 2018-04-01 15:28:56 --> Database Driver Class Initialized
ERROR - 2018-04-01 15:28:56 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-01 15:28:56 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-01 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:28:56 --> Email Class Initialized
INFO - 2018-04-01 15:28:56 --> Controller Class Initialized
INFO - 2018-04-01 15:28:56 --> Helper loaded: form_helper
INFO - 2018-04-01 15:28:56 --> Form Validation Class Initialized
INFO - 2018-04-01 15:28:56 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:28:56 --> Helper loaded: url_helper
INFO - 2018-04-01 15:28:56 --> Model Class Initialized
INFO - 2018-04-01 15:28:56 --> Model Class Initialized
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:58:56 --> Final output sent to browser
DEBUG - 2018-04-01 18:58:56 --> Total execution time: 0.3980
INFO - 2018-04-01 15:28:56 --> Config Class Initialized
INFO - 2018-04-01 15:28:56 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:28:56 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:28:56 --> Utf8 Class Initialized
INFO - 2018-04-01 15:28:56 --> URI Class Initialized
INFO - 2018-04-01 15:28:56 --> Router Class Initialized
INFO - 2018-04-01 15:28:56 --> Output Class Initialized
INFO - 2018-04-01 15:28:56 --> Security Class Initialized
DEBUG - 2018-04-01 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:28:56 --> Input Class Initialized
INFO - 2018-04-01 15:28:56 --> Language Class Initialized
INFO - 2018-04-01 15:28:56 --> Loader Class Initialized
INFO - 2018-04-01 15:28:56 --> Helper loaded: common_helper
INFO - 2018-04-01 15:28:56 --> Database Driver Class Initialized
INFO - 2018-04-01 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:28:56 --> Email Class Initialized
INFO - 2018-04-01 15:28:56 --> Controller Class Initialized
INFO - 2018-04-01 15:28:56 --> Helper loaded: form_helper
INFO - 2018-04-01 15:28:56 --> Form Validation Class Initialized
INFO - 2018-04-01 15:28:56 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:28:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:28:56 --> Helper loaded: url_helper
INFO - 2018-04-01 15:28:56 --> Model Class Initialized
INFO - 2018-04-01 15:28:56 --> Model Class Initialized
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Articles/articles.php
INFO - 2018-04-01 18:58:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:58:56 --> Final output sent to browser
DEBUG - 2018-04-01 18:58:56 --> Total execution time: 0.1190
INFO - 2018-04-01 15:29:05 --> Config Class Initialized
INFO - 2018-04-01 15:29:05 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:29:05 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:29:05 --> Utf8 Class Initialized
INFO - 2018-04-01 15:29:05 --> URI Class Initialized
INFO - 2018-04-01 15:29:05 --> Router Class Initialized
INFO - 2018-04-01 15:29:05 --> Output Class Initialized
INFO - 2018-04-01 15:29:05 --> Security Class Initialized
DEBUG - 2018-04-01 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:29:05 --> Input Class Initialized
INFO - 2018-04-01 15:29:05 --> Language Class Initialized
INFO - 2018-04-01 15:29:05 --> Loader Class Initialized
INFO - 2018-04-01 15:29:05 --> Helper loaded: common_helper
INFO - 2018-04-01 15:29:05 --> Database Driver Class Initialized
INFO - 2018-04-01 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:29:05 --> Email Class Initialized
INFO - 2018-04-01 15:29:05 --> Controller Class Initialized
INFO - 2018-04-01 15:29:05 --> Helper loaded: form_helper
INFO - 2018-04-01 15:29:05 --> Form Validation Class Initialized
INFO - 2018-04-01 15:29:05 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:29:05 --> Helper loaded: url_helper
INFO - 2018-04-01 15:29:05 --> Model Class Initialized
INFO - 2018-04-01 15:29:05 --> Model Class Initialized
INFO - 2018-04-01 18:59:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Subscriptions/subscriptions.php
INFO - 2018-04-01 18:59:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:05 --> Final output sent to browser
DEBUG - 2018-04-01 18:59:05 --> Total execution time: 0.1810
INFO - 2018-04-01 15:29:13 --> Config Class Initialized
INFO - 2018-04-01 15:29:13 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:29:13 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:29:13 --> Utf8 Class Initialized
INFO - 2018-04-01 15:29:13 --> URI Class Initialized
INFO - 2018-04-01 15:29:13 --> Router Class Initialized
INFO - 2018-04-01 15:29:13 --> Output Class Initialized
INFO - 2018-04-01 15:29:13 --> Security Class Initialized
DEBUG - 2018-04-01 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:29:13 --> Input Class Initialized
INFO - 2018-04-01 15:29:13 --> Language Class Initialized
INFO - 2018-04-01 15:29:13 --> Loader Class Initialized
INFO - 2018-04-01 15:29:13 --> Helper loaded: common_helper
INFO - 2018-04-01 15:29:13 --> Database Driver Class Initialized
INFO - 2018-04-01 15:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:29:13 --> Email Class Initialized
INFO - 2018-04-01 15:29:13 --> Controller Class Initialized
INFO - 2018-04-01 15:29:13 --> Helper loaded: form_helper
INFO - 2018-04-01 15:29:13 --> Form Validation Class Initialized
INFO - 2018-04-01 15:29:13 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:29:13 --> Helper loaded: url_helper
INFO - 2018-04-01 15:29:13 --> Model Class Initialized
INFO - 2018-04-01 15:29:13 --> Model Class Initialized
INFO - 2018-04-01 15:29:13 --> Model Class Initialized
INFO - 2018-04-01 18:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-01 18:59:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:13 --> Final output sent to browser
DEBUG - 2018-04-01 18:59:13 --> Total execution time: 0.1300
INFO - 2018-04-01 15:29:39 --> Config Class Initialized
INFO - 2018-04-01 15:29:39 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:29:39 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:29:39 --> Utf8 Class Initialized
INFO - 2018-04-01 15:29:39 --> URI Class Initialized
INFO - 2018-04-01 15:29:39 --> Router Class Initialized
INFO - 2018-04-01 15:29:39 --> Output Class Initialized
INFO - 2018-04-01 15:29:39 --> Security Class Initialized
DEBUG - 2018-04-01 15:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:29:39 --> Input Class Initialized
INFO - 2018-04-01 15:29:39 --> Language Class Initialized
INFO - 2018-04-01 15:29:39 --> Loader Class Initialized
INFO - 2018-04-01 15:29:39 --> Helper loaded: common_helper
INFO - 2018-04-01 15:29:39 --> Database Driver Class Initialized
INFO - 2018-04-01 15:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:29:39 --> Email Class Initialized
INFO - 2018-04-01 15:29:39 --> Controller Class Initialized
INFO - 2018-04-01 15:29:39 --> Helper loaded: form_helper
INFO - 2018-04-01 15:29:39 --> Form Validation Class Initialized
INFO - 2018-04-01 15:29:39 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:29:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:29:39 --> Helper loaded: url_helper
INFO - 2018-04-01 15:29:39 --> Model Class Initialized
INFO - 2018-04-01 15:29:39 --> Model Class Initialized
INFO - 2018-04-01 18:59:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Chats/chats.php
INFO - 2018-04-01 18:59:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:39 --> Final output sent to browser
DEBUG - 2018-04-01 18:59:39 --> Total execution time: 0.1310
INFO - 2018-04-01 15:29:41 --> Config Class Initialized
INFO - 2018-04-01 15:29:41 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:29:41 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:29:41 --> Utf8 Class Initialized
INFO - 2018-04-01 15:29:41 --> URI Class Initialized
INFO - 2018-04-01 15:29:41 --> Router Class Initialized
INFO - 2018-04-01 15:29:41 --> Output Class Initialized
INFO - 2018-04-01 15:29:41 --> Security Class Initialized
DEBUG - 2018-04-01 15:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:29:41 --> Input Class Initialized
INFO - 2018-04-01 15:29:41 --> Language Class Initialized
INFO - 2018-04-01 15:29:41 --> Loader Class Initialized
INFO - 2018-04-01 15:29:41 --> Helper loaded: common_helper
INFO - 2018-04-01 15:29:41 --> Database Driver Class Initialized
INFO - 2018-04-01 15:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:29:41 --> Email Class Initialized
INFO - 2018-04-01 15:29:41 --> Controller Class Initialized
INFO - 2018-04-01 15:29:41 --> Helper loaded: form_helper
INFO - 2018-04-01 15:29:41 --> Form Validation Class Initialized
INFO - 2018-04-01 15:29:41 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:29:41 --> Helper loaded: url_helper
INFO - 2018-04-01 18:59:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2018-04-01 18:59:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:41 --> Final output sent to browser
DEBUG - 2018-04-01 18:59:41 --> Total execution time: 0.1910
INFO - 2018-04-01 15:29:43 --> Config Class Initialized
INFO - 2018-04-01 15:29:43 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:29:43 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:29:43 --> Utf8 Class Initialized
INFO - 2018-04-01 15:29:43 --> URI Class Initialized
INFO - 2018-04-01 15:29:43 --> Router Class Initialized
INFO - 2018-04-01 15:29:43 --> Output Class Initialized
INFO - 2018-04-01 15:29:43 --> Security Class Initialized
DEBUG - 2018-04-01 15:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:29:43 --> Input Class Initialized
INFO - 2018-04-01 15:29:43 --> Language Class Initialized
INFO - 2018-04-01 15:29:43 --> Loader Class Initialized
INFO - 2018-04-01 15:29:43 --> Helper loaded: common_helper
INFO - 2018-04-01 15:29:43 --> Database Driver Class Initialized
INFO - 2018-04-01 15:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:29:43 --> Email Class Initialized
INFO - 2018-04-01 15:29:43 --> Controller Class Initialized
INFO - 2018-04-01 15:29:43 --> Helper loaded: form_helper
INFO - 2018-04-01 15:29:43 --> Form Validation Class Initialized
INFO - 2018-04-01 15:29:43 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:29:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:29:43 --> Helper loaded: url_helper
INFO - 2018-04-01 18:59:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Settings/settings.php
INFO - 2018-04-01 18:59:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:43 --> Final output sent to browser
DEBUG - 2018-04-01 18:59:43 --> Total execution time: 0.1170
INFO - 2018-04-01 15:29:47 --> Config Class Initialized
INFO - 2018-04-01 15:29:47 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:29:47 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:29:47 --> Utf8 Class Initialized
INFO - 2018-04-01 15:29:47 --> URI Class Initialized
INFO - 2018-04-01 15:29:47 --> Router Class Initialized
INFO - 2018-04-01 15:29:47 --> Output Class Initialized
INFO - 2018-04-01 15:29:47 --> Security Class Initialized
DEBUG - 2018-04-01 15:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:29:47 --> Input Class Initialized
INFO - 2018-04-01 15:29:47 --> Language Class Initialized
INFO - 2018-04-01 15:29:47 --> Loader Class Initialized
INFO - 2018-04-01 15:29:47 --> Helper loaded: common_helper
INFO - 2018-04-01 15:29:47 --> Database Driver Class Initialized
INFO - 2018-04-01 15:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:29:47 --> Email Class Initialized
INFO - 2018-04-01 15:29:47 --> Controller Class Initialized
INFO - 2018-04-01 15:29:47 --> Helper loaded: form_helper
INFO - 2018-04-01 15:29:47 --> Form Validation Class Initialized
INFO - 2018-04-01 15:29:47 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:29:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:29:47 --> Helper loaded: url_helper
INFO - 2018-04-01 15:29:47 --> Model Class Initialized
INFO - 2018-04-01 15:29:47 --> Model Class Initialized
INFO - 2018-04-01 15:29:47 --> Model Class Initialized
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 18:59:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 18:59:47 --> Final output sent to browser
DEBUG - 2018-04-01 18:59:47 --> Total execution time: 0.1350
INFO - 2018-04-01 15:42:04 --> Config Class Initialized
INFO - 2018-04-01 15:42:04 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:42:04 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:42:04 --> Utf8 Class Initialized
INFO - 2018-04-01 15:42:04 --> URI Class Initialized
INFO - 2018-04-01 15:42:04 --> Router Class Initialized
INFO - 2018-04-01 15:42:04 --> Output Class Initialized
INFO - 2018-04-01 15:42:04 --> Security Class Initialized
DEBUG - 2018-04-01 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:42:04 --> Input Class Initialized
INFO - 2018-04-01 15:42:04 --> Language Class Initialized
INFO - 2018-04-01 15:42:04 --> Loader Class Initialized
INFO - 2018-04-01 15:42:04 --> Helper loaded: common_helper
INFO - 2018-04-01 15:42:04 --> Database Driver Class Initialized
INFO - 2018-04-01 15:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:42:04 --> Email Class Initialized
INFO - 2018-04-01 15:42:04 --> Controller Class Initialized
INFO - 2018-04-01 15:42:04 --> Helper loaded: form_helper
INFO - 2018-04-01 15:42:04 --> Form Validation Class Initialized
INFO - 2018-04-01 15:42:04 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:42:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:42:04 --> Helper loaded: url_helper
INFO - 2018-04-01 15:42:04 --> Model Class Initialized
INFO - 2018-04-01 15:42:04 --> Model Class Initialized
INFO - 2018-04-01 15:42:04 --> Model Class Initialized
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:12:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:12:04 --> Final output sent to browser
DEBUG - 2018-04-01 19:12:04 --> Total execution time: 0.1440
INFO - 2018-04-01 15:42:54 --> Config Class Initialized
INFO - 2018-04-01 15:42:54 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:42:54 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:42:54 --> Utf8 Class Initialized
INFO - 2018-04-01 15:42:54 --> URI Class Initialized
INFO - 2018-04-01 15:42:54 --> Router Class Initialized
INFO - 2018-04-01 15:42:54 --> Output Class Initialized
INFO - 2018-04-01 15:42:54 --> Security Class Initialized
DEBUG - 2018-04-01 15:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:42:54 --> Input Class Initialized
INFO - 2018-04-01 15:42:54 --> Language Class Initialized
INFO - 2018-04-01 15:42:54 --> Loader Class Initialized
INFO - 2018-04-01 15:42:54 --> Helper loaded: common_helper
INFO - 2018-04-01 15:42:54 --> Database Driver Class Initialized
INFO - 2018-04-01 15:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:42:54 --> Email Class Initialized
INFO - 2018-04-01 15:42:54 --> Controller Class Initialized
INFO - 2018-04-01 15:42:54 --> Helper loaded: form_helper
INFO - 2018-04-01 15:42:54 --> Form Validation Class Initialized
INFO - 2018-04-01 15:42:54 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:42:54 --> Helper loaded: url_helper
INFO - 2018-04-01 15:42:54 --> Model Class Initialized
INFO - 2018-04-01 15:42:54 --> Model Class Initialized
INFO - 2018-04-01 15:42:54 --> Model Class Initialized
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:12:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:12:54 --> Final output sent to browser
DEBUG - 2018-04-01 19:12:54 --> Total execution time: 0.1390
INFO - 2018-04-01 15:50:46 --> Config Class Initialized
INFO - 2018-04-01 15:50:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:50:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:50:46 --> Utf8 Class Initialized
INFO - 2018-04-01 15:50:46 --> URI Class Initialized
INFO - 2018-04-01 15:50:46 --> Router Class Initialized
INFO - 2018-04-01 15:50:46 --> Output Class Initialized
INFO - 2018-04-01 15:50:46 --> Security Class Initialized
DEBUG - 2018-04-01 15:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:50:46 --> Input Class Initialized
INFO - 2018-04-01 15:50:46 --> Language Class Initialized
INFO - 2018-04-01 15:50:46 --> Loader Class Initialized
INFO - 2018-04-01 15:50:46 --> Helper loaded: common_helper
INFO - 2018-04-01 15:50:46 --> Database Driver Class Initialized
INFO - 2018-04-01 15:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:50:46 --> Email Class Initialized
INFO - 2018-04-01 15:50:46 --> Controller Class Initialized
INFO - 2018-04-01 15:50:46 --> Helper loaded: form_helper
INFO - 2018-04-01 15:50:46 --> Form Validation Class Initialized
INFO - 2018-04-01 15:50:46 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:50:46 --> Helper loaded: url_helper
INFO - 2018-04-01 15:50:46 --> Model Class Initialized
INFO - 2018-04-01 15:50:46 --> Model Class Initialized
INFO - 2018-04-01 15:50:46 --> Model Class Initialized
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:20:46 --> Final output sent to browser
DEBUG - 2018-04-01 19:20:46 --> Total execution time: 0.1400
INFO - 2018-04-01 15:51:26 --> Config Class Initialized
INFO - 2018-04-01 15:51:26 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:51:26 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:51:26 --> Utf8 Class Initialized
INFO - 2018-04-01 15:51:26 --> URI Class Initialized
INFO - 2018-04-01 15:51:26 --> Router Class Initialized
INFO - 2018-04-01 15:51:26 --> Output Class Initialized
INFO - 2018-04-01 15:51:26 --> Security Class Initialized
DEBUG - 2018-04-01 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:51:26 --> Input Class Initialized
INFO - 2018-04-01 15:51:26 --> Language Class Initialized
INFO - 2018-04-01 15:51:26 --> Loader Class Initialized
INFO - 2018-04-01 15:51:26 --> Helper loaded: common_helper
INFO - 2018-04-01 15:51:26 --> Database Driver Class Initialized
INFO - 2018-04-01 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:51:26 --> Email Class Initialized
INFO - 2018-04-01 15:51:26 --> Controller Class Initialized
INFO - 2018-04-01 15:51:26 --> Helper loaded: form_helper
INFO - 2018-04-01 15:51:26 --> Form Validation Class Initialized
INFO - 2018-04-01 15:51:26 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:51:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:51:26 --> Helper loaded: url_helper
INFO - 2018-04-01 15:51:26 --> Model Class Initialized
INFO - 2018-04-01 15:51:26 --> Model Class Initialized
INFO - 2018-04-01 15:51:26 --> Model Class Initialized
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:21:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:21:26 --> Final output sent to browser
DEBUG - 2018-04-01 19:21:26 --> Total execution time: 0.1470
INFO - 2018-04-01 15:55:46 --> Config Class Initialized
INFO - 2018-04-01 15:55:46 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:55:46 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:55:46 --> Utf8 Class Initialized
INFO - 2018-04-01 15:55:46 --> URI Class Initialized
INFO - 2018-04-01 15:55:46 --> Router Class Initialized
INFO - 2018-04-01 15:55:46 --> Output Class Initialized
INFO - 2018-04-01 15:55:46 --> Security Class Initialized
DEBUG - 2018-04-01 15:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:55:46 --> Input Class Initialized
INFO - 2018-04-01 15:55:46 --> Language Class Initialized
INFO - 2018-04-01 15:55:46 --> Loader Class Initialized
INFO - 2018-04-01 15:55:46 --> Helper loaded: common_helper
INFO - 2018-04-01 15:55:46 --> Database Driver Class Initialized
INFO - 2018-04-01 15:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:55:46 --> Email Class Initialized
INFO - 2018-04-01 15:55:46 --> Controller Class Initialized
INFO - 2018-04-01 15:55:46 --> Helper loaded: form_helper
INFO - 2018-04-01 15:55:46 --> Form Validation Class Initialized
INFO - 2018-04-01 15:55:46 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:55:46 --> Helper loaded: url_helper
INFO - 2018-04-01 15:55:46 --> Model Class Initialized
INFO - 2018-04-01 15:55:46 --> Model Class Initialized
INFO - 2018-04-01 15:55:46 --> Model Class Initialized
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:25:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:25:46 --> Final output sent to browser
DEBUG - 2018-04-01 19:25:46 --> Total execution time: 0.1410
INFO - 2018-04-01 15:55:59 --> Config Class Initialized
INFO - 2018-04-01 15:55:59 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:55:59 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:55:59 --> Utf8 Class Initialized
INFO - 2018-04-01 15:55:59 --> URI Class Initialized
INFO - 2018-04-01 15:55:59 --> Router Class Initialized
INFO - 2018-04-01 15:55:59 --> Output Class Initialized
INFO - 2018-04-01 15:55:59 --> Security Class Initialized
DEBUG - 2018-04-01 15:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:55:59 --> Input Class Initialized
INFO - 2018-04-01 15:55:59 --> Language Class Initialized
INFO - 2018-04-01 15:55:59 --> Loader Class Initialized
INFO - 2018-04-01 15:55:59 --> Helper loaded: common_helper
INFO - 2018-04-01 15:55:59 --> Database Driver Class Initialized
INFO - 2018-04-01 15:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:55:59 --> Email Class Initialized
INFO - 2018-04-01 15:55:59 --> Controller Class Initialized
INFO - 2018-04-01 15:55:59 --> Helper loaded: form_helper
INFO - 2018-04-01 15:55:59 --> Form Validation Class Initialized
INFO - 2018-04-01 15:55:59 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:55:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:55:59 --> Helper loaded: url_helper
INFO - 2018-04-01 15:55:59 --> Model Class Initialized
INFO - 2018-04-01 15:55:59 --> Model Class Initialized
INFO - 2018-04-01 15:55:59 --> Model Class Initialized
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:25:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:25:59 --> Final output sent to browser
DEBUG - 2018-04-01 19:25:59 --> Total execution time: 0.1490
INFO - 2018-04-01 15:57:07 --> Config Class Initialized
INFO - 2018-04-01 15:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:57:07 --> Utf8 Class Initialized
INFO - 2018-04-01 15:57:07 --> URI Class Initialized
INFO - 2018-04-01 15:57:07 --> Router Class Initialized
INFO - 2018-04-01 15:57:07 --> Output Class Initialized
INFO - 2018-04-01 15:57:07 --> Security Class Initialized
DEBUG - 2018-04-01 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:57:07 --> Input Class Initialized
INFO - 2018-04-01 15:57:07 --> Language Class Initialized
INFO - 2018-04-01 15:57:07 --> Loader Class Initialized
INFO - 2018-04-01 15:57:07 --> Helper loaded: common_helper
INFO - 2018-04-01 15:57:07 --> Database Driver Class Initialized
ERROR - 2018-04-01 15:57:07 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-01 15:57:07 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-01 15:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:57:08 --> Email Class Initialized
INFO - 2018-04-01 15:57:08 --> Controller Class Initialized
INFO - 2018-04-01 15:57:08 --> Helper loaded: form_helper
INFO - 2018-04-01 15:57:08 --> Form Validation Class Initialized
INFO - 2018-04-01 15:57:08 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:57:08 --> Helper loaded: url_helper
INFO - 2018-04-01 15:57:08 --> Model Class Initialized
INFO - 2018-04-01 15:57:08 --> Model Class Initialized
INFO - 2018-04-01 15:57:08 --> Model Class Initialized
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:27:08 --> Final output sent to browser
DEBUG - 2018-04-01 19:27:08 --> Total execution time: 0.1940
INFO - 2018-04-01 15:57:08 --> Config Class Initialized
INFO - 2018-04-01 15:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-01 15:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-01 15:57:08 --> Utf8 Class Initialized
INFO - 2018-04-01 15:57:08 --> URI Class Initialized
INFO - 2018-04-01 15:57:08 --> Router Class Initialized
INFO - 2018-04-01 15:57:08 --> Output Class Initialized
INFO - 2018-04-01 15:57:08 --> Security Class Initialized
DEBUG - 2018-04-01 15:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 15:57:08 --> Input Class Initialized
INFO - 2018-04-01 15:57:08 --> Language Class Initialized
INFO - 2018-04-01 15:57:08 --> Loader Class Initialized
INFO - 2018-04-01 15:57:08 --> Helper loaded: common_helper
INFO - 2018-04-01 15:57:08 --> Database Driver Class Initialized
INFO - 2018-04-01 15:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 15:57:08 --> Email Class Initialized
INFO - 2018-04-01 15:57:08 --> Controller Class Initialized
INFO - 2018-04-01 15:57:08 --> Helper loaded: form_helper
INFO - 2018-04-01 15:57:08 --> Form Validation Class Initialized
INFO - 2018-04-01 15:57:08 --> Helper loaded: email_helper
DEBUG - 2018-04-01 15:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 15:57:08 --> Helper loaded: url_helper
INFO - 2018-04-01 15:57:08 --> Model Class Initialized
INFO - 2018-04-01 15:57:08 --> Model Class Initialized
INFO - 2018-04-01 15:57:08 --> Model Class Initialized
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:27:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:27:08 --> Final output sent to browser
DEBUG - 2018-04-01 19:27:08 --> Total execution time: 0.1380
INFO - 2018-04-01 16:00:47 --> Config Class Initialized
INFO - 2018-04-01 16:00:47 --> Hooks Class Initialized
DEBUG - 2018-04-01 16:00:47 --> UTF-8 Support Enabled
INFO - 2018-04-01 16:00:47 --> Utf8 Class Initialized
INFO - 2018-04-01 16:00:47 --> URI Class Initialized
INFO - 2018-04-01 16:00:47 --> Router Class Initialized
INFO - 2018-04-01 16:00:47 --> Output Class Initialized
INFO - 2018-04-01 16:00:47 --> Security Class Initialized
DEBUG - 2018-04-01 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-01 16:00:47 --> Input Class Initialized
INFO - 2018-04-01 16:00:47 --> Language Class Initialized
INFO - 2018-04-01 16:00:47 --> Loader Class Initialized
INFO - 2018-04-01 16:00:47 --> Helper loaded: common_helper
INFO - 2018-04-01 16:00:47 --> Database Driver Class Initialized
INFO - 2018-04-01 16:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-01 16:00:47 --> Email Class Initialized
INFO - 2018-04-01 16:00:47 --> Controller Class Initialized
INFO - 2018-04-01 16:00:47 --> Helper loaded: form_helper
INFO - 2018-04-01 16:00:47 --> Form Validation Class Initialized
INFO - 2018-04-01 16:00:47 --> Helper loaded: email_helper
DEBUG - 2018-04-01 16:00:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-01 16:00:47 --> Helper loaded: url_helper
INFO - 2018-04-01 16:00:47 --> Model Class Initialized
INFO - 2018-04-01 16:00:47 --> Model Class Initialized
INFO - 2018-04-01 16:00:47 --> Model Class Initialized
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-01 19:30:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-01 19:30:47 --> Final output sent to browser
DEBUG - 2018-04-01 19:30:47 --> Total execution time: 0.1430
