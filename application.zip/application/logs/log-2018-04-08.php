<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2018-04-08 00:06:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 00:06:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 00:06:10 --> Undefined variable: movie_Celebrity
ERROR - 2018-04-08 00:06:10 --> Severity: Notice --> Undefined variable: movie_Celebrity C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 137
INFO - 2018-04-08 00:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:06:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:06:10 --> Final output sent to browser
DEBUG - 2018-04-08 00:06:10 --> Total execution time: 0.1330
DEBUG - 2018-04-08 00:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 00:14:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 00:14:23 --> Query error: Column 'celebrityId' cannot be null - Invalid query: INSERT INTO `news` (`news_title`, `news_content`, `celebrityId`, `news_article_type`, `movieId`, `isActive`, `createdTime`) VALUES ('rangastalamPicks-rangastalam', 'The film features music by Devi Sri Prasad and lyrics by Chandrabose. The DOP of the film has been done by Rathnavelu. Recently, Ram Charan bestowed gifts on the three writers on Sukumar’s writing team because he was that impressed with the work they had done.', NULL, 3, '1', 1, '18-04-08 12:14:23')
INFO - 2018-04-08 00:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:14:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:14:23 --> Final output sent to browser
DEBUG - 2018-04-08 00:14:23 --> Total execution time: 0.0860
INFO - 2018-04-08 00:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:15:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:15:49 --> Final output sent to browser
DEBUG - 2018-04-08 00:15:49 --> Total execution time: 0.1430
DEBUG - 2018-04-08 00:17:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 00:17:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 00:18:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:18:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:18:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:18:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:18:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:18:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:18:58 --> Final output sent to browser
DEBUG - 2018-04-08 00:18:58 --> Total execution time: 0.1360
INFO - 2018-04-08 00:19:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:19:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:19:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:19:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/addMovie.php
INFO - 2018-04-08 00:19:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:19:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:19:02 --> Final output sent to browser
DEBUG - 2018-04-08 00:19:02 --> Total execution time: 0.1330
INFO - 2018-04-08 00:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:19:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:19:11 --> Final output sent to browser
DEBUG - 2018-04-08 00:19:11 --> Total execution time: 0.1710
INFO - 2018-04-08 00:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:19:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:19:24 --> Final output sent to browser
DEBUG - 2018-04-08 00:19:24 --> Total execution time: 0.1420
INFO - 2018-04-08 00:23:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:23:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:23:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:23:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:23:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:23:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:23:28 --> Final output sent to browser
DEBUG - 2018-04-08 00:23:28 --> Total execution time: 0.1910
INFO - 2018-04-08 00:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 00:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:23:39 --> Final output sent to browser
DEBUG - 2018-04-08 00:23:39 --> Total execution time: 0.1330
DEBUG - 2018-04-08 00:25:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 00:25:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-04-08 00:26:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 00:26:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 00:26:08 --> mkdir(): File exists
ERROR - 2018-04-08 00:26:08 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 879
INFO - 2018-04-08 00:26:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 00:26:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:09 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:09 --> Total execution time: 0.1290
INFO - 2018-04-08 00:26:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 00:26:18 --> Undefined variable: ffs
ERROR - 2018-04-08 00:26:18 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 00:26:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 00:26:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:18 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:18 --> Total execution time: 0.1310
INFO - 2018-04-08 00:26:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 00:26:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:21 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:21 --> Total execution time: 0.1300
INFO - 2018-04-08 00:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 00:26:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:24 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:24 --> Total execution time: 0.1280
INFO - 2018-04-08 00:26:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/trillerLink.php
INFO - 2018-04-08 00:26:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:28 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:28 --> Total execution time: 0.1780
INFO - 2018-04-08 00:26:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/fullMovieLink.php
INFO - 2018-04-08 00:26:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:30 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:30 --> Total execution time: 0.1480
INFO - 2018-04-08 00:26:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 00:26:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:33 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:33 --> Total execution time: 0.1410
INFO - 2018-04-08 00:26:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/imagedata.php
INFO - 2018-04-08 00:26:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:36 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:36 --> Total execution time: 0.1220
INFO - 2018-04-08 00:26:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:26:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:26:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:26:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 00:26:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:26:50 --> Final output sent to browser
DEBUG - 2018-04-08 00:26:50 --> Total execution time: 0.1780
INFO - 2018-04-08 00:27:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:27:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:27:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:27:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 00:27:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:27:49 --> Final output sent to browser
DEBUG - 2018-04-08 00:27:49 --> Total execution time: 0.1350
INFO - 2018-04-08 00:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 00:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:28:10 --> Final output sent to browser
DEBUG - 2018-04-08 00:28:10 --> Total execution time: 0.1650
INFO - 2018-04-08 00:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 00:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:28:14 --> Final output sent to browser
DEBUG - 2018-04-08 00:28:14 --> Total execution time: 0.1350
DEBUG - 2018-04-08 00:28:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 00:28:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 00:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 00:28:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:28:43 --> Final output sent to browser
DEBUG - 2018-04-08 00:28:43 --> Total execution time: 0.1290
INFO - 2018-04-08 00:28:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:28:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:28:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:28:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:28:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:28:50 --> Final output sent to browser
DEBUG - 2018-04-08 00:28:50 --> Total execution time: 0.1520
INFO - 2018-04-08 00:30:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:30:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:30:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:30:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:30:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:30:44 --> Final output sent to browser
DEBUG - 2018-04-08 00:30:44 --> Total execution time: 0.1410
INFO - 2018-04-08 00:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:31:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:31:39 --> Final output sent to browser
DEBUG - 2018-04-08 00:31:39 --> Total execution time: 0.1606
INFO - 2018-04-08 00:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:46:16 --> Final output sent to browser
DEBUG - 2018-04-08 00:46:16 --> Total execution time: 0.1430
INFO - 2018-04-08 00:48:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 00:48:19 --> syntax error, unexpected '<'
ERROR - 2018-04-08 00:48:19 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 182
INFO - 2018-04-08 00:50:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:50:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:50:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:50:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:50:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:50:31 --> Final output sent to browser
DEBUG - 2018-04-08 00:50:31 --> Total execution time: 0.1460
INFO - 2018-04-08 00:54:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:54:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:54:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:54:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:54:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:54:02 --> Final output sent to browser
DEBUG - 2018-04-08 00:54:02 --> Total execution time: 0.1490
INFO - 2018-04-08 00:54:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:54:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:54:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:54:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:54:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:54:19 --> Final output sent to browser
DEBUG - 2018-04-08 00:54:19 --> Total execution time: 0.1530
INFO - 2018-04-08 00:54:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:54:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:54:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:54:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:54:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:54:58 --> Final output sent to browser
DEBUG - 2018-04-08 00:54:58 --> Total execution time: 0.1560
INFO - 2018-04-08 00:54:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:54:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:54:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:54:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 00:54:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:54:59 --> Final output sent to browser
DEBUG - 2018-04-08 00:54:59 --> Total execution time: 0.1360
INFO - 2018-04-08 00:55:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:55:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:55:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:55:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 00:55:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:55:02 --> Final output sent to browser
DEBUG - 2018-04-08 00:55:02 --> Total execution time: 0.1340
INFO - 2018-04-08 00:55:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:55:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:55:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:55:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:55:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:55:06 --> Final output sent to browser
DEBUG - 2018-04-08 00:55:06 --> Total execution time: 0.1330
INFO - 2018-04-08 00:57:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:57:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:57:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:57:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:57:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:57:04 --> Final output sent to browser
DEBUG - 2018-04-08 00:57:04 --> Total execution time: 0.1530
INFO - 2018-04-08 00:57:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:57:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:57:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:57:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:57:44 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:57:44 --> Final output sent to browser
DEBUG - 2018-04-08 00:57:44 --> Total execution time: 0.1470
INFO - 2018-04-08 00:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:58:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:58:27 --> Final output sent to browser
DEBUG - 2018-04-08 00:58:27 --> Total execution time: 0.1490
INFO - 2018-04-08 00:58:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 00:58:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 00:58:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 00:58:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 00:58:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 00:58:29 --> Final output sent to browser
DEBUG - 2018-04-08 00:58:29 --> Total execution time: 0.1330
ERROR - 2018-04-08 01:00:09 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:00:09 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:00:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:00:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:00:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:00:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:00:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:00:10 --> Final output sent to browser
DEBUG - 2018-04-08 01:00:10 --> Total execution time: 0.1310
INFO - 2018-04-08 01:03:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:03:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:03:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:03:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:03:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:03:27 --> Final output sent to browser
DEBUG - 2018-04-08 01:03:27 --> Total execution time: 0.1870
ERROR - 2018-04-08 01:03:51 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:03:51 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:03:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:03:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:03:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:03:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:03:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:03:51 --> Final output sent to browser
DEBUG - 2018-04-08 01:03:51 --> Total execution time: 0.1300
INFO - 2018-04-08 01:05:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:05:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:05:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:05:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 01:05:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:05:05 --> Final output sent to browser
DEBUG - 2018-04-08 01:05:05 --> Total execution time: 0.1580
INFO - 2018-04-08 01:05:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:05:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:05:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:05:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:05:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:05:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:05:09 --> Final output sent to browser
DEBUG - 2018-04-08 01:05:09 --> Total execution time: 0.1320
INFO - 2018-04-08 01:07:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:07:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:07:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:07:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:07:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:07:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:07:28 --> Final output sent to browser
DEBUG - 2018-04-08 01:07:28 --> Total execution time: 0.1430
DEBUG - 2018-04-08 01:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:07:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:07:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:07:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:07:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:07:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:07:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:07:40 --> Final output sent to browser
DEBUG - 2018-04-08 01:07:40 --> Total execution time: 0.1360
INFO - 2018-04-08 01:08:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:08:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:08:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:08:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:08:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:08:09 --> Final output sent to browser
DEBUG - 2018-04-08 01:08:09 --> Total execution time: 0.1330
ERROR - 2018-04-08 01:09:22 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:09:22 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:09:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:09:22 --> Final output sent to browser
DEBUG - 2018-04-08 01:09:22 --> Total execution time: 0.1320
INFO - 2018-04-08 01:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:09:30 --> Final output sent to browser
DEBUG - 2018-04-08 01:09:30 --> Total execution time: 0.1350
ERROR - 2018-04-08 01:09:52 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:09:52 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:09:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:09:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:09:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:09:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:09:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:09:52 --> Final output sent to browser
DEBUG - 2018-04-08 01:09:52 --> Total execution time: 0.1320
ERROR - 2018-04-08 01:10:18 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:18 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:18 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:18 --> Total execution time: 0.2160
ERROR - 2018-04-08 01:10:18 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:18 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:18 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:18 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:18 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:18 --> Total execution time: 0.1830
INFO - 2018-04-08 01:10:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:10:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:30 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:30 --> Total execution time: 0.1420
ERROR - 2018-04-08 01:10:36 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:36 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:36 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:36 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:36 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:36 --> Total execution time: 0.1990
ERROR - 2018-04-08 01:10:41 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:41 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:41 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:41 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:41 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:41 --> Total execution time: 0.1790
ERROR - 2018-04-08 01:10:46 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:46 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:46 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:46 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:46 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:46 --> Total execution time: 0.1930
INFO - 2018-04-08 01:10:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:10:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:48 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:48 --> Total execution time: 0.1430
ERROR - 2018-04-08 01:10:49 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:49 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:49 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:49 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:50 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:50 --> Total execution time: 0.1950
ERROR - 2018-04-08 01:10:50 --> Creating default object from empty value
ERROR - 2018-04-08 01:10:50 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 38
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\models\Newsmodel.php 44
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 50
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_title
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_title C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 51
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 62
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 77
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$celebrityId
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$celebrityId C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 99
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 109
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 115
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 132
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 133
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 153
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 224
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 314
ERROR - 2018-04-08 01:10:50 --> Undefined property: stdClass::$news_article_type
ERROR - 2018-04-08 01:10:50 --> Severity: Notice --> Undefined property: stdClass::$news_article_type C:\xampp\htdocs\FlickNews\admin\application\views\News\editNews.php 341
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:50 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:50 --> Total execution time: 0.1740
INFO - 2018-04-08 01:10:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:10:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:51 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:51 --> Total execution time: 0.1400
INFO - 2018-04-08 01:10:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:10:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:10:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:53 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:53 --> Total execution time: 0.1450
INFO - 2018-04-08 01:10:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:10:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:10:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:54 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:54 --> Total execution time: 0.1370
INFO - 2018-04-08 01:10:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:10:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:10:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:10:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:10:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:10:58 --> Final output sent to browser
DEBUG - 2018-04-08 01:10:58 --> Total execution time: 0.1260
INFO - 2018-04-08 01:11:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:11:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:02 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:02 --> Total execution time: 0.1310
INFO - 2018-04-08 01:11:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:11:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:07 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:07 --> Total execution time: 0.1370
INFO - 2018-04-08 01:11:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:11:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:14 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:14 --> Total execution time: 0.1310
INFO - 2018-04-08 01:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:17 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:17 --> Total execution time: 0.1330
INFO - 2018-04-08 01:11:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:11:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:20 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:20 --> Total execution time: 0.1340
INFO - 2018-04-08 01:11:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:11:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:35 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:35 --> Total execution time: 0.1440
INFO - 2018-04-08 01:11:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 01:11:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:37 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:37 --> Total execution time: 0.1450
INFO - 2018-04-08 01:11:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:11:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:41 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:41 --> Total execution time: 0.1350
DEBUG - 2018-04-08 01:11:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:11:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:11:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:11:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:47 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:47 --> Total execution time: 0.1290
INFO - 2018-04-08 01:11:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:11:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:52 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:52 --> Total execution time: 0.1340
INFO - 2018-04-08 01:11:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:11:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:11:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:11:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:11:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:11:57 --> Final output sent to browser
DEBUG - 2018-04-08 01:11:57 --> Total execution time: 0.1450
INFO - 2018-04-08 01:12:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:12:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:12:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:12:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:12:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:12:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:12:00 --> Final output sent to browser
DEBUG - 2018-04-08 01:12:00 --> Total execution time: 0.1360
INFO - 2018-04-08 01:12:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:12:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:12:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:12:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:12:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:12:03 --> Final output sent to browser
DEBUG - 2018-04-08 01:12:03 --> Total execution time: 0.1430
INFO - 2018-04-08 01:12:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:12:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:12:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:12:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:12:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:12:26 --> Final output sent to browser
DEBUG - 2018-04-08 01:12:26 --> Total execution time: 0.1400
ERROR - 2018-04-08 01:12:39 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:12:39 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:12:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:12:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:12:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:12:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:12:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:12:39 --> Final output sent to browser
DEBUG - 2018-04-08 01:12:39 --> Total execution time: 0.1340
INFO - 2018-04-08 01:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:13:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:13:43 --> Final output sent to browser
DEBUG - 2018-04-08 01:13:43 --> Total execution time: 0.1880
INFO - 2018-04-08 01:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:13:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:13:46 --> Final output sent to browser
DEBUG - 2018-04-08 01:13:46 --> Total execution time: 0.1290
INFO - 2018-04-08 01:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:13:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:13:53 --> Final output sent to browser
DEBUG - 2018-04-08 01:13:53 --> Total execution time: 0.1400
ERROR - 2018-04-08 01:14:04 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:14:04 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:04 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:04 --> Total execution time: 0.1340
INFO - 2018-04-08 01:14:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:14:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:10 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:10 --> Total execution time: 0.1580
INFO - 2018-04-08 01:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 01:14:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:25 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:25 --> Total execution time: 0.1570
INFO - 2018-04-08 01:14:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:14:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:28 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:28 --> Total execution time: 0.1290
DEBUG - 2018-04-08 01:14:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:14:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:14:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:14:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:35 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:35 --> Total execution time: 0.1270
INFO - 2018-04-08 01:14:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:14:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:42 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:42 --> Total execution time: 0.1340
ERROR - 2018-04-08 01:14:50 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:14:50 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:14:51 --> Final output sent to browser
DEBUG - 2018-04-08 01:14:51 --> Total execution time: 0.1310
ERROR - 2018-04-08 01:15:17 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:15:17 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:15:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:15:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:15:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:15:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:15:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:15:17 --> Final output sent to browser
DEBUG - 2018-04-08 01:15:17 --> Total execution time: 0.1270
INFO - 2018-04-08 01:16:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:16:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:16:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:16:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:16:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:16:35 --> Final output sent to browser
DEBUG - 2018-04-08 01:16:35 --> Total execution time: 0.1640
INFO - 2018-04-08 01:16:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:16:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:16:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:16:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:16:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:16:37 --> Final output sent to browser
DEBUG - 2018-04-08 01:16:37 --> Total execution time: 0.1430
INFO - 2018-04-08 01:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:16:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:16:38 --> Final output sent to browser
DEBUG - 2018-04-08 01:16:38 --> Total execution time: 0.1380
INFO - 2018-04-08 01:16:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:16:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:16:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:16:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:16:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:16:42 --> Final output sent to browser
DEBUG - 2018-04-08 01:16:42 --> Total execution time: 0.1310
INFO - 2018-04-08 01:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:16:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:16:47 --> Final output sent to browser
DEBUG - 2018-04-08 01:16:47 --> Total execution time: 0.1340
ERROR - 2018-04-08 01:16:53 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:16:53 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:16:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:16:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:16:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:16:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:16:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:16:53 --> Final output sent to browser
DEBUG - 2018-04-08 01:16:53 --> Total execution time: 0.1300
INFO - 2018-04-08 01:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:17:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:00 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:00 --> Total execution time: 0.1310
INFO - 2018-04-08 01:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:04 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:04 --> Total execution time: 0.1350
ERROR - 2018-04-08 01:17:10 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:17:10 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:11 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:11 --> Total execution time: 0.1340
INFO - 2018-04-08 01:17:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 01:17:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:15 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:15 --> Total execution time: 0.1290
INFO - 2018-04-08 01:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:18 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:18 --> Total execution time: 0.1630
DEBUG - 2018-04-08 01:17:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:17:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:17:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:23 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:23 --> Total execution time: 0.1350
INFO - 2018-04-08 01:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:26 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:26 --> Total execution time: 0.1320
ERROR - 2018-04-08 01:17:31 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:17:31 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:17:31 --> Final output sent to browser
DEBUG - 2018-04-08 01:17:31 --> Total execution time: 0.1340
ERROR - 2018-04-08 01:19:51 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:19:51 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:19:51 --> Final output sent to browser
DEBUG - 2018-04-08 01:19:51 --> Total execution time: 0.1270
INFO - 2018-04-08 01:20:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:20:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:20:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:20:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:20:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:20:18 --> Final output sent to browser
DEBUG - 2018-04-08 01:20:18 --> Total execution time: 0.1310
INFO - 2018-04-08 01:20:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:20:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:20:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:20:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:20:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:20:21 --> Final output sent to browser
DEBUG - 2018-04-08 01:20:21 --> Total execution time: 0.1390
ERROR - 2018-04-08 01:20:31 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:20:31 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:20:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:20:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:20:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:20:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:20:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:20:31 --> Final output sent to browser
DEBUG - 2018-04-08 01:20:31 --> Total execution time: 0.1340
INFO - 2018-04-08 01:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:20:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:20:50 --> Final output sent to browser
DEBUG - 2018-04-08 01:20:50 --> Total execution time: 0.1330
INFO - 2018-04-08 01:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:20:53 --> Final output sent to browser
DEBUG - 2018-04-08 01:20:53 --> Total execution time: 0.1720
ERROR - 2018-04-08 01:21:01 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:21:01 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:21:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:21:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:21:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:21:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:21:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:21:01 --> Final output sent to browser
DEBUG - 2018-04-08 01:21:01 --> Total execution time: 0.1310
INFO - 2018-04-08 01:23:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:23:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:23:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:23:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:23:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:23:34 --> Final output sent to browser
DEBUG - 2018-04-08 01:23:34 --> Total execution time: 0.1390
INFO - 2018-04-08 01:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 01:23:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:23:39 --> Final output sent to browser
DEBUG - 2018-04-08 01:23:39 --> Total execution time: 0.1460
INFO - 2018-04-08 01:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 01:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:23:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:23:42 --> Final output sent to browser
DEBUG - 2018-04-08 01:23:42 --> Total execution time: 0.1360
DEBUG - 2018-04-08 01:23:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:23:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:23:48 --> Final output sent to browser
DEBUG - 2018-04-08 01:23:48 --> Total execution time: 0.1290
INFO - 2018-04-08 01:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 01:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:23:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:23:52 --> Final output sent to browser
DEBUG - 2018-04-08 01:23:52 --> Total execution time: 0.1360
ERROR - 2018-04-08 01:23:59 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 01:23:59 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 01:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:24:00 --> Final output sent to browser
DEBUG - 2018-04-08 01:24:00 --> Total execution time: 0.1300
INFO - 2018-04-08 01:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:25:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:19 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:19 --> Total execution time: 0.1260
INFO - 2018-04-08 01:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:25:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:23 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:23 --> Total execution time: 0.1250
INFO - 2018-04-08 01:25:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:25:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:27 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:27 --> Total execution time: 0.1690
INFO - 2018-04-08 01:25:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:25:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:36 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:36 --> Total execution time: 0.1220
INFO - 2018-04-08 01:25:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:25:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:45 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:45 --> Total execution time: 0.1360
INFO - 2018-04-08 01:25:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:25:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:49 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:49 --> Total execution time: 0.1240
INFO - 2018-04-08 01:25:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:25:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:54 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:54 --> Total execution time: 0.1660
INFO - 2018-04-08 01:25:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:25:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:55 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:55 --> Total execution time: 0.1340
INFO - 2018-04-08 01:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:25:57 --> Final output sent to browser
DEBUG - 2018-04-08 01:25:57 --> Total execution time: 0.1700
INFO - 2018-04-08 01:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:26:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:26:02 --> Final output sent to browser
DEBUG - 2018-04-08 01:26:02 --> Total execution time: 0.1550
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:26:08 --> Final output sent to browser
DEBUG - 2018-04-08 01:26:08 --> Total execution time: 0.1300
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:26:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:26:08 --> Final output sent to browser
DEBUG - 2018-04-08 01:26:08 --> Total execution time: 0.1220
INFO - 2018-04-08 01:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:26:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:26:11 --> Final output sent to browser
DEBUG - 2018-04-08 01:26:11 --> Total execution time: 0.1300
INFO - 2018-04-08 01:27:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:27:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:10 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:10 --> Total execution time: 0.1280
INFO - 2018-04-08 01:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:27:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:13 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:13 --> Total execution time: 0.1270
INFO - 2018-04-08 01:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:27:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:15 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:15 --> Total execution time: 0.1240
INFO - 2018-04-08 01:27:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:27:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:22 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:22 --> Total execution time: 0.1280
INFO - 2018-04-08 01:27:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:27:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:25 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:25 --> Total execution time: 0.1360
INFO - 2018-04-08 01:27:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:27:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:28 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:28 --> Total execution time: 0.1260
INFO - 2018-04-08 01:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:27:32 --> Final output sent to browser
DEBUG - 2018-04-08 01:27:32 --> Total execution time: 0.1260
INFO - 2018-04-08 01:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:28:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:02 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:02 --> Total execution time: 0.1280
INFO - 2018-04-08 01:28:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:28:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:05 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:05 --> Total execution time: 0.1220
INFO - 2018-04-08 01:28:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:28:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:08 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:08 --> Total execution time: 0.1260
INFO - 2018-04-08 01:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 01:28:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:10 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:10 --> Total execution time: 0.1240
INFO - 2018-04-08 01:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:28:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:14 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:14 --> Total execution time: 0.1230
INFO - 2018-04-08 01:28:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/video.php
INFO - 2018-04-08 01:28:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:21 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:21 --> Total execution time: 0.1490
INFO - 2018-04-08 01:28:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 01:28:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:25 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:25 --> Total execution time: 0.1430
INFO - 2018-04-08 01:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:28:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:28 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:28 --> Total execution time: 0.1540
INFO - 2018-04-08 01:28:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Celebrity/celebrity.php
INFO - 2018-04-08 01:28:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:35 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:35 --> Total execution time: 0.1260
INFO - 2018-04-08 01:28:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:28:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:28:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Celebrity/addcelebrity.php
INFO - 2018-04-08 01:28:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:28:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:28:39 --> Final output sent to browser
DEBUG - 2018-04-08 01:28:39 --> Total execution time: 0.1180
DEBUG - 2018-04-08 01:44:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:44:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:44:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:44:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:44:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:44:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Celebrity/celebrity.php
INFO - 2018-04-08 01:44:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:44:52 --> Final output sent to browser
DEBUG - 2018-04-08 01:44:52 --> Total execution time: 0.1250
INFO - 2018-04-08 01:45:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:45:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:45:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:45:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:45:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:45:09 --> Final output sent to browser
DEBUG - 2018-04-08 01:45:09 --> Total execution time: 0.1650
INFO - 2018-04-08 01:45:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:45:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:45:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:45:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addNews.php
INFO - 2018-04-08 01:45:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:45:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:45:12 --> Final output sent to browser
DEBUG - 2018-04-08 01:45:12 --> Total execution time: 0.1720
DEBUG - 2018-04-08 01:48:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 01:48:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 01:48:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:48:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:48:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:48:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:48:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:48:21 --> Final output sent to browser
DEBUG - 2018-04-08 01:48:21 --> Total execution time: 0.1320
INFO - 2018-04-08 01:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 01:48:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:48:48 --> Final output sent to browser
DEBUG - 2018-04-08 01:48:48 --> Total execution time: 0.1470
INFO - 2018-04-08 01:48:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:48:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:48:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:48:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 01:48:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:48:55 --> Final output sent to browser
DEBUG - 2018-04-08 01:48:55 --> Total execution time: 0.1360
INFO - 2018-04-08 01:49:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 01:49:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 01:49:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:49:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/addMovie.php
INFO - 2018-04-08 01:49:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 01:49:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 01:49:06 --> Final output sent to browser
DEBUG - 2018-04-08 01:49:06 --> Total execution time: 0.1350
DEBUG - 2018-04-08 02:07:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 02:07:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 02:07:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:07:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:07:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:07:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 02:07:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:07:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:07:04 --> Final output sent to browser
DEBUG - 2018-04-08 02:07:04 --> Total execution time: 0.1280
DEBUG - 2018-04-08 02:11:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 02:11:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 02:11:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:11:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:11:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:11:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 02:11:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:11:56 --> Final output sent to browser
DEBUG - 2018-04-08 02:11:56 --> Total execution time: 0.1290
INFO - 2018-04-08 02:12:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:12:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:12:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:12:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:12:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:12:09 --> Final output sent to browser
DEBUG - 2018-04-08 02:12:09 --> Total execution time: 0.1660
INFO - 2018-04-08 02:15:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:15:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:15:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:15:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:15:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:15:40 --> Final output sent to browser
DEBUG - 2018-04-08 02:15:40 --> Total execution time: 0.1480
INFO - 2018-04-08 02:15:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:15:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:15:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:15:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:15:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:15:47 --> Final output sent to browser
DEBUG - 2018-04-08 02:15:47 --> Total execution time: 0.1490
INFO - 2018-04-08 02:15:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:15:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:15:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:15:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 02:15:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:15:53 --> Final output sent to browser
DEBUG - 2018-04-08 02:15:53 --> Total execution time: 0.1610
INFO - 2018-04-08 02:16:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:16:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:16:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:16:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Celebrity/celebrity.php
INFO - 2018-04-08 02:16:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:16:01 --> Final output sent to browser
DEBUG - 2018-04-08 02:16:01 --> Total execution time: 0.1570
INFO - 2018-04-08 02:16:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:16:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:16:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:16:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:16:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:16:39 --> Final output sent to browser
DEBUG - 2018-04-08 02:16:39 --> Total execution time: 0.1620
INFO - 2018-04-08 02:16:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:16:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:16:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:16:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:16:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:16:46 --> Final output sent to browser
DEBUG - 2018-04-08 02:16:46 --> Total execution time: 0.1540
INFO - 2018-04-08 02:16:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:16:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:16:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:16:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 02:16:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:16:50 --> Final output sent to browser
DEBUG - 2018-04-08 02:16:50 --> Total execution time: 0.1280
INFO - 2018-04-08 02:16:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:16:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:16:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:16:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Celebrity/celebrity.php
INFO - 2018-04-08 02:16:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:16:55 --> Final output sent to browser
DEBUG - 2018-04-08 02:16:55 --> Total execution time: 0.1400
INFO - 2018-04-08 02:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 02:17:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:31 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:31 --> Total execution time: 0.1280
INFO - 2018-04-08 02:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 02:17:34 --> Undefined variable: ffs
ERROR - 2018-04-08 02:17:34 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 02:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 02:17:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:34 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:34 --> Total execution time: 0.1340
INFO - 2018-04-08 02:17:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 02:17:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:38 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:38 --> Total execution time: 0.1270
INFO - 2018-04-08 02:17:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 02:17:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:42 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:42 --> Total execution time: 0.1250
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/trillerLink.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:49 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:49 --> Total execution time: 0.3530
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/trillerLink.php
INFO - 2018-04-08 02:17:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:49 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:49 --> Total execution time: 0.1400
INFO - 2018-04-08 02:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/fullMovieLink.php
INFO - 2018-04-08 02:17:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:52 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:52 --> Total execution time: 0.1420
INFO - 2018-04-08 02:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/trillerLink.php
INFO - 2018-04-08 02:17:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:55 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:55 --> Total execution time: 0.1470
INFO - 2018-04-08 02:17:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 02:17:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:57 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:57 --> Total execution time: 0.1380
INFO - 2018-04-08 02:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 02:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:17:59 --> Final output sent to browser
DEBUG - 2018-04-08 02:17:59 --> Total execution time: 0.1040
INFO - 2018-04-08 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/imagedata.php
INFO - 2018-04-08 02:18:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:18:02 --> Final output sent to browser
DEBUG - 2018-04-08 02:18:02 --> Total execution time: 0.1310
INFO - 2018-04-08 02:18:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:18:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:18:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:18:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:18:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:18:28 --> Final output sent to browser
DEBUG - 2018-04-08 02:18:28 --> Total execution time: 0.1460
INFO - 2018-04-08 02:18:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:18:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:18:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:18:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:18:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:18:32 --> Final output sent to browser
DEBUG - 2018-04-08 02:18:32 --> Total execution time: 0.1310
INFO - 2018-04-08 02:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:19:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:19:36 --> Final output sent to browser
DEBUG - 2018-04-08 02:19:36 --> Total execution time: 0.1260
INFO - 2018-04-08 02:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:19:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:19:39 --> Final output sent to browser
DEBUG - 2018-04-08 02:19:39 --> Total execution time: 0.1370
INFO - 2018-04-08 02:19:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:19:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:19:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:19:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:19:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:19:42 --> Final output sent to browser
DEBUG - 2018-04-08 02:19:42 --> Total execution time: 0.1390
INFO - 2018-04-08 02:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:19:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:19:51 --> Final output sent to browser
DEBUG - 2018-04-08 02:19:51 --> Total execution time: 0.1260
INFO - 2018-04-08 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:19:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:19:57 --> Final output sent to browser
DEBUG - 2018-04-08 02:19:57 --> Total execution time: 0.1360
INFO - 2018-04-08 02:20:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:20:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:20:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:20:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:20:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:20:00 --> Final output sent to browser
DEBUG - 2018-04-08 02:20:00 --> Total execution time: 0.1380
INFO - 2018-04-08 02:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:20:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:20:33 --> Final output sent to browser
DEBUG - 2018-04-08 02:20:33 --> Total execution time: 0.1380
INFO - 2018-04-08 02:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:20:36 --> Final output sent to browser
DEBUG - 2018-04-08 02:20:36 --> Total execution time: 0.1260
INFO - 2018-04-08 02:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:20:46 --> Final output sent to browser
DEBUG - 2018-04-08 02:20:46 --> Total execution time: 0.1300
INFO - 2018-04-08 02:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:20:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:20:53 --> Final output sent to browser
DEBUG - 2018-04-08 02:20:53 --> Total execution time: 0.1370
INFO - 2018-04-08 02:20:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:20:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:20:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:20:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:20:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:20:56 --> Final output sent to browser
DEBUG - 2018-04-08 02:20:56 --> Total execution time: 0.1300
INFO - 2018-04-08 02:23:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:23:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:23:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:23:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:23:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:23:27 --> Final output sent to browser
DEBUG - 2018-04-08 02:23:27 --> Total execution time: 0.1460
INFO - 2018-04-08 02:23:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 02:23:30 --> syntax error, unexpected end of file
ERROR - 2018-04-08 02:23:30 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\FlickNews\admin\application\views\galery\imagedata.php 97
INFO - 2018-04-08 02:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:23:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:23:48 --> Final output sent to browser
DEBUG - 2018-04-08 02:23:48 --> Total execution time: 0.1320
INFO - 2018-04-08 02:23:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:23:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:23:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:23:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 02:23:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:23:53 --> Final output sent to browser
DEBUG - 2018-04-08 02:23:53 --> Total execution time: 0.1360
INFO - 2018-04-08 02:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:23:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:23:57 --> Final output sent to browser
DEBUG - 2018-04-08 02:23:57 --> Total execution time: 0.1410
INFO - 2018-04-08 02:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/imagedata.php
INFO - 2018-04-08 02:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:00 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:00 --> Total execution time: 0.1240
INFO - 2018-04-08 02:24:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\galery/image.php
INFO - 2018-04-08 02:24:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:03 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:03 --> Total execution time: 0.1220
INFO - 2018-04-08 02:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 02:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:18 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:18 --> Total execution time: 0.1300
INFO - 2018-04-08 02:24:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 02:24:21 --> Undefined variable: ffs
ERROR - 2018-04-08 02:24:21 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 02:24:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 02:24:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:21 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:21 --> Total execution time: 0.1430
INFO - 2018-04-08 02:24:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 02:24:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:25 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:25 --> Total execution time: 0.1270
INFO - 2018-04-08 02:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/imagedata.php
INFO - 2018-04-08 02:24:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:29 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:29 --> Total execution time: 0.1410
INFO - 2018-04-08 02:24:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 02:24:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:33 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:33 --> Total execution time: 0.1260
INFO - 2018-04-08 02:24:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/imagedata.php
INFO - 2018-04-08 02:24:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:42 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:42 --> Total execution time: 0.1390
INFO - 2018-04-08 02:24:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 02:24:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:47 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:47 --> Total execution time: 0.1290
INFO - 2018-04-08 02:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 02:24:52 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:24:52 --> Final output sent to browser
DEBUG - 2018-04-08 02:24:52 --> Total execution time: 0.1260
INFO - 2018-04-08 02:25:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 02:25:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 02:25:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 02:25:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 02:25:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 02:25:03 --> Final output sent to browser
DEBUG - 2018-04-08 02:25:03 --> Total execution time: 0.2440
INFO - 2018-04-08 11:35:58 --> Config Class Initialized
INFO - 2018-04-08 11:35:58 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:35:58 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:35:58 --> Utf8 Class Initialized
INFO - 2018-04-08 11:35:58 --> URI Class Initialized
DEBUG - 2018-04-08 11:35:58 --> No URI present. Default controller set.
INFO - 2018-04-08 11:35:58 --> Router Class Initialized
INFO - 2018-04-08 11:35:59 --> Output Class Initialized
INFO - 2018-04-08 11:35:59 --> Security Class Initialized
DEBUG - 2018-04-08 11:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:35:59 --> Input Class Initialized
INFO - 2018-04-08 11:35:59 --> Language Class Initialized
INFO - 2018-04-08 11:35:59 --> Loader Class Initialized
INFO - 2018-04-08 11:35:59 --> Helper loaded: common_helper
INFO - 2018-04-08 11:35:59 --> Database Driver Class Initialized
ERROR - 2018-04-08 11:35:59 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-08 11:35:59 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-08 11:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:35:59 --> Email Class Initialized
INFO - 2018-04-08 11:35:59 --> Controller Class Initialized
INFO - 2018-04-08 11:35:59 --> Helper loaded: form_helper
INFO - 2018-04-08 11:35:59 --> Form Validation Class Initialized
INFO - 2018-04-08 11:35:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:35:59 --> Helper loaded: url_helper
INFO - 2018-04-08 11:35:59 --> Model Class Initialized
INFO - 2018-04-08 11:35:59 --> Model Class Initialized
DEBUG - 2018-04-08 11:35:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:35:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:35:59 --> Config Class Initialized
INFO - 2018-04-08 11:35:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:35:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:35:59 --> Utf8 Class Initialized
INFO - 2018-04-08 11:35:59 --> URI Class Initialized
INFO - 2018-04-08 11:35:59 --> Router Class Initialized
INFO - 2018-04-08 11:35:59 --> Output Class Initialized
INFO - 2018-04-08 11:35:59 --> Security Class Initialized
DEBUG - 2018-04-08 11:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:35:59 --> Input Class Initialized
INFO - 2018-04-08 11:35:59 --> Language Class Initialized
INFO - 2018-04-08 11:35:59 --> Loader Class Initialized
INFO - 2018-04-08 11:35:59 --> Helper loaded: common_helper
INFO - 2018-04-08 11:35:59 --> Database Driver Class Initialized
INFO - 2018-04-08 11:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:35:59 --> Email Class Initialized
INFO - 2018-04-08 11:35:59 --> Controller Class Initialized
INFO - 2018-04-08 11:35:59 --> Helper loaded: form_helper
INFO - 2018-04-08 11:35:59 --> Form Validation Class Initialized
INFO - 2018-04-08 11:35:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:35:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:35:59 --> Helper loaded: url_helper
INFO - 2018-04-08 11:35:59 --> Model Class Initialized
INFO - 2018-04-08 11:35:59 --> Model Class Initialized
INFO - 2018-04-08 11:35:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:35:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:35:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:35:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:35:59 --> Final output sent to browser
DEBUG - 2018-04-08 11:35:59 --> Total execution time: 0.1310
INFO - 2018-04-08 11:36:03 --> Config Class Initialized
INFO - 2018-04-08 11:36:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:36:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:36:03 --> Utf8 Class Initialized
INFO - 2018-04-08 11:36:03 --> URI Class Initialized
INFO - 2018-04-08 11:36:03 --> Router Class Initialized
INFO - 2018-04-08 11:36:03 --> Output Class Initialized
INFO - 2018-04-08 11:36:03 --> Security Class Initialized
DEBUG - 2018-04-08 11:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:36:03 --> Input Class Initialized
INFO - 2018-04-08 11:36:03 --> Language Class Initialized
INFO - 2018-04-08 11:36:03 --> Loader Class Initialized
INFO - 2018-04-08 11:36:03 --> Helper loaded: common_helper
INFO - 2018-04-08 11:36:03 --> Database Driver Class Initialized
INFO - 2018-04-08 11:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:36:03 --> Email Class Initialized
INFO - 2018-04-08 11:36:03 --> Controller Class Initialized
INFO - 2018-04-08 11:36:03 --> Helper loaded: form_helper
INFO - 2018-04-08 11:36:03 --> Form Validation Class Initialized
INFO - 2018-04-08 11:36:03 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:36:03 --> Helper loaded: url_helper
INFO - 2018-04-08 11:36:03 --> Model Class Initialized
INFO - 2018-04-08 11:36:03 --> Model Class Initialized
INFO - 2018-04-08 11:36:03 --> Model Class Initialized
INFO - 2018-04-08 11:36:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:36:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:36:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:36:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:36:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:36:03 --> Final output sent to browser
DEBUG - 2018-04-08 11:36:03 --> Total execution time: 0.2410
INFO - 2018-04-08 11:36:38 --> Config Class Initialized
INFO - 2018-04-08 11:36:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:36:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:36:38 --> Utf8 Class Initialized
INFO - 2018-04-08 11:36:38 --> URI Class Initialized
INFO - 2018-04-08 11:36:38 --> Router Class Initialized
INFO - 2018-04-08 11:36:38 --> Output Class Initialized
INFO - 2018-04-08 11:36:38 --> Security Class Initialized
DEBUG - 2018-04-08 11:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:36:38 --> Input Class Initialized
INFO - 2018-04-08 11:36:38 --> Language Class Initialized
INFO - 2018-04-08 11:36:38 --> Loader Class Initialized
INFO - 2018-04-08 11:36:38 --> Helper loaded: common_helper
INFO - 2018-04-08 11:36:38 --> Database Driver Class Initialized
INFO - 2018-04-08 11:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:36:38 --> Email Class Initialized
INFO - 2018-04-08 11:36:38 --> Controller Class Initialized
INFO - 2018-04-08 11:36:38 --> Helper loaded: form_helper
INFO - 2018-04-08 11:36:38 --> Form Validation Class Initialized
INFO - 2018-04-08 11:36:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:36:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:36:38 --> Helper loaded: url_helper
INFO - 2018-04-08 11:36:38 --> Model Class Initialized
INFO - 2018-04-08 11:36:38 --> Model Class Initialized
INFO - 2018-04-08 11:36:38 --> Model Class Initialized
INFO - 2018-04-08 11:36:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:36:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:36:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 11:36:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:36:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:36:38 --> Final output sent to browser
DEBUG - 2018-04-08 11:36:38 --> Total execution time: 0.1260
INFO - 2018-04-08 11:37:33 --> Config Class Initialized
INFO - 2018-04-08 11:37:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:37:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:37:33 --> Utf8 Class Initialized
INFO - 2018-04-08 11:37:33 --> URI Class Initialized
INFO - 2018-04-08 11:37:33 --> Router Class Initialized
INFO - 2018-04-08 11:37:33 --> Output Class Initialized
INFO - 2018-04-08 11:37:33 --> Security Class Initialized
DEBUG - 2018-04-08 11:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:37:33 --> Input Class Initialized
INFO - 2018-04-08 11:37:33 --> Language Class Initialized
INFO - 2018-04-08 11:37:33 --> Loader Class Initialized
INFO - 2018-04-08 11:37:33 --> Helper loaded: common_helper
INFO - 2018-04-08 11:37:33 --> Database Driver Class Initialized
INFO - 2018-04-08 11:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:37:33 --> Email Class Initialized
INFO - 2018-04-08 11:37:33 --> Controller Class Initialized
INFO - 2018-04-08 11:37:33 --> Helper loaded: form_helper
INFO - 2018-04-08 11:37:33 --> Form Validation Class Initialized
INFO - 2018-04-08 11:37:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:37:33 --> Helper loaded: url_helper
INFO - 2018-04-08 11:37:33 --> Model Class Initialized
INFO - 2018-04-08 11:37:33 --> Model Class Initialized
INFO - 2018-04-08 11:37:33 --> Model Class Initialized
DEBUG - 2018-04-08 11:37:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:37:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:37:33 --> Config Class Initialized
INFO - 2018-04-08 11:37:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:37:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:37:33 --> Utf8 Class Initialized
INFO - 2018-04-08 11:37:33 --> URI Class Initialized
INFO - 2018-04-08 11:37:33 --> Router Class Initialized
INFO - 2018-04-08 11:37:33 --> Output Class Initialized
INFO - 2018-04-08 11:37:33 --> Security Class Initialized
DEBUG - 2018-04-08 11:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:37:33 --> Input Class Initialized
INFO - 2018-04-08 11:37:33 --> Language Class Initialized
INFO - 2018-04-08 11:37:33 --> Loader Class Initialized
INFO - 2018-04-08 11:37:33 --> Helper loaded: common_helper
INFO - 2018-04-08 11:37:33 --> Database Driver Class Initialized
INFO - 2018-04-08 11:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:37:33 --> Email Class Initialized
INFO - 2018-04-08 11:37:33 --> Controller Class Initialized
INFO - 2018-04-08 11:37:33 --> Helper loaded: form_helper
INFO - 2018-04-08 11:37:33 --> Form Validation Class Initialized
INFO - 2018-04-08 11:37:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:37:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:37:33 --> Helper loaded: url_helper
INFO - 2018-04-08 11:37:33 --> Model Class Initialized
INFO - 2018-04-08 11:37:33 --> Model Class Initialized
INFO - 2018-04-08 11:37:33 --> Model Class Initialized
INFO - 2018-04-08 11:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:37:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:37:33 --> Final output sent to browser
DEBUG - 2018-04-08 11:37:33 --> Total execution time: 0.1275
INFO - 2018-04-08 11:38:08 --> Config Class Initialized
INFO - 2018-04-08 11:38:08 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:38:08 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:38:08 --> Utf8 Class Initialized
INFO - 2018-04-08 11:38:08 --> URI Class Initialized
INFO - 2018-04-08 11:38:08 --> Router Class Initialized
INFO - 2018-04-08 11:38:08 --> Output Class Initialized
INFO - 2018-04-08 11:38:08 --> Security Class Initialized
DEBUG - 2018-04-08 11:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:38:08 --> Input Class Initialized
INFO - 2018-04-08 11:38:08 --> Language Class Initialized
INFO - 2018-04-08 11:38:08 --> Loader Class Initialized
INFO - 2018-04-08 11:38:08 --> Helper loaded: common_helper
INFO - 2018-04-08 11:38:08 --> Database Driver Class Initialized
INFO - 2018-04-08 11:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:38:08 --> Email Class Initialized
INFO - 2018-04-08 11:38:08 --> Controller Class Initialized
INFO - 2018-04-08 11:38:08 --> Helper loaded: form_helper
INFO - 2018-04-08 11:38:08 --> Form Validation Class Initialized
INFO - 2018-04-08 11:38:08 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:38:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:38:08 --> Helper loaded: url_helper
INFO - 2018-04-08 11:38:08 --> Model Class Initialized
INFO - 2018-04-08 11:38:08 --> Model Class Initialized
INFO - 2018-04-08 11:38:08 --> Model Class Initialized
INFO - 2018-04-08 11:38:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:38:08 --> Final output sent to browser
DEBUG - 2018-04-08 11:38:08 --> Total execution time: 0.1350
INFO - 2018-04-08 11:38:11 --> Config Class Initialized
INFO - 2018-04-08 11:38:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:38:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:38:11 --> Utf8 Class Initialized
INFO - 2018-04-08 11:38:11 --> URI Class Initialized
INFO - 2018-04-08 11:38:11 --> Router Class Initialized
INFO - 2018-04-08 11:38:11 --> Output Class Initialized
INFO - 2018-04-08 11:38:11 --> Security Class Initialized
DEBUG - 2018-04-08 11:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:38:11 --> Input Class Initialized
INFO - 2018-04-08 11:38:11 --> Language Class Initialized
INFO - 2018-04-08 11:38:11 --> Loader Class Initialized
INFO - 2018-04-08 11:38:11 --> Helper loaded: common_helper
INFO - 2018-04-08 11:38:11 --> Database Driver Class Initialized
INFO - 2018-04-08 11:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:38:11 --> Email Class Initialized
INFO - 2018-04-08 11:38:11 --> Controller Class Initialized
INFO - 2018-04-08 11:38:11 --> Helper loaded: form_helper
INFO - 2018-04-08 11:38:11 --> Form Validation Class Initialized
INFO - 2018-04-08 11:38:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:38:11 --> Helper loaded: url_helper
INFO - 2018-04-08 11:38:11 --> Model Class Initialized
INFO - 2018-04-08 11:38:11 --> Model Class Initialized
INFO - 2018-04-08 11:38:11 --> Model Class Initialized
DEBUG - 2018-04-08 11:38:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:38:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:38:11 --> Config Class Initialized
INFO - 2018-04-08 11:38:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:38:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:38:11 --> Utf8 Class Initialized
INFO - 2018-04-08 11:38:11 --> URI Class Initialized
INFO - 2018-04-08 11:38:11 --> Router Class Initialized
INFO - 2018-04-08 11:38:11 --> Output Class Initialized
INFO - 2018-04-08 11:38:11 --> Security Class Initialized
DEBUG - 2018-04-08 11:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:38:11 --> Input Class Initialized
INFO - 2018-04-08 11:38:11 --> Language Class Initialized
INFO - 2018-04-08 11:38:11 --> Loader Class Initialized
INFO - 2018-04-08 11:38:11 --> Helper loaded: common_helper
INFO - 2018-04-08 11:38:11 --> Database Driver Class Initialized
INFO - 2018-04-08 11:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:38:11 --> Email Class Initialized
INFO - 2018-04-08 11:38:11 --> Controller Class Initialized
INFO - 2018-04-08 11:38:11 --> Helper loaded: form_helper
INFO - 2018-04-08 11:38:11 --> Form Validation Class Initialized
INFO - 2018-04-08 11:38:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:38:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:38:11 --> Helper loaded: url_helper
INFO - 2018-04-08 11:38:11 --> Model Class Initialized
INFO - 2018-04-08 11:38:11 --> Model Class Initialized
INFO - 2018-04-08 11:38:11 --> Model Class Initialized
INFO - 2018-04-08 11:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:38:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:38:11 --> Final output sent to browser
DEBUG - 2018-04-08 11:38:11 --> Total execution time: 0.1320
INFO - 2018-04-08 11:38:15 --> Config Class Initialized
INFO - 2018-04-08 11:38:15 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:38:15 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:38:15 --> Utf8 Class Initialized
INFO - 2018-04-08 11:38:15 --> URI Class Initialized
INFO - 2018-04-08 11:38:15 --> Router Class Initialized
INFO - 2018-04-08 11:38:15 --> Output Class Initialized
INFO - 2018-04-08 11:38:15 --> Security Class Initialized
DEBUG - 2018-04-08 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:38:15 --> Input Class Initialized
INFO - 2018-04-08 11:38:15 --> Language Class Initialized
INFO - 2018-04-08 11:38:15 --> Loader Class Initialized
INFO - 2018-04-08 11:38:15 --> Helper loaded: common_helper
INFO - 2018-04-08 11:38:15 --> Database Driver Class Initialized
INFO - 2018-04-08 11:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:38:15 --> Email Class Initialized
INFO - 2018-04-08 11:38:15 --> Controller Class Initialized
INFO - 2018-04-08 11:38:15 --> Helper loaded: form_helper
INFO - 2018-04-08 11:38:15 --> Form Validation Class Initialized
INFO - 2018-04-08 11:38:15 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:38:15 --> Helper loaded: url_helper
INFO - 2018-04-08 11:38:15 --> Model Class Initialized
INFO - 2018-04-08 11:38:15 --> Model Class Initialized
INFO - 2018-04-08 11:38:15 --> Model Class Initialized
INFO - 2018-04-08 11:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:38:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:38:15 --> Final output sent to browser
DEBUG - 2018-04-08 11:38:15 --> Total execution time: 0.1350
INFO - 2018-04-08 11:42:21 --> Config Class Initialized
INFO - 2018-04-08 11:42:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:42:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:42:21 --> Utf8 Class Initialized
INFO - 2018-04-08 11:42:21 --> URI Class Initialized
INFO - 2018-04-08 11:42:21 --> Router Class Initialized
INFO - 2018-04-08 11:42:21 --> Output Class Initialized
INFO - 2018-04-08 11:42:21 --> Security Class Initialized
DEBUG - 2018-04-08 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:42:21 --> Input Class Initialized
INFO - 2018-04-08 11:42:21 --> Language Class Initialized
INFO - 2018-04-08 11:42:21 --> Loader Class Initialized
INFO - 2018-04-08 11:42:21 --> Helper loaded: common_helper
INFO - 2018-04-08 11:42:21 --> Database Driver Class Initialized
ERROR - 2018-04-08 11:42:21 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-08 11:42:21 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-08 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:42:21 --> Email Class Initialized
INFO - 2018-04-08 11:42:21 --> Controller Class Initialized
INFO - 2018-04-08 11:42:21 --> Helper loaded: form_helper
INFO - 2018-04-08 11:42:21 --> Form Validation Class Initialized
INFO - 2018-04-08 11:42:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:42:21 --> Helper loaded: url_helper
INFO - 2018-04-08 11:42:21 --> Model Class Initialized
INFO - 2018-04-08 11:42:21 --> Model Class Initialized
INFO - 2018-04-08 11:42:21 --> Model Class Initialized
ERROR - 2018-04-08 11:42:21 --> Undefined variable: 2
ERROR - 2018-04-08 11:42:21 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:42:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:42:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:42:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:42:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:42:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:42:21 --> Final output sent to browser
DEBUG - 2018-04-08 11:42:21 --> Total execution time: 0.1570
INFO - 2018-04-08 11:42:21 --> Config Class Initialized
INFO - 2018-04-08 11:42:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:42:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:42:21 --> Utf8 Class Initialized
INFO - 2018-04-08 11:42:21 --> URI Class Initialized
INFO - 2018-04-08 11:42:21 --> Router Class Initialized
INFO - 2018-04-08 11:42:21 --> Output Class Initialized
INFO - 2018-04-08 11:42:21 --> Security Class Initialized
DEBUG - 2018-04-08 11:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:42:21 --> Input Class Initialized
INFO - 2018-04-08 11:42:21 --> Language Class Initialized
INFO - 2018-04-08 11:42:21 --> Loader Class Initialized
INFO - 2018-04-08 11:42:21 --> Helper loaded: common_helper
INFO - 2018-04-08 11:42:21 --> Database Driver Class Initialized
INFO - 2018-04-08 11:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:42:21 --> Email Class Initialized
INFO - 2018-04-08 11:42:21 --> Controller Class Initialized
INFO - 2018-04-08 11:42:21 --> Helper loaded: form_helper
INFO - 2018-04-08 11:42:21 --> Form Validation Class Initialized
INFO - 2018-04-08 11:42:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:42:21 --> Helper loaded: url_helper
INFO - 2018-04-08 11:42:21 --> Model Class Initialized
INFO - 2018-04-08 11:42:21 --> Model Class Initialized
INFO - 2018-04-08 11:42:21 --> Model Class Initialized
ERROR - 2018-04-08 11:42:22 --> Undefined variable: 2
ERROR - 2018-04-08 11:42:22 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:42:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:42:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:42:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:42:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:42:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:42:22 --> Final output sent to browser
DEBUG - 2018-04-08 11:42:22 --> Total execution time: 0.1470
INFO - 2018-04-08 11:42:25 --> Config Class Initialized
INFO - 2018-04-08 11:42:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:42:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:42:25 --> Utf8 Class Initialized
INFO - 2018-04-08 11:42:25 --> URI Class Initialized
INFO - 2018-04-08 11:42:25 --> Router Class Initialized
INFO - 2018-04-08 11:42:25 --> Output Class Initialized
INFO - 2018-04-08 11:42:25 --> Security Class Initialized
DEBUG - 2018-04-08 11:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:42:25 --> Input Class Initialized
INFO - 2018-04-08 11:42:25 --> Language Class Initialized
INFO - 2018-04-08 11:42:25 --> Loader Class Initialized
INFO - 2018-04-08 11:42:25 --> Helper loaded: common_helper
INFO - 2018-04-08 11:42:25 --> Database Driver Class Initialized
INFO - 2018-04-08 11:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:42:25 --> Email Class Initialized
INFO - 2018-04-08 11:42:25 --> Controller Class Initialized
INFO - 2018-04-08 11:42:25 --> Helper loaded: form_helper
INFO - 2018-04-08 11:42:25 --> Form Validation Class Initialized
INFO - 2018-04-08 11:42:25 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:42:25 --> Helper loaded: url_helper
INFO - 2018-04-08 11:42:25 --> Model Class Initialized
INFO - 2018-04-08 11:42:25 --> Model Class Initialized
INFO - 2018-04-08 11:42:25 --> Model Class Initialized
INFO - 2018-04-08 11:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:42:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:42:25 --> Final output sent to browser
DEBUG - 2018-04-08 11:42:25 --> Total execution time: 0.1360
INFO - 2018-04-08 11:42:28 --> Config Class Initialized
INFO - 2018-04-08 11:42:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:42:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:42:28 --> Utf8 Class Initialized
INFO - 2018-04-08 11:42:28 --> URI Class Initialized
INFO - 2018-04-08 11:42:28 --> Router Class Initialized
INFO - 2018-04-08 11:42:28 --> Output Class Initialized
INFO - 2018-04-08 11:42:28 --> Security Class Initialized
DEBUG - 2018-04-08 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:42:28 --> Input Class Initialized
INFO - 2018-04-08 11:42:28 --> Language Class Initialized
INFO - 2018-04-08 11:42:28 --> Loader Class Initialized
INFO - 2018-04-08 11:42:28 --> Helper loaded: common_helper
INFO - 2018-04-08 11:42:28 --> Database Driver Class Initialized
INFO - 2018-04-08 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:42:28 --> Email Class Initialized
INFO - 2018-04-08 11:42:28 --> Controller Class Initialized
INFO - 2018-04-08 11:42:28 --> Helper loaded: form_helper
INFO - 2018-04-08 11:42:28 --> Form Validation Class Initialized
INFO - 2018-04-08 11:42:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:42:28 --> Helper loaded: url_helper
INFO - 2018-04-08 11:42:28 --> Model Class Initialized
INFO - 2018-04-08 11:42:28 --> Model Class Initialized
INFO - 2018-04-08 11:42:28 --> Model Class Initialized
ERROR - 2018-04-08 11:42:28 --> Undefined variable: 2
ERROR - 2018-04-08 11:42:28 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:42:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:42:28 --> Final output sent to browser
DEBUG - 2018-04-08 11:42:28 --> Total execution time: 0.1430
INFO - 2018-04-08 11:42:33 --> Config Class Initialized
INFO - 2018-04-08 11:42:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:42:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:42:33 --> Utf8 Class Initialized
INFO - 2018-04-08 11:42:33 --> URI Class Initialized
INFO - 2018-04-08 11:42:33 --> Router Class Initialized
INFO - 2018-04-08 11:42:33 --> Output Class Initialized
INFO - 2018-04-08 11:42:33 --> Security Class Initialized
DEBUG - 2018-04-08 11:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:42:33 --> Input Class Initialized
INFO - 2018-04-08 11:42:33 --> Language Class Initialized
INFO - 2018-04-08 11:42:33 --> Loader Class Initialized
INFO - 2018-04-08 11:42:33 --> Helper loaded: common_helper
INFO - 2018-04-08 11:42:33 --> Database Driver Class Initialized
INFO - 2018-04-08 11:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:42:33 --> Email Class Initialized
INFO - 2018-04-08 11:42:33 --> Controller Class Initialized
INFO - 2018-04-08 11:42:33 --> Helper loaded: form_helper
INFO - 2018-04-08 11:42:33 --> Form Validation Class Initialized
INFO - 2018-04-08 11:42:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:42:33 --> Helper loaded: url_helper
INFO - 2018-04-08 11:42:33 --> Model Class Initialized
INFO - 2018-04-08 11:42:33 --> Model Class Initialized
INFO - 2018-04-08 11:42:33 --> Model Class Initialized
ERROR - 2018-04-08 11:42:33 --> Undefined variable: 2
ERROR - 2018-04-08 11:42:33 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:42:33 --> Final output sent to browser
DEBUG - 2018-04-08 11:42:33 --> Total execution time: 0.1470
INFO - 2018-04-08 11:43:31 --> Config Class Initialized
INFO - 2018-04-08 11:43:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:31 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:31 --> URI Class Initialized
INFO - 2018-04-08 11:43:31 --> Router Class Initialized
INFO - 2018-04-08 11:43:31 --> Output Class Initialized
INFO - 2018-04-08 11:43:31 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:31 --> Input Class Initialized
INFO - 2018-04-08 11:43:31 --> Language Class Initialized
INFO - 2018-04-08 11:43:31 --> Loader Class Initialized
INFO - 2018-04-08 11:43:31 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:31 --> Database Driver Class Initialized
ERROR - 2018-04-08 11:43:31 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-08 11:43:31 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-08 11:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:31 --> Email Class Initialized
INFO - 2018-04-08 11:43:31 --> Controller Class Initialized
INFO - 2018-04-08 11:43:31 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:31 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:31 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:31 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:31 --> Model Class Initialized
INFO - 2018-04-08 11:43:31 --> Model Class Initialized
INFO - 2018-04-08 11:43:31 --> Model Class Initialized
INFO - 2018-04-08 11:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:31 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:31 --> Total execution time: 0.1710
INFO - 2018-04-08 11:43:33 --> Config Class Initialized
INFO - 2018-04-08 11:43:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:33 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:33 --> URI Class Initialized
INFO - 2018-04-08 11:43:33 --> Router Class Initialized
INFO - 2018-04-08 11:43:33 --> Output Class Initialized
INFO - 2018-04-08 11:43:33 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:33 --> Input Class Initialized
INFO - 2018-04-08 11:43:33 --> Language Class Initialized
INFO - 2018-04-08 11:43:33 --> Loader Class Initialized
INFO - 2018-04-08 11:43:33 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:33 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:33 --> Email Class Initialized
INFO - 2018-04-08 11:43:33 --> Controller Class Initialized
INFO - 2018-04-08 11:43:33 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:33 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:33 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:33 --> Model Class Initialized
INFO - 2018-04-08 11:43:33 --> Model Class Initialized
INFO - 2018-04-08 11:43:33 --> Model Class Initialized
INFO - 2018-04-08 11:43:33 --> Config Class Initialized
INFO - 2018-04-08 11:43:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:33 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:33 --> URI Class Initialized
INFO - 2018-04-08 11:43:33 --> Router Class Initialized
INFO - 2018-04-08 11:43:33 --> Output Class Initialized
INFO - 2018-04-08 11:43:33 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:33 --> Input Class Initialized
INFO - 2018-04-08 11:43:33 --> Language Class Initialized
INFO - 2018-04-08 11:43:33 --> Loader Class Initialized
INFO - 2018-04-08 11:43:33 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:33 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:33 --> Email Class Initialized
INFO - 2018-04-08 11:43:33 --> Controller Class Initialized
INFO - 2018-04-08 11:43:33 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:33 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:33 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:33 --> Model Class Initialized
INFO - 2018-04-08 11:43:33 --> Model Class Initialized
INFO - 2018-04-08 11:43:33 --> Model Class Initialized
INFO - 2018-04-08 11:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:43:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:33 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:33 --> Total execution time: 0.1320
INFO - 2018-04-08 11:43:40 --> Config Class Initialized
INFO - 2018-04-08 11:43:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:40 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:40 --> URI Class Initialized
INFO - 2018-04-08 11:43:40 --> Router Class Initialized
INFO - 2018-04-08 11:43:40 --> Output Class Initialized
INFO - 2018-04-08 11:43:40 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:40 --> Input Class Initialized
INFO - 2018-04-08 11:43:40 --> Language Class Initialized
INFO - 2018-04-08 11:43:40 --> Loader Class Initialized
INFO - 2018-04-08 11:43:40 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:40 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:40 --> Email Class Initialized
INFO - 2018-04-08 11:43:40 --> Controller Class Initialized
INFO - 2018-04-08 11:43:40 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:40 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:40 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:40 --> Model Class Initialized
INFO - 2018-04-08 11:43:40 --> Model Class Initialized
INFO - 2018-04-08 11:43:40 --> Model Class Initialized
INFO - 2018-04-08 11:43:40 --> Config Class Initialized
INFO - 2018-04-08 11:43:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:40 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:40 --> URI Class Initialized
DEBUG - 2018-04-08 11:43:40 --> No URI present. Default controller set.
INFO - 2018-04-08 11:43:40 --> Router Class Initialized
INFO - 2018-04-08 11:43:40 --> Output Class Initialized
INFO - 2018-04-08 11:43:40 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:40 --> Input Class Initialized
INFO - 2018-04-08 11:43:40 --> Language Class Initialized
INFO - 2018-04-08 11:43:40 --> Loader Class Initialized
INFO - 2018-04-08 11:43:40 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:40 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:40 --> Email Class Initialized
INFO - 2018-04-08 11:43:40 --> Controller Class Initialized
INFO - 2018-04-08 11:43:40 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:40 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:40 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:40 --> Model Class Initialized
INFO - 2018-04-08 11:43:40 --> Model Class Initialized
INFO - 2018-04-08 11:43:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:43:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:40 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:40 --> Total execution time: 0.1110
INFO - 2018-04-08 11:43:46 --> Config Class Initialized
INFO - 2018-04-08 11:43:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:46 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:46 --> URI Class Initialized
INFO - 2018-04-08 11:43:46 --> Router Class Initialized
INFO - 2018-04-08 11:43:46 --> Output Class Initialized
INFO - 2018-04-08 11:43:46 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:46 --> Input Class Initialized
INFO - 2018-04-08 11:43:46 --> Language Class Initialized
INFO - 2018-04-08 11:43:46 --> Loader Class Initialized
INFO - 2018-04-08 11:43:46 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:46 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:46 --> Email Class Initialized
INFO - 2018-04-08 11:43:46 --> Controller Class Initialized
INFO - 2018-04-08 11:43:46 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:46 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:46 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:46 --> Model Class Initialized
INFO - 2018-04-08 11:43:46 --> Model Class Initialized
INFO - 2018-04-08 11:43:46 --> Model Class Initialized
INFO - 2018-04-08 11:43:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:43:46 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:46 --> Total execution time: 0.2850
INFO - 2018-04-08 11:43:49 --> Config Class Initialized
INFO - 2018-04-08 11:43:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:49 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:49 --> URI Class Initialized
INFO - 2018-04-08 11:43:49 --> Router Class Initialized
INFO - 2018-04-08 11:43:49 --> Output Class Initialized
INFO - 2018-04-08 11:43:49 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:49 --> Input Class Initialized
INFO - 2018-04-08 11:43:49 --> Language Class Initialized
INFO - 2018-04-08 11:43:49 --> Loader Class Initialized
INFO - 2018-04-08 11:43:49 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:49 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:49 --> Email Class Initialized
INFO - 2018-04-08 11:43:49 --> Controller Class Initialized
INFO - 2018-04-08 11:43:50 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:50 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:50 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:50 --> Model Class Initialized
INFO - 2018-04-08 11:43:50 --> Model Class Initialized
INFO - 2018-04-08 11:43:50 --> Model Class Initialized
DEBUG - 2018-04-08 11:43:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:43:50 --> Config Class Initialized
INFO - 2018-04-08 11:43:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:50 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:50 --> URI Class Initialized
INFO - 2018-04-08 11:43:50 --> Router Class Initialized
INFO - 2018-04-08 11:43:50 --> Output Class Initialized
INFO - 2018-04-08 11:43:50 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:50 --> Input Class Initialized
INFO - 2018-04-08 11:43:50 --> Language Class Initialized
INFO - 2018-04-08 11:43:50 --> Loader Class Initialized
INFO - 2018-04-08 11:43:50 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:50 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:50 --> Email Class Initialized
INFO - 2018-04-08 11:43:50 --> Controller Class Initialized
INFO - 2018-04-08 11:43:50 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:50 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:50 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:50 --> Model Class Initialized
INFO - 2018-04-08 11:43:50 --> Model Class Initialized
INFO - 2018-04-08 11:43:50 --> Model Class Initialized
INFO - 2018-04-08 11:43:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:43:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:43:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:43:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:50 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:50 --> Total execution time: 0.1340
INFO - 2018-04-08 11:43:54 --> Config Class Initialized
INFO - 2018-04-08 11:43:54 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:54 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:54 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:54 --> URI Class Initialized
INFO - 2018-04-08 11:43:54 --> Router Class Initialized
INFO - 2018-04-08 11:43:54 --> Output Class Initialized
INFO - 2018-04-08 11:43:54 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:54 --> Input Class Initialized
INFO - 2018-04-08 11:43:54 --> Language Class Initialized
INFO - 2018-04-08 11:43:54 --> Loader Class Initialized
INFO - 2018-04-08 11:43:54 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:54 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:54 --> Email Class Initialized
INFO - 2018-04-08 11:43:54 --> Controller Class Initialized
INFO - 2018-04-08 11:43:54 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:54 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:54 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:54 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:54 --> Model Class Initialized
INFO - 2018-04-08 11:43:54 --> Model Class Initialized
INFO - 2018-04-08 11:43:54 --> Model Class Initialized
ERROR - 2018-04-08 11:43:54 --> Undefined variable: 2
ERROR - 2018-04-08 11:43:54 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:43:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:43:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:43:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:43:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:43:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:54 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:54 --> Total execution time: 0.1410
INFO - 2018-04-08 11:43:54 --> Config Class Initialized
INFO - 2018-04-08 11:43:54 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:54 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:54 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:54 --> URI Class Initialized
INFO - 2018-04-08 11:43:54 --> Router Class Initialized
INFO - 2018-04-08 11:43:54 --> Output Class Initialized
INFO - 2018-04-08 11:43:54 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:54 --> Input Class Initialized
INFO - 2018-04-08 11:43:54 --> Language Class Initialized
INFO - 2018-04-08 11:43:54 --> Loader Class Initialized
INFO - 2018-04-08 11:43:54 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:54 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:54 --> Email Class Initialized
INFO - 2018-04-08 11:43:54 --> Controller Class Initialized
INFO - 2018-04-08 11:43:54 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:54 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:54 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:55 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:55 --> Model Class Initialized
INFO - 2018-04-08 11:43:55 --> Model Class Initialized
INFO - 2018-04-08 11:43:55 --> Model Class Initialized
ERROR - 2018-04-08 11:43:55 --> Undefined variable: 2
ERROR - 2018-04-08 11:43:55 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:43:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:43:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:43:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:43:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:43:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:55 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:55 --> Total execution time: 0.1480
INFO - 2018-04-08 11:43:57 --> Config Class Initialized
INFO - 2018-04-08 11:43:57 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:43:57 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:43:57 --> Utf8 Class Initialized
INFO - 2018-04-08 11:43:57 --> URI Class Initialized
INFO - 2018-04-08 11:43:57 --> Router Class Initialized
INFO - 2018-04-08 11:43:57 --> Output Class Initialized
INFO - 2018-04-08 11:43:57 --> Security Class Initialized
DEBUG - 2018-04-08 11:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:43:57 --> Input Class Initialized
INFO - 2018-04-08 11:43:57 --> Language Class Initialized
INFO - 2018-04-08 11:43:57 --> Loader Class Initialized
INFO - 2018-04-08 11:43:57 --> Helper loaded: common_helper
INFO - 2018-04-08 11:43:57 --> Database Driver Class Initialized
INFO - 2018-04-08 11:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:43:57 --> Email Class Initialized
INFO - 2018-04-08 11:43:57 --> Controller Class Initialized
INFO - 2018-04-08 11:43:57 --> Helper loaded: form_helper
INFO - 2018-04-08 11:43:57 --> Form Validation Class Initialized
INFO - 2018-04-08 11:43:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:43:57 --> Helper loaded: url_helper
INFO - 2018-04-08 11:43:57 --> Model Class Initialized
INFO - 2018-04-08 11:43:57 --> Model Class Initialized
INFO - 2018-04-08 11:43:57 --> Model Class Initialized
INFO - 2018-04-08 11:43:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:43:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:43:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:43:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:43:57 --> Final output sent to browser
DEBUG - 2018-04-08 11:43:57 --> Total execution time: 0.1340
INFO - 2018-04-08 11:44:02 --> Config Class Initialized
INFO - 2018-04-08 11:44:02 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:44:02 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:44:02 --> Utf8 Class Initialized
INFO - 2018-04-08 11:44:02 --> URI Class Initialized
INFO - 2018-04-08 11:44:02 --> Router Class Initialized
INFO - 2018-04-08 11:44:02 --> Output Class Initialized
INFO - 2018-04-08 11:44:02 --> Security Class Initialized
DEBUG - 2018-04-08 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:44:02 --> Input Class Initialized
INFO - 2018-04-08 11:44:02 --> Language Class Initialized
INFO - 2018-04-08 11:44:02 --> Loader Class Initialized
INFO - 2018-04-08 11:44:02 --> Helper loaded: common_helper
INFO - 2018-04-08 11:44:02 --> Database Driver Class Initialized
INFO - 2018-04-08 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:44:02 --> Email Class Initialized
INFO - 2018-04-08 11:44:02 --> Controller Class Initialized
INFO - 2018-04-08 11:44:02 --> Helper loaded: form_helper
INFO - 2018-04-08 11:44:02 --> Form Validation Class Initialized
INFO - 2018-04-08 11:44:02 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:44:02 --> Helper loaded: url_helper
INFO - 2018-04-08 11:44:02 --> Model Class Initialized
INFO - 2018-04-08 11:44:02 --> Model Class Initialized
INFO - 2018-04-08 11:44:02 --> Model Class Initialized
INFO - 2018-04-08 11:44:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:44:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:44:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:44:02 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:44:02 --> Final output sent to browser
DEBUG - 2018-04-08 11:44:02 --> Total execution time: 0.1340
INFO - 2018-04-08 11:44:48 --> Config Class Initialized
INFO - 2018-04-08 11:44:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:44:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:44:48 --> Utf8 Class Initialized
INFO - 2018-04-08 11:44:48 --> URI Class Initialized
INFO - 2018-04-08 11:44:48 --> Router Class Initialized
INFO - 2018-04-08 11:44:48 --> Output Class Initialized
INFO - 2018-04-08 11:44:48 --> Security Class Initialized
DEBUG - 2018-04-08 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:44:48 --> Input Class Initialized
INFO - 2018-04-08 11:44:48 --> Language Class Initialized
INFO - 2018-04-08 11:44:48 --> Loader Class Initialized
INFO - 2018-04-08 11:44:48 --> Helper loaded: common_helper
INFO - 2018-04-08 11:44:48 --> Database Driver Class Initialized
ERROR - 2018-04-08 11:44:48 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-08 11:44:48 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-08 11:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:44:48 --> Email Class Initialized
INFO - 2018-04-08 11:44:48 --> Controller Class Initialized
INFO - 2018-04-08 11:44:48 --> Helper loaded: form_helper
INFO - 2018-04-08 11:44:48 --> Form Validation Class Initialized
INFO - 2018-04-08 11:44:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:44:48 --> Helper loaded: url_helper
INFO - 2018-04-08 11:44:48 --> Model Class Initialized
INFO - 2018-04-08 11:44:48 --> Model Class Initialized
INFO - 2018-04-08 11:44:48 --> Model Class Initialized
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:44:48 --> Final output sent to browser
DEBUG - 2018-04-08 11:44:48 --> Total execution time: 0.3580
INFO - 2018-04-08 11:44:48 --> Config Class Initialized
INFO - 2018-04-08 11:44:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:44:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:44:48 --> Utf8 Class Initialized
INFO - 2018-04-08 11:44:48 --> URI Class Initialized
INFO - 2018-04-08 11:44:48 --> Router Class Initialized
INFO - 2018-04-08 11:44:48 --> Output Class Initialized
INFO - 2018-04-08 11:44:48 --> Security Class Initialized
DEBUG - 2018-04-08 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:44:48 --> Input Class Initialized
INFO - 2018-04-08 11:44:48 --> Language Class Initialized
INFO - 2018-04-08 11:44:48 --> Loader Class Initialized
INFO - 2018-04-08 11:44:48 --> Helper loaded: common_helper
INFO - 2018-04-08 11:44:48 --> Database Driver Class Initialized
INFO - 2018-04-08 11:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:44:48 --> Email Class Initialized
INFO - 2018-04-08 11:44:48 --> Controller Class Initialized
INFO - 2018-04-08 11:44:48 --> Helper loaded: form_helper
INFO - 2018-04-08 11:44:48 --> Form Validation Class Initialized
INFO - 2018-04-08 11:44:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:44:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:44:48 --> Helper loaded: url_helper
INFO - 2018-04-08 11:44:48 --> Model Class Initialized
INFO - 2018-04-08 11:44:48 --> Model Class Initialized
INFO - 2018-04-08 11:44:48 --> Model Class Initialized
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 11:44:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:44:48 --> Final output sent to browser
DEBUG - 2018-04-08 11:44:48 --> Total execution time: 0.1350
INFO - 2018-04-08 11:44:51 --> Config Class Initialized
INFO - 2018-04-08 11:44:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:44:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:44:51 --> Utf8 Class Initialized
INFO - 2018-04-08 11:44:51 --> URI Class Initialized
INFO - 2018-04-08 11:44:51 --> Router Class Initialized
INFO - 2018-04-08 11:44:51 --> Output Class Initialized
INFO - 2018-04-08 11:44:51 --> Security Class Initialized
DEBUG - 2018-04-08 11:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:44:51 --> Input Class Initialized
INFO - 2018-04-08 11:44:51 --> Language Class Initialized
INFO - 2018-04-08 11:44:51 --> Loader Class Initialized
INFO - 2018-04-08 11:44:51 --> Helper loaded: common_helper
INFO - 2018-04-08 11:44:51 --> Database Driver Class Initialized
INFO - 2018-04-08 11:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:44:51 --> Email Class Initialized
INFO - 2018-04-08 11:44:51 --> Controller Class Initialized
INFO - 2018-04-08 11:44:51 --> Helper loaded: form_helper
INFO - 2018-04-08 11:44:51 --> Form Validation Class Initialized
INFO - 2018-04-08 11:44:51 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:44:51 --> Helper loaded: url_helper
INFO - 2018-04-08 11:44:51 --> Model Class Initialized
INFO - 2018-04-08 11:44:51 --> Model Class Initialized
INFO - 2018-04-08 11:44:51 --> Model Class Initialized
ERROR - 2018-04-08 11:44:51 --> Undefined variable: 2
ERROR - 2018-04-08 11:44:51 --> Severity: Notice --> Undefined variable: 2 C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 34
INFO - 2018-04-08 11:46:17 --> Config Class Initialized
INFO - 2018-04-08 11:46:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:46:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:46:17 --> Utf8 Class Initialized
INFO - 2018-04-08 11:46:17 --> URI Class Initialized
INFO - 2018-04-08 11:46:17 --> Router Class Initialized
INFO - 2018-04-08 11:46:17 --> Output Class Initialized
INFO - 2018-04-08 11:46:17 --> Security Class Initialized
DEBUG - 2018-04-08 11:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:46:17 --> Input Class Initialized
INFO - 2018-04-08 11:46:17 --> Language Class Initialized
INFO - 2018-04-08 11:46:17 --> Loader Class Initialized
INFO - 2018-04-08 11:46:17 --> Helper loaded: common_helper
INFO - 2018-04-08 11:46:17 --> Database Driver Class Initialized
INFO - 2018-04-08 11:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:46:17 --> Email Class Initialized
INFO - 2018-04-08 11:46:17 --> Controller Class Initialized
INFO - 2018-04-08 11:46:17 --> Helper loaded: form_helper
INFO - 2018-04-08 11:46:17 --> Form Validation Class Initialized
INFO - 2018-04-08 11:46:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:46:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:46:17 --> Helper loaded: url_helper
INFO - 2018-04-08 11:46:17 --> Model Class Initialized
INFO - 2018-04-08 11:46:17 --> Model Class Initialized
INFO - 2018-04-08 11:46:17 --> Model Class Initialized
INFO - 2018-04-08 11:46:48 --> Config Class Initialized
INFO - 2018-04-08 11:46:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:46:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:46:48 --> Utf8 Class Initialized
INFO - 2018-04-08 11:46:48 --> URI Class Initialized
INFO - 2018-04-08 11:46:48 --> Router Class Initialized
INFO - 2018-04-08 11:46:48 --> Output Class Initialized
INFO - 2018-04-08 11:46:48 --> Security Class Initialized
DEBUG - 2018-04-08 11:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:46:48 --> Input Class Initialized
INFO - 2018-04-08 11:46:48 --> Language Class Initialized
INFO - 2018-04-08 11:46:48 --> Loader Class Initialized
INFO - 2018-04-08 11:46:49 --> Helper loaded: common_helper
INFO - 2018-04-08 11:46:49 --> Database Driver Class Initialized
INFO - 2018-04-08 11:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:46:49 --> Email Class Initialized
INFO - 2018-04-08 11:46:49 --> Controller Class Initialized
INFO - 2018-04-08 11:46:49 --> Helper loaded: form_helper
INFO - 2018-04-08 11:46:49 --> Form Validation Class Initialized
INFO - 2018-04-08 11:46:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:46:49 --> Helper loaded: url_helper
INFO - 2018-04-08 11:46:49 --> Model Class Initialized
INFO - 2018-04-08 11:46:49 --> Model Class Initialized
INFO - 2018-04-08 11:46:49 --> Model Class Initialized
INFO - 2018-04-08 11:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:46:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:46:49 --> Final output sent to browser
DEBUG - 2018-04-08 11:46:49 --> Total execution time: 0.1340
INFO - 2018-04-08 11:50:07 --> Config Class Initialized
INFO - 2018-04-08 11:50:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:50:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:50:07 --> Utf8 Class Initialized
INFO - 2018-04-08 11:50:07 --> URI Class Initialized
INFO - 2018-04-08 11:50:07 --> Router Class Initialized
INFO - 2018-04-08 11:50:07 --> Output Class Initialized
INFO - 2018-04-08 11:50:07 --> Security Class Initialized
DEBUG - 2018-04-08 11:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:50:07 --> Input Class Initialized
INFO - 2018-04-08 11:50:07 --> Language Class Initialized
INFO - 2018-04-08 11:50:07 --> Loader Class Initialized
INFO - 2018-04-08 11:50:07 --> Helper loaded: common_helper
INFO - 2018-04-08 11:50:07 --> Database Driver Class Initialized
INFO - 2018-04-08 11:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:50:07 --> Email Class Initialized
INFO - 2018-04-08 11:50:07 --> Controller Class Initialized
INFO - 2018-04-08 11:50:07 --> Helper loaded: form_helper
INFO - 2018-04-08 11:50:07 --> Form Validation Class Initialized
INFO - 2018-04-08 11:50:07 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:50:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:50:07 --> Helper loaded: url_helper
INFO - 2018-04-08 11:50:07 --> Model Class Initialized
INFO - 2018-04-08 11:50:07 --> Model Class Initialized
INFO - 2018-04-08 11:50:07 --> Model Class Initialized
INFO - 2018-04-08 11:50:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:50:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:50:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:50:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:50:07 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:50:07 --> Final output sent to browser
DEBUG - 2018-04-08 11:50:07 --> Total execution time: 0.1380
INFO - 2018-04-08 11:50:14 --> Config Class Initialized
INFO - 2018-04-08 11:50:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:50:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:50:14 --> Utf8 Class Initialized
INFO - 2018-04-08 11:50:14 --> URI Class Initialized
INFO - 2018-04-08 11:50:14 --> Router Class Initialized
INFO - 2018-04-08 11:50:14 --> Output Class Initialized
INFO - 2018-04-08 11:50:14 --> Security Class Initialized
DEBUG - 2018-04-08 11:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:50:14 --> Input Class Initialized
INFO - 2018-04-08 11:50:14 --> Language Class Initialized
INFO - 2018-04-08 11:50:14 --> Loader Class Initialized
INFO - 2018-04-08 11:50:14 --> Helper loaded: common_helper
INFO - 2018-04-08 11:50:14 --> Database Driver Class Initialized
INFO - 2018-04-08 11:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:50:14 --> Email Class Initialized
INFO - 2018-04-08 11:50:14 --> Controller Class Initialized
INFO - 2018-04-08 11:50:14 --> Helper loaded: form_helper
INFO - 2018-04-08 11:50:14 --> Form Validation Class Initialized
INFO - 2018-04-08 11:50:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:50:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:50:14 --> Helper loaded: url_helper
INFO - 2018-04-08 11:50:14 --> Model Class Initialized
INFO - 2018-04-08 11:50:14 --> Model Class Initialized
INFO - 2018-04-08 11:50:14 --> Model Class Initialized
INFO - 2018-04-08 11:50:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:50:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:50:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 11:50:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:50:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:50:14 --> Final output sent to browser
DEBUG - 2018-04-08 11:50:14 --> Total execution time: 0.1320
INFO - 2018-04-08 11:50:42 --> Config Class Initialized
INFO - 2018-04-08 11:50:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:50:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:50:42 --> Utf8 Class Initialized
INFO - 2018-04-08 11:50:42 --> URI Class Initialized
INFO - 2018-04-08 11:50:42 --> Router Class Initialized
INFO - 2018-04-08 11:50:42 --> Output Class Initialized
INFO - 2018-04-08 11:50:42 --> Security Class Initialized
DEBUG - 2018-04-08 11:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:50:42 --> Input Class Initialized
INFO - 2018-04-08 11:50:42 --> Language Class Initialized
INFO - 2018-04-08 11:50:42 --> Loader Class Initialized
INFO - 2018-04-08 11:50:42 --> Helper loaded: common_helper
INFO - 2018-04-08 11:50:42 --> Database Driver Class Initialized
INFO - 2018-04-08 11:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:50:42 --> Email Class Initialized
INFO - 2018-04-08 11:50:42 --> Controller Class Initialized
INFO - 2018-04-08 11:50:42 --> Helper loaded: form_helper
INFO - 2018-04-08 11:50:42 --> Form Validation Class Initialized
INFO - 2018-04-08 11:50:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:50:42 --> Helper loaded: url_helper
INFO - 2018-04-08 11:50:42 --> Model Class Initialized
INFO - 2018-04-08 11:50:42 --> Model Class Initialized
INFO - 2018-04-08 11:50:42 --> Model Class Initialized
INFO - 2018-04-08 11:50:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:50:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:50:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:50:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:50:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:50:42 --> Final output sent to browser
DEBUG - 2018-04-08 11:50:42 --> Total execution time: 0.1406
INFO - 2018-04-08 11:52:08 --> Config Class Initialized
INFO - 2018-04-08 11:52:08 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:52:08 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:52:08 --> Utf8 Class Initialized
INFO - 2018-04-08 11:52:08 --> URI Class Initialized
INFO - 2018-04-08 11:52:08 --> Router Class Initialized
INFO - 2018-04-08 11:52:08 --> Output Class Initialized
INFO - 2018-04-08 11:52:08 --> Security Class Initialized
DEBUG - 2018-04-08 11:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:52:08 --> Input Class Initialized
INFO - 2018-04-08 11:52:08 --> Language Class Initialized
INFO - 2018-04-08 11:52:08 --> Loader Class Initialized
INFO - 2018-04-08 11:52:08 --> Helper loaded: common_helper
INFO - 2018-04-08 11:52:08 --> Database Driver Class Initialized
INFO - 2018-04-08 11:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:52:08 --> Email Class Initialized
INFO - 2018-04-08 11:52:08 --> Controller Class Initialized
INFO - 2018-04-08 11:52:08 --> Helper loaded: form_helper
INFO - 2018-04-08 11:52:08 --> Form Validation Class Initialized
INFO - 2018-04-08 11:52:08 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:52:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:08 --> Helper loaded: url_helper
INFO - 2018-04-08 11:52:08 --> Model Class Initialized
INFO - 2018-04-08 11:52:08 --> Model Class Initialized
INFO - 2018-04-08 11:52:08 --> Model Class Initialized
INFO - 2018-04-08 11:52:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:52:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:52:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:52:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:52:08 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:52:08 --> Final output sent to browser
DEBUG - 2018-04-08 11:52:08 --> Total execution time: 0.1310
INFO - 2018-04-08 11:52:11 --> Config Class Initialized
INFO - 2018-04-08 11:52:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:52:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:52:11 --> Utf8 Class Initialized
INFO - 2018-04-08 11:52:11 --> URI Class Initialized
INFO - 2018-04-08 11:52:11 --> Router Class Initialized
INFO - 2018-04-08 11:52:11 --> Output Class Initialized
INFO - 2018-04-08 11:52:11 --> Security Class Initialized
DEBUG - 2018-04-08 11:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:52:11 --> Input Class Initialized
INFO - 2018-04-08 11:52:11 --> Language Class Initialized
INFO - 2018-04-08 11:52:11 --> Loader Class Initialized
INFO - 2018-04-08 11:52:11 --> Helper loaded: common_helper
INFO - 2018-04-08 11:52:11 --> Database Driver Class Initialized
INFO - 2018-04-08 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:52:11 --> Email Class Initialized
INFO - 2018-04-08 11:52:11 --> Controller Class Initialized
INFO - 2018-04-08 11:52:11 --> Helper loaded: form_helper
INFO - 2018-04-08 11:52:11 --> Form Validation Class Initialized
INFO - 2018-04-08 11:52:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:11 --> Helper loaded: url_helper
INFO - 2018-04-08 11:52:11 --> Model Class Initialized
INFO - 2018-04-08 11:52:11 --> Model Class Initialized
INFO - 2018-04-08 11:52:11 --> Model Class Initialized
INFO - 2018-04-08 11:52:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:52:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:52:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 11:52:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:52:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:52:11 --> Final output sent to browser
DEBUG - 2018-04-08 11:52:11 --> Total execution time: 0.1270
INFO - 2018-04-08 11:52:31 --> Config Class Initialized
INFO - 2018-04-08 11:52:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:52:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:52:31 --> Utf8 Class Initialized
INFO - 2018-04-08 11:52:31 --> URI Class Initialized
INFO - 2018-04-08 11:52:31 --> Router Class Initialized
INFO - 2018-04-08 11:52:31 --> Output Class Initialized
INFO - 2018-04-08 11:52:31 --> Security Class Initialized
DEBUG - 2018-04-08 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:52:31 --> Input Class Initialized
INFO - 2018-04-08 11:52:31 --> Language Class Initialized
INFO - 2018-04-08 11:52:31 --> Loader Class Initialized
INFO - 2018-04-08 11:52:31 --> Helper loaded: common_helper
INFO - 2018-04-08 11:52:31 --> Database Driver Class Initialized
INFO - 2018-04-08 11:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:52:31 --> Email Class Initialized
INFO - 2018-04-08 11:52:31 --> Controller Class Initialized
INFO - 2018-04-08 11:52:31 --> Helper loaded: form_helper
INFO - 2018-04-08 11:52:31 --> Form Validation Class Initialized
INFO - 2018-04-08 11:52:31 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:52:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:31 --> Helper loaded: url_helper
INFO - 2018-04-08 11:52:31 --> Model Class Initialized
INFO - 2018-04-08 11:52:31 --> Model Class Initialized
INFO - 2018-04-08 11:52:31 --> Model Class Initialized
DEBUG - 2018-04-08 11:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:52:53 --> Config Class Initialized
INFO - 2018-04-08 11:52:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:52:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:52:53 --> Utf8 Class Initialized
INFO - 2018-04-08 11:52:53 --> URI Class Initialized
INFO - 2018-04-08 11:52:53 --> Router Class Initialized
INFO - 2018-04-08 11:52:53 --> Output Class Initialized
INFO - 2018-04-08 11:52:53 --> Security Class Initialized
DEBUG - 2018-04-08 11:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:52:53 --> Input Class Initialized
INFO - 2018-04-08 11:52:53 --> Language Class Initialized
INFO - 2018-04-08 11:52:53 --> Loader Class Initialized
INFO - 2018-04-08 11:52:53 --> Helper loaded: common_helper
INFO - 2018-04-08 11:52:53 --> Database Driver Class Initialized
INFO - 2018-04-08 11:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:52:53 --> Email Class Initialized
INFO - 2018-04-08 11:52:53 --> Controller Class Initialized
INFO - 2018-04-08 11:52:53 --> Helper loaded: form_helper
INFO - 2018-04-08 11:52:53 --> Form Validation Class Initialized
INFO - 2018-04-08 11:52:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:53 --> Helper loaded: url_helper
INFO - 2018-04-08 11:52:53 --> Model Class Initialized
INFO - 2018-04-08 11:52:53 --> Model Class Initialized
INFO - 2018-04-08 11:52:53 --> Model Class Initialized
DEBUG - 2018-04-08 11:52:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:52:53 --> Config Class Initialized
INFO - 2018-04-08 11:52:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:52:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:52:53 --> Utf8 Class Initialized
INFO - 2018-04-08 11:52:53 --> URI Class Initialized
INFO - 2018-04-08 11:52:53 --> Router Class Initialized
INFO - 2018-04-08 11:52:53 --> Output Class Initialized
INFO - 2018-04-08 11:52:53 --> Security Class Initialized
DEBUG - 2018-04-08 11:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:52:53 --> Input Class Initialized
INFO - 2018-04-08 11:52:53 --> Language Class Initialized
INFO - 2018-04-08 11:52:53 --> Loader Class Initialized
INFO - 2018-04-08 11:52:53 --> Helper loaded: common_helper
INFO - 2018-04-08 11:52:53 --> Database Driver Class Initialized
INFO - 2018-04-08 11:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:52:53 --> Email Class Initialized
INFO - 2018-04-08 11:52:53 --> Controller Class Initialized
INFO - 2018-04-08 11:52:54 --> Helper loaded: form_helper
INFO - 2018-04-08 11:52:54 --> Form Validation Class Initialized
INFO - 2018-04-08 11:52:54 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:52:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:52:54 --> Helper loaded: url_helper
INFO - 2018-04-08 11:52:54 --> Model Class Initialized
INFO - 2018-04-08 11:52:54 --> Model Class Initialized
INFO - 2018-04-08 11:52:54 --> Model Class Initialized
INFO - 2018-04-08 11:52:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:52:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:52:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:52:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:52:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:52:54 --> Final output sent to browser
DEBUG - 2018-04-08 11:52:54 --> Total execution time: 0.1300
INFO - 2018-04-08 11:54:51 --> Config Class Initialized
INFO - 2018-04-08 11:54:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:54:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:54:51 --> Utf8 Class Initialized
INFO - 2018-04-08 11:54:51 --> URI Class Initialized
INFO - 2018-04-08 11:54:51 --> Router Class Initialized
INFO - 2018-04-08 11:54:51 --> Output Class Initialized
INFO - 2018-04-08 11:54:51 --> Security Class Initialized
DEBUG - 2018-04-08 11:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:54:51 --> Input Class Initialized
INFO - 2018-04-08 11:54:51 --> Language Class Initialized
INFO - 2018-04-08 11:54:51 --> Loader Class Initialized
INFO - 2018-04-08 11:54:51 --> Helper loaded: common_helper
INFO - 2018-04-08 11:54:51 --> Database Driver Class Initialized
INFO - 2018-04-08 11:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:54:51 --> Email Class Initialized
INFO - 2018-04-08 11:54:51 --> Controller Class Initialized
INFO - 2018-04-08 11:54:51 --> Helper loaded: form_helper
INFO - 2018-04-08 11:54:51 --> Form Validation Class Initialized
INFO - 2018-04-08 11:54:51 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:54:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:54:51 --> Helper loaded: url_helper
INFO - 2018-04-08 11:54:51 --> Model Class Initialized
INFO - 2018-04-08 11:54:51 --> Model Class Initialized
ERROR - 2018-04-08 11:54:51 --> syntax error, unexpected ')'
ERROR - 2018-04-08 11:54:51 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\FlickNews\admin\application\models\Commonmodel.php 89
INFO - 2018-04-08 11:55:21 --> Config Class Initialized
INFO - 2018-04-08 11:55:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:21 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:21 --> URI Class Initialized
INFO - 2018-04-08 11:55:21 --> Router Class Initialized
INFO - 2018-04-08 11:55:21 --> Output Class Initialized
INFO - 2018-04-08 11:55:21 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:21 --> Input Class Initialized
INFO - 2018-04-08 11:55:21 --> Language Class Initialized
INFO - 2018-04-08 11:55:21 --> Loader Class Initialized
INFO - 2018-04-08 11:55:21 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:21 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:21 --> Email Class Initialized
INFO - 2018-04-08 11:55:21 --> Controller Class Initialized
INFO - 2018-04-08 11:55:21 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:21 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:21 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:21 --> Model Class Initialized
INFO - 2018-04-08 11:55:21 --> Model Class Initialized
INFO - 2018-04-08 11:55:21 --> Model Class Initialized
INFO - 2018-04-08 11:55:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:55:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:55:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 11:55:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:55:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:55:21 --> Final output sent to browser
DEBUG - 2018-04-08 11:55:21 --> Total execution time: 0.1410
INFO - 2018-04-08 11:55:36 --> Config Class Initialized
INFO - 2018-04-08 11:55:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:36 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:36 --> URI Class Initialized
INFO - 2018-04-08 11:55:36 --> Router Class Initialized
INFO - 2018-04-08 11:55:36 --> Output Class Initialized
INFO - 2018-04-08 11:55:36 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:36 --> Input Class Initialized
INFO - 2018-04-08 11:55:36 --> Language Class Initialized
INFO - 2018-04-08 11:55:36 --> Loader Class Initialized
INFO - 2018-04-08 11:55:36 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:36 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:36 --> Email Class Initialized
INFO - 2018-04-08 11:55:36 --> Controller Class Initialized
INFO - 2018-04-08 11:55:36 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:36 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:36 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:36 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:36 --> Model Class Initialized
INFO - 2018-04-08 11:55:36 --> Model Class Initialized
INFO - 2018-04-08 11:55:36 --> Model Class Initialized
DEBUG - 2018-04-08 11:55:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:55:36 --> Config Class Initialized
INFO - 2018-04-08 11:55:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:36 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:36 --> URI Class Initialized
INFO - 2018-04-08 11:55:36 --> Router Class Initialized
INFO - 2018-04-08 11:55:36 --> Output Class Initialized
INFO - 2018-04-08 11:55:36 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:36 --> Input Class Initialized
INFO - 2018-04-08 11:55:36 --> Language Class Initialized
INFO - 2018-04-08 11:55:36 --> Loader Class Initialized
INFO - 2018-04-08 11:55:36 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:36 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:36 --> Email Class Initialized
INFO - 2018-04-08 11:55:36 --> Controller Class Initialized
INFO - 2018-04-08 11:55:37 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:37 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:37 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:37 --> Model Class Initialized
INFO - 2018-04-08 11:55:37 --> Model Class Initialized
INFO - 2018-04-08 11:55:37 --> Model Class Initialized
INFO - 2018-04-08 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 11:55:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:55:37 --> Final output sent to browser
DEBUG - 2018-04-08 11:55:37 --> Total execution time: 0.1250
INFO - 2018-04-08 11:55:46 --> Config Class Initialized
INFO - 2018-04-08 11:55:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:46 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:46 --> URI Class Initialized
INFO - 2018-04-08 11:55:46 --> Router Class Initialized
INFO - 2018-04-08 11:55:46 --> Output Class Initialized
INFO - 2018-04-08 11:55:46 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:46 --> Input Class Initialized
INFO - 2018-04-08 11:55:46 --> Language Class Initialized
INFO - 2018-04-08 11:55:46 --> Loader Class Initialized
INFO - 2018-04-08 11:55:46 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:46 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:46 --> Email Class Initialized
INFO - 2018-04-08 11:55:46 --> Controller Class Initialized
INFO - 2018-04-08 11:55:46 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:46 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:46 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:46 --> Model Class Initialized
INFO - 2018-04-08 11:55:46 --> Model Class Initialized
INFO - 2018-04-08 11:55:46 --> Model Class Initialized
INFO - 2018-04-08 11:55:46 --> Config Class Initialized
INFO - 2018-04-08 11:55:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:46 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:46 --> URI Class Initialized
DEBUG - 2018-04-08 11:55:46 --> No URI present. Default controller set.
INFO - 2018-04-08 11:55:46 --> Router Class Initialized
INFO - 2018-04-08 11:55:46 --> Output Class Initialized
INFO - 2018-04-08 11:55:46 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:46 --> Input Class Initialized
INFO - 2018-04-08 11:55:46 --> Language Class Initialized
INFO - 2018-04-08 11:55:46 --> Loader Class Initialized
INFO - 2018-04-08 11:55:46 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:46 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:46 --> Email Class Initialized
INFO - 2018-04-08 11:55:46 --> Controller Class Initialized
INFO - 2018-04-08 11:55:46 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:46 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:46 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:46 --> Model Class Initialized
INFO - 2018-04-08 11:55:46 --> Model Class Initialized
INFO - 2018-04-08 11:55:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:55:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 11:55:46 --> Final output sent to browser
DEBUG - 2018-04-08 11:55:46 --> Total execution time: 0.2210
INFO - 2018-04-08 11:55:53 --> Config Class Initialized
INFO - 2018-04-08 11:55:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:53 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:53 --> URI Class Initialized
INFO - 2018-04-08 11:55:53 --> Router Class Initialized
INFO - 2018-04-08 11:55:53 --> Output Class Initialized
INFO - 2018-04-08 11:55:53 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:53 --> Input Class Initialized
INFO - 2018-04-08 11:55:53 --> Language Class Initialized
INFO - 2018-04-08 11:55:53 --> Loader Class Initialized
INFO - 2018-04-08 11:55:53 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:53 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:53 --> Email Class Initialized
INFO - 2018-04-08 11:55:53 --> Controller Class Initialized
INFO - 2018-04-08 11:55:53 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:53 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:54 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:54 --> Model Class Initialized
INFO - 2018-04-08 11:55:54 --> Model Class Initialized
INFO - 2018-04-08 11:55:54 --> Model Class Initialized
INFO - 2018-04-08 11:55:54 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:55:54 --> Final output sent to browser
DEBUG - 2018-04-08 11:55:54 --> Total execution time: 0.1850
INFO - 2018-04-08 11:55:56 --> Config Class Initialized
INFO - 2018-04-08 11:55:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:55:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:55:56 --> Utf8 Class Initialized
INFO - 2018-04-08 11:55:56 --> URI Class Initialized
INFO - 2018-04-08 11:55:56 --> Router Class Initialized
INFO - 2018-04-08 11:55:56 --> Output Class Initialized
INFO - 2018-04-08 11:55:56 --> Security Class Initialized
DEBUG - 2018-04-08 11:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:55:56 --> Input Class Initialized
INFO - 2018-04-08 11:55:56 --> Language Class Initialized
INFO - 2018-04-08 11:55:56 --> Loader Class Initialized
INFO - 2018-04-08 11:55:56 --> Helper loaded: common_helper
INFO - 2018-04-08 11:55:56 --> Database Driver Class Initialized
INFO - 2018-04-08 11:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:55:56 --> Email Class Initialized
INFO - 2018-04-08 11:55:56 --> Controller Class Initialized
INFO - 2018-04-08 11:55:56 --> Helper loaded: form_helper
INFO - 2018-04-08 11:55:56 --> Form Validation Class Initialized
INFO - 2018-04-08 11:55:56 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:56 --> Helper loaded: url_helper
INFO - 2018-04-08 11:55:56 --> Model Class Initialized
INFO - 2018-04-08 11:55:56 --> Model Class Initialized
INFO - 2018-04-08 11:55:56 --> Model Class Initialized
DEBUG - 2018-04-08 11:55:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:55:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 11:55:56 --> mcrypt_decrypt(): Received initialization vector of size 4, but size 16 is required for this encryption mode
ERROR - 2018-04-08 11:55:56 --> Severity: Warning --> mcrypt_decrypt(): Received initialization vector of size 4, but size 16 is required for this encryption mode C:\xampp\htdocs\FlickNews\admin\application\helpers\common_helper.php 508
INFO - 2018-04-08 11:58:07 --> Config Class Initialized
INFO - 2018-04-08 11:58:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:58:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:58:07 --> Utf8 Class Initialized
INFO - 2018-04-08 11:58:07 --> URI Class Initialized
INFO - 2018-04-08 11:58:07 --> Router Class Initialized
INFO - 2018-04-08 11:58:07 --> Output Class Initialized
INFO - 2018-04-08 11:58:07 --> Security Class Initialized
DEBUG - 2018-04-08 11:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:58:07 --> Input Class Initialized
INFO - 2018-04-08 11:58:07 --> Language Class Initialized
INFO - 2018-04-08 11:58:07 --> Loader Class Initialized
INFO - 2018-04-08 11:58:07 --> Helper loaded: common_helper
INFO - 2018-04-08 11:58:07 --> Database Driver Class Initialized
INFO - 2018-04-08 11:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:58:07 --> Email Class Initialized
INFO - 2018-04-08 11:58:07 --> Controller Class Initialized
INFO - 2018-04-08 11:58:07 --> Helper loaded: form_helper
INFO - 2018-04-08 11:58:07 --> Form Validation Class Initialized
INFO - 2018-04-08 11:58:07 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:58:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:07 --> Helper loaded: url_helper
INFO - 2018-04-08 11:58:07 --> Model Class Initialized
INFO - 2018-04-08 11:58:07 --> Model Class Initialized
INFO - 2018-04-08 11:58:07 --> Model Class Initialized
DEBUG - 2018-04-08 11:58:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 11:58:18 --> Config Class Initialized
INFO - 2018-04-08 11:58:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:58:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:58:18 --> Utf8 Class Initialized
INFO - 2018-04-08 11:58:18 --> URI Class Initialized
INFO - 2018-04-08 11:58:18 --> Router Class Initialized
INFO - 2018-04-08 11:58:18 --> Output Class Initialized
INFO - 2018-04-08 11:58:18 --> Security Class Initialized
DEBUG - 2018-04-08 11:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:58:18 --> Input Class Initialized
INFO - 2018-04-08 11:58:18 --> Language Class Initialized
INFO - 2018-04-08 11:58:18 --> Loader Class Initialized
INFO - 2018-04-08 11:58:18 --> Helper loaded: common_helper
INFO - 2018-04-08 11:58:18 --> Database Driver Class Initialized
INFO - 2018-04-08 11:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:58:18 --> Email Class Initialized
INFO - 2018-04-08 11:58:18 --> Controller Class Initialized
INFO - 2018-04-08 11:58:18 --> Helper loaded: form_helper
INFO - 2018-04-08 11:58:18 --> Form Validation Class Initialized
INFO - 2018-04-08 11:58:18 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:58:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:18 --> Helper loaded: url_helper
INFO - 2018-04-08 11:58:18 --> Model Class Initialized
INFO - 2018-04-08 11:58:18 --> Model Class Initialized
INFO - 2018-04-08 11:58:18 --> Model Class Initialized
DEBUG - 2018-04-08 11:58:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 11:58:18 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 11:58:18 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 11:58:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:58:18 --> Final output sent to browser
DEBUG - 2018-04-08 11:58:18 --> Total execution time: 0.1960
INFO - 2018-04-08 11:58:21 --> Config Class Initialized
INFO - 2018-04-08 11:58:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:58:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:58:21 --> Utf8 Class Initialized
INFO - 2018-04-08 11:58:21 --> URI Class Initialized
INFO - 2018-04-08 11:58:21 --> Router Class Initialized
INFO - 2018-04-08 11:58:21 --> Output Class Initialized
INFO - 2018-04-08 11:58:21 --> Security Class Initialized
DEBUG - 2018-04-08 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:58:21 --> Input Class Initialized
INFO - 2018-04-08 11:58:21 --> Language Class Initialized
INFO - 2018-04-08 11:58:21 --> Loader Class Initialized
INFO - 2018-04-08 11:58:21 --> Helper loaded: common_helper
INFO - 2018-04-08 11:58:21 --> Database Driver Class Initialized
INFO - 2018-04-08 11:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:58:21 --> Email Class Initialized
INFO - 2018-04-08 11:58:21 --> Controller Class Initialized
INFO - 2018-04-08 11:58:21 --> Helper loaded: form_helper
INFO - 2018-04-08 11:58:21 --> Form Validation Class Initialized
INFO - 2018-04-08 11:58:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:58:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:21 --> Helper loaded: url_helper
INFO - 2018-04-08 11:58:21 --> Model Class Initialized
INFO - 2018-04-08 11:58:21 --> Model Class Initialized
INFO - 2018-04-08 11:58:21 --> Model Class Initialized
DEBUG - 2018-04-08 11:58:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 11:58:21 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 11:58:21 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 11:58:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:58:21 --> Final output sent to browser
DEBUG - 2018-04-08 11:58:21 --> Total execution time: 0.1570
INFO - 2018-04-08 11:58:24 --> Config Class Initialized
INFO - 2018-04-08 11:58:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:58:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:58:24 --> Utf8 Class Initialized
INFO - 2018-04-08 11:58:24 --> URI Class Initialized
INFO - 2018-04-08 11:58:24 --> Router Class Initialized
INFO - 2018-04-08 11:58:24 --> Output Class Initialized
INFO - 2018-04-08 11:58:24 --> Security Class Initialized
DEBUG - 2018-04-08 11:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:58:24 --> Input Class Initialized
INFO - 2018-04-08 11:58:24 --> Language Class Initialized
INFO - 2018-04-08 11:58:24 --> Loader Class Initialized
INFO - 2018-04-08 11:58:24 --> Helper loaded: common_helper
INFO - 2018-04-08 11:58:24 --> Database Driver Class Initialized
INFO - 2018-04-08 11:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:58:24 --> Email Class Initialized
INFO - 2018-04-08 11:58:24 --> Controller Class Initialized
INFO - 2018-04-08 11:58:24 --> Helper loaded: form_helper
INFO - 2018-04-08 11:58:24 --> Form Validation Class Initialized
INFO - 2018-04-08 11:58:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:58:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:24 --> Helper loaded: url_helper
INFO - 2018-04-08 11:58:24 --> Model Class Initialized
INFO - 2018-04-08 11:58:24 --> Model Class Initialized
INFO - 2018-04-08 11:58:24 --> Model Class Initialized
INFO - 2018-04-08 11:58:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:58:24 --> Final output sent to browser
DEBUG - 2018-04-08 11:58:24 --> Total execution time: 0.1380
INFO - 2018-04-08 11:58:26 --> Config Class Initialized
INFO - 2018-04-08 11:58:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 11:58:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 11:58:26 --> Utf8 Class Initialized
INFO - 2018-04-08 11:58:26 --> URI Class Initialized
INFO - 2018-04-08 11:58:26 --> Router Class Initialized
INFO - 2018-04-08 11:58:26 --> Output Class Initialized
INFO - 2018-04-08 11:58:26 --> Security Class Initialized
DEBUG - 2018-04-08 11:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 11:58:26 --> Input Class Initialized
INFO - 2018-04-08 11:58:26 --> Language Class Initialized
INFO - 2018-04-08 11:58:26 --> Loader Class Initialized
INFO - 2018-04-08 11:58:26 --> Helper loaded: common_helper
INFO - 2018-04-08 11:58:26 --> Database Driver Class Initialized
INFO - 2018-04-08 11:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 11:58:26 --> Email Class Initialized
INFO - 2018-04-08 11:58:26 --> Controller Class Initialized
INFO - 2018-04-08 11:58:26 --> Helper loaded: form_helper
INFO - 2018-04-08 11:58:26 --> Form Validation Class Initialized
INFO - 2018-04-08 11:58:26 --> Helper loaded: email_helper
DEBUG - 2018-04-08 11:58:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:26 --> Helper loaded: url_helper
INFO - 2018-04-08 11:58:26 --> Model Class Initialized
INFO - 2018-04-08 11:58:26 --> Model Class Initialized
INFO - 2018-04-08 11:58:26 --> Model Class Initialized
DEBUG - 2018-04-08 11:58:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 11:58:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 11:58:26 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 11:58:26 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 11:58:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 11:58:26 --> Final output sent to browser
DEBUG - 2018-04-08 11:58:26 --> Total execution time: 0.1450
INFO - 2018-04-08 12:01:49 --> Config Class Initialized
INFO - 2018-04-08 12:01:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:01:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:01:49 --> Utf8 Class Initialized
INFO - 2018-04-08 12:01:49 --> URI Class Initialized
INFO - 2018-04-08 12:01:49 --> Router Class Initialized
INFO - 2018-04-08 12:01:49 --> Output Class Initialized
INFO - 2018-04-08 12:01:49 --> Security Class Initialized
DEBUG - 2018-04-08 12:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:01:49 --> Input Class Initialized
INFO - 2018-04-08 12:01:49 --> Language Class Initialized
INFO - 2018-04-08 12:01:49 --> Loader Class Initialized
INFO - 2018-04-08 12:01:49 --> Helper loaded: common_helper
INFO - 2018-04-08 12:01:49 --> Database Driver Class Initialized
INFO - 2018-04-08 12:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:01:50 --> Email Class Initialized
INFO - 2018-04-08 12:01:50 --> Controller Class Initialized
INFO - 2018-04-08 12:01:50 --> Helper loaded: form_helper
INFO - 2018-04-08 12:01:50 --> Form Validation Class Initialized
INFO - 2018-04-08 12:01:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:01:50 --> Helper loaded: url_helper
INFO - 2018-04-08 12:01:50 --> Model Class Initialized
INFO - 2018-04-08 12:01:50 --> Model Class Initialized
INFO - 2018-04-08 12:01:50 --> Model Class Initialized
INFO - 2018-04-08 12:01:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:01:50 --> Final output sent to browser
DEBUG - 2018-04-08 12:01:50 --> Total execution time: 0.2000
INFO - 2018-04-08 12:01:53 --> Config Class Initialized
INFO - 2018-04-08 12:01:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:01:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:01:53 --> Utf8 Class Initialized
INFO - 2018-04-08 12:01:53 --> URI Class Initialized
INFO - 2018-04-08 12:01:53 --> Router Class Initialized
INFO - 2018-04-08 12:01:53 --> Output Class Initialized
INFO - 2018-04-08 12:01:53 --> Security Class Initialized
DEBUG - 2018-04-08 12:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:01:53 --> Input Class Initialized
INFO - 2018-04-08 12:01:53 --> Language Class Initialized
INFO - 2018-04-08 12:01:53 --> Loader Class Initialized
INFO - 2018-04-08 12:01:53 --> Helper loaded: common_helper
INFO - 2018-04-08 12:01:53 --> Database Driver Class Initialized
INFO - 2018-04-08 12:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:01:53 --> Email Class Initialized
INFO - 2018-04-08 12:01:53 --> Controller Class Initialized
INFO - 2018-04-08 12:01:53 --> Helper loaded: form_helper
INFO - 2018-04-08 12:01:53 --> Form Validation Class Initialized
INFO - 2018-04-08 12:01:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:01:53 --> Helper loaded: url_helper
INFO - 2018-04-08 12:01:53 --> Model Class Initialized
INFO - 2018-04-08 12:01:53 --> Model Class Initialized
INFO - 2018-04-08 12:01:53 --> Model Class Initialized
DEBUG - 2018-04-08 12:01:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:01:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 12:01:53 --> Undefined property: stdClass::$password
ERROR - 2018-04-08 12:01:53 --> Severity: Notice --> Undefined property: stdClass::$password C:\xampp\htdocs\FlickNews\admin\application\models\Commonmodel.php 97
ERROR - 2018-04-08 12:01:53 --> mcrypt_decrypt(): Received initialization vector of size 0, but size 16 is required for this encryption mode
ERROR - 2018-04-08 12:01:53 --> Severity: Warning --> mcrypt_decrypt(): Received initialization vector of size 0, but size 16 is required for this encryption mode C:\xampp\htdocs\FlickNews\admin\application\helpers\common_helper.php 508
INFO - 2018-04-08 12:03:23 --> Config Class Initialized
INFO - 2018-04-08 12:03:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:23 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:23 --> URI Class Initialized
INFO - 2018-04-08 12:03:23 --> Router Class Initialized
INFO - 2018-04-08 12:03:23 --> Output Class Initialized
INFO - 2018-04-08 12:03:23 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:23 --> Input Class Initialized
INFO - 2018-04-08 12:03:23 --> Language Class Initialized
INFO - 2018-04-08 12:03:23 --> Loader Class Initialized
INFO - 2018-04-08 12:03:23 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:23 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:23 --> Email Class Initialized
INFO - 2018-04-08 12:03:23 --> Controller Class Initialized
INFO - 2018-04-08 12:03:23 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:23 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:23 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:23 --> Model Class Initialized
INFO - 2018-04-08 12:03:23 --> Model Class Initialized
INFO - 2018-04-08 12:03:23 --> Model Class Initialized
INFO - 2018-04-08 12:03:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:03:23 --> Final output sent to browser
DEBUG - 2018-04-08 12:03:23 --> Total execution time: 0.1490
INFO - 2018-04-08 12:03:25 --> Config Class Initialized
INFO - 2018-04-08 12:03:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:25 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:25 --> URI Class Initialized
INFO - 2018-04-08 12:03:25 --> Router Class Initialized
INFO - 2018-04-08 12:03:25 --> Output Class Initialized
INFO - 2018-04-08 12:03:25 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:25 --> Input Class Initialized
INFO - 2018-04-08 12:03:25 --> Language Class Initialized
INFO - 2018-04-08 12:03:25 --> Loader Class Initialized
INFO - 2018-04-08 12:03:25 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:25 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:25 --> Email Class Initialized
INFO - 2018-04-08 12:03:25 --> Controller Class Initialized
INFO - 2018-04-08 12:03:25 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:25 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:25 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:25 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:25 --> Model Class Initialized
INFO - 2018-04-08 12:03:25 --> Model Class Initialized
INFO - 2018-04-08 12:03:25 --> Model Class Initialized
INFO - 2018-04-08 12:03:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:03:25 --> Final output sent to browser
DEBUG - 2018-04-08 12:03:25 --> Total execution time: 0.1290
INFO - 2018-04-08 12:03:27 --> Config Class Initialized
INFO - 2018-04-08 12:03:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:27 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:27 --> URI Class Initialized
INFO - 2018-04-08 12:03:27 --> Router Class Initialized
INFO - 2018-04-08 12:03:27 --> Output Class Initialized
INFO - 2018-04-08 12:03:27 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:27 --> Input Class Initialized
INFO - 2018-04-08 12:03:27 --> Language Class Initialized
INFO - 2018-04-08 12:03:27 --> Loader Class Initialized
INFO - 2018-04-08 12:03:27 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:28 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:28 --> Email Class Initialized
INFO - 2018-04-08 12:03:28 --> Controller Class Initialized
INFO - 2018-04-08 12:03:28 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:28 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:28 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:28 --> Model Class Initialized
INFO - 2018-04-08 12:03:28 --> Model Class Initialized
INFO - 2018-04-08 12:03:28 --> Model Class Initialized
DEBUG - 2018-04-08 12:03:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:03:42 --> Config Class Initialized
INFO - 2018-04-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:42 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:42 --> URI Class Initialized
INFO - 2018-04-08 12:03:42 --> Router Class Initialized
INFO - 2018-04-08 12:03:42 --> Output Class Initialized
INFO - 2018-04-08 12:03:42 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:42 --> Input Class Initialized
INFO - 2018-04-08 12:03:42 --> Language Class Initialized
INFO - 2018-04-08 12:03:42 --> Loader Class Initialized
INFO - 2018-04-08 12:03:42 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:42 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:42 --> Email Class Initialized
INFO - 2018-04-08 12:03:42 --> Controller Class Initialized
INFO - 2018-04-08 12:03:42 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:42 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:42 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:42 --> Model Class Initialized
INFO - 2018-04-08 12:03:42 --> Model Class Initialized
INFO - 2018-04-08 12:03:42 --> Model Class Initialized
DEBUG - 2018-04-08 12:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:03:42 --> Config Class Initialized
INFO - 2018-04-08 12:03:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:42 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:42 --> URI Class Initialized
INFO - 2018-04-08 12:03:42 --> Router Class Initialized
INFO - 2018-04-08 12:03:42 --> Output Class Initialized
INFO - 2018-04-08 12:03:42 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:42 --> Input Class Initialized
INFO - 2018-04-08 12:03:42 --> Language Class Initialized
INFO - 2018-04-08 12:03:42 --> Loader Class Initialized
INFO - 2018-04-08 12:03:42 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:42 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:42 --> Email Class Initialized
INFO - 2018-04-08 12:03:42 --> Controller Class Initialized
INFO - 2018-04-08 12:03:42 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:42 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:42 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:42 --> Model Class Initialized
INFO - 2018-04-08 12:03:42 --> Model Class Initialized
INFO - 2018-04-08 12:03:42 --> Model Class Initialized
INFO - 2018-04-08 12:03:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:03:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:03:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:03:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:03:42 --> Final output sent to browser
DEBUG - 2018-04-08 12:03:42 --> Total execution time: 0.1190
INFO - 2018-04-08 12:03:49 --> Config Class Initialized
INFO - 2018-04-08 12:03:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:49 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:49 --> URI Class Initialized
INFO - 2018-04-08 12:03:49 --> Router Class Initialized
INFO - 2018-04-08 12:03:49 --> Output Class Initialized
INFO - 2018-04-08 12:03:49 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:49 --> Input Class Initialized
INFO - 2018-04-08 12:03:49 --> Language Class Initialized
INFO - 2018-04-08 12:03:49 --> Loader Class Initialized
INFO - 2018-04-08 12:03:49 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:49 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:49 --> Email Class Initialized
INFO - 2018-04-08 12:03:49 --> Controller Class Initialized
INFO - 2018-04-08 12:03:49 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:49 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:49 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:49 --> Model Class Initialized
INFO - 2018-04-08 12:03:49 --> Model Class Initialized
INFO - 2018-04-08 12:03:49 --> Model Class Initialized
INFO - 2018-04-08 12:03:49 --> Config Class Initialized
INFO - 2018-04-08 12:03:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:49 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:49 --> URI Class Initialized
DEBUG - 2018-04-08 12:03:49 --> No URI present. Default controller set.
INFO - 2018-04-08 12:03:49 --> Router Class Initialized
INFO - 2018-04-08 12:03:49 --> Output Class Initialized
INFO - 2018-04-08 12:03:49 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:49 --> Input Class Initialized
INFO - 2018-04-08 12:03:49 --> Language Class Initialized
INFO - 2018-04-08 12:03:49 --> Loader Class Initialized
INFO - 2018-04-08 12:03:49 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:49 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:49 --> Email Class Initialized
INFO - 2018-04-08 12:03:49 --> Controller Class Initialized
INFO - 2018-04-08 12:03:49 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:49 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:49 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:49 --> Model Class Initialized
INFO - 2018-04-08 12:03:49 --> Model Class Initialized
INFO - 2018-04-08 12:03:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:03:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:03:49 --> Final output sent to browser
DEBUG - 2018-04-08 12:03:49 --> Total execution time: 0.2770
INFO - 2018-04-08 12:03:55 --> Config Class Initialized
INFO - 2018-04-08 12:03:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:55 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:55 --> URI Class Initialized
INFO - 2018-04-08 12:03:55 --> Router Class Initialized
INFO - 2018-04-08 12:03:55 --> Output Class Initialized
INFO - 2018-04-08 12:03:55 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:55 --> Input Class Initialized
INFO - 2018-04-08 12:03:55 --> Language Class Initialized
INFO - 2018-04-08 12:03:55 --> Loader Class Initialized
INFO - 2018-04-08 12:03:55 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:55 --> Database Driver Class Initialized
ERROR - 2018-04-08 12:03:55 --> mysqli::real_connect(): MySQL server has gone away
ERROR - 2018-04-08 12:03:55 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\FlickNews\admin\system\database\drivers\mysqli\mysqli_driver.php 135
INFO - 2018-04-08 12:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:55 --> Email Class Initialized
INFO - 2018-04-08 12:03:55 --> Controller Class Initialized
INFO - 2018-04-08 12:03:55 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:55 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:55 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:55 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:55 --> Model Class Initialized
INFO - 2018-04-08 12:03:55 --> Model Class Initialized
INFO - 2018-04-08 12:03:55 --> Model Class Initialized
INFO - 2018-04-08 12:03:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:03:55 --> Final output sent to browser
DEBUG - 2018-04-08 12:03:55 --> Total execution time: 0.2280
INFO - 2018-04-08 12:03:55 --> Config Class Initialized
INFO - 2018-04-08 12:03:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:03:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:03:55 --> Utf8 Class Initialized
INFO - 2018-04-08 12:03:55 --> URI Class Initialized
INFO - 2018-04-08 12:03:55 --> Router Class Initialized
INFO - 2018-04-08 12:03:55 --> Output Class Initialized
INFO - 2018-04-08 12:03:55 --> Security Class Initialized
DEBUG - 2018-04-08 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:03:55 --> Input Class Initialized
INFO - 2018-04-08 12:03:55 --> Language Class Initialized
INFO - 2018-04-08 12:03:55 --> Loader Class Initialized
INFO - 2018-04-08 12:03:55 --> Helper loaded: common_helper
INFO - 2018-04-08 12:03:55 --> Database Driver Class Initialized
INFO - 2018-04-08 12:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:03:55 --> Email Class Initialized
INFO - 2018-04-08 12:03:55 --> Controller Class Initialized
INFO - 2018-04-08 12:03:55 --> Helper loaded: form_helper
INFO - 2018-04-08 12:03:55 --> Form Validation Class Initialized
INFO - 2018-04-08 12:03:55 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:03:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:03:55 --> Helper loaded: url_helper
INFO - 2018-04-08 12:03:55 --> Model Class Initialized
INFO - 2018-04-08 12:03:55 --> Model Class Initialized
INFO - 2018-04-08 12:03:55 --> Model Class Initialized
INFO - 2018-04-08 12:03:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:03:55 --> Final output sent to browser
DEBUG - 2018-04-08 12:03:55 --> Total execution time: 0.1240
INFO - 2018-04-08 12:04:00 --> Config Class Initialized
INFO - 2018-04-08 12:04:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:04:00 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:04:00 --> Utf8 Class Initialized
INFO - 2018-04-08 12:04:00 --> URI Class Initialized
INFO - 2018-04-08 12:04:00 --> Router Class Initialized
INFO - 2018-04-08 12:04:00 --> Output Class Initialized
INFO - 2018-04-08 12:04:00 --> Security Class Initialized
DEBUG - 2018-04-08 12:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:04:00 --> Input Class Initialized
INFO - 2018-04-08 12:04:00 --> Language Class Initialized
INFO - 2018-04-08 12:04:00 --> Loader Class Initialized
INFO - 2018-04-08 12:04:00 --> Helper loaded: common_helper
INFO - 2018-04-08 12:04:00 --> Database Driver Class Initialized
INFO - 2018-04-08 12:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:04:00 --> Email Class Initialized
INFO - 2018-04-08 12:04:00 --> Controller Class Initialized
INFO - 2018-04-08 12:04:00 --> Helper loaded: form_helper
INFO - 2018-04-08 12:04:00 --> Form Validation Class Initialized
INFO - 2018-04-08 12:04:00 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:04:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:04:00 --> Helper loaded: url_helper
INFO - 2018-04-08 12:04:00 --> Model Class Initialized
INFO - 2018-04-08 12:04:00 --> Model Class Initialized
INFO - 2018-04-08 12:04:00 --> Model Class Initialized
DEBUG - 2018-04-08 12:04:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:04:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 12:04:00 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 12:04:00 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 12:04:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:04:00 --> Final output sent to browser
DEBUG - 2018-04-08 12:04:00 --> Total execution time: 0.2010
INFO - 2018-04-08 12:08:36 --> Config Class Initialized
INFO - 2018-04-08 12:08:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:08:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:08:36 --> Utf8 Class Initialized
INFO - 2018-04-08 12:08:36 --> URI Class Initialized
INFO - 2018-04-08 12:08:36 --> Router Class Initialized
INFO - 2018-04-08 12:08:36 --> Output Class Initialized
INFO - 2018-04-08 12:08:36 --> Security Class Initialized
DEBUG - 2018-04-08 12:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:08:36 --> Input Class Initialized
INFO - 2018-04-08 12:08:36 --> Language Class Initialized
INFO - 2018-04-08 12:08:36 --> Loader Class Initialized
INFO - 2018-04-08 12:08:36 --> Helper loaded: common_helper
INFO - 2018-04-08 12:08:36 --> Database Driver Class Initialized
INFO - 2018-04-08 12:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:08:36 --> Email Class Initialized
INFO - 2018-04-08 12:08:36 --> Controller Class Initialized
INFO - 2018-04-08 12:08:36 --> Helper loaded: form_helper
INFO - 2018-04-08 12:08:36 --> Form Validation Class Initialized
INFO - 2018-04-08 12:08:36 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:08:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:08:36 --> Helper loaded: url_helper
INFO - 2018-04-08 12:08:36 --> Model Class Initialized
INFO - 2018-04-08 12:08:36 --> Model Class Initialized
INFO - 2018-04-08 12:08:36 --> Model Class Initialized
INFO - 2018-04-08 12:08:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:08:36 --> Final output sent to browser
DEBUG - 2018-04-08 12:08:36 --> Total execution time: 0.1360
INFO - 2018-04-08 12:08:37 --> Config Class Initialized
INFO - 2018-04-08 12:08:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:08:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:08:37 --> Utf8 Class Initialized
INFO - 2018-04-08 12:08:37 --> URI Class Initialized
INFO - 2018-04-08 12:08:37 --> Router Class Initialized
INFO - 2018-04-08 12:08:37 --> Output Class Initialized
INFO - 2018-04-08 12:08:37 --> Security Class Initialized
DEBUG - 2018-04-08 12:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:08:37 --> Input Class Initialized
INFO - 2018-04-08 12:08:37 --> Language Class Initialized
INFO - 2018-04-08 12:08:37 --> Loader Class Initialized
INFO - 2018-04-08 12:08:37 --> Helper loaded: common_helper
INFO - 2018-04-08 12:08:37 --> Database Driver Class Initialized
INFO - 2018-04-08 12:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:08:38 --> Email Class Initialized
INFO - 2018-04-08 12:08:38 --> Controller Class Initialized
INFO - 2018-04-08 12:08:38 --> Helper loaded: form_helper
INFO - 2018-04-08 12:08:38 --> Form Validation Class Initialized
INFO - 2018-04-08 12:08:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:08:38 --> Helper loaded: url_helper
INFO - 2018-04-08 12:08:38 --> Model Class Initialized
INFO - 2018-04-08 12:08:38 --> Model Class Initialized
INFO - 2018-04-08 12:08:38 --> Model Class Initialized
INFO - 2018-04-08 12:08:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:08:38 --> Final output sent to browser
DEBUG - 2018-04-08 12:08:38 --> Total execution time: 0.1280
INFO - 2018-04-08 12:08:44 --> Config Class Initialized
INFO - 2018-04-08 12:08:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:08:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:08:44 --> Utf8 Class Initialized
INFO - 2018-04-08 12:08:44 --> URI Class Initialized
INFO - 2018-04-08 12:08:44 --> Router Class Initialized
INFO - 2018-04-08 12:08:44 --> Output Class Initialized
INFO - 2018-04-08 12:08:44 --> Security Class Initialized
DEBUG - 2018-04-08 12:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:08:44 --> Input Class Initialized
INFO - 2018-04-08 12:08:44 --> Language Class Initialized
INFO - 2018-04-08 12:08:44 --> Loader Class Initialized
INFO - 2018-04-08 12:08:44 --> Helper loaded: common_helper
INFO - 2018-04-08 12:08:44 --> Database Driver Class Initialized
INFO - 2018-04-08 12:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:08:44 --> Email Class Initialized
INFO - 2018-04-08 12:08:44 --> Controller Class Initialized
INFO - 2018-04-08 12:08:44 --> Helper loaded: form_helper
INFO - 2018-04-08 12:08:44 --> Form Validation Class Initialized
INFO - 2018-04-08 12:08:44 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:08:44 --> Helper loaded: url_helper
INFO - 2018-04-08 12:08:44 --> Model Class Initialized
INFO - 2018-04-08 12:08:44 --> Model Class Initialized
INFO - 2018-04-08 12:08:44 --> Model Class Initialized
DEBUG - 2018-04-08 12:08:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:08:44 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 12:08:44 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 12:08:44 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 12:13:14 --> Config Class Initialized
INFO - 2018-04-08 12:13:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:13:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:13:14 --> Utf8 Class Initialized
INFO - 2018-04-08 12:13:14 --> URI Class Initialized
INFO - 2018-04-08 12:13:14 --> Router Class Initialized
INFO - 2018-04-08 12:13:14 --> Output Class Initialized
INFO - 2018-04-08 12:13:14 --> Security Class Initialized
DEBUG - 2018-04-08 12:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:13:14 --> Input Class Initialized
INFO - 2018-04-08 12:13:14 --> Language Class Initialized
INFO - 2018-04-08 12:13:14 --> Loader Class Initialized
INFO - 2018-04-08 12:13:14 --> Helper loaded: common_helper
INFO - 2018-04-08 12:13:14 --> Database Driver Class Initialized
INFO - 2018-04-08 12:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:13:14 --> Email Class Initialized
INFO - 2018-04-08 12:13:14 --> Controller Class Initialized
INFO - 2018-04-08 12:13:14 --> Helper loaded: form_helper
INFO - 2018-04-08 12:13:14 --> Form Validation Class Initialized
INFO - 2018-04-08 12:13:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:13:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:13:14 --> Helper loaded: url_helper
INFO - 2018-04-08 12:13:14 --> Model Class Initialized
INFO - 2018-04-08 12:13:14 --> Model Class Initialized
INFO - 2018-04-08 12:13:14 --> Model Class Initialized
INFO - 2018-04-08 12:13:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:13:15 --> Final output sent to browser
DEBUG - 2018-04-08 12:13:15 --> Total execution time: 0.1280
INFO - 2018-04-08 12:13:16 --> Config Class Initialized
INFO - 2018-04-08 12:13:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:13:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:13:16 --> Utf8 Class Initialized
INFO - 2018-04-08 12:13:16 --> URI Class Initialized
INFO - 2018-04-08 12:13:16 --> Router Class Initialized
INFO - 2018-04-08 12:13:16 --> Output Class Initialized
INFO - 2018-04-08 12:13:16 --> Security Class Initialized
DEBUG - 2018-04-08 12:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:13:16 --> Input Class Initialized
INFO - 2018-04-08 12:13:16 --> Language Class Initialized
INFO - 2018-04-08 12:13:16 --> Loader Class Initialized
INFO - 2018-04-08 12:13:16 --> Helper loaded: common_helper
INFO - 2018-04-08 12:13:16 --> Database Driver Class Initialized
INFO - 2018-04-08 12:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:13:16 --> Email Class Initialized
INFO - 2018-04-08 12:13:16 --> Controller Class Initialized
INFO - 2018-04-08 12:13:16 --> Helper loaded: form_helper
INFO - 2018-04-08 12:13:16 --> Form Validation Class Initialized
INFO - 2018-04-08 12:13:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:13:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:13:16 --> Helper loaded: url_helper
INFO - 2018-04-08 12:13:16 --> Model Class Initialized
INFO - 2018-04-08 12:13:16 --> Model Class Initialized
INFO - 2018-04-08 12:13:16 --> Model Class Initialized
INFO - 2018-04-08 12:13:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:13:16 --> Final output sent to browser
DEBUG - 2018-04-08 12:13:16 --> Total execution time: 0.1250
INFO - 2018-04-08 12:13:21 --> Config Class Initialized
INFO - 2018-04-08 12:13:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:13:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:13:21 --> Utf8 Class Initialized
INFO - 2018-04-08 12:13:21 --> URI Class Initialized
INFO - 2018-04-08 12:13:21 --> Router Class Initialized
INFO - 2018-04-08 12:13:21 --> Output Class Initialized
INFO - 2018-04-08 12:13:21 --> Security Class Initialized
DEBUG - 2018-04-08 12:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:13:21 --> Input Class Initialized
INFO - 2018-04-08 12:13:21 --> Language Class Initialized
INFO - 2018-04-08 12:13:21 --> Loader Class Initialized
INFO - 2018-04-08 12:13:21 --> Helper loaded: common_helper
INFO - 2018-04-08 12:13:21 --> Database Driver Class Initialized
INFO - 2018-04-08 12:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:13:21 --> Email Class Initialized
INFO - 2018-04-08 12:13:21 --> Controller Class Initialized
INFO - 2018-04-08 12:13:21 --> Helper loaded: form_helper
INFO - 2018-04-08 12:13:21 --> Form Validation Class Initialized
INFO - 2018-04-08 12:13:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:13:21 --> Helper loaded: url_helper
INFO - 2018-04-08 12:13:21 --> Model Class Initialized
INFO - 2018-04-08 12:13:21 --> Model Class Initialized
INFO - 2018-04-08 12:13:21 --> Model Class Initialized
DEBUG - 2018-04-08 12:13:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:13:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 12:13:21 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 12:13:21 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 12:13:41 --> Config Class Initialized
INFO - 2018-04-08 12:13:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:13:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:13:41 --> Utf8 Class Initialized
INFO - 2018-04-08 12:13:41 --> URI Class Initialized
INFO - 2018-04-08 12:13:41 --> Router Class Initialized
INFO - 2018-04-08 12:13:41 --> Output Class Initialized
INFO - 2018-04-08 12:13:41 --> Security Class Initialized
DEBUG - 2018-04-08 12:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:13:41 --> Input Class Initialized
INFO - 2018-04-08 12:13:41 --> Language Class Initialized
INFO - 2018-04-08 12:13:41 --> Loader Class Initialized
INFO - 2018-04-08 12:13:41 --> Helper loaded: common_helper
INFO - 2018-04-08 12:13:41 --> Database Driver Class Initialized
INFO - 2018-04-08 12:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:13:41 --> Email Class Initialized
INFO - 2018-04-08 12:13:41 --> Controller Class Initialized
INFO - 2018-04-08 12:13:41 --> Helper loaded: form_helper
INFO - 2018-04-08 12:13:41 --> Form Validation Class Initialized
INFO - 2018-04-08 12:13:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:13:41 --> Helper loaded: url_helper
INFO - 2018-04-08 12:13:41 --> Model Class Initialized
INFO - 2018-04-08 12:13:41 --> Model Class Initialized
INFO - 2018-04-08 12:13:41 --> Model Class Initialized
ERROR - 2018-04-08 12:13:41 --> Trying to get property of non-object
ERROR - 2018-04-08 12:13:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:13:41 --> Final output sent to browser
DEBUG - 2018-04-08 12:13:41 --> Total execution time: 0.1210
INFO - 2018-04-08 12:13:41 --> Config Class Initialized
INFO - 2018-04-08 12:13:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:13:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:13:41 --> Utf8 Class Initialized
INFO - 2018-04-08 12:13:41 --> URI Class Initialized
INFO - 2018-04-08 12:13:41 --> Router Class Initialized
INFO - 2018-04-08 12:13:41 --> Output Class Initialized
INFO - 2018-04-08 12:13:41 --> Security Class Initialized
DEBUG - 2018-04-08 12:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:13:41 --> Input Class Initialized
INFO - 2018-04-08 12:13:41 --> Language Class Initialized
INFO - 2018-04-08 12:13:41 --> Loader Class Initialized
INFO - 2018-04-08 12:13:41 --> Helper loaded: common_helper
INFO - 2018-04-08 12:13:41 --> Database Driver Class Initialized
INFO - 2018-04-08 12:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:13:41 --> Email Class Initialized
INFO - 2018-04-08 12:13:41 --> Controller Class Initialized
INFO - 2018-04-08 12:13:41 --> Helper loaded: form_helper
INFO - 2018-04-08 12:13:41 --> Form Validation Class Initialized
INFO - 2018-04-08 12:13:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:13:41 --> Helper loaded: url_helper
INFO - 2018-04-08 12:13:41 --> Model Class Initialized
INFO - 2018-04-08 12:13:41 --> Model Class Initialized
INFO - 2018-04-08 12:13:41 --> Model Class Initialized
ERROR - 2018-04-08 12:13:41 --> Trying to get property of non-object
ERROR - 2018-04-08 12:13:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:13:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:13:41 --> Final output sent to browser
DEBUG - 2018-04-08 12:13:41 --> Total execution time: 0.1190
INFO - 2018-04-08 12:14:37 --> Config Class Initialized
INFO - 2018-04-08 12:14:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:37 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:37 --> URI Class Initialized
INFO - 2018-04-08 12:14:37 --> Router Class Initialized
INFO - 2018-04-08 12:14:37 --> Output Class Initialized
INFO - 2018-04-08 12:14:37 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:37 --> Input Class Initialized
INFO - 2018-04-08 12:14:37 --> Language Class Initialized
INFO - 2018-04-08 12:14:37 --> Loader Class Initialized
INFO - 2018-04-08 12:14:37 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:37 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:37 --> Email Class Initialized
INFO - 2018-04-08 12:14:37 --> Controller Class Initialized
INFO - 2018-04-08 12:14:37 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:37 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:37 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:37 --> Model Class Initialized
INFO - 2018-04-08 12:14:37 --> Model Class Initialized
INFO - 2018-04-08 12:14:37 --> Model Class Initialized
INFO - 2018-04-08 12:14:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:14:37 --> Final output sent to browser
DEBUG - 2018-04-08 12:14:37 --> Total execution time: 0.1210
INFO - 2018-04-08 12:14:39 --> Config Class Initialized
INFO - 2018-04-08 12:14:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:39 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:39 --> URI Class Initialized
INFO - 2018-04-08 12:14:39 --> Router Class Initialized
INFO - 2018-04-08 12:14:39 --> Output Class Initialized
INFO - 2018-04-08 12:14:39 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:39 --> Input Class Initialized
INFO - 2018-04-08 12:14:39 --> Language Class Initialized
INFO - 2018-04-08 12:14:39 --> Loader Class Initialized
INFO - 2018-04-08 12:14:39 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:39 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:39 --> Email Class Initialized
INFO - 2018-04-08 12:14:39 --> Controller Class Initialized
INFO - 2018-04-08 12:14:39 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:39 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:39 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:39 --> Model Class Initialized
INFO - 2018-04-08 12:14:39 --> Model Class Initialized
INFO - 2018-04-08 12:14:39 --> Model Class Initialized
DEBUG - 2018-04-08 12:14:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:14:40 --> Config Class Initialized
INFO - 2018-04-08 12:14:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:40 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:40 --> URI Class Initialized
INFO - 2018-04-08 12:14:40 --> Router Class Initialized
INFO - 2018-04-08 12:14:40 --> Output Class Initialized
INFO - 2018-04-08 12:14:40 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:40 --> Input Class Initialized
INFO - 2018-04-08 12:14:40 --> Language Class Initialized
INFO - 2018-04-08 12:14:40 --> Loader Class Initialized
INFO - 2018-04-08 12:14:40 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:40 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:40 --> Email Class Initialized
INFO - 2018-04-08 12:14:40 --> Controller Class Initialized
INFO - 2018-04-08 12:14:40 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:40 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:40 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:40 --> Model Class Initialized
INFO - 2018-04-08 12:14:40 --> Model Class Initialized
INFO - 2018-04-08 12:14:40 --> Model Class Initialized
INFO - 2018-04-08 12:14:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:14:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:14:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:14:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:14:40 --> Final output sent to browser
DEBUG - 2018-04-08 12:14:40 --> Total execution time: 0.1300
INFO - 2018-04-08 12:14:47 --> Config Class Initialized
INFO - 2018-04-08 12:14:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:47 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:47 --> URI Class Initialized
INFO - 2018-04-08 12:14:47 --> Router Class Initialized
INFO - 2018-04-08 12:14:47 --> Output Class Initialized
INFO - 2018-04-08 12:14:47 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:47 --> Input Class Initialized
INFO - 2018-04-08 12:14:47 --> Language Class Initialized
INFO - 2018-04-08 12:14:47 --> Loader Class Initialized
INFO - 2018-04-08 12:14:47 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:47 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:47 --> Email Class Initialized
INFO - 2018-04-08 12:14:47 --> Controller Class Initialized
INFO - 2018-04-08 12:14:47 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:47 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:47 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:47 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:47 --> Model Class Initialized
INFO - 2018-04-08 12:14:47 --> Model Class Initialized
INFO - 2018-04-08 12:14:47 --> Model Class Initialized
INFO - 2018-04-08 12:14:47 --> Config Class Initialized
INFO - 2018-04-08 12:14:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:47 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:47 --> URI Class Initialized
DEBUG - 2018-04-08 12:14:47 --> No URI present. Default controller set.
INFO - 2018-04-08 12:14:47 --> Router Class Initialized
INFO - 2018-04-08 12:14:47 --> Output Class Initialized
INFO - 2018-04-08 12:14:47 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:47 --> Input Class Initialized
INFO - 2018-04-08 12:14:47 --> Language Class Initialized
INFO - 2018-04-08 12:14:47 --> Loader Class Initialized
INFO - 2018-04-08 12:14:47 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:47 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:47 --> Email Class Initialized
INFO - 2018-04-08 12:14:47 --> Controller Class Initialized
INFO - 2018-04-08 12:14:47 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:47 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:47 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:47 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:47 --> Model Class Initialized
INFO - 2018-04-08 12:14:47 --> Model Class Initialized
INFO - 2018-04-08 12:14:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:14:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:14:47 --> Final output sent to browser
DEBUG - 2018-04-08 12:14:47 --> Total execution time: 0.1100
INFO - 2018-04-08 12:14:52 --> Config Class Initialized
INFO - 2018-04-08 12:14:52 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:52 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:52 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:52 --> URI Class Initialized
INFO - 2018-04-08 12:14:52 --> Router Class Initialized
INFO - 2018-04-08 12:14:52 --> Output Class Initialized
INFO - 2018-04-08 12:14:52 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:52 --> Input Class Initialized
INFO - 2018-04-08 12:14:52 --> Language Class Initialized
INFO - 2018-04-08 12:14:53 --> Loader Class Initialized
INFO - 2018-04-08 12:14:53 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:53 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:53 --> Email Class Initialized
INFO - 2018-04-08 12:14:53 --> Controller Class Initialized
INFO - 2018-04-08 12:14:53 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:53 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:53 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:53 --> Model Class Initialized
INFO - 2018-04-08 12:14:53 --> Model Class Initialized
INFO - 2018-04-08 12:14:53 --> Model Class Initialized
INFO - 2018-04-08 12:14:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:14:53 --> Final output sent to browser
DEBUG - 2018-04-08 12:14:53 --> Total execution time: 0.1640
INFO - 2018-04-08 12:14:59 --> Config Class Initialized
INFO - 2018-04-08 12:14:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:59 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:59 --> URI Class Initialized
INFO - 2018-04-08 12:14:59 --> Router Class Initialized
INFO - 2018-04-08 12:14:59 --> Output Class Initialized
INFO - 2018-04-08 12:14:59 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:59 --> Input Class Initialized
INFO - 2018-04-08 12:14:59 --> Language Class Initialized
INFO - 2018-04-08 12:14:59 --> Loader Class Initialized
INFO - 2018-04-08 12:14:59 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:59 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:59 --> Email Class Initialized
INFO - 2018-04-08 12:14:59 --> Controller Class Initialized
INFO - 2018-04-08 12:14:59 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:59 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:59 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:59 --> Model Class Initialized
INFO - 2018-04-08 12:14:59 --> Model Class Initialized
INFO - 2018-04-08 12:14:59 --> Model Class Initialized
DEBUG - 2018-04-08 12:14:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 12:14:59 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 12:14:59 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 12:14:59 --> Config Class Initialized
INFO - 2018-04-08 12:14:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:14:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:14:59 --> Utf8 Class Initialized
INFO - 2018-04-08 12:14:59 --> URI Class Initialized
INFO - 2018-04-08 12:14:59 --> Router Class Initialized
INFO - 2018-04-08 12:14:59 --> Output Class Initialized
INFO - 2018-04-08 12:14:59 --> Security Class Initialized
DEBUG - 2018-04-08 12:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:14:59 --> Input Class Initialized
INFO - 2018-04-08 12:14:59 --> Language Class Initialized
INFO - 2018-04-08 12:14:59 --> Loader Class Initialized
INFO - 2018-04-08 12:14:59 --> Helper loaded: common_helper
INFO - 2018-04-08 12:14:59 --> Database Driver Class Initialized
INFO - 2018-04-08 12:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:14:59 --> Email Class Initialized
INFO - 2018-04-08 12:14:59 --> Controller Class Initialized
INFO - 2018-04-08 12:14:59 --> Helper loaded: form_helper
INFO - 2018-04-08 12:14:59 --> Form Validation Class Initialized
INFO - 2018-04-08 12:14:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:14:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:14:59 --> Helper loaded: url_helper
INFO - 2018-04-08 12:14:59 --> Model Class Initialized
INFO - 2018-04-08 12:14:59 --> Model Class Initialized
INFO - 2018-04-08 12:15:00 --> Model Class Initialized
ERROR - 2018-04-08 12:15:00 --> Trying to get property of non-object
ERROR - 2018-04-08 12:15:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:15:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:15:00 --> Final output sent to browser
DEBUG - 2018-04-08 12:15:00 --> Total execution time: 0.1190
INFO - 2018-04-08 12:15:00 --> Config Class Initialized
INFO - 2018-04-08 12:15:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:15:00 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:15:00 --> Utf8 Class Initialized
INFO - 2018-04-08 12:15:00 --> URI Class Initialized
INFO - 2018-04-08 12:15:00 --> Router Class Initialized
INFO - 2018-04-08 12:15:00 --> Output Class Initialized
INFO - 2018-04-08 12:15:00 --> Security Class Initialized
DEBUG - 2018-04-08 12:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:15:00 --> Input Class Initialized
INFO - 2018-04-08 12:15:00 --> Language Class Initialized
INFO - 2018-04-08 12:15:00 --> Loader Class Initialized
INFO - 2018-04-08 12:15:00 --> Helper loaded: common_helper
INFO - 2018-04-08 12:15:00 --> Database Driver Class Initialized
INFO - 2018-04-08 12:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:15:00 --> Email Class Initialized
INFO - 2018-04-08 12:15:00 --> Controller Class Initialized
INFO - 2018-04-08 12:15:00 --> Helper loaded: form_helper
INFO - 2018-04-08 12:15:00 --> Form Validation Class Initialized
INFO - 2018-04-08 12:15:00 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:15:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:15:00 --> Helper loaded: url_helper
INFO - 2018-04-08 12:15:00 --> Model Class Initialized
INFO - 2018-04-08 12:15:00 --> Model Class Initialized
INFO - 2018-04-08 12:15:00 --> Model Class Initialized
ERROR - 2018-04-08 12:15:00 --> Trying to get property of non-object
ERROR - 2018-04-08 12:15:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:15:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:15:00 --> Final output sent to browser
DEBUG - 2018-04-08 12:15:00 --> Total execution time: 0.1250
INFO - 2018-04-08 12:39:14 --> Config Class Initialized
INFO - 2018-04-08 12:39:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:39:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:39:14 --> Utf8 Class Initialized
INFO - 2018-04-08 12:39:14 --> URI Class Initialized
DEBUG - 2018-04-08 12:39:14 --> No URI present. Default controller set.
INFO - 2018-04-08 12:39:14 --> Router Class Initialized
INFO - 2018-04-08 12:39:14 --> Output Class Initialized
INFO - 2018-04-08 12:39:14 --> Security Class Initialized
DEBUG - 2018-04-08 12:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:39:14 --> Input Class Initialized
INFO - 2018-04-08 12:39:14 --> Language Class Initialized
INFO - 2018-04-08 12:39:14 --> Loader Class Initialized
INFO - 2018-04-08 12:39:14 --> Helper loaded: common_helper
INFO - 2018-04-08 12:39:14 --> Database Driver Class Initialized
INFO - 2018-04-08 12:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:39:14 --> Email Class Initialized
INFO - 2018-04-08 12:39:14 --> Controller Class Initialized
INFO - 2018-04-08 12:39:14 --> Helper loaded: form_helper
INFO - 2018-04-08 12:39:14 --> Form Validation Class Initialized
INFO - 2018-04-08 12:39:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:39:14 --> Helper loaded: url_helper
INFO - 2018-04-08 12:39:14 --> Model Class Initialized
INFO - 2018-04-08 12:39:14 --> Model Class Initialized
INFO - 2018-04-08 12:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:39:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:39:14 --> Final output sent to browser
DEBUG - 2018-04-08 12:39:14 --> Total execution time: 0.0620
INFO - 2018-04-08 12:39:19 --> Config Class Initialized
INFO - 2018-04-08 12:39:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:39:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:39:19 --> Utf8 Class Initialized
INFO - 2018-04-08 12:39:19 --> URI Class Initialized
DEBUG - 2018-04-08 12:39:19 --> No URI present. Default controller set.
INFO - 2018-04-08 12:39:19 --> Router Class Initialized
INFO - 2018-04-08 12:39:19 --> Output Class Initialized
INFO - 2018-04-08 12:39:19 --> Security Class Initialized
DEBUG - 2018-04-08 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:39:19 --> Input Class Initialized
INFO - 2018-04-08 12:39:19 --> Language Class Initialized
INFO - 2018-04-08 12:39:19 --> Loader Class Initialized
INFO - 2018-04-08 12:39:19 --> Helper loaded: common_helper
INFO - 2018-04-08 12:39:19 --> Database Driver Class Initialized
INFO - 2018-04-08 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:39:19 --> Email Class Initialized
INFO - 2018-04-08 12:39:19 --> Controller Class Initialized
INFO - 2018-04-08 12:39:19 --> Helper loaded: form_helper
INFO - 2018-04-08 12:39:19 --> Form Validation Class Initialized
INFO - 2018-04-08 12:39:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:39:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:39:19 --> Helper loaded: url_helper
INFO - 2018-04-08 12:39:19 --> Model Class Initialized
INFO - 2018-04-08 12:39:19 --> Model Class Initialized
INFO - 2018-04-08 12:39:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:39:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:39:19 --> Final output sent to browser
DEBUG - 2018-04-08 12:39:19 --> Total execution time: 0.0670
INFO - 2018-04-08 12:39:22 --> Config Class Initialized
INFO - 2018-04-08 12:39:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:39:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:39:23 --> Utf8 Class Initialized
INFO - 2018-04-08 12:39:23 --> URI Class Initialized
INFO - 2018-04-08 12:39:23 --> Router Class Initialized
INFO - 2018-04-08 12:39:23 --> Output Class Initialized
INFO - 2018-04-08 12:39:23 --> Security Class Initialized
DEBUG - 2018-04-08 12:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:39:23 --> Input Class Initialized
INFO - 2018-04-08 12:39:23 --> Language Class Initialized
INFO - 2018-04-08 12:39:23 --> Loader Class Initialized
INFO - 2018-04-08 12:39:23 --> Helper loaded: common_helper
INFO - 2018-04-08 12:39:23 --> Database Driver Class Initialized
INFO - 2018-04-08 12:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:39:23 --> Email Class Initialized
INFO - 2018-04-08 12:39:23 --> Controller Class Initialized
INFO - 2018-04-08 12:39:23 --> Helper loaded: form_helper
INFO - 2018-04-08 12:39:23 --> Form Validation Class Initialized
INFO - 2018-04-08 12:39:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:39:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:39:23 --> Helper loaded: url_helper
INFO - 2018-04-08 12:39:23 --> Model Class Initialized
INFO - 2018-04-08 12:39:23 --> Model Class Initialized
INFO - 2018-04-08 12:39:23 --> Model Class Initialized
INFO - 2018-04-08 12:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:39:23 --> Final output sent to browser
DEBUG - 2018-04-08 12:39:23 --> Total execution time: 0.0800
INFO - 2018-04-08 12:39:39 --> Config Class Initialized
INFO - 2018-04-08 12:39:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:39:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:39:39 --> Utf8 Class Initialized
INFO - 2018-04-08 12:39:39 --> URI Class Initialized
DEBUG - 2018-04-08 12:39:39 --> No URI present. Default controller set.
INFO - 2018-04-08 12:39:39 --> Router Class Initialized
INFO - 2018-04-08 12:39:39 --> Output Class Initialized
INFO - 2018-04-08 12:39:39 --> Security Class Initialized
DEBUG - 2018-04-08 12:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:39:39 --> Input Class Initialized
INFO - 2018-04-08 12:39:39 --> Language Class Initialized
INFO - 2018-04-08 12:39:39 --> Loader Class Initialized
INFO - 2018-04-08 12:39:39 --> Helper loaded: common_helper
INFO - 2018-04-08 12:39:39 --> Database Driver Class Initialized
INFO - 2018-04-08 12:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:39:39 --> Email Class Initialized
INFO - 2018-04-08 12:39:39 --> Controller Class Initialized
INFO - 2018-04-08 12:39:39 --> Helper loaded: form_helper
INFO - 2018-04-08 12:39:39 --> Form Validation Class Initialized
INFO - 2018-04-08 12:39:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:39:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:39:39 --> Helper loaded: url_helper
INFO - 2018-04-08 12:39:39 --> Model Class Initialized
INFO - 2018-04-08 12:39:39 --> Model Class Initialized
INFO - 2018-04-08 12:39:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:39:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:39:39 --> Final output sent to browser
DEBUG - 2018-04-08 12:39:39 --> Total execution time: 0.0770
INFO - 2018-04-08 12:40:10 --> Config Class Initialized
INFO - 2018-04-08 12:40:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:40:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:40:10 --> Utf8 Class Initialized
INFO - 2018-04-08 12:40:10 --> URI Class Initialized
INFO - 2018-04-08 12:40:10 --> Router Class Initialized
INFO - 2018-04-08 12:40:10 --> Output Class Initialized
INFO - 2018-04-08 12:40:10 --> Security Class Initialized
DEBUG - 2018-04-08 12:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:40:10 --> Input Class Initialized
INFO - 2018-04-08 12:40:10 --> Language Class Initialized
INFO - 2018-04-08 12:40:10 --> Loader Class Initialized
INFO - 2018-04-08 12:40:10 --> Helper loaded: common_helper
INFO - 2018-04-08 12:40:10 --> Database Driver Class Initialized
INFO - 2018-04-08 12:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:40:10 --> Email Class Initialized
INFO - 2018-04-08 12:40:10 --> Controller Class Initialized
INFO - 2018-04-08 12:40:10 --> Helper loaded: form_helper
INFO - 2018-04-08 12:40:10 --> Form Validation Class Initialized
INFO - 2018-04-08 12:40:10 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:10 --> Helper loaded: url_helper
INFO - 2018-04-08 12:40:10 --> Model Class Initialized
INFO - 2018-04-08 12:40:10 --> Model Class Initialized
INFO - 2018-04-08 12:40:10 --> Model Class Initialized
INFO - 2018-04-08 12:40:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:40:10 --> Final output sent to browser
DEBUG - 2018-04-08 12:40:10 --> Total execution time: 0.0740
INFO - 2018-04-08 12:40:14 --> Config Class Initialized
INFO - 2018-04-08 12:40:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:40:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:40:14 --> Utf8 Class Initialized
INFO - 2018-04-08 12:40:14 --> URI Class Initialized
INFO - 2018-04-08 12:40:14 --> Router Class Initialized
INFO - 2018-04-08 12:40:14 --> Output Class Initialized
INFO - 2018-04-08 12:40:14 --> Security Class Initialized
DEBUG - 2018-04-08 12:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:40:14 --> Input Class Initialized
INFO - 2018-04-08 12:40:14 --> Language Class Initialized
INFO - 2018-04-08 12:40:14 --> Loader Class Initialized
INFO - 2018-04-08 12:40:14 --> Helper loaded: common_helper
INFO - 2018-04-08 12:40:14 --> Database Driver Class Initialized
INFO - 2018-04-08 12:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:40:14 --> Email Class Initialized
INFO - 2018-04-08 12:40:14 --> Controller Class Initialized
INFO - 2018-04-08 12:40:14 --> Helper loaded: form_helper
INFO - 2018-04-08 12:40:14 --> Form Validation Class Initialized
INFO - 2018-04-08 12:40:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:14 --> Helper loaded: url_helper
INFO - 2018-04-08 12:40:14 --> Model Class Initialized
INFO - 2018-04-08 12:40:14 --> Model Class Initialized
INFO - 2018-04-08 12:40:14 --> Model Class Initialized
DEBUG - 2018-04-08 12:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 12:40:14 --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH'
ERROR - 2018-04-08 12:40:14 --> Severity: Notice --> Use of undefined constant EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH - assumed 'EMAIL_OR_NAME_AND_PASSWORD_NOT_MATCH' C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 207
INFO - 2018-04-08 12:40:14 --> Config Class Initialized
INFO - 2018-04-08 12:40:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:40:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:40:14 --> Utf8 Class Initialized
INFO - 2018-04-08 12:40:14 --> URI Class Initialized
DEBUG - 2018-04-08 12:40:14 --> No URI present. Default controller set.
INFO - 2018-04-08 12:40:14 --> Router Class Initialized
INFO - 2018-04-08 12:40:14 --> Output Class Initialized
INFO - 2018-04-08 12:40:14 --> Security Class Initialized
DEBUG - 2018-04-08 12:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:40:14 --> Input Class Initialized
INFO - 2018-04-08 12:40:14 --> Language Class Initialized
INFO - 2018-04-08 12:40:14 --> Loader Class Initialized
INFO - 2018-04-08 12:40:14 --> Helper loaded: common_helper
INFO - 2018-04-08 12:40:14 --> Database Driver Class Initialized
INFO - 2018-04-08 12:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:40:14 --> Email Class Initialized
INFO - 2018-04-08 12:40:14 --> Controller Class Initialized
INFO - 2018-04-08 12:40:14 --> Helper loaded: form_helper
INFO - 2018-04-08 12:40:14 --> Form Validation Class Initialized
INFO - 2018-04-08 12:40:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:40:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:14 --> Helper loaded: url_helper
INFO - 2018-04-08 12:40:14 --> Model Class Initialized
INFO - 2018-04-08 12:40:14 --> Model Class Initialized
INFO - 2018-04-08 12:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:40:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:40:14 --> Final output sent to browser
DEBUG - 2018-04-08 12:40:14 --> Total execution time: 0.0610
INFO - 2018-04-08 12:40:39 --> Config Class Initialized
INFO - 2018-04-08 12:40:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:40:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:40:39 --> Utf8 Class Initialized
INFO - 2018-04-08 12:40:39 --> URI Class Initialized
DEBUG - 2018-04-08 12:40:39 --> No URI present. Default controller set.
INFO - 2018-04-08 12:40:39 --> Router Class Initialized
INFO - 2018-04-08 12:40:39 --> Output Class Initialized
INFO - 2018-04-08 12:40:39 --> Security Class Initialized
DEBUG - 2018-04-08 12:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:40:39 --> Input Class Initialized
INFO - 2018-04-08 12:40:39 --> Language Class Initialized
INFO - 2018-04-08 12:40:39 --> Loader Class Initialized
INFO - 2018-04-08 12:40:39 --> Helper loaded: common_helper
INFO - 2018-04-08 12:40:39 --> Database Driver Class Initialized
INFO - 2018-04-08 12:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:40:40 --> Email Class Initialized
INFO - 2018-04-08 12:40:40 --> Controller Class Initialized
INFO - 2018-04-08 12:40:40 --> Helper loaded: form_helper
INFO - 2018-04-08 12:40:40 --> Form Validation Class Initialized
INFO - 2018-04-08 12:40:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:40 --> Helper loaded: url_helper
INFO - 2018-04-08 12:40:40 --> Model Class Initialized
INFO - 2018-04-08 12:40:40 --> Model Class Initialized
DEBUG - 2018-04-08 12:40:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:40:40 --> Config Class Initialized
INFO - 2018-04-08 12:40:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:40:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:40:40 --> Utf8 Class Initialized
INFO - 2018-04-08 12:40:40 --> URI Class Initialized
DEBUG - 2018-04-08 12:40:40 --> No URI present. Default controller set.
INFO - 2018-04-08 12:40:40 --> Router Class Initialized
INFO - 2018-04-08 12:40:40 --> Output Class Initialized
INFO - 2018-04-08 12:40:40 --> Security Class Initialized
DEBUG - 2018-04-08 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:40:40 --> Input Class Initialized
INFO - 2018-04-08 12:40:40 --> Language Class Initialized
INFO - 2018-04-08 12:40:40 --> Loader Class Initialized
INFO - 2018-04-08 12:40:40 --> Helper loaded: common_helper
INFO - 2018-04-08 12:40:40 --> Database Driver Class Initialized
INFO - 2018-04-08 12:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:40:40 --> Email Class Initialized
INFO - 2018-04-08 12:40:40 --> Controller Class Initialized
INFO - 2018-04-08 12:40:40 --> Helper loaded: form_helper
INFO - 2018-04-08 12:40:40 --> Form Validation Class Initialized
INFO - 2018-04-08 12:40:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:40:40 --> Helper loaded: url_helper
INFO - 2018-04-08 12:40:40 --> Model Class Initialized
INFO - 2018-04-08 12:40:40 --> Model Class Initialized
INFO - 2018-04-08 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:40:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:40:40 --> Final output sent to browser
DEBUG - 2018-04-08 12:40:40 --> Total execution time: 0.1110
INFO - 2018-04-08 12:42:44 --> Config Class Initialized
INFO - 2018-04-08 12:42:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:42:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:42:44 --> Utf8 Class Initialized
INFO - 2018-04-08 12:42:44 --> URI Class Initialized
INFO - 2018-04-08 12:42:44 --> Router Class Initialized
INFO - 2018-04-08 12:42:44 --> Output Class Initialized
INFO - 2018-04-08 12:42:44 --> Security Class Initialized
DEBUG - 2018-04-08 12:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:42:44 --> Input Class Initialized
INFO - 2018-04-08 12:42:44 --> Language Class Initialized
INFO - 2018-04-08 12:42:44 --> Loader Class Initialized
INFO - 2018-04-08 12:42:44 --> Helper loaded: common_helper
INFO - 2018-04-08 12:42:44 --> Database Driver Class Initialized
INFO - 2018-04-08 12:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:42:44 --> Email Class Initialized
INFO - 2018-04-08 12:42:44 --> Controller Class Initialized
INFO - 2018-04-08 12:42:45 --> Helper loaded: form_helper
INFO - 2018-04-08 12:42:45 --> Form Validation Class Initialized
INFO - 2018-04-08 12:42:45 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:42:45 --> Helper loaded: url_helper
INFO - 2018-04-08 12:42:45 --> Model Class Initialized
INFO - 2018-04-08 12:42:45 --> Model Class Initialized
INFO - 2018-04-08 12:42:45 --> Model Class Initialized
INFO - 2018-04-08 12:42:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:42:45 --> Final output sent to browser
DEBUG - 2018-04-08 12:42:45 --> Total execution time: 0.1440
INFO - 2018-04-08 12:42:49 --> Config Class Initialized
INFO - 2018-04-08 12:42:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:42:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:42:49 --> Utf8 Class Initialized
INFO - 2018-04-08 12:42:49 --> URI Class Initialized
INFO - 2018-04-08 12:42:49 --> Router Class Initialized
INFO - 2018-04-08 12:42:49 --> Output Class Initialized
INFO - 2018-04-08 12:42:49 --> Security Class Initialized
DEBUG - 2018-04-08 12:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:42:49 --> Input Class Initialized
INFO - 2018-04-08 12:42:49 --> Language Class Initialized
INFO - 2018-04-08 12:42:49 --> Loader Class Initialized
INFO - 2018-04-08 12:42:49 --> Helper loaded: common_helper
INFO - 2018-04-08 12:42:49 --> Database Driver Class Initialized
INFO - 2018-04-08 12:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:42:49 --> Email Class Initialized
INFO - 2018-04-08 12:42:49 --> Controller Class Initialized
INFO - 2018-04-08 12:42:49 --> Helper loaded: form_helper
INFO - 2018-04-08 12:42:49 --> Form Validation Class Initialized
INFO - 2018-04-08 12:42:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:42:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:42:49 --> Helper loaded: url_helper
INFO - 2018-04-08 12:42:49 --> Model Class Initialized
INFO - 2018-04-08 12:42:50 --> Model Class Initialized
INFO - 2018-04-08 12:42:50 --> Model Class Initialized
DEBUG - 2018-04-08 12:42:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:42:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:42:50 --> Config Class Initialized
INFO - 2018-04-08 12:42:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:42:50 --> Utf8 Class Initialized
INFO - 2018-04-08 12:42:50 --> URI Class Initialized
DEBUG - 2018-04-08 12:42:50 --> No URI present. Default controller set.
INFO - 2018-04-08 12:42:50 --> Router Class Initialized
INFO - 2018-04-08 12:42:50 --> Output Class Initialized
INFO - 2018-04-08 12:42:50 --> Security Class Initialized
DEBUG - 2018-04-08 12:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:42:50 --> Input Class Initialized
INFO - 2018-04-08 12:42:50 --> Language Class Initialized
INFO - 2018-04-08 12:42:50 --> Loader Class Initialized
INFO - 2018-04-08 12:42:50 --> Helper loaded: common_helper
INFO - 2018-04-08 12:42:50 --> Database Driver Class Initialized
INFO - 2018-04-08 12:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:42:50 --> Email Class Initialized
INFO - 2018-04-08 12:42:50 --> Controller Class Initialized
INFO - 2018-04-08 12:42:50 --> Helper loaded: form_helper
INFO - 2018-04-08 12:42:50 --> Form Validation Class Initialized
INFO - 2018-04-08 12:42:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:42:50 --> Helper loaded: url_helper
INFO - 2018-04-08 12:42:50 --> Model Class Initialized
INFO - 2018-04-08 12:42:50 --> Model Class Initialized
INFO - 2018-04-08 12:42:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:42:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:42:50 --> Final output sent to browser
DEBUG - 2018-04-08 12:42:50 --> Total execution time: 0.1080
INFO - 2018-04-08 12:43:31 --> Config Class Initialized
INFO - 2018-04-08 12:43:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:43:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:43:31 --> Utf8 Class Initialized
INFO - 2018-04-08 12:43:31 --> URI Class Initialized
INFO - 2018-04-08 12:43:31 --> Router Class Initialized
INFO - 2018-04-08 12:43:31 --> Output Class Initialized
INFO - 2018-04-08 12:43:31 --> Security Class Initialized
DEBUG - 2018-04-08 12:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:43:31 --> Input Class Initialized
INFO - 2018-04-08 12:43:31 --> Language Class Initialized
INFO - 2018-04-08 12:43:31 --> Loader Class Initialized
INFO - 2018-04-08 12:43:31 --> Helper loaded: common_helper
INFO - 2018-04-08 12:43:31 --> Database Driver Class Initialized
INFO - 2018-04-08 12:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:43:31 --> Email Class Initialized
INFO - 2018-04-08 12:43:31 --> Controller Class Initialized
INFO - 2018-04-08 12:43:31 --> Helper loaded: form_helper
INFO - 2018-04-08 12:43:31 --> Form Validation Class Initialized
INFO - 2018-04-08 12:43:31 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:43:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:31 --> Helper loaded: url_helper
INFO - 2018-04-08 12:43:31 --> Model Class Initialized
INFO - 2018-04-08 12:43:31 --> Model Class Initialized
INFO - 2018-04-08 12:43:31 --> Model Class Initialized
INFO - 2018-04-08 12:43:31 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:43:31 --> Final output sent to browser
DEBUG - 2018-04-08 12:43:31 --> Total execution time: 0.1470
INFO - 2018-04-08 12:43:42 --> Config Class Initialized
INFO - 2018-04-08 12:43:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:43:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:43:42 --> Utf8 Class Initialized
INFO - 2018-04-08 12:43:42 --> URI Class Initialized
INFO - 2018-04-08 12:43:42 --> Router Class Initialized
INFO - 2018-04-08 12:43:42 --> Output Class Initialized
INFO - 2018-04-08 12:43:42 --> Security Class Initialized
DEBUG - 2018-04-08 12:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:43:42 --> Input Class Initialized
INFO - 2018-04-08 12:43:42 --> Language Class Initialized
INFO - 2018-04-08 12:43:42 --> Loader Class Initialized
INFO - 2018-04-08 12:43:42 --> Helper loaded: common_helper
INFO - 2018-04-08 12:43:42 --> Database Driver Class Initialized
INFO - 2018-04-08 12:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:43:42 --> Email Class Initialized
INFO - 2018-04-08 12:43:42 --> Controller Class Initialized
INFO - 2018-04-08 12:43:42 --> Helper loaded: form_helper
INFO - 2018-04-08 12:43:42 --> Form Validation Class Initialized
INFO - 2018-04-08 12:43:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:42 --> Helper loaded: url_helper
INFO - 2018-04-08 12:43:42 --> Model Class Initialized
INFO - 2018-04-08 12:43:42 --> Model Class Initialized
INFO - 2018-04-08 12:43:42 --> Model Class Initialized
ERROR - 2018-04-08 12:43:42 --> Trying to get property of non-object
ERROR - 2018-04-08 12:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:43:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:43:42 --> Final output sent to browser
DEBUG - 2018-04-08 12:43:42 --> Total execution time: 0.1640
INFO - 2018-04-08 12:43:42 --> Config Class Initialized
INFO - 2018-04-08 12:43:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:43:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:43:42 --> Utf8 Class Initialized
INFO - 2018-04-08 12:43:42 --> URI Class Initialized
INFO - 2018-04-08 12:43:42 --> Router Class Initialized
INFO - 2018-04-08 12:43:42 --> Output Class Initialized
INFO - 2018-04-08 12:43:42 --> Security Class Initialized
DEBUG - 2018-04-08 12:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:43:42 --> Input Class Initialized
INFO - 2018-04-08 12:43:42 --> Language Class Initialized
INFO - 2018-04-08 12:43:42 --> Loader Class Initialized
INFO - 2018-04-08 12:43:42 --> Helper loaded: common_helper
INFO - 2018-04-08 12:43:42 --> Database Driver Class Initialized
INFO - 2018-04-08 12:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:43:42 --> Email Class Initialized
INFO - 2018-04-08 12:43:42 --> Controller Class Initialized
INFO - 2018-04-08 12:43:42 --> Helper loaded: form_helper
INFO - 2018-04-08 12:43:42 --> Form Validation Class Initialized
INFO - 2018-04-08 12:43:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:43:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:42 --> Helper loaded: url_helper
INFO - 2018-04-08 12:43:42 --> Model Class Initialized
INFO - 2018-04-08 12:43:42 --> Model Class Initialized
INFO - 2018-04-08 12:43:42 --> Model Class Initialized
ERROR - 2018-04-08 12:43:42 --> Trying to get property of non-object
ERROR - 2018-04-08 12:43:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:43:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:43:42 --> Final output sent to browser
DEBUG - 2018-04-08 12:43:42 --> Total execution time: 0.1500
INFO - 2018-04-08 12:43:53 --> Config Class Initialized
INFO - 2018-04-08 12:43:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:43:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:43:53 --> Utf8 Class Initialized
INFO - 2018-04-08 12:43:53 --> URI Class Initialized
DEBUG - 2018-04-08 12:43:53 --> No URI present. Default controller set.
INFO - 2018-04-08 12:43:53 --> Router Class Initialized
INFO - 2018-04-08 12:43:53 --> Output Class Initialized
INFO - 2018-04-08 12:43:53 --> Security Class Initialized
DEBUG - 2018-04-08 12:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:43:53 --> Input Class Initialized
INFO - 2018-04-08 12:43:53 --> Language Class Initialized
INFO - 2018-04-08 12:43:53 --> Loader Class Initialized
INFO - 2018-04-08 12:43:53 --> Helper loaded: common_helper
INFO - 2018-04-08 12:43:53 --> Database Driver Class Initialized
INFO - 2018-04-08 12:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:43:53 --> Email Class Initialized
INFO - 2018-04-08 12:43:53 --> Controller Class Initialized
INFO - 2018-04-08 12:43:53 --> Helper loaded: form_helper
INFO - 2018-04-08 12:43:53 --> Form Validation Class Initialized
INFO - 2018-04-08 12:43:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:53 --> Helper loaded: url_helper
INFO - 2018-04-08 12:43:53 --> Model Class Initialized
INFO - 2018-04-08 12:43:53 --> Model Class Initialized
INFO - 2018-04-08 12:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:43:53 --> Final output sent to browser
DEBUG - 2018-04-08 12:43:53 --> Total execution time: 0.1170
INFO - 2018-04-08 12:43:56 --> Config Class Initialized
INFO - 2018-04-08 12:43:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:43:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:43:56 --> Utf8 Class Initialized
INFO - 2018-04-08 12:43:56 --> URI Class Initialized
DEBUG - 2018-04-08 12:43:56 --> No URI present. Default controller set.
INFO - 2018-04-08 12:43:56 --> Router Class Initialized
INFO - 2018-04-08 12:43:56 --> Output Class Initialized
INFO - 2018-04-08 12:43:56 --> Security Class Initialized
DEBUG - 2018-04-08 12:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:43:56 --> Input Class Initialized
INFO - 2018-04-08 12:43:56 --> Language Class Initialized
INFO - 2018-04-08 12:43:56 --> Loader Class Initialized
INFO - 2018-04-08 12:43:56 --> Helper loaded: common_helper
INFO - 2018-04-08 12:43:56 --> Database Driver Class Initialized
INFO - 2018-04-08 12:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:43:56 --> Email Class Initialized
INFO - 2018-04-08 12:43:56 --> Controller Class Initialized
INFO - 2018-04-08 12:43:56 --> Helper loaded: form_helper
INFO - 2018-04-08 12:43:56 --> Form Validation Class Initialized
INFO - 2018-04-08 12:43:56 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:56 --> Helper loaded: url_helper
INFO - 2018-04-08 12:43:56 --> Model Class Initialized
INFO - 2018-04-08 12:43:56 --> Model Class Initialized
DEBUG - 2018-04-08 12:43:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:43:56 --> Config Class Initialized
INFO - 2018-04-08 12:43:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:43:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:43:56 --> Utf8 Class Initialized
INFO - 2018-04-08 12:43:56 --> URI Class Initialized
INFO - 2018-04-08 12:43:56 --> Router Class Initialized
INFO - 2018-04-08 12:43:56 --> Output Class Initialized
INFO - 2018-04-08 12:43:56 --> Security Class Initialized
DEBUG - 2018-04-08 12:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:43:56 --> Input Class Initialized
INFO - 2018-04-08 12:43:56 --> Language Class Initialized
INFO - 2018-04-08 12:43:56 --> Loader Class Initialized
INFO - 2018-04-08 12:43:56 --> Helper loaded: common_helper
INFO - 2018-04-08 12:43:56 --> Database Driver Class Initialized
INFO - 2018-04-08 12:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:43:56 --> Email Class Initialized
INFO - 2018-04-08 12:43:56 --> Controller Class Initialized
INFO - 2018-04-08 12:43:56 --> Helper loaded: form_helper
INFO - 2018-04-08 12:43:56 --> Form Validation Class Initialized
INFO - 2018-04-08 12:43:56 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:43:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:43:56 --> Helper loaded: url_helper
INFO - 2018-04-08 12:43:56 --> Model Class Initialized
INFO - 2018-04-08 12:43:56 --> Model Class Initialized
INFO - 2018-04-08 12:43:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:43:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:43:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:43:56 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:43:56 --> Final output sent to browser
DEBUG - 2018-04-08 12:43:56 --> Total execution time: 0.1240
INFO - 2018-04-08 12:44:04 --> Config Class Initialized
INFO - 2018-04-08 12:44:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:04 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:04 --> URI Class Initialized
INFO - 2018-04-08 12:44:04 --> Router Class Initialized
INFO - 2018-04-08 12:44:04 --> Output Class Initialized
INFO - 2018-04-08 12:44:04 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:04 --> Input Class Initialized
INFO - 2018-04-08 12:44:04 --> Language Class Initialized
INFO - 2018-04-08 12:44:04 --> Loader Class Initialized
INFO - 2018-04-08 12:44:04 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:04 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:04 --> Email Class Initialized
INFO - 2018-04-08 12:44:04 --> Controller Class Initialized
INFO - 2018-04-08 12:44:04 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:04 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:04 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:04 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:04 --> Model Class Initialized
INFO - 2018-04-08 12:44:04 --> Model Class Initialized
INFO - 2018-04-08 12:44:04 --> Model Class Initialized
ERROR - 2018-04-08 12:44:04 --> Trying to get property of non-object
ERROR - 2018-04-08 12:44:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:44:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:44:04 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:04 --> Total execution time: 0.1330
INFO - 2018-04-08 12:44:04 --> Config Class Initialized
INFO - 2018-04-08 12:44:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:04 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:04 --> URI Class Initialized
INFO - 2018-04-08 12:44:05 --> Router Class Initialized
INFO - 2018-04-08 12:44:05 --> Output Class Initialized
INFO - 2018-04-08 12:44:05 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:05 --> Input Class Initialized
INFO - 2018-04-08 12:44:05 --> Language Class Initialized
INFO - 2018-04-08 12:44:05 --> Loader Class Initialized
INFO - 2018-04-08 12:44:05 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:05 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:05 --> Email Class Initialized
INFO - 2018-04-08 12:44:05 --> Controller Class Initialized
INFO - 2018-04-08 12:44:05 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:05 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:05 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:05 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:05 --> Model Class Initialized
INFO - 2018-04-08 12:44:05 --> Model Class Initialized
INFO - 2018-04-08 12:44:05 --> Model Class Initialized
ERROR - 2018-04-08 12:44:05 --> Trying to get property of non-object
ERROR - 2018-04-08 12:44:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Admins.php 164
INFO - 2018-04-08 12:44:05 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\pageNotFound.php
INFO - 2018-04-08 12:44:05 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:05 --> Total execution time: 0.1290
INFO - 2018-04-08 12:44:15 --> Config Class Initialized
INFO - 2018-04-08 12:44:15 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:15 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:15 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:15 --> URI Class Initialized
INFO - 2018-04-08 12:44:15 --> Router Class Initialized
INFO - 2018-04-08 12:44:15 --> Output Class Initialized
INFO - 2018-04-08 12:44:15 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:15 --> Input Class Initialized
INFO - 2018-04-08 12:44:15 --> Language Class Initialized
INFO - 2018-04-08 12:44:15 --> Loader Class Initialized
INFO - 2018-04-08 12:44:15 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:15 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:16 --> Email Class Initialized
INFO - 2018-04-08 12:44:16 --> Controller Class Initialized
INFO - 2018-04-08 12:44:16 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:16 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:16 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:16 --> Model Class Initialized
INFO - 2018-04-08 12:44:16 --> Model Class Initialized
INFO - 2018-04-08 12:44:16 --> Model Class Initialized
INFO - 2018-04-08 12:44:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:44:16 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:16 --> Total execution time: 0.1310
INFO - 2018-04-08 12:44:21 --> Config Class Initialized
INFO - 2018-04-08 12:44:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:21 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:21 --> URI Class Initialized
INFO - 2018-04-08 12:44:21 --> Router Class Initialized
INFO - 2018-04-08 12:44:21 --> Output Class Initialized
INFO - 2018-04-08 12:44:21 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:21 --> Input Class Initialized
INFO - 2018-04-08 12:44:21 --> Language Class Initialized
INFO - 2018-04-08 12:44:21 --> Loader Class Initialized
INFO - 2018-04-08 12:44:21 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:21 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:21 --> Email Class Initialized
INFO - 2018-04-08 12:44:21 --> Controller Class Initialized
INFO - 2018-04-08 12:44:21 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:21 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:21 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:21 --> Model Class Initialized
INFO - 2018-04-08 12:44:21 --> Model Class Initialized
INFO - 2018-04-08 12:44:21 --> Model Class Initialized
INFO - 2018-04-08 12:44:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 12:44:21 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:21 --> Total execution time: 0.1270
INFO - 2018-04-08 12:44:23 --> Config Class Initialized
INFO - 2018-04-08 12:44:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:23 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:23 --> URI Class Initialized
INFO - 2018-04-08 12:44:23 --> Router Class Initialized
INFO - 2018-04-08 12:44:23 --> Output Class Initialized
INFO - 2018-04-08 12:44:23 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:23 --> Input Class Initialized
INFO - 2018-04-08 12:44:23 --> Language Class Initialized
INFO - 2018-04-08 12:44:23 --> Loader Class Initialized
INFO - 2018-04-08 12:44:23 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:23 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:23 --> Email Class Initialized
INFO - 2018-04-08 12:44:23 --> Controller Class Initialized
INFO - 2018-04-08 12:44:23 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:23 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:23 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:23 --> Model Class Initialized
INFO - 2018-04-08 12:44:23 --> Model Class Initialized
INFO - 2018-04-08 12:44:23 --> Model Class Initialized
DEBUG - 2018-04-08 12:44:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:44:23 --> Config Class Initialized
INFO - 2018-04-08 12:44:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:23 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:23 --> URI Class Initialized
INFO - 2018-04-08 12:44:23 --> Router Class Initialized
INFO - 2018-04-08 12:44:23 --> Output Class Initialized
INFO - 2018-04-08 12:44:23 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:23 --> Input Class Initialized
INFO - 2018-04-08 12:44:23 --> Language Class Initialized
INFO - 2018-04-08 12:44:23 --> Loader Class Initialized
INFO - 2018-04-08 12:44:23 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:23 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:23 --> Email Class Initialized
INFO - 2018-04-08 12:44:23 --> Controller Class Initialized
INFO - 2018-04-08 12:44:23 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:23 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:23 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:23 --> Model Class Initialized
INFO - 2018-04-08 12:44:23 --> Model Class Initialized
INFO - 2018-04-08 12:44:23 --> Model Class Initialized
INFO - 2018-04-08 12:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:44:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:44:23 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:23 --> Total execution time: 0.1340
INFO - 2018-04-08 12:44:29 --> Config Class Initialized
INFO - 2018-04-08 12:44:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:29 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:29 --> URI Class Initialized
INFO - 2018-04-08 12:44:29 --> Router Class Initialized
INFO - 2018-04-08 12:44:29 --> Output Class Initialized
INFO - 2018-04-08 12:44:29 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:29 --> Input Class Initialized
INFO - 2018-04-08 12:44:29 --> Language Class Initialized
INFO - 2018-04-08 12:44:29 --> Loader Class Initialized
INFO - 2018-04-08 12:44:29 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:29 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:29 --> Email Class Initialized
INFO - 2018-04-08 12:44:29 --> Controller Class Initialized
INFO - 2018-04-08 12:44:29 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:29 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:29 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:29 --> Model Class Initialized
INFO - 2018-04-08 12:44:29 --> Model Class Initialized
INFO - 2018-04-08 12:44:29 --> Model Class Initialized
INFO - 2018-04-08 12:44:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:44:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:44:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:44:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 12:44:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:44:29 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:29 --> Total execution time: 0.1380
INFO - 2018-04-08 12:44:41 --> Config Class Initialized
INFO - 2018-04-08 12:44:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:44:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:44:41 --> Utf8 Class Initialized
INFO - 2018-04-08 12:44:41 --> URI Class Initialized
INFO - 2018-04-08 12:44:41 --> Router Class Initialized
INFO - 2018-04-08 12:44:41 --> Output Class Initialized
INFO - 2018-04-08 12:44:41 --> Security Class Initialized
DEBUG - 2018-04-08 12:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:44:41 --> Input Class Initialized
INFO - 2018-04-08 12:44:41 --> Language Class Initialized
INFO - 2018-04-08 12:44:41 --> Loader Class Initialized
INFO - 2018-04-08 12:44:41 --> Helper loaded: common_helper
INFO - 2018-04-08 12:44:41 --> Database Driver Class Initialized
INFO - 2018-04-08 12:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:44:41 --> Email Class Initialized
INFO - 2018-04-08 12:44:41 --> Controller Class Initialized
INFO - 2018-04-08 12:44:41 --> Helper loaded: form_helper
INFO - 2018-04-08 12:44:41 --> Form Validation Class Initialized
INFO - 2018-04-08 12:44:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:44:41 --> Helper loaded: url_helper
INFO - 2018-04-08 12:44:41 --> Model Class Initialized
INFO - 2018-04-08 12:44:41 --> Model Class Initialized
INFO - 2018-04-08 12:44:41 --> Model Class Initialized
INFO - 2018-04-08 12:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:44:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:44:41 --> Final output sent to browser
DEBUG - 2018-04-08 12:44:41 --> Total execution time: 0.1480
INFO - 2018-04-08 12:48:19 --> Config Class Initialized
INFO - 2018-04-08 12:48:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:48:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:48:19 --> Utf8 Class Initialized
INFO - 2018-04-08 12:48:19 --> URI Class Initialized
INFO - 2018-04-08 12:48:19 --> Router Class Initialized
INFO - 2018-04-08 12:48:19 --> Output Class Initialized
INFO - 2018-04-08 12:48:19 --> Security Class Initialized
DEBUG - 2018-04-08 12:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:48:19 --> Input Class Initialized
INFO - 2018-04-08 12:48:19 --> Language Class Initialized
INFO - 2018-04-08 12:48:19 --> Loader Class Initialized
INFO - 2018-04-08 12:48:19 --> Helper loaded: common_helper
INFO - 2018-04-08 12:48:19 --> Database Driver Class Initialized
INFO - 2018-04-08 12:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:48:19 --> Email Class Initialized
INFO - 2018-04-08 12:48:19 --> Controller Class Initialized
INFO - 2018-04-08 12:48:19 --> Helper loaded: form_helper
INFO - 2018-04-08 12:48:19 --> Form Validation Class Initialized
INFO - 2018-04-08 12:48:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:48:19 --> Helper loaded: url_helper
INFO - 2018-04-08 12:48:19 --> Model Class Initialized
INFO - 2018-04-08 12:48:19 --> Model Class Initialized
INFO - 2018-04-08 12:48:19 --> Model Class Initialized
INFO - 2018-04-08 12:48:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:48:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:48:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:48:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:48:19 --> Final output sent to browser
DEBUG - 2018-04-08 12:48:19 --> Total execution time: 0.1420
INFO - 2018-04-08 12:51:36 --> Config Class Initialized
INFO - 2018-04-08 12:51:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:51:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:51:36 --> Utf8 Class Initialized
INFO - 2018-04-08 12:51:36 --> URI Class Initialized
INFO - 2018-04-08 12:51:36 --> Router Class Initialized
INFO - 2018-04-08 12:51:36 --> Output Class Initialized
INFO - 2018-04-08 12:51:36 --> Security Class Initialized
DEBUG - 2018-04-08 12:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:51:36 --> Input Class Initialized
INFO - 2018-04-08 12:51:36 --> Language Class Initialized
INFO - 2018-04-08 12:51:36 --> Loader Class Initialized
INFO - 2018-04-08 12:51:36 --> Helper loaded: common_helper
INFO - 2018-04-08 12:51:36 --> Database Driver Class Initialized
INFO - 2018-04-08 12:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:51:37 --> Email Class Initialized
INFO - 2018-04-08 12:51:37 --> Controller Class Initialized
INFO - 2018-04-08 12:51:37 --> Helper loaded: form_helper
INFO - 2018-04-08 12:51:37 --> Form Validation Class Initialized
INFO - 2018-04-08 12:51:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:51:37 --> Helper loaded: url_helper
INFO - 2018-04-08 12:51:37 --> Model Class Initialized
INFO - 2018-04-08 12:51:37 --> Model Class Initialized
INFO - 2018-04-08 12:51:37 --> Model Class Initialized
INFO - 2018-04-08 12:51:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:51:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:51:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:51:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 12:51:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:51:37 --> Final output sent to browser
DEBUG - 2018-04-08 12:51:37 --> Total execution time: 0.1300
INFO - 2018-04-08 12:51:43 --> Config Class Initialized
INFO - 2018-04-08 12:51:43 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:51:43 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:51:43 --> Utf8 Class Initialized
INFO - 2018-04-08 12:51:43 --> URI Class Initialized
INFO - 2018-04-08 12:51:43 --> Router Class Initialized
INFO - 2018-04-08 12:51:43 --> Output Class Initialized
INFO - 2018-04-08 12:51:43 --> Security Class Initialized
DEBUG - 2018-04-08 12:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:51:43 --> Input Class Initialized
INFO - 2018-04-08 12:51:43 --> Language Class Initialized
INFO - 2018-04-08 12:51:43 --> Loader Class Initialized
INFO - 2018-04-08 12:51:43 --> Helper loaded: common_helper
INFO - 2018-04-08 12:51:43 --> Database Driver Class Initialized
INFO - 2018-04-08 12:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:51:43 --> Email Class Initialized
INFO - 2018-04-08 12:51:43 --> Controller Class Initialized
INFO - 2018-04-08 12:51:43 --> Helper loaded: form_helper
INFO - 2018-04-08 12:51:43 --> Form Validation Class Initialized
INFO - 2018-04-08 12:51:43 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:51:43 --> Helper loaded: url_helper
INFO - 2018-04-08 12:51:43 --> Model Class Initialized
INFO - 2018-04-08 12:51:43 --> Model Class Initialized
INFO - 2018-04-08 12:51:43 --> Model Class Initialized
INFO - 2018-04-08 12:51:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:51:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:51:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 12:51:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:51:43 --> Final output sent to browser
DEBUG - 2018-04-08 12:51:43 --> Total execution time: 0.1290
INFO - 2018-04-08 12:51:46 --> Config Class Initialized
INFO - 2018-04-08 12:51:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:51:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:51:46 --> Utf8 Class Initialized
INFO - 2018-04-08 12:51:46 --> URI Class Initialized
INFO - 2018-04-08 12:51:46 --> Router Class Initialized
INFO - 2018-04-08 12:51:46 --> Output Class Initialized
INFO - 2018-04-08 12:51:46 --> Security Class Initialized
DEBUG - 2018-04-08 12:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:51:46 --> Input Class Initialized
INFO - 2018-04-08 12:51:46 --> Language Class Initialized
INFO - 2018-04-08 12:51:46 --> Loader Class Initialized
INFO - 2018-04-08 12:51:46 --> Helper loaded: common_helper
INFO - 2018-04-08 12:51:46 --> Database Driver Class Initialized
INFO - 2018-04-08 12:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:51:46 --> Email Class Initialized
INFO - 2018-04-08 12:51:46 --> Controller Class Initialized
INFO - 2018-04-08 12:51:46 --> Helper loaded: form_helper
INFO - 2018-04-08 12:51:46 --> Form Validation Class Initialized
INFO - 2018-04-08 12:51:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:51:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:51:46 --> Helper loaded: url_helper
INFO - 2018-04-08 12:51:46 --> Model Class Initialized
INFO - 2018-04-08 12:51:46 --> Model Class Initialized
INFO - 2018-04-08 12:51:46 --> Model Class Initialized
INFO - 2018-04-08 12:51:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:51:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:51:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:51:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 12:51:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:51:46 --> Final output sent to browser
DEBUG - 2018-04-08 12:51:46 --> Total execution time: 0.1340
INFO - 2018-04-08 12:52:47 --> Config Class Initialized
INFO - 2018-04-08 12:52:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:52:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:52:47 --> Utf8 Class Initialized
INFO - 2018-04-08 12:52:47 --> URI Class Initialized
INFO - 2018-04-08 12:52:47 --> Router Class Initialized
INFO - 2018-04-08 12:52:47 --> Output Class Initialized
INFO - 2018-04-08 12:52:47 --> Security Class Initialized
DEBUG - 2018-04-08 12:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:52:47 --> Input Class Initialized
INFO - 2018-04-08 12:52:47 --> Language Class Initialized
INFO - 2018-04-08 12:52:47 --> Loader Class Initialized
INFO - 2018-04-08 12:52:47 --> Helper loaded: common_helper
INFO - 2018-04-08 12:52:47 --> Database Driver Class Initialized
INFO - 2018-04-08 12:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:52:47 --> Email Class Initialized
INFO - 2018-04-08 12:52:47 --> Controller Class Initialized
INFO - 2018-04-08 12:52:47 --> Helper loaded: form_helper
INFO - 2018-04-08 12:52:47 --> Form Validation Class Initialized
INFO - 2018-04-08 12:52:47 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:52:47 --> Helper loaded: url_helper
INFO - 2018-04-08 12:52:47 --> Model Class Initialized
INFO - 2018-04-08 12:52:47 --> Model Class Initialized
INFO - 2018-04-08 12:52:47 --> Model Class Initialized
INFO - 2018-04-08 12:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2018-04-08 12:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:52:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:52:47 --> Final output sent to browser
DEBUG - 2018-04-08 12:52:47 --> Total execution time: 0.1850
INFO - 2018-04-08 12:55:04 --> Config Class Initialized
INFO - 2018-04-08 12:55:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:55:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:55:04 --> Utf8 Class Initialized
INFO - 2018-04-08 12:55:04 --> URI Class Initialized
INFO - 2018-04-08 12:55:04 --> Router Class Initialized
INFO - 2018-04-08 12:55:04 --> Output Class Initialized
INFO - 2018-04-08 12:55:04 --> Security Class Initialized
DEBUG - 2018-04-08 12:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:55:04 --> Input Class Initialized
INFO - 2018-04-08 12:55:04 --> Language Class Initialized
INFO - 2018-04-08 12:55:04 --> Loader Class Initialized
INFO - 2018-04-08 12:55:04 --> Helper loaded: common_helper
INFO - 2018-04-08 12:55:04 --> Database Driver Class Initialized
INFO - 2018-04-08 12:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:55:04 --> Email Class Initialized
INFO - 2018-04-08 12:55:04 --> Controller Class Initialized
INFO - 2018-04-08 12:55:04 --> Helper loaded: form_helper
INFO - 2018-04-08 12:55:04 --> Form Validation Class Initialized
INFO - 2018-04-08 12:55:04 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:55:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:55:04 --> Helper loaded: url_helper
INFO - 2018-04-08 12:55:04 --> Model Class Initialized
INFO - 2018-04-08 12:55:04 --> Model Class Initialized
INFO - 2018-04-08 12:55:04 --> Model Class Initialized
INFO - 2018-04-08 12:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2018-04-08 12:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:55:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:55:04 --> Final output sent to browser
DEBUG - 2018-04-08 12:55:04 --> Total execution time: 0.1320
INFO - 2018-04-08 12:55:20 --> Config Class Initialized
INFO - 2018-04-08 12:55:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:55:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:55:20 --> Utf8 Class Initialized
INFO - 2018-04-08 12:55:20 --> URI Class Initialized
INFO - 2018-04-08 12:55:20 --> Router Class Initialized
INFO - 2018-04-08 12:55:20 --> Output Class Initialized
INFO - 2018-04-08 12:55:20 --> Security Class Initialized
DEBUG - 2018-04-08 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:55:20 --> Input Class Initialized
INFO - 2018-04-08 12:55:20 --> Language Class Initialized
INFO - 2018-04-08 12:55:20 --> Loader Class Initialized
INFO - 2018-04-08 12:55:20 --> Helper loaded: common_helper
INFO - 2018-04-08 12:55:20 --> Database Driver Class Initialized
INFO - 2018-04-08 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:55:20 --> Email Class Initialized
INFO - 2018-04-08 12:55:20 --> Controller Class Initialized
INFO - 2018-04-08 12:55:20 --> Helper loaded: form_helper
INFO - 2018-04-08 12:55:20 --> Form Validation Class Initialized
INFO - 2018-04-08 12:55:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:55:20 --> Helper loaded: url_helper
INFO - 2018-04-08 12:55:20 --> Model Class Initialized
INFO - 2018-04-08 12:55:20 --> Model Class Initialized
INFO - 2018-04-08 12:55:20 --> Model Class Initialized
DEBUG - 2018-04-08 12:55:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:55:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:55:20 --> Config Class Initialized
INFO - 2018-04-08 12:55:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:55:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:55:20 --> Utf8 Class Initialized
INFO - 2018-04-08 12:55:20 --> URI Class Initialized
INFO - 2018-04-08 12:55:20 --> Router Class Initialized
INFO - 2018-04-08 12:55:20 --> Output Class Initialized
INFO - 2018-04-08 12:55:20 --> Security Class Initialized
DEBUG - 2018-04-08 12:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:55:20 --> Input Class Initialized
INFO - 2018-04-08 12:55:20 --> Language Class Initialized
INFO - 2018-04-08 12:55:20 --> Loader Class Initialized
INFO - 2018-04-08 12:55:20 --> Helper loaded: common_helper
INFO - 2018-04-08 12:55:20 --> Database Driver Class Initialized
INFO - 2018-04-08 12:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:55:20 --> Email Class Initialized
INFO - 2018-04-08 12:55:20 --> Controller Class Initialized
INFO - 2018-04-08 12:55:20 --> Helper loaded: form_helper
INFO - 2018-04-08 12:55:20 --> Form Validation Class Initialized
INFO - 2018-04-08 12:55:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:55:20 --> Helper loaded: url_helper
INFO - 2018-04-08 12:55:20 --> Model Class Initialized
INFO - 2018-04-08 12:55:20 --> Model Class Initialized
INFO - 2018-04-08 12:55:20 --> Model Class Initialized
INFO - 2018-04-08 12:55:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:55:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:55:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2018-04-08 12:55:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:55:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:55:20 --> Final output sent to browser
DEBUG - 2018-04-08 12:55:20 --> Total execution time: 0.1210
INFO - 2018-04-08 12:58:09 --> Config Class Initialized
INFO - 2018-04-08 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:58:09 --> Utf8 Class Initialized
INFO - 2018-04-08 12:58:09 --> URI Class Initialized
INFO - 2018-04-08 12:58:09 --> Router Class Initialized
INFO - 2018-04-08 12:58:09 --> Output Class Initialized
INFO - 2018-04-08 12:58:09 --> Security Class Initialized
DEBUG - 2018-04-08 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:58:09 --> Input Class Initialized
INFO - 2018-04-08 12:58:09 --> Language Class Initialized
INFO - 2018-04-08 12:58:09 --> Loader Class Initialized
INFO - 2018-04-08 12:58:09 --> Helper loaded: common_helper
INFO - 2018-04-08 12:58:09 --> Database Driver Class Initialized
INFO - 2018-04-08 12:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:58:09 --> Email Class Initialized
INFO - 2018-04-08 12:58:09 --> Controller Class Initialized
INFO - 2018-04-08 12:58:09 --> Helper loaded: form_helper
INFO - 2018-04-08 12:58:09 --> Form Validation Class Initialized
INFO - 2018-04-08 12:58:09 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:58:09 --> Helper loaded: url_helper
INFO - 2018-04-08 12:58:09 --> Model Class Initialized
INFO - 2018-04-08 12:58:09 --> Model Class Initialized
INFO - 2018-04-08 12:58:09 --> Model Class Initialized
DEBUG - 2018-04-08 12:58:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:58:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 12:58:09 --> Config Class Initialized
INFO - 2018-04-08 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 12:58:09 --> Utf8 Class Initialized
INFO - 2018-04-08 12:58:09 --> URI Class Initialized
INFO - 2018-04-08 12:58:09 --> Router Class Initialized
INFO - 2018-04-08 12:58:09 --> Output Class Initialized
INFO - 2018-04-08 12:58:09 --> Security Class Initialized
DEBUG - 2018-04-08 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 12:58:09 --> Input Class Initialized
INFO - 2018-04-08 12:58:09 --> Language Class Initialized
INFO - 2018-04-08 12:58:09 --> Loader Class Initialized
INFO - 2018-04-08 12:58:09 --> Helper loaded: common_helper
INFO - 2018-04-08 12:58:09 --> Database Driver Class Initialized
INFO - 2018-04-08 12:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 12:58:09 --> Email Class Initialized
INFO - 2018-04-08 12:58:09 --> Controller Class Initialized
INFO - 2018-04-08 12:58:09 --> Helper loaded: form_helper
INFO - 2018-04-08 12:58:09 --> Form Validation Class Initialized
INFO - 2018-04-08 12:58:09 --> Helper loaded: email_helper
DEBUG - 2018-04-08 12:58:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 12:58:09 --> Helper loaded: url_helper
INFO - 2018-04-08 12:58:09 --> Model Class Initialized
INFO - 2018-04-08 12:58:09 --> Model Class Initialized
INFO - 2018-04-08 12:58:09 --> Model Class Initialized
INFO - 2018-04-08 12:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 12:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 12:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2018-04-08 12:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 12:58:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 12:58:09 --> Final output sent to browser
DEBUG - 2018-04-08 12:58:09 --> Total execution time: 0.1210
INFO - 2018-04-08 13:03:59 --> Config Class Initialized
INFO - 2018-04-08 13:03:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:03:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:03:59 --> Utf8 Class Initialized
INFO - 2018-04-08 13:03:59 --> URI Class Initialized
INFO - 2018-04-08 13:03:59 --> Router Class Initialized
INFO - 2018-04-08 13:03:59 --> Output Class Initialized
INFO - 2018-04-08 13:03:59 --> Security Class Initialized
DEBUG - 2018-04-08 13:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:03:59 --> Input Class Initialized
INFO - 2018-04-08 13:03:59 --> Language Class Initialized
INFO - 2018-04-08 13:03:59 --> Loader Class Initialized
INFO - 2018-04-08 13:03:59 --> Helper loaded: common_helper
INFO - 2018-04-08 13:03:59 --> Database Driver Class Initialized
INFO - 2018-04-08 13:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:03:59 --> Email Class Initialized
INFO - 2018-04-08 13:03:59 --> Controller Class Initialized
INFO - 2018-04-08 13:03:59 --> Helper loaded: form_helper
INFO - 2018-04-08 13:03:59 --> Form Validation Class Initialized
INFO - 2018-04-08 13:03:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:03:59 --> Helper loaded: url_helper
INFO - 2018-04-08 13:03:59 --> Model Class Initialized
INFO - 2018-04-08 13:03:59 --> Model Class Initialized
INFO - 2018-04-08 13:03:59 --> Model Class Initialized
INFO - 2018-04-08 13:03:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:03:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:03:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\changepassword.php
INFO - 2018-04-08 13:03:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:03:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:03:59 --> Final output sent to browser
DEBUG - 2018-04-08 13:03:59 --> Total execution time: 0.1380
INFO - 2018-04-08 13:04:11 --> Config Class Initialized
INFO - 2018-04-08 13:04:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:04:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:04:11 --> Utf8 Class Initialized
INFO - 2018-04-08 13:04:11 --> URI Class Initialized
INFO - 2018-04-08 13:04:11 --> Router Class Initialized
INFO - 2018-04-08 13:04:11 --> Output Class Initialized
INFO - 2018-04-08 13:04:11 --> Security Class Initialized
DEBUG - 2018-04-08 13:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:04:11 --> Input Class Initialized
INFO - 2018-04-08 13:04:11 --> Language Class Initialized
INFO - 2018-04-08 13:04:11 --> Loader Class Initialized
INFO - 2018-04-08 13:04:11 --> Helper loaded: common_helper
INFO - 2018-04-08 13:04:11 --> Database Driver Class Initialized
INFO - 2018-04-08 13:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:04:11 --> Email Class Initialized
INFO - 2018-04-08 13:04:11 --> Controller Class Initialized
INFO - 2018-04-08 13:04:11 --> Helper loaded: form_helper
INFO - 2018-04-08 13:04:11 --> Form Validation Class Initialized
INFO - 2018-04-08 13:04:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:04:11 --> Helper loaded: url_helper
INFO - 2018-04-08 13:04:11 --> Model Class Initialized
INFO - 2018-04-08 13:04:11 --> Model Class Initialized
INFO - 2018-04-08 13:04:11 --> Model Class Initialized
DEBUG - 2018-04-08 13:04:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:04:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 13:04:11 --> Config Class Initialized
INFO - 2018-04-08 13:04:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:04:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:04:11 --> Utf8 Class Initialized
INFO - 2018-04-08 13:04:11 --> URI Class Initialized
INFO - 2018-04-08 13:04:11 --> Router Class Initialized
INFO - 2018-04-08 13:04:11 --> Output Class Initialized
INFO - 2018-04-08 13:04:11 --> Security Class Initialized
DEBUG - 2018-04-08 13:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:04:11 --> Input Class Initialized
INFO - 2018-04-08 13:04:11 --> Language Class Initialized
INFO - 2018-04-08 13:04:11 --> Loader Class Initialized
INFO - 2018-04-08 13:04:11 --> Helper loaded: common_helper
INFO - 2018-04-08 13:04:11 --> Database Driver Class Initialized
INFO - 2018-04-08 13:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:04:11 --> Email Class Initialized
INFO - 2018-04-08 13:04:11 --> Controller Class Initialized
INFO - 2018-04-08 13:04:11 --> Helper loaded: form_helper
INFO - 2018-04-08 13:04:11 --> Form Validation Class Initialized
INFO - 2018-04-08 13:04:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:04:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:04:11 --> Helper loaded: url_helper
INFO - 2018-04-08 13:04:11 --> Model Class Initialized
INFO - 2018-04-08 13:04:11 --> Model Class Initialized
INFO - 2018-04-08 13:04:11 --> Model Class Initialized
INFO - 2018-04-08 13:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:04:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:04:11 --> Final output sent to browser
DEBUG - 2018-04-08 13:04:11 --> Total execution time: 0.1250
INFO - 2018-04-08 13:06:42 --> Config Class Initialized
INFO - 2018-04-08 13:06:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:06:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:06:42 --> Utf8 Class Initialized
INFO - 2018-04-08 13:06:42 --> URI Class Initialized
INFO - 2018-04-08 13:06:42 --> Router Class Initialized
INFO - 2018-04-08 13:06:42 --> Output Class Initialized
INFO - 2018-04-08 13:06:42 --> Security Class Initialized
DEBUG - 2018-04-08 13:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:06:42 --> Input Class Initialized
INFO - 2018-04-08 13:06:42 --> Language Class Initialized
INFO - 2018-04-08 13:06:42 --> Loader Class Initialized
INFO - 2018-04-08 13:06:42 --> Helper loaded: common_helper
INFO - 2018-04-08 13:06:42 --> Database Driver Class Initialized
INFO - 2018-04-08 13:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:06:42 --> Email Class Initialized
INFO - 2018-04-08 13:06:42 --> Controller Class Initialized
INFO - 2018-04-08 13:06:42 --> Helper loaded: form_helper
INFO - 2018-04-08 13:06:42 --> Form Validation Class Initialized
INFO - 2018-04-08 13:06:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:06:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:06:42 --> Helper loaded: url_helper
INFO - 2018-04-08 13:06:42 --> Model Class Initialized
INFO - 2018-04-08 13:06:42 --> Model Class Initialized
INFO - 2018-04-08 13:06:42 --> Model Class Initialized
INFO - 2018-04-08 13:06:42 --> Config Class Initialized
INFO - 2018-04-08 13:06:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:06:43 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:06:43 --> Utf8 Class Initialized
INFO - 2018-04-08 13:06:43 --> URI Class Initialized
DEBUG - 2018-04-08 13:06:43 --> No URI present. Default controller set.
INFO - 2018-04-08 13:06:43 --> Router Class Initialized
INFO - 2018-04-08 13:06:43 --> Output Class Initialized
INFO - 2018-04-08 13:06:43 --> Security Class Initialized
DEBUG - 2018-04-08 13:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:06:43 --> Input Class Initialized
INFO - 2018-04-08 13:06:43 --> Language Class Initialized
INFO - 2018-04-08 13:06:43 --> Loader Class Initialized
INFO - 2018-04-08 13:06:43 --> Helper loaded: common_helper
INFO - 2018-04-08 13:06:43 --> Database Driver Class Initialized
INFO - 2018-04-08 13:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:06:43 --> Email Class Initialized
INFO - 2018-04-08 13:06:43 --> Controller Class Initialized
INFO - 2018-04-08 13:06:43 --> Helper loaded: form_helper
INFO - 2018-04-08 13:06:43 --> Form Validation Class Initialized
INFO - 2018-04-08 13:06:43 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:06:43 --> Helper loaded: url_helper
INFO - 2018-04-08 13:06:43 --> Model Class Initialized
INFO - 2018-04-08 13:06:43 --> Model Class Initialized
INFO - 2018-04-08 13:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 13:06:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:06:43 --> Final output sent to browser
DEBUG - 2018-04-08 13:06:43 --> Total execution time: 0.1110
INFO - 2018-04-08 13:08:32 --> Config Class Initialized
INFO - 2018-04-08 13:08:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:08:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:08:32 --> Utf8 Class Initialized
INFO - 2018-04-08 13:08:32 --> URI Class Initialized
INFO - 2018-04-08 13:08:32 --> Router Class Initialized
INFO - 2018-04-08 13:08:32 --> Output Class Initialized
INFO - 2018-04-08 13:08:32 --> Security Class Initialized
DEBUG - 2018-04-08 13:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:08:32 --> Input Class Initialized
INFO - 2018-04-08 13:08:32 --> Language Class Initialized
INFO - 2018-04-08 13:08:32 --> Loader Class Initialized
INFO - 2018-04-08 13:08:32 --> Helper loaded: common_helper
INFO - 2018-04-08 13:08:32 --> Database Driver Class Initialized
INFO - 2018-04-08 13:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:08:32 --> Email Class Initialized
INFO - 2018-04-08 13:08:32 --> Controller Class Initialized
INFO - 2018-04-08 13:08:32 --> Helper loaded: form_helper
INFO - 2018-04-08 13:08:32 --> Form Validation Class Initialized
INFO - 2018-04-08 13:08:32 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:08:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:08:32 --> Helper loaded: url_helper
INFO - 2018-04-08 13:08:32 --> Model Class Initialized
INFO - 2018-04-08 13:08:32 --> Model Class Initialized
INFO - 2018-04-08 13:08:32 --> Model Class Initialized
INFO - 2018-04-08 13:08:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 13:08:32 --> Final output sent to browser
DEBUG - 2018-04-08 13:08:32 --> Total execution time: 0.1510
INFO - 2018-04-08 13:08:48 --> Config Class Initialized
INFO - 2018-04-08 13:08:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:08:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:08:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:08:48 --> URI Class Initialized
INFO - 2018-04-08 13:08:48 --> Router Class Initialized
INFO - 2018-04-08 13:08:48 --> Output Class Initialized
INFO - 2018-04-08 13:08:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:08:48 --> Input Class Initialized
INFO - 2018-04-08 13:08:48 --> Language Class Initialized
INFO - 2018-04-08 13:08:48 --> Loader Class Initialized
INFO - 2018-04-08 13:08:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:08:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:08:48 --> Email Class Initialized
INFO - 2018-04-08 13:08:48 --> Controller Class Initialized
INFO - 2018-04-08 13:08:48 --> Helper loaded: form_helper
INFO - 2018-04-08 13:08:48 --> Form Validation Class Initialized
INFO - 2018-04-08 13:08:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:08:48 --> Helper loaded: url_helper
INFO - 2018-04-08 13:08:48 --> Model Class Initialized
INFO - 2018-04-08 13:08:48 --> Model Class Initialized
INFO - 2018-04-08 13:08:48 --> Model Class Initialized
DEBUG - 2018-04-08 13:08:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:08:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 13:08:48 --> Config Class Initialized
INFO - 2018-04-08 13:08:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:08:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:08:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:08:48 --> URI Class Initialized
DEBUG - 2018-04-08 13:08:48 --> No URI present. Default controller set.
INFO - 2018-04-08 13:08:48 --> Router Class Initialized
INFO - 2018-04-08 13:08:48 --> Output Class Initialized
INFO - 2018-04-08 13:08:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:08:48 --> Input Class Initialized
INFO - 2018-04-08 13:08:48 --> Language Class Initialized
INFO - 2018-04-08 13:08:48 --> Loader Class Initialized
INFO - 2018-04-08 13:08:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:08:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:08:48 --> Email Class Initialized
INFO - 2018-04-08 13:08:48 --> Controller Class Initialized
INFO - 2018-04-08 13:08:48 --> Helper loaded: form_helper
INFO - 2018-04-08 13:08:48 --> Form Validation Class Initialized
INFO - 2018-04-08 13:08:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:08:48 --> Helper loaded: url_helper
INFO - 2018-04-08 13:08:48 --> Model Class Initialized
INFO - 2018-04-08 13:08:48 --> Model Class Initialized
INFO - 2018-04-08 13:08:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 13:08:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:08:48 --> Final output sent to browser
DEBUG - 2018-04-08 13:08:48 --> Total execution time: 0.1125
INFO - 2018-04-08 13:09:09 --> Config Class Initialized
INFO - 2018-04-08 13:09:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:09 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:09 --> URI Class Initialized
DEBUG - 2018-04-08 13:09:09 --> No URI present. Default controller set.
INFO - 2018-04-08 13:09:09 --> Router Class Initialized
INFO - 2018-04-08 13:09:09 --> Output Class Initialized
INFO - 2018-04-08 13:09:09 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:09 --> Input Class Initialized
INFO - 2018-04-08 13:09:09 --> Language Class Initialized
INFO - 2018-04-08 13:09:09 --> Loader Class Initialized
INFO - 2018-04-08 13:09:09 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:09 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:09 --> Email Class Initialized
INFO - 2018-04-08 13:09:09 --> Controller Class Initialized
INFO - 2018-04-08 13:09:09 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:09 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:09 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:09 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:09 --> Model Class Initialized
INFO - 2018-04-08 13:09:09 --> Model Class Initialized
DEBUG - 2018-04-08 13:09:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 13:09:09 --> Config Class Initialized
INFO - 2018-04-08 13:09:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:09 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:09 --> URI Class Initialized
INFO - 2018-04-08 13:09:09 --> Router Class Initialized
INFO - 2018-04-08 13:09:09 --> Output Class Initialized
INFO - 2018-04-08 13:09:09 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:09 --> Input Class Initialized
INFO - 2018-04-08 13:09:09 --> Language Class Initialized
INFO - 2018-04-08 13:09:09 --> Loader Class Initialized
INFO - 2018-04-08 13:09:09 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:09 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:09 --> Email Class Initialized
INFO - 2018-04-08 13:09:09 --> Controller Class Initialized
INFO - 2018-04-08 13:09:09 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:09 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:09 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:09 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:09 --> Model Class Initialized
INFO - 2018-04-08 13:09:09 --> Model Class Initialized
INFO - 2018-04-08 13:09:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:09:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:09:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 13:09:09 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:09:09 --> Final output sent to browser
DEBUG - 2018-04-08 13:09:09 --> Total execution time: 0.1300
INFO - 2018-04-08 13:09:14 --> Config Class Initialized
INFO - 2018-04-08 13:09:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:14 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:14 --> URI Class Initialized
INFO - 2018-04-08 13:09:14 --> Router Class Initialized
INFO - 2018-04-08 13:09:14 --> Output Class Initialized
INFO - 2018-04-08 13:09:14 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:14 --> Input Class Initialized
INFO - 2018-04-08 13:09:14 --> Language Class Initialized
INFO - 2018-04-08 13:09:14 --> Loader Class Initialized
INFO - 2018-04-08 13:09:14 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:15 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:15 --> Email Class Initialized
INFO - 2018-04-08 13:09:15 --> Controller Class Initialized
INFO - 2018-04-08 13:09:15 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:15 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:15 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:15 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:15 --> Model Class Initialized
INFO - 2018-04-08 13:09:15 --> Model Class Initialized
INFO - 2018-04-08 13:09:15 --> Model Class Initialized
INFO - 2018-04-08 13:09:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:09:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:09:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:09:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:09:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:09:15 --> Final output sent to browser
DEBUG - 2018-04-08 13:09:15 --> Total execution time: 0.1490
INFO - 2018-04-08 13:09:19 --> Config Class Initialized
INFO - 2018-04-08 13:09:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:19 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:19 --> URI Class Initialized
INFO - 2018-04-08 13:09:19 --> Router Class Initialized
INFO - 2018-04-08 13:09:19 --> Output Class Initialized
INFO - 2018-04-08 13:09:19 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:19 --> Input Class Initialized
INFO - 2018-04-08 13:09:19 --> Language Class Initialized
INFO - 2018-04-08 13:09:19 --> Loader Class Initialized
INFO - 2018-04-08 13:09:19 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:19 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:19 --> Email Class Initialized
INFO - 2018-04-08 13:09:19 --> Controller Class Initialized
INFO - 2018-04-08 13:09:19 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:19 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:19 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:19 --> Model Class Initialized
INFO - 2018-04-08 13:09:19 --> Model Class Initialized
INFO - 2018-04-08 13:09:19 --> Model Class Initialized
INFO - 2018-04-08 13:09:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:09:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:09:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 13:09:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:09:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:09:19 --> Final output sent to browser
DEBUG - 2018-04-08 13:09:19 --> Total execution time: 0.1250
INFO - 2018-04-08 13:09:30 --> Config Class Initialized
INFO - 2018-04-08 13:09:30 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:30 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:30 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:30 --> URI Class Initialized
INFO - 2018-04-08 13:09:30 --> Router Class Initialized
INFO - 2018-04-08 13:09:30 --> Output Class Initialized
INFO - 2018-04-08 13:09:30 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:30 --> Input Class Initialized
INFO - 2018-04-08 13:09:30 --> Language Class Initialized
INFO - 2018-04-08 13:09:30 --> Loader Class Initialized
INFO - 2018-04-08 13:09:30 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:30 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:30 --> Email Class Initialized
INFO - 2018-04-08 13:09:30 --> Controller Class Initialized
INFO - 2018-04-08 13:09:30 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:30 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:30 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:30 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:30 --> Model Class Initialized
INFO - 2018-04-08 13:09:30 --> Model Class Initialized
INFO - 2018-04-08 13:09:30 --> Model Class Initialized
DEBUG - 2018-04-08 13:09:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 13:09:30 --> Config Class Initialized
INFO - 2018-04-08 13:09:30 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:30 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:30 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:30 --> URI Class Initialized
INFO - 2018-04-08 13:09:30 --> Router Class Initialized
INFO - 2018-04-08 13:09:30 --> Output Class Initialized
INFO - 2018-04-08 13:09:30 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:30 --> Input Class Initialized
INFO - 2018-04-08 13:09:30 --> Language Class Initialized
INFO - 2018-04-08 13:09:30 --> Loader Class Initialized
INFO - 2018-04-08 13:09:30 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:30 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:30 --> Email Class Initialized
INFO - 2018-04-08 13:09:30 --> Controller Class Initialized
INFO - 2018-04-08 13:09:30 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:30 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:30 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:30 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:30 --> Model Class Initialized
INFO - 2018-04-08 13:09:30 --> Model Class Initialized
INFO - 2018-04-08 13:09:30 --> Model Class Initialized
INFO - 2018-04-08 13:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:09:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:09:30 --> Final output sent to browser
DEBUG - 2018-04-08 13:09:30 --> Total execution time: 0.1225
INFO - 2018-04-08 13:09:39 --> Config Class Initialized
INFO - 2018-04-08 13:09:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:39 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:39 --> URI Class Initialized
INFO - 2018-04-08 13:09:39 --> Router Class Initialized
INFO - 2018-04-08 13:09:39 --> Output Class Initialized
INFO - 2018-04-08 13:09:39 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:39 --> Input Class Initialized
INFO - 2018-04-08 13:09:39 --> Language Class Initialized
INFO - 2018-04-08 13:09:39 --> Loader Class Initialized
INFO - 2018-04-08 13:09:39 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:39 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:39 --> Email Class Initialized
INFO - 2018-04-08 13:09:39 --> Controller Class Initialized
INFO - 2018-04-08 13:09:39 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:39 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:39 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:39 --> Model Class Initialized
INFO - 2018-04-08 13:09:39 --> Model Class Initialized
INFO - 2018-04-08 13:09:39 --> Model Class Initialized
INFO - 2018-04-08 13:09:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:09:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:09:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 13:09:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:09:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:09:39 --> Final output sent to browser
DEBUG - 2018-04-08 13:09:39 --> Total execution time: 0.1280
INFO - 2018-04-08 13:09:56 --> Config Class Initialized
INFO - 2018-04-08 13:09:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:56 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:56 --> URI Class Initialized
INFO - 2018-04-08 13:09:56 --> Router Class Initialized
INFO - 2018-04-08 13:09:56 --> Output Class Initialized
INFO - 2018-04-08 13:09:56 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:56 --> Input Class Initialized
INFO - 2018-04-08 13:09:56 --> Language Class Initialized
INFO - 2018-04-08 13:09:57 --> Loader Class Initialized
INFO - 2018-04-08 13:09:57 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:57 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:57 --> Email Class Initialized
INFO - 2018-04-08 13:09:57 --> Controller Class Initialized
INFO - 2018-04-08 13:09:57 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:57 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:57 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:57 --> Model Class Initialized
INFO - 2018-04-08 13:09:57 --> Model Class Initialized
INFO - 2018-04-08 13:09:57 --> Model Class Initialized
DEBUG - 2018-04-08 13:09:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 13:09:57 --> Config Class Initialized
INFO - 2018-04-08 13:09:57 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:09:57 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:09:57 --> Utf8 Class Initialized
INFO - 2018-04-08 13:09:57 --> URI Class Initialized
INFO - 2018-04-08 13:09:57 --> Router Class Initialized
INFO - 2018-04-08 13:09:57 --> Output Class Initialized
INFO - 2018-04-08 13:09:57 --> Security Class Initialized
DEBUG - 2018-04-08 13:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:09:57 --> Input Class Initialized
INFO - 2018-04-08 13:09:57 --> Language Class Initialized
INFO - 2018-04-08 13:09:57 --> Loader Class Initialized
INFO - 2018-04-08 13:09:57 --> Helper loaded: common_helper
INFO - 2018-04-08 13:09:57 --> Database Driver Class Initialized
INFO - 2018-04-08 13:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:09:57 --> Email Class Initialized
INFO - 2018-04-08 13:09:57 --> Controller Class Initialized
INFO - 2018-04-08 13:09:57 --> Helper loaded: form_helper
INFO - 2018-04-08 13:09:57 --> Form Validation Class Initialized
INFO - 2018-04-08 13:09:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:09:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:09:57 --> Helper loaded: url_helper
INFO - 2018-04-08 13:09:57 --> Model Class Initialized
INFO - 2018-04-08 13:09:57 --> Model Class Initialized
INFO - 2018-04-08 13:09:57 --> Model Class Initialized
INFO - 2018-04-08 13:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:09:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:09:57 --> Final output sent to browser
DEBUG - 2018-04-08 13:09:57 --> Total execution time: 0.1230
INFO - 2018-04-08 13:10:25 --> Config Class Initialized
INFO - 2018-04-08 13:10:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:10:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:10:25 --> Utf8 Class Initialized
INFO - 2018-04-08 13:10:25 --> URI Class Initialized
INFO - 2018-04-08 13:10:25 --> Router Class Initialized
INFO - 2018-04-08 13:10:25 --> Output Class Initialized
INFO - 2018-04-08 13:10:25 --> Security Class Initialized
DEBUG - 2018-04-08 13:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:10:25 --> Input Class Initialized
INFO - 2018-04-08 13:10:25 --> Language Class Initialized
INFO - 2018-04-08 13:10:25 --> Loader Class Initialized
INFO - 2018-04-08 13:10:25 --> Helper loaded: common_helper
INFO - 2018-04-08 13:10:25 --> Database Driver Class Initialized
INFO - 2018-04-08 13:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:10:25 --> Email Class Initialized
INFO - 2018-04-08 13:10:25 --> Controller Class Initialized
INFO - 2018-04-08 13:10:25 --> Helper loaded: form_helper
INFO - 2018-04-08 13:10:25 --> Form Validation Class Initialized
INFO - 2018-04-08 13:10:25 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:10:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:10:25 --> Helper loaded: url_helper
INFO - 2018-04-08 13:10:25 --> Model Class Initialized
INFO - 2018-04-08 13:10:25 --> Model Class Initialized
INFO - 2018-04-08 13:10:25 --> Model Class Initialized
INFO - 2018-04-08 13:10:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:10:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:10:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:10:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:10:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:10:25 --> Final output sent to browser
DEBUG - 2018-04-08 13:10:25 --> Total execution time: 0.1310
INFO - 2018-04-08 13:10:29 --> Config Class Initialized
INFO - 2018-04-08 13:10:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:10:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:10:29 --> Utf8 Class Initialized
INFO - 2018-04-08 13:10:29 --> URI Class Initialized
INFO - 2018-04-08 13:10:29 --> Router Class Initialized
INFO - 2018-04-08 13:10:29 --> Output Class Initialized
INFO - 2018-04-08 13:10:29 --> Security Class Initialized
DEBUG - 2018-04-08 13:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:10:29 --> Input Class Initialized
INFO - 2018-04-08 13:10:29 --> Language Class Initialized
INFO - 2018-04-08 13:10:29 --> Loader Class Initialized
INFO - 2018-04-08 13:10:29 --> Helper loaded: common_helper
INFO - 2018-04-08 13:10:29 --> Database Driver Class Initialized
INFO - 2018-04-08 13:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:10:29 --> Email Class Initialized
INFO - 2018-04-08 13:10:29 --> Controller Class Initialized
INFO - 2018-04-08 13:10:29 --> Helper loaded: form_helper
INFO - 2018-04-08 13:10:29 --> Form Validation Class Initialized
INFO - 2018-04-08 13:10:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:10:29 --> Helper loaded: url_helper
INFO - 2018-04-08 13:10:29 --> Model Class Initialized
INFO - 2018-04-08 13:10:29 --> Model Class Initialized
INFO - 2018-04-08 13:10:29 --> Model Class Initialized
INFO - 2018-04-08 13:10:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:10:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:10:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 13:10:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:10:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:10:29 --> Final output sent to browser
DEBUG - 2018-04-08 13:10:29 --> Total execution time: 0.1290
INFO - 2018-04-08 13:10:39 --> Config Class Initialized
INFO - 2018-04-08 13:10:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:10:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:10:39 --> Utf8 Class Initialized
INFO - 2018-04-08 13:10:39 --> URI Class Initialized
INFO - 2018-04-08 13:10:39 --> Router Class Initialized
INFO - 2018-04-08 13:10:39 --> Output Class Initialized
INFO - 2018-04-08 13:10:39 --> Security Class Initialized
DEBUG - 2018-04-08 13:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:10:39 --> Input Class Initialized
INFO - 2018-04-08 13:10:39 --> Language Class Initialized
INFO - 2018-04-08 13:10:39 --> Loader Class Initialized
INFO - 2018-04-08 13:10:39 --> Helper loaded: common_helper
INFO - 2018-04-08 13:10:39 --> Database Driver Class Initialized
INFO - 2018-04-08 13:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:10:39 --> Email Class Initialized
INFO - 2018-04-08 13:10:39 --> Controller Class Initialized
INFO - 2018-04-08 13:10:39 --> Helper loaded: form_helper
INFO - 2018-04-08 13:10:39 --> Form Validation Class Initialized
INFO - 2018-04-08 13:10:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:10:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:10:39 --> Helper loaded: url_helper
INFO - 2018-04-08 13:10:39 --> Model Class Initialized
INFO - 2018-04-08 13:10:39 --> Model Class Initialized
INFO - 2018-04-08 13:10:39 --> Model Class Initialized
INFO - 2018-04-08 13:10:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:10:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:10:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:10:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:10:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:10:39 --> Final output sent to browser
DEBUG - 2018-04-08 13:10:39 --> Total execution time: 0.1340
INFO - 2018-04-08 13:11:13 --> Config Class Initialized
INFO - 2018-04-08 13:11:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:11:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:11:13 --> Utf8 Class Initialized
INFO - 2018-04-08 13:11:13 --> URI Class Initialized
INFO - 2018-04-08 13:11:13 --> Router Class Initialized
INFO - 2018-04-08 13:11:13 --> Output Class Initialized
INFO - 2018-04-08 13:11:13 --> Security Class Initialized
DEBUG - 2018-04-08 13:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:11:13 --> Input Class Initialized
INFO - 2018-04-08 13:11:13 --> Language Class Initialized
INFO - 2018-04-08 13:11:13 --> Loader Class Initialized
INFO - 2018-04-08 13:11:13 --> Helper loaded: common_helper
INFO - 2018-04-08 13:11:13 --> Database Driver Class Initialized
INFO - 2018-04-08 13:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:11:13 --> Email Class Initialized
INFO - 2018-04-08 13:11:13 --> Controller Class Initialized
INFO - 2018-04-08 13:11:13 --> Helper loaded: form_helper
INFO - 2018-04-08 13:11:13 --> Form Validation Class Initialized
INFO - 2018-04-08 13:11:13 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:11:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:11:13 --> Helper loaded: url_helper
INFO - 2018-04-08 13:11:13 --> Model Class Initialized
INFO - 2018-04-08 13:11:13 --> Model Class Initialized
INFO - 2018-04-08 13:11:13 --> Model Class Initialized
INFO - 2018-04-08 13:11:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:11:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:11:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:11:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:11:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:11:13 --> Final output sent to browser
DEBUG - 2018-04-08 13:11:13 --> Total execution time: 0.1270
INFO - 2018-04-08 13:11:17 --> Config Class Initialized
INFO - 2018-04-08 13:11:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:11:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:11:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:11:17 --> URI Class Initialized
INFO - 2018-04-08 13:11:17 --> Router Class Initialized
INFO - 2018-04-08 13:11:17 --> Output Class Initialized
INFO - 2018-04-08 13:11:17 --> Security Class Initialized
DEBUG - 2018-04-08 13:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:11:17 --> Input Class Initialized
INFO - 2018-04-08 13:11:17 --> Language Class Initialized
INFO - 2018-04-08 13:11:17 --> Loader Class Initialized
INFO - 2018-04-08 13:11:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:11:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:11:17 --> Email Class Initialized
INFO - 2018-04-08 13:11:17 --> Controller Class Initialized
INFO - 2018-04-08 13:11:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:11:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:11:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:11:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:11:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:11:17 --> Model Class Initialized
INFO - 2018-04-08 13:11:17 --> Model Class Initialized
INFO - 2018-04-08 13:11:17 --> Model Class Initialized
INFO - 2018-04-08 13:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 13:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:11:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:11:17 --> Final output sent to browser
DEBUG - 2018-04-08 13:11:17 --> Total execution time: 0.1280
INFO - 2018-04-08 13:11:38 --> Config Class Initialized
INFO - 2018-04-08 13:11:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:11:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:11:38 --> Utf8 Class Initialized
INFO - 2018-04-08 13:11:38 --> URI Class Initialized
INFO - 2018-04-08 13:11:38 --> Router Class Initialized
INFO - 2018-04-08 13:11:38 --> Output Class Initialized
INFO - 2018-04-08 13:11:38 --> Security Class Initialized
DEBUG - 2018-04-08 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:11:38 --> Input Class Initialized
INFO - 2018-04-08 13:11:38 --> Language Class Initialized
INFO - 2018-04-08 13:11:38 --> Loader Class Initialized
INFO - 2018-04-08 13:11:38 --> Helper loaded: common_helper
INFO - 2018-04-08 13:11:38 --> Database Driver Class Initialized
INFO - 2018-04-08 13:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:11:38 --> Email Class Initialized
INFO - 2018-04-08 13:11:38 --> Controller Class Initialized
INFO - 2018-04-08 13:11:38 --> Helper loaded: form_helper
INFO - 2018-04-08 13:11:38 --> Form Validation Class Initialized
INFO - 2018-04-08 13:11:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:11:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:11:38 --> Helper loaded: url_helper
INFO - 2018-04-08 13:11:38 --> Model Class Initialized
INFO - 2018-04-08 13:11:38 --> Model Class Initialized
INFO - 2018-04-08 13:11:38 --> Model Class Initialized
INFO - 2018-04-08 13:11:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:11:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:11:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:11:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:11:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:11:38 --> Final output sent to browser
DEBUG - 2018-04-08 13:11:38 --> Total execution time: 0.1360
INFO - 2018-04-08 13:14:24 --> Config Class Initialized
INFO - 2018-04-08 13:14:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:14:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:14:24 --> Utf8 Class Initialized
INFO - 2018-04-08 13:14:24 --> URI Class Initialized
INFO - 2018-04-08 13:14:24 --> Router Class Initialized
INFO - 2018-04-08 13:14:24 --> Output Class Initialized
INFO - 2018-04-08 13:14:24 --> Security Class Initialized
DEBUG - 2018-04-08 13:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:14:24 --> Input Class Initialized
INFO - 2018-04-08 13:14:24 --> Language Class Initialized
INFO - 2018-04-08 13:14:24 --> Loader Class Initialized
INFO - 2018-04-08 13:14:24 --> Helper loaded: common_helper
INFO - 2018-04-08 13:14:24 --> Database Driver Class Initialized
INFO - 2018-04-08 13:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:14:24 --> Email Class Initialized
INFO - 2018-04-08 13:14:24 --> Controller Class Initialized
INFO - 2018-04-08 13:14:24 --> Helper loaded: form_helper
INFO - 2018-04-08 13:14:24 --> Form Validation Class Initialized
INFO - 2018-04-08 13:14:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:14:24 --> Helper loaded: url_helper
INFO - 2018-04-08 13:14:24 --> Model Class Initialized
INFO - 2018-04-08 13:14:24 --> Model Class Initialized
INFO - 2018-04-08 13:14:24 --> Model Class Initialized
INFO - 2018-04-08 13:14:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:14:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:14:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:14:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:14:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:14:24 --> Final output sent to browser
DEBUG - 2018-04-08 13:14:24 --> Total execution time: 0.1260
INFO - 2018-04-08 13:14:29 --> Config Class Initialized
INFO - 2018-04-08 13:14:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:14:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:14:29 --> Utf8 Class Initialized
INFO - 2018-04-08 13:14:29 --> URI Class Initialized
INFO - 2018-04-08 13:14:29 --> Router Class Initialized
INFO - 2018-04-08 13:14:29 --> Output Class Initialized
INFO - 2018-04-08 13:14:29 --> Security Class Initialized
DEBUG - 2018-04-08 13:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:14:29 --> Input Class Initialized
INFO - 2018-04-08 13:14:29 --> Language Class Initialized
INFO - 2018-04-08 13:14:29 --> Loader Class Initialized
INFO - 2018-04-08 13:14:29 --> Helper loaded: common_helper
INFO - 2018-04-08 13:14:29 --> Database Driver Class Initialized
INFO - 2018-04-08 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:14:29 --> Email Class Initialized
INFO - 2018-04-08 13:14:29 --> Controller Class Initialized
INFO - 2018-04-08 13:14:29 --> Helper loaded: form_helper
INFO - 2018-04-08 13:14:29 --> Form Validation Class Initialized
INFO - 2018-04-08 13:14:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:14:29 --> Helper loaded: url_helper
INFO - 2018-04-08 13:14:29 --> Model Class Initialized
INFO - 2018-04-08 13:14:29 --> Model Class Initialized
INFO - 2018-04-08 13:14:29 --> Model Class Initialized
INFO - 2018-04-08 13:14:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:14:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:14:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 13:14:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:14:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:14:29 --> Final output sent to browser
DEBUG - 2018-04-08 13:14:29 --> Total execution time: 0.1270
INFO - 2018-04-08 13:14:38 --> Config Class Initialized
INFO - 2018-04-08 13:14:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:14:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:14:38 --> Utf8 Class Initialized
INFO - 2018-04-08 13:14:38 --> URI Class Initialized
INFO - 2018-04-08 13:14:38 --> Router Class Initialized
INFO - 2018-04-08 13:14:38 --> Output Class Initialized
INFO - 2018-04-08 13:14:38 --> Security Class Initialized
DEBUG - 2018-04-08 13:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:14:38 --> Input Class Initialized
INFO - 2018-04-08 13:14:38 --> Language Class Initialized
INFO - 2018-04-08 13:14:38 --> Loader Class Initialized
INFO - 2018-04-08 13:14:38 --> Helper loaded: common_helper
INFO - 2018-04-08 13:14:38 --> Database Driver Class Initialized
INFO - 2018-04-08 13:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:14:38 --> Email Class Initialized
INFO - 2018-04-08 13:14:38 --> Controller Class Initialized
INFO - 2018-04-08 13:14:38 --> Helper loaded: form_helper
INFO - 2018-04-08 13:14:38 --> Form Validation Class Initialized
INFO - 2018-04-08 13:14:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:14:38 --> Helper loaded: url_helper
INFO - 2018-04-08 13:14:38 --> Model Class Initialized
INFO - 2018-04-08 13:14:38 --> Model Class Initialized
INFO - 2018-04-08 13:14:38 --> Model Class Initialized
INFO - 2018-04-08 13:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:14:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:14:38 --> Final output sent to browser
DEBUG - 2018-04-08 13:14:38 --> Total execution time: 0.1310
INFO - 2018-04-08 13:14:41 --> Config Class Initialized
INFO - 2018-04-08 13:14:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:14:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:14:41 --> Utf8 Class Initialized
INFO - 2018-04-08 13:14:41 --> URI Class Initialized
INFO - 2018-04-08 13:14:41 --> Router Class Initialized
INFO - 2018-04-08 13:14:41 --> Output Class Initialized
INFO - 2018-04-08 13:14:41 --> Security Class Initialized
DEBUG - 2018-04-08 13:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:14:41 --> Input Class Initialized
INFO - 2018-04-08 13:14:41 --> Language Class Initialized
INFO - 2018-04-08 13:14:41 --> Loader Class Initialized
INFO - 2018-04-08 13:14:41 --> Helper loaded: common_helper
INFO - 2018-04-08 13:14:41 --> Database Driver Class Initialized
INFO - 2018-04-08 13:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:14:41 --> Email Class Initialized
INFO - 2018-04-08 13:14:41 --> Controller Class Initialized
INFO - 2018-04-08 13:14:41 --> Helper loaded: form_helper
INFO - 2018-04-08 13:14:41 --> Form Validation Class Initialized
INFO - 2018-04-08 13:14:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:14:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:14:41 --> Helper loaded: url_helper
INFO - 2018-04-08 13:14:41 --> Model Class Initialized
INFO - 2018-04-08 13:14:41 --> Model Class Initialized
INFO - 2018-04-08 13:14:41 --> Model Class Initialized
INFO - 2018-04-08 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/addAdmin.php
INFO - 2018-04-08 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:14:41 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:14:41 --> Final output sent to browser
DEBUG - 2018-04-08 13:14:41 --> Total execution time: 0.1240
INFO - 2018-04-08 13:14:45 --> Config Class Initialized
INFO - 2018-04-08 13:14:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:14:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:14:45 --> Utf8 Class Initialized
INFO - 2018-04-08 13:14:45 --> URI Class Initialized
INFO - 2018-04-08 13:14:45 --> Router Class Initialized
INFO - 2018-04-08 13:14:46 --> Output Class Initialized
INFO - 2018-04-08 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-08 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:14:46 --> Input Class Initialized
INFO - 2018-04-08 13:14:46 --> Language Class Initialized
INFO - 2018-04-08 13:14:46 --> Loader Class Initialized
INFO - 2018-04-08 13:14:46 --> Helper loaded: common_helper
INFO - 2018-04-08 13:14:46 --> Database Driver Class Initialized
INFO - 2018-04-08 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:14:46 --> Email Class Initialized
INFO - 2018-04-08 13:14:46 --> Controller Class Initialized
INFO - 2018-04-08 13:14:46 --> Helper loaded: form_helper
INFO - 2018-04-08 13:14:46 --> Form Validation Class Initialized
INFO - 2018-04-08 13:14:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:14:46 --> Helper loaded: url_helper
INFO - 2018-04-08 13:14:46 --> Model Class Initialized
INFO - 2018-04-08 13:14:46 --> Model Class Initialized
INFO - 2018-04-08 13:14:46 --> Model Class Initialized
INFO - 2018-04-08 13:14:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:14:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:14:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:14:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:14:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:14:46 --> Final output sent to browser
DEBUG - 2018-04-08 13:14:46 --> Total execution time: 0.1520
INFO - 2018-04-08 13:15:04 --> Config Class Initialized
INFO - 2018-04-08 13:15:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:15:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:15:04 --> Utf8 Class Initialized
INFO - 2018-04-08 13:15:04 --> URI Class Initialized
INFO - 2018-04-08 13:15:04 --> Router Class Initialized
INFO - 2018-04-08 13:15:04 --> Output Class Initialized
INFO - 2018-04-08 13:15:04 --> Security Class Initialized
DEBUG - 2018-04-08 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:15:04 --> Input Class Initialized
INFO - 2018-04-08 13:15:04 --> Language Class Initialized
INFO - 2018-04-08 13:15:04 --> Loader Class Initialized
INFO - 2018-04-08 13:15:04 --> Helper loaded: common_helper
INFO - 2018-04-08 13:15:04 --> Database Driver Class Initialized
INFO - 2018-04-08 13:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:15:04 --> Email Class Initialized
INFO - 2018-04-08 13:15:04 --> Controller Class Initialized
INFO - 2018-04-08 13:15:04 --> Helper loaded: form_helper
INFO - 2018-04-08 13:15:04 --> Form Validation Class Initialized
INFO - 2018-04-08 13:15:04 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:15:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:15:04 --> Helper loaded: url_helper
INFO - 2018-04-08 13:15:04 --> Model Class Initialized
INFO - 2018-04-08 13:15:04 --> Model Class Initialized
INFO - 2018-04-08 13:15:04 --> Model Class Initialized
INFO - 2018-04-08 13:15:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:15:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 13:15:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 13:15:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\admins/admins.php
INFO - 2018-04-08 13:15:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 13:15:04 --> Final output sent to browser
DEBUG - 2018-04-08 13:15:04 --> Total execution time: 0.1310
INFO - 2018-04-08 13:17:17 --> Config Class Initialized
INFO - 2018-04-08 13:17:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:17:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:17:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:17:17 --> URI Class Initialized
INFO - 2018-04-08 13:17:17 --> Router Class Initialized
INFO - 2018-04-08 13:17:17 --> Output Class Initialized
INFO - 2018-04-08 13:17:17 --> Security Class Initialized
DEBUG - 2018-04-08 13:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:17:17 --> Input Class Initialized
INFO - 2018-04-08 13:17:17 --> Language Class Initialized
INFO - 2018-04-08 13:17:17 --> Loader Class Initialized
INFO - 2018-04-08 13:17:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:17:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:17:17 --> Email Class Initialized
INFO - 2018-04-08 13:17:17 --> Controller Class Initialized
INFO - 2018-04-08 13:17:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:17:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:17:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:17:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:17:17 --> Model Class Initialized
INFO - 2018-04-08 13:17:17 --> Model Class Initialized
INFO - 2018-04-08 13:17:17 --> Model Class Initialized
INFO - 2018-04-08 16:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 16:47:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:47:17 --> Final output sent to browser
DEBUG - 2018-04-08 16:47:17 --> Total execution time: 0.1330
INFO - 2018-04-08 13:17:27 --> Config Class Initialized
INFO - 2018-04-08 13:17:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:17:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:17:27 --> Utf8 Class Initialized
INFO - 2018-04-08 13:17:27 --> URI Class Initialized
INFO - 2018-04-08 13:17:27 --> Router Class Initialized
INFO - 2018-04-08 13:17:27 --> Output Class Initialized
INFO - 2018-04-08 13:17:27 --> Security Class Initialized
DEBUG - 2018-04-08 13:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:17:27 --> Input Class Initialized
INFO - 2018-04-08 13:17:27 --> Language Class Initialized
INFO - 2018-04-08 13:17:27 --> Loader Class Initialized
INFO - 2018-04-08 13:17:27 --> Helper loaded: common_helper
INFO - 2018-04-08 13:17:27 --> Database Driver Class Initialized
INFO - 2018-04-08 13:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:17:27 --> Email Class Initialized
INFO - 2018-04-08 13:17:27 --> Controller Class Initialized
INFO - 2018-04-08 13:17:27 --> Helper loaded: form_helper
INFO - 2018-04-08 13:17:27 --> Form Validation Class Initialized
INFO - 2018-04-08 13:17:27 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:17:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:17:27 --> Helper loaded: url_helper
INFO - 2018-04-08 13:17:27 --> Model Class Initialized
INFO - 2018-04-08 13:17:27 --> Model Class Initialized
INFO - 2018-04-08 13:17:27 --> Model Class Initialized
INFO - 2018-04-08 16:47:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:47:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:47:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 16:47:27 --> Undefined variable: ffs
ERROR - 2018-04-08 16:47:27 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 16:47:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 16:47:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:47:27 --> Final output sent to browser
DEBUG - 2018-04-08 16:47:27 --> Total execution time: 0.1320
INFO - 2018-04-08 13:17:33 --> Config Class Initialized
INFO - 2018-04-08 13:17:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:17:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:17:33 --> Utf8 Class Initialized
INFO - 2018-04-08 13:17:33 --> URI Class Initialized
INFO - 2018-04-08 13:17:33 --> Router Class Initialized
INFO - 2018-04-08 13:17:33 --> Output Class Initialized
INFO - 2018-04-08 13:17:33 --> Security Class Initialized
DEBUG - 2018-04-08 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:17:33 --> Input Class Initialized
INFO - 2018-04-08 13:17:33 --> Language Class Initialized
INFO - 2018-04-08 13:17:33 --> Loader Class Initialized
INFO - 2018-04-08 13:17:33 --> Helper loaded: common_helper
INFO - 2018-04-08 13:17:33 --> Database Driver Class Initialized
INFO - 2018-04-08 13:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:17:33 --> Email Class Initialized
INFO - 2018-04-08 13:17:33 --> Controller Class Initialized
INFO - 2018-04-08 13:17:33 --> Helper loaded: form_helper
INFO - 2018-04-08 13:17:33 --> Form Validation Class Initialized
INFO - 2018-04-08 13:17:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:17:33 --> Helper loaded: url_helper
INFO - 2018-04-08 13:17:33 --> Model Class Initialized
INFO - 2018-04-08 13:17:33 --> Model Class Initialized
INFO - 2018-04-08 13:17:33 --> Model Class Initialized
INFO - 2018-04-08 16:47:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:47:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:47:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:47:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 16:47:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:47:33 --> Final output sent to browser
DEBUG - 2018-04-08 16:47:33 --> Total execution time: 0.1230
INFO - 2018-04-08 13:17:42 --> Config Class Initialized
INFO - 2018-04-08 13:17:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:17:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:17:42 --> Utf8 Class Initialized
INFO - 2018-04-08 13:17:42 --> URI Class Initialized
INFO - 2018-04-08 13:17:42 --> Router Class Initialized
INFO - 2018-04-08 13:17:42 --> Output Class Initialized
INFO - 2018-04-08 13:17:42 --> Security Class Initialized
DEBUG - 2018-04-08 13:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:17:42 --> Input Class Initialized
INFO - 2018-04-08 13:17:42 --> Language Class Initialized
INFO - 2018-04-08 13:17:42 --> Loader Class Initialized
INFO - 2018-04-08 13:17:42 --> Helper loaded: common_helper
INFO - 2018-04-08 13:17:42 --> Database Driver Class Initialized
INFO - 2018-04-08 13:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:17:42 --> Email Class Initialized
INFO - 2018-04-08 13:17:42 --> Controller Class Initialized
INFO - 2018-04-08 13:17:42 --> Helper loaded: form_helper
INFO - 2018-04-08 13:17:42 --> Form Validation Class Initialized
INFO - 2018-04-08 13:17:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:17:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:17:42 --> Helper loaded: url_helper
INFO - 2018-04-08 13:17:42 --> Model Class Initialized
INFO - 2018-04-08 13:17:42 --> Model Class Initialized
INFO - 2018-04-08 13:17:42 --> Model Class Initialized
INFO - 2018-04-08 16:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/imagedata.php
INFO - 2018-04-08 16:47:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:47:42 --> Final output sent to browser
DEBUG - 2018-04-08 16:47:42 --> Total execution time: 0.1230
INFO - 2018-04-08 13:18:06 --> Config Class Initialized
INFO - 2018-04-08 13:18:06 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:18:06 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:18:06 --> Utf8 Class Initialized
INFO - 2018-04-08 13:18:06 --> URI Class Initialized
INFO - 2018-04-08 13:18:06 --> Router Class Initialized
INFO - 2018-04-08 13:18:06 --> Output Class Initialized
INFO - 2018-04-08 13:18:06 --> Security Class Initialized
DEBUG - 2018-04-08 13:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:18:06 --> Input Class Initialized
INFO - 2018-04-08 13:18:06 --> Language Class Initialized
INFO - 2018-04-08 13:18:06 --> Loader Class Initialized
INFO - 2018-04-08 13:18:06 --> Helper loaded: common_helper
INFO - 2018-04-08 13:18:06 --> Database Driver Class Initialized
INFO - 2018-04-08 13:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:18:06 --> Email Class Initialized
INFO - 2018-04-08 13:18:06 --> Controller Class Initialized
INFO - 2018-04-08 13:18:06 --> Helper loaded: form_helper
INFO - 2018-04-08 13:18:06 --> Form Validation Class Initialized
INFO - 2018-04-08 13:18:06 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:18:06 --> Helper loaded: url_helper
INFO - 2018-04-08 13:18:06 --> Model Class Initialized
INFO - 2018-04-08 13:18:06 --> Model Class Initialized
INFO - 2018-04-08 13:18:06 --> Model Class Initialized
INFO - 2018-04-08 16:48:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:48:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:48:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:48:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 16:48:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:48:06 --> Final output sent to browser
DEBUG - 2018-04-08 16:48:06 --> Total execution time: 0.1230
INFO - 2018-04-08 13:18:12 --> Config Class Initialized
INFO - 2018-04-08 13:18:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:18:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:18:12 --> Utf8 Class Initialized
INFO - 2018-04-08 13:18:12 --> URI Class Initialized
INFO - 2018-04-08 13:18:12 --> Router Class Initialized
INFO - 2018-04-08 13:18:12 --> Output Class Initialized
INFO - 2018-04-08 13:18:12 --> Security Class Initialized
DEBUG - 2018-04-08 13:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:18:12 --> Input Class Initialized
INFO - 2018-04-08 13:18:12 --> Language Class Initialized
INFO - 2018-04-08 13:18:12 --> Loader Class Initialized
INFO - 2018-04-08 13:18:12 --> Helper loaded: common_helper
INFO - 2018-04-08 13:18:12 --> Database Driver Class Initialized
INFO - 2018-04-08 13:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:18:12 --> Email Class Initialized
INFO - 2018-04-08 13:18:12 --> Controller Class Initialized
INFO - 2018-04-08 13:18:12 --> Helper loaded: form_helper
INFO - 2018-04-08 13:18:12 --> Form Validation Class Initialized
INFO - 2018-04-08 13:18:12 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:18:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:18:12 --> Helper loaded: url_helper
INFO - 2018-04-08 13:18:12 --> Model Class Initialized
INFO - 2018-04-08 13:18:12 --> Model Class Initialized
INFO - 2018-04-08 13:18:12 --> Model Class Initialized
INFO - 2018-04-08 16:48:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:48:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:48:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:48:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 16:48:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:48:13 --> Final output sent to browser
DEBUG - 2018-04-08 16:48:13 --> Total execution time: 0.1370
INFO - 2018-04-08 13:18:30 --> Config Class Initialized
INFO - 2018-04-08 13:18:30 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:18:30 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:18:30 --> Utf8 Class Initialized
INFO - 2018-04-08 13:18:30 --> URI Class Initialized
INFO - 2018-04-08 13:18:30 --> Router Class Initialized
INFO - 2018-04-08 13:18:30 --> Output Class Initialized
INFO - 2018-04-08 13:18:30 --> Security Class Initialized
DEBUG - 2018-04-08 13:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:18:30 --> Input Class Initialized
INFO - 2018-04-08 13:18:30 --> Language Class Initialized
INFO - 2018-04-08 13:18:30 --> Loader Class Initialized
INFO - 2018-04-08 13:18:30 --> Helper loaded: common_helper
INFO - 2018-04-08 13:18:30 --> Database Driver Class Initialized
INFO - 2018-04-08 13:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:18:30 --> Email Class Initialized
INFO - 2018-04-08 13:18:30 --> Controller Class Initialized
INFO - 2018-04-08 13:18:30 --> Helper loaded: form_helper
INFO - 2018-04-08 13:18:30 --> Form Validation Class Initialized
INFO - 2018-04-08 13:18:30 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:18:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:18:30 --> Helper loaded: url_helper
INFO - 2018-04-08 13:18:30 --> Model Class Initialized
INFO - 2018-04-08 13:18:30 --> Model Class Initialized
INFO - 2018-04-08 13:18:30 --> Model Class Initialized
INFO - 2018-04-08 16:48:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:48:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:48:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:48:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 16:48:30 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:48:30 --> Final output sent to browser
DEBUG - 2018-04-08 16:48:30 --> Total execution time: 0.2860
INFO - 2018-04-08 13:26:36 --> Config Class Initialized
INFO - 2018-04-08 13:26:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:26:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:26:36 --> Utf8 Class Initialized
INFO - 2018-04-08 13:26:36 --> URI Class Initialized
INFO - 2018-04-08 13:26:36 --> Router Class Initialized
INFO - 2018-04-08 13:26:36 --> Output Class Initialized
INFO - 2018-04-08 13:26:36 --> Security Class Initialized
DEBUG - 2018-04-08 13:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:26:36 --> Input Class Initialized
INFO - 2018-04-08 13:26:36 --> Language Class Initialized
INFO - 2018-04-08 13:26:36 --> Loader Class Initialized
INFO - 2018-04-08 13:26:36 --> Helper loaded: common_helper
INFO - 2018-04-08 13:26:36 --> Database Driver Class Initialized
INFO - 2018-04-08 13:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:26:36 --> Email Class Initialized
INFO - 2018-04-08 13:26:36 --> Controller Class Initialized
INFO - 2018-04-08 13:26:36 --> Helper loaded: form_helper
INFO - 2018-04-08 13:26:36 --> Form Validation Class Initialized
INFO - 2018-04-08 13:26:36 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:26:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:26:36 --> Helper loaded: url_helper
INFO - 2018-04-08 13:26:36 --> Model Class Initialized
INFO - 2018-04-08 13:26:36 --> Model Class Initialized
INFO - 2018-04-08 13:26:36 --> Model Class Initialized
INFO - 2018-04-08 16:56:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:56:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:56:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:56:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/songsLink.php
INFO - 2018-04-08 16:56:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:56:36 --> Final output sent to browser
DEBUG - 2018-04-08 16:56:36 --> Total execution time: 0.1360
INFO - 2018-04-08 13:26:38 --> Config Class Initialized
INFO - 2018-04-08 13:26:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:26:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:26:38 --> Utf8 Class Initialized
INFO - 2018-04-08 13:26:38 --> URI Class Initialized
INFO - 2018-04-08 13:26:38 --> Router Class Initialized
INFO - 2018-04-08 13:26:38 --> Output Class Initialized
INFO - 2018-04-08 13:26:38 --> Security Class Initialized
DEBUG - 2018-04-08 13:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:26:38 --> Input Class Initialized
INFO - 2018-04-08 13:26:38 --> Language Class Initialized
INFO - 2018-04-08 13:26:38 --> Loader Class Initialized
INFO - 2018-04-08 13:26:38 --> Helper loaded: common_helper
INFO - 2018-04-08 13:26:38 --> Database Driver Class Initialized
INFO - 2018-04-08 13:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:26:38 --> Email Class Initialized
INFO - 2018-04-08 13:26:38 --> Controller Class Initialized
INFO - 2018-04-08 13:26:38 --> Helper loaded: form_helper
INFO - 2018-04-08 13:26:38 --> Form Validation Class Initialized
INFO - 2018-04-08 13:26:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:26:38 --> Helper loaded: url_helper
INFO - 2018-04-08 13:26:38 --> Model Class Initialized
INFO - 2018-04-08 13:26:38 --> Model Class Initialized
INFO - 2018-04-08 13:26:38 --> Model Class Initialized
ERROR - 2018-04-08 16:56:38 --> Undefined variable: newsTitle
ERROR - 2018-04-08 16:56:38 --> Severity: Notice --> Undefined variable: newsTitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
ERROR - 2018-04-08 16:56:38 --> Trying to get property of non-object
ERROR - 2018-04-08 16:56:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
INFO - 2018-04-08 13:26:39 --> Config Class Initialized
INFO - 2018-04-08 13:26:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:26:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:26:39 --> Utf8 Class Initialized
INFO - 2018-04-08 13:26:39 --> URI Class Initialized
INFO - 2018-04-08 13:26:39 --> Router Class Initialized
INFO - 2018-04-08 13:26:39 --> Output Class Initialized
INFO - 2018-04-08 13:26:39 --> Security Class Initialized
DEBUG - 2018-04-08 13:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:26:39 --> Input Class Initialized
INFO - 2018-04-08 13:26:39 --> Language Class Initialized
INFO - 2018-04-08 13:26:39 --> Loader Class Initialized
INFO - 2018-04-08 13:26:39 --> Helper loaded: common_helper
INFO - 2018-04-08 13:26:39 --> Database Driver Class Initialized
INFO - 2018-04-08 13:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:26:39 --> Email Class Initialized
INFO - 2018-04-08 13:26:39 --> Controller Class Initialized
INFO - 2018-04-08 13:26:39 --> Helper loaded: form_helper
INFO - 2018-04-08 13:26:39 --> Form Validation Class Initialized
INFO - 2018-04-08 13:26:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:26:39 --> Helper loaded: url_helper
INFO - 2018-04-08 13:26:39 --> Model Class Initialized
INFO - 2018-04-08 13:26:39 --> Model Class Initialized
INFO - 2018-04-08 13:26:39 --> Model Class Initialized
INFO - 2018-04-08 16:56:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:56:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:56:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:56:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/imagedata.php
INFO - 2018-04-08 16:56:39 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:56:39 --> Final output sent to browser
DEBUG - 2018-04-08 16:56:39 --> Total execution time: 0.1290
INFO - 2018-04-08 13:26:41 --> Config Class Initialized
INFO - 2018-04-08 13:26:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:26:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:26:41 --> Utf8 Class Initialized
INFO - 2018-04-08 13:26:41 --> URI Class Initialized
INFO - 2018-04-08 13:26:41 --> Router Class Initialized
INFO - 2018-04-08 13:26:41 --> Output Class Initialized
INFO - 2018-04-08 13:26:41 --> Security Class Initialized
DEBUG - 2018-04-08 13:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:26:41 --> Input Class Initialized
INFO - 2018-04-08 13:26:41 --> Language Class Initialized
INFO - 2018-04-08 13:26:41 --> Loader Class Initialized
INFO - 2018-04-08 13:26:41 --> Helper loaded: common_helper
INFO - 2018-04-08 13:26:41 --> Database Driver Class Initialized
INFO - 2018-04-08 13:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:26:41 --> Email Class Initialized
INFO - 2018-04-08 13:26:41 --> Controller Class Initialized
INFO - 2018-04-08 13:26:41 --> Helper loaded: form_helper
INFO - 2018-04-08 13:26:41 --> Form Validation Class Initialized
INFO - 2018-04-08 13:26:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:26:41 --> Helper loaded: url_helper
INFO - 2018-04-08 13:26:41 --> Model Class Initialized
INFO - 2018-04-08 13:26:41 --> Model Class Initialized
INFO - 2018-04-08 13:26:41 --> Model Class Initialized
ERROR - 2018-04-08 16:56:41 --> Undefined variable: newsTitle
ERROR - 2018-04-08 16:56:41 --> Severity: Notice --> Undefined variable: newsTitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
ERROR - 2018-04-08 16:56:41 --> Trying to get property of non-object
ERROR - 2018-04-08 16:56:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
INFO - 2018-04-08 13:27:10 --> Config Class Initialized
INFO - 2018-04-08 13:27:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:27:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:27:10 --> Utf8 Class Initialized
INFO - 2018-04-08 13:27:10 --> URI Class Initialized
INFO - 2018-04-08 13:27:10 --> Router Class Initialized
INFO - 2018-04-08 13:27:10 --> Output Class Initialized
INFO - 2018-04-08 13:27:10 --> Security Class Initialized
DEBUG - 2018-04-08 13:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:27:10 --> Input Class Initialized
INFO - 2018-04-08 13:27:10 --> Language Class Initialized
INFO - 2018-04-08 13:27:10 --> Loader Class Initialized
INFO - 2018-04-08 13:27:10 --> Helper loaded: common_helper
INFO - 2018-04-08 13:27:10 --> Database Driver Class Initialized
INFO - 2018-04-08 13:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:27:10 --> Email Class Initialized
INFO - 2018-04-08 13:27:10 --> Controller Class Initialized
INFO - 2018-04-08 13:27:10 --> Helper loaded: form_helper
INFO - 2018-04-08 13:27:10 --> Form Validation Class Initialized
INFO - 2018-04-08 13:27:10 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:27:10 --> Helper loaded: url_helper
INFO - 2018-04-08 13:27:10 --> Model Class Initialized
INFO - 2018-04-08 13:27:10 --> Model Class Initialized
INFO - 2018-04-08 13:27:10 --> Model Class Initialized
ERROR - 2018-04-08 16:57:10 --> Trying to get property of non-object
ERROR - 2018-04-08 16:57:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
INFO - 2018-04-08 13:27:14 --> Config Class Initialized
INFO - 2018-04-08 13:27:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:27:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:27:14 --> Utf8 Class Initialized
INFO - 2018-04-08 13:27:14 --> URI Class Initialized
INFO - 2018-04-08 13:27:14 --> Router Class Initialized
INFO - 2018-04-08 13:27:14 --> Output Class Initialized
INFO - 2018-04-08 13:27:14 --> Security Class Initialized
DEBUG - 2018-04-08 13:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:27:14 --> Input Class Initialized
INFO - 2018-04-08 13:27:14 --> Language Class Initialized
INFO - 2018-04-08 13:27:14 --> Loader Class Initialized
INFO - 2018-04-08 13:27:14 --> Helper loaded: common_helper
INFO - 2018-04-08 13:27:14 --> Database Driver Class Initialized
INFO - 2018-04-08 13:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:27:14 --> Email Class Initialized
INFO - 2018-04-08 13:27:14 --> Controller Class Initialized
INFO - 2018-04-08 13:27:14 --> Helper loaded: form_helper
INFO - 2018-04-08 13:27:14 --> Form Validation Class Initialized
INFO - 2018-04-08 13:27:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:27:14 --> Helper loaded: url_helper
INFO - 2018-04-08 13:27:14 --> Model Class Initialized
INFO - 2018-04-08 13:27:14 --> Model Class Initialized
INFO - 2018-04-08 13:27:14 --> Model Class Initialized
INFO - 2018-04-08 16:57:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:57:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:57:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 16:57:14 --> Undefined variable: ffs
ERROR - 2018-04-08 16:57:14 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 16:57:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 16:57:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:57:14 --> Final output sent to browser
DEBUG - 2018-04-08 16:57:14 --> Total execution time: 0.1260
INFO - 2018-04-08 13:27:16 --> Config Class Initialized
INFO - 2018-04-08 13:27:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:27:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:27:16 --> Utf8 Class Initialized
INFO - 2018-04-08 13:27:16 --> URI Class Initialized
INFO - 2018-04-08 13:27:16 --> Router Class Initialized
INFO - 2018-04-08 13:27:16 --> Output Class Initialized
INFO - 2018-04-08 13:27:16 --> Security Class Initialized
DEBUG - 2018-04-08 13:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:27:16 --> Input Class Initialized
INFO - 2018-04-08 13:27:16 --> Language Class Initialized
INFO - 2018-04-08 13:27:16 --> Loader Class Initialized
INFO - 2018-04-08 13:27:16 --> Helper loaded: common_helper
INFO - 2018-04-08 13:27:16 --> Database Driver Class Initialized
INFO - 2018-04-08 13:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:27:16 --> Email Class Initialized
INFO - 2018-04-08 13:27:16 --> Controller Class Initialized
INFO - 2018-04-08 13:27:16 --> Helper loaded: form_helper
INFO - 2018-04-08 13:27:16 --> Form Validation Class Initialized
INFO - 2018-04-08 13:27:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:27:16 --> Helper loaded: url_helper
INFO - 2018-04-08 13:27:16 --> Model Class Initialized
INFO - 2018-04-08 13:27:16 --> Model Class Initialized
INFO - 2018-04-08 13:27:16 --> Model Class Initialized
INFO - 2018-04-08 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 16:57:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:57:16 --> Final output sent to browser
DEBUG - 2018-04-08 16:57:16 --> Total execution time: 0.1270
INFO - 2018-04-08 13:27:18 --> Config Class Initialized
INFO - 2018-04-08 13:27:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:27:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:27:18 --> Utf8 Class Initialized
INFO - 2018-04-08 13:27:18 --> URI Class Initialized
INFO - 2018-04-08 13:27:18 --> Router Class Initialized
INFO - 2018-04-08 13:27:18 --> Output Class Initialized
INFO - 2018-04-08 13:27:18 --> Security Class Initialized
DEBUG - 2018-04-08 13:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:27:18 --> Input Class Initialized
INFO - 2018-04-08 13:27:18 --> Language Class Initialized
INFO - 2018-04-08 13:27:18 --> Loader Class Initialized
INFO - 2018-04-08 13:27:18 --> Helper loaded: common_helper
INFO - 2018-04-08 13:27:18 --> Database Driver Class Initialized
INFO - 2018-04-08 13:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:27:18 --> Email Class Initialized
INFO - 2018-04-08 13:27:18 --> Controller Class Initialized
INFO - 2018-04-08 13:27:18 --> Helper loaded: form_helper
INFO - 2018-04-08 13:27:18 --> Form Validation Class Initialized
INFO - 2018-04-08 13:27:18 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:27:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:27:18 --> Helper loaded: url_helper
INFO - 2018-04-08 13:27:18 --> Model Class Initialized
INFO - 2018-04-08 13:27:18 --> Model Class Initialized
INFO - 2018-04-08 13:27:18 --> Model Class Initialized
INFO - 2018-04-08 16:57:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:57:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:57:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 16:57:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 16:57:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:57:18 --> Final output sent to browser
DEBUG - 2018-04-08 16:57:18 --> Total execution time: 0.1410
INFO - 2018-04-08 13:27:21 --> Config Class Initialized
INFO - 2018-04-08 13:27:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:27:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:27:21 --> Utf8 Class Initialized
INFO - 2018-04-08 13:27:21 --> URI Class Initialized
INFO - 2018-04-08 13:27:21 --> Router Class Initialized
INFO - 2018-04-08 13:27:21 --> Output Class Initialized
INFO - 2018-04-08 13:27:21 --> Security Class Initialized
DEBUG - 2018-04-08 13:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:27:21 --> Input Class Initialized
INFO - 2018-04-08 13:27:21 --> Language Class Initialized
INFO - 2018-04-08 13:27:21 --> Loader Class Initialized
INFO - 2018-04-08 13:27:21 --> Helper loaded: common_helper
INFO - 2018-04-08 13:27:21 --> Database Driver Class Initialized
INFO - 2018-04-08 13:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:27:21 --> Email Class Initialized
INFO - 2018-04-08 13:27:21 --> Controller Class Initialized
INFO - 2018-04-08 13:27:21 --> Helper loaded: form_helper
INFO - 2018-04-08 13:27:21 --> Form Validation Class Initialized
INFO - 2018-04-08 13:27:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:27:21 --> Helper loaded: url_helper
INFO - 2018-04-08 13:27:21 --> Model Class Initialized
INFO - 2018-04-08 13:27:21 --> Model Class Initialized
INFO - 2018-04-08 13:27:21 --> Model Class Initialized
INFO - 2018-04-08 16:57:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 16:57:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 16:57:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 16:57:21 --> Undefined variable: ffs
ERROR - 2018-04-08 16:57:21 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 16:57:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 16:57:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 16:57:21 --> Final output sent to browser
DEBUG - 2018-04-08 16:57:21 --> Total execution time: 0.1300
INFO - 2018-04-08 13:27:24 --> Config Class Initialized
INFO - 2018-04-08 13:27:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:27:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:27:24 --> Utf8 Class Initialized
INFO - 2018-04-08 13:27:24 --> URI Class Initialized
INFO - 2018-04-08 13:27:24 --> Router Class Initialized
INFO - 2018-04-08 13:27:24 --> Output Class Initialized
INFO - 2018-04-08 13:27:24 --> Security Class Initialized
DEBUG - 2018-04-08 13:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:27:24 --> Input Class Initialized
INFO - 2018-04-08 13:27:24 --> Language Class Initialized
INFO - 2018-04-08 13:27:24 --> Loader Class Initialized
INFO - 2018-04-08 13:27:24 --> Helper loaded: common_helper
INFO - 2018-04-08 13:27:24 --> Database Driver Class Initialized
INFO - 2018-04-08 13:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:27:24 --> Email Class Initialized
INFO - 2018-04-08 13:27:24 --> Controller Class Initialized
INFO - 2018-04-08 13:27:24 --> Helper loaded: form_helper
INFO - 2018-04-08 13:27:24 --> Form Validation Class Initialized
INFO - 2018-04-08 13:27:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:27:24 --> Helper loaded: url_helper
INFO - 2018-04-08 13:27:24 --> Model Class Initialized
INFO - 2018-04-08 13:27:24 --> Model Class Initialized
INFO - 2018-04-08 13:27:24 --> Model Class Initialized
ERROR - 2018-04-08 16:57:24 --> Trying to get property of non-object
ERROR - 2018-04-08 16:57:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
INFO - 2018-04-08 13:28:09 --> Config Class Initialized
INFO - 2018-04-08 13:28:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:28:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:28:09 --> Utf8 Class Initialized
INFO - 2018-04-08 13:28:09 --> URI Class Initialized
INFO - 2018-04-08 13:28:09 --> Router Class Initialized
INFO - 2018-04-08 13:28:09 --> Output Class Initialized
INFO - 2018-04-08 13:28:09 --> Security Class Initialized
DEBUG - 2018-04-08 13:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:28:09 --> Input Class Initialized
INFO - 2018-04-08 13:28:09 --> Language Class Initialized
INFO - 2018-04-08 13:28:09 --> Loader Class Initialized
INFO - 2018-04-08 13:28:09 --> Helper loaded: common_helper
INFO - 2018-04-08 13:28:09 --> Database Driver Class Initialized
INFO - 2018-04-08 13:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:28:09 --> Email Class Initialized
INFO - 2018-04-08 13:28:09 --> Controller Class Initialized
INFO - 2018-04-08 13:28:09 --> Helper loaded: form_helper
INFO - 2018-04-08 13:28:09 --> Form Validation Class Initialized
INFO - 2018-04-08 13:28:09 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:28:09 --> Helper loaded: url_helper
INFO - 2018-04-08 13:28:09 --> Model Class Initialized
INFO - 2018-04-08 13:28:09 --> Model Class Initialized
INFO - 2018-04-08 13:28:09 --> Model Class Initialized
INFO - 2018-04-08 13:28:32 --> Config Class Initialized
INFO - 2018-04-08 13:28:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:28:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:28:32 --> Utf8 Class Initialized
INFO - 2018-04-08 13:28:32 --> URI Class Initialized
INFO - 2018-04-08 13:28:32 --> Router Class Initialized
INFO - 2018-04-08 13:28:32 --> Output Class Initialized
INFO - 2018-04-08 13:28:32 --> Security Class Initialized
DEBUG - 2018-04-08 13:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:28:32 --> Input Class Initialized
INFO - 2018-04-08 13:28:32 --> Language Class Initialized
INFO - 2018-04-08 13:28:32 --> Loader Class Initialized
INFO - 2018-04-08 13:28:32 --> Helper loaded: common_helper
INFO - 2018-04-08 13:28:32 --> Database Driver Class Initialized
INFO - 2018-04-08 13:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:28:32 --> Email Class Initialized
INFO - 2018-04-08 13:28:32 --> Controller Class Initialized
INFO - 2018-04-08 13:28:32 --> Helper loaded: form_helper
INFO - 2018-04-08 13:28:32 --> Form Validation Class Initialized
INFO - 2018-04-08 13:28:32 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:28:32 --> Helper loaded: url_helper
INFO - 2018-04-08 13:28:32 --> Model Class Initialized
INFO - 2018-04-08 13:28:32 --> Model Class Initialized
INFO - 2018-04-08 13:28:32 --> Model Class Initialized
INFO - 2018-04-08 13:29:27 --> Config Class Initialized
INFO - 2018-04-08 13:29:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:29:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:29:27 --> Utf8 Class Initialized
INFO - 2018-04-08 13:29:27 --> URI Class Initialized
INFO - 2018-04-08 13:29:27 --> Router Class Initialized
INFO - 2018-04-08 13:29:27 --> Output Class Initialized
INFO - 2018-04-08 13:29:27 --> Security Class Initialized
DEBUG - 2018-04-08 13:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:29:27 --> Input Class Initialized
INFO - 2018-04-08 13:29:27 --> Language Class Initialized
INFO - 2018-04-08 13:29:27 --> Loader Class Initialized
INFO - 2018-04-08 13:29:27 --> Helper loaded: common_helper
INFO - 2018-04-08 13:29:27 --> Database Driver Class Initialized
INFO - 2018-04-08 13:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:29:27 --> Email Class Initialized
INFO - 2018-04-08 13:29:27 --> Controller Class Initialized
INFO - 2018-04-08 13:29:27 --> Helper loaded: form_helper
INFO - 2018-04-08 13:29:27 --> Form Validation Class Initialized
INFO - 2018-04-08 13:29:27 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:29:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:29:27 --> Helper loaded: url_helper
INFO - 2018-04-08 13:29:27 --> Model Class Initialized
INFO - 2018-04-08 13:29:27 --> Model Class Initialized
INFO - 2018-04-08 13:29:27 --> Model Class Initialized
ERROR - 2018-04-08 16:59:27 --> Undefined property: stdClass::$news_id
ERROR - 2018-04-08 16:59:27 --> Severity: Notice --> Undefined property: stdClass::$news_id C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
INFO - 2018-04-08 13:30:05 --> Config Class Initialized
INFO - 2018-04-08 13:30:05 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:30:05 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:30:05 --> Utf8 Class Initialized
INFO - 2018-04-08 13:30:05 --> URI Class Initialized
INFO - 2018-04-08 13:30:05 --> Router Class Initialized
INFO - 2018-04-08 13:30:05 --> Output Class Initialized
INFO - 2018-04-08 13:30:05 --> Security Class Initialized
DEBUG - 2018-04-08 13:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:30:05 --> Input Class Initialized
INFO - 2018-04-08 13:30:05 --> Language Class Initialized
INFO - 2018-04-08 13:30:05 --> Loader Class Initialized
INFO - 2018-04-08 13:30:05 --> Helper loaded: common_helper
INFO - 2018-04-08 13:30:05 --> Database Driver Class Initialized
INFO - 2018-04-08 13:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:30:05 --> Email Class Initialized
INFO - 2018-04-08 13:30:05 --> Controller Class Initialized
INFO - 2018-04-08 13:30:05 --> Helper loaded: form_helper
INFO - 2018-04-08 13:30:05 --> Form Validation Class Initialized
INFO - 2018-04-08 13:30:05 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:30:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:30:05 --> Helper loaded: url_helper
INFO - 2018-04-08 13:30:05 --> Model Class Initialized
INFO - 2018-04-08 13:30:05 --> Model Class Initialized
INFO - 2018-04-08 13:30:05 --> Model Class Initialized
INFO - 2018-04-08 13:36:00 --> Config Class Initialized
INFO - 2018-04-08 13:36:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:36:00 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:36:00 --> Utf8 Class Initialized
INFO - 2018-04-08 13:36:00 --> URI Class Initialized
INFO - 2018-04-08 13:36:00 --> Router Class Initialized
INFO - 2018-04-08 13:36:00 --> Output Class Initialized
INFO - 2018-04-08 13:36:00 --> Security Class Initialized
DEBUG - 2018-04-08 13:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:36:00 --> Input Class Initialized
INFO - 2018-04-08 13:36:00 --> Language Class Initialized
INFO - 2018-04-08 13:36:00 --> Loader Class Initialized
INFO - 2018-04-08 13:36:00 --> Helper loaded: common_helper
INFO - 2018-04-08 13:36:00 --> Database Driver Class Initialized
INFO - 2018-04-08 13:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:36:00 --> Email Class Initialized
INFO - 2018-04-08 13:36:00 --> Controller Class Initialized
INFO - 2018-04-08 13:36:00 --> Helper loaded: form_helper
INFO - 2018-04-08 13:36:00 --> Form Validation Class Initialized
INFO - 2018-04-08 13:36:00 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:36:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:36:00 --> Helper loaded: url_helper
INFO - 2018-04-08 13:36:00 --> Model Class Initialized
INFO - 2018-04-08 13:36:00 --> Model Class Initialized
INFO - 2018-04-08 13:36:00 --> Model Class Initialized
INFO - 2018-04-08 17:06:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:06:00 --> syntax error, unexpected '$newsImage' (T_VARIABLE)
ERROR - 2018-04-08 17:06:00 --> Severity: Parsing Error --> syntax error, unexpected '$newsImage' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 67
INFO - 2018-04-08 13:37:03 --> Config Class Initialized
INFO - 2018-04-08 13:37:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:37:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:37:04 --> Utf8 Class Initialized
INFO - 2018-04-08 13:37:04 --> URI Class Initialized
INFO - 2018-04-08 13:37:04 --> Router Class Initialized
INFO - 2018-04-08 13:37:04 --> Output Class Initialized
INFO - 2018-04-08 13:37:04 --> Security Class Initialized
DEBUG - 2018-04-08 13:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:37:04 --> Input Class Initialized
INFO - 2018-04-08 13:37:04 --> Language Class Initialized
INFO - 2018-04-08 13:37:04 --> Loader Class Initialized
INFO - 2018-04-08 13:37:04 --> Helper loaded: common_helper
INFO - 2018-04-08 13:37:04 --> Database Driver Class Initialized
INFO - 2018-04-08 13:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:37:04 --> Email Class Initialized
INFO - 2018-04-08 13:37:04 --> Controller Class Initialized
INFO - 2018-04-08 13:37:04 --> Helper loaded: form_helper
INFO - 2018-04-08 13:37:04 --> Form Validation Class Initialized
INFO - 2018-04-08 13:37:04 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:37:04 --> Helper loaded: url_helper
INFO - 2018-04-08 13:37:04 --> Model Class Initialized
INFO - 2018-04-08 13:37:04 --> Model Class Initialized
INFO - 2018-04-08 13:37:04 --> Model Class Initialized
INFO - 2018-04-08 13:39:30 --> Config Class Initialized
INFO - 2018-04-08 13:39:30 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:39:30 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:39:30 --> Utf8 Class Initialized
INFO - 2018-04-08 13:39:30 --> URI Class Initialized
INFO - 2018-04-08 13:39:30 --> Router Class Initialized
INFO - 2018-04-08 13:39:30 --> Output Class Initialized
INFO - 2018-04-08 13:39:30 --> Security Class Initialized
DEBUG - 2018-04-08 13:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:39:30 --> Input Class Initialized
INFO - 2018-04-08 13:39:30 --> Language Class Initialized
INFO - 2018-04-08 13:39:30 --> Loader Class Initialized
INFO - 2018-04-08 13:39:30 --> Helper loaded: common_helper
INFO - 2018-04-08 13:39:30 --> Database Driver Class Initialized
INFO - 2018-04-08 13:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:39:30 --> Email Class Initialized
INFO - 2018-04-08 13:39:30 --> Controller Class Initialized
INFO - 2018-04-08 13:39:30 --> Helper loaded: form_helper
INFO - 2018-04-08 13:39:30 --> Form Validation Class Initialized
INFO - 2018-04-08 13:39:30 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:39:30 --> Helper loaded: url_helper
INFO - 2018-04-08 13:39:30 --> Model Class Initialized
INFO - 2018-04-08 13:39:30 --> Model Class Initialized
INFO - 2018-04-08 13:39:30 --> Model Class Initialized
INFO - 2018-04-08 13:39:42 --> Config Class Initialized
INFO - 2018-04-08 13:39:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:39:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:39:42 --> Utf8 Class Initialized
INFO - 2018-04-08 13:39:42 --> URI Class Initialized
INFO - 2018-04-08 13:39:42 --> Router Class Initialized
INFO - 2018-04-08 13:39:42 --> Output Class Initialized
INFO - 2018-04-08 13:39:42 --> Security Class Initialized
DEBUG - 2018-04-08 13:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:39:42 --> Input Class Initialized
INFO - 2018-04-08 13:39:42 --> Language Class Initialized
INFO - 2018-04-08 13:39:42 --> Loader Class Initialized
INFO - 2018-04-08 13:39:42 --> Helper loaded: common_helper
INFO - 2018-04-08 13:39:42 --> Database Driver Class Initialized
INFO - 2018-04-08 13:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:39:42 --> Email Class Initialized
INFO - 2018-04-08 13:39:42 --> Controller Class Initialized
INFO - 2018-04-08 13:39:42 --> Helper loaded: form_helper
INFO - 2018-04-08 13:39:42 --> Form Validation Class Initialized
INFO - 2018-04-08 13:39:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:39:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:39:42 --> Helper loaded: url_helper
INFO - 2018-04-08 13:39:42 --> Model Class Initialized
INFO - 2018-04-08 13:39:42 --> Model Class Initialized
INFO - 2018-04-08 13:39:42 --> Model Class Initialized
INFO - 2018-04-08 17:09:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:09:42 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:09:42 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:15 --> Config Class Initialized
INFO - 2018-04-08 13:40:15 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:15 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:15 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:15 --> URI Class Initialized
INFO - 2018-04-08 13:40:15 --> Router Class Initialized
INFO - 2018-04-08 13:40:15 --> Output Class Initialized
INFO - 2018-04-08 13:40:15 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:15 --> Input Class Initialized
INFO - 2018-04-08 13:40:15 --> Language Class Initialized
INFO - 2018-04-08 13:40:15 --> Loader Class Initialized
INFO - 2018-04-08 13:40:15 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:15 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:15 --> Email Class Initialized
INFO - 2018-04-08 13:40:15 --> Controller Class Initialized
INFO - 2018-04-08 13:40:15 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:15 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:15 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:15 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:15 --> Model Class Initialized
INFO - 2018-04-08 13:40:15 --> Model Class Initialized
INFO - 2018-04-08 13:40:15 --> Model Class Initialized
INFO - 2018-04-08 17:10:15 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:15 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:15 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:17 --> Config Class Initialized
INFO - 2018-04-08 13:40:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:17 --> URI Class Initialized
INFO - 2018-04-08 13:40:17 --> Router Class Initialized
INFO - 2018-04-08 13:40:17 --> Output Class Initialized
INFO - 2018-04-08 13:40:17 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:17 --> Input Class Initialized
INFO - 2018-04-08 13:40:17 --> Language Class Initialized
INFO - 2018-04-08 13:40:17 --> Loader Class Initialized
INFO - 2018-04-08 13:40:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:17 --> Email Class Initialized
INFO - 2018-04-08 13:40:17 --> Controller Class Initialized
INFO - 2018-04-08 13:40:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:17 --> Model Class Initialized
INFO - 2018-04-08 13:40:17 --> Model Class Initialized
INFO - 2018-04-08 13:40:17 --> Model Class Initialized
INFO - 2018-04-08 17:10:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:17 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:17 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:19 --> Config Class Initialized
INFO - 2018-04-08 13:40:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:19 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:19 --> URI Class Initialized
INFO - 2018-04-08 13:40:19 --> Router Class Initialized
INFO - 2018-04-08 13:40:19 --> Output Class Initialized
INFO - 2018-04-08 13:40:19 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:19 --> Input Class Initialized
INFO - 2018-04-08 13:40:19 --> Language Class Initialized
INFO - 2018-04-08 13:40:19 --> Loader Class Initialized
INFO - 2018-04-08 13:40:19 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:19 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:19 --> Email Class Initialized
INFO - 2018-04-08 13:40:19 --> Controller Class Initialized
INFO - 2018-04-08 13:40:19 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:19 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:19 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:19 --> Model Class Initialized
INFO - 2018-04-08 13:40:19 --> Model Class Initialized
INFO - 2018-04-08 13:40:19 --> Model Class Initialized
INFO - 2018-04-08 17:10:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:10:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:10:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:10:19 --> Undefined variable: ffs
ERROR - 2018-04-08 17:10:19 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:10:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:10:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:10:19 --> Final output sent to browser
DEBUG - 2018-04-08 17:10:19 --> Total execution time: 0.1280
INFO - 2018-04-08 13:40:21 --> Config Class Initialized
INFO - 2018-04-08 13:40:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:21 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:21 --> URI Class Initialized
INFO - 2018-04-08 13:40:21 --> Router Class Initialized
INFO - 2018-04-08 13:40:21 --> Output Class Initialized
INFO - 2018-04-08 13:40:21 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:21 --> Input Class Initialized
INFO - 2018-04-08 13:40:21 --> Language Class Initialized
INFO - 2018-04-08 13:40:21 --> Loader Class Initialized
INFO - 2018-04-08 13:40:21 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:21 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:21 --> Email Class Initialized
INFO - 2018-04-08 13:40:21 --> Controller Class Initialized
INFO - 2018-04-08 13:40:21 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:21 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:21 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:21 --> Model Class Initialized
INFO - 2018-04-08 13:40:21 --> Model Class Initialized
INFO - 2018-04-08 13:40:21 --> Model Class Initialized
INFO - 2018-04-08 17:10:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:21 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:21 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:37 --> Config Class Initialized
INFO - 2018-04-08 13:40:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:37 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:37 --> URI Class Initialized
INFO - 2018-04-08 13:40:37 --> Router Class Initialized
INFO - 2018-04-08 13:40:37 --> Output Class Initialized
INFO - 2018-04-08 13:40:37 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:37 --> Input Class Initialized
INFO - 2018-04-08 13:40:37 --> Language Class Initialized
INFO - 2018-04-08 13:40:37 --> Loader Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:37 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:37 --> Email Class Initialized
INFO - 2018-04-08 13:40:37 --> Controller Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:37 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:37 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:37 --> Model Class Initialized
INFO - 2018-04-08 13:40:37 --> Model Class Initialized
INFO - 2018-04-08 13:40:37 --> Model Class Initialized
INFO - 2018-04-08 17:10:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:37 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:37 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:37 --> Config Class Initialized
INFO - 2018-04-08 13:40:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:37 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:37 --> URI Class Initialized
INFO - 2018-04-08 13:40:37 --> Router Class Initialized
INFO - 2018-04-08 13:40:37 --> Output Class Initialized
INFO - 2018-04-08 13:40:37 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:37 --> Input Class Initialized
INFO - 2018-04-08 13:40:37 --> Language Class Initialized
INFO - 2018-04-08 13:40:37 --> Loader Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:37 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:37 --> Email Class Initialized
INFO - 2018-04-08 13:40:37 --> Controller Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:37 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:37 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:37 --> Model Class Initialized
INFO - 2018-04-08 13:40:37 --> Model Class Initialized
INFO - 2018-04-08 13:40:37 --> Model Class Initialized
INFO - 2018-04-08 17:10:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:37 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:37 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:37 --> Config Class Initialized
INFO - 2018-04-08 13:40:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:37 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:37 --> URI Class Initialized
INFO - 2018-04-08 13:40:37 --> Router Class Initialized
INFO - 2018-04-08 13:40:37 --> Output Class Initialized
INFO - 2018-04-08 13:40:37 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:37 --> Input Class Initialized
INFO - 2018-04-08 13:40:37 --> Language Class Initialized
INFO - 2018-04-08 13:40:37 --> Loader Class Initialized
INFO - 2018-04-08 13:40:37 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:37 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:37 --> Email Class Initialized
INFO - 2018-04-08 13:40:37 --> Controller Class Initialized
INFO - 2018-04-08 13:40:38 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:38 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:38 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:38 --> Model Class Initialized
INFO - 2018-04-08 13:40:38 --> Model Class Initialized
INFO - 2018-04-08 13:40:38 --> Model Class Initialized
INFO - 2018-04-08 17:10:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:38 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:38 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:38 --> Config Class Initialized
INFO - 2018-04-08 13:40:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:38 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:38 --> URI Class Initialized
INFO - 2018-04-08 13:40:38 --> Router Class Initialized
INFO - 2018-04-08 13:40:38 --> Output Class Initialized
INFO - 2018-04-08 13:40:38 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:38 --> Input Class Initialized
INFO - 2018-04-08 13:40:38 --> Language Class Initialized
INFO - 2018-04-08 13:40:38 --> Loader Class Initialized
INFO - 2018-04-08 13:40:38 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:38 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:38 --> Email Class Initialized
INFO - 2018-04-08 13:40:38 --> Controller Class Initialized
INFO - 2018-04-08 13:40:38 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:38 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:38 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:38 --> Model Class Initialized
INFO - 2018-04-08 13:40:38 --> Model Class Initialized
INFO - 2018-04-08 13:40:38 --> Model Class Initialized
INFO - 2018-04-08 17:10:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:38 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:38 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:40:40 --> Config Class Initialized
INFO - 2018-04-08 13:40:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:40 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:40 --> URI Class Initialized
INFO - 2018-04-08 13:40:40 --> Router Class Initialized
INFO - 2018-04-08 13:40:40 --> Output Class Initialized
INFO - 2018-04-08 13:40:40 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:40 --> Input Class Initialized
INFO - 2018-04-08 13:40:40 --> Language Class Initialized
INFO - 2018-04-08 13:40:40 --> Loader Class Initialized
INFO - 2018-04-08 13:40:40 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:40 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:40 --> Email Class Initialized
INFO - 2018-04-08 13:40:40 --> Controller Class Initialized
INFO - 2018-04-08 13:40:40 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:40 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:40 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:40 --> Model Class Initialized
INFO - 2018-04-08 13:40:40 --> Model Class Initialized
INFO - 2018-04-08 13:40:40 --> Model Class Initialized
INFO - 2018-04-08 17:10:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:10:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:10:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:10:40 --> Undefined variable: ffs
ERROR - 2018-04-08 17:10:40 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:10:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:10:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:10:40 --> Final output sent to browser
DEBUG - 2018-04-08 17:10:40 --> Total execution time: 0.1320
INFO - 2018-04-08 13:40:42 --> Config Class Initialized
INFO - 2018-04-08 13:40:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:40:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:40:42 --> Utf8 Class Initialized
INFO - 2018-04-08 13:40:42 --> URI Class Initialized
INFO - 2018-04-08 13:40:42 --> Router Class Initialized
INFO - 2018-04-08 13:40:42 --> Output Class Initialized
INFO - 2018-04-08 13:40:42 --> Security Class Initialized
DEBUG - 2018-04-08 13:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:40:42 --> Input Class Initialized
INFO - 2018-04-08 13:40:42 --> Language Class Initialized
INFO - 2018-04-08 13:40:42 --> Loader Class Initialized
INFO - 2018-04-08 13:40:42 --> Helper loaded: common_helper
INFO - 2018-04-08 13:40:42 --> Database Driver Class Initialized
INFO - 2018-04-08 13:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:40:42 --> Email Class Initialized
INFO - 2018-04-08 13:40:42 --> Controller Class Initialized
INFO - 2018-04-08 13:40:42 --> Helper loaded: form_helper
INFO - 2018-04-08 13:40:42 --> Form Validation Class Initialized
INFO - 2018-04-08 13:40:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:40:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:40:42 --> Helper loaded: url_helper
INFO - 2018-04-08 13:40:42 --> Model Class Initialized
INFO - 2018-04-08 13:40:42 --> Model Class Initialized
INFO - 2018-04-08 13:40:42 --> Model Class Initialized
INFO - 2018-04-08 17:10:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:10:42 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:10:42 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:41:13 --> Config Class Initialized
INFO - 2018-04-08 13:41:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:13 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:13 --> URI Class Initialized
INFO - 2018-04-08 13:41:13 --> Router Class Initialized
INFO - 2018-04-08 13:41:13 --> Output Class Initialized
INFO - 2018-04-08 13:41:13 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:13 --> Input Class Initialized
INFO - 2018-04-08 13:41:13 --> Language Class Initialized
INFO - 2018-04-08 13:41:13 --> Loader Class Initialized
INFO - 2018-04-08 13:41:13 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:14 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:14 --> Email Class Initialized
INFO - 2018-04-08 13:41:14 --> Controller Class Initialized
INFO - 2018-04-08 13:41:14 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:14 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:14 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:14 --> Model Class Initialized
INFO - 2018-04-08 13:41:14 --> Model Class Initialized
INFO - 2018-04-08 13:41:14 --> Model Class Initialized
INFO - 2018-04-08 13:41:35 --> Config Class Initialized
INFO - 2018-04-08 13:41:35 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:35 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:35 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:35 --> URI Class Initialized
INFO - 2018-04-08 13:41:35 --> Router Class Initialized
INFO - 2018-04-08 13:41:35 --> Output Class Initialized
INFO - 2018-04-08 13:41:35 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:35 --> Input Class Initialized
INFO - 2018-04-08 13:41:35 --> Language Class Initialized
INFO - 2018-04-08 13:41:35 --> Loader Class Initialized
INFO - 2018-04-08 13:41:35 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:35 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:35 --> Email Class Initialized
INFO - 2018-04-08 13:41:35 --> Controller Class Initialized
INFO - 2018-04-08 13:41:35 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:35 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:35 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:35 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:35 --> Model Class Initialized
INFO - 2018-04-08 13:41:35 --> Model Class Initialized
INFO - 2018-04-08 13:41:35 --> Model Class Initialized
INFO - 2018-04-08 17:11:35 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:11:35 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:11:35 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:41:46 --> Config Class Initialized
INFO - 2018-04-08 13:41:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:46 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:46 --> URI Class Initialized
INFO - 2018-04-08 13:41:46 --> Router Class Initialized
INFO - 2018-04-08 13:41:46 --> Output Class Initialized
INFO - 2018-04-08 13:41:46 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:46 --> Input Class Initialized
INFO - 2018-04-08 13:41:46 --> Language Class Initialized
INFO - 2018-04-08 13:41:46 --> Loader Class Initialized
INFO - 2018-04-08 13:41:46 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:46 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:46 --> Email Class Initialized
INFO - 2018-04-08 13:41:46 --> Controller Class Initialized
INFO - 2018-04-08 13:41:46 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:46 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:46 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:46 --> Model Class Initialized
INFO - 2018-04-08 13:41:46 --> Model Class Initialized
INFO - 2018-04-08 13:41:46 --> Model Class Initialized
INFO - 2018-04-08 17:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:11:46 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:11:46 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:41:46 --> Config Class Initialized
INFO - 2018-04-08 13:41:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:46 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:46 --> URI Class Initialized
INFO - 2018-04-08 13:41:46 --> Router Class Initialized
INFO - 2018-04-08 13:41:46 --> Output Class Initialized
INFO - 2018-04-08 13:41:46 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:46 --> Input Class Initialized
INFO - 2018-04-08 13:41:46 --> Language Class Initialized
INFO - 2018-04-08 13:41:46 --> Loader Class Initialized
INFO - 2018-04-08 13:41:46 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:46 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:46 --> Email Class Initialized
INFO - 2018-04-08 13:41:46 --> Controller Class Initialized
INFO - 2018-04-08 13:41:46 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:46 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:46 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:46 --> Model Class Initialized
INFO - 2018-04-08 13:41:46 --> Model Class Initialized
INFO - 2018-04-08 13:41:46 --> Model Class Initialized
INFO - 2018-04-08 17:11:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:11:46 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:11:46 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:41:47 --> Config Class Initialized
INFO - 2018-04-08 13:41:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:47 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:47 --> URI Class Initialized
INFO - 2018-04-08 13:41:47 --> Router Class Initialized
INFO - 2018-04-08 13:41:47 --> Output Class Initialized
INFO - 2018-04-08 13:41:47 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:47 --> Input Class Initialized
INFO - 2018-04-08 13:41:47 --> Language Class Initialized
INFO - 2018-04-08 13:41:47 --> Loader Class Initialized
INFO - 2018-04-08 13:41:47 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:47 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:47 --> Email Class Initialized
INFO - 2018-04-08 13:41:47 --> Controller Class Initialized
INFO - 2018-04-08 13:41:47 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:47 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:47 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:47 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:47 --> Model Class Initialized
INFO - 2018-04-08 13:41:47 --> Model Class Initialized
INFO - 2018-04-08 13:41:47 --> Model Class Initialized
INFO - 2018-04-08 17:11:47 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:11:47 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:11:47 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:41:48 --> Config Class Initialized
INFO - 2018-04-08 13:41:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:48 --> URI Class Initialized
INFO - 2018-04-08 13:41:48 --> Router Class Initialized
INFO - 2018-04-08 13:41:48 --> Output Class Initialized
INFO - 2018-04-08 13:41:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:48 --> Input Class Initialized
INFO - 2018-04-08 13:41:48 --> Language Class Initialized
INFO - 2018-04-08 13:41:48 --> Loader Class Initialized
INFO - 2018-04-08 13:41:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:49 --> Email Class Initialized
INFO - 2018-04-08 13:41:49 --> Controller Class Initialized
INFO - 2018-04-08 13:41:49 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:49 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:49 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:49 --> Model Class Initialized
INFO - 2018-04-08 13:41:49 --> Model Class Initialized
INFO - 2018-04-08 13:41:49 --> Model Class Initialized
INFO - 2018-04-08 17:11:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:11:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:11:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:11:49 --> Undefined variable: ffs
ERROR - 2018-04-08 17:11:49 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:11:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:11:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:11:49 --> Final output sent to browser
DEBUG - 2018-04-08 17:11:49 --> Total execution time: 0.1260
INFO - 2018-04-08 13:41:50 --> Config Class Initialized
INFO - 2018-04-08 13:41:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:50 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:50 --> URI Class Initialized
INFO - 2018-04-08 13:41:50 --> Router Class Initialized
INFO - 2018-04-08 13:41:50 --> Output Class Initialized
INFO - 2018-04-08 13:41:50 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:50 --> Input Class Initialized
INFO - 2018-04-08 13:41:50 --> Language Class Initialized
INFO - 2018-04-08 13:41:50 --> Loader Class Initialized
INFO - 2018-04-08 13:41:50 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:50 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:50 --> Email Class Initialized
INFO - 2018-04-08 13:41:50 --> Controller Class Initialized
INFO - 2018-04-08 13:41:50 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:50 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:50 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:50 --> Model Class Initialized
INFO - 2018-04-08 13:41:50 --> Model Class Initialized
INFO - 2018-04-08 13:41:50 --> Model Class Initialized
INFO - 2018-04-08 17:11:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:11:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:11:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:11:50 --> Undefined variable: ffs
ERROR - 2018-04-08 17:11:50 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:11:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:11:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:11:50 --> Final output sent to browser
DEBUG - 2018-04-08 17:11:50 --> Total execution time: 0.1290
INFO - 2018-04-08 13:41:53 --> Config Class Initialized
INFO - 2018-04-08 13:41:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:41:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:41:53 --> Utf8 Class Initialized
INFO - 2018-04-08 13:41:53 --> URI Class Initialized
INFO - 2018-04-08 13:41:53 --> Router Class Initialized
INFO - 2018-04-08 13:41:53 --> Output Class Initialized
INFO - 2018-04-08 13:41:53 --> Security Class Initialized
DEBUG - 2018-04-08 13:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:41:53 --> Input Class Initialized
INFO - 2018-04-08 13:41:53 --> Language Class Initialized
INFO - 2018-04-08 13:41:53 --> Loader Class Initialized
INFO - 2018-04-08 13:41:53 --> Helper loaded: common_helper
INFO - 2018-04-08 13:41:53 --> Database Driver Class Initialized
INFO - 2018-04-08 13:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:41:53 --> Email Class Initialized
INFO - 2018-04-08 13:41:53 --> Controller Class Initialized
INFO - 2018-04-08 13:41:53 --> Helper loaded: form_helper
INFO - 2018-04-08 13:41:53 --> Form Validation Class Initialized
INFO - 2018-04-08 13:41:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:41:53 --> Helper loaded: url_helper
INFO - 2018-04-08 13:41:53 --> Model Class Initialized
INFO - 2018-04-08 13:41:53 --> Model Class Initialized
INFO - 2018-04-08 13:41:53 --> Model Class Initialized
INFO - 2018-04-08 17:11:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:11:53 --> syntax error, unexpected '$Image' (T_VARIABLE)
ERROR - 2018-04-08 17:11:53 --> Severity: Parsing Error --> syntax error, unexpected '$Image' (T_VARIABLE) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:19 --> Config Class Initialized
INFO - 2018-04-08 13:42:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:19 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:19 --> URI Class Initialized
INFO - 2018-04-08 13:42:19 --> Router Class Initialized
INFO - 2018-04-08 13:42:19 --> Output Class Initialized
INFO - 2018-04-08 13:42:19 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:19 --> Input Class Initialized
INFO - 2018-04-08 13:42:19 --> Language Class Initialized
INFO - 2018-04-08 13:42:19 --> Loader Class Initialized
INFO - 2018-04-08 13:42:19 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:19 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:19 --> Email Class Initialized
INFO - 2018-04-08 13:42:19 --> Controller Class Initialized
INFO - 2018-04-08 13:42:19 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:19 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:19 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:19 --> Model Class Initialized
INFO - 2018-04-08 13:42:19 --> Model Class Initialized
INFO - 2018-04-08 13:42:19 --> Model Class Initialized
INFO - 2018-04-08 17:12:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:19 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:19 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:20 --> Config Class Initialized
INFO - 2018-04-08 13:42:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:20 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:20 --> URI Class Initialized
INFO - 2018-04-08 13:42:20 --> Router Class Initialized
INFO - 2018-04-08 13:42:20 --> Output Class Initialized
INFO - 2018-04-08 13:42:20 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:20 --> Input Class Initialized
INFO - 2018-04-08 13:42:20 --> Language Class Initialized
INFO - 2018-04-08 13:42:20 --> Loader Class Initialized
INFO - 2018-04-08 13:42:20 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:20 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:20 --> Email Class Initialized
INFO - 2018-04-08 13:42:20 --> Controller Class Initialized
INFO - 2018-04-08 13:42:20 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:20 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:20 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:20 --> Model Class Initialized
INFO - 2018-04-08 13:42:20 --> Model Class Initialized
INFO - 2018-04-08 13:42:20 --> Model Class Initialized
INFO - 2018-04-08 17:12:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:20 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:20 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:20 --> Config Class Initialized
INFO - 2018-04-08 13:42:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:20 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:20 --> URI Class Initialized
INFO - 2018-04-08 13:42:20 --> Router Class Initialized
INFO - 2018-04-08 13:42:20 --> Output Class Initialized
INFO - 2018-04-08 13:42:20 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:20 --> Input Class Initialized
INFO - 2018-04-08 13:42:20 --> Language Class Initialized
INFO - 2018-04-08 13:42:20 --> Loader Class Initialized
INFO - 2018-04-08 13:42:20 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:20 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:20 --> Email Class Initialized
INFO - 2018-04-08 13:42:20 --> Controller Class Initialized
INFO - 2018-04-08 13:42:20 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:20 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:20 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:20 --> Model Class Initialized
INFO - 2018-04-08 13:42:20 --> Model Class Initialized
INFO - 2018-04-08 13:42:20 --> Model Class Initialized
INFO - 2018-04-08 17:12:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:20 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:20 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:20 --> Config Class Initialized
INFO - 2018-04-08 13:42:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:20 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:20 --> URI Class Initialized
INFO - 2018-04-08 13:42:20 --> Router Class Initialized
INFO - 2018-04-08 13:42:20 --> Output Class Initialized
INFO - 2018-04-08 13:42:20 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:20 --> Input Class Initialized
INFO - 2018-04-08 13:42:20 --> Language Class Initialized
INFO - 2018-04-08 13:42:20 --> Loader Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:21 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:21 --> Email Class Initialized
INFO - 2018-04-08 13:42:21 --> Controller Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:21 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:21 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 17:12:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:21 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:21 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:21 --> Config Class Initialized
INFO - 2018-04-08 13:42:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:21 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:21 --> URI Class Initialized
INFO - 2018-04-08 13:42:21 --> Router Class Initialized
INFO - 2018-04-08 13:42:21 --> Output Class Initialized
INFO - 2018-04-08 13:42:21 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:21 --> Input Class Initialized
INFO - 2018-04-08 13:42:21 --> Language Class Initialized
INFO - 2018-04-08 13:42:21 --> Loader Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:21 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:21 --> Email Class Initialized
INFO - 2018-04-08 13:42:21 --> Controller Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:21 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:21 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 17:12:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:21 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:21 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:21 --> Config Class Initialized
INFO - 2018-04-08 13:42:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:21 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:21 --> URI Class Initialized
INFO - 2018-04-08 13:42:21 --> Router Class Initialized
INFO - 2018-04-08 13:42:21 --> Output Class Initialized
INFO - 2018-04-08 13:42:21 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:21 --> Input Class Initialized
INFO - 2018-04-08 13:42:21 --> Language Class Initialized
INFO - 2018-04-08 13:42:21 --> Loader Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:21 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:21 --> Email Class Initialized
INFO - 2018-04-08 13:42:21 --> Controller Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:21 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:21 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 17:12:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:21 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:21 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:42:21 --> Config Class Initialized
INFO - 2018-04-08 13:42:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:42:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:42:21 --> Utf8 Class Initialized
INFO - 2018-04-08 13:42:21 --> URI Class Initialized
INFO - 2018-04-08 13:42:21 --> Router Class Initialized
INFO - 2018-04-08 13:42:21 --> Output Class Initialized
INFO - 2018-04-08 13:42:21 --> Security Class Initialized
DEBUG - 2018-04-08 13:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:42:21 --> Input Class Initialized
INFO - 2018-04-08 13:42:21 --> Language Class Initialized
INFO - 2018-04-08 13:42:21 --> Loader Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: common_helper
INFO - 2018-04-08 13:42:21 --> Database Driver Class Initialized
INFO - 2018-04-08 13:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:42:21 --> Email Class Initialized
INFO - 2018-04-08 13:42:21 --> Controller Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: form_helper
INFO - 2018-04-08 13:42:21 --> Form Validation Class Initialized
INFO - 2018-04-08 13:42:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:42:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:42:21 --> Helper loaded: url_helper
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 13:42:21 --> Model Class Initialized
INFO - 2018-04-08 17:12:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:12:21 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:12:21 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 69
INFO - 2018-04-08 13:44:16 --> Config Class Initialized
INFO - 2018-04-08 13:44:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:44:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:44:16 --> Utf8 Class Initialized
INFO - 2018-04-08 13:44:16 --> URI Class Initialized
INFO - 2018-04-08 13:44:16 --> Router Class Initialized
INFO - 2018-04-08 13:44:16 --> Output Class Initialized
INFO - 2018-04-08 13:44:16 --> Security Class Initialized
DEBUG - 2018-04-08 13:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:44:16 --> Input Class Initialized
INFO - 2018-04-08 13:44:16 --> Language Class Initialized
INFO - 2018-04-08 13:44:16 --> Loader Class Initialized
INFO - 2018-04-08 13:44:16 --> Helper loaded: common_helper
INFO - 2018-04-08 13:44:16 --> Database Driver Class Initialized
INFO - 2018-04-08 13:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:44:16 --> Email Class Initialized
INFO - 2018-04-08 13:44:16 --> Controller Class Initialized
INFO - 2018-04-08 13:44:16 --> Helper loaded: form_helper
INFO - 2018-04-08 13:44:16 --> Form Validation Class Initialized
INFO - 2018-04-08 13:44:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:44:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:44:16 --> Helper loaded: url_helper
INFO - 2018-04-08 13:44:16 --> Model Class Initialized
INFO - 2018-04-08 13:44:16 --> Model Class Initialized
INFO - 2018-04-08 13:44:16 --> Model Class Initialized
INFO - 2018-04-08 17:14:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:14:16 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:14:16 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 13:44:17 --> Config Class Initialized
INFO - 2018-04-08 13:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:44:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:44:17 --> URI Class Initialized
INFO - 2018-04-08 13:44:17 --> Router Class Initialized
INFO - 2018-04-08 13:44:17 --> Output Class Initialized
INFO - 2018-04-08 13:44:17 --> Security Class Initialized
DEBUG - 2018-04-08 13:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:44:17 --> Input Class Initialized
INFO - 2018-04-08 13:44:17 --> Language Class Initialized
INFO - 2018-04-08 13:44:17 --> Loader Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:44:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:44:17 --> Email Class Initialized
INFO - 2018-04-08 13:44:17 --> Controller Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:44:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:44:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 17:14:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:14:17 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:14:17 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 13:44:17 --> Config Class Initialized
INFO - 2018-04-08 13:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:44:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:44:17 --> URI Class Initialized
INFO - 2018-04-08 13:44:17 --> Router Class Initialized
INFO - 2018-04-08 13:44:17 --> Output Class Initialized
INFO - 2018-04-08 13:44:17 --> Security Class Initialized
DEBUG - 2018-04-08 13:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:44:17 --> Input Class Initialized
INFO - 2018-04-08 13:44:17 --> Language Class Initialized
INFO - 2018-04-08 13:44:17 --> Loader Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:44:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:44:17 --> Email Class Initialized
INFO - 2018-04-08 13:44:17 --> Controller Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:44:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:44:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 17:14:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:14:17 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:14:17 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 13:44:17 --> Config Class Initialized
INFO - 2018-04-08 13:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:44:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:44:17 --> URI Class Initialized
INFO - 2018-04-08 13:44:17 --> Router Class Initialized
INFO - 2018-04-08 13:44:17 --> Output Class Initialized
INFO - 2018-04-08 13:44:17 --> Security Class Initialized
DEBUG - 2018-04-08 13:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:44:17 --> Input Class Initialized
INFO - 2018-04-08 13:44:17 --> Language Class Initialized
INFO - 2018-04-08 13:44:17 --> Loader Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:44:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:44:17 --> Email Class Initialized
INFO - 2018-04-08 13:44:17 --> Controller Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:44:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: email_helper
INFO - 2018-04-08 13:44:17 --> Config Class Initialized
INFO - 2018-04-08 13:44:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:44:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
DEBUG - 2018-04-08 13:44:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:44:17 --> Utf8 Class Initialized
INFO - 2018-04-08 13:44:17 --> URI Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Router Class Initialized
INFO - 2018-04-08 13:44:17 --> Output Class Initialized
INFO - 2018-04-08 17:14:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 13:44:17 --> Security Class Initialized
ERROR - 2018-04-08 17:14:17 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:14:17 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
DEBUG - 2018-04-08 13:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:44:17 --> Input Class Initialized
INFO - 2018-04-08 13:44:17 --> Language Class Initialized
INFO - 2018-04-08 13:44:17 --> Loader Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: common_helper
INFO - 2018-04-08 13:44:17 --> Database Driver Class Initialized
INFO - 2018-04-08 13:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:44:17 --> Email Class Initialized
INFO - 2018-04-08 13:44:17 --> Controller Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: form_helper
INFO - 2018-04-08 13:44:17 --> Form Validation Class Initialized
INFO - 2018-04-08 13:44:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:44:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:44:17 --> Helper loaded: url_helper
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 13:44:17 --> Model Class Initialized
INFO - 2018-04-08 17:14:17 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
ERROR - 2018-04-08 17:14:17 --> syntax error, unexpected '->' (T_OBJECT_OPERATOR)
ERROR - 2018-04-08 17:14:17 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 13:44:50 --> Config Class Initialized
INFO - 2018-04-08 13:44:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:44:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:44:50 --> Utf8 Class Initialized
INFO - 2018-04-08 13:44:50 --> URI Class Initialized
INFO - 2018-04-08 13:44:50 --> Router Class Initialized
INFO - 2018-04-08 13:44:50 --> Output Class Initialized
INFO - 2018-04-08 13:44:50 --> Security Class Initialized
DEBUG - 2018-04-08 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:44:50 --> Input Class Initialized
INFO - 2018-04-08 13:44:50 --> Language Class Initialized
INFO - 2018-04-08 13:44:50 --> Loader Class Initialized
INFO - 2018-04-08 13:44:50 --> Helper loaded: common_helper
INFO - 2018-04-08 13:44:50 --> Database Driver Class Initialized
INFO - 2018-04-08 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:44:51 --> Email Class Initialized
INFO - 2018-04-08 13:44:51 --> Controller Class Initialized
INFO - 2018-04-08 13:44:51 --> Helper loaded: form_helper
INFO - 2018-04-08 13:44:51 --> Form Validation Class Initialized
INFO - 2018-04-08 13:44:51 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:44:51 --> Helper loaded: url_helper
INFO - 2018-04-08 13:44:51 --> Model Class Initialized
INFO - 2018-04-08 13:44:51 --> Model Class Initialized
INFO - 2018-04-08 13:44:51 --> Model Class Initialized
INFO - 2018-04-08 17:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:14:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:14:51 --> Undefined variable: news_title
ERROR - 2018-04-08 17:14:51 --> Severity: Notice --> Undefined variable: news_title C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 66
ERROR - 2018-04-08 17:14:51 --> Trying to get property of non-object
ERROR - 2018-04-08 17:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 66
ERROR - 2018-04-08 17:14:51 --> Undefined variable: Image
ERROR - 2018-04-08 17:14:51 --> Severity: Notice --> Undefined variable: Image C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 66
ERROR - 2018-04-08 17:14:51 --> Trying to get property of non-object
ERROR - 2018-04-08 17:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 66
INFO - 2018-04-08 13:45:14 --> Config Class Initialized
INFO - 2018-04-08 13:45:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:45:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:45:14 --> Utf8 Class Initialized
INFO - 2018-04-08 13:45:14 --> URI Class Initialized
INFO - 2018-04-08 13:45:14 --> Router Class Initialized
INFO - 2018-04-08 13:45:14 --> Output Class Initialized
INFO - 2018-04-08 13:45:14 --> Security Class Initialized
DEBUG - 2018-04-08 13:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:45:14 --> Input Class Initialized
INFO - 2018-04-08 13:45:14 --> Language Class Initialized
INFO - 2018-04-08 13:45:14 --> Loader Class Initialized
INFO - 2018-04-08 13:45:14 --> Helper loaded: common_helper
INFO - 2018-04-08 13:45:14 --> Database Driver Class Initialized
INFO - 2018-04-08 13:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:45:14 --> Email Class Initialized
INFO - 2018-04-08 13:45:14 --> Controller Class Initialized
INFO - 2018-04-08 13:45:14 --> Helper loaded: form_helper
INFO - 2018-04-08 13:45:14 --> Form Validation Class Initialized
INFO - 2018-04-08 13:45:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:45:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:45:14 --> Helper loaded: url_helper
INFO - 2018-04-08 13:45:14 --> Model Class Initialized
INFO - 2018-04-08 13:45:14 --> Model Class Initialized
INFO - 2018-04-08 13:45:14 --> Model Class Initialized
INFO - 2018-04-08 17:15:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:15:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:15:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:15:14 --> Undefined variable: newsImages
ERROR - 2018-04-08 17:15:14 --> Severity: Notice --> Undefined variable: newsImages C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 68
ERROR - 2018-04-08 17:15:14 --> Invalid argument supplied for foreach()
ERROR - 2018-04-08 17:15:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 68
ERROR - 2018-04-08 17:15:14 --> Undefined variable: Image
ERROR - 2018-04-08 17:15:14 --> Severity: Notice --> Undefined variable: Image C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
ERROR - 2018-04-08 17:15:14 --> Trying to get property of non-object
ERROR - 2018-04-08 17:15:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:15:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:15:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:15:14 --> Final output sent to browser
DEBUG - 2018-04-08 17:15:14 --> Total execution time: 0.1420
INFO - 2018-04-08 13:45:14 --> Config Class Initialized
INFO - 2018-04-08 13:45:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:45:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:45:14 --> Utf8 Class Initialized
INFO - 2018-04-08 13:46:48 --> Config Class Initialized
INFO - 2018-04-08 13:46:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:46:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:46:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:46:48 --> URI Class Initialized
INFO - 2018-04-08 13:46:48 --> Router Class Initialized
INFO - 2018-04-08 13:46:48 --> Output Class Initialized
INFO - 2018-04-08 13:46:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:46:48 --> Input Class Initialized
INFO - 2018-04-08 13:46:48 --> Language Class Initialized
INFO - 2018-04-08 13:46:48 --> Loader Class Initialized
INFO - 2018-04-08 13:46:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:46:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:46:48 --> Email Class Initialized
INFO - 2018-04-08 13:46:48 --> Controller Class Initialized
INFO - 2018-04-08 13:46:49 --> Helper loaded: form_helper
INFO - 2018-04-08 13:46:49 --> Form Validation Class Initialized
INFO - 2018-04-08 13:46:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:46:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:46:49 --> Helper loaded: url_helper
INFO - 2018-04-08 13:46:49 --> Model Class Initialized
INFO - 2018-04-08 13:46:49 --> Model Class Initialized
INFO - 2018-04-08 13:46:49 --> Model Class Initialized
INFO - 2018-04-08 13:47:10 --> Config Class Initialized
INFO - 2018-04-08 13:47:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:10 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:10 --> URI Class Initialized
INFO - 2018-04-08 13:47:10 --> Router Class Initialized
INFO - 2018-04-08 13:47:10 --> Output Class Initialized
INFO - 2018-04-08 13:47:10 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:10 --> Input Class Initialized
INFO - 2018-04-08 13:47:10 --> Language Class Initialized
INFO - 2018-04-08 13:47:10 --> Loader Class Initialized
INFO - 2018-04-08 13:47:10 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:10 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:10 --> Email Class Initialized
INFO - 2018-04-08 13:47:10 --> Controller Class Initialized
INFO - 2018-04-08 13:47:10 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:10 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:10 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:10 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:10 --> Model Class Initialized
INFO - 2018-04-08 13:47:10 --> Model Class Initialized
INFO - 2018-04-08 13:47:10 --> Model Class Initialized
INFO - 2018-04-08 17:17:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:17:10 --> Trying to get property of non-object
ERROR - 2018-04-08 17:17:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:17:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:17:10 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:10 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:10 --> Total execution time: 0.1390
INFO - 2018-04-08 13:47:10 --> Config Class Initialized
INFO - 2018-04-08 13:47:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:10 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:16 --> Config Class Initialized
INFO - 2018-04-08 13:47:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:16 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:16 --> URI Class Initialized
INFO - 2018-04-08 13:47:16 --> Router Class Initialized
INFO - 2018-04-08 13:47:16 --> Output Class Initialized
INFO - 2018-04-08 13:47:16 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:16 --> Input Class Initialized
INFO - 2018-04-08 13:47:16 --> Language Class Initialized
INFO - 2018-04-08 13:47:16 --> Loader Class Initialized
INFO - 2018-04-08 13:47:16 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:16 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:16 --> Email Class Initialized
INFO - 2018-04-08 13:47:16 --> Controller Class Initialized
INFO - 2018-04-08 13:47:16 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:16 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:16 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:16 --> Model Class Initialized
INFO - 2018-04-08 13:47:16 --> Model Class Initialized
INFO - 2018-04-08 13:47:16 --> Model Class Initialized
INFO - 2018-04-08 17:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:17:16 --> Trying to get property of non-object
ERROR - 2018-04-08 17:17:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:17:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:16 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:16 --> Total execution time: 0.1280
INFO - 2018-04-08 13:47:16 --> Config Class Initialized
INFO - 2018-04-08 13:47:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:16 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:18 --> Config Class Initialized
INFO - 2018-04-08 13:47:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:18 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:18 --> URI Class Initialized
INFO - 2018-04-08 13:47:18 --> Router Class Initialized
INFO - 2018-04-08 13:47:18 --> Output Class Initialized
INFO - 2018-04-08 13:47:18 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:18 --> Input Class Initialized
INFO - 2018-04-08 13:47:18 --> Language Class Initialized
INFO - 2018-04-08 13:47:18 --> Loader Class Initialized
INFO - 2018-04-08 13:47:18 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:18 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:18 --> Email Class Initialized
INFO - 2018-04-08 13:47:18 --> Controller Class Initialized
INFO - 2018-04-08 13:47:18 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:18 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:18 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:18 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:18 --> Model Class Initialized
INFO - 2018-04-08 13:47:18 --> Model Class Initialized
INFO - 2018-04-08 13:47:18 --> Model Class Initialized
INFO - 2018-04-08 17:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:17:18 --> Trying to get property of non-object
ERROR - 2018-04-08 17:17:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:17:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:18 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:18 --> Total execution time: 0.1610
INFO - 2018-04-08 13:47:18 --> Config Class Initialized
INFO - 2018-04-08 13:47:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:18 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:20 --> Config Class Initialized
INFO - 2018-04-08 13:47:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:20 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:20 --> URI Class Initialized
INFO - 2018-04-08 13:47:20 --> Router Class Initialized
INFO - 2018-04-08 13:47:20 --> Output Class Initialized
INFO - 2018-04-08 13:47:20 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:20 --> Input Class Initialized
INFO - 2018-04-08 13:47:20 --> Language Class Initialized
INFO - 2018-04-08 13:47:20 --> Loader Class Initialized
INFO - 2018-04-08 13:47:20 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:20 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:20 --> Email Class Initialized
INFO - 2018-04-08 13:47:20 --> Controller Class Initialized
INFO - 2018-04-08 13:47:20 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:20 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:20 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:20 --> Model Class Initialized
INFO - 2018-04-08 13:47:20 --> Model Class Initialized
INFO - 2018-04-08 13:47:20 --> Model Class Initialized
INFO - 2018-04-08 17:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:17:20 --> Trying to get property of non-object
ERROR - 2018-04-08 17:17:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:17:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:20 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:20 --> Total execution time: 0.1460
INFO - 2018-04-08 13:47:20 --> Config Class Initialized
INFO - 2018-04-08 13:47:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:20 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:25 --> Config Class Initialized
INFO - 2018-04-08 13:47:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:25 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:25 --> URI Class Initialized
INFO - 2018-04-08 13:47:25 --> Router Class Initialized
INFO - 2018-04-08 13:47:25 --> Output Class Initialized
INFO - 2018-04-08 13:47:25 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:25 --> Input Class Initialized
INFO - 2018-04-08 13:47:25 --> Language Class Initialized
INFO - 2018-04-08 13:47:25 --> Loader Class Initialized
INFO - 2018-04-08 13:47:25 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:25 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:25 --> Email Class Initialized
INFO - 2018-04-08 13:47:25 --> Controller Class Initialized
INFO - 2018-04-08 13:47:25 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:25 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:25 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:25 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:25 --> Model Class Initialized
INFO - 2018-04-08 13:47:25 --> Model Class Initialized
INFO - 2018-04-08 13:47:25 --> Model Class Initialized
INFO - 2018-04-08 17:17:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:17:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/aboutMovie.php
INFO - 2018-04-08 17:17:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:25 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:25 --> Total execution time: 0.1750
INFO - 2018-04-08 13:47:28 --> Config Class Initialized
INFO - 2018-04-08 13:47:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:28 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:28 --> URI Class Initialized
INFO - 2018-04-08 13:47:28 --> Router Class Initialized
INFO - 2018-04-08 13:47:28 --> Output Class Initialized
INFO - 2018-04-08 13:47:28 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:28 --> Input Class Initialized
INFO - 2018-04-08 13:47:28 --> Language Class Initialized
INFO - 2018-04-08 13:47:28 --> Loader Class Initialized
INFO - 2018-04-08 13:47:28 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:28 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:28 --> Email Class Initialized
INFO - 2018-04-08 13:47:28 --> Controller Class Initialized
INFO - 2018-04-08 13:47:28 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:28 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:28 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:28 --> Model Class Initialized
INFO - 2018-04-08 13:47:28 --> Model Class Initialized
INFO - 2018-04-08 13:47:28 --> Model Class Initialized
INFO - 2018-04-08 17:17:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:17:28 --> Trying to get property of non-object
ERROR - 2018-04-08 17:17:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:17:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:17:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:28 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:28 --> Total execution time: 0.1280
INFO - 2018-04-08 13:47:28 --> Config Class Initialized
INFO - 2018-04-08 13:47:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:28 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:59 --> Config Class Initialized
INFO - 2018-04-08 13:47:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:47:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:47:59 --> Utf8 Class Initialized
INFO - 2018-04-08 13:47:59 --> URI Class Initialized
INFO - 2018-04-08 13:47:59 --> Router Class Initialized
INFO - 2018-04-08 13:47:59 --> Output Class Initialized
INFO - 2018-04-08 13:47:59 --> Security Class Initialized
DEBUG - 2018-04-08 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:47:59 --> Input Class Initialized
INFO - 2018-04-08 13:47:59 --> Language Class Initialized
INFO - 2018-04-08 13:47:59 --> Loader Class Initialized
INFO - 2018-04-08 13:47:59 --> Helper loaded: common_helper
INFO - 2018-04-08 13:47:59 --> Database Driver Class Initialized
INFO - 2018-04-08 13:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:47:59 --> Email Class Initialized
INFO - 2018-04-08 13:47:59 --> Controller Class Initialized
INFO - 2018-04-08 13:47:59 --> Helper loaded: form_helper
INFO - 2018-04-08 13:47:59 --> Form Validation Class Initialized
INFO - 2018-04-08 13:47:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:47:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:47:59 --> Helper loaded: url_helper
INFO - 2018-04-08 13:47:59 --> Model Class Initialized
INFO - 2018-04-08 13:47:59 --> Model Class Initialized
INFO - 2018-04-08 13:47:59 --> Model Class Initialized
INFO - 2018-04-08 17:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:17:59 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:17:59 --> Final output sent to browser
DEBUG - 2018-04-08 17:17:59 --> Total execution time: 0.1310
INFO - 2018-04-08 13:48:28 --> Config Class Initialized
INFO - 2018-04-08 13:48:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:48:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:48:28 --> Utf8 Class Initialized
INFO - 2018-04-08 13:48:28 --> URI Class Initialized
INFO - 2018-04-08 13:48:28 --> Router Class Initialized
INFO - 2018-04-08 13:48:28 --> Output Class Initialized
INFO - 2018-04-08 13:48:28 --> Security Class Initialized
DEBUG - 2018-04-08 13:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:48:28 --> Input Class Initialized
INFO - 2018-04-08 13:48:28 --> Language Class Initialized
INFO - 2018-04-08 13:48:28 --> Loader Class Initialized
INFO - 2018-04-08 13:48:28 --> Helper loaded: common_helper
INFO - 2018-04-08 13:48:28 --> Database Driver Class Initialized
INFO - 2018-04-08 13:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:48:28 --> Email Class Initialized
INFO - 2018-04-08 13:48:28 --> Controller Class Initialized
INFO - 2018-04-08 13:48:28 --> Helper loaded: form_helper
INFO - 2018-04-08 13:48:28 --> Form Validation Class Initialized
INFO - 2018-04-08 13:48:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:48:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:48:28 --> Helper loaded: url_helper
INFO - 2018-04-08 13:48:29 --> Model Class Initialized
INFO - 2018-04-08 13:48:29 --> Model Class Initialized
INFO - 2018-04-08 13:48:29 --> Model Class Initialized
INFO - 2018-04-08 13:48:42 --> Config Class Initialized
INFO - 2018-04-08 13:48:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:48:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:48:42 --> Utf8 Class Initialized
INFO - 2018-04-08 13:48:42 --> URI Class Initialized
INFO - 2018-04-08 13:48:42 --> Router Class Initialized
INFO - 2018-04-08 13:48:42 --> Output Class Initialized
INFO - 2018-04-08 13:48:42 --> Security Class Initialized
DEBUG - 2018-04-08 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:48:42 --> Input Class Initialized
INFO - 2018-04-08 13:48:42 --> Language Class Initialized
INFO - 2018-04-08 13:48:42 --> Loader Class Initialized
INFO - 2018-04-08 13:48:42 --> Helper loaded: common_helper
INFO - 2018-04-08 13:48:42 --> Database Driver Class Initialized
INFO - 2018-04-08 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:48:42 --> Email Class Initialized
INFO - 2018-04-08 13:48:42 --> Controller Class Initialized
INFO - 2018-04-08 13:48:42 --> Helper loaded: form_helper
INFO - 2018-04-08 13:48:42 --> Form Validation Class Initialized
INFO - 2018-04-08 13:48:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:48:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:48:42 --> Helper loaded: url_helper
INFO - 2018-04-08 13:48:42 --> Model Class Initialized
INFO - 2018-04-08 13:48:42 --> Model Class Initialized
INFO - 2018-04-08 13:48:42 --> Model Class Initialized
INFO - 2018-04-08 17:18:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:18:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:18:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:18:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:18:42 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:18:42 --> Final output sent to browser
DEBUG - 2018-04-08 17:18:42 --> Total execution time: 0.1330
INFO - 2018-04-08 13:50:24 --> Config Class Initialized
INFO - 2018-04-08 13:50:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:24 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:24 --> URI Class Initialized
INFO - 2018-04-08 13:50:24 --> Router Class Initialized
INFO - 2018-04-08 13:50:24 --> Output Class Initialized
INFO - 2018-04-08 13:50:24 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:24 --> Input Class Initialized
INFO - 2018-04-08 13:50:24 --> Language Class Initialized
INFO - 2018-04-08 13:50:24 --> Loader Class Initialized
INFO - 2018-04-08 13:50:24 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:24 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:25 --> Email Class Initialized
INFO - 2018-04-08 13:50:25 --> Controller Class Initialized
INFO - 2018-04-08 13:50:25 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:25 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:25 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:25 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:25 --> Model Class Initialized
INFO - 2018-04-08 13:50:25 --> Model Class Initialized
INFO - 2018-04-08 13:50:25 --> Model Class Initialized
INFO - 2018-04-08 17:20:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:20:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:20:25 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:25 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:25 --> Total execution time: 0.1350
INFO - 2018-04-08 13:50:34 --> Config Class Initialized
INFO - 2018-04-08 13:50:34 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:34 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:34 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:34 --> URI Class Initialized
INFO - 2018-04-08 13:50:34 --> Router Class Initialized
INFO - 2018-04-08 13:50:34 --> Output Class Initialized
INFO - 2018-04-08 13:50:34 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:34 --> Input Class Initialized
INFO - 2018-04-08 13:50:34 --> Language Class Initialized
INFO - 2018-04-08 13:50:34 --> Loader Class Initialized
INFO - 2018-04-08 13:50:34 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:34 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:34 --> Email Class Initialized
INFO - 2018-04-08 13:50:34 --> Controller Class Initialized
INFO - 2018-04-08 13:50:34 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:34 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:34 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:34 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:34 --> Model Class Initialized
INFO - 2018-04-08 13:50:34 --> Model Class Initialized
INFO - 2018-04-08 13:50:34 --> Model Class Initialized
INFO - 2018-04-08 17:20:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:20:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/aboutMovie.php
INFO - 2018-04-08 17:20:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:34 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:34 --> Total execution time: 0.1940
INFO - 2018-04-08 13:50:36 --> Config Class Initialized
INFO - 2018-04-08 13:50:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:36 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:36 --> URI Class Initialized
INFO - 2018-04-08 13:50:36 --> Router Class Initialized
INFO - 2018-04-08 13:50:36 --> Output Class Initialized
INFO - 2018-04-08 13:50:36 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:36 --> Input Class Initialized
INFO - 2018-04-08 13:50:36 --> Language Class Initialized
INFO - 2018-04-08 13:50:36 --> Loader Class Initialized
INFO - 2018-04-08 13:50:36 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:36 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:36 --> Email Class Initialized
INFO - 2018-04-08 13:50:36 --> Controller Class Initialized
INFO - 2018-04-08 13:50:36 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:36 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:36 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:36 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:36 --> Model Class Initialized
INFO - 2018-04-08 13:50:36 --> Model Class Initialized
INFO - 2018-04-08 13:50:36 --> Model Class Initialized
INFO - 2018-04-08 17:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:20:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:36 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:36 --> Total execution time: 0.1420
INFO - 2018-04-08 13:50:37 --> Config Class Initialized
INFO - 2018-04-08 13:50:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:37 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:37 --> URI Class Initialized
INFO - 2018-04-08 13:50:37 --> Router Class Initialized
INFO - 2018-04-08 13:50:37 --> Output Class Initialized
INFO - 2018-04-08 13:50:37 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:37 --> Input Class Initialized
INFO - 2018-04-08 13:50:37 --> Language Class Initialized
INFO - 2018-04-08 13:50:37 --> Loader Class Initialized
INFO - 2018-04-08 13:50:37 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:37 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:37 --> Email Class Initialized
INFO - 2018-04-08 13:50:37 --> Controller Class Initialized
INFO - 2018-04-08 13:50:37 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:37 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:37 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:37 --> Model Class Initialized
INFO - 2018-04-08 13:50:37 --> Model Class Initialized
INFO - 2018-04-08 13:50:37 --> Model Class Initialized
INFO - 2018-04-08 17:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:20:37 --> Undefined variable: ffs
ERROR - 2018-04-08 17:20:37 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:20:37 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:37 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:37 --> Total execution time: 0.1260
INFO - 2018-04-08 13:50:40 --> Config Class Initialized
INFO - 2018-04-08 13:50:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:40 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:40 --> URI Class Initialized
INFO - 2018-04-08 13:50:40 --> Router Class Initialized
INFO - 2018-04-08 13:50:40 --> Output Class Initialized
INFO - 2018-04-08 13:50:40 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:40 --> Input Class Initialized
INFO - 2018-04-08 13:50:40 --> Language Class Initialized
INFO - 2018-04-08 13:50:40 --> Loader Class Initialized
INFO - 2018-04-08 13:50:40 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:40 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:40 --> Email Class Initialized
INFO - 2018-04-08 13:50:40 --> Controller Class Initialized
INFO - 2018-04-08 13:50:40 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:40 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:40 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:40 --> Model Class Initialized
INFO - 2018-04-08 13:50:40 --> Model Class Initialized
INFO - 2018-04-08 13:50:40 --> Model Class Initialized
INFO - 2018-04-08 17:20:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:20:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:20:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:40 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:40 --> Total execution time: 0.1230
INFO - 2018-04-08 13:50:45 --> Config Class Initialized
INFO - 2018-04-08 13:50:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:45 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:45 --> URI Class Initialized
INFO - 2018-04-08 13:50:45 --> Router Class Initialized
INFO - 2018-04-08 13:50:46 --> Output Class Initialized
INFO - 2018-04-08 13:50:46 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:46 --> Input Class Initialized
INFO - 2018-04-08 13:50:46 --> Language Class Initialized
INFO - 2018-04-08 13:50:46 --> Loader Class Initialized
INFO - 2018-04-08 13:50:46 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:46 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:46 --> Email Class Initialized
INFO - 2018-04-08 13:50:46 --> Controller Class Initialized
INFO - 2018-04-08 13:50:46 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:46 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:46 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:46 --> Model Class Initialized
INFO - 2018-04-08 13:50:46 --> Model Class Initialized
INFO - 2018-04-08 13:50:46 --> Model Class Initialized
INFO - 2018-04-08 17:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:20:46 --> Undefined variable: ffs
ERROR - 2018-04-08 17:20:46 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:20:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:46 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:46 --> Total execution time: 0.1260
INFO - 2018-04-08 13:50:48 --> Config Class Initialized
INFO - 2018-04-08 13:50:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:50:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:50:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:50:48 --> URI Class Initialized
INFO - 2018-04-08 13:50:48 --> Router Class Initialized
INFO - 2018-04-08 13:50:48 --> Output Class Initialized
INFO - 2018-04-08 13:50:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:50:48 --> Input Class Initialized
INFO - 2018-04-08 13:50:48 --> Language Class Initialized
INFO - 2018-04-08 13:50:48 --> Loader Class Initialized
INFO - 2018-04-08 13:50:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:50:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:50:48 --> Email Class Initialized
INFO - 2018-04-08 13:50:48 --> Controller Class Initialized
INFO - 2018-04-08 13:50:48 --> Helper loaded: form_helper
INFO - 2018-04-08 13:50:48 --> Form Validation Class Initialized
INFO - 2018-04-08 13:50:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:50:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:50:48 --> Helper loaded: url_helper
INFO - 2018-04-08 13:50:48 --> Model Class Initialized
INFO - 2018-04-08 13:50:48 --> Model Class Initialized
INFO - 2018-04-08 13:50:48 --> Model Class Initialized
INFO - 2018-04-08 17:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:20:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:20:48 --> Final output sent to browser
DEBUG - 2018-04-08 17:20:48 --> Total execution time: 0.1290
INFO - 2018-04-08 13:53:03 --> Config Class Initialized
INFO - 2018-04-08 13:53:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:53:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:53:03 --> Utf8 Class Initialized
INFO - 2018-04-08 13:53:03 --> URI Class Initialized
INFO - 2018-04-08 13:53:03 --> Router Class Initialized
INFO - 2018-04-08 13:53:03 --> Output Class Initialized
INFO - 2018-04-08 13:53:03 --> Security Class Initialized
DEBUG - 2018-04-08 13:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:53:03 --> Input Class Initialized
INFO - 2018-04-08 13:53:03 --> Language Class Initialized
INFO - 2018-04-08 13:53:03 --> Loader Class Initialized
INFO - 2018-04-08 13:53:03 --> Helper loaded: common_helper
INFO - 2018-04-08 13:53:03 --> Database Driver Class Initialized
INFO - 2018-04-08 13:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:53:03 --> Email Class Initialized
INFO - 2018-04-08 13:53:03 --> Controller Class Initialized
INFO - 2018-04-08 13:53:03 --> Helper loaded: form_helper
INFO - 2018-04-08 13:53:03 --> Form Validation Class Initialized
INFO - 2018-04-08 13:53:03 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:53:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:53:03 --> Helper loaded: url_helper
INFO - 2018-04-08 13:53:03 --> Model Class Initialized
INFO - 2018-04-08 13:53:03 --> Model Class Initialized
INFO - 2018-04-08 13:53:03 --> Model Class Initialized
INFO - 2018-04-08 17:23:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:23:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:23:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:23:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:23:03 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:23:03 --> Final output sent to browser
DEBUG - 2018-04-08 17:23:03 --> Total execution time: 0.1290
INFO - 2018-04-08 13:53:55 --> Config Class Initialized
INFO - 2018-04-08 13:53:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:53:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:53:55 --> Utf8 Class Initialized
INFO - 2018-04-08 13:53:55 --> URI Class Initialized
INFO - 2018-04-08 13:53:55 --> Router Class Initialized
INFO - 2018-04-08 13:53:55 --> Output Class Initialized
INFO - 2018-04-08 13:53:55 --> Security Class Initialized
DEBUG - 2018-04-08 13:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:53:55 --> Input Class Initialized
INFO - 2018-04-08 13:53:55 --> Language Class Initialized
INFO - 2018-04-08 13:53:55 --> Loader Class Initialized
INFO - 2018-04-08 13:53:55 --> Helper loaded: common_helper
INFO - 2018-04-08 13:53:55 --> Database Driver Class Initialized
INFO - 2018-04-08 13:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:53:55 --> Email Class Initialized
INFO - 2018-04-08 13:53:55 --> Controller Class Initialized
INFO - 2018-04-08 13:53:55 --> Helper loaded: form_helper
INFO - 2018-04-08 13:53:55 --> Form Validation Class Initialized
INFO - 2018-04-08 13:53:55 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:53:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:53:55 --> Helper loaded: url_helper
INFO - 2018-04-08 13:53:55 --> Model Class Initialized
INFO - 2018-04-08 13:53:55 --> Model Class Initialized
INFO - 2018-04-08 13:53:55 --> Model Class Initialized
INFO - 2018-04-08 17:23:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:23:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:23:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:23:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:23:55 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:23:55 --> Final output sent to browser
DEBUG - 2018-04-08 17:23:55 --> Total execution time: 0.1290
INFO - 2018-04-08 13:53:58 --> Config Class Initialized
INFO - 2018-04-08 13:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:53:58 --> Utf8 Class Initialized
INFO - 2018-04-08 13:53:58 --> URI Class Initialized
INFO - 2018-04-08 13:53:58 --> Router Class Initialized
INFO - 2018-04-08 13:53:58 --> Output Class Initialized
INFO - 2018-04-08 13:53:58 --> Security Class Initialized
DEBUG - 2018-04-08 13:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:53:58 --> Input Class Initialized
INFO - 2018-04-08 13:53:58 --> Language Class Initialized
INFO - 2018-04-08 13:53:58 --> Loader Class Initialized
INFO - 2018-04-08 13:53:58 --> Helper loaded: common_helper
INFO - 2018-04-08 13:53:58 --> Database Driver Class Initialized
INFO - 2018-04-08 13:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:53:58 --> Email Class Initialized
INFO - 2018-04-08 13:53:58 --> Controller Class Initialized
INFO - 2018-04-08 13:53:58 --> Helper loaded: form_helper
INFO - 2018-04-08 13:53:58 --> Form Validation Class Initialized
INFO - 2018-04-08 13:53:58 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:53:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:53:58 --> Helper loaded: url_helper
INFO - 2018-04-08 13:53:58 --> Model Class Initialized
INFO - 2018-04-08 13:53:58 --> Model Class Initialized
INFO - 2018-04-08 13:53:58 --> Model Class Initialized
INFO - 2018-04-08 17:23:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:23:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:23:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:23:58 --> Undefined variable: ffs
ERROR - 2018-04-08 17:23:58 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:23:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:23:58 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:23:58 --> Final output sent to browser
DEBUG - 2018-04-08 17:23:58 --> Total execution time: 0.1430
INFO - 2018-04-08 13:54:00 --> Config Class Initialized
INFO - 2018-04-08 13:54:00 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:54:00 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:54:00 --> Utf8 Class Initialized
INFO - 2018-04-08 13:54:00 --> URI Class Initialized
INFO - 2018-04-08 13:54:00 --> Router Class Initialized
INFO - 2018-04-08 13:54:00 --> Output Class Initialized
INFO - 2018-04-08 13:54:00 --> Security Class Initialized
DEBUG - 2018-04-08 13:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:54:00 --> Input Class Initialized
INFO - 2018-04-08 13:54:00 --> Language Class Initialized
INFO - 2018-04-08 13:54:00 --> Loader Class Initialized
INFO - 2018-04-08 13:54:00 --> Helper loaded: common_helper
INFO - 2018-04-08 13:54:00 --> Database Driver Class Initialized
INFO - 2018-04-08 13:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:54:00 --> Email Class Initialized
INFO - 2018-04-08 13:54:00 --> Controller Class Initialized
INFO - 2018-04-08 13:54:00 --> Helper loaded: form_helper
INFO - 2018-04-08 13:54:00 --> Form Validation Class Initialized
INFO - 2018-04-08 13:54:00 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:54:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:54:00 --> Helper loaded: url_helper
INFO - 2018-04-08 13:54:00 --> Model Class Initialized
INFO - 2018-04-08 13:54:00 --> Model Class Initialized
INFO - 2018-04-08 13:54:00 --> Model Class Initialized
INFO - 2018-04-08 17:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:24:00 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:24:00 --> Final output sent to browser
DEBUG - 2018-04-08 17:24:00 --> Total execution time: 0.1200
INFO - 2018-04-08 13:54:06 --> Config Class Initialized
INFO - 2018-04-08 13:54:06 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:54:06 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:54:06 --> Utf8 Class Initialized
INFO - 2018-04-08 13:54:06 --> URI Class Initialized
INFO - 2018-04-08 13:54:06 --> Router Class Initialized
INFO - 2018-04-08 13:54:06 --> Output Class Initialized
INFO - 2018-04-08 13:54:06 --> Security Class Initialized
DEBUG - 2018-04-08 13:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:54:06 --> Input Class Initialized
INFO - 2018-04-08 13:54:06 --> Language Class Initialized
INFO - 2018-04-08 13:54:06 --> Loader Class Initialized
INFO - 2018-04-08 13:54:06 --> Helper loaded: common_helper
INFO - 2018-04-08 13:54:06 --> Database Driver Class Initialized
INFO - 2018-04-08 13:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:54:06 --> Email Class Initialized
INFO - 2018-04-08 13:54:06 --> Controller Class Initialized
INFO - 2018-04-08 13:54:06 --> Helper loaded: form_helper
INFO - 2018-04-08 13:54:06 --> Form Validation Class Initialized
INFO - 2018-04-08 13:54:06 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:54:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:54:06 --> Helper loaded: url_helper
INFO - 2018-04-08 13:54:06 --> Model Class Initialized
INFO - 2018-04-08 13:54:06 --> Model Class Initialized
INFO - 2018-04-08 13:54:06 --> Model Class Initialized
INFO - 2018-04-08 17:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:24:06 --> Undefined variable: ffs
ERROR - 2018-04-08 17:24:06 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:24:06 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:24:06 --> Final output sent to browser
DEBUG - 2018-04-08 17:24:06 --> Total execution time: 0.1400
INFO - 2018-04-08 13:54:10 --> Config Class Initialized
INFO - 2018-04-08 13:54:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:54:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:54:10 --> Utf8 Class Initialized
INFO - 2018-04-08 13:54:10 --> URI Class Initialized
INFO - 2018-04-08 13:54:10 --> Router Class Initialized
INFO - 2018-04-08 13:54:10 --> Output Class Initialized
INFO - 2018-04-08 13:54:10 --> Security Class Initialized
DEBUG - 2018-04-08 13:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:54:10 --> Input Class Initialized
INFO - 2018-04-08 13:54:10 --> Language Class Initialized
INFO - 2018-04-08 13:54:10 --> Loader Class Initialized
INFO - 2018-04-08 13:54:10 --> Helper loaded: common_helper
INFO - 2018-04-08 13:54:10 --> Database Driver Class Initialized
INFO - 2018-04-08 13:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:54:11 --> Email Class Initialized
INFO - 2018-04-08 13:54:11 --> Controller Class Initialized
INFO - 2018-04-08 13:54:11 --> Helper loaded: form_helper
INFO - 2018-04-08 13:54:11 --> Form Validation Class Initialized
INFO - 2018-04-08 13:54:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:54:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:54:11 --> Helper loaded: url_helper
INFO - 2018-04-08 13:54:11 --> Model Class Initialized
INFO - 2018-04-08 13:54:11 --> Model Class Initialized
INFO - 2018-04-08 13:54:11 --> Model Class Initialized
INFO - 2018-04-08 17:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:24:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:24:11 --> Final output sent to browser
DEBUG - 2018-04-08 17:24:11 --> Total execution time: 0.1610
INFO - 2018-04-08 13:54:18 --> Config Class Initialized
INFO - 2018-04-08 13:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:54:18 --> Utf8 Class Initialized
INFO - 2018-04-08 13:54:18 --> URI Class Initialized
INFO - 2018-04-08 13:54:18 --> Router Class Initialized
INFO - 2018-04-08 13:54:18 --> Output Class Initialized
INFO - 2018-04-08 13:54:18 --> Security Class Initialized
DEBUG - 2018-04-08 13:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:54:18 --> Input Class Initialized
INFO - 2018-04-08 13:54:18 --> Language Class Initialized
INFO - 2018-04-08 13:54:18 --> Loader Class Initialized
INFO - 2018-04-08 13:54:18 --> Helper loaded: common_helper
INFO - 2018-04-08 13:54:18 --> Database Driver Class Initialized
INFO - 2018-04-08 13:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:54:18 --> Email Class Initialized
INFO - 2018-04-08 13:54:18 --> Controller Class Initialized
INFO - 2018-04-08 13:54:18 --> Helper loaded: form_helper
INFO - 2018-04-08 13:54:18 --> Form Validation Class Initialized
INFO - 2018-04-08 13:54:18 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:54:18 --> Helper loaded: url_helper
INFO - 2018-04-08 13:54:18 --> Model Class Initialized
INFO - 2018-04-08 13:54:18 --> Model Class Initialized
INFO - 2018-04-08 13:54:18 --> Model Class Initialized
INFO - 2018-04-08 17:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/addMovie.php
INFO - 2018-04-08 17:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:24:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:24:18 --> Final output sent to browser
DEBUG - 2018-04-08 17:24:18 --> Total execution time: 0.1320
INFO - 2018-04-08 13:54:46 --> Config Class Initialized
INFO - 2018-04-08 13:54:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:54:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:54:46 --> Utf8 Class Initialized
INFO - 2018-04-08 13:54:46 --> URI Class Initialized
INFO - 2018-04-08 13:54:46 --> Router Class Initialized
INFO - 2018-04-08 13:54:46 --> Output Class Initialized
INFO - 2018-04-08 13:54:46 --> Security Class Initialized
DEBUG - 2018-04-08 13:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:54:46 --> Input Class Initialized
INFO - 2018-04-08 13:54:46 --> Language Class Initialized
INFO - 2018-04-08 13:54:46 --> Loader Class Initialized
INFO - 2018-04-08 13:54:46 --> Helper loaded: common_helper
INFO - 2018-04-08 13:54:46 --> Database Driver Class Initialized
INFO - 2018-04-08 13:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:54:46 --> Email Class Initialized
INFO - 2018-04-08 13:54:46 --> Controller Class Initialized
INFO - 2018-04-08 13:54:46 --> Helper loaded: form_helper
INFO - 2018-04-08 13:54:46 --> Form Validation Class Initialized
INFO - 2018-04-08 13:54:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:54:46 --> Helper loaded: url_helper
INFO - 2018-04-08 13:54:46 --> Model Class Initialized
INFO - 2018-04-08 13:54:46 --> Model Class Initialized
INFO - 2018-04-08 13:54:46 --> Model Class Initialized
DEBUG - 2018-04-08 17:24:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 17:24:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 13:54:46 --> Config Class Initialized
INFO - 2018-04-08 13:54:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:54:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:54:46 --> Utf8 Class Initialized
INFO - 2018-04-08 13:54:46 --> URI Class Initialized
INFO - 2018-04-08 13:54:46 --> Router Class Initialized
INFO - 2018-04-08 13:54:46 --> Output Class Initialized
INFO - 2018-04-08 13:54:46 --> Security Class Initialized
DEBUG - 2018-04-08 13:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:54:46 --> Input Class Initialized
INFO - 2018-04-08 13:54:46 --> Language Class Initialized
INFO - 2018-04-08 13:54:46 --> Loader Class Initialized
INFO - 2018-04-08 13:54:46 --> Helper loaded: common_helper
INFO - 2018-04-08 13:54:46 --> Database Driver Class Initialized
INFO - 2018-04-08 13:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:54:46 --> Email Class Initialized
INFO - 2018-04-08 13:54:46 --> Controller Class Initialized
INFO - 2018-04-08 13:54:46 --> Helper loaded: form_helper
INFO - 2018-04-08 13:54:46 --> Form Validation Class Initialized
INFO - 2018-04-08 13:54:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:54:46 --> Helper loaded: url_helper
INFO - 2018-04-08 13:54:46 --> Model Class Initialized
INFO - 2018-04-08 13:54:46 --> Model Class Initialized
INFO - 2018-04-08 13:54:46 --> Model Class Initialized
INFO - 2018-04-08 17:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:24:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:24:46 --> Final output sent to browser
DEBUG - 2018-04-08 17:24:46 --> Total execution time: 0.1230
INFO - 2018-04-08 13:55:37 --> Config Class Initialized
INFO - 2018-04-08 13:55:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:55:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:55:37 --> Utf8 Class Initialized
INFO - 2018-04-08 13:55:37 --> URI Class Initialized
INFO - 2018-04-08 13:55:37 --> Router Class Initialized
INFO - 2018-04-08 13:55:37 --> Output Class Initialized
INFO - 2018-04-08 13:55:37 --> Security Class Initialized
DEBUG - 2018-04-08 13:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:55:37 --> Input Class Initialized
INFO - 2018-04-08 13:55:37 --> Language Class Initialized
INFO - 2018-04-08 13:55:37 --> Loader Class Initialized
INFO - 2018-04-08 13:55:37 --> Helper loaded: common_helper
INFO - 2018-04-08 13:55:38 --> Database Driver Class Initialized
INFO - 2018-04-08 13:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:55:38 --> Email Class Initialized
INFO - 2018-04-08 13:55:38 --> Controller Class Initialized
INFO - 2018-04-08 13:55:38 --> Helper loaded: form_helper
INFO - 2018-04-08 13:55:38 --> Form Validation Class Initialized
INFO - 2018-04-08 13:55:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:55:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:55:38 --> Helper loaded: url_helper
INFO - 2018-04-08 13:55:38 --> Model Class Initialized
INFO - 2018-04-08 13:55:38 --> Model Class Initialized
INFO - 2018-04-08 13:55:38 --> Model Class Initialized
INFO - 2018-04-08 17:25:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:25:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:25:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:25:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:25:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:25:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:25:38 --> Final output sent to browser
DEBUG - 2018-04-08 17:25:38 --> Total execution time: 0.1310
INFO - 2018-04-08 13:55:57 --> Config Class Initialized
INFO - 2018-04-08 13:55:57 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:55:57 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:55:57 --> Utf8 Class Initialized
INFO - 2018-04-08 13:55:57 --> URI Class Initialized
INFO - 2018-04-08 13:55:57 --> Router Class Initialized
INFO - 2018-04-08 13:55:57 --> Output Class Initialized
INFO - 2018-04-08 13:55:57 --> Security Class Initialized
DEBUG - 2018-04-08 13:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:55:57 --> Input Class Initialized
INFO - 2018-04-08 13:55:57 --> Language Class Initialized
INFO - 2018-04-08 13:55:57 --> Loader Class Initialized
INFO - 2018-04-08 13:55:57 --> Helper loaded: common_helper
INFO - 2018-04-08 13:55:57 --> Database Driver Class Initialized
INFO - 2018-04-08 13:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:55:57 --> Email Class Initialized
INFO - 2018-04-08 13:55:57 --> Controller Class Initialized
INFO - 2018-04-08 13:55:57 --> Helper loaded: form_helper
INFO - 2018-04-08 13:55:57 --> Form Validation Class Initialized
INFO - 2018-04-08 13:55:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:55:57 --> Helper loaded: url_helper
INFO - 2018-04-08 13:55:57 --> Model Class Initialized
INFO - 2018-04-08 13:55:57 --> Model Class Initialized
INFO - 2018-04-08 13:55:57 --> Model Class Initialized
INFO - 2018-04-08 17:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:25:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:25:57 --> Final output sent to browser
DEBUG - 2018-04-08 17:25:57 --> Total execution time: 0.1280
INFO - 2018-04-08 13:57:32 --> Config Class Initialized
INFO - 2018-04-08 13:57:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:57:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:57:32 --> Utf8 Class Initialized
INFO - 2018-04-08 13:57:32 --> URI Class Initialized
INFO - 2018-04-08 13:57:32 --> Router Class Initialized
INFO - 2018-04-08 13:57:32 --> Output Class Initialized
INFO - 2018-04-08 13:57:32 --> Security Class Initialized
DEBUG - 2018-04-08 13:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:57:32 --> Input Class Initialized
INFO - 2018-04-08 13:57:32 --> Language Class Initialized
INFO - 2018-04-08 13:57:32 --> Loader Class Initialized
INFO - 2018-04-08 13:57:32 --> Helper loaded: common_helper
INFO - 2018-04-08 13:57:32 --> Database Driver Class Initialized
INFO - 2018-04-08 13:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:57:32 --> Email Class Initialized
INFO - 2018-04-08 13:57:32 --> Controller Class Initialized
INFO - 2018-04-08 13:57:32 --> Helper loaded: form_helper
INFO - 2018-04-08 13:57:32 --> Form Validation Class Initialized
INFO - 2018-04-08 13:57:32 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:57:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:57:32 --> Helper loaded: url_helper
INFO - 2018-04-08 13:57:32 --> Model Class Initialized
INFO - 2018-04-08 13:57:32 --> Model Class Initialized
INFO - 2018-04-08 13:57:32 --> Model Class Initialized
INFO - 2018-04-08 17:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/addMovie.php
INFO - 2018-04-08 17:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:27:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:27:32 --> Final output sent to browser
DEBUG - 2018-04-08 17:27:32 --> Total execution time: 0.2970
INFO - 2018-04-08 13:57:34 --> Config Class Initialized
INFO - 2018-04-08 13:57:34 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:57:34 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:57:34 --> Utf8 Class Initialized
INFO - 2018-04-08 13:57:34 --> URI Class Initialized
INFO - 2018-04-08 13:57:34 --> Router Class Initialized
INFO - 2018-04-08 13:57:34 --> Output Class Initialized
INFO - 2018-04-08 13:57:34 --> Security Class Initialized
DEBUG - 2018-04-08 13:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:57:34 --> Input Class Initialized
INFO - 2018-04-08 13:57:34 --> Language Class Initialized
INFO - 2018-04-08 13:57:34 --> Loader Class Initialized
INFO - 2018-04-08 13:57:34 --> Helper loaded: common_helper
INFO - 2018-04-08 13:57:34 --> Database Driver Class Initialized
INFO - 2018-04-08 13:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:57:34 --> Email Class Initialized
INFO - 2018-04-08 13:57:34 --> Controller Class Initialized
INFO - 2018-04-08 13:57:34 --> Helper loaded: form_helper
INFO - 2018-04-08 13:57:34 --> Form Validation Class Initialized
INFO - 2018-04-08 13:57:34 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:57:34 --> Helper loaded: url_helper
INFO - 2018-04-08 13:57:34 --> Model Class Initialized
INFO - 2018-04-08 13:57:34 --> Model Class Initialized
INFO - 2018-04-08 13:57:34 --> Model Class Initialized
INFO - 2018-04-08 17:27:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:27:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:27:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:27:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:27:34 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:27:34 --> Final output sent to browser
DEBUG - 2018-04-08 17:27:34 --> Total execution time: 0.1340
INFO - 2018-04-08 13:57:40 --> Config Class Initialized
INFO - 2018-04-08 13:57:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:57:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:57:40 --> Utf8 Class Initialized
INFO - 2018-04-08 13:57:40 --> URI Class Initialized
INFO - 2018-04-08 13:57:40 --> Router Class Initialized
INFO - 2018-04-08 13:57:40 --> Output Class Initialized
INFO - 2018-04-08 13:57:40 --> Security Class Initialized
DEBUG - 2018-04-08 13:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:57:40 --> Input Class Initialized
INFO - 2018-04-08 13:57:40 --> Language Class Initialized
INFO - 2018-04-08 13:57:40 --> Loader Class Initialized
INFO - 2018-04-08 13:57:40 --> Helper loaded: common_helper
INFO - 2018-04-08 13:57:40 --> Database Driver Class Initialized
INFO - 2018-04-08 13:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:57:40 --> Email Class Initialized
INFO - 2018-04-08 13:57:40 --> Controller Class Initialized
INFO - 2018-04-08 13:57:40 --> Helper loaded: form_helper
INFO - 2018-04-08 13:57:40 --> Form Validation Class Initialized
INFO - 2018-04-08 13:57:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:57:40 --> Helper loaded: url_helper
INFO - 2018-04-08 13:57:40 --> Model Class Initialized
INFO - 2018-04-08 13:57:40 --> Model Class Initialized
INFO - 2018-04-08 13:57:40 --> Model Class Initialized
INFO - 2018-04-08 13:57:40 --> Config Class Initialized
INFO - 2018-04-08 13:57:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:57:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:57:40 --> Utf8 Class Initialized
INFO - 2018-04-08 13:57:40 --> URI Class Initialized
INFO - 2018-04-08 13:57:40 --> Router Class Initialized
INFO - 2018-04-08 13:57:40 --> Output Class Initialized
INFO - 2018-04-08 13:57:40 --> Security Class Initialized
DEBUG - 2018-04-08 13:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:57:40 --> Input Class Initialized
INFO - 2018-04-08 13:57:40 --> Language Class Initialized
INFO - 2018-04-08 13:57:40 --> Loader Class Initialized
INFO - 2018-04-08 13:57:40 --> Helper loaded: common_helper
INFO - 2018-04-08 13:57:40 --> Database Driver Class Initialized
INFO - 2018-04-08 13:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:57:40 --> Email Class Initialized
INFO - 2018-04-08 13:57:40 --> Controller Class Initialized
INFO - 2018-04-08 13:57:40 --> Helper loaded: form_helper
INFO - 2018-04-08 13:57:40 --> Form Validation Class Initialized
INFO - 2018-04-08 13:57:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:57:40 --> Helper loaded: url_helper
INFO - 2018-04-08 13:57:40 --> Model Class Initialized
INFO - 2018-04-08 13:57:40 --> Model Class Initialized
INFO - 2018-04-08 13:57:40 --> Model Class Initialized
INFO - 2018-04-08 17:27:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:27:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:27:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:27:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:27:40 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:27:40 --> Final output sent to browser
DEBUG - 2018-04-08 17:27:40 --> Total execution time: 0.1150
INFO - 2018-04-08 13:57:48 --> Config Class Initialized
INFO - 2018-04-08 13:57:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:57:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:57:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:57:48 --> URI Class Initialized
INFO - 2018-04-08 13:57:48 --> Router Class Initialized
INFO - 2018-04-08 13:57:48 --> Output Class Initialized
INFO - 2018-04-08 13:57:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:57:48 --> Input Class Initialized
INFO - 2018-04-08 13:57:48 --> Language Class Initialized
INFO - 2018-04-08 13:57:48 --> Loader Class Initialized
INFO - 2018-04-08 13:57:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:57:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:57:48 --> Email Class Initialized
INFO - 2018-04-08 13:57:48 --> Controller Class Initialized
INFO - 2018-04-08 13:57:48 --> Helper loaded: form_helper
INFO - 2018-04-08 13:57:48 --> Form Validation Class Initialized
INFO - 2018-04-08 13:57:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:57:48 --> Helper loaded: url_helper
INFO - 2018-04-08 13:57:48 --> Model Class Initialized
INFO - 2018-04-08 13:57:48 --> Model Class Initialized
INFO - 2018-04-08 13:57:48 --> Model Class Initialized
INFO - 2018-04-08 13:57:48 --> Config Class Initialized
INFO - 2018-04-08 13:57:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:57:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:57:48 --> Utf8 Class Initialized
INFO - 2018-04-08 13:57:48 --> URI Class Initialized
INFO - 2018-04-08 13:57:48 --> Router Class Initialized
INFO - 2018-04-08 13:57:48 --> Output Class Initialized
INFO - 2018-04-08 13:57:48 --> Security Class Initialized
DEBUG - 2018-04-08 13:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:57:48 --> Input Class Initialized
INFO - 2018-04-08 13:57:48 --> Language Class Initialized
INFO - 2018-04-08 13:57:48 --> Loader Class Initialized
INFO - 2018-04-08 13:57:48 --> Helper loaded: common_helper
INFO - 2018-04-08 13:57:48 --> Database Driver Class Initialized
INFO - 2018-04-08 13:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:57:48 --> Email Class Initialized
INFO - 2018-04-08 13:57:48 --> Controller Class Initialized
INFO - 2018-04-08 13:57:48 --> Helper loaded: form_helper
INFO - 2018-04-08 13:57:48 --> Form Validation Class Initialized
INFO - 2018-04-08 13:57:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:57:48 --> Helper loaded: url_helper
INFO - 2018-04-08 13:57:48 --> Model Class Initialized
INFO - 2018-04-08 13:57:48 --> Model Class Initialized
INFO - 2018-04-08 13:57:48 --> Model Class Initialized
INFO - 2018-04-08 17:27:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:27:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:27:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:27:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:27:48 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:27:48 --> Final output sent to browser
DEBUG - 2018-04-08 17:27:48 --> Total execution time: 0.1160
INFO - 2018-04-08 13:58:57 --> Config Class Initialized
INFO - 2018-04-08 13:58:57 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:58:57 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:58:57 --> Utf8 Class Initialized
INFO - 2018-04-08 13:58:57 --> URI Class Initialized
INFO - 2018-04-08 13:58:57 --> Router Class Initialized
INFO - 2018-04-08 13:58:57 --> Output Class Initialized
INFO - 2018-04-08 13:58:57 --> Security Class Initialized
DEBUG - 2018-04-08 13:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:58:57 --> Input Class Initialized
INFO - 2018-04-08 13:58:57 --> Language Class Initialized
INFO - 2018-04-08 13:58:57 --> Loader Class Initialized
INFO - 2018-04-08 13:58:57 --> Helper loaded: common_helper
INFO - 2018-04-08 13:58:57 --> Database Driver Class Initialized
INFO - 2018-04-08 13:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:58:57 --> Email Class Initialized
INFO - 2018-04-08 13:58:57 --> Controller Class Initialized
INFO - 2018-04-08 13:58:57 --> Helper loaded: form_helper
INFO - 2018-04-08 13:58:57 --> Form Validation Class Initialized
INFO - 2018-04-08 13:58:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:58:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:58:57 --> Helper loaded: url_helper
INFO - 2018-04-08 13:58:57 --> Model Class Initialized
INFO - 2018-04-08 13:58:57 --> Model Class Initialized
INFO - 2018-04-08 13:58:57 --> Model Class Initialized
INFO - 2018-04-08 17:28:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:28:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:28:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:28:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:28:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:28:57 --> Final output sent to browser
DEBUG - 2018-04-08 17:28:57 --> Total execution time: 0.1350
INFO - 2018-04-08 13:59:07 --> Config Class Initialized
INFO - 2018-04-08 13:59:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:59:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:59:07 --> Utf8 Class Initialized
INFO - 2018-04-08 13:59:07 --> URI Class Initialized
INFO - 2018-04-08 13:59:07 --> Router Class Initialized
INFO - 2018-04-08 13:59:07 --> Output Class Initialized
INFO - 2018-04-08 13:59:07 --> Security Class Initialized
DEBUG - 2018-04-08 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:59:07 --> Input Class Initialized
INFO - 2018-04-08 13:59:07 --> Language Class Initialized
INFO - 2018-04-08 13:59:07 --> Loader Class Initialized
INFO - 2018-04-08 13:59:07 --> Helper loaded: common_helper
INFO - 2018-04-08 13:59:07 --> Database Driver Class Initialized
INFO - 2018-04-08 13:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:59:07 --> Email Class Initialized
INFO - 2018-04-08 13:59:07 --> Controller Class Initialized
INFO - 2018-04-08 13:59:07 --> Helper loaded: form_helper
INFO - 2018-04-08 13:59:07 --> Form Validation Class Initialized
INFO - 2018-04-08 13:59:07 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:59:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:59:07 --> Helper loaded: url_helper
INFO - 2018-04-08 13:59:07 --> Model Class Initialized
INFO - 2018-04-08 13:59:07 --> Model Class Initialized
INFO - 2018-04-08 13:59:07 --> Model Class Initialized
INFO - 2018-04-08 13:59:10 --> Config Class Initialized
INFO - 2018-04-08 13:59:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 13:59:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 13:59:10 --> Utf8 Class Initialized
INFO - 2018-04-08 13:59:10 --> URI Class Initialized
INFO - 2018-04-08 13:59:10 --> Router Class Initialized
INFO - 2018-04-08 13:59:10 --> Output Class Initialized
INFO - 2018-04-08 13:59:10 --> Security Class Initialized
DEBUG - 2018-04-08 13:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 13:59:11 --> Input Class Initialized
INFO - 2018-04-08 13:59:11 --> Language Class Initialized
INFO - 2018-04-08 13:59:11 --> Loader Class Initialized
INFO - 2018-04-08 13:59:11 --> Helper loaded: common_helper
INFO - 2018-04-08 13:59:11 --> Database Driver Class Initialized
INFO - 2018-04-08 13:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 13:59:11 --> Email Class Initialized
INFO - 2018-04-08 13:59:11 --> Controller Class Initialized
INFO - 2018-04-08 13:59:11 --> Helper loaded: form_helper
INFO - 2018-04-08 13:59:11 --> Form Validation Class Initialized
INFO - 2018-04-08 13:59:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 13:59:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 13:59:11 --> Helper loaded: url_helper
INFO - 2018-04-08 13:59:11 --> Model Class Initialized
INFO - 2018-04-08 13:59:11 --> Model Class Initialized
INFO - 2018-04-08 13:59:11 --> Model Class Initialized
INFO - 2018-04-08 17:29:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:29:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:29:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:29:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:29:11 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:29:11 --> Final output sent to browser
DEBUG - 2018-04-08 17:29:11 --> Total execution time: 0.1360
INFO - 2018-04-08 14:00:45 --> Config Class Initialized
INFO - 2018-04-08 14:00:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:00:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:00:45 --> Utf8 Class Initialized
INFO - 2018-04-08 14:00:45 --> URI Class Initialized
INFO - 2018-04-08 14:00:45 --> Router Class Initialized
INFO - 2018-04-08 14:00:45 --> Output Class Initialized
INFO - 2018-04-08 14:00:45 --> Security Class Initialized
DEBUG - 2018-04-08 14:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:00:45 --> Input Class Initialized
INFO - 2018-04-08 14:00:45 --> Language Class Initialized
INFO - 2018-04-08 14:00:45 --> Loader Class Initialized
INFO - 2018-04-08 14:00:45 --> Helper loaded: common_helper
INFO - 2018-04-08 14:00:45 --> Database Driver Class Initialized
INFO - 2018-04-08 14:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:00:45 --> Email Class Initialized
INFO - 2018-04-08 14:00:45 --> Controller Class Initialized
INFO - 2018-04-08 14:00:45 --> Helper loaded: form_helper
INFO - 2018-04-08 14:00:45 --> Form Validation Class Initialized
INFO - 2018-04-08 14:00:45 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:00:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:00:45 --> Helper loaded: url_helper
INFO - 2018-04-08 14:00:45 --> Model Class Initialized
INFO - 2018-04-08 14:00:46 --> Model Class Initialized
INFO - 2018-04-08 14:00:46 --> Model Class Initialized
INFO - 2018-04-08 17:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:30:46 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:30:46 --> Final output sent to browser
DEBUG - 2018-04-08 17:30:46 --> Total execution time: 0.1370
INFO - 2018-04-08 14:00:51 --> Config Class Initialized
INFO - 2018-04-08 14:00:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:00:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:00:51 --> Utf8 Class Initialized
INFO - 2018-04-08 14:00:51 --> URI Class Initialized
INFO - 2018-04-08 14:00:51 --> Router Class Initialized
INFO - 2018-04-08 14:00:51 --> Output Class Initialized
INFO - 2018-04-08 14:00:51 --> Security Class Initialized
DEBUG - 2018-04-08 14:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:00:51 --> Input Class Initialized
INFO - 2018-04-08 14:00:51 --> Language Class Initialized
INFO - 2018-04-08 14:00:51 --> Loader Class Initialized
INFO - 2018-04-08 14:00:51 --> Helper loaded: common_helper
INFO - 2018-04-08 14:00:51 --> Database Driver Class Initialized
INFO - 2018-04-08 14:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:00:51 --> Email Class Initialized
INFO - 2018-04-08 14:00:51 --> Controller Class Initialized
INFO - 2018-04-08 14:00:51 --> Helper loaded: form_helper
INFO - 2018-04-08 14:00:51 --> Form Validation Class Initialized
INFO - 2018-04-08 14:00:51 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:00:51 --> Helper loaded: url_helper
INFO - 2018-04-08 14:00:51 --> Model Class Initialized
INFO - 2018-04-08 14:00:51 --> Model Class Initialized
INFO - 2018-04-08 14:00:51 --> Model Class Initialized
INFO - 2018-04-08 14:00:51 --> Config Class Initialized
INFO - 2018-04-08 14:00:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:00:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:00:51 --> Utf8 Class Initialized
INFO - 2018-04-08 14:00:51 --> URI Class Initialized
INFO - 2018-04-08 14:00:51 --> Router Class Initialized
INFO - 2018-04-08 14:00:51 --> Output Class Initialized
INFO - 2018-04-08 14:00:51 --> Security Class Initialized
DEBUG - 2018-04-08 14:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:00:51 --> Input Class Initialized
INFO - 2018-04-08 14:00:51 --> Language Class Initialized
INFO - 2018-04-08 14:00:51 --> Loader Class Initialized
INFO - 2018-04-08 14:00:51 --> Helper loaded: common_helper
INFO - 2018-04-08 14:00:51 --> Database Driver Class Initialized
INFO - 2018-04-08 14:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:00:51 --> Email Class Initialized
INFO - 2018-04-08 14:00:51 --> Controller Class Initialized
INFO - 2018-04-08 14:00:51 --> Helper loaded: form_helper
INFO - 2018-04-08 14:00:51 --> Form Validation Class Initialized
INFO - 2018-04-08 14:00:51 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:00:51 --> Helper loaded: url_helper
INFO - 2018-04-08 14:00:51 --> Model Class Initialized
INFO - 2018-04-08 14:00:51 --> Model Class Initialized
INFO - 2018-04-08 14:00:51 --> Model Class Initialized
INFO - 2018-04-08 17:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:30:51 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:30:51 --> Final output sent to browser
DEBUG - 2018-04-08 17:30:51 --> Total execution time: 0.1270
INFO - 2018-04-08 14:01:23 --> Config Class Initialized
INFO - 2018-04-08 14:01:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:01:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:01:23 --> Utf8 Class Initialized
INFO - 2018-04-08 14:01:23 --> URI Class Initialized
INFO - 2018-04-08 14:01:23 --> Router Class Initialized
INFO - 2018-04-08 14:01:23 --> Output Class Initialized
INFO - 2018-04-08 14:01:23 --> Security Class Initialized
DEBUG - 2018-04-08 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:01:23 --> Input Class Initialized
INFO - 2018-04-08 14:01:23 --> Language Class Initialized
INFO - 2018-04-08 14:01:23 --> Loader Class Initialized
INFO - 2018-04-08 14:01:23 --> Helper loaded: common_helper
INFO - 2018-04-08 14:01:23 --> Database Driver Class Initialized
INFO - 2018-04-08 14:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:01:23 --> Email Class Initialized
INFO - 2018-04-08 14:01:23 --> Controller Class Initialized
INFO - 2018-04-08 14:01:23 --> Helper loaded: form_helper
INFO - 2018-04-08 14:01:23 --> Form Validation Class Initialized
INFO - 2018-04-08 14:01:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:01:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:01:23 --> Helper loaded: url_helper
INFO - 2018-04-08 14:01:23 --> Model Class Initialized
INFO - 2018-04-08 14:01:23 --> Model Class Initialized
INFO - 2018-04-08 14:01:23 --> Model Class Initialized
INFO - 2018-04-08 17:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:31:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:31:23 --> Final output sent to browser
DEBUG - 2018-04-08 17:31:23 --> Total execution time: 0.1360
INFO - 2018-04-08 14:01:27 --> Config Class Initialized
INFO - 2018-04-08 14:01:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:01:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:01:27 --> Utf8 Class Initialized
INFO - 2018-04-08 14:01:27 --> URI Class Initialized
INFO - 2018-04-08 14:01:27 --> Router Class Initialized
INFO - 2018-04-08 14:01:27 --> Output Class Initialized
INFO - 2018-04-08 14:01:27 --> Security Class Initialized
DEBUG - 2018-04-08 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:01:27 --> Input Class Initialized
INFO - 2018-04-08 14:01:27 --> Language Class Initialized
INFO - 2018-04-08 14:01:27 --> Loader Class Initialized
INFO - 2018-04-08 14:01:27 --> Helper loaded: common_helper
INFO - 2018-04-08 14:01:27 --> Database Driver Class Initialized
INFO - 2018-04-08 14:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:01:27 --> Email Class Initialized
INFO - 2018-04-08 14:01:27 --> Controller Class Initialized
INFO - 2018-04-08 14:01:27 --> Helper loaded: form_helper
INFO - 2018-04-08 14:01:27 --> Form Validation Class Initialized
INFO - 2018-04-08 14:01:27 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:01:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:01:28 --> Helper loaded: url_helper
INFO - 2018-04-08 14:01:28 --> Model Class Initialized
INFO - 2018-04-08 14:01:28 --> Model Class Initialized
INFO - 2018-04-08 14:01:28 --> Model Class Initialized
INFO - 2018-04-08 14:01:29 --> Config Class Initialized
INFO - 2018-04-08 14:01:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:01:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:01:29 --> Utf8 Class Initialized
INFO - 2018-04-08 14:01:29 --> URI Class Initialized
INFO - 2018-04-08 14:01:29 --> Router Class Initialized
INFO - 2018-04-08 14:01:29 --> Output Class Initialized
INFO - 2018-04-08 14:01:29 --> Security Class Initialized
DEBUG - 2018-04-08 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:01:29 --> Input Class Initialized
INFO - 2018-04-08 14:01:29 --> Language Class Initialized
INFO - 2018-04-08 14:01:29 --> Loader Class Initialized
INFO - 2018-04-08 14:01:29 --> Helper loaded: common_helper
INFO - 2018-04-08 14:01:29 --> Database Driver Class Initialized
INFO - 2018-04-08 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:01:29 --> Email Class Initialized
INFO - 2018-04-08 14:01:29 --> Controller Class Initialized
INFO - 2018-04-08 14:01:29 --> Helper loaded: form_helper
INFO - 2018-04-08 14:01:29 --> Form Validation Class Initialized
INFO - 2018-04-08 14:01:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:01:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:01:29 --> Helper loaded: url_helper
INFO - 2018-04-08 14:01:29 --> Model Class Initialized
INFO - 2018-04-08 14:01:29 --> Model Class Initialized
INFO - 2018-04-08 14:01:29 --> Model Class Initialized
INFO - 2018-04-08 17:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:31:29 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:31:29 --> Final output sent to browser
DEBUG - 2018-04-08 17:31:29 --> Total execution time: 0.1410
INFO - 2018-04-08 14:01:50 --> Config Class Initialized
INFO - 2018-04-08 14:01:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:01:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:01:50 --> Utf8 Class Initialized
INFO - 2018-04-08 14:01:50 --> URI Class Initialized
INFO - 2018-04-08 14:01:50 --> Router Class Initialized
INFO - 2018-04-08 14:01:50 --> Output Class Initialized
INFO - 2018-04-08 14:01:50 --> Security Class Initialized
DEBUG - 2018-04-08 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:01:50 --> Input Class Initialized
INFO - 2018-04-08 14:01:50 --> Language Class Initialized
INFO - 2018-04-08 14:01:50 --> Loader Class Initialized
INFO - 2018-04-08 14:01:50 --> Helper loaded: common_helper
INFO - 2018-04-08 14:01:50 --> Database Driver Class Initialized
INFO - 2018-04-08 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:01:50 --> Email Class Initialized
INFO - 2018-04-08 14:01:50 --> Controller Class Initialized
INFO - 2018-04-08 14:01:50 --> Helper loaded: form_helper
INFO - 2018-04-08 14:01:50 --> Form Validation Class Initialized
INFO - 2018-04-08 14:01:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:01:50 --> Helper loaded: url_helper
INFO - 2018-04-08 14:01:50 --> Model Class Initialized
INFO - 2018-04-08 14:01:50 --> Model Class Initialized
INFO - 2018-04-08 14:01:50 --> Model Class Initialized
INFO - 2018-04-08 17:31:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:31:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:31:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:31:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:31:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:31:50 --> Final output sent to browser
DEBUG - 2018-04-08 17:31:50 --> Total execution time: 0.1320
INFO - 2018-04-08 14:01:55 --> Config Class Initialized
INFO - 2018-04-08 14:01:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:01:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:01:55 --> Utf8 Class Initialized
INFO - 2018-04-08 14:01:55 --> URI Class Initialized
INFO - 2018-04-08 14:01:55 --> Router Class Initialized
INFO - 2018-04-08 14:01:55 --> Output Class Initialized
INFO - 2018-04-08 14:01:55 --> Security Class Initialized
DEBUG - 2018-04-08 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:01:55 --> Input Class Initialized
INFO - 2018-04-08 14:01:55 --> Language Class Initialized
INFO - 2018-04-08 14:01:55 --> Loader Class Initialized
INFO - 2018-04-08 14:01:55 --> Helper loaded: common_helper
INFO - 2018-04-08 14:01:55 --> Database Driver Class Initialized
INFO - 2018-04-08 14:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:01:55 --> Email Class Initialized
INFO - 2018-04-08 14:01:55 --> Controller Class Initialized
INFO - 2018-04-08 14:01:55 --> Helper loaded: form_helper
INFO - 2018-04-08 14:01:55 --> Form Validation Class Initialized
INFO - 2018-04-08 14:01:55 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:01:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:01:55 --> Helper loaded: url_helper
INFO - 2018-04-08 14:01:55 --> Model Class Initialized
INFO - 2018-04-08 14:01:55 --> Model Class Initialized
INFO - 2018-04-08 14:01:55 --> Model Class Initialized
INFO - 2018-04-08 14:02:04 --> Config Class Initialized
INFO - 2018-04-08 14:02:04 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:02:04 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:02:04 --> Utf8 Class Initialized
INFO - 2018-04-08 14:02:04 --> URI Class Initialized
INFO - 2018-04-08 14:02:04 --> Router Class Initialized
INFO - 2018-04-08 14:02:04 --> Output Class Initialized
INFO - 2018-04-08 14:02:04 --> Security Class Initialized
DEBUG - 2018-04-08 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:02:04 --> Input Class Initialized
INFO - 2018-04-08 14:02:04 --> Language Class Initialized
INFO - 2018-04-08 14:02:04 --> Loader Class Initialized
INFO - 2018-04-08 14:02:04 --> Helper loaded: common_helper
INFO - 2018-04-08 14:02:04 --> Database Driver Class Initialized
INFO - 2018-04-08 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:02:04 --> Email Class Initialized
INFO - 2018-04-08 14:02:04 --> Controller Class Initialized
INFO - 2018-04-08 14:02:04 --> Helper loaded: form_helper
INFO - 2018-04-08 14:02:04 --> Form Validation Class Initialized
INFO - 2018-04-08 14:02:04 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:02:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:02:04 --> Helper loaded: url_helper
INFO - 2018-04-08 14:02:04 --> Model Class Initialized
INFO - 2018-04-08 14:02:04 --> Model Class Initialized
INFO - 2018-04-08 14:02:04 --> Model Class Initialized
INFO - 2018-04-08 17:32:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:32:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:32:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:32:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:32:04 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:32:04 --> Final output sent to browser
DEBUG - 2018-04-08 17:32:04 --> Total execution time: 0.1430
INFO - 2018-04-08 14:03:14 --> Config Class Initialized
INFO - 2018-04-08 14:03:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:03:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:03:14 --> Utf8 Class Initialized
INFO - 2018-04-08 14:03:14 --> URI Class Initialized
INFO - 2018-04-08 14:03:14 --> Router Class Initialized
INFO - 2018-04-08 14:03:14 --> Output Class Initialized
INFO - 2018-04-08 14:03:14 --> Security Class Initialized
DEBUG - 2018-04-08 14:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:03:14 --> Input Class Initialized
INFO - 2018-04-08 14:03:14 --> Language Class Initialized
INFO - 2018-04-08 14:03:14 --> Loader Class Initialized
INFO - 2018-04-08 14:03:14 --> Helper loaded: common_helper
INFO - 2018-04-08 14:03:14 --> Database Driver Class Initialized
INFO - 2018-04-08 14:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:03:14 --> Email Class Initialized
INFO - 2018-04-08 14:03:14 --> Controller Class Initialized
INFO - 2018-04-08 14:03:14 --> Helper loaded: form_helper
INFO - 2018-04-08 14:03:14 --> Form Validation Class Initialized
INFO - 2018-04-08 14:03:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:03:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:03:14 --> Helper loaded: url_helper
INFO - 2018-04-08 14:03:14 --> Model Class Initialized
INFO - 2018-04-08 14:03:14 --> Model Class Initialized
INFO - 2018-04-08 14:03:14 --> Model Class Initialized
INFO - 2018-04-08 17:33:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:33:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:33:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:33:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:33:14 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:33:14 --> Final output sent to browser
DEBUG - 2018-04-08 17:33:14 --> Total execution time: 0.1310
INFO - 2018-04-08 14:03:19 --> Config Class Initialized
INFO - 2018-04-08 14:03:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:03:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:03:19 --> Utf8 Class Initialized
INFO - 2018-04-08 14:03:19 --> URI Class Initialized
INFO - 2018-04-08 14:03:19 --> Router Class Initialized
INFO - 2018-04-08 14:03:19 --> Output Class Initialized
INFO - 2018-04-08 14:03:19 --> Security Class Initialized
DEBUG - 2018-04-08 14:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:03:19 --> Input Class Initialized
INFO - 2018-04-08 14:03:19 --> Language Class Initialized
INFO - 2018-04-08 14:03:19 --> Loader Class Initialized
INFO - 2018-04-08 14:03:19 --> Helper loaded: common_helper
INFO - 2018-04-08 14:03:19 --> Database Driver Class Initialized
INFO - 2018-04-08 14:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:03:19 --> Email Class Initialized
INFO - 2018-04-08 14:03:19 --> Controller Class Initialized
INFO - 2018-04-08 14:03:19 --> Helper loaded: form_helper
INFO - 2018-04-08 14:03:19 --> Form Validation Class Initialized
INFO - 2018-04-08 14:03:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:03:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:03:19 --> Helper loaded: url_helper
INFO - 2018-04-08 14:03:19 --> Model Class Initialized
INFO - 2018-04-08 14:03:19 --> Model Class Initialized
INFO - 2018-04-08 14:03:19 --> Model Class Initialized
INFO - 2018-04-08 14:03:21 --> Config Class Initialized
INFO - 2018-04-08 14:03:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:03:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:03:21 --> Utf8 Class Initialized
INFO - 2018-04-08 14:03:21 --> URI Class Initialized
INFO - 2018-04-08 14:03:21 --> Router Class Initialized
INFO - 2018-04-08 14:03:21 --> Output Class Initialized
INFO - 2018-04-08 14:03:21 --> Security Class Initialized
DEBUG - 2018-04-08 14:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:03:21 --> Input Class Initialized
INFO - 2018-04-08 14:03:21 --> Language Class Initialized
INFO - 2018-04-08 14:03:21 --> Loader Class Initialized
INFO - 2018-04-08 14:03:21 --> Helper loaded: common_helper
INFO - 2018-04-08 14:03:21 --> Database Driver Class Initialized
INFO - 2018-04-08 14:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:03:21 --> Email Class Initialized
INFO - 2018-04-08 14:03:21 --> Controller Class Initialized
INFO - 2018-04-08 14:03:21 --> Helper loaded: form_helper
INFO - 2018-04-08 14:03:21 --> Form Validation Class Initialized
INFO - 2018-04-08 14:03:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:03:21 --> Helper loaded: url_helper
INFO - 2018-04-08 14:03:21 --> Model Class Initialized
INFO - 2018-04-08 14:03:21 --> Model Class Initialized
INFO - 2018-04-08 14:03:21 --> Model Class Initialized
INFO - 2018-04-08 17:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:33:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:33:21 --> Final output sent to browser
DEBUG - 2018-04-08 17:33:21 --> Total execution time: 0.1380
INFO - 2018-04-08 14:03:42 --> Config Class Initialized
INFO - 2018-04-08 14:03:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:03:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:03:42 --> Utf8 Class Initialized
INFO - 2018-04-08 14:03:42 --> URI Class Initialized
INFO - 2018-04-08 14:03:42 --> Router Class Initialized
INFO - 2018-04-08 14:03:42 --> Output Class Initialized
INFO - 2018-04-08 14:03:42 --> Security Class Initialized
DEBUG - 2018-04-08 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:03:42 --> Input Class Initialized
INFO - 2018-04-08 14:03:43 --> Language Class Initialized
INFO - 2018-04-08 14:03:43 --> Loader Class Initialized
INFO - 2018-04-08 14:03:43 --> Helper loaded: common_helper
INFO - 2018-04-08 14:03:43 --> Database Driver Class Initialized
INFO - 2018-04-08 14:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:03:43 --> Email Class Initialized
INFO - 2018-04-08 14:03:43 --> Controller Class Initialized
INFO - 2018-04-08 14:03:43 --> Helper loaded: form_helper
INFO - 2018-04-08 14:03:43 --> Form Validation Class Initialized
INFO - 2018-04-08 14:03:43 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:03:43 --> Helper loaded: url_helper
INFO - 2018-04-08 14:03:43 --> Model Class Initialized
INFO - 2018-04-08 14:03:43 --> Model Class Initialized
INFO - 2018-04-08 14:03:43 --> Model Class Initialized
INFO - 2018-04-08 17:33:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:33:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:33:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:33:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:33:43 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:33:43 --> Final output sent to browser
DEBUG - 2018-04-08 17:33:43 --> Total execution time: 0.1350
INFO - 2018-04-08 14:03:48 --> Config Class Initialized
INFO - 2018-04-08 14:03:48 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:03:48 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:03:48 --> Utf8 Class Initialized
INFO - 2018-04-08 14:03:48 --> URI Class Initialized
INFO - 2018-04-08 14:03:48 --> Router Class Initialized
INFO - 2018-04-08 14:03:48 --> Output Class Initialized
INFO - 2018-04-08 14:03:48 --> Security Class Initialized
DEBUG - 2018-04-08 14:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:03:48 --> Input Class Initialized
INFO - 2018-04-08 14:03:48 --> Language Class Initialized
INFO - 2018-04-08 14:03:48 --> Loader Class Initialized
INFO - 2018-04-08 14:03:48 --> Helper loaded: common_helper
INFO - 2018-04-08 14:03:48 --> Database Driver Class Initialized
INFO - 2018-04-08 14:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:03:48 --> Email Class Initialized
INFO - 2018-04-08 14:03:48 --> Controller Class Initialized
INFO - 2018-04-08 14:03:48 --> Helper loaded: form_helper
INFO - 2018-04-08 14:03:48 --> Form Validation Class Initialized
INFO - 2018-04-08 14:03:48 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:03:48 --> Helper loaded: url_helper
INFO - 2018-04-08 14:03:48 --> Model Class Initialized
INFO - 2018-04-08 14:03:48 --> Model Class Initialized
INFO - 2018-04-08 14:03:48 --> Model Class Initialized
INFO - 2018-04-08 17:33:48 --> Final output sent to browser
DEBUG - 2018-04-08 17:33:48 --> Total execution time: 0.1920
INFO - 2018-04-08 14:03:49 --> Config Class Initialized
INFO - 2018-04-08 14:03:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:03:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:03:49 --> Utf8 Class Initialized
INFO - 2018-04-08 14:03:49 --> URI Class Initialized
INFO - 2018-04-08 14:03:49 --> Router Class Initialized
INFO - 2018-04-08 14:03:49 --> Output Class Initialized
INFO - 2018-04-08 14:03:49 --> Security Class Initialized
DEBUG - 2018-04-08 14:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:03:49 --> Input Class Initialized
INFO - 2018-04-08 14:03:49 --> Language Class Initialized
INFO - 2018-04-08 14:03:49 --> Loader Class Initialized
INFO - 2018-04-08 14:03:49 --> Helper loaded: common_helper
INFO - 2018-04-08 14:03:49 --> Database Driver Class Initialized
INFO - 2018-04-08 14:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:03:49 --> Email Class Initialized
INFO - 2018-04-08 14:03:49 --> Controller Class Initialized
INFO - 2018-04-08 14:03:49 --> Helper loaded: form_helper
INFO - 2018-04-08 14:03:49 --> Form Validation Class Initialized
INFO - 2018-04-08 14:03:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:03:49 --> Helper loaded: url_helper
INFO - 2018-04-08 14:03:49 --> Model Class Initialized
INFO - 2018-04-08 14:03:49 --> Model Class Initialized
INFO - 2018-04-08 14:03:49 --> Model Class Initialized
INFO - 2018-04-08 17:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:33:49 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:33:49 --> Final output sent to browser
DEBUG - 2018-04-08 17:33:49 --> Total execution time: 0.1380
INFO - 2018-04-08 14:04:17 --> Config Class Initialized
INFO - 2018-04-08 14:04:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:17 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:17 --> URI Class Initialized
INFO - 2018-04-08 14:04:17 --> Router Class Initialized
INFO - 2018-04-08 14:04:17 --> Output Class Initialized
INFO - 2018-04-08 14:04:17 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:17 --> Input Class Initialized
INFO - 2018-04-08 14:04:17 --> Language Class Initialized
INFO - 2018-04-08 14:04:17 --> Loader Class Initialized
INFO - 2018-04-08 14:04:17 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:17 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:17 --> Email Class Initialized
INFO - 2018-04-08 14:04:17 --> Controller Class Initialized
INFO - 2018-04-08 14:04:17 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:17 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:17 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:17 --> Model Class Initialized
INFO - 2018-04-08 14:04:18 --> Model Class Initialized
INFO - 2018-04-08 14:04:18 --> Model Class Initialized
INFO - 2018-04-08 17:34:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:34:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:34:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:34:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:34:18 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:34:18 --> Final output sent to browser
DEBUG - 2018-04-08 17:34:18 --> Total execution time: 0.1420
INFO - 2018-04-08 14:04:21 --> Config Class Initialized
INFO - 2018-04-08 14:04:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:21 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:21 --> URI Class Initialized
INFO - 2018-04-08 14:04:21 --> Router Class Initialized
INFO - 2018-04-08 14:04:21 --> Output Class Initialized
INFO - 2018-04-08 14:04:21 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:21 --> Input Class Initialized
INFO - 2018-04-08 14:04:21 --> Language Class Initialized
INFO - 2018-04-08 14:04:21 --> Loader Class Initialized
INFO - 2018-04-08 14:04:21 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:21 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:21 --> Email Class Initialized
INFO - 2018-04-08 14:04:21 --> Controller Class Initialized
INFO - 2018-04-08 14:04:21 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:21 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:21 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:21 --> Model Class Initialized
INFO - 2018-04-08 14:04:21 --> Model Class Initialized
INFO - 2018-04-08 14:04:21 --> Model Class Initialized
INFO - 2018-04-08 17:34:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:34:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:34:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:34:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 17:34:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:34:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:34:21 --> Final output sent to browser
DEBUG - 2018-04-08 17:34:21 --> Total execution time: 0.1320
INFO - 2018-04-08 14:04:27 --> Config Class Initialized
INFO - 2018-04-08 14:04:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:27 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:27 --> URI Class Initialized
INFO - 2018-04-08 14:04:27 --> Router Class Initialized
INFO - 2018-04-08 14:04:27 --> Output Class Initialized
INFO - 2018-04-08 14:04:27 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:27 --> Input Class Initialized
INFO - 2018-04-08 14:04:27 --> Language Class Initialized
INFO - 2018-04-08 14:04:27 --> Loader Class Initialized
INFO - 2018-04-08 14:04:27 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:27 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:27 --> Email Class Initialized
INFO - 2018-04-08 14:04:27 --> Controller Class Initialized
INFO - 2018-04-08 14:04:27 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:27 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:27 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:27 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:27 --> Model Class Initialized
INFO - 2018-04-08 14:04:27 --> Model Class Initialized
INFO - 2018-04-08 14:04:27 --> Model Class Initialized
DEBUG - 2018-04-08 17:34:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 17:34:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 14:04:27 --> Config Class Initialized
INFO - 2018-04-08 14:04:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:27 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:27 --> URI Class Initialized
INFO - 2018-04-08 14:04:27 --> Router Class Initialized
INFO - 2018-04-08 14:04:27 --> Output Class Initialized
INFO - 2018-04-08 14:04:27 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:27 --> Input Class Initialized
INFO - 2018-04-08 14:04:27 --> Language Class Initialized
INFO - 2018-04-08 14:04:27 --> Loader Class Initialized
INFO - 2018-04-08 14:04:27 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:27 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:27 --> Email Class Initialized
INFO - 2018-04-08 14:04:27 --> Controller Class Initialized
INFO - 2018-04-08 14:04:27 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:27 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:27 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:27 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:27 --> Model Class Initialized
INFO - 2018-04-08 14:04:27 --> Model Class Initialized
INFO - 2018-04-08 14:04:27 --> Model Class Initialized
INFO - 2018-04-08 17:34:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:34:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:34:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:34:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 17:34:27 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:34:27 --> Final output sent to browser
DEBUG - 2018-04-08 17:34:27 --> Total execution time: 0.1400
INFO - 2018-04-08 14:04:31 --> Config Class Initialized
INFO - 2018-04-08 14:04:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:31 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:31 --> URI Class Initialized
INFO - 2018-04-08 14:04:31 --> Router Class Initialized
INFO - 2018-04-08 14:04:31 --> Output Class Initialized
INFO - 2018-04-08 14:04:31 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:31 --> Input Class Initialized
INFO - 2018-04-08 14:04:31 --> Language Class Initialized
INFO - 2018-04-08 14:04:31 --> Loader Class Initialized
INFO - 2018-04-08 14:04:31 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:31 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:32 --> Email Class Initialized
INFO - 2018-04-08 14:04:32 --> Controller Class Initialized
INFO - 2018-04-08 14:04:32 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:32 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:32 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:32 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:32 --> Model Class Initialized
INFO - 2018-04-08 14:04:32 --> Model Class Initialized
INFO - 2018-04-08 14:04:32 --> Model Class Initialized
INFO - 2018-04-08 17:34:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:34:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:34:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 17:34:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:34:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:34:32 --> Final output sent to browser
DEBUG - 2018-04-08 17:34:32 --> Total execution time: 0.1380
INFO - 2018-04-08 14:04:53 --> Config Class Initialized
INFO - 2018-04-08 14:04:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:53 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:53 --> URI Class Initialized
INFO - 2018-04-08 14:04:53 --> Router Class Initialized
INFO - 2018-04-08 14:04:53 --> Output Class Initialized
INFO - 2018-04-08 14:04:53 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:53 --> Input Class Initialized
INFO - 2018-04-08 14:04:53 --> Language Class Initialized
INFO - 2018-04-08 14:04:53 --> Loader Class Initialized
INFO - 2018-04-08 14:04:53 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:53 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:53 --> Email Class Initialized
INFO - 2018-04-08 14:04:53 --> Controller Class Initialized
INFO - 2018-04-08 14:04:53 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:53 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:53 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:53 --> Model Class Initialized
INFO - 2018-04-08 14:04:53 --> Model Class Initialized
INFO - 2018-04-08 14:04:53 --> Model Class Initialized
ERROR - 2018-04-08 17:34:53 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 17:34:53 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 14:04:53 --> Config Class Initialized
INFO - 2018-04-08 14:04:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:04:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:04:53 --> Utf8 Class Initialized
INFO - 2018-04-08 14:04:53 --> URI Class Initialized
INFO - 2018-04-08 14:04:53 --> Router Class Initialized
INFO - 2018-04-08 14:04:53 --> Output Class Initialized
INFO - 2018-04-08 14:04:53 --> Security Class Initialized
DEBUG - 2018-04-08 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:04:53 --> Input Class Initialized
INFO - 2018-04-08 14:04:53 --> Language Class Initialized
INFO - 2018-04-08 14:04:53 --> Loader Class Initialized
INFO - 2018-04-08 14:04:53 --> Helper loaded: common_helper
INFO - 2018-04-08 14:04:53 --> Database Driver Class Initialized
INFO - 2018-04-08 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:04:53 --> Email Class Initialized
INFO - 2018-04-08 14:04:53 --> Controller Class Initialized
INFO - 2018-04-08 14:04:53 --> Helper loaded: form_helper
INFO - 2018-04-08 14:04:53 --> Form Validation Class Initialized
INFO - 2018-04-08 14:04:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:04:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:04:53 --> Helper loaded: url_helper
INFO - 2018-04-08 14:04:53 --> Model Class Initialized
INFO - 2018-04-08 14:04:53 --> Model Class Initialized
INFO - 2018-04-08 14:04:53 --> Model Class Initialized
INFO - 2018-04-08 17:34:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:34:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:34:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:34:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 17:34:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:34:53 --> Final output sent to browser
DEBUG - 2018-04-08 17:34:53 --> Total execution time: 0.1290
INFO - 2018-04-08 14:05:24 --> Config Class Initialized
INFO - 2018-04-08 14:05:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:24 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:24 --> URI Class Initialized
INFO - 2018-04-08 14:05:24 --> Router Class Initialized
INFO - 2018-04-08 14:05:24 --> Output Class Initialized
INFO - 2018-04-08 14:05:24 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:24 --> Input Class Initialized
INFO - 2018-04-08 14:05:24 --> Language Class Initialized
INFO - 2018-04-08 14:05:24 --> Loader Class Initialized
INFO - 2018-04-08 14:05:24 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:24 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:24 --> Email Class Initialized
INFO - 2018-04-08 14:05:24 --> Controller Class Initialized
INFO - 2018-04-08 14:05:24 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:24 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:24 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:24 --> Model Class Initialized
INFO - 2018-04-08 14:05:24 --> Model Class Initialized
INFO - 2018-04-08 14:05:24 --> Model Class Initialized
INFO - 2018-04-08 17:35:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:35:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:35:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/editNews.php
INFO - 2018-04-08 17:35:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:24 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:35:24 --> Final output sent to browser
DEBUG - 2018-04-08 17:35:24 --> Total execution time: 0.2270
INFO - 2018-04-08 14:05:28 --> Config Class Initialized
INFO - 2018-04-08 14:05:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:28 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:28 --> URI Class Initialized
INFO - 2018-04-08 14:05:28 --> Router Class Initialized
INFO - 2018-04-08 14:05:28 --> Output Class Initialized
INFO - 2018-04-08 14:05:28 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:28 --> Input Class Initialized
INFO - 2018-04-08 14:05:28 --> Language Class Initialized
INFO - 2018-04-08 14:05:28 --> Loader Class Initialized
INFO - 2018-04-08 14:05:28 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:28 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:28 --> Email Class Initialized
INFO - 2018-04-08 14:05:28 --> Controller Class Initialized
INFO - 2018-04-08 14:05:28 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:28 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:28 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:28 --> Model Class Initialized
INFO - 2018-04-08 14:05:28 --> Model Class Initialized
INFO - 2018-04-08 14:05:28 --> Model Class Initialized
ERROR - 2018-04-08 17:35:28 --> Undefined index: edit_source_Image
ERROR - 2018-04-08 17:35:28 --> Severity: Notice --> Undefined index: edit_source_Image C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 558
INFO - 2018-04-08 14:05:28 --> Config Class Initialized
INFO - 2018-04-08 14:05:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:28 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:28 --> URI Class Initialized
INFO - 2018-04-08 14:05:28 --> Router Class Initialized
INFO - 2018-04-08 14:05:28 --> Output Class Initialized
INFO - 2018-04-08 14:05:28 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:28 --> Input Class Initialized
INFO - 2018-04-08 14:05:28 --> Language Class Initialized
INFO - 2018-04-08 14:05:28 --> Loader Class Initialized
INFO - 2018-04-08 14:05:28 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:28 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:28 --> Email Class Initialized
INFO - 2018-04-08 14:05:28 --> Controller Class Initialized
INFO - 2018-04-08 14:05:28 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:28 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:28 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:28 --> Model Class Initialized
INFO - 2018-04-08 14:05:28 --> Model Class Initialized
INFO - 2018-04-08 14:05:28 --> Model Class Initialized
INFO - 2018-04-08 17:35:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:35:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:35:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 17:35:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:35:28 --> Final output sent to browser
DEBUG - 2018-04-08 17:35:28 --> Total execution time: 0.1300
INFO - 2018-04-08 14:05:38 --> Config Class Initialized
INFO - 2018-04-08 14:05:38 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:38 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:38 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:38 --> URI Class Initialized
INFO - 2018-04-08 14:05:38 --> Router Class Initialized
INFO - 2018-04-08 14:05:38 --> Output Class Initialized
INFO - 2018-04-08 14:05:38 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:38 --> Input Class Initialized
INFO - 2018-04-08 14:05:38 --> Language Class Initialized
INFO - 2018-04-08 14:05:38 --> Loader Class Initialized
INFO - 2018-04-08 14:05:38 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:38 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:38 --> Email Class Initialized
INFO - 2018-04-08 14:05:38 --> Controller Class Initialized
INFO - 2018-04-08 14:05:38 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:38 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:38 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:38 --> Model Class Initialized
INFO - 2018-04-08 14:05:38 --> Model Class Initialized
INFO - 2018-04-08 14:05:38 --> Model Class Initialized
INFO - 2018-04-08 17:35:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:35:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:35:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:35:38 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:35:38 --> Final output sent to browser
DEBUG - 2018-04-08 17:35:38 --> Total execution time: 0.1570
INFO - 2018-04-08 14:05:45 --> Config Class Initialized
INFO - 2018-04-08 14:05:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:45 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:45 --> URI Class Initialized
INFO - 2018-04-08 14:05:45 --> Router Class Initialized
INFO - 2018-04-08 14:05:45 --> Output Class Initialized
INFO - 2018-04-08 14:05:45 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:45 --> Input Class Initialized
INFO - 2018-04-08 14:05:45 --> Language Class Initialized
INFO - 2018-04-08 14:05:45 --> Loader Class Initialized
INFO - 2018-04-08 14:05:45 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:45 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:45 --> Email Class Initialized
INFO - 2018-04-08 14:05:45 --> Controller Class Initialized
INFO - 2018-04-08 14:05:45 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:45 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:45 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:45 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:45 --> Model Class Initialized
INFO - 2018-04-08 14:05:45 --> Model Class Initialized
INFO - 2018-04-08 14:05:45 --> Model Class Initialized
INFO - 2018-04-08 17:35:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:35:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:35:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 17:35:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:45 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:35:45 --> Final output sent to browser
DEBUG - 2018-04-08 17:35:45 --> Total execution time: 0.1320
INFO - 2018-04-08 14:05:50 --> Config Class Initialized
INFO - 2018-04-08 14:05:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:50 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:50 --> URI Class Initialized
INFO - 2018-04-08 14:05:50 --> Router Class Initialized
INFO - 2018-04-08 14:05:50 --> Output Class Initialized
INFO - 2018-04-08 14:05:50 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:50 --> Input Class Initialized
INFO - 2018-04-08 14:05:50 --> Language Class Initialized
INFO - 2018-04-08 14:05:50 --> Loader Class Initialized
INFO - 2018-04-08 14:05:50 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:50 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:50 --> Email Class Initialized
INFO - 2018-04-08 14:05:50 --> Controller Class Initialized
INFO - 2018-04-08 14:05:50 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:50 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:50 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:50 --> Model Class Initialized
INFO - 2018-04-08 14:05:50 --> Model Class Initialized
INFO - 2018-04-08 14:05:50 --> Model Class Initialized
DEBUG - 2018-04-08 17:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 17:35:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 14:05:50 --> Config Class Initialized
INFO - 2018-04-08 14:05:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:50 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:50 --> URI Class Initialized
INFO - 2018-04-08 14:05:50 --> Router Class Initialized
INFO - 2018-04-08 14:05:50 --> Output Class Initialized
INFO - 2018-04-08 14:05:50 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:50 --> Input Class Initialized
INFO - 2018-04-08 14:05:50 --> Language Class Initialized
INFO - 2018-04-08 14:05:50 --> Loader Class Initialized
INFO - 2018-04-08 14:05:50 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:50 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:50 --> Email Class Initialized
INFO - 2018-04-08 14:05:50 --> Controller Class Initialized
INFO - 2018-04-08 14:05:50 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:50 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:50 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:50 --> Model Class Initialized
INFO - 2018-04-08 14:05:50 --> Model Class Initialized
INFO - 2018-04-08 14:05:50 --> Model Class Initialized
INFO - 2018-04-08 17:35:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:35:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:35:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 17:35:50 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:35:50 --> Final output sent to browser
DEBUG - 2018-04-08 17:35:50 --> Total execution time: 0.1270
INFO - 2018-04-08 14:05:57 --> Config Class Initialized
INFO - 2018-04-08 14:05:57 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:05:57 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:05:57 --> Utf8 Class Initialized
INFO - 2018-04-08 14:05:57 --> URI Class Initialized
INFO - 2018-04-08 14:05:57 --> Router Class Initialized
INFO - 2018-04-08 14:05:57 --> Output Class Initialized
INFO - 2018-04-08 14:05:57 --> Security Class Initialized
DEBUG - 2018-04-08 14:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:05:57 --> Input Class Initialized
INFO - 2018-04-08 14:05:57 --> Language Class Initialized
INFO - 2018-04-08 14:05:57 --> Loader Class Initialized
INFO - 2018-04-08 14:05:57 --> Helper loaded: common_helper
INFO - 2018-04-08 14:05:57 --> Database Driver Class Initialized
INFO - 2018-04-08 14:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:05:57 --> Email Class Initialized
INFO - 2018-04-08 14:05:57 --> Controller Class Initialized
INFO - 2018-04-08 14:05:57 --> Helper loaded: form_helper
INFO - 2018-04-08 14:05:57 --> Form Validation Class Initialized
INFO - 2018-04-08 14:05:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:05:57 --> Helper loaded: url_helper
INFO - 2018-04-08 14:05:57 --> Model Class Initialized
INFO - 2018-04-08 14:05:57 --> Model Class Initialized
INFO - 2018-04-08 14:05:57 --> Model Class Initialized
INFO - 2018-04-08 17:35:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:35:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:35:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:35:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:35:57 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:35:57 --> Final output sent to browser
DEBUG - 2018-04-08 17:35:57 --> Total execution time: 0.1290
INFO - 2018-04-08 14:07:22 --> Config Class Initialized
INFO - 2018-04-08 14:07:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:07:22 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:07:22 --> Utf8 Class Initialized
INFO - 2018-04-08 14:07:22 --> URI Class Initialized
INFO - 2018-04-08 14:07:22 --> Router Class Initialized
INFO - 2018-04-08 14:07:22 --> Output Class Initialized
INFO - 2018-04-08 14:07:22 --> Security Class Initialized
DEBUG - 2018-04-08 14:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:07:22 --> Input Class Initialized
INFO - 2018-04-08 14:07:22 --> Language Class Initialized
INFO - 2018-04-08 14:07:22 --> Loader Class Initialized
INFO - 2018-04-08 14:07:22 --> Helper loaded: common_helper
INFO - 2018-04-08 14:07:22 --> Database Driver Class Initialized
INFO - 2018-04-08 14:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:07:22 --> Email Class Initialized
INFO - 2018-04-08 14:07:22 --> Controller Class Initialized
INFO - 2018-04-08 14:07:22 --> Helper loaded: form_helper
INFO - 2018-04-08 14:07:22 --> Form Validation Class Initialized
INFO - 2018-04-08 14:07:22 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:07:22 --> Helper loaded: url_helper
INFO - 2018-04-08 14:07:22 --> Model Class Initialized
INFO - 2018-04-08 14:07:22 --> Model Class Initialized
INFO - 2018-04-08 14:07:22 --> Model Class Initialized
DEBUG - 2018-04-08 17:37:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 17:37:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 17:37:22 --> Query error: Column 'celebrityId' cannot be null - Invalid query: INSERT INTO `news` (`news_title`, `news_content`, `celebrityId`, `news_article_type`, `movieId`, `isActive`, `createdTime`) VALUES ('shootingPicks-rangastalam', 'sdfghjkasdfghjk', NULL, 3, '1', 1, '18-04-08 05:37:22')
INFO - 2018-04-08 17:37:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:37:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:37:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:37:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:37:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:37:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:37:22 --> Final output sent to browser
DEBUG - 2018-04-08 17:37:22 --> Total execution time: 0.1620
INFO - 2018-04-08 14:09:21 --> Config Class Initialized
INFO - 2018-04-08 14:09:21 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:21 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:21 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:21 --> URI Class Initialized
INFO - 2018-04-08 14:09:21 --> Router Class Initialized
INFO - 2018-04-08 14:09:21 --> Output Class Initialized
INFO - 2018-04-08 14:09:21 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:21 --> Input Class Initialized
INFO - 2018-04-08 14:09:21 --> Language Class Initialized
INFO - 2018-04-08 14:09:21 --> Loader Class Initialized
INFO - 2018-04-08 14:09:21 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:21 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:21 --> Email Class Initialized
INFO - 2018-04-08 14:09:21 --> Controller Class Initialized
INFO - 2018-04-08 14:09:21 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:21 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:21 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:21 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:21 --> Model Class Initialized
INFO - 2018-04-08 14:09:21 --> Model Class Initialized
INFO - 2018-04-08 14:09:21 --> Model Class Initialized
INFO - 2018-04-08 17:39:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:39:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:39:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:39:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:21 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:39:21 --> Final output sent to browser
DEBUG - 2018-04-08 17:39:21 --> Total execution time: 0.1650
INFO - 2018-04-08 14:09:23 --> Config Class Initialized
INFO - 2018-04-08 14:09:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:23 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:23 --> URI Class Initialized
INFO - 2018-04-08 14:09:23 --> Router Class Initialized
INFO - 2018-04-08 14:09:23 --> Output Class Initialized
INFO - 2018-04-08 14:09:23 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:23 --> Input Class Initialized
INFO - 2018-04-08 14:09:23 --> Language Class Initialized
INFO - 2018-04-08 14:09:23 --> Loader Class Initialized
INFO - 2018-04-08 14:09:23 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:23 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:23 --> Email Class Initialized
INFO - 2018-04-08 14:09:23 --> Controller Class Initialized
INFO - 2018-04-08 14:09:23 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:23 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:23 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:23 --> Model Class Initialized
INFO - 2018-04-08 14:09:23 --> Model Class Initialized
INFO - 2018-04-08 14:09:23 --> Model Class Initialized
INFO - 2018-04-08 17:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 17:39:23 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:39:23 --> Final output sent to browser
DEBUG - 2018-04-08 17:39:23 --> Total execution time: 0.1370
INFO - 2018-04-08 14:09:26 --> Config Class Initialized
INFO - 2018-04-08 14:09:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:26 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:26 --> URI Class Initialized
INFO - 2018-04-08 14:09:26 --> Router Class Initialized
INFO - 2018-04-08 14:09:26 --> Output Class Initialized
INFO - 2018-04-08 14:09:26 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:26 --> Input Class Initialized
INFO - 2018-04-08 14:09:26 --> Language Class Initialized
INFO - 2018-04-08 14:09:26 --> Loader Class Initialized
INFO - 2018-04-08 14:09:26 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:26 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:26 --> Email Class Initialized
INFO - 2018-04-08 14:09:26 --> Controller Class Initialized
INFO - 2018-04-08 14:09:26 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:26 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:26 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:26 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:26 --> Model Class Initialized
INFO - 2018-04-08 14:09:26 --> Model Class Initialized
INFO - 2018-04-08 14:09:26 --> Model Class Initialized
INFO - 2018-04-08 17:39:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:39:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:39:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 17:39:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:26 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:39:26 --> Final output sent to browser
DEBUG - 2018-04-08 17:39:26 --> Total execution time: 0.1330
INFO - 2018-04-08 14:09:28 --> Config Class Initialized
INFO - 2018-04-08 14:09:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:28 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:28 --> URI Class Initialized
INFO - 2018-04-08 14:09:28 --> Router Class Initialized
INFO - 2018-04-08 14:09:28 --> Output Class Initialized
INFO - 2018-04-08 14:09:28 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:28 --> Input Class Initialized
INFO - 2018-04-08 14:09:28 --> Language Class Initialized
INFO - 2018-04-08 14:09:28 --> Loader Class Initialized
INFO - 2018-04-08 14:09:28 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:28 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:28 --> Email Class Initialized
INFO - 2018-04-08 14:09:28 --> Controller Class Initialized
INFO - 2018-04-08 14:09:28 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:28 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:28 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:28 --> Model Class Initialized
INFO - 2018-04-08 14:09:28 --> Model Class Initialized
INFO - 2018-04-08 14:09:28 --> Model Class Initialized
INFO - 2018-04-08 17:39:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:39:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:39:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/editMovie.php
INFO - 2018-04-08 17:39:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:28 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:39:28 --> Final output sent to browser
DEBUG - 2018-04-08 17:39:28 --> Total execution time: 0.1240
INFO - 2018-04-08 14:09:31 --> Config Class Initialized
INFO - 2018-04-08 14:09:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:31 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:31 --> URI Class Initialized
INFO - 2018-04-08 14:09:31 --> Router Class Initialized
INFO - 2018-04-08 14:09:31 --> Output Class Initialized
INFO - 2018-04-08 14:09:31 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:31 --> Input Class Initialized
INFO - 2018-04-08 14:09:31 --> Language Class Initialized
INFO - 2018-04-08 14:09:31 --> Loader Class Initialized
INFO - 2018-04-08 14:09:31 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:31 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:31 --> Email Class Initialized
INFO - 2018-04-08 14:09:31 --> Controller Class Initialized
INFO - 2018-04-08 14:09:31 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:31 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:31 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:31 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:31 --> Model Class Initialized
INFO - 2018-04-08 14:09:31 --> Model Class Initialized
INFO - 2018-04-08 14:09:31 --> Model Class Initialized
DEBUG - 2018-04-08 17:39:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 17:39:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 14:09:32 --> Config Class Initialized
INFO - 2018-04-08 14:09:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:32 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:32 --> URI Class Initialized
INFO - 2018-04-08 14:09:32 --> Router Class Initialized
INFO - 2018-04-08 14:09:32 --> Output Class Initialized
INFO - 2018-04-08 14:09:32 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:32 --> Input Class Initialized
INFO - 2018-04-08 14:09:32 --> Language Class Initialized
INFO - 2018-04-08 14:09:32 --> Loader Class Initialized
INFO - 2018-04-08 14:09:32 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:32 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:32 --> Email Class Initialized
INFO - 2018-04-08 14:09:32 --> Controller Class Initialized
INFO - 2018-04-08 14:09:32 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:32 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:32 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:32 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:32 --> Model Class Initialized
INFO - 2018-04-08 14:09:32 --> Model Class Initialized
INFO - 2018-04-08 14:09:32 --> Model Class Initialized
INFO - 2018-04-08 17:39:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:39:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:39:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/news.php
INFO - 2018-04-08 17:39:32 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:39:32 --> Final output sent to browser
DEBUG - 2018-04-08 17:39:32 --> Total execution time: 0.1300
INFO - 2018-04-08 14:09:36 --> Config Class Initialized
INFO - 2018-04-08 14:09:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:09:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:09:36 --> Utf8 Class Initialized
INFO - 2018-04-08 14:09:36 --> URI Class Initialized
INFO - 2018-04-08 14:09:36 --> Router Class Initialized
INFO - 2018-04-08 14:09:36 --> Output Class Initialized
INFO - 2018-04-08 14:09:36 --> Security Class Initialized
DEBUG - 2018-04-08 14:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:09:36 --> Input Class Initialized
INFO - 2018-04-08 14:09:36 --> Language Class Initialized
INFO - 2018-04-08 14:09:36 --> Loader Class Initialized
INFO - 2018-04-08 14:09:36 --> Helper loaded: common_helper
INFO - 2018-04-08 14:09:36 --> Database Driver Class Initialized
INFO - 2018-04-08 14:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:09:36 --> Email Class Initialized
INFO - 2018-04-08 14:09:36 --> Controller Class Initialized
INFO - 2018-04-08 14:09:36 --> Helper loaded: form_helper
INFO - 2018-04-08 14:09:36 --> Form Validation Class Initialized
INFO - 2018-04-08 14:09:36 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:09:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:09:36 --> Helper loaded: url_helper
INFO - 2018-04-08 14:09:36 --> Model Class Initialized
INFO - 2018-04-08 14:09:36 --> Model Class Initialized
INFO - 2018-04-08 14:09:36 --> Model Class Initialized
INFO - 2018-04-08 17:39:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:39:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:39:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\News/addGeleryImages.php
INFO - 2018-04-08 17:39:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:39:36 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:39:36 --> Final output sent to browser
DEBUG - 2018-04-08 17:39:36 --> Total execution time: 0.1220
INFO - 2018-04-08 14:10:01 --> Config Class Initialized
INFO - 2018-04-08 14:10:01 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:10:01 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:10:01 --> Utf8 Class Initialized
INFO - 2018-04-08 14:10:01 --> URI Class Initialized
INFO - 2018-04-08 14:10:01 --> Router Class Initialized
INFO - 2018-04-08 14:10:01 --> Output Class Initialized
INFO - 2018-04-08 14:10:01 --> Security Class Initialized
DEBUG - 2018-04-08 14:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:10:01 --> Input Class Initialized
INFO - 2018-04-08 14:10:01 --> Language Class Initialized
INFO - 2018-04-08 14:10:01 --> Loader Class Initialized
INFO - 2018-04-08 14:10:01 --> Helper loaded: common_helper
INFO - 2018-04-08 14:10:01 --> Database Driver Class Initialized
INFO - 2018-04-08 14:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:10:01 --> Email Class Initialized
INFO - 2018-04-08 14:10:01 --> Controller Class Initialized
INFO - 2018-04-08 14:10:01 --> Helper loaded: form_helper
INFO - 2018-04-08 14:10:01 --> Form Validation Class Initialized
INFO - 2018-04-08 14:10:01 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:10:01 --> Helper loaded: url_helper
INFO - 2018-04-08 14:10:01 --> Model Class Initialized
INFO - 2018-04-08 14:10:01 --> Model Class Initialized
INFO - 2018-04-08 14:10:01 --> Model Class Initialized
DEBUG - 2018-04-08 17:40:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 17:40:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-04-08 17:40:01 --> mkdir(): File exists
ERROR - 2018-04-08 17:40:01 --> Severity: Warning --> mkdir(): File exists C:\xampp\htdocs\FlickNews\admin\application\controllers\News.php 879
INFO - 2018-04-08 14:10:01 --> Config Class Initialized
INFO - 2018-04-08 14:10:01 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:10:01 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:10:01 --> Utf8 Class Initialized
INFO - 2018-04-08 14:10:01 --> URI Class Initialized
INFO - 2018-04-08 14:10:01 --> Router Class Initialized
INFO - 2018-04-08 14:10:01 --> Output Class Initialized
INFO - 2018-04-08 14:10:01 --> Security Class Initialized
DEBUG - 2018-04-08 14:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:10:01 --> Input Class Initialized
INFO - 2018-04-08 14:10:01 --> Language Class Initialized
INFO - 2018-04-08 14:10:01 --> Loader Class Initialized
INFO - 2018-04-08 14:10:01 --> Helper loaded: common_helper
INFO - 2018-04-08 14:10:01 --> Database Driver Class Initialized
INFO - 2018-04-08 14:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:10:01 --> Email Class Initialized
INFO - 2018-04-08 14:10:01 --> Controller Class Initialized
INFO - 2018-04-08 14:10:01 --> Helper loaded: form_helper
INFO - 2018-04-08 14:10:01 --> Form Validation Class Initialized
INFO - 2018-04-08 14:10:01 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:10:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:10:01 --> Helper loaded: url_helper
INFO - 2018-04-08 14:10:01 --> Model Class Initialized
INFO - 2018-04-08 14:10:01 --> Model Class Initialized
INFO - 2018-04-08 14:10:01 --> Model Class Initialized
INFO - 2018-04-08 17:40:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:40:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:40:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:40:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movies.php
INFO - 2018-04-08 17:40:01 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:40:01 --> Final output sent to browser
DEBUG - 2018-04-08 17:40:01 --> Total execution time: 0.1250
INFO - 2018-04-08 14:10:12 --> Config Class Initialized
INFO - 2018-04-08 14:10:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:10:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:10:12 --> Utf8 Class Initialized
INFO - 2018-04-08 14:10:12 --> URI Class Initialized
INFO - 2018-04-08 14:10:12 --> Router Class Initialized
INFO - 2018-04-08 14:10:12 --> Output Class Initialized
INFO - 2018-04-08 14:10:12 --> Security Class Initialized
DEBUG - 2018-04-08 14:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:10:12 --> Input Class Initialized
INFO - 2018-04-08 14:10:12 --> Language Class Initialized
INFO - 2018-04-08 14:10:12 --> Loader Class Initialized
INFO - 2018-04-08 14:10:12 --> Helper loaded: common_helper
INFO - 2018-04-08 14:10:12 --> Database Driver Class Initialized
INFO - 2018-04-08 14:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:10:12 --> Email Class Initialized
INFO - 2018-04-08 14:10:12 --> Controller Class Initialized
INFO - 2018-04-08 14:10:12 --> Helper loaded: form_helper
INFO - 2018-04-08 14:10:12 --> Form Validation Class Initialized
INFO - 2018-04-08 14:10:12 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:10:12 --> Helper loaded: url_helper
INFO - 2018-04-08 14:10:12 --> Model Class Initialized
INFO - 2018-04-08 14:10:12 --> Model Class Initialized
INFO - 2018-04-08 14:10:12 --> Model Class Initialized
INFO - 2018-04-08 17:40:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:40:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:40:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:40:12 --> Undefined variable: ffs
ERROR - 2018-04-08 17:40:12 --> Severity: Notice --> Undefined variable: ffs C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieDetails.php 75
INFO - 2018-04-08 17:40:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieDetails.php
INFO - 2018-04-08 17:40:12 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:40:12 --> Final output sent to browser
DEBUG - 2018-04-08 17:40:12 --> Total execution time: 0.1370
INFO - 2018-04-08 14:10:16 --> Config Class Initialized
INFO - 2018-04-08 14:10:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:10:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:10:16 --> Utf8 Class Initialized
INFO - 2018-04-08 14:10:16 --> URI Class Initialized
INFO - 2018-04-08 14:10:16 --> Router Class Initialized
INFO - 2018-04-08 14:10:16 --> Output Class Initialized
INFO - 2018-04-08 14:10:16 --> Security Class Initialized
DEBUG - 2018-04-08 14:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:10:16 --> Input Class Initialized
INFO - 2018-04-08 14:10:16 --> Language Class Initialized
INFO - 2018-04-08 14:10:16 --> Loader Class Initialized
INFO - 2018-04-08 14:10:16 --> Helper loaded: common_helper
INFO - 2018-04-08 14:10:16 --> Database Driver Class Initialized
INFO - 2018-04-08 14:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:10:16 --> Email Class Initialized
INFO - 2018-04-08 14:10:16 --> Controller Class Initialized
INFO - 2018-04-08 14:10:16 --> Helper loaded: form_helper
INFO - 2018-04-08 14:10:16 --> Form Validation Class Initialized
INFO - 2018-04-08 14:10:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:10:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:10:16 --> Helper loaded: url_helper
INFO - 2018-04-08 14:10:16 --> Model Class Initialized
INFO - 2018-04-08 14:10:16 --> Model Class Initialized
INFO - 2018-04-08 14:10:16 --> Model Class Initialized
INFO - 2018-04-08 17:40:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:40:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:40:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:40:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:40:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:40:16 --> Final output sent to browser
DEBUG - 2018-04-08 17:40:16 --> Total execution time: 0.1280
INFO - 2018-04-08 14:12:33 --> Config Class Initialized
INFO - 2018-04-08 14:12:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:12:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:12:33 --> Utf8 Class Initialized
INFO - 2018-04-08 14:12:33 --> URI Class Initialized
INFO - 2018-04-08 14:12:33 --> Router Class Initialized
INFO - 2018-04-08 14:12:33 --> Output Class Initialized
INFO - 2018-04-08 14:12:33 --> Security Class Initialized
DEBUG - 2018-04-08 14:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:12:33 --> Input Class Initialized
INFO - 2018-04-08 14:12:33 --> Language Class Initialized
INFO - 2018-04-08 14:12:33 --> Loader Class Initialized
INFO - 2018-04-08 14:12:33 --> Helper loaded: common_helper
INFO - 2018-04-08 14:12:33 --> Database Driver Class Initialized
INFO - 2018-04-08 14:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:12:33 --> Email Class Initialized
INFO - 2018-04-08 14:12:33 --> Controller Class Initialized
INFO - 2018-04-08 14:12:33 --> Helper loaded: form_helper
INFO - 2018-04-08 14:12:33 --> Form Validation Class Initialized
INFO - 2018-04-08 14:12:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:12:33 --> Helper loaded: url_helper
INFO - 2018-04-08 14:12:33 --> Model Class Initialized
INFO - 2018-04-08 14:12:33 --> Model Class Initialized
INFO - 2018-04-08 14:12:33 --> Model Class Initialized
INFO - 2018-04-08 17:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:42:33 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:42:33 --> Final output sent to browser
DEBUG - 2018-04-08 17:42:33 --> Total execution time: 0.1320
INFO - 2018-04-08 14:13:53 --> Config Class Initialized
INFO - 2018-04-08 14:13:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:13:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:13:53 --> Utf8 Class Initialized
INFO - 2018-04-08 14:13:53 --> URI Class Initialized
INFO - 2018-04-08 14:13:53 --> Router Class Initialized
INFO - 2018-04-08 14:13:53 --> Output Class Initialized
INFO - 2018-04-08 14:13:53 --> Security Class Initialized
DEBUG - 2018-04-08 14:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:13:53 --> Input Class Initialized
INFO - 2018-04-08 14:13:53 --> Language Class Initialized
INFO - 2018-04-08 14:13:53 --> Loader Class Initialized
INFO - 2018-04-08 14:13:53 --> Helper loaded: common_helper
INFO - 2018-04-08 14:13:53 --> Database Driver Class Initialized
INFO - 2018-04-08 14:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:13:53 --> Email Class Initialized
INFO - 2018-04-08 14:13:53 --> Controller Class Initialized
INFO - 2018-04-08 14:13:53 --> Helper loaded: form_helper
INFO - 2018-04-08 14:13:53 --> Form Validation Class Initialized
INFO - 2018-04-08 14:13:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:13:53 --> Helper loaded: url_helper
INFO - 2018-04-08 14:13:53 --> Model Class Initialized
INFO - 2018-04-08 14:13:53 --> Model Class Initialized
INFO - 2018-04-08 14:13:53 --> Model Class Initialized
ERROR - 2018-04-08 17:43:53 --> Undefined variable: newsTitle
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: newsTitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
ERROR - 2018-04-08 17:43:53 --> Trying to get property of non-object
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
ERROR - 2018-04-08 17:43:53 --> Undefined variable: newsTitle
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: newsTitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
ERROR - 2018-04-08 17:43:53 --> Trying to get property of non-object
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:43:53 --> Invalid argument supplied for foreach()
ERROR - 2018-04-08 17:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 68
ERROR - 2018-04-08 17:43:53 --> Undefined variable: Image
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: Image C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
ERROR - 2018-04-08 17:43:53 --> Invalid argument supplied for foreach()
ERROR - 2018-04-08 17:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 68
ERROR - 2018-04-08 17:43:53 --> Undefined variable: Image
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: Image C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:43:53 --> Final output sent to browser
DEBUG - 2018-04-08 17:43:53 --> Total execution time: 0.1930
INFO - 2018-04-08 14:13:53 --> Config Class Initialized
INFO - 2018-04-08 14:13:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:13:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:13:53 --> Utf8 Class Initialized
INFO - 2018-04-08 14:13:53 --> URI Class Initialized
INFO - 2018-04-08 14:13:53 --> Router Class Initialized
INFO - 2018-04-08 14:13:53 --> Output Class Initialized
INFO - 2018-04-08 14:13:53 --> Security Class Initialized
DEBUG - 2018-04-08 14:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:13:53 --> Input Class Initialized
INFO - 2018-04-08 14:13:53 --> Language Class Initialized
INFO - 2018-04-08 14:13:53 --> Loader Class Initialized
INFO - 2018-04-08 14:13:53 --> Helper loaded: common_helper
INFO - 2018-04-08 14:13:53 --> Database Driver Class Initialized
INFO - 2018-04-08 14:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:13:53 --> Email Class Initialized
INFO - 2018-04-08 14:13:53 --> Controller Class Initialized
INFO - 2018-04-08 14:13:53 --> Helper loaded: form_helper
INFO - 2018-04-08 14:13:53 --> Form Validation Class Initialized
INFO - 2018-04-08 14:13:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:13:53 --> Helper loaded: url_helper
INFO - 2018-04-08 14:13:53 --> Model Class Initialized
INFO - 2018-04-08 14:13:53 --> Model Class Initialized
INFO - 2018-04-08 14:13:53 --> Model Class Initialized
ERROR - 2018-04-08 17:43:53 --> Undefined variable: newsTitle
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: newsTitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
ERROR - 2018-04-08 17:43:53 --> Trying to get property of non-object
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
ERROR - 2018-04-08 17:43:53 --> Undefined variable: newsTitle
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: newsTitle C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
ERROR - 2018-04-08 17:43:53 --> Trying to get property of non-object
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 277
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
ERROR - 2018-04-08 17:43:53 --> Invalid argument supplied for foreach()
ERROR - 2018-04-08 17:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 68
ERROR - 2018-04-08 17:43:53 --> Undefined variable: Image
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: Image C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
ERROR - 2018-04-08 17:43:53 --> Invalid argument supplied for foreach()
ERROR - 2018-04-08 17:43:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 68
ERROR - 2018-04-08 17:43:53 --> Undefined variable: Image
ERROR - 2018-04-08 17:43:53 --> Severity: Notice --> Undefined variable: Image C:\xampp\htdocs\FlickNews\admin\application\views\Movies\movieImageDetails.php 70
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:43:53 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:43:53 --> Final output sent to browser
DEBUG - 2018-04-08 17:43:53 --> Total execution time: 0.1430
INFO - 2018-04-08 14:14:13 --> Config Class Initialized
INFO - 2018-04-08 14:14:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:14:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:14:13 --> Utf8 Class Initialized
INFO - 2018-04-08 14:14:13 --> URI Class Initialized
INFO - 2018-04-08 14:14:13 --> Router Class Initialized
INFO - 2018-04-08 14:14:13 --> Output Class Initialized
INFO - 2018-04-08 14:14:13 --> Security Class Initialized
DEBUG - 2018-04-08 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:14:13 --> Input Class Initialized
INFO - 2018-04-08 14:14:13 --> Language Class Initialized
INFO - 2018-04-08 14:14:13 --> Loader Class Initialized
INFO - 2018-04-08 14:14:13 --> Helper loaded: common_helper
INFO - 2018-04-08 14:14:13 --> Database Driver Class Initialized
INFO - 2018-04-08 14:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:14:13 --> Email Class Initialized
INFO - 2018-04-08 14:14:13 --> Controller Class Initialized
INFO - 2018-04-08 14:14:13 --> Helper loaded: form_helper
INFO - 2018-04-08 14:14:13 --> Form Validation Class Initialized
INFO - 2018-04-08 14:14:13 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:14:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:14:13 --> Helper loaded: url_helper
INFO - 2018-04-08 14:14:13 --> Model Class Initialized
INFO - 2018-04-08 14:14:13 --> Model Class Initialized
INFO - 2018-04-08 14:14:13 --> Model Class Initialized
INFO - 2018-04-08 17:44:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:44:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:44:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:44:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:44:13 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:44:13 --> Final output sent to browser
DEBUG - 2018-04-08 17:44:13 --> Total execution time: 0.1320
INFO - 2018-04-08 14:14:19 --> Config Class Initialized
INFO - 2018-04-08 14:14:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:14:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:14:19 --> Utf8 Class Initialized
INFO - 2018-04-08 14:14:19 --> URI Class Initialized
INFO - 2018-04-08 14:14:19 --> Router Class Initialized
INFO - 2018-04-08 14:14:19 --> Output Class Initialized
INFO - 2018-04-08 14:14:19 --> Security Class Initialized
DEBUG - 2018-04-08 14:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:14:19 --> Input Class Initialized
INFO - 2018-04-08 14:14:19 --> Language Class Initialized
INFO - 2018-04-08 14:14:19 --> Loader Class Initialized
INFO - 2018-04-08 14:14:19 --> Helper loaded: common_helper
INFO - 2018-04-08 14:14:19 --> Database Driver Class Initialized
INFO - 2018-04-08 14:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:14:19 --> Email Class Initialized
INFO - 2018-04-08 14:14:19 --> Controller Class Initialized
INFO - 2018-04-08 14:14:19 --> Helper loaded: form_helper
INFO - 2018-04-08 14:14:19 --> Form Validation Class Initialized
INFO - 2018-04-08 14:14:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:14:19 --> Helper loaded: url_helper
INFO - 2018-04-08 14:14:19 --> Model Class Initialized
INFO - 2018-04-08 14:14:19 --> Model Class Initialized
INFO - 2018-04-08 14:14:19 --> Model Class Initialized
INFO - 2018-04-08 17:44:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:44:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:44:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:44:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:44:19 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:44:19 --> Final output sent to browser
DEBUG - 2018-04-08 17:44:19 --> Total execution time: 0.1230
INFO - 2018-04-08 14:15:16 --> Config Class Initialized
INFO - 2018-04-08 14:15:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:15:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:15:16 --> Utf8 Class Initialized
INFO - 2018-04-08 14:15:16 --> URI Class Initialized
INFO - 2018-04-08 14:15:16 --> Router Class Initialized
INFO - 2018-04-08 14:15:16 --> Output Class Initialized
INFO - 2018-04-08 14:15:16 --> Security Class Initialized
DEBUG - 2018-04-08 14:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:15:16 --> Input Class Initialized
INFO - 2018-04-08 14:15:16 --> Language Class Initialized
INFO - 2018-04-08 14:15:16 --> Loader Class Initialized
INFO - 2018-04-08 14:15:16 --> Helper loaded: common_helper
INFO - 2018-04-08 14:15:16 --> Database Driver Class Initialized
INFO - 2018-04-08 14:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:15:16 --> Email Class Initialized
INFO - 2018-04-08 14:15:16 --> Controller Class Initialized
INFO - 2018-04-08 14:15:16 --> Helper loaded: form_helper
INFO - 2018-04-08 14:15:16 --> Form Validation Class Initialized
INFO - 2018-04-08 14:15:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:15:16 --> Helper loaded: url_helper
INFO - 2018-04-08 14:15:16 --> Model Class Initialized
INFO - 2018-04-08 14:15:16 --> Model Class Initialized
INFO - 2018-04-08 14:15:16 --> Model Class Initialized
ERROR - 2018-04-08 17:45:16 --> Cannot use object of type stdClass as array
ERROR - 2018-04-08 17:45:16 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\FlickNews\admin\application\controllers\Movie.php 278
INFO - 2018-04-08 14:16:16 --> Config Class Initialized
INFO - 2018-04-08 14:16:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 14:16:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 14:16:16 --> Utf8 Class Initialized
INFO - 2018-04-08 14:16:16 --> URI Class Initialized
INFO - 2018-04-08 14:16:16 --> Router Class Initialized
INFO - 2018-04-08 14:16:16 --> Output Class Initialized
INFO - 2018-04-08 14:16:16 --> Security Class Initialized
DEBUG - 2018-04-08 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 14:16:16 --> Input Class Initialized
INFO - 2018-04-08 14:16:16 --> Language Class Initialized
INFO - 2018-04-08 14:16:16 --> Loader Class Initialized
INFO - 2018-04-08 14:16:16 --> Helper loaded: common_helper
INFO - 2018-04-08 14:16:16 --> Database Driver Class Initialized
INFO - 2018-04-08 14:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 14:16:16 --> Email Class Initialized
INFO - 2018-04-08 14:16:16 --> Controller Class Initialized
INFO - 2018-04-08 14:16:16 --> Helper loaded: form_helper
INFO - 2018-04-08 14:16:16 --> Form Validation Class Initialized
INFO - 2018-04-08 14:16:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 14:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 14:16:16 --> Helper loaded: url_helper
INFO - 2018-04-08 14:16:16 --> Model Class Initialized
INFO - 2018-04-08 14:16:16 --> Model Class Initialized
INFO - 2018-04-08 14:16:16 --> Model Class Initialized
INFO - 2018-04-08 17:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 17:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 17:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\scripts.php
INFO - 2018-04-08 17:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\Movies/movieImageDetails.php
INFO - 2018-04-08 17:46:16 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 17:46:16 --> Final output sent to browser
DEBUG - 2018-04-08 17:46:16 --> Total execution time: 0.1310
INFO - 2018-04-08 20:42:12 --> Config Class Initialized
INFO - 2018-04-08 20:42:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:12 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:12 --> URI Class Initialized
INFO - 2018-04-08 20:42:12 --> Router Class Initialized
INFO - 2018-04-08 20:42:12 --> Output Class Initialized
INFO - 2018-04-08 20:42:12 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:12 --> Input Class Initialized
INFO - 2018-04-08 20:42:12 --> Language Class Initialized
INFO - 2018-04-08 20:42:12 --> Loader Class Initialized
INFO - 2018-04-08 20:42:12 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:12 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:12 --> Email Class Initialized
INFO - 2018-04-08 20:42:12 --> Controller Class Initialized
INFO - 2018-04-08 20:42:12 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:12 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:12 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:12 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:12 --> Model Class Initialized
INFO - 2018-04-08 20:42:12 --> Model Class Initialized
INFO - 2018-04-08 20:42:12 --> Model Class Initialized
INFO - 2018-04-08 20:42:15 --> Config Class Initialized
INFO - 2018-04-08 20:42:15 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:15 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:15 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:15 --> URI Class Initialized
INFO - 2018-04-08 20:42:15 --> Router Class Initialized
INFO - 2018-04-08 20:42:15 --> Output Class Initialized
INFO - 2018-04-08 20:42:15 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:15 --> Input Class Initialized
INFO - 2018-04-08 20:42:15 --> Language Class Initialized
INFO - 2018-04-08 20:42:15 --> Loader Class Initialized
INFO - 2018-04-08 20:42:15 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:15 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:15 --> Email Class Initialized
INFO - 2018-04-08 20:42:15 --> Controller Class Initialized
INFO - 2018-04-08 20:42:15 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:15 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:15 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:15 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:15 --> Model Class Initialized
INFO - 2018-04-08 20:42:15 --> Model Class Initialized
INFO - 2018-04-08 20:42:15 --> Model Class Initialized
INFO - 2018-04-08 20:42:17 --> Config Class Initialized
INFO - 2018-04-08 20:42:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:17 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:17 --> URI Class Initialized
INFO - 2018-04-08 20:42:17 --> Router Class Initialized
INFO - 2018-04-08 20:42:17 --> Output Class Initialized
INFO - 2018-04-08 20:42:17 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:17 --> Input Class Initialized
INFO - 2018-04-08 20:42:17 --> Language Class Initialized
INFO - 2018-04-08 20:42:17 --> Loader Class Initialized
INFO - 2018-04-08 20:42:17 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:17 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:17 --> Email Class Initialized
INFO - 2018-04-08 20:42:17 --> Controller Class Initialized
INFO - 2018-04-08 20:42:17 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:17 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:17 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:17 --> Model Class Initialized
INFO - 2018-04-08 20:42:17 --> Model Class Initialized
INFO - 2018-04-08 20:42:17 --> Model Class Initialized
INFO - 2018-04-08 20:42:39 --> Config Class Initialized
INFO - 2018-04-08 20:42:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:39 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:39 --> URI Class Initialized
INFO - 2018-04-08 20:42:39 --> Router Class Initialized
INFO - 2018-04-08 20:42:39 --> Output Class Initialized
INFO - 2018-04-08 20:42:39 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:39 --> Input Class Initialized
INFO - 2018-04-08 20:42:39 --> Language Class Initialized
INFO - 2018-04-08 20:42:39 --> Loader Class Initialized
INFO - 2018-04-08 20:42:39 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:39 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:40 --> Email Class Initialized
INFO - 2018-04-08 20:42:40 --> Controller Class Initialized
INFO - 2018-04-08 20:42:40 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:40 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:40 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:40 --> Model Class Initialized
INFO - 2018-04-08 20:42:40 --> Model Class Initialized
INFO - 2018-04-08 20:42:40 --> Model Class Initialized
INFO - 2018-04-08 20:42:50 --> Config Class Initialized
INFO - 2018-04-08 20:42:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:50 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:50 --> URI Class Initialized
INFO - 2018-04-08 20:42:50 --> Router Class Initialized
INFO - 2018-04-08 20:42:50 --> Output Class Initialized
INFO - 2018-04-08 20:42:50 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:50 --> Input Class Initialized
INFO - 2018-04-08 20:42:50 --> Language Class Initialized
INFO - 2018-04-08 20:42:50 --> Loader Class Initialized
INFO - 2018-04-08 20:42:50 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:50 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:50 --> Email Class Initialized
INFO - 2018-04-08 20:42:50 --> Controller Class Initialized
INFO - 2018-04-08 20:42:50 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:50 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:50 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:50 --> Model Class Initialized
INFO - 2018-04-08 20:42:50 --> Model Class Initialized
INFO - 2018-04-08 20:42:50 --> Model Class Initialized
INFO - 2018-04-08 20:42:55 --> Config Class Initialized
INFO - 2018-04-08 20:42:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:55 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:55 --> URI Class Initialized
INFO - 2018-04-08 20:42:55 --> Router Class Initialized
INFO - 2018-04-08 20:42:55 --> Output Class Initialized
INFO - 2018-04-08 20:42:55 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:55 --> Input Class Initialized
INFO - 2018-04-08 20:42:55 --> Language Class Initialized
INFO - 2018-04-08 20:42:55 --> Loader Class Initialized
INFO - 2018-04-08 20:42:55 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:55 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:55 --> Email Class Initialized
INFO - 2018-04-08 20:42:55 --> Controller Class Initialized
INFO - 2018-04-08 20:42:55 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:55 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:55 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:55 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:55 --> Model Class Initialized
INFO - 2018-04-08 20:42:55 --> Model Class Initialized
INFO - 2018-04-08 20:42:55 --> Model Class Initialized
INFO - 2018-04-08 20:42:59 --> Config Class Initialized
INFO - 2018-04-08 20:42:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:42:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:42:59 --> Utf8 Class Initialized
INFO - 2018-04-08 20:42:59 --> URI Class Initialized
INFO - 2018-04-08 20:42:59 --> Router Class Initialized
INFO - 2018-04-08 20:42:59 --> Output Class Initialized
INFO - 2018-04-08 20:42:59 --> Security Class Initialized
DEBUG - 2018-04-08 20:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:42:59 --> Input Class Initialized
INFO - 2018-04-08 20:42:59 --> Language Class Initialized
INFO - 2018-04-08 20:42:59 --> Loader Class Initialized
INFO - 2018-04-08 20:42:59 --> Helper loaded: common_helper
INFO - 2018-04-08 20:42:59 --> Database Driver Class Initialized
INFO - 2018-04-08 20:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:42:59 --> Email Class Initialized
INFO - 2018-04-08 20:42:59 --> Controller Class Initialized
INFO - 2018-04-08 20:42:59 --> Helper loaded: form_helper
INFO - 2018-04-08 20:42:59 --> Form Validation Class Initialized
INFO - 2018-04-08 20:42:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:42:59 --> Helper loaded: url_helper
INFO - 2018-04-08 20:42:59 --> Model Class Initialized
INFO - 2018-04-08 20:42:59 --> Model Class Initialized
INFO - 2018-04-08 20:42:59 --> Model Class Initialized
INFO - 2018-04-08 20:43:03 --> Config Class Initialized
INFO - 2018-04-08 20:43:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:03 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:03 --> URI Class Initialized
INFO - 2018-04-08 20:43:03 --> Router Class Initialized
INFO - 2018-04-08 20:43:03 --> Output Class Initialized
INFO - 2018-04-08 20:43:03 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:03 --> Input Class Initialized
INFO - 2018-04-08 20:43:03 --> Language Class Initialized
INFO - 2018-04-08 20:43:03 --> Loader Class Initialized
INFO - 2018-04-08 20:43:03 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:03 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:03 --> Email Class Initialized
INFO - 2018-04-08 20:43:03 --> Controller Class Initialized
INFO - 2018-04-08 20:43:03 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:03 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:03 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:03 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:03 --> Model Class Initialized
INFO - 2018-04-08 20:43:03 --> Model Class Initialized
INFO - 2018-04-08 20:43:03 --> Model Class Initialized
INFO - 2018-04-08 20:43:06 --> Config Class Initialized
INFO - 2018-04-08 20:43:06 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:06 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:06 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:06 --> URI Class Initialized
INFO - 2018-04-08 20:43:06 --> Router Class Initialized
INFO - 2018-04-08 20:43:06 --> Output Class Initialized
INFO - 2018-04-08 20:43:06 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:06 --> Input Class Initialized
INFO - 2018-04-08 20:43:06 --> Language Class Initialized
INFO - 2018-04-08 20:43:06 --> Loader Class Initialized
INFO - 2018-04-08 20:43:06 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:06 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:06 --> Email Class Initialized
INFO - 2018-04-08 20:43:06 --> Controller Class Initialized
INFO - 2018-04-08 20:43:06 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:06 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:06 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:06 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:06 --> Model Class Initialized
INFO - 2018-04-08 20:43:06 --> Model Class Initialized
INFO - 2018-04-08 20:43:06 --> Model Class Initialized
INFO - 2018-04-08 20:43:08 --> Config Class Initialized
INFO - 2018-04-08 20:43:08 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:08 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:08 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:08 --> URI Class Initialized
INFO - 2018-04-08 20:43:08 --> Router Class Initialized
INFO - 2018-04-08 20:43:08 --> Output Class Initialized
INFO - 2018-04-08 20:43:08 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:08 --> Input Class Initialized
INFO - 2018-04-08 20:43:08 --> Language Class Initialized
INFO - 2018-04-08 20:43:08 --> Loader Class Initialized
INFO - 2018-04-08 20:43:08 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:08 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:08 --> Email Class Initialized
INFO - 2018-04-08 20:43:08 --> Controller Class Initialized
INFO - 2018-04-08 20:43:08 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:08 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:08 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:08 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:08 --> Model Class Initialized
INFO - 2018-04-08 20:43:08 --> Model Class Initialized
INFO - 2018-04-08 20:43:08 --> Model Class Initialized
INFO - 2018-04-08 20:43:14 --> Config Class Initialized
INFO - 2018-04-08 20:43:14 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:14 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:14 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:14 --> URI Class Initialized
INFO - 2018-04-08 20:43:14 --> Router Class Initialized
INFO - 2018-04-08 20:43:14 --> Output Class Initialized
INFO - 2018-04-08 20:43:14 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:14 --> Input Class Initialized
INFO - 2018-04-08 20:43:14 --> Language Class Initialized
INFO - 2018-04-08 20:43:14 --> Loader Class Initialized
INFO - 2018-04-08 20:43:14 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:14 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:14 --> Email Class Initialized
INFO - 2018-04-08 20:43:14 --> Controller Class Initialized
INFO - 2018-04-08 20:43:14 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:14 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:14 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:14 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:14 --> Model Class Initialized
INFO - 2018-04-08 20:43:14 --> Model Class Initialized
INFO - 2018-04-08 20:43:14 --> Model Class Initialized
INFO - 2018-04-08 20:43:17 --> Config Class Initialized
INFO - 2018-04-08 20:43:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:17 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:17 --> URI Class Initialized
INFO - 2018-04-08 20:43:17 --> Router Class Initialized
INFO - 2018-04-08 20:43:17 --> Output Class Initialized
INFO - 2018-04-08 20:43:17 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:17 --> Input Class Initialized
INFO - 2018-04-08 20:43:17 --> Language Class Initialized
INFO - 2018-04-08 20:43:17 --> Loader Class Initialized
INFO - 2018-04-08 20:43:17 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:17 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:17 --> Email Class Initialized
INFO - 2018-04-08 20:43:17 --> Controller Class Initialized
INFO - 2018-04-08 20:43:17 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:17 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:17 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:17 --> Model Class Initialized
INFO - 2018-04-08 20:43:17 --> Model Class Initialized
INFO - 2018-04-08 20:43:17 --> Model Class Initialized
INFO - 2018-04-08 20:43:19 --> Config Class Initialized
INFO - 2018-04-08 20:43:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:19 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:19 --> URI Class Initialized
INFO - 2018-04-08 20:43:19 --> Router Class Initialized
INFO - 2018-04-08 20:43:19 --> Output Class Initialized
INFO - 2018-04-08 20:43:19 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:19 --> Input Class Initialized
INFO - 2018-04-08 20:43:19 --> Language Class Initialized
INFO - 2018-04-08 20:43:19 --> Loader Class Initialized
INFO - 2018-04-08 20:43:19 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:19 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:19 --> Email Class Initialized
INFO - 2018-04-08 20:43:19 --> Controller Class Initialized
INFO - 2018-04-08 20:43:19 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:19 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:19 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:19 --> Model Class Initialized
INFO - 2018-04-08 20:43:19 --> Model Class Initialized
INFO - 2018-04-08 20:43:19 --> Model Class Initialized
INFO - 2018-04-08 20:43:20 --> Config Class Initialized
INFO - 2018-04-08 20:43:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:20 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:20 --> URI Class Initialized
INFO - 2018-04-08 20:43:20 --> Router Class Initialized
INFO - 2018-04-08 20:43:20 --> Output Class Initialized
INFO - 2018-04-08 20:43:20 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:20 --> Input Class Initialized
INFO - 2018-04-08 20:43:20 --> Language Class Initialized
INFO - 2018-04-08 20:43:20 --> Loader Class Initialized
INFO - 2018-04-08 20:43:20 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:20 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:20 --> Email Class Initialized
INFO - 2018-04-08 20:43:20 --> Controller Class Initialized
INFO - 2018-04-08 20:43:20 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:20 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:20 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:20 --> Model Class Initialized
INFO - 2018-04-08 20:43:20 --> Model Class Initialized
INFO - 2018-04-08 20:43:20 --> Config Class Initialized
INFO - 2018-04-08 20:43:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:20 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:20 --> URI Class Initialized
DEBUG - 2018-04-08 20:43:20 --> No URI present. Default controller set.
INFO - 2018-04-08 20:43:20 --> Router Class Initialized
INFO - 2018-04-08 20:43:20 --> Output Class Initialized
INFO - 2018-04-08 20:43:20 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:20 --> Input Class Initialized
INFO - 2018-04-08 20:43:20 --> Language Class Initialized
INFO - 2018-04-08 20:43:20 --> Loader Class Initialized
INFO - 2018-04-08 20:43:20 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:20 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:20 --> Email Class Initialized
INFO - 2018-04-08 20:43:20 --> Controller Class Initialized
INFO - 2018-04-08 20:43:20 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:20 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:20 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:20 --> Model Class Initialized
INFO - 2018-04-08 20:43:20 --> Model Class Initialized
INFO - 2018-04-08 20:43:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\index.php
INFO - 2018-04-08 20:43:20 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 20:43:20 --> Final output sent to browser
DEBUG - 2018-04-08 20:43:20 --> Total execution time: 0.1120
INFO - 2018-04-08 20:43:22 --> Config Class Initialized
INFO - 2018-04-08 20:43:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:22 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:22 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:22 --> URI Class Initialized
DEBUG - 2018-04-08 20:43:22 --> No URI present. Default controller set.
INFO - 2018-04-08 20:43:22 --> Router Class Initialized
INFO - 2018-04-08 20:43:22 --> Output Class Initialized
INFO - 2018-04-08 20:43:22 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:22 --> Input Class Initialized
INFO - 2018-04-08 20:43:22 --> Language Class Initialized
INFO - 2018-04-08 20:43:22 --> Loader Class Initialized
INFO - 2018-04-08 20:43:22 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:22 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:22 --> Email Class Initialized
INFO - 2018-04-08 20:43:22 --> Controller Class Initialized
INFO - 2018-04-08 20:43:22 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:22 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:22 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:22 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:22 --> Model Class Initialized
INFO - 2018-04-08 20:43:22 --> Model Class Initialized
DEBUG - 2018-04-08 20:43:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-08 20:43:22 --> Config Class Initialized
INFO - 2018-04-08 20:43:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:22 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:22 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:22 --> URI Class Initialized
INFO - 2018-04-08 20:43:22 --> Router Class Initialized
INFO - 2018-04-08 20:43:22 --> Output Class Initialized
INFO - 2018-04-08 20:43:22 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:22 --> Input Class Initialized
INFO - 2018-04-08 20:43:22 --> Language Class Initialized
INFO - 2018-04-08 20:43:22 --> Loader Class Initialized
INFO - 2018-04-08 20:43:22 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:22 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:22 --> Email Class Initialized
INFO - 2018-04-08 20:43:22 --> Controller Class Initialized
INFO - 2018-04-08 20:43:22 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:22 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:22 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:22 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:22 --> Model Class Initialized
INFO - 2018-04-08 20:43:22 --> Model Class Initialized
INFO - 2018-04-08 20:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\header.php
INFO - 2018-04-08 20:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\sideMenu.php
INFO - 2018-04-08 20:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\dashboard.php
INFO - 2018-04-08 20:43:22 --> File loaded: C:\xampp\htdocs\FlickNews\admin\application\views\footer.php
INFO - 2018-04-08 20:43:22 --> Final output sent to browser
DEBUG - 2018-04-08 20:43:22 --> Total execution time: 0.0670
INFO - 2018-04-08 20:43:26 --> Config Class Initialized
INFO - 2018-04-08 20:43:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:26 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:26 --> URI Class Initialized
INFO - 2018-04-08 20:43:26 --> Router Class Initialized
INFO - 2018-04-08 20:43:26 --> Output Class Initialized
INFO - 2018-04-08 20:43:26 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:26 --> Input Class Initialized
INFO - 2018-04-08 20:43:26 --> Language Class Initialized
INFO - 2018-04-08 20:43:26 --> Loader Class Initialized
INFO - 2018-04-08 20:43:26 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:26 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:26 --> Email Class Initialized
INFO - 2018-04-08 20:43:26 --> Controller Class Initialized
INFO - 2018-04-08 20:43:26 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:26 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:26 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:26 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:26 --> Model Class Initialized
INFO - 2018-04-08 20:43:26 --> Model Class Initialized
INFO - 2018-04-08 20:43:26 --> Model Class Initialized
INFO - 2018-04-08 20:43:37 --> Config Class Initialized
INFO - 2018-04-08 20:43:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:37 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:37 --> URI Class Initialized
INFO - 2018-04-08 20:43:37 --> Router Class Initialized
INFO - 2018-04-08 20:43:37 --> Output Class Initialized
INFO - 2018-04-08 20:43:37 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:37 --> Input Class Initialized
INFO - 2018-04-08 20:43:37 --> Language Class Initialized
INFO - 2018-04-08 20:43:37 --> Loader Class Initialized
INFO - 2018-04-08 20:43:37 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:37 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:37 --> Email Class Initialized
INFO - 2018-04-08 20:43:37 --> Controller Class Initialized
INFO - 2018-04-08 20:43:37 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:37 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:37 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:37 --> Model Class Initialized
INFO - 2018-04-08 20:43:37 --> Model Class Initialized
INFO - 2018-04-08 20:43:37 --> Model Class Initialized
INFO - 2018-04-08 20:43:41 --> Config Class Initialized
INFO - 2018-04-08 20:43:41 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:41 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:41 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:41 --> URI Class Initialized
INFO - 2018-04-08 20:43:41 --> Router Class Initialized
INFO - 2018-04-08 20:43:41 --> Output Class Initialized
INFO - 2018-04-08 20:43:41 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:41 --> Input Class Initialized
INFO - 2018-04-08 20:43:41 --> Language Class Initialized
INFO - 2018-04-08 20:43:41 --> Loader Class Initialized
INFO - 2018-04-08 20:43:41 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:41 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:41 --> Email Class Initialized
INFO - 2018-04-08 20:43:41 --> Controller Class Initialized
INFO - 2018-04-08 20:43:41 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:41 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:41 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:41 --> Model Class Initialized
INFO - 2018-04-08 20:43:41 --> Model Class Initialized
INFO - 2018-04-08 20:43:41 --> Model Class Initialized
INFO - 2018-04-08 20:43:45 --> Config Class Initialized
INFO - 2018-04-08 20:43:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:45 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:45 --> URI Class Initialized
INFO - 2018-04-08 20:43:45 --> Router Class Initialized
INFO - 2018-04-08 20:43:45 --> Output Class Initialized
INFO - 2018-04-08 20:43:45 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:45 --> Input Class Initialized
INFO - 2018-04-08 20:43:45 --> Language Class Initialized
INFO - 2018-04-08 20:43:45 --> Loader Class Initialized
INFO - 2018-04-08 20:43:45 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:45 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:45 --> Email Class Initialized
INFO - 2018-04-08 20:43:45 --> Controller Class Initialized
INFO - 2018-04-08 20:43:45 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:45 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:45 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:45 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:45 --> Model Class Initialized
INFO - 2018-04-08 20:43:45 --> Model Class Initialized
INFO - 2018-04-08 20:43:45 --> Model Class Initialized
INFO - 2018-04-08 20:43:47 --> Config Class Initialized
INFO - 2018-04-08 20:43:47 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:47 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:47 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:47 --> URI Class Initialized
INFO - 2018-04-08 20:43:47 --> Router Class Initialized
INFO - 2018-04-08 20:43:47 --> Output Class Initialized
INFO - 2018-04-08 20:43:47 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:47 --> Input Class Initialized
INFO - 2018-04-08 20:43:47 --> Language Class Initialized
INFO - 2018-04-08 20:43:47 --> Loader Class Initialized
INFO - 2018-04-08 20:43:47 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:47 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:47 --> Email Class Initialized
INFO - 2018-04-08 20:43:47 --> Controller Class Initialized
INFO - 2018-04-08 20:43:47 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:47 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:47 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:47 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:47 --> Model Class Initialized
INFO - 2018-04-08 20:43:47 --> Model Class Initialized
INFO - 2018-04-08 20:43:48 --> Model Class Initialized
INFO - 2018-04-08 20:43:50 --> Config Class Initialized
INFO - 2018-04-08 20:43:50 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:43:50 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:43:50 --> Utf8 Class Initialized
INFO - 2018-04-08 20:43:50 --> URI Class Initialized
INFO - 2018-04-08 20:43:50 --> Router Class Initialized
INFO - 2018-04-08 20:43:50 --> Output Class Initialized
INFO - 2018-04-08 20:43:50 --> Security Class Initialized
DEBUG - 2018-04-08 20:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:43:50 --> Input Class Initialized
INFO - 2018-04-08 20:43:50 --> Language Class Initialized
INFO - 2018-04-08 20:43:50 --> Loader Class Initialized
INFO - 2018-04-08 20:43:50 --> Helper loaded: common_helper
INFO - 2018-04-08 20:43:50 --> Database Driver Class Initialized
INFO - 2018-04-08 20:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:43:50 --> Email Class Initialized
INFO - 2018-04-08 20:43:50 --> Controller Class Initialized
INFO - 2018-04-08 20:43:50 --> Helper loaded: form_helper
INFO - 2018-04-08 20:43:50 --> Form Validation Class Initialized
INFO - 2018-04-08 20:43:50 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:43:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:43:50 --> Helper loaded: url_helper
INFO - 2018-04-08 20:43:50 --> Model Class Initialized
INFO - 2018-04-08 20:43:50 --> Model Class Initialized
INFO - 2018-04-08 20:43:50 --> Model Class Initialized
INFO - 2018-04-08 20:44:23 --> Config Class Initialized
INFO - 2018-04-08 20:44:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:44:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:44:23 --> Utf8 Class Initialized
INFO - 2018-04-08 20:44:23 --> URI Class Initialized
INFO - 2018-04-08 20:44:23 --> Router Class Initialized
INFO - 2018-04-08 20:44:23 --> Output Class Initialized
INFO - 2018-04-08 20:44:23 --> Security Class Initialized
DEBUG - 2018-04-08 20:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:44:23 --> Input Class Initialized
INFO - 2018-04-08 20:44:23 --> Language Class Initialized
INFO - 2018-04-08 20:44:23 --> Loader Class Initialized
INFO - 2018-04-08 20:44:23 --> Helper loaded: common_helper
INFO - 2018-04-08 20:44:24 --> Database Driver Class Initialized
INFO - 2018-04-08 20:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:44:24 --> Email Class Initialized
INFO - 2018-04-08 20:44:24 --> Controller Class Initialized
INFO - 2018-04-08 20:44:24 --> Helper loaded: form_helper
INFO - 2018-04-08 20:44:24 --> Form Validation Class Initialized
INFO - 2018-04-08 20:44:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:44:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:44:24 --> Helper loaded: url_helper
INFO - 2018-04-08 20:44:24 --> Model Class Initialized
INFO - 2018-04-08 20:44:24 --> Model Class Initialized
INFO - 2018-04-08 20:44:24 --> Model Class Initialized
INFO - 2018-04-08 20:48:44 --> Config Class Initialized
INFO - 2018-04-08 20:48:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:48:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:48:44 --> Utf8 Class Initialized
INFO - 2018-04-08 20:48:44 --> URI Class Initialized
INFO - 2018-04-08 20:48:44 --> Router Class Initialized
INFO - 2018-04-08 20:48:44 --> Output Class Initialized
INFO - 2018-04-08 20:48:44 --> Security Class Initialized
DEBUG - 2018-04-08 20:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:48:44 --> Input Class Initialized
INFO - 2018-04-08 20:48:44 --> Language Class Initialized
INFO - 2018-04-08 20:48:44 --> Loader Class Initialized
INFO - 2018-04-08 20:48:44 --> Helper loaded: common_helper
INFO - 2018-04-08 20:48:44 --> Database Driver Class Initialized
INFO - 2018-04-08 20:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:48:44 --> Email Class Initialized
INFO - 2018-04-08 20:48:44 --> Controller Class Initialized
INFO - 2018-04-08 20:48:44 --> Helper loaded: form_helper
INFO - 2018-04-08 20:48:44 --> Form Validation Class Initialized
INFO - 2018-04-08 20:48:44 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:48:44 --> Helper loaded: url_helper
INFO - 2018-04-08 20:48:44 --> Model Class Initialized
INFO - 2018-04-08 20:48:44 --> Model Class Initialized
INFO - 2018-04-08 20:48:44 --> Model Class Initialized
INFO - 2018-04-08 20:48:46 --> Config Class Initialized
INFO - 2018-04-08 20:48:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:48:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:48:46 --> Utf8 Class Initialized
INFO - 2018-04-08 20:48:46 --> URI Class Initialized
INFO - 2018-04-08 20:48:46 --> Router Class Initialized
INFO - 2018-04-08 20:48:46 --> Output Class Initialized
INFO - 2018-04-08 20:48:46 --> Security Class Initialized
DEBUG - 2018-04-08 20:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:48:46 --> Input Class Initialized
INFO - 2018-04-08 20:48:46 --> Language Class Initialized
INFO - 2018-04-08 20:48:46 --> Loader Class Initialized
INFO - 2018-04-08 20:48:46 --> Helper loaded: common_helper
INFO - 2018-04-08 20:48:46 --> Database Driver Class Initialized
INFO - 2018-04-08 20:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:48:46 --> Email Class Initialized
INFO - 2018-04-08 20:48:46 --> Controller Class Initialized
INFO - 2018-04-08 20:48:46 --> Helper loaded: form_helper
INFO - 2018-04-08 20:48:46 --> Form Validation Class Initialized
INFO - 2018-04-08 20:48:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:48:46 --> Helper loaded: url_helper
INFO - 2018-04-08 20:48:46 --> Model Class Initialized
INFO - 2018-04-08 20:48:46 --> Model Class Initialized
INFO - 2018-04-08 20:48:46 --> Model Class Initialized
INFO - 2018-04-08 20:48:49 --> Config Class Initialized
INFO - 2018-04-08 20:48:49 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:48:49 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:48:49 --> Utf8 Class Initialized
INFO - 2018-04-08 20:48:49 --> URI Class Initialized
INFO - 2018-04-08 20:48:49 --> Router Class Initialized
INFO - 2018-04-08 20:48:49 --> Output Class Initialized
INFO - 2018-04-08 20:48:49 --> Security Class Initialized
DEBUG - 2018-04-08 20:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:48:49 --> Input Class Initialized
INFO - 2018-04-08 20:48:49 --> Language Class Initialized
INFO - 2018-04-08 20:48:49 --> Loader Class Initialized
INFO - 2018-04-08 20:48:49 --> Helper loaded: common_helper
INFO - 2018-04-08 20:48:49 --> Database Driver Class Initialized
INFO - 2018-04-08 20:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:48:49 --> Email Class Initialized
INFO - 2018-04-08 20:48:49 --> Controller Class Initialized
INFO - 2018-04-08 20:48:49 --> Helper loaded: form_helper
INFO - 2018-04-08 20:48:49 --> Form Validation Class Initialized
INFO - 2018-04-08 20:48:49 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:48:49 --> Helper loaded: url_helper
INFO - 2018-04-08 20:48:49 --> Model Class Initialized
INFO - 2018-04-08 20:48:49 --> Model Class Initialized
INFO - 2018-04-08 20:48:49 --> Model Class Initialized
INFO - 2018-04-08 20:49:09 --> Config Class Initialized
INFO - 2018-04-08 20:49:09 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:49:09 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:49:09 --> Utf8 Class Initialized
INFO - 2018-04-08 20:49:09 --> URI Class Initialized
INFO - 2018-04-08 20:49:09 --> Router Class Initialized
INFO - 2018-04-08 20:49:09 --> Output Class Initialized
INFO - 2018-04-08 20:49:09 --> Security Class Initialized
DEBUG - 2018-04-08 20:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:49:09 --> Input Class Initialized
INFO - 2018-04-08 20:49:09 --> Language Class Initialized
INFO - 2018-04-08 20:49:09 --> Loader Class Initialized
INFO - 2018-04-08 20:49:09 --> Helper loaded: common_helper
INFO - 2018-04-08 20:49:09 --> Database Driver Class Initialized
INFO - 2018-04-08 20:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:49:09 --> Email Class Initialized
INFO - 2018-04-08 20:49:09 --> Controller Class Initialized
INFO - 2018-04-08 20:49:09 --> Helper loaded: form_helper
INFO - 2018-04-08 20:49:09 --> Form Validation Class Initialized
INFO - 2018-04-08 20:49:09 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:49:09 --> Helper loaded: url_helper
INFO - 2018-04-08 20:49:09 --> Model Class Initialized
INFO - 2018-04-08 20:49:09 --> Model Class Initialized
INFO - 2018-04-08 20:49:09 --> Model Class Initialized
INFO - 2018-04-08 20:53:29 --> Config Class Initialized
INFO - 2018-04-08 20:53:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:53:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:53:29 --> Utf8 Class Initialized
INFO - 2018-04-08 20:53:29 --> URI Class Initialized
INFO - 2018-04-08 20:53:29 --> Router Class Initialized
INFO - 2018-04-08 20:53:29 --> Output Class Initialized
INFO - 2018-04-08 20:53:29 --> Security Class Initialized
DEBUG - 2018-04-08 20:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:53:29 --> Input Class Initialized
INFO - 2018-04-08 20:53:29 --> Language Class Initialized
INFO - 2018-04-08 20:53:29 --> Loader Class Initialized
INFO - 2018-04-08 20:53:29 --> Helper loaded: common_helper
INFO - 2018-04-08 20:53:29 --> Database Driver Class Initialized
INFO - 2018-04-08 20:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:53:29 --> Email Class Initialized
INFO - 2018-04-08 20:53:29 --> Controller Class Initialized
INFO - 2018-04-08 20:53:29 --> Helper loaded: form_helper
INFO - 2018-04-08 20:53:29 --> Form Validation Class Initialized
INFO - 2018-04-08 20:53:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:53:29 --> Helper loaded: url_helper
INFO - 2018-04-08 20:53:29 --> Model Class Initialized
INFO - 2018-04-08 20:53:29 --> Model Class Initialized
INFO - 2018-04-08 20:53:29 --> Model Class Initialized
INFO - 2018-04-08 20:53:32 --> Config Class Initialized
INFO - 2018-04-08 20:53:32 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:53:32 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:53:32 --> Utf8 Class Initialized
INFO - 2018-04-08 20:53:32 --> URI Class Initialized
INFO - 2018-04-08 20:53:32 --> Router Class Initialized
INFO - 2018-04-08 20:53:32 --> Output Class Initialized
INFO - 2018-04-08 20:53:32 --> Security Class Initialized
DEBUG - 2018-04-08 20:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:53:32 --> Input Class Initialized
INFO - 2018-04-08 20:53:32 --> Language Class Initialized
INFO - 2018-04-08 20:53:32 --> Loader Class Initialized
INFO - 2018-04-08 20:53:32 --> Helper loaded: common_helper
INFO - 2018-04-08 20:53:32 --> Database Driver Class Initialized
INFO - 2018-04-08 20:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:53:32 --> Email Class Initialized
INFO - 2018-04-08 20:53:32 --> Controller Class Initialized
INFO - 2018-04-08 20:53:32 --> Helper loaded: form_helper
INFO - 2018-04-08 20:53:32 --> Form Validation Class Initialized
INFO - 2018-04-08 20:53:32 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:53:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:53:32 --> Helper loaded: url_helper
INFO - 2018-04-08 20:53:32 --> Model Class Initialized
INFO - 2018-04-08 20:53:32 --> Model Class Initialized
INFO - 2018-04-08 20:53:32 --> Model Class Initialized
INFO - 2018-04-08 20:54:28 --> Config Class Initialized
INFO - 2018-04-08 20:54:28 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:54:28 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:54:28 --> Utf8 Class Initialized
INFO - 2018-04-08 20:54:28 --> URI Class Initialized
INFO - 2018-04-08 20:54:28 --> Router Class Initialized
INFO - 2018-04-08 20:54:28 --> Output Class Initialized
INFO - 2018-04-08 20:54:28 --> Security Class Initialized
DEBUG - 2018-04-08 20:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:54:28 --> Input Class Initialized
INFO - 2018-04-08 20:54:28 --> Language Class Initialized
INFO - 2018-04-08 20:54:28 --> Loader Class Initialized
INFO - 2018-04-08 20:54:28 --> Helper loaded: common_helper
INFO - 2018-04-08 20:54:28 --> Database Driver Class Initialized
INFO - 2018-04-08 20:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:54:28 --> Email Class Initialized
INFO - 2018-04-08 20:54:28 --> Controller Class Initialized
INFO - 2018-04-08 20:54:28 --> Helper loaded: form_helper
INFO - 2018-04-08 20:54:28 --> Form Validation Class Initialized
INFO - 2018-04-08 20:54:28 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:54:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:54:28 --> Helper loaded: url_helper
INFO - 2018-04-08 20:54:28 --> Model Class Initialized
INFO - 2018-04-08 20:54:28 --> Model Class Initialized
INFO - 2018-04-08 20:54:28 --> Model Class Initialized
INFO - 2018-04-08 20:55:10 --> Config Class Initialized
INFO - 2018-04-08 20:55:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:55:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:55:10 --> Utf8 Class Initialized
INFO - 2018-04-08 20:55:10 --> URI Class Initialized
INFO - 2018-04-08 20:55:10 --> Router Class Initialized
INFO - 2018-04-08 20:55:10 --> Output Class Initialized
INFO - 2018-04-08 20:55:10 --> Security Class Initialized
DEBUG - 2018-04-08 20:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:55:10 --> Input Class Initialized
INFO - 2018-04-08 20:55:10 --> Language Class Initialized
INFO - 2018-04-08 20:55:10 --> Loader Class Initialized
INFO - 2018-04-08 20:55:10 --> Helper loaded: common_helper
INFO - 2018-04-08 20:55:10 --> Database Driver Class Initialized
INFO - 2018-04-08 20:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:55:10 --> Email Class Initialized
INFO - 2018-04-08 20:55:10 --> Controller Class Initialized
INFO - 2018-04-08 20:55:10 --> Helper loaded: form_helper
INFO - 2018-04-08 20:55:10 --> Form Validation Class Initialized
INFO - 2018-04-08 20:55:10 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:55:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:55:10 --> Helper loaded: url_helper
INFO - 2018-04-08 20:55:10 --> Model Class Initialized
INFO - 2018-04-08 20:55:10 --> Model Class Initialized
INFO - 2018-04-08 20:55:10 --> Model Class Initialized
INFO - 2018-04-08 20:55:44 --> Config Class Initialized
INFO - 2018-04-08 20:55:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:55:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:55:44 --> Utf8 Class Initialized
INFO - 2018-04-08 20:55:44 --> URI Class Initialized
INFO - 2018-04-08 20:55:44 --> Router Class Initialized
INFO - 2018-04-08 20:55:44 --> Output Class Initialized
INFO - 2018-04-08 20:55:44 --> Security Class Initialized
DEBUG - 2018-04-08 20:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:55:44 --> Input Class Initialized
INFO - 2018-04-08 20:55:44 --> Language Class Initialized
INFO - 2018-04-08 20:55:44 --> Loader Class Initialized
INFO - 2018-04-08 20:55:44 --> Helper loaded: common_helper
INFO - 2018-04-08 20:55:44 --> Database Driver Class Initialized
INFO - 2018-04-08 20:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:55:44 --> Email Class Initialized
INFO - 2018-04-08 20:55:44 --> Controller Class Initialized
INFO - 2018-04-08 20:55:44 --> Helper loaded: form_helper
INFO - 2018-04-08 20:55:44 --> Form Validation Class Initialized
INFO - 2018-04-08 20:55:44 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:55:44 --> Helper loaded: url_helper
INFO - 2018-04-08 20:55:44 --> Model Class Initialized
INFO - 2018-04-08 20:55:44 --> Model Class Initialized
INFO - 2018-04-08 20:55:44 --> Model Class Initialized
INFO - 2018-04-08 20:55:55 --> Config Class Initialized
INFO - 2018-04-08 20:55:55 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:55:55 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:55:55 --> Utf8 Class Initialized
INFO - 2018-04-08 20:55:55 --> URI Class Initialized
INFO - 2018-04-08 20:55:55 --> Router Class Initialized
INFO - 2018-04-08 20:55:55 --> Output Class Initialized
INFO - 2018-04-08 20:55:55 --> Security Class Initialized
DEBUG - 2018-04-08 20:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:55:55 --> Input Class Initialized
INFO - 2018-04-08 20:55:55 --> Language Class Initialized
INFO - 2018-04-08 20:55:55 --> Loader Class Initialized
INFO - 2018-04-08 20:55:55 --> Helper loaded: common_helper
INFO - 2018-04-08 20:55:55 --> Database Driver Class Initialized
INFO - 2018-04-08 20:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:55:56 --> Email Class Initialized
INFO - 2018-04-08 20:55:56 --> Controller Class Initialized
INFO - 2018-04-08 20:55:56 --> Helper loaded: form_helper
INFO - 2018-04-08 20:55:56 --> Form Validation Class Initialized
INFO - 2018-04-08 20:55:56 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:55:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:55:56 --> Helper loaded: url_helper
INFO - 2018-04-08 20:55:56 --> Model Class Initialized
INFO - 2018-04-08 20:55:56 --> Model Class Initialized
INFO - 2018-04-08 20:55:56 --> Model Class Initialized
INFO - 2018-04-08 20:56:39 --> Config Class Initialized
INFO - 2018-04-08 20:56:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:56:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:56:39 --> Utf8 Class Initialized
INFO - 2018-04-08 20:56:39 --> URI Class Initialized
INFO - 2018-04-08 20:56:39 --> Router Class Initialized
INFO - 2018-04-08 20:56:39 --> Output Class Initialized
INFO - 2018-04-08 20:56:39 --> Security Class Initialized
DEBUG - 2018-04-08 20:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:56:39 --> Input Class Initialized
INFO - 2018-04-08 20:56:39 --> Language Class Initialized
INFO - 2018-04-08 20:56:39 --> Loader Class Initialized
INFO - 2018-04-08 20:56:39 --> Helper loaded: common_helper
INFO - 2018-04-08 20:56:39 --> Database Driver Class Initialized
INFO - 2018-04-08 20:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:56:39 --> Email Class Initialized
INFO - 2018-04-08 20:56:39 --> Controller Class Initialized
INFO - 2018-04-08 20:56:39 --> Helper loaded: form_helper
INFO - 2018-04-08 20:56:39 --> Form Validation Class Initialized
INFO - 2018-04-08 20:56:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:56:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:56:39 --> Helper loaded: url_helper
INFO - 2018-04-08 20:56:39 --> Model Class Initialized
INFO - 2018-04-08 20:56:39 --> Model Class Initialized
INFO - 2018-04-08 20:56:39 --> Model Class Initialized
INFO - 2018-04-08 20:56:45 --> Config Class Initialized
INFO - 2018-04-08 20:56:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:56:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:56:45 --> Utf8 Class Initialized
INFO - 2018-04-08 20:56:45 --> URI Class Initialized
INFO - 2018-04-08 20:56:45 --> Router Class Initialized
INFO - 2018-04-08 20:56:45 --> Output Class Initialized
INFO - 2018-04-08 20:56:45 --> Security Class Initialized
DEBUG - 2018-04-08 20:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:56:45 --> Input Class Initialized
INFO - 2018-04-08 20:56:45 --> Language Class Initialized
INFO - 2018-04-08 20:56:45 --> Loader Class Initialized
INFO - 2018-04-08 20:56:45 --> Helper loaded: common_helper
INFO - 2018-04-08 20:56:45 --> Database Driver Class Initialized
INFO - 2018-04-08 20:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:56:45 --> Email Class Initialized
INFO - 2018-04-08 20:56:45 --> Controller Class Initialized
INFO - 2018-04-08 20:56:45 --> Helper loaded: form_helper
INFO - 2018-04-08 20:56:45 --> Form Validation Class Initialized
INFO - 2018-04-08 20:56:45 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:56:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:56:45 --> Helper loaded: url_helper
INFO - 2018-04-08 20:56:45 --> Model Class Initialized
INFO - 2018-04-08 20:56:45 --> Model Class Initialized
INFO - 2018-04-08 20:56:45 --> Model Class Initialized
INFO - 2018-04-08 20:56:59 --> Config Class Initialized
INFO - 2018-04-08 20:56:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:56:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:56:59 --> Utf8 Class Initialized
INFO - 2018-04-08 20:56:59 --> URI Class Initialized
INFO - 2018-04-08 20:56:59 --> Router Class Initialized
INFO - 2018-04-08 20:56:59 --> Output Class Initialized
INFO - 2018-04-08 20:56:59 --> Security Class Initialized
DEBUG - 2018-04-08 20:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:56:59 --> Input Class Initialized
INFO - 2018-04-08 20:56:59 --> Language Class Initialized
INFO - 2018-04-08 20:56:59 --> Loader Class Initialized
INFO - 2018-04-08 20:56:59 --> Helper loaded: common_helper
INFO - 2018-04-08 20:56:59 --> Database Driver Class Initialized
INFO - 2018-04-08 20:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:56:59 --> Email Class Initialized
INFO - 2018-04-08 20:56:59 --> Controller Class Initialized
INFO - 2018-04-08 20:56:59 --> Helper loaded: form_helper
INFO - 2018-04-08 20:56:59 --> Form Validation Class Initialized
INFO - 2018-04-08 20:56:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:56:59 --> Helper loaded: url_helper
INFO - 2018-04-08 20:56:59 --> Model Class Initialized
INFO - 2018-04-08 20:56:59 --> Model Class Initialized
INFO - 2018-04-08 20:56:59 --> Model Class Initialized
INFO - 2018-04-08 20:57:26 --> Config Class Initialized
INFO - 2018-04-08 20:57:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 20:57:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 20:57:26 --> Utf8 Class Initialized
INFO - 2018-04-08 20:57:26 --> URI Class Initialized
INFO - 2018-04-08 20:57:26 --> Router Class Initialized
INFO - 2018-04-08 20:57:26 --> Output Class Initialized
INFO - 2018-04-08 20:57:26 --> Security Class Initialized
DEBUG - 2018-04-08 20:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 20:57:26 --> Input Class Initialized
INFO - 2018-04-08 20:57:26 --> Language Class Initialized
INFO - 2018-04-08 20:57:26 --> Loader Class Initialized
INFO - 2018-04-08 20:57:26 --> Helper loaded: common_helper
INFO - 2018-04-08 20:57:26 --> Database Driver Class Initialized
INFO - 2018-04-08 20:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 20:57:26 --> Email Class Initialized
INFO - 2018-04-08 20:57:26 --> Controller Class Initialized
INFO - 2018-04-08 20:57:26 --> Helper loaded: form_helper
INFO - 2018-04-08 20:57:26 --> Form Validation Class Initialized
INFO - 2018-04-08 20:57:26 --> Helper loaded: email_helper
DEBUG - 2018-04-08 20:57:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 20:57:26 --> Helper loaded: url_helper
INFO - 2018-04-08 20:57:26 --> Model Class Initialized
INFO - 2018-04-08 20:57:26 --> Model Class Initialized
INFO - 2018-04-08 20:57:26 --> Model Class Initialized
INFO - 2018-04-08 21:02:13 --> Config Class Initialized
INFO - 2018-04-08 21:02:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:02:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:02:13 --> Utf8 Class Initialized
INFO - 2018-04-08 21:02:13 --> URI Class Initialized
INFO - 2018-04-08 21:02:13 --> Router Class Initialized
INFO - 2018-04-08 21:02:13 --> Output Class Initialized
INFO - 2018-04-08 21:02:13 --> Security Class Initialized
DEBUG - 2018-04-08 21:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:02:13 --> Input Class Initialized
INFO - 2018-04-08 21:02:13 --> Language Class Initialized
INFO - 2018-04-08 21:02:13 --> Loader Class Initialized
INFO - 2018-04-08 21:02:13 --> Helper loaded: common_helper
INFO - 2018-04-08 21:02:13 --> Database Driver Class Initialized
INFO - 2018-04-08 21:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:02:13 --> Email Class Initialized
INFO - 2018-04-08 21:02:13 --> Controller Class Initialized
INFO - 2018-04-08 21:02:13 --> Helper loaded: form_helper
INFO - 2018-04-08 21:02:13 --> Form Validation Class Initialized
INFO - 2018-04-08 21:02:13 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:02:13 --> Helper loaded: url_helper
INFO - 2018-04-08 21:02:13 --> Model Class Initialized
INFO - 2018-04-08 21:02:13 --> Model Class Initialized
INFO - 2018-04-08 21:02:13 --> Model Class Initialized
INFO - 2018-04-08 21:02:17 --> Config Class Initialized
INFO - 2018-04-08 21:02:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:02:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:02:17 --> Utf8 Class Initialized
INFO - 2018-04-08 21:02:17 --> URI Class Initialized
INFO - 2018-04-08 21:02:17 --> Router Class Initialized
INFO - 2018-04-08 21:02:17 --> Output Class Initialized
INFO - 2018-04-08 21:02:17 --> Security Class Initialized
DEBUG - 2018-04-08 21:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:02:17 --> Input Class Initialized
INFO - 2018-04-08 21:02:17 --> Language Class Initialized
INFO - 2018-04-08 21:02:17 --> Loader Class Initialized
INFO - 2018-04-08 21:02:17 --> Helper loaded: common_helper
INFO - 2018-04-08 21:02:17 --> Database Driver Class Initialized
INFO - 2018-04-08 21:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:02:17 --> Email Class Initialized
INFO - 2018-04-08 21:02:17 --> Controller Class Initialized
INFO - 2018-04-08 21:02:17 --> Helper loaded: form_helper
INFO - 2018-04-08 21:02:17 --> Form Validation Class Initialized
INFO - 2018-04-08 21:02:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:02:17 --> Helper loaded: url_helper
INFO - 2018-04-08 21:02:17 --> Model Class Initialized
INFO - 2018-04-08 21:02:17 --> Model Class Initialized
INFO - 2018-04-08 21:02:17 --> Model Class Initialized
INFO - 2018-04-08 21:02:20 --> Config Class Initialized
INFO - 2018-04-08 21:02:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:02:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:02:20 --> Utf8 Class Initialized
INFO - 2018-04-08 21:02:20 --> URI Class Initialized
INFO - 2018-04-08 21:02:20 --> Router Class Initialized
INFO - 2018-04-08 21:02:20 --> Output Class Initialized
INFO - 2018-04-08 21:02:20 --> Security Class Initialized
DEBUG - 2018-04-08 21:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:02:20 --> Input Class Initialized
INFO - 2018-04-08 21:02:20 --> Language Class Initialized
INFO - 2018-04-08 21:02:20 --> Loader Class Initialized
INFO - 2018-04-08 21:02:20 --> Helper loaded: common_helper
INFO - 2018-04-08 21:02:20 --> Database Driver Class Initialized
INFO - 2018-04-08 21:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:02:20 --> Email Class Initialized
INFO - 2018-04-08 21:02:20 --> Controller Class Initialized
INFO - 2018-04-08 21:02:20 --> Helper loaded: form_helper
INFO - 2018-04-08 21:02:20 --> Form Validation Class Initialized
INFO - 2018-04-08 21:02:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:02:20 --> Helper loaded: url_helper
INFO - 2018-04-08 21:02:20 --> Model Class Initialized
INFO - 2018-04-08 21:02:20 --> Model Class Initialized
INFO - 2018-04-08 21:02:20 --> Model Class Initialized
INFO - 2018-04-08 21:02:37 --> Config Class Initialized
INFO - 2018-04-08 21:02:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:02:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:02:37 --> Utf8 Class Initialized
INFO - 2018-04-08 21:02:37 --> URI Class Initialized
INFO - 2018-04-08 21:02:37 --> Router Class Initialized
INFO - 2018-04-08 21:02:37 --> Output Class Initialized
INFO - 2018-04-08 21:02:37 --> Security Class Initialized
DEBUG - 2018-04-08 21:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:02:37 --> Input Class Initialized
INFO - 2018-04-08 21:02:38 --> Language Class Initialized
INFO - 2018-04-08 21:02:38 --> Loader Class Initialized
INFO - 2018-04-08 21:02:38 --> Helper loaded: common_helper
INFO - 2018-04-08 21:02:38 --> Database Driver Class Initialized
INFO - 2018-04-08 21:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:02:38 --> Email Class Initialized
INFO - 2018-04-08 21:02:38 --> Controller Class Initialized
INFO - 2018-04-08 21:02:38 --> Helper loaded: form_helper
INFO - 2018-04-08 21:02:38 --> Form Validation Class Initialized
INFO - 2018-04-08 21:02:38 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:02:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:02:38 --> Helper loaded: url_helper
INFO - 2018-04-08 21:02:38 --> Model Class Initialized
INFO - 2018-04-08 21:02:38 --> Model Class Initialized
INFO - 2018-04-08 21:02:38 --> Model Class Initialized
INFO - 2018-04-08 21:02:40 --> Config Class Initialized
INFO - 2018-04-08 21:02:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:02:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:02:40 --> Utf8 Class Initialized
INFO - 2018-04-08 21:02:40 --> URI Class Initialized
INFO - 2018-04-08 21:02:40 --> Router Class Initialized
INFO - 2018-04-08 21:02:40 --> Output Class Initialized
INFO - 2018-04-08 21:02:41 --> Security Class Initialized
DEBUG - 2018-04-08 21:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:02:41 --> Input Class Initialized
INFO - 2018-04-08 21:02:41 --> Language Class Initialized
INFO - 2018-04-08 21:02:41 --> Loader Class Initialized
INFO - 2018-04-08 21:02:41 --> Helper loaded: common_helper
INFO - 2018-04-08 21:02:41 --> Database Driver Class Initialized
INFO - 2018-04-08 21:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:02:41 --> Email Class Initialized
INFO - 2018-04-08 21:02:41 --> Controller Class Initialized
INFO - 2018-04-08 21:02:41 --> Helper loaded: form_helper
INFO - 2018-04-08 21:02:41 --> Form Validation Class Initialized
INFO - 2018-04-08 21:02:41 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:02:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:02:41 --> Helper loaded: url_helper
INFO - 2018-04-08 21:02:41 --> Model Class Initialized
INFO - 2018-04-08 21:02:41 --> Model Class Initialized
INFO - 2018-04-08 21:02:41 --> Model Class Initialized
INFO - 2018-04-08 21:02:57 --> Config Class Initialized
INFO - 2018-04-08 21:02:57 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:02:57 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:02:57 --> Utf8 Class Initialized
INFO - 2018-04-08 21:02:57 --> URI Class Initialized
INFO - 2018-04-08 21:02:57 --> Router Class Initialized
INFO - 2018-04-08 21:02:57 --> Output Class Initialized
INFO - 2018-04-08 21:02:57 --> Security Class Initialized
DEBUG - 2018-04-08 21:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:02:57 --> Input Class Initialized
INFO - 2018-04-08 21:02:57 --> Language Class Initialized
INFO - 2018-04-08 21:02:57 --> Loader Class Initialized
INFO - 2018-04-08 21:02:57 --> Helper loaded: common_helper
INFO - 2018-04-08 21:02:57 --> Database Driver Class Initialized
INFO - 2018-04-08 21:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:02:57 --> Email Class Initialized
INFO - 2018-04-08 21:02:57 --> Controller Class Initialized
INFO - 2018-04-08 21:02:57 --> Helper loaded: form_helper
INFO - 2018-04-08 21:02:57 --> Form Validation Class Initialized
INFO - 2018-04-08 21:02:57 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:02:57 --> Helper loaded: url_helper
INFO - 2018-04-08 21:02:57 --> Model Class Initialized
INFO - 2018-04-08 21:02:57 --> Model Class Initialized
INFO - 2018-04-08 21:02:57 --> Model Class Initialized
INFO - 2018-04-08 21:03:02 --> Config Class Initialized
INFO - 2018-04-08 21:03:02 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:03:02 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:03:02 --> Utf8 Class Initialized
INFO - 2018-04-08 21:03:16 --> Config Class Initialized
INFO - 2018-04-08 21:03:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:03:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:03:16 --> Utf8 Class Initialized
INFO - 2018-04-08 21:03:16 --> URI Class Initialized
INFO - 2018-04-08 21:03:16 --> Router Class Initialized
INFO - 2018-04-08 21:03:16 --> Output Class Initialized
INFO - 2018-04-08 21:03:16 --> Security Class Initialized
DEBUG - 2018-04-08 21:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:03:16 --> Input Class Initialized
INFO - 2018-04-08 21:03:16 --> Language Class Initialized
INFO - 2018-04-08 21:03:16 --> Loader Class Initialized
INFO - 2018-04-08 21:03:16 --> Helper loaded: common_helper
INFO - 2018-04-08 21:03:16 --> Database Driver Class Initialized
INFO - 2018-04-08 21:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:03:16 --> Email Class Initialized
INFO - 2018-04-08 21:03:16 --> Controller Class Initialized
INFO - 2018-04-08 21:03:16 --> Helper loaded: form_helper
INFO - 2018-04-08 21:03:16 --> Form Validation Class Initialized
INFO - 2018-04-08 21:03:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:03:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:03:16 --> Helper loaded: url_helper
INFO - 2018-04-08 21:03:16 --> Model Class Initialized
INFO - 2018-04-08 21:03:16 --> Model Class Initialized
INFO - 2018-04-08 21:03:16 --> Model Class Initialized
INFO - 2018-04-08 21:03:25 --> Config Class Initialized
INFO - 2018-04-08 21:03:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:03:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:03:25 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:22 --> Config Class Initialized
INFO - 2018-04-08 21:04:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:22 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:22 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:22 --> URI Class Initialized
INFO - 2018-04-08 21:04:22 --> Router Class Initialized
INFO - 2018-04-08 21:04:22 --> Output Class Initialized
INFO - 2018-04-08 21:04:22 --> Security Class Initialized
DEBUG - 2018-04-08 21:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:04:22 --> Input Class Initialized
INFO - 2018-04-08 21:04:22 --> Language Class Initialized
INFO - 2018-04-08 21:04:22 --> Loader Class Initialized
INFO - 2018-04-08 21:04:22 --> Helper loaded: common_helper
INFO - 2018-04-08 21:04:22 --> Database Driver Class Initialized
INFO - 2018-04-08 21:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:04:23 --> Email Class Initialized
INFO - 2018-04-08 21:04:23 --> Controller Class Initialized
INFO - 2018-04-08 21:04:23 --> Helper loaded: form_helper
INFO - 2018-04-08 21:04:23 --> Form Validation Class Initialized
INFO - 2018-04-08 21:04:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:04:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:04:23 --> Helper loaded: url_helper
INFO - 2018-04-08 21:04:23 --> Model Class Initialized
INFO - 2018-04-08 21:04:23 --> Model Class Initialized
INFO - 2018-04-08 21:04:23 --> Model Class Initialized
INFO - 2018-04-08 21:04:27 --> Config Class Initialized
INFO - 2018-04-08 21:04:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:27 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:29 --> Config Class Initialized
INFO - 2018-04-08 21:04:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:29 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:29 --> URI Class Initialized
INFO - 2018-04-08 21:04:29 --> Router Class Initialized
INFO - 2018-04-08 21:04:29 --> Output Class Initialized
INFO - 2018-04-08 21:04:29 --> Security Class Initialized
DEBUG - 2018-04-08 21:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:04:29 --> Input Class Initialized
INFO - 2018-04-08 21:04:29 --> Language Class Initialized
INFO - 2018-04-08 21:04:29 --> Loader Class Initialized
INFO - 2018-04-08 21:04:29 --> Helper loaded: common_helper
INFO - 2018-04-08 21:04:29 --> Database Driver Class Initialized
INFO - 2018-04-08 21:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:04:29 --> Email Class Initialized
INFO - 2018-04-08 21:04:29 --> Controller Class Initialized
INFO - 2018-04-08 21:04:29 --> Helper loaded: form_helper
INFO - 2018-04-08 21:04:29 --> Form Validation Class Initialized
INFO - 2018-04-08 21:04:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:04:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:04:29 --> Helper loaded: url_helper
INFO - 2018-04-08 21:04:29 --> Model Class Initialized
INFO - 2018-04-08 21:04:29 --> Model Class Initialized
INFO - 2018-04-08 21:04:29 --> Model Class Initialized
INFO - 2018-04-08 21:04:31 --> Config Class Initialized
INFO - 2018-04-08 21:04:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:31 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:33 --> Config Class Initialized
INFO - 2018-04-08 21:04:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:33 --> URI Class Initialized
INFO - 2018-04-08 21:04:33 --> Router Class Initialized
INFO - 2018-04-08 21:04:33 --> Output Class Initialized
INFO - 2018-04-08 21:04:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:04:33 --> Input Class Initialized
INFO - 2018-04-08 21:04:33 --> Language Class Initialized
INFO - 2018-04-08 21:04:33 --> Loader Class Initialized
INFO - 2018-04-08 21:04:33 --> Helper loaded: common_helper
INFO - 2018-04-08 21:04:33 --> Database Driver Class Initialized
INFO - 2018-04-08 21:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:04:33 --> Email Class Initialized
INFO - 2018-04-08 21:04:33 --> Controller Class Initialized
INFO - 2018-04-08 21:04:33 --> Helper loaded: form_helper
INFO - 2018-04-08 21:04:33 --> Form Validation Class Initialized
INFO - 2018-04-08 21:04:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:04:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:04:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:04:33 --> Model Class Initialized
INFO - 2018-04-08 21:04:33 --> Model Class Initialized
INFO - 2018-04-08 21:04:33 --> Model Class Initialized
INFO - 2018-04-08 21:04:35 --> Config Class Initialized
INFO - 2018-04-08 21:04:35 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:35 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:35 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:35 --> URI Class Initialized
INFO - 2018-04-08 21:04:35 --> Router Class Initialized
INFO - 2018-04-08 21:04:35 --> Output Class Initialized
INFO - 2018-04-08 21:04:35 --> Security Class Initialized
DEBUG - 2018-04-08 21:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:04:35 --> Input Class Initialized
INFO - 2018-04-08 21:04:35 --> Language Class Initialized
INFO - 2018-04-08 21:04:35 --> Loader Class Initialized
INFO - 2018-04-08 21:04:35 --> Helper loaded: common_helper
INFO - 2018-04-08 21:04:35 --> Database Driver Class Initialized
INFO - 2018-04-08 21:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:04:35 --> Email Class Initialized
INFO - 2018-04-08 21:04:35 --> Controller Class Initialized
INFO - 2018-04-08 21:04:35 --> Helper loaded: form_helper
INFO - 2018-04-08 21:04:35 --> Form Validation Class Initialized
INFO - 2018-04-08 21:04:35 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:04:35 --> Helper loaded: url_helper
INFO - 2018-04-08 21:04:35 --> Model Class Initialized
INFO - 2018-04-08 21:04:35 --> Model Class Initialized
INFO - 2018-04-08 21:04:35 --> Model Class Initialized
INFO - 2018-04-08 21:04:39 --> Config Class Initialized
INFO - 2018-04-08 21:04:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:39 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:39 --> URI Class Initialized
INFO - 2018-04-08 21:04:39 --> Router Class Initialized
INFO - 2018-04-08 21:04:39 --> Output Class Initialized
INFO - 2018-04-08 21:04:39 --> Security Class Initialized
DEBUG - 2018-04-08 21:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:04:39 --> Input Class Initialized
INFO - 2018-04-08 21:04:39 --> Language Class Initialized
INFO - 2018-04-08 21:04:39 --> Loader Class Initialized
INFO - 2018-04-08 21:04:39 --> Helper loaded: common_helper
INFO - 2018-04-08 21:04:39 --> Database Driver Class Initialized
INFO - 2018-04-08 21:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:04:39 --> Email Class Initialized
INFO - 2018-04-08 21:04:39 --> Controller Class Initialized
INFO - 2018-04-08 21:04:39 --> Helper loaded: form_helper
INFO - 2018-04-08 21:04:39 --> Form Validation Class Initialized
INFO - 2018-04-08 21:04:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:04:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:04:39 --> Helper loaded: url_helper
INFO - 2018-04-08 21:04:39 --> Model Class Initialized
INFO - 2018-04-08 21:04:39 --> Model Class Initialized
INFO - 2018-04-08 21:04:39 --> Model Class Initialized
INFO - 2018-04-08 21:04:42 --> Config Class Initialized
INFO - 2018-04-08 21:04:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:42 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:45 --> Config Class Initialized
INFO - 2018-04-08 21:04:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:04:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:04:45 --> Utf8 Class Initialized
INFO - 2018-04-08 21:04:45 --> URI Class Initialized
INFO - 2018-04-08 21:04:45 --> Router Class Initialized
INFO - 2018-04-08 21:04:45 --> Output Class Initialized
INFO - 2018-04-08 21:04:45 --> Security Class Initialized
DEBUG - 2018-04-08 21:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:04:45 --> Input Class Initialized
INFO - 2018-04-08 21:04:45 --> Language Class Initialized
INFO - 2018-04-08 21:04:45 --> Loader Class Initialized
INFO - 2018-04-08 21:04:45 --> Helper loaded: common_helper
INFO - 2018-04-08 21:04:45 --> Database Driver Class Initialized
INFO - 2018-04-08 21:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:04:45 --> Email Class Initialized
INFO - 2018-04-08 21:04:45 --> Controller Class Initialized
INFO - 2018-04-08 21:04:45 --> Helper loaded: form_helper
INFO - 2018-04-08 21:04:45 --> Form Validation Class Initialized
INFO - 2018-04-08 21:04:45 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:04:45 --> Helper loaded: url_helper
INFO - 2018-04-08 21:04:45 --> Model Class Initialized
INFO - 2018-04-08 21:04:45 --> Model Class Initialized
INFO - 2018-04-08 21:04:45 --> Model Class Initialized
INFO - 2018-04-08 21:05:19 --> Config Class Initialized
INFO - 2018-04-08 21:05:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:19 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:19 --> URI Class Initialized
INFO - 2018-04-08 21:05:19 --> Router Class Initialized
INFO - 2018-04-08 21:05:19 --> Output Class Initialized
INFO - 2018-04-08 21:05:19 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:19 --> Input Class Initialized
INFO - 2018-04-08 21:05:19 --> Language Class Initialized
INFO - 2018-04-08 21:05:19 --> Loader Class Initialized
INFO - 2018-04-08 21:05:19 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:19 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:19 --> Email Class Initialized
INFO - 2018-04-08 21:05:19 --> Controller Class Initialized
INFO - 2018-04-08 21:05:19 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:19 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:19 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:19 --> Model Class Initialized
INFO - 2018-04-08 21:05:19 --> Model Class Initialized
INFO - 2018-04-08 21:05:19 --> Model Class Initialized
INFO - 2018-04-08 21:05:24 --> Config Class Initialized
INFO - 2018-04-08 21:05:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:24 --> URI Class Initialized
INFO - 2018-04-08 21:05:24 --> Router Class Initialized
INFO - 2018-04-08 21:05:24 --> Output Class Initialized
INFO - 2018-04-08 21:05:24 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:24 --> Input Class Initialized
INFO - 2018-04-08 21:05:24 --> Language Class Initialized
INFO - 2018-04-08 21:05:24 --> Loader Class Initialized
INFO - 2018-04-08 21:05:24 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:24 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:24 --> Email Class Initialized
INFO - 2018-04-08 21:05:24 --> Controller Class Initialized
INFO - 2018-04-08 21:05:24 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:24 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:24 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:24 --> Model Class Initialized
INFO - 2018-04-08 21:05:24 --> Model Class Initialized
INFO - 2018-04-08 21:05:24 --> Model Class Initialized
INFO - 2018-04-08 21:05:31 --> Config Class Initialized
INFO - 2018-04-08 21:05:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:31 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:31 --> URI Class Initialized
INFO - 2018-04-08 21:05:31 --> Router Class Initialized
INFO - 2018-04-08 21:05:31 --> Output Class Initialized
INFO - 2018-04-08 21:05:31 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:31 --> Input Class Initialized
INFO - 2018-04-08 21:05:31 --> Language Class Initialized
INFO - 2018-04-08 21:05:31 --> Loader Class Initialized
INFO - 2018-04-08 21:05:31 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:31 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:31 --> Email Class Initialized
INFO - 2018-04-08 21:05:31 --> Controller Class Initialized
INFO - 2018-04-08 21:05:31 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:31 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:31 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:31 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:31 --> Model Class Initialized
INFO - 2018-04-08 21:05:31 --> Model Class Initialized
INFO - 2018-04-08 21:05:31 --> Model Class Initialized
INFO - 2018-04-08 21:05:33 --> Config Class Initialized
INFO - 2018-04-08 21:05:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:33 --> URI Class Initialized
INFO - 2018-04-08 21:05:33 --> Router Class Initialized
INFO - 2018-04-08 21:05:33 --> Output Class Initialized
INFO - 2018-04-08 21:05:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:33 --> Input Class Initialized
INFO - 2018-04-08 21:05:33 --> Language Class Initialized
INFO - 2018-04-08 21:05:33 --> Loader Class Initialized
INFO - 2018-04-08 21:05:33 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:33 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:33 --> Email Class Initialized
INFO - 2018-04-08 21:05:33 --> Controller Class Initialized
INFO - 2018-04-08 21:05:33 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:33 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:33 --> Model Class Initialized
INFO - 2018-04-08 21:05:33 --> Model Class Initialized
INFO - 2018-04-08 21:05:33 --> Model Class Initialized
INFO - 2018-04-08 21:05:37 --> Config Class Initialized
INFO - 2018-04-08 21:05:37 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:37 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:37 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:37 --> URI Class Initialized
INFO - 2018-04-08 21:05:37 --> Router Class Initialized
INFO - 2018-04-08 21:05:37 --> Output Class Initialized
INFO - 2018-04-08 21:05:37 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:37 --> Input Class Initialized
INFO - 2018-04-08 21:05:37 --> Language Class Initialized
INFO - 2018-04-08 21:05:37 --> Loader Class Initialized
INFO - 2018-04-08 21:05:37 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:37 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:37 --> Email Class Initialized
INFO - 2018-04-08 21:05:37 --> Controller Class Initialized
INFO - 2018-04-08 21:05:37 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:37 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:37 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:37 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:37 --> Model Class Initialized
INFO - 2018-04-08 21:05:37 --> Model Class Initialized
INFO - 2018-04-08 21:05:37 --> Model Class Initialized
INFO - 2018-04-08 21:05:39 --> Config Class Initialized
INFO - 2018-04-08 21:05:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:39 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:39 --> URI Class Initialized
INFO - 2018-04-08 21:05:39 --> Router Class Initialized
INFO - 2018-04-08 21:05:39 --> Output Class Initialized
INFO - 2018-04-08 21:05:39 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:39 --> Input Class Initialized
INFO - 2018-04-08 21:05:39 --> Language Class Initialized
INFO - 2018-04-08 21:05:39 --> Loader Class Initialized
INFO - 2018-04-08 21:05:39 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:39 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:39 --> Email Class Initialized
INFO - 2018-04-08 21:05:39 --> Controller Class Initialized
INFO - 2018-04-08 21:05:39 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:39 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:39 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:39 --> Model Class Initialized
INFO - 2018-04-08 21:05:39 --> Model Class Initialized
INFO - 2018-04-08 21:05:39 --> Model Class Initialized
INFO - 2018-04-08 21:05:52 --> Config Class Initialized
INFO - 2018-04-08 21:05:52 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:52 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:52 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:52 --> URI Class Initialized
INFO - 2018-04-08 21:05:52 --> Router Class Initialized
INFO - 2018-04-08 21:05:52 --> Output Class Initialized
INFO - 2018-04-08 21:05:52 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:52 --> Input Class Initialized
INFO - 2018-04-08 21:05:52 --> Language Class Initialized
INFO - 2018-04-08 21:05:52 --> Loader Class Initialized
INFO - 2018-04-08 21:05:52 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:52 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:52 --> Email Class Initialized
INFO - 2018-04-08 21:05:52 --> Controller Class Initialized
INFO - 2018-04-08 21:05:52 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:52 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:52 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:52 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:52 --> Model Class Initialized
INFO - 2018-04-08 21:05:52 --> Model Class Initialized
INFO - 2018-04-08 21:05:52 --> Model Class Initialized
INFO - 2018-04-08 21:05:54 --> Config Class Initialized
INFO - 2018-04-08 21:05:54 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:05:54 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:05:54 --> Utf8 Class Initialized
INFO - 2018-04-08 21:05:54 --> URI Class Initialized
INFO - 2018-04-08 21:05:54 --> Router Class Initialized
INFO - 2018-04-08 21:05:54 --> Output Class Initialized
INFO - 2018-04-08 21:05:54 --> Security Class Initialized
DEBUG - 2018-04-08 21:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:05:54 --> Input Class Initialized
INFO - 2018-04-08 21:05:54 --> Language Class Initialized
INFO - 2018-04-08 21:05:54 --> Loader Class Initialized
INFO - 2018-04-08 21:05:54 --> Helper loaded: common_helper
INFO - 2018-04-08 21:05:55 --> Database Driver Class Initialized
INFO - 2018-04-08 21:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:05:55 --> Email Class Initialized
INFO - 2018-04-08 21:05:55 --> Controller Class Initialized
INFO - 2018-04-08 21:05:55 --> Helper loaded: form_helper
INFO - 2018-04-08 21:05:55 --> Form Validation Class Initialized
INFO - 2018-04-08 21:05:55 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:05:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:05:55 --> Helper loaded: url_helper
INFO - 2018-04-08 21:05:55 --> Model Class Initialized
INFO - 2018-04-08 21:05:55 --> Model Class Initialized
INFO - 2018-04-08 21:05:55 --> Model Class Initialized
INFO - 2018-04-08 21:06:03 --> Config Class Initialized
INFO - 2018-04-08 21:06:03 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:06:03 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:06:03 --> Utf8 Class Initialized
INFO - 2018-04-08 21:06:03 --> URI Class Initialized
INFO - 2018-04-08 21:06:03 --> Router Class Initialized
INFO - 2018-04-08 21:06:03 --> Output Class Initialized
INFO - 2018-04-08 21:06:03 --> Security Class Initialized
DEBUG - 2018-04-08 21:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:06:03 --> Input Class Initialized
INFO - 2018-04-08 21:06:03 --> Language Class Initialized
INFO - 2018-04-08 21:06:04 --> Loader Class Initialized
INFO - 2018-04-08 21:06:04 --> Helper loaded: common_helper
INFO - 2018-04-08 21:06:04 --> Database Driver Class Initialized
INFO - 2018-04-08 21:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:06:04 --> Email Class Initialized
INFO - 2018-04-08 21:06:04 --> Controller Class Initialized
INFO - 2018-04-08 21:06:04 --> Helper loaded: form_helper
INFO - 2018-04-08 21:06:04 --> Form Validation Class Initialized
INFO - 2018-04-08 21:06:04 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:06:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:06:04 --> Helper loaded: url_helper
INFO - 2018-04-08 21:06:04 --> Model Class Initialized
INFO - 2018-04-08 21:06:04 --> Model Class Initialized
INFO - 2018-04-08 21:06:04 --> Model Class Initialized
INFO - 2018-04-08 21:06:07 --> Config Class Initialized
INFO - 2018-04-08 21:06:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:06:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:06:07 --> Utf8 Class Initialized
INFO - 2018-04-08 21:06:07 --> URI Class Initialized
INFO - 2018-04-08 21:06:07 --> Router Class Initialized
INFO - 2018-04-08 21:06:07 --> Output Class Initialized
INFO - 2018-04-08 21:06:07 --> Security Class Initialized
DEBUG - 2018-04-08 21:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:06:07 --> Input Class Initialized
INFO - 2018-04-08 21:06:07 --> Language Class Initialized
INFO - 2018-04-08 21:06:07 --> Loader Class Initialized
INFO - 2018-04-08 21:06:07 --> Helper loaded: common_helper
INFO - 2018-04-08 21:06:07 --> Database Driver Class Initialized
INFO - 2018-04-08 21:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:06:07 --> Email Class Initialized
INFO - 2018-04-08 21:06:07 --> Controller Class Initialized
INFO - 2018-04-08 21:06:07 --> Helper loaded: form_helper
INFO - 2018-04-08 21:06:07 --> Form Validation Class Initialized
INFO - 2018-04-08 21:06:07 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:06:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:06:07 --> Helper loaded: url_helper
INFO - 2018-04-08 21:06:07 --> Model Class Initialized
INFO - 2018-04-08 21:06:07 --> Model Class Initialized
INFO - 2018-04-08 21:06:07 --> Model Class Initialized
INFO - 2018-04-08 21:06:10 --> Config Class Initialized
INFO - 2018-04-08 21:06:10 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:06:10 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:06:10 --> Utf8 Class Initialized
INFO - 2018-04-08 21:06:10 --> URI Class Initialized
INFO - 2018-04-08 21:06:10 --> Router Class Initialized
INFO - 2018-04-08 21:06:10 --> Output Class Initialized
INFO - 2018-04-08 21:06:10 --> Security Class Initialized
DEBUG - 2018-04-08 21:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:06:10 --> Input Class Initialized
INFO - 2018-04-08 21:06:10 --> Language Class Initialized
INFO - 2018-04-08 21:06:11 --> Loader Class Initialized
INFO - 2018-04-08 21:06:11 --> Helper loaded: common_helper
INFO - 2018-04-08 21:06:11 --> Database Driver Class Initialized
INFO - 2018-04-08 21:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:06:11 --> Email Class Initialized
INFO - 2018-04-08 21:06:11 --> Controller Class Initialized
INFO - 2018-04-08 21:06:11 --> Helper loaded: form_helper
INFO - 2018-04-08 21:06:11 --> Form Validation Class Initialized
INFO - 2018-04-08 21:06:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:06:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:06:11 --> Helper loaded: url_helper
INFO - 2018-04-08 21:06:11 --> Model Class Initialized
INFO - 2018-04-08 21:06:11 --> Model Class Initialized
INFO - 2018-04-08 21:06:11 --> Model Class Initialized
INFO - 2018-04-08 21:07:13 --> Config Class Initialized
INFO - 2018-04-08 21:07:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:07:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:07:13 --> Utf8 Class Initialized
INFO - 2018-04-08 21:07:13 --> URI Class Initialized
INFO - 2018-04-08 21:07:13 --> Router Class Initialized
INFO - 2018-04-08 21:07:13 --> Output Class Initialized
INFO - 2018-04-08 21:07:13 --> Security Class Initialized
DEBUG - 2018-04-08 21:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:07:13 --> Input Class Initialized
INFO - 2018-04-08 21:07:13 --> Language Class Initialized
INFO - 2018-04-08 21:07:13 --> Loader Class Initialized
INFO - 2018-04-08 21:07:13 --> Helper loaded: common_helper
INFO - 2018-04-08 21:07:13 --> Database Driver Class Initialized
INFO - 2018-04-08 21:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:07:13 --> Email Class Initialized
INFO - 2018-04-08 21:07:13 --> Controller Class Initialized
INFO - 2018-04-08 21:07:13 --> Helper loaded: form_helper
INFO - 2018-04-08 21:07:13 --> Form Validation Class Initialized
INFO - 2018-04-08 21:07:13 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:07:13 --> Helper loaded: url_helper
INFO - 2018-04-08 21:07:13 --> Model Class Initialized
INFO - 2018-04-08 21:07:13 --> Model Class Initialized
INFO - 2018-04-08 21:07:13 --> Model Class Initialized
INFO - 2018-04-08 21:07:22 --> Config Class Initialized
INFO - 2018-04-08 21:07:22 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:07:22 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:07:22 --> Utf8 Class Initialized
INFO - 2018-04-08 21:07:22 --> URI Class Initialized
INFO - 2018-04-08 21:07:22 --> Router Class Initialized
INFO - 2018-04-08 21:07:22 --> Output Class Initialized
INFO - 2018-04-08 21:07:22 --> Security Class Initialized
DEBUG - 2018-04-08 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:07:22 --> Input Class Initialized
INFO - 2018-04-08 21:07:22 --> Language Class Initialized
INFO - 2018-04-08 21:07:22 --> Loader Class Initialized
INFO - 2018-04-08 21:07:22 --> Helper loaded: common_helper
INFO - 2018-04-08 21:07:22 --> Database Driver Class Initialized
INFO - 2018-04-08 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:07:22 --> Email Class Initialized
INFO - 2018-04-08 21:07:22 --> Controller Class Initialized
INFO - 2018-04-08 21:07:22 --> Helper loaded: form_helper
INFO - 2018-04-08 21:07:22 --> Form Validation Class Initialized
INFO - 2018-04-08 21:07:22 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:07:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:07:22 --> Helper loaded: url_helper
INFO - 2018-04-08 21:07:22 --> Model Class Initialized
INFO - 2018-04-08 21:07:22 --> Model Class Initialized
INFO - 2018-04-08 21:07:22 --> Model Class Initialized
INFO - 2018-04-08 21:07:26 --> Config Class Initialized
INFO - 2018-04-08 21:07:26 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:07:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:07:26 --> Utf8 Class Initialized
INFO - 2018-04-08 21:07:26 --> URI Class Initialized
INFO - 2018-04-08 21:07:26 --> Router Class Initialized
INFO - 2018-04-08 21:07:26 --> Output Class Initialized
INFO - 2018-04-08 21:07:26 --> Security Class Initialized
DEBUG - 2018-04-08 21:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:07:26 --> Input Class Initialized
INFO - 2018-04-08 21:07:26 --> Language Class Initialized
INFO - 2018-04-08 21:07:26 --> Loader Class Initialized
INFO - 2018-04-08 21:07:26 --> Helper loaded: common_helper
INFO - 2018-04-08 21:07:26 --> Database Driver Class Initialized
INFO - 2018-04-08 21:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:07:26 --> Email Class Initialized
INFO - 2018-04-08 21:07:26 --> Controller Class Initialized
INFO - 2018-04-08 21:07:26 --> Helper loaded: form_helper
INFO - 2018-04-08 21:07:26 --> Form Validation Class Initialized
INFO - 2018-04-08 21:07:26 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:07:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:07:26 --> Helper loaded: url_helper
INFO - 2018-04-08 21:07:26 --> Model Class Initialized
INFO - 2018-04-08 21:07:26 --> Model Class Initialized
INFO - 2018-04-08 21:07:26 --> Model Class Initialized
INFO - 2018-04-08 21:08:29 --> Config Class Initialized
INFO - 2018-04-08 21:08:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:08:30 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:08:30 --> Utf8 Class Initialized
INFO - 2018-04-08 21:08:30 --> URI Class Initialized
INFO - 2018-04-08 21:08:30 --> Router Class Initialized
INFO - 2018-04-08 21:08:30 --> Output Class Initialized
INFO - 2018-04-08 21:08:30 --> Security Class Initialized
DEBUG - 2018-04-08 21:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:08:30 --> Input Class Initialized
INFO - 2018-04-08 21:08:30 --> Language Class Initialized
INFO - 2018-04-08 21:08:30 --> Loader Class Initialized
INFO - 2018-04-08 21:08:30 --> Helper loaded: common_helper
INFO - 2018-04-08 21:08:30 --> Database Driver Class Initialized
INFO - 2018-04-08 21:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:08:30 --> Email Class Initialized
INFO - 2018-04-08 21:08:30 --> Controller Class Initialized
INFO - 2018-04-08 21:08:30 --> Helper loaded: form_helper
INFO - 2018-04-08 21:08:30 --> Form Validation Class Initialized
INFO - 2018-04-08 21:08:30 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:08:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:08:30 --> Helper loaded: url_helper
INFO - 2018-04-08 21:08:30 --> Model Class Initialized
INFO - 2018-04-08 21:08:30 --> Model Class Initialized
INFO - 2018-04-08 21:08:30 --> Model Class Initialized
INFO - 2018-04-08 21:12:07 --> Config Class Initialized
INFO - 2018-04-08 21:12:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:07 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:07 --> URI Class Initialized
INFO - 2018-04-08 21:12:07 --> Router Class Initialized
INFO - 2018-04-08 21:12:07 --> Output Class Initialized
INFO - 2018-04-08 21:12:07 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:07 --> Input Class Initialized
INFO - 2018-04-08 21:12:07 --> Language Class Initialized
INFO - 2018-04-08 21:12:07 --> Loader Class Initialized
INFO - 2018-04-08 21:12:07 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:07 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:07 --> Email Class Initialized
INFO - 2018-04-08 21:12:07 --> Controller Class Initialized
INFO - 2018-04-08 21:12:07 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:07 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:07 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:07 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:07 --> Model Class Initialized
INFO - 2018-04-08 21:12:07 --> Model Class Initialized
INFO - 2018-04-08 21:12:07 --> Model Class Initialized
INFO - 2018-04-08 21:12:12 --> Config Class Initialized
INFO - 2018-04-08 21:12:12 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:12 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:12 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:12 --> URI Class Initialized
INFO - 2018-04-08 21:12:12 --> Router Class Initialized
INFO - 2018-04-08 21:12:12 --> Output Class Initialized
INFO - 2018-04-08 21:12:12 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:13 --> Input Class Initialized
INFO - 2018-04-08 21:12:13 --> Language Class Initialized
INFO - 2018-04-08 21:12:13 --> Loader Class Initialized
INFO - 2018-04-08 21:12:13 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:13 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:13 --> Email Class Initialized
INFO - 2018-04-08 21:12:13 --> Controller Class Initialized
INFO - 2018-04-08 21:12:13 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:13 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:13 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:13 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:13 --> Model Class Initialized
INFO - 2018-04-08 21:12:13 --> Model Class Initialized
INFO - 2018-04-08 21:12:13 --> Model Class Initialized
INFO - 2018-04-08 21:12:16 --> Config Class Initialized
INFO - 2018-04-08 21:12:16 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:16 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:16 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:16 --> URI Class Initialized
INFO - 2018-04-08 21:12:16 --> Router Class Initialized
INFO - 2018-04-08 21:12:16 --> Output Class Initialized
INFO - 2018-04-08 21:12:16 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:16 --> Input Class Initialized
INFO - 2018-04-08 21:12:16 --> Language Class Initialized
INFO - 2018-04-08 21:12:16 --> Loader Class Initialized
INFO - 2018-04-08 21:12:16 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:16 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:16 --> Email Class Initialized
INFO - 2018-04-08 21:12:16 --> Controller Class Initialized
INFO - 2018-04-08 21:12:16 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:16 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:16 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:16 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:16 --> Model Class Initialized
INFO - 2018-04-08 21:12:16 --> Model Class Initialized
INFO - 2018-04-08 21:12:16 --> Model Class Initialized
INFO - 2018-04-08 21:12:20 --> Config Class Initialized
INFO - 2018-04-08 21:12:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:20 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:20 --> URI Class Initialized
INFO - 2018-04-08 21:12:20 --> Router Class Initialized
INFO - 2018-04-08 21:12:20 --> Output Class Initialized
INFO - 2018-04-08 21:12:20 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:20 --> Input Class Initialized
INFO - 2018-04-08 21:12:20 --> Language Class Initialized
INFO - 2018-04-08 21:12:20 --> Loader Class Initialized
INFO - 2018-04-08 21:12:20 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:20 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:20 --> Email Class Initialized
INFO - 2018-04-08 21:12:20 --> Controller Class Initialized
INFO - 2018-04-08 21:12:20 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:20 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:20 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:20 --> Model Class Initialized
INFO - 2018-04-08 21:12:20 --> Model Class Initialized
INFO - 2018-04-08 21:12:20 --> Model Class Initialized
INFO - 2018-04-08 21:12:23 --> Config Class Initialized
INFO - 2018-04-08 21:12:23 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:23 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:23 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:23 --> URI Class Initialized
INFO - 2018-04-08 21:12:23 --> Router Class Initialized
INFO - 2018-04-08 21:12:23 --> Output Class Initialized
INFO - 2018-04-08 21:12:23 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:23 --> Input Class Initialized
INFO - 2018-04-08 21:12:23 --> Language Class Initialized
INFO - 2018-04-08 21:12:23 --> Loader Class Initialized
INFO - 2018-04-08 21:12:23 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:23 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:23 --> Email Class Initialized
INFO - 2018-04-08 21:12:23 --> Controller Class Initialized
INFO - 2018-04-08 21:12:23 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:23 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:23 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:23 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:23 --> Model Class Initialized
INFO - 2018-04-08 21:12:23 --> Model Class Initialized
INFO - 2018-04-08 21:12:23 --> Model Class Initialized
INFO - 2018-04-08 21:12:25 --> Config Class Initialized
INFO - 2018-04-08 21:12:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:26 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:26 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:26 --> URI Class Initialized
INFO - 2018-04-08 21:12:26 --> Router Class Initialized
INFO - 2018-04-08 21:12:26 --> Output Class Initialized
INFO - 2018-04-08 21:12:26 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:26 --> Input Class Initialized
INFO - 2018-04-08 21:12:26 --> Language Class Initialized
INFO - 2018-04-08 21:12:26 --> Loader Class Initialized
INFO - 2018-04-08 21:12:26 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:26 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:26 --> Email Class Initialized
INFO - 2018-04-08 21:12:26 --> Controller Class Initialized
INFO - 2018-04-08 21:12:26 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:26 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:26 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:26 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:26 --> Model Class Initialized
INFO - 2018-04-08 21:12:26 --> Model Class Initialized
INFO - 2018-04-08 21:12:26 --> Model Class Initialized
INFO - 2018-04-08 21:12:33 --> Config Class Initialized
INFO - 2018-04-08 21:12:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:33 --> URI Class Initialized
INFO - 2018-04-08 21:12:33 --> Router Class Initialized
INFO - 2018-04-08 21:12:33 --> Output Class Initialized
INFO - 2018-04-08 21:12:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:33 --> Input Class Initialized
INFO - 2018-04-08 21:12:33 --> Language Class Initialized
INFO - 2018-04-08 21:12:33 --> Loader Class Initialized
INFO - 2018-04-08 21:12:33 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:33 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:33 --> Email Class Initialized
INFO - 2018-04-08 21:12:33 --> Controller Class Initialized
INFO - 2018-04-08 21:12:33 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:33 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:33 --> Model Class Initialized
INFO - 2018-04-08 21:12:33 --> Model Class Initialized
INFO - 2018-04-08 21:12:33 --> Model Class Initialized
INFO - 2018-04-08 21:12:36 --> Config Class Initialized
INFO - 2018-04-08 21:12:36 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:36 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:36 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:36 --> URI Class Initialized
INFO - 2018-04-08 21:12:36 --> Router Class Initialized
INFO - 2018-04-08 21:12:36 --> Output Class Initialized
INFO - 2018-04-08 21:12:36 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:36 --> Input Class Initialized
INFO - 2018-04-08 21:12:36 --> Language Class Initialized
INFO - 2018-04-08 21:12:36 --> Loader Class Initialized
INFO - 2018-04-08 21:12:36 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:36 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:36 --> Email Class Initialized
INFO - 2018-04-08 21:12:36 --> Controller Class Initialized
INFO - 2018-04-08 21:12:36 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:36 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:36 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:36 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:36 --> Model Class Initialized
INFO - 2018-04-08 21:12:36 --> Model Class Initialized
INFO - 2018-04-08 21:12:36 --> Model Class Initialized
INFO - 2018-04-08 21:12:39 --> Config Class Initialized
INFO - 2018-04-08 21:12:39 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:39 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:39 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:39 --> URI Class Initialized
INFO - 2018-04-08 21:12:39 --> Router Class Initialized
INFO - 2018-04-08 21:12:39 --> Output Class Initialized
INFO - 2018-04-08 21:12:39 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:39 --> Input Class Initialized
INFO - 2018-04-08 21:12:39 --> Language Class Initialized
INFO - 2018-04-08 21:12:39 --> Loader Class Initialized
INFO - 2018-04-08 21:12:39 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:39 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:39 --> Email Class Initialized
INFO - 2018-04-08 21:12:39 --> Controller Class Initialized
INFO - 2018-04-08 21:12:39 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:39 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:39 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:39 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:39 --> Model Class Initialized
INFO - 2018-04-08 21:12:39 --> Model Class Initialized
INFO - 2018-04-08 21:12:39 --> Model Class Initialized
INFO - 2018-04-08 21:12:42 --> Config Class Initialized
INFO - 2018-04-08 21:12:42 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:42 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:42 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:42 --> URI Class Initialized
INFO - 2018-04-08 21:12:42 --> Router Class Initialized
INFO - 2018-04-08 21:12:42 --> Output Class Initialized
INFO - 2018-04-08 21:12:42 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:42 --> Input Class Initialized
INFO - 2018-04-08 21:12:42 --> Language Class Initialized
INFO - 2018-04-08 21:12:42 --> Loader Class Initialized
INFO - 2018-04-08 21:12:42 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:42 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:42 --> Email Class Initialized
INFO - 2018-04-08 21:12:42 --> Controller Class Initialized
INFO - 2018-04-08 21:12:42 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:42 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:42 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:42 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:42 --> Model Class Initialized
INFO - 2018-04-08 21:12:42 --> Model Class Initialized
INFO - 2018-04-08 21:12:42 --> Model Class Initialized
INFO - 2018-04-08 21:12:45 --> Config Class Initialized
INFO - 2018-04-08 21:12:45 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:45 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:45 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:45 --> URI Class Initialized
INFO - 2018-04-08 21:12:45 --> Router Class Initialized
INFO - 2018-04-08 21:12:45 --> Output Class Initialized
INFO - 2018-04-08 21:12:45 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:45 --> Input Class Initialized
INFO - 2018-04-08 21:12:45 --> Language Class Initialized
INFO - 2018-04-08 21:12:45 --> Loader Class Initialized
INFO - 2018-04-08 21:12:45 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:45 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:46 --> Email Class Initialized
INFO - 2018-04-08 21:12:46 --> Controller Class Initialized
INFO - 2018-04-08 21:12:46 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:46 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:46 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:46 --> Model Class Initialized
INFO - 2018-04-08 21:12:46 --> Model Class Initialized
INFO - 2018-04-08 21:12:46 --> Model Class Initialized
INFO - 2018-04-08 21:12:56 --> Config Class Initialized
INFO - 2018-04-08 21:12:56 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:12:56 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:12:56 --> Utf8 Class Initialized
INFO - 2018-04-08 21:12:56 --> URI Class Initialized
INFO - 2018-04-08 21:12:56 --> Router Class Initialized
INFO - 2018-04-08 21:12:56 --> Output Class Initialized
INFO - 2018-04-08 21:12:56 --> Security Class Initialized
DEBUG - 2018-04-08 21:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:12:56 --> Input Class Initialized
INFO - 2018-04-08 21:12:56 --> Language Class Initialized
INFO - 2018-04-08 21:12:56 --> Loader Class Initialized
INFO - 2018-04-08 21:12:56 --> Helper loaded: common_helper
INFO - 2018-04-08 21:12:56 --> Database Driver Class Initialized
INFO - 2018-04-08 21:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:12:56 --> Email Class Initialized
INFO - 2018-04-08 21:12:56 --> Controller Class Initialized
INFO - 2018-04-08 21:12:56 --> Helper loaded: form_helper
INFO - 2018-04-08 21:12:56 --> Form Validation Class Initialized
INFO - 2018-04-08 21:12:56 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:12:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:12:56 --> Helper loaded: url_helper
INFO - 2018-04-08 21:12:56 --> Model Class Initialized
INFO - 2018-04-08 21:12:56 --> Model Class Initialized
INFO - 2018-04-08 21:12:56 --> Model Class Initialized
INFO - 2018-04-08 21:13:02 --> Config Class Initialized
INFO - 2018-04-08 21:13:02 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:13:02 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:13:02 --> Utf8 Class Initialized
INFO - 2018-04-08 21:13:02 --> URI Class Initialized
INFO - 2018-04-08 21:13:02 --> Router Class Initialized
INFO - 2018-04-08 21:13:02 --> Output Class Initialized
INFO - 2018-04-08 21:13:02 --> Security Class Initialized
DEBUG - 2018-04-08 21:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:13:02 --> Input Class Initialized
INFO - 2018-04-08 21:13:02 --> Language Class Initialized
INFO - 2018-04-08 21:13:02 --> Loader Class Initialized
INFO - 2018-04-08 21:13:02 --> Helper loaded: common_helper
INFO - 2018-04-08 21:13:02 --> Database Driver Class Initialized
INFO - 2018-04-08 21:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:13:02 --> Email Class Initialized
INFO - 2018-04-08 21:13:02 --> Controller Class Initialized
INFO - 2018-04-08 21:13:02 --> Helper loaded: form_helper
INFO - 2018-04-08 21:13:02 --> Form Validation Class Initialized
INFO - 2018-04-08 21:13:02 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:13:02 --> Helper loaded: url_helper
INFO - 2018-04-08 21:13:02 --> Model Class Initialized
INFO - 2018-04-08 21:13:02 --> Model Class Initialized
INFO - 2018-04-08 21:13:02 --> Model Class Initialized
INFO - 2018-04-08 21:13:05 --> Config Class Initialized
INFO - 2018-04-08 21:13:05 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:13:05 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:13:05 --> Utf8 Class Initialized
INFO - 2018-04-08 21:13:05 --> URI Class Initialized
INFO - 2018-04-08 21:13:05 --> Router Class Initialized
INFO - 2018-04-08 21:13:05 --> Output Class Initialized
INFO - 2018-04-08 21:13:05 --> Security Class Initialized
DEBUG - 2018-04-08 21:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:13:05 --> Input Class Initialized
INFO - 2018-04-08 21:13:05 --> Language Class Initialized
INFO - 2018-04-08 21:13:05 --> Loader Class Initialized
INFO - 2018-04-08 21:13:05 --> Helper loaded: common_helper
INFO - 2018-04-08 21:13:05 --> Database Driver Class Initialized
INFO - 2018-04-08 21:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:13:05 --> Email Class Initialized
INFO - 2018-04-08 21:13:05 --> Controller Class Initialized
INFO - 2018-04-08 21:13:05 --> Helper loaded: form_helper
INFO - 2018-04-08 21:13:05 --> Form Validation Class Initialized
INFO - 2018-04-08 21:13:05 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:13:05 --> Helper loaded: url_helper
INFO - 2018-04-08 21:13:05 --> Model Class Initialized
INFO - 2018-04-08 21:13:05 --> Model Class Initialized
INFO - 2018-04-08 21:13:05 --> Model Class Initialized
INFO - 2018-04-08 21:18:06 --> Config Class Initialized
INFO - 2018-04-08 21:18:06 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:18:06 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:18:06 --> Utf8 Class Initialized
INFO - 2018-04-08 21:18:06 --> URI Class Initialized
INFO - 2018-04-08 21:18:06 --> Router Class Initialized
INFO - 2018-04-08 21:18:06 --> Output Class Initialized
INFO - 2018-04-08 21:18:06 --> Security Class Initialized
DEBUG - 2018-04-08 21:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:18:06 --> Input Class Initialized
INFO - 2018-04-08 21:18:06 --> Language Class Initialized
INFO - 2018-04-08 21:18:06 --> Loader Class Initialized
INFO - 2018-04-08 21:18:06 --> Helper loaded: common_helper
INFO - 2018-04-08 21:18:06 --> Database Driver Class Initialized
INFO - 2018-04-08 21:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:18:06 --> Email Class Initialized
INFO - 2018-04-08 21:18:06 --> Controller Class Initialized
INFO - 2018-04-08 21:18:06 --> Helper loaded: form_helper
INFO - 2018-04-08 21:18:06 --> Form Validation Class Initialized
INFO - 2018-04-08 21:18:06 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:18:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:18:06 --> Helper loaded: url_helper
INFO - 2018-04-08 21:18:06 --> Model Class Initialized
INFO - 2018-04-08 21:18:06 --> Model Class Initialized
INFO - 2018-04-08 21:18:06 --> Model Class Initialized
INFO - 2018-04-08 21:18:19 --> Config Class Initialized
INFO - 2018-04-08 21:18:19 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:18:19 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:18:19 --> Utf8 Class Initialized
INFO - 2018-04-08 21:18:19 --> URI Class Initialized
INFO - 2018-04-08 21:18:19 --> Router Class Initialized
INFO - 2018-04-08 21:18:19 --> Output Class Initialized
INFO - 2018-04-08 21:18:19 --> Security Class Initialized
DEBUG - 2018-04-08 21:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:18:19 --> Input Class Initialized
INFO - 2018-04-08 21:18:19 --> Language Class Initialized
INFO - 2018-04-08 21:18:19 --> Loader Class Initialized
INFO - 2018-04-08 21:18:19 --> Helper loaded: common_helper
INFO - 2018-04-08 21:18:19 --> Database Driver Class Initialized
INFO - 2018-04-08 21:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:18:19 --> Email Class Initialized
INFO - 2018-04-08 21:18:19 --> Controller Class Initialized
INFO - 2018-04-08 21:18:19 --> Helper loaded: form_helper
INFO - 2018-04-08 21:18:19 --> Form Validation Class Initialized
INFO - 2018-04-08 21:18:19 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:18:19 --> Helper loaded: url_helper
INFO - 2018-04-08 21:18:19 --> Model Class Initialized
INFO - 2018-04-08 21:18:19 --> Model Class Initialized
INFO - 2018-04-08 21:18:19 --> Model Class Initialized
INFO - 2018-04-08 21:18:27 --> Config Class Initialized
INFO - 2018-04-08 21:18:27 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:18:27 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:18:27 --> Utf8 Class Initialized
INFO - 2018-04-08 21:18:27 --> URI Class Initialized
INFO - 2018-04-08 21:18:27 --> Router Class Initialized
INFO - 2018-04-08 21:18:27 --> Output Class Initialized
INFO - 2018-04-08 21:18:27 --> Security Class Initialized
DEBUG - 2018-04-08 21:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:18:27 --> Input Class Initialized
INFO - 2018-04-08 21:18:27 --> Language Class Initialized
INFO - 2018-04-08 21:18:27 --> Loader Class Initialized
INFO - 2018-04-08 21:18:27 --> Helper loaded: common_helper
INFO - 2018-04-08 21:18:27 --> Database Driver Class Initialized
INFO - 2018-04-08 21:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:18:27 --> Email Class Initialized
INFO - 2018-04-08 21:18:27 --> Controller Class Initialized
INFO - 2018-04-08 21:18:27 --> Helper loaded: form_helper
INFO - 2018-04-08 21:18:27 --> Form Validation Class Initialized
INFO - 2018-04-08 21:18:27 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:18:27 --> Helper loaded: url_helper
INFO - 2018-04-08 21:18:27 --> Model Class Initialized
INFO - 2018-04-08 21:18:27 --> Model Class Initialized
INFO - 2018-04-08 21:18:27 --> Model Class Initialized
INFO - 2018-04-08 21:18:31 --> Config Class Initialized
INFO - 2018-04-08 21:18:31 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:18:31 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:18:31 --> Utf8 Class Initialized
INFO - 2018-04-08 21:18:31 --> URI Class Initialized
INFO - 2018-04-08 21:18:31 --> Router Class Initialized
INFO - 2018-04-08 21:18:31 --> Output Class Initialized
INFO - 2018-04-08 21:18:31 --> Security Class Initialized
DEBUG - 2018-04-08 21:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:18:31 --> Input Class Initialized
INFO - 2018-04-08 21:18:31 --> Language Class Initialized
INFO - 2018-04-08 21:18:31 --> Loader Class Initialized
INFO - 2018-04-08 21:18:31 --> Helper loaded: common_helper
INFO - 2018-04-08 21:18:31 --> Database Driver Class Initialized
INFO - 2018-04-08 21:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:18:31 --> Email Class Initialized
INFO - 2018-04-08 21:18:31 --> Controller Class Initialized
INFO - 2018-04-08 21:18:31 --> Helper loaded: form_helper
INFO - 2018-04-08 21:18:31 --> Form Validation Class Initialized
INFO - 2018-04-08 21:18:31 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:18:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:18:31 --> Helper loaded: url_helper
INFO - 2018-04-08 21:18:31 --> Model Class Initialized
INFO - 2018-04-08 21:18:31 --> Model Class Initialized
INFO - 2018-04-08 21:18:31 --> Model Class Initialized
INFO - 2018-04-08 21:19:15 --> Config Class Initialized
INFO - 2018-04-08 21:19:15 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:19:15 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:19:15 --> Utf8 Class Initialized
INFO - 2018-04-08 21:19:15 --> URI Class Initialized
INFO - 2018-04-08 21:19:15 --> Router Class Initialized
INFO - 2018-04-08 21:19:15 --> Output Class Initialized
INFO - 2018-04-08 21:19:15 --> Security Class Initialized
DEBUG - 2018-04-08 21:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:19:15 --> Input Class Initialized
INFO - 2018-04-08 21:19:15 --> Language Class Initialized
INFO - 2018-04-08 21:19:15 --> Loader Class Initialized
INFO - 2018-04-08 21:19:15 --> Helper loaded: common_helper
INFO - 2018-04-08 21:19:15 --> Database Driver Class Initialized
INFO - 2018-04-08 21:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:19:15 --> Email Class Initialized
INFO - 2018-04-08 21:19:15 --> Controller Class Initialized
INFO - 2018-04-08 21:19:15 --> Helper loaded: form_helper
INFO - 2018-04-08 21:19:15 --> Form Validation Class Initialized
INFO - 2018-04-08 21:19:15 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:19:15 --> Helper loaded: url_helper
INFO - 2018-04-08 21:19:15 --> Model Class Initialized
INFO - 2018-04-08 21:19:15 --> Model Class Initialized
INFO - 2018-04-08 21:19:15 --> Model Class Initialized
INFO - 2018-04-08 21:19:24 --> Config Class Initialized
INFO - 2018-04-08 21:19:24 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:19:24 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:19:24 --> Utf8 Class Initialized
INFO - 2018-04-08 21:19:24 --> URI Class Initialized
INFO - 2018-04-08 21:19:24 --> Router Class Initialized
INFO - 2018-04-08 21:19:24 --> Output Class Initialized
INFO - 2018-04-08 21:19:24 --> Security Class Initialized
DEBUG - 2018-04-08 21:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:19:24 --> Input Class Initialized
INFO - 2018-04-08 21:19:24 --> Language Class Initialized
INFO - 2018-04-08 21:19:24 --> Loader Class Initialized
INFO - 2018-04-08 21:19:24 --> Helper loaded: common_helper
INFO - 2018-04-08 21:19:24 --> Database Driver Class Initialized
INFO - 2018-04-08 21:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:19:24 --> Email Class Initialized
INFO - 2018-04-08 21:19:24 --> Controller Class Initialized
INFO - 2018-04-08 21:19:24 --> Helper loaded: form_helper
INFO - 2018-04-08 21:19:24 --> Form Validation Class Initialized
INFO - 2018-04-08 21:19:24 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:19:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:19:24 --> Helper loaded: url_helper
INFO - 2018-04-08 21:19:24 --> Model Class Initialized
INFO - 2018-04-08 21:19:24 --> Model Class Initialized
INFO - 2018-04-08 21:19:24 --> Model Class Initialized
INFO - 2018-04-08 21:19:29 --> Config Class Initialized
INFO - 2018-04-08 21:19:29 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:19:29 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:19:29 --> Utf8 Class Initialized
INFO - 2018-04-08 21:19:29 --> URI Class Initialized
INFO - 2018-04-08 21:19:29 --> Router Class Initialized
INFO - 2018-04-08 21:19:29 --> Output Class Initialized
INFO - 2018-04-08 21:19:29 --> Security Class Initialized
DEBUG - 2018-04-08 21:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:19:29 --> Input Class Initialized
INFO - 2018-04-08 21:19:29 --> Language Class Initialized
INFO - 2018-04-08 21:19:29 --> Loader Class Initialized
INFO - 2018-04-08 21:19:29 --> Helper loaded: common_helper
INFO - 2018-04-08 21:19:29 --> Database Driver Class Initialized
INFO - 2018-04-08 21:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:19:29 --> Email Class Initialized
INFO - 2018-04-08 21:19:29 --> Controller Class Initialized
INFO - 2018-04-08 21:19:29 --> Helper loaded: form_helper
INFO - 2018-04-08 21:19:29 --> Form Validation Class Initialized
INFO - 2018-04-08 21:19:29 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:19:29 --> Helper loaded: url_helper
INFO - 2018-04-08 21:19:29 --> Model Class Initialized
INFO - 2018-04-08 21:19:29 --> Model Class Initialized
INFO - 2018-04-08 21:19:29 --> Model Class Initialized
INFO - 2018-04-08 21:19:40 --> Config Class Initialized
INFO - 2018-04-08 21:19:40 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:19:40 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:19:40 --> Utf8 Class Initialized
INFO - 2018-04-08 21:19:40 --> URI Class Initialized
INFO - 2018-04-08 21:19:40 --> Router Class Initialized
INFO - 2018-04-08 21:19:40 --> Output Class Initialized
INFO - 2018-04-08 21:19:40 --> Security Class Initialized
DEBUG - 2018-04-08 21:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:19:40 --> Input Class Initialized
INFO - 2018-04-08 21:19:40 --> Language Class Initialized
INFO - 2018-04-08 21:19:40 --> Loader Class Initialized
INFO - 2018-04-08 21:19:40 --> Helper loaded: common_helper
INFO - 2018-04-08 21:19:40 --> Database Driver Class Initialized
INFO - 2018-04-08 21:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:19:40 --> Email Class Initialized
INFO - 2018-04-08 21:19:40 --> Controller Class Initialized
INFO - 2018-04-08 21:19:40 --> Helper loaded: form_helper
INFO - 2018-04-08 21:19:40 --> Form Validation Class Initialized
INFO - 2018-04-08 21:19:40 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:19:40 --> Helper loaded: url_helper
INFO - 2018-04-08 21:19:40 --> Model Class Initialized
INFO - 2018-04-08 21:19:40 --> Model Class Initialized
INFO - 2018-04-08 21:19:40 --> Model Class Initialized
INFO - 2018-04-08 21:19:51 --> Config Class Initialized
INFO - 2018-04-08 21:19:51 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:19:51 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:19:51 --> Utf8 Class Initialized
INFO - 2018-04-08 21:19:51 --> URI Class Initialized
INFO - 2018-04-08 21:19:51 --> Router Class Initialized
INFO - 2018-04-08 21:19:51 --> Output Class Initialized
INFO - 2018-04-08 21:19:51 --> Security Class Initialized
DEBUG - 2018-04-08 21:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:19:51 --> Input Class Initialized
INFO - 2018-04-08 21:19:51 --> Language Class Initialized
INFO - 2018-04-08 21:19:51 --> Loader Class Initialized
INFO - 2018-04-08 21:19:51 --> Helper loaded: common_helper
INFO - 2018-04-08 21:19:51 --> Database Driver Class Initialized
INFO - 2018-04-08 21:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:19:51 --> Email Class Initialized
INFO - 2018-04-08 21:19:51 --> Controller Class Initialized
INFO - 2018-04-08 21:19:51 --> Helper loaded: form_helper
INFO - 2018-04-08 21:19:51 --> Form Validation Class Initialized
INFO - 2018-04-08 21:19:51 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:19:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:19:51 --> Helper loaded: url_helper
INFO - 2018-04-08 21:19:51 --> Model Class Initialized
INFO - 2018-04-08 21:19:51 --> Model Class Initialized
INFO - 2018-04-08 21:19:51 --> Model Class Initialized
INFO - 2018-04-08 21:20:11 --> Config Class Initialized
INFO - 2018-04-08 21:20:11 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:11 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:11 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:11 --> URI Class Initialized
INFO - 2018-04-08 21:20:11 --> Router Class Initialized
INFO - 2018-04-08 21:20:11 --> Output Class Initialized
INFO - 2018-04-08 21:20:11 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:11 --> Input Class Initialized
INFO - 2018-04-08 21:20:11 --> Language Class Initialized
INFO - 2018-04-08 21:20:11 --> Loader Class Initialized
INFO - 2018-04-08 21:20:11 --> Helper loaded: common_helper
INFO - 2018-04-08 21:20:11 --> Database Driver Class Initialized
INFO - 2018-04-08 21:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:11 --> Email Class Initialized
INFO - 2018-04-08 21:20:11 --> Controller Class Initialized
INFO - 2018-04-08 21:20:11 --> Helper loaded: form_helper
INFO - 2018-04-08 21:20:11 --> Form Validation Class Initialized
INFO - 2018-04-08 21:20:11 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:20:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:20:11 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:11 --> Model Class Initialized
INFO - 2018-04-08 21:20:11 --> Model Class Initialized
INFO - 2018-04-08 21:20:11 --> Model Class Initialized
INFO - 2018-04-08 21:20:17 --> Config Class Initialized
INFO - 2018-04-08 21:20:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:17 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:17 --> URI Class Initialized
INFO - 2018-04-08 21:20:17 --> Router Class Initialized
INFO - 2018-04-08 21:20:17 --> Output Class Initialized
INFO - 2018-04-08 21:20:17 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:17 --> Input Class Initialized
INFO - 2018-04-08 21:20:17 --> Language Class Initialized
INFO - 2018-04-08 21:20:17 --> Loader Class Initialized
INFO - 2018-04-08 21:20:17 --> Helper loaded: common_helper
INFO - 2018-04-08 21:20:17 --> Database Driver Class Initialized
INFO - 2018-04-08 21:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:17 --> Email Class Initialized
INFO - 2018-04-08 21:20:17 --> Controller Class Initialized
INFO - 2018-04-08 21:20:17 --> Helper loaded: form_helper
INFO - 2018-04-08 21:20:17 --> Form Validation Class Initialized
INFO - 2018-04-08 21:20:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:20:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:20:17 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:17 --> Model Class Initialized
INFO - 2018-04-08 21:20:17 --> Model Class Initialized
INFO - 2018-04-08 21:20:17 --> Model Class Initialized
INFO - 2018-04-08 21:20:20 --> Config Class Initialized
INFO - 2018-04-08 21:20:20 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:20 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:20 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:20 --> URI Class Initialized
INFO - 2018-04-08 21:20:20 --> Router Class Initialized
INFO - 2018-04-08 21:20:20 --> Output Class Initialized
INFO - 2018-04-08 21:20:20 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:20 --> Input Class Initialized
INFO - 2018-04-08 21:20:20 --> Language Class Initialized
INFO - 2018-04-08 21:20:20 --> Loader Class Initialized
INFO - 2018-04-08 21:20:20 --> Helper loaded: common_helper
INFO - 2018-04-08 21:20:20 --> Database Driver Class Initialized
INFO - 2018-04-08 21:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:20 --> Email Class Initialized
INFO - 2018-04-08 21:20:20 --> Controller Class Initialized
INFO - 2018-04-08 21:20:20 --> Helper loaded: form_helper
INFO - 2018-04-08 21:20:20 --> Form Validation Class Initialized
INFO - 2018-04-08 21:20:20 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:20:20 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:20 --> Model Class Initialized
INFO - 2018-04-08 21:20:20 --> Model Class Initialized
INFO - 2018-04-08 21:20:20 --> Model Class Initialized
INFO - 2018-04-08 21:20:33 --> Config Class Initialized
INFO - 2018-04-08 21:20:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:20:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:20:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:20:33 --> URI Class Initialized
INFO - 2018-04-08 21:20:33 --> Router Class Initialized
INFO - 2018-04-08 21:20:33 --> Output Class Initialized
INFO - 2018-04-08 21:20:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:20:33 --> Input Class Initialized
INFO - 2018-04-08 21:20:33 --> Language Class Initialized
INFO - 2018-04-08 21:20:33 --> Loader Class Initialized
INFO - 2018-04-08 21:20:33 --> Helper loaded: common_helper
INFO - 2018-04-08 21:20:33 --> Database Driver Class Initialized
INFO - 2018-04-08 21:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:20:33 --> Email Class Initialized
INFO - 2018-04-08 21:20:33 --> Controller Class Initialized
INFO - 2018-04-08 21:20:33 --> Helper loaded: form_helper
INFO - 2018-04-08 21:20:33 --> Form Validation Class Initialized
INFO - 2018-04-08 21:20:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:20:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:20:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:20:33 --> Model Class Initialized
INFO - 2018-04-08 21:20:33 --> Model Class Initialized
INFO - 2018-04-08 21:20:33 --> Model Class Initialized
INFO - 2018-04-08 21:21:07 --> Config Class Initialized
INFO - 2018-04-08 21:21:07 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:21:07 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:21:07 --> Utf8 Class Initialized
INFO - 2018-04-08 21:21:07 --> URI Class Initialized
INFO - 2018-04-08 21:21:07 --> Router Class Initialized
INFO - 2018-04-08 21:21:07 --> Output Class Initialized
INFO - 2018-04-08 21:21:07 --> Security Class Initialized
DEBUG - 2018-04-08 21:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:21:07 --> Input Class Initialized
INFO - 2018-04-08 21:21:07 --> Language Class Initialized
INFO - 2018-04-08 21:21:07 --> Loader Class Initialized
INFO - 2018-04-08 21:21:07 --> Helper loaded: common_helper
INFO - 2018-04-08 21:21:07 --> Database Driver Class Initialized
INFO - 2018-04-08 21:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:21:08 --> Email Class Initialized
INFO - 2018-04-08 21:21:08 --> Controller Class Initialized
INFO - 2018-04-08 21:21:08 --> Helper loaded: form_helper
INFO - 2018-04-08 21:21:08 --> Form Validation Class Initialized
INFO - 2018-04-08 21:21:08 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:21:08 --> Helper loaded: url_helper
INFO - 2018-04-08 21:21:08 --> Model Class Initialized
INFO - 2018-04-08 21:21:08 --> Model Class Initialized
INFO - 2018-04-08 21:21:08 --> Model Class Initialized
INFO - 2018-04-08 21:21:13 --> Config Class Initialized
INFO - 2018-04-08 21:21:13 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:21:13 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:21:13 --> Utf8 Class Initialized
INFO - 2018-04-08 21:21:13 --> URI Class Initialized
INFO - 2018-04-08 21:21:13 --> Router Class Initialized
INFO - 2018-04-08 21:21:13 --> Output Class Initialized
INFO - 2018-04-08 21:21:13 --> Security Class Initialized
DEBUG - 2018-04-08 21:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:21:13 --> Input Class Initialized
INFO - 2018-04-08 21:21:13 --> Language Class Initialized
INFO - 2018-04-08 21:21:13 --> Loader Class Initialized
INFO - 2018-04-08 21:21:13 --> Helper loaded: common_helper
INFO - 2018-04-08 21:21:13 --> Database Driver Class Initialized
INFO - 2018-04-08 21:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:21:13 --> Email Class Initialized
INFO - 2018-04-08 21:21:13 --> Controller Class Initialized
INFO - 2018-04-08 21:21:13 --> Helper loaded: form_helper
INFO - 2018-04-08 21:21:13 --> Form Validation Class Initialized
INFO - 2018-04-08 21:21:13 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:21:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:21:13 --> Helper loaded: url_helper
INFO - 2018-04-08 21:21:13 --> Model Class Initialized
INFO - 2018-04-08 21:21:13 --> Model Class Initialized
INFO - 2018-04-08 21:21:13 --> Model Class Initialized
INFO - 2018-04-08 21:21:17 --> Config Class Initialized
INFO - 2018-04-08 21:21:17 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:21:17 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:21:17 --> Utf8 Class Initialized
INFO - 2018-04-08 21:21:17 --> URI Class Initialized
INFO - 2018-04-08 21:21:17 --> Router Class Initialized
INFO - 2018-04-08 21:21:17 --> Output Class Initialized
INFO - 2018-04-08 21:21:17 --> Security Class Initialized
DEBUG - 2018-04-08 21:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:21:17 --> Input Class Initialized
INFO - 2018-04-08 21:21:17 --> Language Class Initialized
INFO - 2018-04-08 21:21:17 --> Loader Class Initialized
INFO - 2018-04-08 21:21:17 --> Helper loaded: common_helper
INFO - 2018-04-08 21:21:17 --> Database Driver Class Initialized
INFO - 2018-04-08 21:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:21:17 --> Email Class Initialized
INFO - 2018-04-08 21:21:17 --> Controller Class Initialized
INFO - 2018-04-08 21:21:17 --> Helper loaded: form_helper
INFO - 2018-04-08 21:21:17 --> Form Validation Class Initialized
INFO - 2018-04-08 21:21:17 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:21:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:21:17 --> Helper loaded: url_helper
INFO - 2018-04-08 21:21:17 --> Model Class Initialized
INFO - 2018-04-08 21:21:17 --> Model Class Initialized
INFO - 2018-04-08 21:21:17 --> Model Class Initialized
INFO - 2018-04-08 21:22:44 --> Config Class Initialized
INFO - 2018-04-08 21:22:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:22:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:22:44 --> Utf8 Class Initialized
INFO - 2018-04-08 21:22:44 --> URI Class Initialized
INFO - 2018-04-08 21:22:44 --> Router Class Initialized
INFO - 2018-04-08 21:22:44 --> Output Class Initialized
INFO - 2018-04-08 21:22:44 --> Security Class Initialized
DEBUG - 2018-04-08 21:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:22:44 --> Input Class Initialized
INFO - 2018-04-08 21:22:44 --> Language Class Initialized
INFO - 2018-04-08 21:22:44 --> Loader Class Initialized
INFO - 2018-04-08 21:22:44 --> Helper loaded: common_helper
INFO - 2018-04-08 21:22:44 --> Database Driver Class Initialized
INFO - 2018-04-08 21:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:22:44 --> Email Class Initialized
INFO - 2018-04-08 21:22:44 --> Controller Class Initialized
INFO - 2018-04-08 21:22:44 --> Helper loaded: form_helper
INFO - 2018-04-08 21:22:44 --> Form Validation Class Initialized
INFO - 2018-04-08 21:22:44 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:22:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:22:44 --> Helper loaded: url_helper
INFO - 2018-04-08 21:22:44 --> Model Class Initialized
INFO - 2018-04-08 21:22:44 --> Model Class Initialized
INFO - 2018-04-08 21:22:44 --> Model Class Initialized
INFO - 2018-04-08 21:22:59 --> Config Class Initialized
INFO - 2018-04-08 21:22:59 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:22:59 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:22:59 --> Utf8 Class Initialized
INFO - 2018-04-08 21:22:59 --> URI Class Initialized
INFO - 2018-04-08 21:22:59 --> Router Class Initialized
INFO - 2018-04-08 21:22:59 --> Output Class Initialized
INFO - 2018-04-08 21:22:59 --> Security Class Initialized
DEBUG - 2018-04-08 21:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:22:59 --> Input Class Initialized
INFO - 2018-04-08 21:22:59 --> Language Class Initialized
INFO - 2018-04-08 21:22:59 --> Loader Class Initialized
INFO - 2018-04-08 21:22:59 --> Helper loaded: common_helper
INFO - 2018-04-08 21:22:59 --> Database Driver Class Initialized
INFO - 2018-04-08 21:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:22:59 --> Email Class Initialized
INFO - 2018-04-08 21:22:59 --> Controller Class Initialized
INFO - 2018-04-08 21:22:59 --> Helper loaded: form_helper
INFO - 2018-04-08 21:22:59 --> Form Validation Class Initialized
INFO - 2018-04-08 21:22:59 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:22:59 --> Helper loaded: url_helper
INFO - 2018-04-08 21:22:59 --> Model Class Initialized
INFO - 2018-04-08 21:22:59 --> Model Class Initialized
INFO - 2018-04-08 21:22:59 --> Model Class Initialized
INFO - 2018-04-08 21:23:08 --> Config Class Initialized
INFO - 2018-04-08 21:23:08 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:23:08 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:23:08 --> Utf8 Class Initialized
INFO - 2018-04-08 21:23:08 --> URI Class Initialized
INFO - 2018-04-08 21:23:08 --> Router Class Initialized
INFO - 2018-04-08 21:23:08 --> Output Class Initialized
INFO - 2018-04-08 21:23:08 --> Security Class Initialized
DEBUG - 2018-04-08 21:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:23:08 --> Input Class Initialized
INFO - 2018-04-08 21:23:08 --> Language Class Initialized
INFO - 2018-04-08 21:23:08 --> Loader Class Initialized
INFO - 2018-04-08 21:23:08 --> Helper loaded: common_helper
INFO - 2018-04-08 21:23:08 --> Database Driver Class Initialized
INFO - 2018-04-08 21:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:23:08 --> Email Class Initialized
INFO - 2018-04-08 21:23:08 --> Controller Class Initialized
INFO - 2018-04-08 21:23:08 --> Helper loaded: form_helper
INFO - 2018-04-08 21:23:08 --> Form Validation Class Initialized
INFO - 2018-04-08 21:23:08 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:23:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:23:08 --> Helper loaded: url_helper
INFO - 2018-04-08 21:23:08 --> Model Class Initialized
INFO - 2018-04-08 21:23:08 --> Model Class Initialized
INFO - 2018-04-08 21:23:08 --> Model Class Initialized
INFO - 2018-04-08 21:28:25 --> Config Class Initialized
INFO - 2018-04-08 21:28:25 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:28:25 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:28:25 --> Utf8 Class Initialized
INFO - 2018-04-08 21:28:25 --> URI Class Initialized
INFO - 2018-04-08 21:28:25 --> Router Class Initialized
INFO - 2018-04-08 21:28:25 --> Output Class Initialized
INFO - 2018-04-08 21:28:25 --> Security Class Initialized
DEBUG - 2018-04-08 21:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:28:25 --> Input Class Initialized
INFO - 2018-04-08 21:28:25 --> Language Class Initialized
INFO - 2018-04-08 21:28:25 --> Loader Class Initialized
INFO - 2018-04-08 21:28:25 --> Helper loaded: common_helper
INFO - 2018-04-08 21:28:25 --> Database Driver Class Initialized
INFO - 2018-04-08 21:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:28:25 --> Email Class Initialized
INFO - 2018-04-08 21:28:25 --> Controller Class Initialized
INFO - 2018-04-08 21:28:25 --> Helper loaded: form_helper
INFO - 2018-04-08 21:28:25 --> Form Validation Class Initialized
INFO - 2018-04-08 21:28:25 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:28:25 --> Helper loaded: url_helper
INFO - 2018-04-08 21:28:25 --> Model Class Initialized
INFO - 2018-04-08 21:28:25 --> Model Class Initialized
INFO - 2018-04-08 21:28:25 --> Model Class Initialized
INFO - 2018-04-08 21:28:33 --> Config Class Initialized
INFO - 2018-04-08 21:28:33 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:28:33 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:28:33 --> Utf8 Class Initialized
INFO - 2018-04-08 21:28:33 --> URI Class Initialized
INFO - 2018-04-08 21:28:33 --> Router Class Initialized
INFO - 2018-04-08 21:28:33 --> Output Class Initialized
INFO - 2018-04-08 21:28:33 --> Security Class Initialized
DEBUG - 2018-04-08 21:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:28:33 --> Input Class Initialized
INFO - 2018-04-08 21:28:33 --> Language Class Initialized
INFO - 2018-04-08 21:28:33 --> Loader Class Initialized
INFO - 2018-04-08 21:28:33 --> Helper loaded: common_helper
INFO - 2018-04-08 21:28:33 --> Database Driver Class Initialized
INFO - 2018-04-08 21:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:28:33 --> Email Class Initialized
INFO - 2018-04-08 21:28:33 --> Controller Class Initialized
INFO - 2018-04-08 21:28:33 --> Helper loaded: form_helper
INFO - 2018-04-08 21:28:33 --> Form Validation Class Initialized
INFO - 2018-04-08 21:28:33 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:28:33 --> Helper loaded: url_helper
INFO - 2018-04-08 21:28:33 --> Model Class Initialized
INFO - 2018-04-08 21:28:33 --> Model Class Initialized
INFO - 2018-04-08 21:28:33 --> Model Class Initialized
INFO - 2018-04-08 21:28:44 --> Config Class Initialized
INFO - 2018-04-08 21:28:44 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:28:44 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:28:44 --> Utf8 Class Initialized
INFO - 2018-04-08 21:28:44 --> URI Class Initialized
INFO - 2018-04-08 21:28:44 --> Router Class Initialized
INFO - 2018-04-08 21:28:44 --> Output Class Initialized
INFO - 2018-04-08 21:28:44 --> Security Class Initialized
DEBUG - 2018-04-08 21:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:28:44 --> Input Class Initialized
INFO - 2018-04-08 21:28:44 --> Language Class Initialized
INFO - 2018-04-08 21:28:44 --> Loader Class Initialized
INFO - 2018-04-08 21:28:44 --> Helper loaded: common_helper
INFO - 2018-04-08 21:28:44 --> Database Driver Class Initialized
INFO - 2018-04-08 21:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:28:44 --> Email Class Initialized
INFO - 2018-04-08 21:28:44 --> Controller Class Initialized
INFO - 2018-04-08 21:28:44 --> Helper loaded: form_helper
INFO - 2018-04-08 21:28:44 --> Form Validation Class Initialized
INFO - 2018-04-08 21:28:44 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:28:44 --> Helper loaded: url_helper
INFO - 2018-04-08 21:28:44 --> Model Class Initialized
INFO - 2018-04-08 21:28:44 --> Model Class Initialized
INFO - 2018-04-08 21:28:44 --> Model Class Initialized
INFO - 2018-04-08 21:31:46 --> Config Class Initialized
INFO - 2018-04-08 21:31:46 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:31:46 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:31:46 --> Utf8 Class Initialized
INFO - 2018-04-08 21:31:46 --> URI Class Initialized
INFO - 2018-04-08 21:31:46 --> Router Class Initialized
INFO - 2018-04-08 21:31:46 --> Output Class Initialized
INFO - 2018-04-08 21:31:46 --> Security Class Initialized
DEBUG - 2018-04-08 21:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:31:46 --> Input Class Initialized
INFO - 2018-04-08 21:31:46 --> Language Class Initialized
INFO - 2018-04-08 21:31:46 --> Loader Class Initialized
INFO - 2018-04-08 21:31:46 --> Helper loaded: common_helper
INFO - 2018-04-08 21:31:46 --> Database Driver Class Initialized
INFO - 2018-04-08 21:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:31:46 --> Email Class Initialized
INFO - 2018-04-08 21:31:46 --> Controller Class Initialized
INFO - 2018-04-08 21:31:46 --> Helper loaded: form_helper
INFO - 2018-04-08 21:31:46 --> Form Validation Class Initialized
INFO - 2018-04-08 21:31:46 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:31:46 --> Helper loaded: url_helper
INFO - 2018-04-08 21:31:46 --> Model Class Initialized
INFO - 2018-04-08 21:31:46 --> Model Class Initialized
INFO - 2018-04-08 21:31:46 --> Model Class Initialized
INFO - 2018-04-08 21:31:53 --> Config Class Initialized
INFO - 2018-04-08 21:31:53 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:31:53 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:31:53 --> Utf8 Class Initialized
INFO - 2018-04-08 21:31:53 --> URI Class Initialized
INFO - 2018-04-08 21:31:53 --> Router Class Initialized
INFO - 2018-04-08 21:31:53 --> Output Class Initialized
INFO - 2018-04-08 21:31:53 --> Security Class Initialized
DEBUG - 2018-04-08 21:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:31:53 --> Input Class Initialized
INFO - 2018-04-08 21:31:53 --> Language Class Initialized
INFO - 2018-04-08 21:31:53 --> Loader Class Initialized
INFO - 2018-04-08 21:31:53 --> Helper loaded: common_helper
INFO - 2018-04-08 21:31:53 --> Database Driver Class Initialized
INFO - 2018-04-08 21:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:31:53 --> Email Class Initialized
INFO - 2018-04-08 21:31:53 --> Controller Class Initialized
INFO - 2018-04-08 21:31:53 --> Helper loaded: form_helper
INFO - 2018-04-08 21:31:53 --> Form Validation Class Initialized
INFO - 2018-04-08 21:31:53 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:31:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:31:53 --> Helper loaded: url_helper
INFO - 2018-04-08 21:31:53 --> Model Class Initialized
INFO - 2018-04-08 21:31:53 --> Model Class Initialized
INFO - 2018-04-08 21:31:53 --> Model Class Initialized
INFO - 2018-04-08 21:33:01 --> Config Class Initialized
INFO - 2018-04-08 21:33:01 --> Hooks Class Initialized
DEBUG - 2018-04-08 21:33:01 --> UTF-8 Support Enabled
INFO - 2018-04-08 21:33:01 --> Utf8 Class Initialized
INFO - 2018-04-08 21:33:01 --> URI Class Initialized
INFO - 2018-04-08 21:33:01 --> Router Class Initialized
INFO - 2018-04-08 21:33:01 --> Output Class Initialized
INFO - 2018-04-08 21:33:01 --> Security Class Initialized
DEBUG - 2018-04-08 21:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-08 21:33:01 --> Input Class Initialized
INFO - 2018-04-08 21:33:01 --> Language Class Initialized
INFO - 2018-04-08 21:33:01 --> Loader Class Initialized
INFO - 2018-04-08 21:33:01 --> Helper loaded: common_helper
INFO - 2018-04-08 21:33:01 --> Database Driver Class Initialized
INFO - 2018-04-08 21:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-08 21:33:01 --> Email Class Initialized
INFO - 2018-04-08 21:33:01 --> Controller Class Initialized
INFO - 2018-04-08 21:33:01 --> Helper loaded: form_helper
INFO - 2018-04-08 21:33:01 --> Form Validation Class Initialized
INFO - 2018-04-08 21:33:01 --> Helper loaded: email_helper
DEBUG - 2018-04-08 21:33:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-08 21:33:01 --> Helper loaded: url_helper
INFO - 2018-04-08 21:33:01 --> Model Class Initialized
INFO - 2018-04-08 21:33:01 --> Model Class Initialized
INFO - 2018-04-08 21:33:01 --> Model Class Initialized
