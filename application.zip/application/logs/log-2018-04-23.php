<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-04-23 05:21:37 --> Config Class Initialized
INFO - 2018-04-23 05:21:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:37 --> URI Class Initialized
DEBUG - 2018-04-23 05:21:37 --> No URI present. Default controller set.
INFO - 2018-04-23 05:21:37 --> Router Class Initialized
INFO - 2018-04-23 05:21:37 --> Output Class Initialized
INFO - 2018-04-23 05:21:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:37 --> Input Class Initialized
INFO - 2018-04-23 05:21:37 --> Language Class Initialized
INFO - 2018-04-23 05:21:37 --> Loader Class Initialized
INFO - 2018-04-23 05:21:37 --> Helper loaded: common_helper
INFO - 2018-04-23 05:21:37 --> Database Driver Class Initialized
INFO - 2018-04-23 05:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:21:37 --> Email Class Initialized
INFO - 2018-04-23 05:21:37 --> Controller Class Initialized
INFO - 2018-04-23 05:21:37 --> Helper loaded: form_helper
INFO - 2018-04-23 05:21:37 --> Form Validation Class Initialized
INFO - 2018-04-23 05:21:37 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:21:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:21:37 --> Helper loaded: url_helper
INFO - 2018-04-23 05:21:37 --> Model Class Initialized
INFO - 2018-04-23 05:21:37 --> Model Class Initialized
INFO - 2018-04-23 05:21:37 --> File loaded: /var/www/html/admin/application/views/index.php
INFO - 2018-04-23 05:21:37 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:21:37 --> Final output sent to browser
DEBUG - 2018-04-23 05:21:37 --> Total execution time: 0.0261
INFO - 2018-04-23 05:21:37 --> Config Class Initialized
INFO - 2018-04-23 05:21:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:37 --> URI Class Initialized
INFO - 2018-04-23 05:21:37 --> Router Class Initialized
INFO - 2018-04-23 05:21:37 --> Output Class Initialized
INFO - 2018-04-23 05:21:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:37 --> Input Class Initialized
INFO - 2018-04-23 05:21:37 --> Language Class Initialized
ERROR - 2018-04-23 05:21:37 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:21:37 --> Config Class Initialized
INFO - 2018-04-23 05:21:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:37 --> URI Class Initialized
INFO - 2018-04-23 05:21:37 --> Router Class Initialized
INFO - 2018-04-23 05:21:37 --> Output Class Initialized
INFO - 2018-04-23 05:21:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:37 --> Input Class Initialized
INFO - 2018-04-23 05:21:37 --> Language Class Initialized
ERROR - 2018-04-23 05:21:37 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:21:37 --> Config Class Initialized
INFO - 2018-04-23 05:21:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:37 --> URI Class Initialized
INFO - 2018-04-23 05:21:37 --> Router Class Initialized
INFO - 2018-04-23 05:21:37 --> Output Class Initialized
INFO - 2018-04-23 05:21:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:37 --> Input Class Initialized
INFO - 2018-04-23 05:21:37 --> Language Class Initialized
ERROR - 2018-04-23 05:21:37 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:21:38 --> Config Class Initialized
INFO - 2018-04-23 05:21:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:38 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:38 --> URI Class Initialized
INFO - 2018-04-23 05:21:38 --> Router Class Initialized
INFO - 2018-04-23 05:21:38 --> Output Class Initialized
INFO - 2018-04-23 05:21:38 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:38 --> Input Class Initialized
INFO - 2018-04-23 05:21:38 --> Language Class Initialized
ERROR - 2018-04-23 05:21:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:21:38 --> Config Class Initialized
INFO - 2018-04-23 05:21:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:38 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:38 --> URI Class Initialized
INFO - 2018-04-23 05:21:38 --> Router Class Initialized
INFO - 2018-04-23 05:21:38 --> Output Class Initialized
INFO - 2018-04-23 05:21:38 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:38 --> Input Class Initialized
INFO - 2018-04-23 05:21:38 --> Language Class Initialized
ERROR - 2018-04-23 05:21:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:21:38 --> Config Class Initialized
INFO - 2018-04-23 05:21:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:38 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:38 --> URI Class Initialized
INFO - 2018-04-23 05:21:38 --> Router Class Initialized
INFO - 2018-04-23 05:21:38 --> Output Class Initialized
INFO - 2018-04-23 05:21:38 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:38 --> Input Class Initialized
INFO - 2018-04-23 05:21:38 --> Language Class Initialized
ERROR - 2018-04-23 05:21:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
DEBUG - 2018-04-23 05:21:45 --> No URI present. Default controller set.
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
INFO - 2018-04-23 05:21:45 --> Loader Class Initialized
INFO - 2018-04-23 05:21:45 --> Helper loaded: common_helper
INFO - 2018-04-23 05:21:45 --> Database Driver Class Initialized
INFO - 2018-04-23 05:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:21:45 --> Email Class Initialized
INFO - 2018-04-23 05:21:45 --> Controller Class Initialized
INFO - 2018-04-23 05:21:45 --> Helper loaded: form_helper
INFO - 2018-04-23 05:21:45 --> Form Validation Class Initialized
INFO - 2018-04-23 05:21:45 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:21:45 --> Helper loaded: url_helper
INFO - 2018-04-23 05:21:45 --> Model Class Initialized
INFO - 2018-04-23 05:21:45 --> Model Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:21:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
INFO - 2018-04-23 05:21:45 --> Loader Class Initialized
INFO - 2018-04-23 05:21:45 --> Helper loaded: common_helper
INFO - 2018-04-23 05:21:45 --> Database Driver Class Initialized
INFO - 2018-04-23 05:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:21:45 --> Email Class Initialized
INFO - 2018-04-23 05:21:45 --> Controller Class Initialized
INFO - 2018-04-23 05:21:45 --> Helper loaded: form_helper
INFO - 2018-04-23 05:21:45 --> Form Validation Class Initialized
INFO - 2018-04-23 05:21:45 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:21:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:21:45 --> Helper loaded: url_helper
INFO - 2018-04-23 05:21:45 --> Model Class Initialized
INFO - 2018-04-23 05:21:45 --> Model Class Initialized
INFO - 2018-04-23 05:21:45 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:21:45 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 05:21:45 --> Undefined variable: categories
ERROR - 2018-04-23 05:21:45 --> Severity: Notice --> Undefined variable: categories /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 05:21:45 --> Trying to get property of non-object
ERROR - 2018-04-23 05:21:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 05:21:45 --> Undefined variable: articles
ERROR - 2018-04-23 05:21:45 --> Severity: Notice --> Undefined variable: articles /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 05:21:45 --> Trying to get property of non-object
ERROR - 2018-04-23 05:21:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 05:21:45 --> Undefined variable: subscriptions
ERROR - 2018-04-23 05:21:45 --> Severity: Notice --> Undefined variable: subscriptions /var/www/html/admin/application/views/dashboard.php 67
ERROR - 2018-04-23 05:21:45 --> Trying to get property of non-object
ERROR - 2018-04-23 05:21:45 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 67
INFO - 2018-04-23 05:21:45 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 05:21:45 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:21:45 --> Final output sent to browser
DEBUG - 2018-04-23 05:21:45 --> Total execution time: 0.0035
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:21:45 --> Config Class Initialized
INFO - 2018-04-23 05:21:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:21:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:21:45 --> Utf8 Class Initialized
INFO - 2018-04-23 05:21:45 --> URI Class Initialized
INFO - 2018-04-23 05:21:45 --> Router Class Initialized
INFO - 2018-04-23 05:21:45 --> Output Class Initialized
INFO - 2018-04-23 05:21:45 --> Security Class Initialized
DEBUG - 2018-04-23 05:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:21:45 --> Input Class Initialized
INFO - 2018-04-23 05:21:45 --> Language Class Initialized
ERROR - 2018-04-23 05:21:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
INFO - 2018-04-23 05:22:10 --> Loader Class Initialized
INFO - 2018-04-23 05:22:10 --> Helper loaded: common_helper
INFO - 2018-04-23 05:22:10 --> Database Driver Class Initialized
INFO - 2018-04-23 05:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:22:10 --> Email Class Initialized
INFO - 2018-04-23 05:22:10 --> Controller Class Initialized
INFO - 2018-04-23 05:22:10 --> Helper loaded: form_helper
INFO - 2018-04-23 05:22:10 --> Form Validation Class Initialized
INFO - 2018-04-23 05:22:10 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:22:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:22:10 --> Helper loaded: url_helper
INFO - 2018-04-23 05:22:10 --> Model Class Initialized
INFO - 2018-04-23 05:22:10 --> Model Class Initialized
INFO - 2018-04-23 05:22:10 --> Model Class Initialized
INFO - 2018-04-23 05:22:10 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:22:10 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 05:22:10 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:22:10 --> File loaded: /var/www/html/admin/application/views/admins/admins.php
INFO - 2018-04-23 05:22:10 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:22:10 --> Final output sent to browser
DEBUG - 2018-04-23 05:22:10 --> Total execution time: 0.0044
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:22:10 --> Config Class Initialized
INFO - 2018-04-23 05:22:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:10 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:10 --> URI Class Initialized
INFO - 2018-04-23 05:22:10 --> Router Class Initialized
INFO - 2018-04-23 05:22:10 --> Output Class Initialized
INFO - 2018-04-23 05:22:10 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:10 --> Input Class Initialized
INFO - 2018-04-23 05:22:10 --> Language Class Initialized
ERROR - 2018-04-23 05:22:10 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
INFO - 2018-04-23 05:22:12 --> Loader Class Initialized
INFO - 2018-04-23 05:22:12 --> Helper loaded: common_helper
INFO - 2018-04-23 05:22:12 --> Database Driver Class Initialized
INFO - 2018-04-23 05:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:22:12 --> Email Class Initialized
INFO - 2018-04-23 05:22:12 --> Controller Class Initialized
INFO - 2018-04-23 05:22:12 --> Helper loaded: form_helper
INFO - 2018-04-23 05:22:12 --> Form Validation Class Initialized
INFO - 2018-04-23 05:22:12 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:22:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:22:12 --> Helper loaded: url_helper
INFO - 2018-04-23 05:22:12 --> Model Class Initialized
INFO - 2018-04-23 05:22:12 --> Model Class Initialized
INFO - 2018-04-23 05:22:12 --> Model Class Initialized
INFO - 2018-04-23 05:22:12 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:22:12 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 05:22:12 --> Undefined variable: details
ERROR - 2018-04-23 05:22:12 --> Severity: Notice --> Undefined variable: details /var/www/html/admin/application/views/admins/addAdmin.php 73
INFO - 2018-04-23 05:22:12 --> File loaded: /var/www/html/admin/application/views/admins/addAdmin.php
INFO - 2018-04-23 05:22:12 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:22:12 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:22:12 --> Final output sent to browser
DEBUG - 2018-04-23 05:22:12 --> Total execution time: 0.0028
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:22:12 --> Config Class Initialized
INFO - 2018-04-23 05:22:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:12 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:12 --> URI Class Initialized
INFO - 2018-04-23 05:22:12 --> Router Class Initialized
INFO - 2018-04-23 05:22:12 --> Output Class Initialized
INFO - 2018-04-23 05:22:12 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:12 --> Input Class Initialized
INFO - 2018-04-23 05:22:12 --> Language Class Initialized
ERROR - 2018-04-23 05:22:12 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:42 --> Config Class Initialized
INFO - 2018-04-23 05:22:42 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:42 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:42 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:42 --> URI Class Initialized
DEBUG - 2018-04-23 05:22:42 --> No URI present. Default controller set.
INFO - 2018-04-23 05:22:42 --> Router Class Initialized
INFO - 2018-04-23 05:22:42 --> Output Class Initialized
INFO - 2018-04-23 05:22:42 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:42 --> Input Class Initialized
INFO - 2018-04-23 05:22:42 --> Language Class Initialized
INFO - 2018-04-23 05:22:42 --> Loader Class Initialized
INFO - 2018-04-23 05:22:42 --> Helper loaded: common_helper
INFO - 2018-04-23 05:22:42 --> Database Driver Class Initialized
INFO - 2018-04-23 05:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:22:42 --> Email Class Initialized
INFO - 2018-04-23 05:22:42 --> Controller Class Initialized
INFO - 2018-04-23 05:22:42 --> Helper loaded: form_helper
INFO - 2018-04-23 05:22:42 --> Form Validation Class Initialized
INFO - 2018-04-23 05:22:42 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:22:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:22:42 --> Helper loaded: url_helper
INFO - 2018-04-23 05:22:42 --> Model Class Initialized
INFO - 2018-04-23 05:22:42 --> Model Class Initialized
INFO - 2018-04-23 05:22:42 --> File loaded: /var/www/html/admin/application/views/index.php
INFO - 2018-04-23 05:22:42 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:22:42 --> Final output sent to browser
DEBUG - 2018-04-23 05:22:42 --> Total execution time: 0.0020
INFO - 2018-04-23 05:22:42 --> Config Class Initialized
INFO - 2018-04-23 05:22:42 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:42 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:42 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:42 --> URI Class Initialized
INFO - 2018-04-23 05:22:42 --> Router Class Initialized
INFO - 2018-04-23 05:22:42 --> Output Class Initialized
INFO - 2018-04-23 05:22:42 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:42 --> Input Class Initialized
INFO - 2018-04-23 05:22:42 --> Language Class Initialized
ERROR - 2018-04-23 05:22:42 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:42 --> Config Class Initialized
INFO - 2018-04-23 05:22:42 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:42 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:42 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:42 --> URI Class Initialized
INFO - 2018-04-23 05:22:42 --> Router Class Initialized
INFO - 2018-04-23 05:22:42 --> Output Class Initialized
INFO - 2018-04-23 05:22:42 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:42 --> Input Class Initialized
INFO - 2018-04-23 05:22:42 --> Language Class Initialized
ERROR - 2018-04-23 05:22:42 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:22:42 --> Config Class Initialized
INFO - 2018-04-23 05:22:42 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:42 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:42 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:42 --> URI Class Initialized
INFO - 2018-04-23 05:22:42 --> Router Class Initialized
INFO - 2018-04-23 05:22:42 --> Output Class Initialized
INFO - 2018-04-23 05:22:42 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:42 --> Input Class Initialized
INFO - 2018-04-23 05:22:42 --> Language Class Initialized
ERROR - 2018-04-23 05:22:42 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:43 --> Config Class Initialized
INFO - 2018-04-23 05:22:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:43 --> URI Class Initialized
INFO - 2018-04-23 05:22:43 --> Router Class Initialized
INFO - 2018-04-23 05:22:43 --> Output Class Initialized
INFO - 2018-04-23 05:22:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:43 --> Input Class Initialized
INFO - 2018-04-23 05:22:43 --> Language Class Initialized
ERROR - 2018-04-23 05:22:43 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:22:43 --> Config Class Initialized
INFO - 2018-04-23 05:22:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:43 --> URI Class Initialized
INFO - 2018-04-23 05:22:43 --> Router Class Initialized
INFO - 2018-04-23 05:22:43 --> Output Class Initialized
INFO - 2018-04-23 05:22:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:43 --> Input Class Initialized
INFO - 2018-04-23 05:22:43 --> Language Class Initialized
ERROR - 2018-04-23 05:22:43 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:22:43 --> Config Class Initialized
INFO - 2018-04-23 05:22:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:43 --> URI Class Initialized
INFO - 2018-04-23 05:22:43 --> Router Class Initialized
INFO - 2018-04-23 05:22:43 --> Output Class Initialized
INFO - 2018-04-23 05:22:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:43 --> Input Class Initialized
INFO - 2018-04-23 05:22:43 --> Language Class Initialized
ERROR - 2018-04-23 05:22:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:22:56 --> Config Class Initialized
INFO - 2018-04-23 05:22:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:22:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:22:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:22:56 --> URI Class Initialized
DEBUG - 2018-04-23 05:22:56 --> No URI present. Default controller set.
INFO - 2018-04-23 05:22:56 --> Router Class Initialized
INFO - 2018-04-23 05:22:56 --> Output Class Initialized
INFO - 2018-04-23 05:22:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:22:56 --> Input Class Initialized
INFO - 2018-04-23 05:22:56 --> Language Class Initialized
INFO - 2018-04-23 05:22:56 --> Loader Class Initialized
INFO - 2018-04-23 05:22:56 --> Helper loaded: common_helper
INFO - 2018-04-23 05:22:56 --> Database Driver Class Initialized
INFO - 2018-04-23 05:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:22:56 --> Email Class Initialized
INFO - 2018-04-23 05:22:56 --> Controller Class Initialized
INFO - 2018-04-23 05:22:56 --> Helper loaded: form_helper
INFO - 2018-04-23 05:22:56 --> Form Validation Class Initialized
INFO - 2018-04-23 05:22:56 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:22:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:22:56 --> Helper loaded: url_helper
INFO - 2018-04-23 05:22:56 --> Model Class Initialized
INFO - 2018-04-23 05:22:56 --> Model Class Initialized
DEBUG - 2018-04-23 05:22:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:22:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 05:23:23 --> Config Class Initialized
INFO - 2018-04-23 05:23:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:23 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:23 --> URI Class Initialized
DEBUG - 2018-04-23 05:23:23 --> No URI present. Default controller set.
INFO - 2018-04-23 05:23:23 --> Router Class Initialized
INFO - 2018-04-23 05:23:23 --> Output Class Initialized
INFO - 2018-04-23 05:23:23 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:23 --> Input Class Initialized
INFO - 2018-04-23 05:23:23 --> Language Class Initialized
INFO - 2018-04-23 05:23:23 --> Loader Class Initialized
INFO - 2018-04-23 05:23:23 --> Helper loaded: common_helper
INFO - 2018-04-23 05:23:23 --> Database Driver Class Initialized
INFO - 2018-04-23 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:23:23 --> Email Class Initialized
INFO - 2018-04-23 05:23:23 --> Controller Class Initialized
INFO - 2018-04-23 05:23:23 --> Helper loaded: form_helper
INFO - 2018-04-23 05:23:23 --> Form Validation Class Initialized
INFO - 2018-04-23 05:23:23 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:23:23 --> Helper loaded: url_helper
INFO - 2018-04-23 05:23:23 --> Model Class Initialized
INFO - 2018-04-23 05:23:23 --> Model Class Initialized
INFO - 2018-04-23 05:23:23 --> Config Class Initialized
INFO - 2018-04-23 05:23:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:23 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:23 --> URI Class Initialized
INFO - 2018-04-23 05:23:23 --> Router Class Initialized
INFO - 2018-04-23 05:23:23 --> Output Class Initialized
INFO - 2018-04-23 05:23:23 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:23 --> Input Class Initialized
INFO - 2018-04-23 05:23:23 --> Language Class Initialized
INFO - 2018-04-23 05:23:23 --> Loader Class Initialized
INFO - 2018-04-23 05:23:23 --> Helper loaded: common_helper
INFO - 2018-04-23 05:23:23 --> Database Driver Class Initialized
INFO - 2018-04-23 05:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:23:23 --> Email Class Initialized
INFO - 2018-04-23 05:23:23 --> Controller Class Initialized
INFO - 2018-04-23 05:23:23 --> Helper loaded: form_helper
INFO - 2018-04-23 05:23:23 --> Form Validation Class Initialized
INFO - 2018-04-23 05:23:23 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:23:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:23:23 --> Helper loaded: url_helper
INFO - 2018-04-23 05:23:23 --> Model Class Initialized
INFO - 2018-04-23 05:23:23 --> Model Class Initialized
INFO - 2018-04-23 05:23:23 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:23:23 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 05:23:23 --> Undefined variable: categories
ERROR - 2018-04-23 05:23:23 --> Severity: Notice --> Undefined variable: categories /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 05:23:23 --> Trying to get property of non-object
ERROR - 2018-04-23 05:23:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 05:23:23 --> Undefined variable: articles
ERROR - 2018-04-23 05:23:23 --> Severity: Notice --> Undefined variable: articles /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 05:23:23 --> Trying to get property of non-object
ERROR - 2018-04-23 05:23:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 05:23:23 --> Undefined variable: subscriptions
ERROR - 2018-04-23 05:23:23 --> Severity: Notice --> Undefined variable: subscriptions /var/www/html/admin/application/views/dashboard.php 67
ERROR - 2018-04-23 05:23:23 --> Trying to get property of non-object
ERROR - 2018-04-23 05:23:23 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 67
INFO - 2018-04-23 05:23:23 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 05:23:23 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:23:23 --> Final output sent to browser
DEBUG - 2018-04-23 05:23:23 --> Total execution time: 0.0027
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:23:24 --> Config Class Initialized
INFO - 2018-04-23 05:23:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:24 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:24 --> URI Class Initialized
INFO - 2018-04-23 05:23:24 --> Router Class Initialized
INFO - 2018-04-23 05:23:24 --> Output Class Initialized
INFO - 2018-04-23 05:23:24 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:24 --> Input Class Initialized
INFO - 2018-04-23 05:23:24 --> Language Class Initialized
ERROR - 2018-04-23 05:23:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
INFO - 2018-04-23 05:23:31 --> Loader Class Initialized
INFO - 2018-04-23 05:23:31 --> Helper loaded: common_helper
INFO - 2018-04-23 05:23:31 --> Database Driver Class Initialized
INFO - 2018-04-23 05:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:23:31 --> Email Class Initialized
INFO - 2018-04-23 05:23:31 --> Controller Class Initialized
INFO - 2018-04-23 05:23:31 --> Helper loaded: form_helper
INFO - 2018-04-23 05:23:31 --> Form Validation Class Initialized
INFO - 2018-04-23 05:23:31 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:23:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:23:31 --> Helper loaded: url_helper
INFO - 2018-04-23 05:23:31 --> Model Class Initialized
INFO - 2018-04-23 05:23:31 --> Model Class Initialized
INFO - 2018-04-23 05:23:31 --> Model Class Initialized
INFO - 2018-04-23 05:23:31 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:23:31 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 05:23:31 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:23:31 --> File loaded: /var/www/html/admin/application/views/admins/admins.php
INFO - 2018-04-23 05:23:31 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:23:31 --> Final output sent to browser
DEBUG - 2018-04-23 05:23:31 --> Total execution time: 0.0028
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
ERROR - 2018-04-23 05:23:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
ERROR - 2018-04-23 05:23:31 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
ERROR - 2018-04-23 05:23:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
ERROR - 2018-04-23 05:23:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
ERROR - 2018-04-23 05:23:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:31 --> Config Class Initialized
INFO - 2018-04-23 05:23:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:31 --> URI Class Initialized
INFO - 2018-04-23 05:23:31 --> Router Class Initialized
INFO - 2018-04-23 05:23:31 --> Output Class Initialized
INFO - 2018-04-23 05:23:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:31 --> Input Class Initialized
INFO - 2018-04-23 05:23:31 --> Language Class Initialized
ERROR - 2018-04-23 05:23:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:55 --> Config Class Initialized
INFO - 2018-04-23 05:23:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:55 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:55 --> URI Class Initialized
INFO - 2018-04-23 05:23:55 --> Router Class Initialized
INFO - 2018-04-23 05:23:55 --> Output Class Initialized
INFO - 2018-04-23 05:23:55 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:55 --> Input Class Initialized
INFO - 2018-04-23 05:23:55 --> Language Class Initialized
INFO - 2018-04-23 05:23:55 --> Loader Class Initialized
INFO - 2018-04-23 05:23:55 --> Helper loaded: common_helper
INFO - 2018-04-23 05:23:55 --> Database Driver Class Initialized
INFO - 2018-04-23 05:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:23:55 --> Email Class Initialized
INFO - 2018-04-23 05:23:55 --> Controller Class Initialized
INFO - 2018-04-23 05:23:55 --> Helper loaded: form_helper
INFO - 2018-04-23 05:23:55 --> Form Validation Class Initialized
INFO - 2018-04-23 05:23:55 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:23:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:23:55 --> Helper loaded: url_helper
INFO - 2018-04-23 05:23:55 --> Model Class Initialized
INFO - 2018-04-23 05:23:55 --> Model Class Initialized
INFO - 2018-04-23 05:23:55 --> Model Class Initialized
INFO - 2018-04-23 05:23:55 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:23:55 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 05:23:55 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:23:55 --> File loaded: /var/www/html/admin/application/views/admins/admins.php
INFO - 2018-04-23 05:23:55 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:23:55 --> Final output sent to browser
DEBUG - 2018-04-23 05:23:55 --> Total execution time: 0.0027
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:23:56 --> Config Class Initialized
INFO - 2018-04-23 05:23:56 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:23:56 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:23:56 --> Utf8 Class Initialized
INFO - 2018-04-23 05:23:56 --> URI Class Initialized
INFO - 2018-04-23 05:23:56 --> Router Class Initialized
INFO - 2018-04-23 05:23:56 --> Output Class Initialized
INFO - 2018-04-23 05:23:56 --> Security Class Initialized
DEBUG - 2018-04-23 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:23:56 --> Input Class Initialized
INFO - 2018-04-23 05:23:56 --> Language Class Initialized
ERROR - 2018-04-23 05:23:56 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
INFO - 2018-04-23 05:24:08 --> Loader Class Initialized
INFO - 2018-04-23 05:24:08 --> Helper loaded: common_helper
INFO - 2018-04-23 05:24:08 --> Database Driver Class Initialized
INFO - 2018-04-23 05:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:24:08 --> Email Class Initialized
INFO - 2018-04-23 05:24:08 --> Controller Class Initialized
INFO - 2018-04-23 05:24:08 --> Helper loaded: form_helper
INFO - 2018-04-23 05:24:08 --> Form Validation Class Initialized
INFO - 2018-04-23 05:24:08 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:24:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:24:08 --> Helper loaded: url_helper
INFO - 2018-04-23 05:24:08 --> Model Class Initialized
INFO - 2018-04-23 05:24:08 --> Model Class Initialized
INFO - 2018-04-23 05:24:08 --> Model Class Initialized
INFO - 2018-04-23 05:24:08 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:24:08 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 05:24:08 --> Undefined variable: details
ERROR - 2018-04-23 05:24:08 --> Severity: Notice --> Undefined variable: details /var/www/html/admin/application/views/admins/addAdmin.php 73
INFO - 2018-04-23 05:24:08 --> File loaded: /var/www/html/admin/application/views/admins/addAdmin.php
INFO - 2018-04-23 05:24:08 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:24:08 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:24:08 --> Final output sent to browser
DEBUG - 2018-04-23 05:24:08 --> Total execution time: 0.0025
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:24:08 --> Config Class Initialized
INFO - 2018-04-23 05:24:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:08 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:08 --> URI Class Initialized
INFO - 2018-04-23 05:24:08 --> Router Class Initialized
INFO - 2018-04-23 05:24:08 --> Output Class Initialized
INFO - 2018-04-23 05:24:08 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:08 --> Input Class Initialized
INFO - 2018-04-23 05:24:08 --> Language Class Initialized
ERROR - 2018-04-23 05:24:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:50 --> Config Class Initialized
INFO - 2018-04-23 05:24:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:50 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:50 --> URI Class Initialized
INFO - 2018-04-23 05:24:50 --> Router Class Initialized
INFO - 2018-04-23 05:24:50 --> Output Class Initialized
INFO - 2018-04-23 05:24:50 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:50 --> Input Class Initialized
INFO - 2018-04-23 05:24:50 --> Language Class Initialized
INFO - 2018-04-23 05:24:50 --> Loader Class Initialized
INFO - 2018-04-23 05:24:50 --> Helper loaded: common_helper
INFO - 2018-04-23 05:24:50 --> Database Driver Class Initialized
INFO - 2018-04-23 05:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:24:50 --> Email Class Initialized
INFO - 2018-04-23 05:24:50 --> Controller Class Initialized
INFO - 2018-04-23 05:24:50 --> Helper loaded: form_helper
INFO - 2018-04-23 05:24:50 --> Form Validation Class Initialized
INFO - 2018-04-23 05:24:50 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:24:50 --> Helper loaded: url_helper
INFO - 2018-04-23 05:24:50 --> Model Class Initialized
INFO - 2018-04-23 05:24:50 --> Model Class Initialized
INFO - 2018-04-23 05:24:50 --> Model Class Initialized
DEBUG - 2018-04-23 05:24:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:24:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 05:24:50 --> Config Class Initialized
INFO - 2018-04-23 05:24:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:50 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:50 --> URI Class Initialized
INFO - 2018-04-23 05:24:50 --> Router Class Initialized
INFO - 2018-04-23 05:24:50 --> Output Class Initialized
INFO - 2018-04-23 05:24:50 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:50 --> Input Class Initialized
INFO - 2018-04-23 05:24:50 --> Language Class Initialized
INFO - 2018-04-23 05:24:50 --> Loader Class Initialized
INFO - 2018-04-23 05:24:50 --> Helper loaded: common_helper
INFO - 2018-04-23 05:24:50 --> Database Driver Class Initialized
INFO - 2018-04-23 05:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:24:50 --> Email Class Initialized
INFO - 2018-04-23 05:24:50 --> Controller Class Initialized
INFO - 2018-04-23 05:24:50 --> Helper loaded: form_helper
INFO - 2018-04-23 05:24:50 --> Form Validation Class Initialized
INFO - 2018-04-23 05:24:50 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:24:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:24:50 --> Helper loaded: url_helper
INFO - 2018-04-23 05:24:50 --> Model Class Initialized
INFO - 2018-04-23 05:24:50 --> Model Class Initialized
INFO - 2018-04-23 05:24:50 --> Model Class Initialized
INFO - 2018-04-23 05:24:50 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:24:50 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 05:24:50 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:24:50 --> File loaded: /var/www/html/admin/application/views/admins/admins.php
INFO - 2018-04-23 05:24:50 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:24:50 --> Final output sent to browser
DEBUG - 2018-04-23 05:24:50 --> Total execution time: 0.0025
INFO - 2018-04-23 05:24:50 --> Config Class Initialized
INFO - 2018-04-23 05:24:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:50 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:50 --> URI Class Initialized
INFO - 2018-04-23 05:24:50 --> Router Class Initialized
INFO - 2018-04-23 05:24:50 --> Output Class Initialized
INFO - 2018-04-23 05:24:50 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:50 --> Input Class Initialized
INFO - 2018-04-23 05:24:50 --> Language Class Initialized
ERROR - 2018-04-23 05:24:50 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:50 --> Config Class Initialized
INFO - 2018-04-23 05:24:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:50 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:50 --> URI Class Initialized
INFO - 2018-04-23 05:24:50 --> Router Class Initialized
INFO - 2018-04-23 05:24:50 --> Output Class Initialized
INFO - 2018-04-23 05:24:50 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:50 --> Input Class Initialized
INFO - 2018-04-23 05:24:50 --> Language Class Initialized
ERROR - 2018-04-23 05:24:50 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:50 --> Config Class Initialized
INFO - 2018-04-23 05:24:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:50 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:50 --> URI Class Initialized
INFO - 2018-04-23 05:24:50 --> Router Class Initialized
INFO - 2018-04-23 05:24:50 --> Output Class Initialized
INFO - 2018-04-23 05:24:50 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:50 --> Input Class Initialized
INFO - 2018-04-23 05:24:50 --> Language Class Initialized
ERROR - 2018-04-23 05:24:50 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:24:51 --> Config Class Initialized
INFO - 2018-04-23 05:24:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:24:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:24:51 --> Utf8 Class Initialized
INFO - 2018-04-23 05:24:51 --> URI Class Initialized
INFO - 2018-04-23 05:24:51 --> Router Class Initialized
INFO - 2018-04-23 05:24:51 --> Output Class Initialized
INFO - 2018-04-23 05:24:51 --> Security Class Initialized
DEBUG - 2018-04-23 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:24:51 --> Input Class Initialized
INFO - 2018-04-23 05:24:51 --> Language Class Initialized
ERROR - 2018-04-23 05:24:51 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
INFO - 2018-04-23 05:45:15 --> Loader Class Initialized
INFO - 2018-04-23 05:45:15 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:15 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:15 --> Email Class Initialized
INFO - 2018-04-23 05:45:15 --> Controller Class Initialized
INFO - 2018-04-23 05:45:15 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:15 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:15 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:15 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:15 --> Model Class Initialized
INFO - 2018-04-23 05:45:15 --> Model Class Initialized
INFO - 2018-04-23 05:45:15 --> Model Class Initialized
INFO - 2018-04-23 11:15:15 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:15 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:15 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:15 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 11:15:15 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:15 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:15 --> Total execution time: 0.0049
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
ERROR - 2018-04-23 05:45:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
ERROR - 2018-04-23 05:45:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
ERROR - 2018-04-23 05:45:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
ERROR - 2018-04-23 05:45:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
ERROR - 2018-04-23 05:45:15 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:15 --> Config Class Initialized
INFO - 2018-04-23 05:45:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:15 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:15 --> URI Class Initialized
INFO - 2018-04-23 05:45:15 --> Router Class Initialized
INFO - 2018-04-23 05:45:15 --> Output Class Initialized
INFO - 2018-04-23 05:45:15 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:15 --> Input Class Initialized
INFO - 2018-04-23 05:45:15 --> Language Class Initialized
ERROR - 2018-04-23 05:45:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
INFO - 2018-04-23 05:45:17 --> Loader Class Initialized
INFO - 2018-04-23 05:45:17 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:17 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:17 --> Email Class Initialized
INFO - 2018-04-23 05:45:17 --> Controller Class Initialized
INFO - 2018-04-23 05:45:17 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:17 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:17 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:17 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:17 --> Model Class Initialized
INFO - 2018-04-23 05:45:17 --> Model Class Initialized
INFO - 2018-04-23 05:45:17 --> Model Class Initialized
INFO - 2018-04-23 11:15:17 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:17 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:17 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 11:15:17 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:17 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:17 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:17 --> Total execution time: 0.0026
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:17 --> Config Class Initialized
INFO - 2018-04-23 05:45:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:17 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:17 --> URI Class Initialized
INFO - 2018-04-23 05:45:17 --> Router Class Initialized
INFO - 2018-04-23 05:45:17 --> Output Class Initialized
INFO - 2018-04-23 05:45:17 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:17 --> Input Class Initialized
INFO - 2018-04-23 05:45:17 --> Language Class Initialized
ERROR - 2018-04-23 05:45:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
INFO - 2018-04-23 05:45:31 --> Loader Class Initialized
INFO - 2018-04-23 05:45:31 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:31 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:31 --> Email Class Initialized
INFO - 2018-04-23 05:45:31 --> Controller Class Initialized
INFO - 2018-04-23 05:45:31 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:31 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:31 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:31 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:31 --> Model Class Initialized
INFO - 2018-04-23 05:45:31 --> Model Class Initialized
INFO - 2018-04-23 05:45:31 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:45:31 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 05:45:31 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:45:31 --> File loaded: /var/www/html/admin/application/views/socialService/socialService.php
INFO - 2018-04-23 05:45:31 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:45:31 --> Final output sent to browser
DEBUG - 2018-04-23 05:45:31 --> Total execution time: 0.0040
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
ERROR - 2018-04-23 05:45:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
ERROR - 2018-04-23 05:45:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
ERROR - 2018-04-23 05:45:31 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
ERROR - 2018-04-23 05:45:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
ERROR - 2018-04-23 05:45:31 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:31 --> Config Class Initialized
INFO - 2018-04-23 05:45:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:31 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:31 --> URI Class Initialized
INFO - 2018-04-23 05:45:31 --> Router Class Initialized
INFO - 2018-04-23 05:45:31 --> Output Class Initialized
INFO - 2018-04-23 05:45:31 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:31 --> Input Class Initialized
INFO - 2018-04-23 05:45:31 --> Language Class Initialized
ERROR - 2018-04-23 05:45:31 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:33 --> Config Class Initialized
INFO - 2018-04-23 05:45:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:33 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:33 --> URI Class Initialized
INFO - 2018-04-23 05:45:33 --> Router Class Initialized
INFO - 2018-04-23 05:45:33 --> Output Class Initialized
INFO - 2018-04-23 05:45:33 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:33 --> Input Class Initialized
INFO - 2018-04-23 05:45:33 --> Language Class Initialized
INFO - 2018-04-23 05:45:33 --> Loader Class Initialized
INFO - 2018-04-23 05:45:33 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:33 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:33 --> Email Class Initialized
INFO - 2018-04-23 05:45:33 --> Controller Class Initialized
INFO - 2018-04-23 05:45:33 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:33 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:33 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:33 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:33 --> Model Class Initialized
INFO - 2018-04-23 05:45:33 --> Model Class Initialized
INFO - 2018-04-23 05:45:33 --> Model Class Initialized
INFO - 2018-04-23 11:15:33 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:33 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:33 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 11:15:33 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:33 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:33 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:33 --> Total execution time: 0.0023
INFO - 2018-04-23 05:45:33 --> Config Class Initialized
INFO - 2018-04-23 05:45:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:33 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:33 --> URI Class Initialized
INFO - 2018-04-23 05:45:33 --> Router Class Initialized
INFO - 2018-04-23 05:45:33 --> Output Class Initialized
INFO - 2018-04-23 05:45:33 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:33 --> Input Class Initialized
INFO - 2018-04-23 05:45:33 --> Language Class Initialized
ERROR - 2018-04-23 05:45:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
INFO - 2018-04-23 05:45:34 --> Loader Class Initialized
INFO - 2018-04-23 05:45:34 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:34 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:34 --> Email Class Initialized
INFO - 2018-04-23 05:45:34 --> Controller Class Initialized
INFO - 2018-04-23 05:45:34 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:34 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:34 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:34 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:34 --> Model Class Initialized
INFO - 2018-04-23 05:45:34 --> Model Class Initialized
INFO - 2018-04-23 05:45:34 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 05:45:34 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 05:45:34 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 05:45:34 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 05:45:34 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 05:45:34 --> Final output sent to browser
DEBUG - 2018-04-23 05:45:34 --> Total execution time: 0.0037
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:34 --> Config Class Initialized
INFO - 2018-04-23 05:45:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:34 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:34 --> URI Class Initialized
INFO - 2018-04-23 05:45:34 --> Router Class Initialized
INFO - 2018-04-23 05:45:34 --> Output Class Initialized
INFO - 2018-04-23 05:45:34 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:34 --> Input Class Initialized
INFO - 2018-04-23 05:45:34 --> Language Class Initialized
ERROR - 2018-04-23 05:45:34 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
INFO - 2018-04-23 05:45:35 --> Loader Class Initialized
INFO - 2018-04-23 05:45:35 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:35 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:35 --> Email Class Initialized
INFO - 2018-04-23 05:45:35 --> Controller Class Initialized
INFO - 2018-04-23 05:45:35 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:35 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:35 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:35 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:35 --> Model Class Initialized
INFO - 2018-04-23 05:45:35 --> Model Class Initialized
INFO - 2018-04-23 05:45:35 --> Model Class Initialized
INFO - 2018-04-23 11:15:35 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:35 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:35 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 11:15:35 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:35 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:35 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:35 --> Total execution time: 0.0022
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
ERROR - 2018-04-23 05:45:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
ERROR - 2018-04-23 05:45:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
ERROR - 2018-04-23 05:45:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
ERROR - 2018-04-23 05:45:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
ERROR - 2018-04-23 05:45:35 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:35 --> Config Class Initialized
INFO - 2018-04-23 05:45:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:35 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:35 --> URI Class Initialized
INFO - 2018-04-23 05:45:35 --> Router Class Initialized
INFO - 2018-04-23 05:45:35 --> Output Class Initialized
INFO - 2018-04-23 05:45:35 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:35 --> Input Class Initialized
INFO - 2018-04-23 05:45:35 --> Language Class Initialized
ERROR - 2018-04-23 05:45:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
INFO - 2018-04-23 05:45:36 --> Loader Class Initialized
INFO - 2018-04-23 05:45:36 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:36 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:36 --> Email Class Initialized
INFO - 2018-04-23 05:45:36 --> Controller Class Initialized
INFO - 2018-04-23 05:45:36 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:36 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:36 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:36 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:36 --> Model Class Initialized
INFO - 2018-04-23 05:45:36 --> Model Class Initialized
INFO - 2018-04-23 05:45:36 --> Model Class Initialized
INFO - 2018-04-23 11:15:36 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:36 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:36 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:36 --> File loaded: /var/www/html/admin/application/views/Wishes/wishes.php
INFO - 2018-04-23 11:15:36 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:36 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:36 --> Total execution time: 0.0031
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:36 --> Config Class Initialized
INFO - 2018-04-23 05:45:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:36 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:36 --> URI Class Initialized
INFO - 2018-04-23 05:45:36 --> Router Class Initialized
INFO - 2018-04-23 05:45:36 --> Output Class Initialized
INFO - 2018-04-23 05:45:36 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:36 --> Input Class Initialized
INFO - 2018-04-23 05:45:36 --> Language Class Initialized
ERROR - 2018-04-23 05:45:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
INFO - 2018-04-23 05:45:37 --> Loader Class Initialized
INFO - 2018-04-23 05:45:37 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:37 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:37 --> Email Class Initialized
INFO - 2018-04-23 05:45:37 --> Controller Class Initialized
INFO - 2018-04-23 05:45:37 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:37 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:37 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:37 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:37 --> Model Class Initialized
INFO - 2018-04-23 05:45:37 --> Model Class Initialized
INFO - 2018-04-23 05:45:37 --> Model Class Initialized
INFO - 2018-04-23 11:15:37 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:37 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:37 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 11:15:37 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:37 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:37 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:37 --> Total execution time: 0.0023
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
ERROR - 2018-04-23 05:45:37 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
ERROR - 2018-04-23 05:45:37 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
ERROR - 2018-04-23 05:45:37 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
ERROR - 2018-04-23 05:45:37 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
ERROR - 2018-04-23 05:45:37 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:37 --> Config Class Initialized
INFO - 2018-04-23 05:45:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:37 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:37 --> URI Class Initialized
INFO - 2018-04-23 05:45:37 --> Router Class Initialized
INFO - 2018-04-23 05:45:37 --> Output Class Initialized
INFO - 2018-04-23 05:45:37 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:37 --> Input Class Initialized
INFO - 2018-04-23 05:45:37 --> Language Class Initialized
ERROR - 2018-04-23 05:45:37 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
INFO - 2018-04-23 05:45:39 --> Loader Class Initialized
INFO - 2018-04-23 05:45:39 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:39 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:39 --> Email Class Initialized
INFO - 2018-04-23 05:45:39 --> Controller Class Initialized
INFO - 2018-04-23 05:45:39 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:39 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:39 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:39 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:39 --> Model Class Initialized
INFO - 2018-04-23 05:45:39 --> Model Class Initialized
INFO - 2018-04-23 05:45:39 --> Model Class Initialized
INFO - 2018-04-23 11:15:39 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:39 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:39 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:39 --> File loaded: /var/www/html/admin/application/views/movies/movies.php
INFO - 2018-04-23 11:15:39 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:39 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:39 --> Total execution time: 0.0047
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:39 --> Config Class Initialized
INFO - 2018-04-23 05:45:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:39 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:39 --> URI Class Initialized
INFO - 2018-04-23 05:45:39 --> Router Class Initialized
INFO - 2018-04-23 05:45:39 --> Output Class Initialized
INFO - 2018-04-23 05:45:39 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:39 --> Input Class Initialized
INFO - 2018-04-23 05:45:39 --> Language Class Initialized
ERROR - 2018-04-23 05:45:39 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:40 --> Config Class Initialized
INFO - 2018-04-23 05:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:40 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:40 --> URI Class Initialized
INFO - 2018-04-23 05:45:40 --> Router Class Initialized
INFO - 2018-04-23 05:45:40 --> Output Class Initialized
INFO - 2018-04-23 05:45:40 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:40 --> Input Class Initialized
INFO - 2018-04-23 05:45:40 --> Language Class Initialized
INFO - 2018-04-23 05:45:40 --> Loader Class Initialized
INFO - 2018-04-23 05:45:40 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:40 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:40 --> Email Class Initialized
INFO - 2018-04-23 05:45:40 --> Controller Class Initialized
INFO - 2018-04-23 05:45:40 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:40 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:40 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:40 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:40 --> Model Class Initialized
INFO - 2018-04-23 05:45:40 --> Model Class Initialized
INFO - 2018-04-23 05:45:40 --> Model Class Initialized
INFO - 2018-04-23 11:15:40 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:40 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:40 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 11:15:40 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:40 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:40 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:40 --> Total execution time: 0.0023
INFO - 2018-04-23 05:45:40 --> Config Class Initialized
INFO - 2018-04-23 05:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:40 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:40 --> URI Class Initialized
INFO - 2018-04-23 05:45:40 --> Router Class Initialized
INFO - 2018-04-23 05:45:40 --> Output Class Initialized
INFO - 2018-04-23 05:45:40 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:40 --> Input Class Initialized
INFO - 2018-04-23 05:45:40 --> Language Class Initialized
ERROR - 2018-04-23 05:45:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:40 --> Config Class Initialized
INFO - 2018-04-23 05:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:40 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:40 --> URI Class Initialized
INFO - 2018-04-23 05:45:40 --> Router Class Initialized
INFO - 2018-04-23 05:45:40 --> Output Class Initialized
INFO - 2018-04-23 05:45:40 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:40 --> Input Class Initialized
INFO - 2018-04-23 05:45:40 --> Language Class Initialized
ERROR - 2018-04-23 05:45:40 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:40 --> Config Class Initialized
INFO - 2018-04-23 05:45:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:40 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:40 --> URI Class Initialized
INFO - 2018-04-23 05:45:40 --> Router Class Initialized
INFO - 2018-04-23 05:45:40 --> Output Class Initialized
INFO - 2018-04-23 05:45:40 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:40 --> Input Class Initialized
INFO - 2018-04-23 05:45:40 --> Language Class Initialized
ERROR - 2018-04-23 05:45:40 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
INFO - 2018-04-23 05:45:41 --> Loader Class Initialized
INFO - 2018-04-23 05:45:41 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:41 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:41 --> Email Class Initialized
INFO - 2018-04-23 05:45:41 --> Controller Class Initialized
INFO - 2018-04-23 05:45:41 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:41 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:41 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:41 --> Model Class Initialized
INFO - 2018-04-23 05:45:41 --> Model Class Initialized
INFO - 2018-04-23 05:45:41 --> Model Class Initialized
INFO - 2018-04-23 11:15:41 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:41 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:41 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:41 --> File loaded: /var/www/html/admin/application/views/movies/movies.php
INFO - 2018-04-23 11:15:41 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:41 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:41 --> Total execution time: 0.0026
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:41 --> Config Class Initialized
INFO - 2018-04-23 05:45:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:41 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:41 --> URI Class Initialized
INFO - 2018-04-23 05:45:41 --> Router Class Initialized
INFO - 2018-04-23 05:45:41 --> Output Class Initialized
INFO - 2018-04-23 05:45:41 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:41 --> Input Class Initialized
INFO - 2018-04-23 05:45:41 --> Language Class Initialized
ERROR - 2018-04-23 05:45:41 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:42 --> Config Class Initialized
INFO - 2018-04-23 05:45:42 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:42 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:42 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:42 --> URI Class Initialized
INFO - 2018-04-23 05:45:42 --> Router Class Initialized
INFO - 2018-04-23 05:45:42 --> Output Class Initialized
INFO - 2018-04-23 05:45:42 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:42 --> Input Class Initialized
INFO - 2018-04-23 05:45:42 --> Language Class Initialized
ERROR - 2018-04-23 05:45:42 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
INFO - 2018-04-23 05:45:43 --> Loader Class Initialized
INFO - 2018-04-23 05:45:43 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:43 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:43 --> Email Class Initialized
INFO - 2018-04-23 05:45:43 --> Controller Class Initialized
INFO - 2018-04-23 05:45:43 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:43 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:43 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:43 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:43 --> Model Class Initialized
INFO - 2018-04-23 05:45:43 --> Model Class Initialized
INFO - 2018-04-23 05:45:43 --> Model Class Initialized
INFO - 2018-04-23 11:15:43 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:43 --> File loaded: /var/www/html/admin/application/views/calender.php
INFO - 2018-04-23 11:15:43 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:43 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:43 --> File loaded: /var/www/html/admin/application/views/movies/editTrailer.php
INFO - 2018-04-23 11:15:43 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:43 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:43 --> Total execution time: 0.0027
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
ERROR - 2018-04-23 05:45:43 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
ERROR - 2018-04-23 05:45:43 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
ERROR - 2018-04-23 05:45:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
ERROR - 2018-04-23 05:45:43 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
ERROR - 2018-04-23 05:45:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:43 --> Config Class Initialized
INFO - 2018-04-23 05:45:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:43 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:43 --> URI Class Initialized
INFO - 2018-04-23 05:45:43 --> Router Class Initialized
INFO - 2018-04-23 05:45:43 --> Output Class Initialized
INFO - 2018-04-23 05:45:43 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:43 --> Input Class Initialized
INFO - 2018-04-23 05:45:43 --> Language Class Initialized
ERROR - 2018-04-23 05:45:43 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:44 --> Config Class Initialized
INFO - 2018-04-23 05:45:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:44 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:44 --> URI Class Initialized
INFO - 2018-04-23 05:45:44 --> Router Class Initialized
INFO - 2018-04-23 05:45:44 --> Output Class Initialized
INFO - 2018-04-23 05:45:44 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:44 --> Input Class Initialized
INFO - 2018-04-23 05:45:44 --> Language Class Initialized
ERROR - 2018-04-23 05:45:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:44 --> Config Class Initialized
INFO - 2018-04-23 05:45:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:44 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:44 --> URI Class Initialized
INFO - 2018-04-23 05:45:44 --> Router Class Initialized
INFO - 2018-04-23 05:45:44 --> Output Class Initialized
INFO - 2018-04-23 05:45:44 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:44 --> Input Class Initialized
INFO - 2018-04-23 05:45:44 --> Language Class Initialized
ERROR - 2018-04-23 05:45:44 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:44 --> Config Class Initialized
INFO - 2018-04-23 05:45:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:44 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:44 --> URI Class Initialized
INFO - 2018-04-23 05:45:44 --> Router Class Initialized
INFO - 2018-04-23 05:45:44 --> Output Class Initialized
INFO - 2018-04-23 05:45:44 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:44 --> Input Class Initialized
INFO - 2018-04-23 05:45:44 --> Language Class Initialized
ERROR - 2018-04-23 05:45:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
INFO - 2018-04-23 05:45:48 --> Loader Class Initialized
INFO - 2018-04-23 05:45:48 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:48 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:48 --> Email Class Initialized
INFO - 2018-04-23 05:45:48 --> Controller Class Initialized
INFO - 2018-04-23 05:45:48 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:48 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:48 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:48 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:48 --> Model Class Initialized
INFO - 2018-04-23 05:45:48 --> Model Class Initialized
INFO - 2018-04-23 05:45:48 --> Model Class Initialized
INFO - 2018-04-23 11:15:48 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:48 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:48 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:48 --> File loaded: /var/www/html/admin/application/views/movies/movies.php
INFO - 2018-04-23 11:15:48 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:48 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:48 --> Total execution time: 0.0027
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
ERROR - 2018-04-23 05:45:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2018-04-23 05:45:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
ERROR - 2018-04-23 05:45:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
ERROR - 2018-04-23 05:45:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
ERROR - 2018-04-23 05:45:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:48 --> Config Class Initialized
INFO - 2018-04-23 05:45:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:48 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:48 --> URI Class Initialized
INFO - 2018-04-23 05:45:48 --> Router Class Initialized
INFO - 2018-04-23 05:45:48 --> Output Class Initialized
INFO - 2018-04-23 05:45:48 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:48 --> Input Class Initialized
INFO - 2018-04-23 05:45:48 --> Language Class Initialized
ERROR - 2018-04-23 05:45:48 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
INFO - 2018-04-23 05:45:52 --> Loader Class Initialized
INFO - 2018-04-23 05:45:52 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:52 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:52 --> Email Class Initialized
INFO - 2018-04-23 05:45:52 --> Controller Class Initialized
INFO - 2018-04-23 05:45:52 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:52 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:52 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:52 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:52 --> Model Class Initialized
INFO - 2018-04-23 05:45:52 --> Model Class Initialized
INFO - 2018-04-23 05:45:52 --> Model Class Initialized
INFO - 2018-04-23 11:15:52 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:52 --> File loaded: /var/www/html/admin/application/views/calender.php
INFO - 2018-04-23 11:15:52 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:52 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:52 --> File loaded: /var/www/html/admin/application/views/movies/editTrailer.php
INFO - 2018-04-23 11:15:52 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:52 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:52 --> Total execution time: 0.0025
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:52 --> Config Class Initialized
INFO - 2018-04-23 05:45:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:52 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:52 --> URI Class Initialized
INFO - 2018-04-23 05:45:52 --> Router Class Initialized
INFO - 2018-04-23 05:45:52 --> Output Class Initialized
INFO - 2018-04-23 05:45:52 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:52 --> Input Class Initialized
INFO - 2018-04-23 05:45:52 --> Language Class Initialized
ERROR - 2018-04-23 05:45:52 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 05:45:58 --> Config Class Initialized
INFO - 2018-04-23 05:45:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:58 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:58 --> URI Class Initialized
INFO - 2018-04-23 05:45:58 --> Router Class Initialized
INFO - 2018-04-23 05:45:58 --> Output Class Initialized
INFO - 2018-04-23 05:45:58 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:58 --> Input Class Initialized
INFO - 2018-04-23 05:45:58 --> Language Class Initialized
INFO - 2018-04-23 05:45:58 --> Loader Class Initialized
INFO - 2018-04-23 05:45:58 --> Helper loaded: common_helper
INFO - 2018-04-23 05:45:58 --> Database Driver Class Initialized
INFO - 2018-04-23 05:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 05:45:58 --> Email Class Initialized
INFO - 2018-04-23 05:45:58 --> Controller Class Initialized
INFO - 2018-04-23 05:45:58 --> Helper loaded: form_helper
INFO - 2018-04-23 05:45:58 --> Form Validation Class Initialized
INFO - 2018-04-23 05:45:58 --> Helper loaded: email_helper
DEBUG - 2018-04-23 05:45:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 05:45:58 --> Helper loaded: url_helper
INFO - 2018-04-23 05:45:58 --> Model Class Initialized
INFO - 2018-04-23 05:45:58 --> Model Class Initialized
INFO - 2018-04-23 05:45:58 --> Model Class Initialized
INFO - 2018-04-23 11:15:58 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:15:58 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:15:58 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:15:58 --> File loaded: /var/www/html/admin/application/views/movies/movies.php
INFO - 2018-04-23 11:15:58 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:15:58 --> Final output sent to browser
DEBUG - 2018-04-23 11:15:58 --> Total execution time: 0.0055
INFO - 2018-04-23 05:45:58 --> Config Class Initialized
INFO - 2018-04-23 05:45:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:58 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:58 --> URI Class Initialized
INFO - 2018-04-23 05:45:58 --> Router Class Initialized
INFO - 2018-04-23 05:45:58 --> Output Class Initialized
INFO - 2018-04-23 05:45:58 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:58 --> Input Class Initialized
INFO - 2018-04-23 05:45:58 --> Language Class Initialized
ERROR - 2018-04-23 05:45:58 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:58 --> Config Class Initialized
INFO - 2018-04-23 05:45:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:58 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:58 --> URI Class Initialized
INFO - 2018-04-23 05:45:58 --> Router Class Initialized
INFO - 2018-04-23 05:45:58 --> Output Class Initialized
INFO - 2018-04-23 05:45:58 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:58 --> Input Class Initialized
INFO - 2018-04-23 05:45:58 --> Language Class Initialized
ERROR - 2018-04-23 05:45:58 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 05:45:58 --> Config Class Initialized
INFO - 2018-04-23 05:45:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:58 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:58 --> URI Class Initialized
INFO - 2018-04-23 05:45:58 --> Router Class Initialized
INFO - 2018-04-23 05:45:58 --> Output Class Initialized
INFO - 2018-04-23 05:45:58 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:58 --> Input Class Initialized
INFO - 2018-04-23 05:45:58 --> Language Class Initialized
ERROR - 2018-04-23 05:45:58 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 05:45:58 --> Config Class Initialized
INFO - 2018-04-23 05:45:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 05:45:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 05:45:58 --> Utf8 Class Initialized
INFO - 2018-04-23 05:45:58 --> URI Class Initialized
INFO - 2018-04-23 05:45:58 --> Router Class Initialized
INFO - 2018-04-23 05:45:58 --> Output Class Initialized
INFO - 2018-04-23 05:45:58 --> Security Class Initialized
DEBUG - 2018-04-23 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 05:45:58 --> Input Class Initialized
INFO - 2018-04-23 05:45:58 --> Language Class Initialized
ERROR - 2018-04-23 05:45:58 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
INFO - 2018-04-23 06:02:11 --> Loader Class Initialized
INFO - 2018-04-23 06:02:11 --> Helper loaded: common_helper
INFO - 2018-04-23 06:02:11 --> Database Driver Class Initialized
INFO - 2018-04-23 06:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 06:02:11 --> Email Class Initialized
INFO - 2018-04-23 06:02:11 --> Controller Class Initialized
INFO - 2018-04-23 06:02:11 --> Helper loaded: form_helper
INFO - 2018-04-23 06:02:11 --> Form Validation Class Initialized
INFO - 2018-04-23 06:02:11 --> Helper loaded: email_helper
DEBUG - 2018-04-23 06:02:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 06:02:11 --> Helper loaded: url_helper
INFO - 2018-04-23 06:02:11 --> Model Class Initialized
INFO - 2018-04-23 06:02:11 --> Model Class Initialized
INFO - 2018-04-23 06:02:11 --> Model Class Initialized
INFO - 2018-04-23 11:32:11 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:32:11 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:32:11 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:32:11 --> File loaded: /var/www/html/admin/application/views/movies/movies.php
INFO - 2018-04-23 11:32:11 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:32:11 --> Final output sent to browser
DEBUG - 2018-04-23 11:32:11 --> Total execution time: 0.0027
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 06:02:11 --> Config Class Initialized
INFO - 2018-04-23 06:02:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:02:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:02:11 --> Utf8 Class Initialized
INFO - 2018-04-23 06:02:11 --> URI Class Initialized
INFO - 2018-04-23 06:02:11 --> Router Class Initialized
INFO - 2018-04-23 06:02:11 --> Output Class Initialized
INFO - 2018-04-23 06:02:11 --> Security Class Initialized
DEBUG - 2018-04-23 06:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:02:11 --> Input Class Initialized
INFO - 2018-04-23 06:02:11 --> Language Class Initialized
ERROR - 2018-04-23 06:02:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
INFO - 2018-04-23 06:17:29 --> Loader Class Initialized
INFO - 2018-04-23 06:17:29 --> Helper loaded: common_helper
INFO - 2018-04-23 06:17:29 --> Database Driver Class Initialized
INFO - 2018-04-23 06:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 06:17:29 --> Email Class Initialized
INFO - 2018-04-23 06:17:29 --> Controller Class Initialized
INFO - 2018-04-23 06:17:29 --> Helper loaded: form_helper
INFO - 2018-04-23 06:17:29 --> Form Validation Class Initialized
INFO - 2018-04-23 06:17:29 --> Helper loaded: email_helper
DEBUG - 2018-04-23 06:17:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 06:17:29 --> Helper loaded: url_helper
INFO - 2018-04-23 06:17:29 --> Model Class Initialized
INFO - 2018-04-23 06:17:29 --> Model Class Initialized
INFO - 2018-04-23 06:17:29 --> Model Class Initialized
INFO - 2018-04-23 11:47:29 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:47:29 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:47:29 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:47:29 --> File loaded: /var/www/html/admin/application/views/movies/movies.php
INFO - 2018-04-23 11:47:29 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:47:29 --> Final output sent to browser
DEBUG - 2018-04-23 11:47:29 --> Total execution time: 0.0027
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 06:17:29 --> Config Class Initialized
INFO - 2018-04-23 06:17:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:17:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:17:29 --> Utf8 Class Initialized
INFO - 2018-04-23 06:17:29 --> URI Class Initialized
INFO - 2018-04-23 06:17:29 --> Router Class Initialized
INFO - 2018-04-23 06:17:29 --> Output Class Initialized
INFO - 2018-04-23 06:17:29 --> Security Class Initialized
DEBUG - 2018-04-23 06:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:17:29 --> Input Class Initialized
INFO - 2018-04-23 06:17:29 --> Language Class Initialized
ERROR - 2018-04-23 06:17:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:38:48 --> Config Class Initialized
INFO - 2018-04-23 06:38:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:48 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:48 --> URI Class Initialized
INFO - 2018-04-23 06:38:48 --> Router Class Initialized
INFO - 2018-04-23 06:38:48 --> Output Class Initialized
INFO - 2018-04-23 06:38:48 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:48 --> Input Class Initialized
INFO - 2018-04-23 06:38:48 --> Language Class Initialized
INFO - 2018-04-23 06:38:48 --> Loader Class Initialized
INFO - 2018-04-23 06:38:48 --> Helper loaded: common_helper
INFO - 2018-04-23 06:38:48 --> Database Driver Class Initialized
INFO - 2018-04-23 06:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 06:38:48 --> Email Class Initialized
INFO - 2018-04-23 06:38:48 --> Controller Class Initialized
INFO - 2018-04-23 06:38:48 --> Helper loaded: form_helper
INFO - 2018-04-23 06:38:48 --> Form Validation Class Initialized
INFO - 2018-04-23 06:38:48 --> Helper loaded: email_helper
DEBUG - 2018-04-23 06:38:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 06:38:48 --> Helper loaded: url_helper
INFO - 2018-04-23 06:38:48 --> Model Class Initialized
INFO - 2018-04-23 06:38:48 --> Model Class Initialized
INFO - 2018-04-23 06:38:48 --> Model Class Initialized
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/calender.php
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/movies/addMovie.php
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:08:48 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:08:48 --> Final output sent to browser
DEBUG - 2018-04-23 12:08:48 --> Total execution time: 0.0293
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 06:38:49 --> Config Class Initialized
INFO - 2018-04-23 06:38:49 --> Hooks Class Initialized
DEBUG - 2018-04-23 06:38:49 --> UTF-8 Support Enabled
INFO - 2018-04-23 06:38:49 --> Utf8 Class Initialized
INFO - 2018-04-23 06:38:49 --> URI Class Initialized
INFO - 2018-04-23 06:38:49 --> Router Class Initialized
INFO - 2018-04-23 06:38:49 --> Output Class Initialized
INFO - 2018-04-23 06:38:49 --> Security Class Initialized
DEBUG - 2018-04-23 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 06:38:49 --> Input Class Initialized
INFO - 2018-04-23 06:38:49 --> Language Class Initialized
ERROR - 2018-04-23 06:38:49 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
INFO - 2018-04-23 07:18:44 --> Loader Class Initialized
INFO - 2018-04-23 07:18:44 --> Helper loaded: common_helper
INFO - 2018-04-23 07:18:44 --> Database Driver Class Initialized
INFO - 2018-04-23 07:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 07:18:44 --> Email Class Initialized
INFO - 2018-04-23 07:18:44 --> Controller Class Initialized
INFO - 2018-04-23 07:18:44 --> Helper loaded: form_helper
INFO - 2018-04-23 07:18:44 --> Form Validation Class Initialized
INFO - 2018-04-23 07:18:44 --> Helper loaded: email_helper
DEBUG - 2018-04-23 07:18:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 07:18:44 --> Helper loaded: url_helper
INFO - 2018-04-23 07:18:44 --> Model Class Initialized
INFO - 2018-04-23 07:18:44 --> Model Class Initialized
INFO - 2018-04-23 07:18:44 --> Model Class Initialized
INFO - 2018-04-23 12:48:44 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:48:44 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:48:44 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:48:44 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 12:48:44 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:48:44 --> Final output sent to browser
DEBUG - 2018-04-23 12:48:44 --> Total execution time: 0.0073
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
ERROR - 2018-04-23 07:18:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
ERROR - 2018-04-23 07:18:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
ERROR - 2018-04-23 07:18:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
ERROR - 2018-04-23 07:18:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
ERROR - 2018-04-23 07:18:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:44 --> Config Class Initialized
INFO - 2018-04-23 07:18:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:44 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:44 --> URI Class Initialized
INFO - 2018-04-23 07:18:44 --> Router Class Initialized
INFO - 2018-04-23 07:18:44 --> Output Class Initialized
INFO - 2018-04-23 07:18:44 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:44 --> Input Class Initialized
INFO - 2018-04-23 07:18:44 --> Language Class Initialized
ERROR - 2018-04-23 07:18:44 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 07:18:45 --> Config Class Initialized
INFO - 2018-04-23 07:18:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:45 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:45 --> URI Class Initialized
INFO - 2018-04-23 07:18:45 --> Router Class Initialized
INFO - 2018-04-23 07:18:45 --> Output Class Initialized
INFO - 2018-04-23 07:18:45 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:45 --> Input Class Initialized
INFO - 2018-04-23 07:18:45 --> Language Class Initialized
INFO - 2018-04-23 07:18:45 --> Loader Class Initialized
INFO - 2018-04-23 07:18:45 --> Helper loaded: common_helper
INFO - 2018-04-23 07:18:45 --> Database Driver Class Initialized
INFO - 2018-04-23 07:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 07:18:45 --> Email Class Initialized
INFO - 2018-04-23 07:18:45 --> Controller Class Initialized
INFO - 2018-04-23 07:18:45 --> Helper loaded: form_helper
INFO - 2018-04-23 07:18:45 --> Form Validation Class Initialized
INFO - 2018-04-23 07:18:45 --> Helper loaded: email_helper
DEBUG - 2018-04-23 07:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 07:18:45 --> Helper loaded: url_helper
INFO - 2018-04-23 07:18:45 --> Model Class Initialized
INFO - 2018-04-23 07:18:45 --> Model Class Initialized
INFO - 2018-04-23 07:18:45 --> Model Class Initialized
INFO - 2018-04-23 12:48:45 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:48:45 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:48:45 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:48:45 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 12:48:45 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:48:45 --> Final output sent to browser
DEBUG - 2018-04-23 12:48:45 --> Total execution time: 0.0031
INFO - 2018-04-23 07:18:45 --> Config Class Initialized
INFO - 2018-04-23 07:18:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:45 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:45 --> URI Class Initialized
INFO - 2018-04-23 07:18:45 --> Router Class Initialized
INFO - 2018-04-23 07:18:45 --> Output Class Initialized
INFO - 2018-04-23 07:18:45 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:45 --> Input Class Initialized
INFO - 2018-04-23 07:18:45 --> Language Class Initialized
ERROR - 2018-04-23 07:18:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:45 --> Config Class Initialized
INFO - 2018-04-23 07:18:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:45 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:45 --> URI Class Initialized
INFO - 2018-04-23 07:18:45 --> Router Class Initialized
INFO - 2018-04-23 07:18:45 --> Output Class Initialized
INFO - 2018-04-23 07:18:45 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:45 --> Input Class Initialized
INFO - 2018-04-23 07:18:45 --> Language Class Initialized
ERROR - 2018-04-23 07:18:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:45 --> Config Class Initialized
INFO - 2018-04-23 07:18:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:45 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:45 --> URI Class Initialized
INFO - 2018-04-23 07:18:45 --> Router Class Initialized
INFO - 2018-04-23 07:18:45 --> Output Class Initialized
INFO - 2018-04-23 07:18:45 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:45 --> Input Class Initialized
INFO - 2018-04-23 07:18:45 --> Language Class Initialized
ERROR - 2018-04-23 07:18:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
INFO - 2018-04-23 07:18:46 --> Loader Class Initialized
INFO - 2018-04-23 07:18:46 --> Helper loaded: common_helper
INFO - 2018-04-23 07:18:46 --> Database Driver Class Initialized
INFO - 2018-04-23 07:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 07:18:46 --> Email Class Initialized
INFO - 2018-04-23 07:18:46 --> Controller Class Initialized
INFO - 2018-04-23 07:18:46 --> Helper loaded: form_helper
INFO - 2018-04-23 07:18:46 --> Form Validation Class Initialized
INFO - 2018-04-23 07:18:46 --> Helper loaded: email_helper
DEBUG - 2018-04-23 07:18:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 07:18:46 --> Helper loaded: url_helper
INFO - 2018-04-23 07:18:46 --> Model Class Initialized
INFO - 2018-04-23 07:18:46 --> Model Class Initialized
INFO - 2018-04-23 07:18:46 --> Model Class Initialized
INFO - 2018-04-23 12:48:46 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:48:46 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:48:46 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:48:46 --> File loaded: /var/www/html/admin/application/views/Celebrity/addcelebrity.php
INFO - 2018-04-23 12:48:46 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:48:46 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:48:46 --> Final output sent to browser
DEBUG - 2018-04-23 12:48:46 --> Total execution time: 0.0027
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 07:18:46 --> Config Class Initialized
INFO - 2018-04-23 07:18:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 07:18:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 07:18:46 --> Utf8 Class Initialized
INFO - 2018-04-23 07:18:46 --> URI Class Initialized
INFO - 2018-04-23 07:18:46 --> Router Class Initialized
INFO - 2018-04-23 07:18:46 --> Output Class Initialized
INFO - 2018-04-23 07:18:46 --> Security Class Initialized
DEBUG - 2018-04-23 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 07:18:46 --> Input Class Initialized
INFO - 2018-04-23 07:18:46 --> Language Class Initialized
ERROR - 2018-04-23 07:18:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:21 --> Config Class Initialized
INFO - 2018-04-23 10:51:21 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:21 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:21 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:21 --> URI Class Initialized
DEBUG - 2018-04-23 10:51:21 --> No URI present. Default controller set.
INFO - 2018-04-23 10:51:21 --> Router Class Initialized
INFO - 2018-04-23 10:51:21 --> Output Class Initialized
INFO - 2018-04-23 10:51:21 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:21 --> Input Class Initialized
INFO - 2018-04-23 10:51:21 --> Language Class Initialized
INFO - 2018-04-23 10:51:21 --> Loader Class Initialized
INFO - 2018-04-23 10:51:21 --> Helper loaded: common_helper
INFO - 2018-04-23 10:51:21 --> Database Driver Class Initialized
INFO - 2018-04-23 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:51:21 --> Email Class Initialized
INFO - 2018-04-23 10:51:21 --> Controller Class Initialized
INFO - 2018-04-23 10:51:21 --> Helper loaded: form_helper
INFO - 2018-04-23 10:51:21 --> Form Validation Class Initialized
INFO - 2018-04-23 10:51:21 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:21 --> Helper loaded: url_helper
INFO - 2018-04-23 10:51:21 --> Model Class Initialized
INFO - 2018-04-23 10:51:21 --> Model Class Initialized
DEBUG - 2018-04-23 10:51:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 10:51:21 --> Config Class Initialized
INFO - 2018-04-23 10:51:21 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:21 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:21 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:21 --> URI Class Initialized
INFO - 2018-04-23 10:51:21 --> Router Class Initialized
INFO - 2018-04-23 10:51:21 --> Output Class Initialized
INFO - 2018-04-23 10:51:21 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:21 --> Input Class Initialized
INFO - 2018-04-23 10:51:21 --> Language Class Initialized
INFO - 2018-04-23 10:51:21 --> Loader Class Initialized
INFO - 2018-04-23 10:51:21 --> Helper loaded: common_helper
INFO - 2018-04-23 10:51:21 --> Database Driver Class Initialized
INFO - 2018-04-23 10:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:51:21 --> Email Class Initialized
INFO - 2018-04-23 10:51:21 --> Controller Class Initialized
INFO - 2018-04-23 10:51:21 --> Helper loaded: form_helper
INFO - 2018-04-23 10:51:21 --> Form Validation Class Initialized
INFO - 2018-04-23 10:51:21 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:51:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:21 --> Helper loaded: url_helper
INFO - 2018-04-23 10:51:21 --> Model Class Initialized
INFO - 2018-04-23 10:51:21 --> Model Class Initialized
INFO - 2018-04-23 10:51:21 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 10:51:21 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 10:51:21 --> Undefined variable: categories
ERROR - 2018-04-23 10:51:21 --> Severity: Notice --> Undefined variable: categories /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 10:51:21 --> Trying to get property of non-object
ERROR - 2018-04-23 10:51:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 10:51:21 --> Undefined variable: articles
ERROR - 2018-04-23 10:51:21 --> Severity: Notice --> Undefined variable: articles /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 10:51:21 --> Trying to get property of non-object
ERROR - 2018-04-23 10:51:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 10:51:21 --> Undefined variable: subscriptions
ERROR - 2018-04-23 10:51:21 --> Severity: Notice --> Undefined variable: subscriptions /var/www/html/admin/application/views/dashboard.php 67
ERROR - 2018-04-23 10:51:21 --> Trying to get property of non-object
ERROR - 2018-04-23 10:51:21 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 67
INFO - 2018-04-23 10:51:21 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 10:51:21 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 10:51:21 --> Final output sent to browser
DEBUG - 2018-04-23 10:51:21 --> Total execution time: 0.0029
INFO - 2018-04-23 10:51:21 --> Config Class Initialized
INFO - 2018-04-23 10:51:21 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:21 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:21 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:21 --> URI Class Initialized
INFO - 2018-04-23 10:51:21 --> Router Class Initialized
INFO - 2018-04-23 10:51:21 --> Output Class Initialized
INFO - 2018-04-23 10:51:21 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:21 --> Input Class Initialized
INFO - 2018-04-23 10:51:21 --> Language Class Initialized
ERROR - 2018-04-23 10:51:21 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:22 --> Config Class Initialized
INFO - 2018-04-23 10:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:22 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:22 --> URI Class Initialized
INFO - 2018-04-23 10:51:22 --> Router Class Initialized
INFO - 2018-04-23 10:51:22 --> Output Class Initialized
INFO - 2018-04-23 10:51:22 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:22 --> Input Class Initialized
INFO - 2018-04-23 10:51:22 --> Language Class Initialized
ERROR - 2018-04-23 10:51:22 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:22 --> Config Class Initialized
INFO - 2018-04-23 10:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:22 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:22 --> URI Class Initialized
INFO - 2018-04-23 10:51:22 --> Router Class Initialized
INFO - 2018-04-23 10:51:22 --> Output Class Initialized
INFO - 2018-04-23 10:51:22 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:22 --> Input Class Initialized
INFO - 2018-04-23 10:51:22 --> Language Class Initialized
ERROR - 2018-04-23 10:51:22 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:22 --> Config Class Initialized
INFO - 2018-04-23 10:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:22 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:22 --> URI Class Initialized
INFO - 2018-04-23 10:51:22 --> Router Class Initialized
INFO - 2018-04-23 10:51:22 --> Output Class Initialized
INFO - 2018-04-23 10:51:22 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:22 --> Input Class Initialized
INFO - 2018-04-23 10:51:22 --> Language Class Initialized
ERROR - 2018-04-23 10:51:22 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:22 --> Config Class Initialized
INFO - 2018-04-23 10:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:22 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:22 --> URI Class Initialized
INFO - 2018-04-23 10:51:22 --> Router Class Initialized
INFO - 2018-04-23 10:51:22 --> Output Class Initialized
INFO - 2018-04-23 10:51:22 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:22 --> Input Class Initialized
INFO - 2018-04-23 10:51:22 --> Language Class Initialized
ERROR - 2018-04-23 10:51:22 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:51:22 --> Config Class Initialized
INFO - 2018-04-23 10:51:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:22 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:22 --> URI Class Initialized
INFO - 2018-04-23 10:51:22 --> Router Class Initialized
INFO - 2018-04-23 10:51:22 --> Output Class Initialized
INFO - 2018-04-23 10:51:22 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:22 --> Input Class Initialized
INFO - 2018-04-23 10:51:22 --> Language Class Initialized
ERROR - 2018-04-23 10:51:22 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:28 --> Config Class Initialized
INFO - 2018-04-23 10:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:28 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:28 --> URI Class Initialized
INFO - 2018-04-23 10:51:28 --> Router Class Initialized
INFO - 2018-04-23 10:51:28 --> Output Class Initialized
INFO - 2018-04-23 10:51:28 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:28 --> Input Class Initialized
INFO - 2018-04-23 10:51:28 --> Language Class Initialized
INFO - 2018-04-23 10:51:28 --> Loader Class Initialized
INFO - 2018-04-23 10:51:28 --> Helper loaded: common_helper
INFO - 2018-04-23 10:51:28 --> Database Driver Class Initialized
INFO - 2018-04-23 10:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:51:28 --> Email Class Initialized
INFO - 2018-04-23 10:51:28 --> Controller Class Initialized
INFO - 2018-04-23 10:51:28 --> Helper loaded: form_helper
INFO - 2018-04-23 10:51:28 --> Form Validation Class Initialized
INFO - 2018-04-23 10:51:28 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:51:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:28 --> Helper loaded: url_helper
INFO - 2018-04-23 10:51:28 --> Model Class Initialized
INFO - 2018-04-23 10:51:28 --> Model Class Initialized
INFO - 2018-04-23 10:51:28 --> Model Class Initialized
INFO - 2018-04-23 16:21:28 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 16:21:28 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 16:21:28 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 16:21:28 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 16:21:28 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 16:21:28 --> Final output sent to browser
DEBUG - 2018-04-23 16:21:28 --> Total execution time: 0.0031
INFO - 2018-04-23 10:51:28 --> Config Class Initialized
INFO - 2018-04-23 10:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:28 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:28 --> URI Class Initialized
INFO - 2018-04-23 10:51:28 --> Router Class Initialized
INFO - 2018-04-23 10:51:28 --> Output Class Initialized
INFO - 2018-04-23 10:51:28 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:28 --> Input Class Initialized
INFO - 2018-04-23 10:51:28 --> Language Class Initialized
ERROR - 2018-04-23 10:51:28 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:28 --> Config Class Initialized
INFO - 2018-04-23 10:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:28 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:28 --> URI Class Initialized
INFO - 2018-04-23 10:51:28 --> Router Class Initialized
INFO - 2018-04-23 10:51:28 --> Output Class Initialized
INFO - 2018-04-23 10:51:28 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:28 --> Input Class Initialized
INFO - 2018-04-23 10:51:28 --> Language Class Initialized
ERROR - 2018-04-23 10:51:28 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:28 --> Config Class Initialized
INFO - 2018-04-23 10:51:28 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:28 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:28 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:28 --> URI Class Initialized
INFO - 2018-04-23 10:51:28 --> Router Class Initialized
INFO - 2018-04-23 10:51:28 --> Output Class Initialized
INFO - 2018-04-23 10:51:28 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:28 --> Input Class Initialized
INFO - 2018-04-23 10:51:28 --> Language Class Initialized
ERROR - 2018-04-23 10:51:28 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:29 --> Config Class Initialized
INFO - 2018-04-23 10:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:29 --> URI Class Initialized
INFO - 2018-04-23 10:51:29 --> Router Class Initialized
INFO - 2018-04-23 10:51:29 --> Output Class Initialized
INFO - 2018-04-23 10:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:29 --> Input Class Initialized
INFO - 2018-04-23 10:51:29 --> Language Class Initialized
ERROR - 2018-04-23 10:51:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:29 --> Config Class Initialized
INFO - 2018-04-23 10:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:29 --> URI Class Initialized
INFO - 2018-04-23 10:51:29 --> Router Class Initialized
INFO - 2018-04-23 10:51:29 --> Output Class Initialized
INFO - 2018-04-23 10:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:29 --> Input Class Initialized
INFO - 2018-04-23 10:51:29 --> Language Class Initialized
ERROR - 2018-04-23 10:51:29 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:51:29 --> Config Class Initialized
INFO - 2018-04-23 10:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:29 --> URI Class Initialized
INFO - 2018-04-23 10:51:29 --> Router Class Initialized
INFO - 2018-04-23 10:51:29 --> Output Class Initialized
INFO - 2018-04-23 10:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:29 --> Input Class Initialized
INFO - 2018-04-23 10:51:29 --> Language Class Initialized
ERROR - 2018-04-23 10:51:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:30 --> Config Class Initialized
INFO - 2018-04-23 10:51:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:30 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:30 --> URI Class Initialized
INFO - 2018-04-23 10:51:30 --> Router Class Initialized
INFO - 2018-04-23 10:51:30 --> Output Class Initialized
INFO - 2018-04-23 10:51:30 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:30 --> Input Class Initialized
INFO - 2018-04-23 10:51:30 --> Language Class Initialized
INFO - 2018-04-23 10:51:30 --> Loader Class Initialized
INFO - 2018-04-23 10:51:30 --> Helper loaded: common_helper
INFO - 2018-04-23 10:51:30 --> Database Driver Class Initialized
INFO - 2018-04-23 10:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:51:30 --> Email Class Initialized
INFO - 2018-04-23 10:51:30 --> Controller Class Initialized
INFO - 2018-04-23 10:51:30 --> Helper loaded: form_helper
INFO - 2018-04-23 10:51:30 --> Form Validation Class Initialized
INFO - 2018-04-23 10:51:30 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:30 --> Helper loaded: url_helper
INFO - 2018-04-23 10:51:30 --> Model Class Initialized
INFO - 2018-04-23 10:51:30 --> Model Class Initialized
INFO - 2018-04-23 10:51:30 --> Model Class Initialized
INFO - 2018-04-23 16:21:30 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 16:21:30 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 16:21:30 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 16:21:30 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 16:21:30 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 16:21:30 --> Final output sent to browser
DEBUG - 2018-04-23 16:21:30 --> Total execution time: 0.0024
INFO - 2018-04-23 10:51:30 --> Config Class Initialized
INFO - 2018-04-23 10:51:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:30 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:30 --> URI Class Initialized
INFO - 2018-04-23 10:51:30 --> Router Class Initialized
INFO - 2018-04-23 10:51:30 --> Output Class Initialized
INFO - 2018-04-23 10:51:30 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:30 --> Input Class Initialized
INFO - 2018-04-23 10:51:30 --> Language Class Initialized
ERROR - 2018-04-23 10:51:30 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:30 --> Config Class Initialized
INFO - 2018-04-23 10:51:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:30 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:30 --> URI Class Initialized
INFO - 2018-04-23 10:51:30 --> Router Class Initialized
INFO - 2018-04-23 10:51:30 --> Output Class Initialized
INFO - 2018-04-23 10:51:30 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:30 --> Input Class Initialized
INFO - 2018-04-23 10:51:30 --> Language Class Initialized
ERROR - 2018-04-23 10:51:30 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:30 --> Config Class Initialized
INFO - 2018-04-23 10:51:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:30 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:30 --> URI Class Initialized
INFO - 2018-04-23 10:51:30 --> Router Class Initialized
INFO - 2018-04-23 10:51:30 --> Output Class Initialized
INFO - 2018-04-23 10:51:30 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:30 --> Input Class Initialized
INFO - 2018-04-23 10:51:30 --> Language Class Initialized
ERROR - 2018-04-23 10:51:30 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:31 --> Config Class Initialized
INFO - 2018-04-23 10:51:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:31 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:31 --> URI Class Initialized
INFO - 2018-04-23 10:51:31 --> Router Class Initialized
INFO - 2018-04-23 10:51:31 --> Output Class Initialized
INFO - 2018-04-23 10:51:31 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:31 --> Input Class Initialized
INFO - 2018-04-23 10:51:31 --> Language Class Initialized
ERROR - 2018-04-23 10:51:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:31 --> Config Class Initialized
INFO - 2018-04-23 10:51:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:31 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:31 --> URI Class Initialized
INFO - 2018-04-23 10:51:31 --> Router Class Initialized
INFO - 2018-04-23 10:51:31 --> Output Class Initialized
INFO - 2018-04-23 10:51:31 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:31 --> Input Class Initialized
INFO - 2018-04-23 10:51:31 --> Language Class Initialized
ERROR - 2018-04-23 10:51:31 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:51:31 --> Config Class Initialized
INFO - 2018-04-23 10:51:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:31 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:31 --> URI Class Initialized
INFO - 2018-04-23 10:51:31 --> Router Class Initialized
INFO - 2018-04-23 10:51:31 --> Output Class Initialized
INFO - 2018-04-23 10:51:31 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:31 --> Input Class Initialized
INFO - 2018-04-23 10:51:31 --> Language Class Initialized
ERROR - 2018-04-23 10:51:31 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:34 --> Config Class Initialized
INFO - 2018-04-23 10:51:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:34 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:34 --> URI Class Initialized
INFO - 2018-04-23 10:51:34 --> Router Class Initialized
INFO - 2018-04-23 10:51:34 --> Output Class Initialized
INFO - 2018-04-23 10:51:34 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:34 --> Input Class Initialized
INFO - 2018-04-23 10:51:34 --> Language Class Initialized
INFO - 2018-04-23 10:51:34 --> Loader Class Initialized
INFO - 2018-04-23 10:51:34 --> Helper loaded: common_helper
INFO - 2018-04-23 10:51:34 --> Database Driver Class Initialized
INFO - 2018-04-23 10:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:51:34 --> Email Class Initialized
INFO - 2018-04-23 10:51:34 --> Controller Class Initialized
INFO - 2018-04-23 10:51:34 --> Helper loaded: form_helper
INFO - 2018-04-23 10:51:34 --> Form Validation Class Initialized
INFO - 2018-04-23 10:51:34 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:34 --> Helper loaded: url_helper
INFO - 2018-04-23 10:51:34 --> Model Class Initialized
INFO - 2018-04-23 10:51:34 --> Model Class Initialized
INFO - 2018-04-23 10:51:34 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 10:51:34 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 10:51:34 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 10:51:34 --> File loaded: /var/www/html/admin/application/views/socialService/socialService.php
INFO - 2018-04-23 10:51:34 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 10:51:34 --> Final output sent to browser
DEBUG - 2018-04-23 10:51:34 --> Total execution time: 0.0041
INFO - 2018-04-23 10:51:35 --> Config Class Initialized
INFO - 2018-04-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:35 --> URI Class Initialized
INFO - 2018-04-23 10:51:35 --> Router Class Initialized
INFO - 2018-04-23 10:51:35 --> Output Class Initialized
INFO - 2018-04-23 10:51:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:35 --> Input Class Initialized
INFO - 2018-04-23 10:51:35 --> Language Class Initialized
ERROR - 2018-04-23 10:51:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:35 --> Config Class Initialized
INFO - 2018-04-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:35 --> URI Class Initialized
INFO - 2018-04-23 10:51:35 --> Router Class Initialized
INFO - 2018-04-23 10:51:35 --> Output Class Initialized
INFO - 2018-04-23 10:51:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:35 --> Input Class Initialized
INFO - 2018-04-23 10:51:35 --> Language Class Initialized
ERROR - 2018-04-23 10:51:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:35 --> Config Class Initialized
INFO - 2018-04-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:35 --> URI Class Initialized
INFO - 2018-04-23 10:51:35 --> Router Class Initialized
INFO - 2018-04-23 10:51:35 --> Output Class Initialized
INFO - 2018-04-23 10:51:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:35 --> Input Class Initialized
INFO - 2018-04-23 10:51:35 --> Language Class Initialized
ERROR - 2018-04-23 10:51:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:35 --> Config Class Initialized
INFO - 2018-04-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:35 --> URI Class Initialized
INFO - 2018-04-23 10:51:35 --> Router Class Initialized
INFO - 2018-04-23 10:51:35 --> Output Class Initialized
INFO - 2018-04-23 10:51:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:35 --> Input Class Initialized
INFO - 2018-04-23 10:51:35 --> Language Class Initialized
ERROR - 2018-04-23 10:51:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:35 --> Config Class Initialized
INFO - 2018-04-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:35 --> URI Class Initialized
INFO - 2018-04-23 10:51:35 --> Router Class Initialized
INFO - 2018-04-23 10:51:35 --> Output Class Initialized
INFO - 2018-04-23 10:51:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:35 --> Input Class Initialized
INFO - 2018-04-23 10:51:35 --> Language Class Initialized
ERROR - 2018-04-23 10:51:35 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:51:35 --> Config Class Initialized
INFO - 2018-04-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:35 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:35 --> URI Class Initialized
INFO - 2018-04-23 10:51:35 --> Router Class Initialized
INFO - 2018-04-23 10:51:35 --> Output Class Initialized
INFO - 2018-04-23 10:51:35 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:35 --> Input Class Initialized
INFO - 2018-04-23 10:51:35 --> Language Class Initialized
ERROR - 2018-04-23 10:51:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
INFO - 2018-04-23 10:51:38 --> Loader Class Initialized
INFO - 2018-04-23 10:51:38 --> Helper loaded: common_helper
INFO - 2018-04-23 10:51:38 --> Database Driver Class Initialized
INFO - 2018-04-23 10:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:51:38 --> Email Class Initialized
INFO - 2018-04-23 10:51:38 --> Controller Class Initialized
INFO - 2018-04-23 10:51:38 --> Helper loaded: form_helper
INFO - 2018-04-23 10:51:38 --> Form Validation Class Initialized
INFO - 2018-04-23 10:51:38 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:51:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:51:38 --> Helper loaded: url_helper
INFO - 2018-04-23 10:51:38 --> Model Class Initialized
INFO - 2018-04-23 10:51:38 --> Model Class Initialized
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/calender.php
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/socialService/editSocialService.php
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 10:51:38 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 10:51:38 --> Final output sent to browser
DEBUG - 2018-04-23 10:51:38 --> Total execution time: 0.0026
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
ERROR - 2018-04-23 10:51:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
ERROR - 2018-04-23 10:51:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
ERROR - 2018-04-23 10:51:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
ERROR - 2018-04-23 10:51:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
ERROR - 2018-04-23 10:51:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:51:38 --> Config Class Initialized
INFO - 2018-04-23 10:51:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:38 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:38 --> URI Class Initialized
INFO - 2018-04-23 10:51:38 --> Router Class Initialized
INFO - 2018-04-23 10:51:38 --> Output Class Initialized
INFO - 2018-04-23 10:51:38 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:38 --> Input Class Initialized
INFO - 2018-04-23 10:51:38 --> Language Class Initialized
ERROR - 2018-04-23 10:51:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:51:59 --> Config Class Initialized
INFO - 2018-04-23 10:51:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:59 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:59 --> URI Class Initialized
INFO - 2018-04-23 10:51:59 --> Router Class Initialized
INFO - 2018-04-23 10:51:59 --> Output Class Initialized
INFO - 2018-04-23 10:51:59 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:59 --> Input Class Initialized
INFO - 2018-04-23 10:51:59 --> Language Class Initialized
ERROR - 2018-04-23 10:51:59 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:51:59 --> Config Class Initialized
INFO - 2018-04-23 10:51:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:59 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:59 --> URI Class Initialized
INFO - 2018-04-23 10:51:59 --> Router Class Initialized
INFO - 2018-04-23 10:51:59 --> Output Class Initialized
INFO - 2018-04-23 10:51:59 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:59 --> Input Class Initialized
INFO - 2018-04-23 10:51:59 --> Language Class Initialized
ERROR - 2018-04-23 10:51:59 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:51:59 --> Config Class Initialized
INFO - 2018-04-23 10:51:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:51:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:51:59 --> Utf8 Class Initialized
INFO - 2018-04-23 10:51:59 --> URI Class Initialized
INFO - 2018-04-23 10:51:59 --> Router Class Initialized
INFO - 2018-04-23 10:51:59 --> Output Class Initialized
INFO - 2018-04-23 10:51:59 --> Security Class Initialized
DEBUG - 2018-04-23 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:51:59 --> Input Class Initialized
INFO - 2018-04-23 10:51:59 --> Language Class Initialized
ERROR - 2018-04-23 10:51:59 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:52:47 --> Config Class Initialized
INFO - 2018-04-23 10:52:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:47 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:47 --> URI Class Initialized
INFO - 2018-04-23 10:52:47 --> Router Class Initialized
INFO - 2018-04-23 10:52:47 --> Output Class Initialized
INFO - 2018-04-23 10:52:47 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:47 --> Input Class Initialized
INFO - 2018-04-23 10:52:47 --> Language Class Initialized
INFO - 2018-04-23 10:52:47 --> Loader Class Initialized
INFO - 2018-04-23 10:52:47 --> Helper loaded: common_helper
INFO - 2018-04-23 10:52:47 --> Database Driver Class Initialized
INFO - 2018-04-23 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:52:47 --> Email Class Initialized
INFO - 2018-04-23 10:52:47 --> Controller Class Initialized
INFO - 2018-04-23 10:52:47 --> Helper loaded: form_helper
INFO - 2018-04-23 10:52:47 --> Form Validation Class Initialized
INFO - 2018-04-23 10:52:47 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:52:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:52:47 --> Helper loaded: url_helper
INFO - 2018-04-23 10:52:47 --> Model Class Initialized
INFO - 2018-04-23 10:52:47 --> Model Class Initialized
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/calender.php
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/socialService/editSocialService.php
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 10:52:47 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 10:52:47 --> Final output sent to browser
DEBUG - 2018-04-23 10:52:47 --> Total execution time: 0.0027
INFO - 2018-04-23 10:52:47 --> Config Class Initialized
INFO - 2018-04-23 10:52:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:47 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:47 --> URI Class Initialized
INFO - 2018-04-23 10:52:47 --> Router Class Initialized
INFO - 2018-04-23 10:52:47 --> Output Class Initialized
INFO - 2018-04-23 10:52:47 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:47 --> Input Class Initialized
INFO - 2018-04-23 10:52:47 --> Language Class Initialized
ERROR - 2018-04-23 10:52:47 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:52:48 --> Config Class Initialized
INFO - 2018-04-23 10:52:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:48 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:48 --> URI Class Initialized
INFO - 2018-04-23 10:52:48 --> Router Class Initialized
INFO - 2018-04-23 10:52:48 --> Output Class Initialized
INFO - 2018-04-23 10:52:48 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:48 --> Input Class Initialized
INFO - 2018-04-23 10:52:48 --> Language Class Initialized
ERROR - 2018-04-23 10:52:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:52:48 --> Config Class Initialized
INFO - 2018-04-23 10:52:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:48 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:48 --> URI Class Initialized
INFO - 2018-04-23 10:52:48 --> Router Class Initialized
INFO - 2018-04-23 10:52:48 --> Output Class Initialized
INFO - 2018-04-23 10:52:48 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:48 --> Input Class Initialized
INFO - 2018-04-23 10:52:48 --> Language Class Initialized
ERROR - 2018-04-23 10:52:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:52:48 --> Config Class Initialized
INFO - 2018-04-23 10:52:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:48 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:48 --> URI Class Initialized
INFO - 2018-04-23 10:52:48 --> Router Class Initialized
INFO - 2018-04-23 10:52:48 --> Output Class Initialized
INFO - 2018-04-23 10:52:48 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:48 --> Input Class Initialized
INFO - 2018-04-23 10:52:48 --> Language Class Initialized
ERROR - 2018-04-23 10:52:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:52:48 --> Config Class Initialized
INFO - 2018-04-23 10:52:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:48 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:48 --> URI Class Initialized
INFO - 2018-04-23 10:52:48 --> Router Class Initialized
INFO - 2018-04-23 10:52:48 --> Output Class Initialized
INFO - 2018-04-23 10:52:48 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:48 --> Input Class Initialized
INFO - 2018-04-23 10:52:48 --> Language Class Initialized
ERROR - 2018-04-23 10:52:48 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:52:48 --> Config Class Initialized
INFO - 2018-04-23 10:52:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:48 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:48 --> URI Class Initialized
INFO - 2018-04-23 10:52:48 --> Router Class Initialized
INFO - 2018-04-23 10:52:48 --> Output Class Initialized
INFO - 2018-04-23 10:52:48 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:48 --> Input Class Initialized
INFO - 2018-04-23 10:52:48 --> Language Class Initialized
ERROR - 2018-04-23 10:52:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:52:54 --> Config Class Initialized
INFO - 2018-04-23 10:52:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:54 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:54 --> URI Class Initialized
INFO - 2018-04-23 10:52:54 --> Router Class Initialized
INFO - 2018-04-23 10:52:54 --> Output Class Initialized
INFO - 2018-04-23 10:52:54 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:54 --> Input Class Initialized
INFO - 2018-04-23 10:52:54 --> Language Class Initialized
ERROR - 2018-04-23 10:52:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 10:52:54 --> Config Class Initialized
INFO - 2018-04-23 10:52:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:54 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:54 --> URI Class Initialized
INFO - 2018-04-23 10:52:54 --> Router Class Initialized
INFO - 2018-04-23 10:52:54 --> Output Class Initialized
INFO - 2018-04-23 10:52:54 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:54 --> Input Class Initialized
INFO - 2018-04-23 10:52:54 --> Language Class Initialized
ERROR - 2018-04-23 10:52:54 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 10:52:54 --> Config Class Initialized
INFO - 2018-04-23 10:52:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:52:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:52:54 --> Utf8 Class Initialized
INFO - 2018-04-23 10:52:54 --> URI Class Initialized
INFO - 2018-04-23 10:52:54 --> Router Class Initialized
INFO - 2018-04-23 10:52:54 --> Output Class Initialized
INFO - 2018-04-23 10:52:54 --> Security Class Initialized
DEBUG - 2018-04-23 10:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:52:54 --> Input Class Initialized
INFO - 2018-04-23 10:52:54 --> Language Class Initialized
ERROR - 2018-04-23 10:52:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 10:53:06 --> Config Class Initialized
INFO - 2018-04-23 10:53:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:53:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:53:06 --> Utf8 Class Initialized
INFO - 2018-04-23 10:53:06 --> URI Class Initialized
INFO - 2018-04-23 10:53:06 --> Router Class Initialized
INFO - 2018-04-23 10:53:06 --> Output Class Initialized
INFO - 2018-04-23 10:53:06 --> Security Class Initialized
DEBUG - 2018-04-23 10:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:53:06 --> Input Class Initialized
INFO - 2018-04-23 10:53:06 --> Language Class Initialized
INFO - 2018-04-23 10:53:06 --> Loader Class Initialized
INFO - 2018-04-23 10:53:06 --> Helper loaded: common_helper
INFO - 2018-04-23 10:53:06 --> Database Driver Class Initialized
INFO - 2018-04-23 10:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 10:53:06 --> Email Class Initialized
INFO - 2018-04-23 10:53:06 --> Controller Class Initialized
INFO - 2018-04-23 10:53:06 --> Helper loaded: form_helper
INFO - 2018-04-23 10:53:06 --> Form Validation Class Initialized
INFO - 2018-04-23 10:53:06 --> Helper loaded: email_helper
DEBUG - 2018-04-23 10:53:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 10:53:06 --> Helper loaded: url_helper
INFO - 2018-04-23 10:53:06 --> Model Class Initialized
INFO - 2018-04-23 10:53:06 --> Model Class Initialized
INFO - 2018-04-23 10:53:06 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 10:53:06 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 10:53:06 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 10:53:06 --> File loaded: /var/www/html/admin/application/views/socialService/socialService.php
INFO - 2018-04-23 10:53:06 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 10:53:06 --> Final output sent to browser
DEBUG - 2018-04-23 10:53:06 --> Total execution time: 0.0027
INFO - 2018-04-23 10:53:06 --> Config Class Initialized
INFO - 2018-04-23 10:53:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 10:53:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 10:53:06 --> Utf8 Class Initialized
INFO - 2018-04-23 10:53:06 --> URI Class Initialized
INFO - 2018-04-23 10:53:06 --> Router Class Initialized
INFO - 2018-04-23 10:53:06 --> Output Class Initialized
INFO - 2018-04-23 10:53:06 --> Security Class Initialized
DEBUG - 2018-04-23 10:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 10:53:06 --> Input Class Initialized
INFO - 2018-04-23 10:53:06 --> Language Class Initialized
ERROR - 2018-04-23 10:53:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:20:53 --> Config Class Initialized
INFO - 2018-04-23 11:20:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:53 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:53 --> URI Class Initialized
INFO - 2018-04-23 11:20:53 --> Router Class Initialized
INFO - 2018-04-23 11:20:53 --> Output Class Initialized
INFO - 2018-04-23 11:20:53 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:53 --> Input Class Initialized
INFO - 2018-04-23 11:20:53 --> Language Class Initialized
INFO - 2018-04-23 11:20:53 --> Loader Class Initialized
INFO - 2018-04-23 11:20:53 --> Helper loaded: common_helper
INFO - 2018-04-23 11:20:53 --> Database Driver Class Initialized
INFO - 2018-04-23 11:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:20:53 --> Email Class Initialized
INFO - 2018-04-23 11:20:53 --> Controller Class Initialized
INFO - 2018-04-23 11:20:53 --> Helper loaded: form_helper
INFO - 2018-04-23 11:20:53 --> Form Validation Class Initialized
INFO - 2018-04-23 11:20:53 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:20:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:20:53 --> Helper loaded: url_helper
INFO - 2018-04-23 11:20:53 --> Model Class Initialized
INFO - 2018-04-23 11:20:53 --> Model Class Initialized
INFO - 2018-04-23 11:20:53 --> Model Class Initialized
INFO - 2018-04-23 16:50:53 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 16:50:53 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 16:50:53 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 16:50:53 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 16:50:53 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 16:50:53 --> Final output sent to browser
DEBUG - 2018-04-23 16:50:53 --> Total execution time: 0.0029
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:20:54 --> Config Class Initialized
INFO - 2018-04-23 11:20:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:20:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:20:54 --> Utf8 Class Initialized
INFO - 2018-04-23 11:20:54 --> URI Class Initialized
INFO - 2018-04-23 11:20:54 --> Router Class Initialized
INFO - 2018-04-23 11:20:54 --> Output Class Initialized
INFO - 2018-04-23 11:20:54 --> Security Class Initialized
DEBUG - 2018-04-23 11:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:20:54 --> Input Class Initialized
INFO - 2018-04-23 11:20:54 --> Language Class Initialized
ERROR - 2018-04-23 11:20:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
INFO - 2018-04-23 11:22:27 --> Loader Class Initialized
INFO - 2018-04-23 11:22:27 --> Helper loaded: common_helper
INFO - 2018-04-23 11:22:27 --> Database Driver Class Initialized
INFO - 2018-04-23 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:22:27 --> Email Class Initialized
INFO - 2018-04-23 11:22:27 --> Controller Class Initialized
INFO - 2018-04-23 11:22:27 --> Helper loaded: form_helper
INFO - 2018-04-23 11:22:27 --> Form Validation Class Initialized
INFO - 2018-04-23 11:22:27 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:22:27 --> Helper loaded: url_helper
INFO - 2018-04-23 11:22:27 --> Model Class Initialized
INFO - 2018-04-23 11:22:27 --> Model Class Initialized
INFO - 2018-04-23 11:22:27 --> Model Class Initialized
INFO - 2018-04-23 16:52:27 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 16:52:27 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 16:52:27 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 16:52:27 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 16:52:27 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 16:52:27 --> Final output sent to browser
DEBUG - 2018-04-23 16:52:27 --> Total execution time: 0.0028
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
ERROR - 2018-04-23 11:22:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
ERROR - 2018-04-23 11:22:27 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
ERROR - 2018-04-23 11:22:27 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
ERROR - 2018-04-23 11:22:27 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
ERROR - 2018-04-23 11:22:27 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:22:27 --> Config Class Initialized
INFO - 2018-04-23 11:22:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:27 --> URI Class Initialized
INFO - 2018-04-23 11:22:27 --> Router Class Initialized
INFO - 2018-04-23 11:22:27 --> Output Class Initialized
INFO - 2018-04-23 11:22:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:27 --> Input Class Initialized
INFO - 2018-04-23 11:22:27 --> Language Class Initialized
ERROR - 2018-04-23 11:22:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
INFO - 2018-04-23 11:22:29 --> Loader Class Initialized
INFO - 2018-04-23 11:22:29 --> Helper loaded: common_helper
INFO - 2018-04-23 11:22:29 --> Database Driver Class Initialized
INFO - 2018-04-23 11:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:22:29 --> Email Class Initialized
INFO - 2018-04-23 11:22:29 --> Controller Class Initialized
INFO - 2018-04-23 11:22:29 --> Helper loaded: form_helper
INFO - 2018-04-23 11:22:29 --> Form Validation Class Initialized
INFO - 2018-04-23 11:22:29 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:22:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:22:29 --> Helper loaded: url_helper
INFO - 2018-04-23 11:22:29 --> Model Class Initialized
INFO - 2018-04-23 11:22:29 --> Model Class Initialized
INFO - 2018-04-23 11:22:29 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:22:29 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:22:29 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:22:29 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 11:22:29 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:22:29 --> Final output sent to browser
DEBUG - 2018-04-23 11:22:29 --> Total execution time: 0.0045
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:22:29 --> Config Class Initialized
INFO - 2018-04-23 11:22:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:29 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:29 --> URI Class Initialized
INFO - 2018-04-23 11:22:29 --> Router Class Initialized
INFO - 2018-04-23 11:22:29 --> Output Class Initialized
INFO - 2018-04-23 11:22:29 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:29 --> Input Class Initialized
INFO - 2018-04-23 11:22:29 --> Language Class Initialized
ERROR - 2018-04-23 11:22:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
INFO - 2018-04-23 11:22:30 --> Loader Class Initialized
INFO - 2018-04-23 11:22:30 --> Helper loaded: common_helper
INFO - 2018-04-23 11:22:30 --> Database Driver Class Initialized
INFO - 2018-04-23 11:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:22:30 --> Email Class Initialized
INFO - 2018-04-23 11:22:30 --> Controller Class Initialized
INFO - 2018-04-23 11:22:30 --> Helper loaded: form_helper
INFO - 2018-04-23 11:22:30 --> Form Validation Class Initialized
INFO - 2018-04-23 11:22:30 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:22:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:22:30 --> Helper loaded: url_helper
INFO - 2018-04-23 11:22:30 --> Model Class Initialized
INFO - 2018-04-23 11:22:30 --> Model Class Initialized
INFO - 2018-04-23 11:22:30 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:22:30 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:22:30 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:22:30 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 11:22:30 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:22:30 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:22:30 --> Final output sent to browser
DEBUG - 2018-04-23 11:22:30 --> Total execution time: 0.0022
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:30 --> Config Class Initialized
INFO - 2018-04-23 11:22:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:30 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:30 --> URI Class Initialized
INFO - 2018-04-23 11:22:30 --> Router Class Initialized
INFO - 2018-04-23 11:22:30 --> Output Class Initialized
INFO - 2018-04-23 11:22:30 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:30 --> Input Class Initialized
INFO - 2018-04-23 11:22:30 --> Language Class Initialized
ERROR - 2018-04-23 11:22:30 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:37 --> Config Class Initialized
INFO - 2018-04-23 11:22:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:37 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:37 --> URI Class Initialized
INFO - 2018-04-23 11:22:37 --> Router Class Initialized
INFO - 2018-04-23 11:22:37 --> Output Class Initialized
INFO - 2018-04-23 11:22:37 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:37 --> Input Class Initialized
INFO - 2018-04-23 11:22:37 --> Language Class Initialized
INFO - 2018-04-23 11:22:37 --> Loader Class Initialized
INFO - 2018-04-23 11:22:37 --> Helper loaded: common_helper
INFO - 2018-04-23 11:22:37 --> Database Driver Class Initialized
INFO - 2018-04-23 11:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:22:37 --> Email Class Initialized
INFO - 2018-04-23 11:22:37 --> Controller Class Initialized
INFO - 2018-04-23 11:22:37 --> Helper loaded: form_helper
INFO - 2018-04-23 11:22:37 --> Form Validation Class Initialized
INFO - 2018-04-23 11:22:37 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:22:37 --> Helper loaded: url_helper
INFO - 2018-04-23 11:22:37 --> Model Class Initialized
INFO - 2018-04-23 11:22:37 --> Model Class Initialized
INFO - 2018-04-23 11:22:37 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:22:37 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:22:37 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:22:37 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 11:22:37 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:22:37 --> Final output sent to browser
DEBUG - 2018-04-23 11:22:37 --> Total execution time: 0.0027
INFO - 2018-04-23 11:22:38 --> Config Class Initialized
INFO - 2018-04-23 11:22:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:38 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:38 --> URI Class Initialized
INFO - 2018-04-23 11:22:38 --> Router Class Initialized
INFO - 2018-04-23 11:22:38 --> Output Class Initialized
INFO - 2018-04-23 11:22:38 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:38 --> Input Class Initialized
INFO - 2018-04-23 11:22:38 --> Language Class Initialized
ERROR - 2018-04-23 11:22:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:38 --> Config Class Initialized
INFO - 2018-04-23 11:22:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:38 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:38 --> URI Class Initialized
INFO - 2018-04-23 11:22:38 --> Router Class Initialized
INFO - 2018-04-23 11:22:38 --> Output Class Initialized
INFO - 2018-04-23 11:22:38 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:38 --> Input Class Initialized
INFO - 2018-04-23 11:22:38 --> Language Class Initialized
ERROR - 2018-04-23 11:22:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:38 --> Config Class Initialized
INFO - 2018-04-23 11:22:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:38 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:38 --> URI Class Initialized
INFO - 2018-04-23 11:22:38 --> Router Class Initialized
INFO - 2018-04-23 11:22:38 --> Output Class Initialized
INFO - 2018-04-23 11:22:38 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:38 --> Input Class Initialized
INFO - 2018-04-23 11:22:38 --> Language Class Initialized
ERROR - 2018-04-23 11:22:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:38 --> Config Class Initialized
INFO - 2018-04-23 11:22:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:38 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:38 --> URI Class Initialized
INFO - 2018-04-23 11:22:38 --> Router Class Initialized
INFO - 2018-04-23 11:22:38 --> Output Class Initialized
INFO - 2018-04-23 11:22:38 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:38 --> Input Class Initialized
INFO - 2018-04-23 11:22:38 --> Language Class Initialized
ERROR - 2018-04-23 11:22:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
INFO - 2018-04-23 11:22:41 --> Loader Class Initialized
INFO - 2018-04-23 11:22:41 --> Helper loaded: common_helper
INFO - 2018-04-23 11:22:41 --> Database Driver Class Initialized
INFO - 2018-04-23 11:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:22:41 --> Email Class Initialized
INFO - 2018-04-23 11:22:41 --> Controller Class Initialized
INFO - 2018-04-23 11:22:41 --> Helper loaded: form_helper
INFO - 2018-04-23 11:22:41 --> Form Validation Class Initialized
INFO - 2018-04-23 11:22:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:22:41 --> Helper loaded: url_helper
INFO - 2018-04-23 11:22:41 --> Model Class Initialized
INFO - 2018-04-23 11:22:41 --> Model Class Initialized
INFO - 2018-04-23 11:22:41 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:22:41 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:22:41 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:22:41 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 11:22:41 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:22:41 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:22:41 --> Final output sent to browser
DEBUG - 2018-04-23 11:22:41 --> Total execution time: 0.0021
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:22:41 --> Config Class Initialized
INFO - 2018-04-23 11:22:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:22:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:22:41 --> Utf8 Class Initialized
INFO - 2018-04-23 11:22:41 --> URI Class Initialized
INFO - 2018-04-23 11:22:41 --> Router Class Initialized
INFO - 2018-04-23 11:22:41 --> Output Class Initialized
INFO - 2018-04-23 11:22:41 --> Security Class Initialized
DEBUG - 2018-04-23 11:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:22:41 --> Input Class Initialized
INFO - 2018-04-23 11:22:41 --> Language Class Initialized
ERROR - 2018-04-23 11:22:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
INFO - 2018-04-23 11:26:16 --> Loader Class Initialized
INFO - 2018-04-23 11:26:16 --> Helper loaded: common_helper
INFO - 2018-04-23 11:26:16 --> Database Driver Class Initialized
INFO - 2018-04-23 11:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:26:16 --> Email Class Initialized
INFO - 2018-04-23 11:26:16 --> Controller Class Initialized
INFO - 2018-04-23 11:26:16 --> Helper loaded: form_helper
INFO - 2018-04-23 11:26:16 --> Form Validation Class Initialized
INFO - 2018-04-23 11:26:16 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:26:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:26:16 --> Helper loaded: url_helper
INFO - 2018-04-23 11:26:16 --> Model Class Initialized
INFO - 2018-04-23 11:26:16 --> Model Class Initialized
INFO - 2018-04-23 11:26:16 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:26:16 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 11:26:16 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:26:16 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 11:26:16 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 11:26:16 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:26:16 --> Final output sent to browser
DEBUG - 2018-04-23 11:26:16 --> Total execution time: 0.0020
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
ERROR - 2018-04-23 11:26:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
ERROR - 2018-04-23 11:26:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
ERROR - 2018-04-23 11:26:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
ERROR - 2018-04-23 11:26:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
ERROR - 2018-04-23 11:26:16 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:26:16 --> Config Class Initialized
INFO - 2018-04-23 11:26:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:26:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:26:16 --> Utf8 Class Initialized
INFO - 2018-04-23 11:26:16 --> URI Class Initialized
INFO - 2018-04-23 11:26:16 --> Router Class Initialized
INFO - 2018-04-23 11:26:16 --> Output Class Initialized
INFO - 2018-04-23 11:26:16 --> Security Class Initialized
DEBUG - 2018-04-23 11:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:26:16 --> Input Class Initialized
INFO - 2018-04-23 11:26:16 --> Language Class Initialized
ERROR - 2018-04-23 11:26:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
INFO - 2018-04-23 11:29:06 --> Loader Class Initialized
INFO - 2018-04-23 11:29:06 --> Helper loaded: common_helper
INFO - 2018-04-23 11:29:06 --> Database Driver Class Initialized
INFO - 2018-04-23 11:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:29:06 --> Email Class Initialized
INFO - 2018-04-23 11:29:06 --> Controller Class Initialized
INFO - 2018-04-23 11:29:06 --> Helper loaded: form_helper
INFO - 2018-04-23 11:29:06 --> Form Validation Class Initialized
INFO - 2018-04-23 11:29:06 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:29:06 --> Helper loaded: url_helper
INFO - 2018-04-23 11:29:06 --> Model Class Initialized
INFO - 2018-04-23 11:29:06 --> Model Class Initialized
INFO - 2018-04-23 11:29:06 --> Model Class Initialized
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
INFO - 2018-04-23 11:29:06 --> Loader Class Initialized
INFO - 2018-04-23 11:29:06 --> Helper loaded: common_helper
INFO - 2018-04-23 11:29:06 --> Database Driver Class Initialized
INFO - 2018-04-23 11:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:29:06 --> Email Class Initialized
INFO - 2018-04-23 11:29:06 --> Controller Class Initialized
INFO - 2018-04-23 11:29:06 --> Helper loaded: form_helper
INFO - 2018-04-23 11:29:06 --> Form Validation Class Initialized
INFO - 2018-04-23 11:29:06 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:29:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:29:06 --> Helper loaded: url_helper
INFO - 2018-04-23 11:29:06 --> Model Class Initialized
INFO - 2018-04-23 11:29:06 --> Model Class Initialized
INFO - 2018-04-23 11:29:06 --> Model Class Initialized
INFO - 2018-04-23 11:29:06 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:29:06 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 11:29:06 --> Undefined variable: noOfapps
ERROR - 2018-04-23 11:29:06 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:29:06 --> Trying to get property of non-object
ERROR - 2018-04-23 11:29:06 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:29:06 --> Undefined variable: apptypes
ERROR - 2018-04-23 11:29:06 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 11:29:06 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 11:29:06 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:29:06 --> Final output sent to browser
DEBUG - 2018-04-23 11:29:06 --> Total execution time: 0.0035
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:29:06 --> Config Class Initialized
INFO - 2018-04-23 11:29:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:29:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:29:06 --> Utf8 Class Initialized
INFO - 2018-04-23 11:29:06 --> URI Class Initialized
INFO - 2018-04-23 11:29:06 --> Router Class Initialized
INFO - 2018-04-23 11:29:06 --> Output Class Initialized
INFO - 2018-04-23 11:29:06 --> Security Class Initialized
DEBUG - 2018-04-23 11:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:29:06 --> Input Class Initialized
INFO - 2018-04-23 11:29:06 --> Language Class Initialized
ERROR - 2018-04-23 11:29:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
INFO - 2018-04-23 11:30:24 --> Loader Class Initialized
INFO - 2018-04-23 11:30:24 --> Helper loaded: common_helper
INFO - 2018-04-23 11:30:24 --> Database Driver Class Initialized
INFO - 2018-04-23 11:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:30:24 --> Email Class Initialized
INFO - 2018-04-23 11:30:24 --> Controller Class Initialized
INFO - 2018-04-23 11:30:24 --> Helper loaded: form_helper
INFO - 2018-04-23 11:30:24 --> Form Validation Class Initialized
INFO - 2018-04-23 11:30:24 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:30:24 --> Helper loaded: url_helper
INFO - 2018-04-23 11:30:24 --> Model Class Initialized
INFO - 2018-04-23 11:30:24 --> Model Class Initialized
INFO - 2018-04-23 11:30:24 --> Model Class Initialized
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
INFO - 2018-04-23 11:30:24 --> Loader Class Initialized
INFO - 2018-04-23 11:30:24 --> Helper loaded: common_helper
INFO - 2018-04-23 11:30:24 --> Database Driver Class Initialized
INFO - 2018-04-23 11:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:30:24 --> Email Class Initialized
INFO - 2018-04-23 11:30:24 --> Controller Class Initialized
INFO - 2018-04-23 11:30:24 --> Helper loaded: form_helper
INFO - 2018-04-23 11:30:24 --> Form Validation Class Initialized
INFO - 2018-04-23 11:30:24 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:30:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:30:24 --> Helper loaded: url_helper
INFO - 2018-04-23 11:30:24 --> Model Class Initialized
INFO - 2018-04-23 11:30:24 --> Model Class Initialized
INFO - 2018-04-23 11:30:24 --> Model Class Initialized
INFO - 2018-04-23 11:30:24 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:30:24 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 11:30:24 --> Undefined variable: noOfapps
ERROR - 2018-04-23 11:30:24 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:24 --> Trying to get property of non-object
ERROR - 2018-04-23 11:30:24 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:24 --> Undefined variable: apptypes
ERROR - 2018-04-23 11:30:24 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 11:30:24 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 11:30:24 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:30:24 --> Final output sent to browser
DEBUG - 2018-04-23 11:30:24 --> Total execution time: 0.0031
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/components-select2.min.js
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:30:24 --> Config Class Initialized
INFO - 2018-04-23 11:30:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:24 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:24 --> URI Class Initialized
INFO - 2018-04-23 11:30:24 --> Router Class Initialized
INFO - 2018-04-23 11:30:24 --> Output Class Initialized
INFO - 2018-04-23 11:30:24 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:24 --> Input Class Initialized
INFO - 2018-04-23 11:30:24 --> Language Class Initialized
ERROR - 2018-04-23 11:30:24 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:26 --> Config Class Initialized
INFO - 2018-04-23 11:30:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:26 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:26 --> URI Class Initialized
INFO - 2018-04-23 11:30:26 --> Router Class Initialized
INFO - 2018-04-23 11:30:26 --> Output Class Initialized
INFO - 2018-04-23 11:30:26 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:26 --> Input Class Initialized
INFO - 2018-04-23 11:30:26 --> Language Class Initialized
INFO - 2018-04-23 11:30:26 --> Loader Class Initialized
INFO - 2018-04-23 11:30:26 --> Helper loaded: common_helper
INFO - 2018-04-23 11:30:26 --> Database Driver Class Initialized
INFO - 2018-04-23 11:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:30:26 --> Email Class Initialized
INFO - 2018-04-23 11:30:26 --> Controller Class Initialized
INFO - 2018-04-23 11:30:26 --> Helper loaded: form_helper
INFO - 2018-04-23 11:30:26 --> Form Validation Class Initialized
INFO - 2018-04-23 11:30:26 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:30:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:30:26 --> Helper loaded: url_helper
INFO - 2018-04-23 11:30:26 --> Model Class Initialized
INFO - 2018-04-23 11:30:26 --> Model Class Initialized
INFO - 2018-04-23 11:30:26 --> Model Class Initialized
INFO - 2018-04-23 11:30:26 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:30:26 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 11:30:26 --> Undefined variable: noOfapps
ERROR - 2018-04-23 11:30:26 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:26 --> Trying to get property of non-object
ERROR - 2018-04-23 11:30:26 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:26 --> Undefined variable: apptypes
ERROR - 2018-04-23 11:30:26 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 11:30:26 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 11:30:26 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:30:26 --> Final output sent to browser
DEBUG - 2018-04-23 11:30:26 --> Total execution time: 0.0029
INFO - 2018-04-23 11:30:27 --> Config Class Initialized
INFO - 2018-04-23 11:30:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:27 --> URI Class Initialized
INFO - 2018-04-23 11:30:27 --> Router Class Initialized
INFO - 2018-04-23 11:30:27 --> Output Class Initialized
INFO - 2018-04-23 11:30:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:27 --> Input Class Initialized
INFO - 2018-04-23 11:30:27 --> Language Class Initialized
ERROR - 2018-04-23 11:30:27 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:30:27 --> Config Class Initialized
INFO - 2018-04-23 11:30:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:27 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:27 --> URI Class Initialized
INFO - 2018-04-23 11:30:27 --> Router Class Initialized
INFO - 2018-04-23 11:30:27 --> Output Class Initialized
INFO - 2018-04-23 11:30:27 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:27 --> Input Class Initialized
INFO - 2018-04-23 11:30:27 --> Language Class Initialized
ERROR - 2018-04-23 11:30:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
INFO - 2018-04-23 11:30:33 --> Loader Class Initialized
INFO - 2018-04-23 11:30:33 --> Helper loaded: common_helper
INFO - 2018-04-23 11:30:33 --> Database Driver Class Initialized
INFO - 2018-04-23 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:30:33 --> Email Class Initialized
INFO - 2018-04-23 11:30:33 --> Controller Class Initialized
INFO - 2018-04-23 11:30:33 --> Helper loaded: form_helper
INFO - 2018-04-23 11:30:33 --> Form Validation Class Initialized
INFO - 2018-04-23 11:30:33 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:30:33 --> Helper loaded: url_helper
INFO - 2018-04-23 11:30:33 --> Model Class Initialized
INFO - 2018-04-23 11:30:33 --> Model Class Initialized
INFO - 2018-04-23 11:30:33 --> Model Class Initialized
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
INFO - 2018-04-23 11:30:33 --> Loader Class Initialized
INFO - 2018-04-23 11:30:33 --> Helper loaded: common_helper
INFO - 2018-04-23 11:30:33 --> Database Driver Class Initialized
INFO - 2018-04-23 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:30:33 --> Email Class Initialized
INFO - 2018-04-23 11:30:33 --> Controller Class Initialized
INFO - 2018-04-23 11:30:33 --> Helper loaded: form_helper
INFO - 2018-04-23 11:30:33 --> Form Validation Class Initialized
INFO - 2018-04-23 11:30:33 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:30:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:30:33 --> Helper loaded: url_helper
INFO - 2018-04-23 11:30:33 --> Model Class Initialized
INFO - 2018-04-23 11:30:33 --> Model Class Initialized
INFO - 2018-04-23 11:30:33 --> Model Class Initialized
INFO - 2018-04-23 11:30:33 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:30:33 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 11:30:33 --> Undefined variable: noOfapps
ERROR - 2018-04-23 11:30:33 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:33 --> Trying to get property of non-object
ERROR - 2018-04-23 11:30:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:33 --> Undefined variable: apptypes
ERROR - 2018-04-23 11:30:33 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 11:30:33 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 11:30:33 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:30:33 --> Final output sent to browser
DEBUG - 2018-04-23 11:30:33 --> Total execution time: 0.0032
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:33 --> Config Class Initialized
INFO - 2018-04-23 11:30:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:33 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:33 --> URI Class Initialized
INFO - 2018-04-23 11:30:33 --> Router Class Initialized
INFO - 2018-04-23 11:30:33 --> Output Class Initialized
INFO - 2018-04-23 11:30:33 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:33 --> Input Class Initialized
INFO - 2018-04-23 11:30:33 --> Language Class Initialized
ERROR - 2018-04-23 11:30:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:35 --> Config Class Initialized
INFO - 2018-04-23 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:35 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:35 --> URI Class Initialized
INFO - 2018-04-23 11:30:35 --> Router Class Initialized
INFO - 2018-04-23 11:30:35 --> Output Class Initialized
INFO - 2018-04-23 11:30:35 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:35 --> Input Class Initialized
INFO - 2018-04-23 11:30:35 --> Language Class Initialized
INFO - 2018-04-23 11:30:35 --> Loader Class Initialized
INFO - 2018-04-23 11:30:35 --> Helper loaded: common_helper
INFO - 2018-04-23 11:30:35 --> Database Driver Class Initialized
INFO - 2018-04-23 11:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 11:30:35 --> Email Class Initialized
INFO - 2018-04-23 11:30:35 --> Controller Class Initialized
INFO - 2018-04-23 11:30:35 --> Helper loaded: form_helper
INFO - 2018-04-23 11:30:35 --> Form Validation Class Initialized
INFO - 2018-04-23 11:30:35 --> Helper loaded: email_helper
DEBUG - 2018-04-23 11:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 11:30:35 --> Helper loaded: url_helper
INFO - 2018-04-23 11:30:35 --> Model Class Initialized
INFO - 2018-04-23 11:30:35 --> Model Class Initialized
INFO - 2018-04-23 11:30:35 --> Model Class Initialized
INFO - 2018-04-23 11:30:35 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 11:30:35 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 11:30:35 --> Undefined variable: noOfapps
ERROR - 2018-04-23 11:30:35 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:35 --> Trying to get property of non-object
ERROR - 2018-04-23 11:30:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 11:30:35 --> Undefined variable: apptypes
ERROR - 2018-04-23 11:30:35 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 11:30:35 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 11:30:35 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 11:30:35 --> Final output sent to browser
DEBUG - 2018-04-23 11:30:35 --> Total execution time: 0.0030
INFO - 2018-04-23 11:30:35 --> Config Class Initialized
INFO - 2018-04-23 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:35 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:35 --> URI Class Initialized
INFO - 2018-04-23 11:30:35 --> Router Class Initialized
INFO - 2018-04-23 11:30:35 --> Output Class Initialized
INFO - 2018-04-23 11:30:35 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:35 --> Input Class Initialized
INFO - 2018-04-23 11:30:35 --> Language Class Initialized
ERROR - 2018-04-23 11:30:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:35 --> Config Class Initialized
INFO - 2018-04-23 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:35 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:35 --> URI Class Initialized
INFO - 2018-04-23 11:30:35 --> Router Class Initialized
INFO - 2018-04-23 11:30:35 --> Output Class Initialized
INFO - 2018-04-23 11:30:35 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:35 --> Input Class Initialized
INFO - 2018-04-23 11:30:35 --> Language Class Initialized
ERROR - 2018-04-23 11:30:35 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 11:30:35 --> Config Class Initialized
INFO - 2018-04-23 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:35 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:35 --> URI Class Initialized
INFO - 2018-04-23 11:30:35 --> Router Class Initialized
INFO - 2018-04-23 11:30:35 --> Output Class Initialized
INFO - 2018-04-23 11:30:35 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:35 --> Input Class Initialized
INFO - 2018-04-23 11:30:35 --> Language Class Initialized
ERROR - 2018-04-23 11:30:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 11:30:35 --> Config Class Initialized
INFO - 2018-04-23 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:35 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:35 --> URI Class Initialized
INFO - 2018-04-23 11:30:35 --> Router Class Initialized
INFO - 2018-04-23 11:30:35 --> Output Class Initialized
INFO - 2018-04-23 11:30:35 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:35 --> Input Class Initialized
INFO - 2018-04-23 11:30:35 --> Language Class Initialized
ERROR - 2018-04-23 11:30:35 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 11:30:35 --> Config Class Initialized
INFO - 2018-04-23 11:30:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 11:30:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 11:30:35 --> Utf8 Class Initialized
INFO - 2018-04-23 11:30:35 --> URI Class Initialized
INFO - 2018-04-23 11:30:35 --> Router Class Initialized
INFO - 2018-04-23 11:30:35 --> Output Class Initialized
INFO - 2018-04-23 11:30:35 --> Security Class Initialized
DEBUG - 2018-04-23 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 11:30:35 --> Input Class Initialized
INFO - 2018-04-23 11:30:35 --> Language Class Initialized
ERROR - 2018-04-23 11:30:35 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
INFO - 2018-04-23 12:51:14 --> Loader Class Initialized
INFO - 2018-04-23 12:51:14 --> Helper loaded: common_helper
INFO - 2018-04-23 12:51:14 --> Database Driver Class Initialized
INFO - 2018-04-23 12:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:51:14 --> Email Class Initialized
INFO - 2018-04-23 12:51:14 --> Controller Class Initialized
INFO - 2018-04-23 12:51:14 --> Helper loaded: form_helper
INFO - 2018-04-23 12:51:14 --> Form Validation Class Initialized
INFO - 2018-04-23 12:51:14 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:51:14 --> Helper loaded: url_helper
INFO - 2018-04-23 12:51:14 --> Model Class Initialized
INFO - 2018-04-23 12:51:14 --> Model Class Initialized
INFO - 2018-04-23 12:51:14 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:51:14 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:51:14 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:51:14 --> File loaded: /var/www/html/admin/application/views/timeline/timeline.php
INFO - 2018-04-23 12:51:14 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:51:14 --> Final output sent to browser
DEBUG - 2018-04-23 12:51:14 --> Total execution time: 0.0047
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:14 --> Config Class Initialized
INFO - 2018-04-23 12:51:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:14 --> URI Class Initialized
INFO - 2018-04-23 12:51:14 --> Router Class Initialized
INFO - 2018-04-23 12:51:14 --> Output Class Initialized
INFO - 2018-04-23 12:51:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:14 --> Input Class Initialized
INFO - 2018-04-23 12:51:14 --> Language Class Initialized
ERROR - 2018-04-23 12:51:14 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:15 --> Config Class Initialized
INFO - 2018-04-23 12:51:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:15 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:15 --> URI Class Initialized
INFO - 2018-04-23 12:51:15 --> Router Class Initialized
INFO - 2018-04-23 12:51:15 --> Output Class Initialized
INFO - 2018-04-23 12:51:15 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:15 --> Input Class Initialized
INFO - 2018-04-23 12:51:15 --> Language Class Initialized
INFO - 2018-04-23 12:51:15 --> Loader Class Initialized
INFO - 2018-04-23 12:51:15 --> Helper loaded: common_helper
INFO - 2018-04-23 12:51:15 --> Database Driver Class Initialized
INFO - 2018-04-23 12:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:51:15 --> Email Class Initialized
INFO - 2018-04-23 12:51:15 --> Controller Class Initialized
INFO - 2018-04-23 12:51:15 --> Helper loaded: form_helper
INFO - 2018-04-23 12:51:15 --> Form Validation Class Initialized
INFO - 2018-04-23 12:51:15 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:51:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:51:15 --> Helper loaded: url_helper
INFO - 2018-04-23 12:51:15 --> Model Class Initialized
INFO - 2018-04-23 12:51:15 --> Model Class Initialized
INFO - 2018-04-23 12:51:15 --> Model Class Initialized
INFO - 2018-04-23 18:21:15 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:21:15 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:21:15 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:21:15 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 18:21:15 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:21:15 --> Final output sent to browser
DEBUG - 2018-04-23 18:21:15 --> Total execution time: 0.0029
INFO - 2018-04-23 12:51:15 --> Config Class Initialized
INFO - 2018-04-23 12:51:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:15 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:15 --> URI Class Initialized
INFO - 2018-04-23 12:51:15 --> Router Class Initialized
INFO - 2018-04-23 12:51:15 --> Output Class Initialized
INFO - 2018-04-23 12:51:15 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:15 --> Input Class Initialized
INFO - 2018-04-23 12:51:15 --> Language Class Initialized
ERROR - 2018-04-23 12:51:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:16 --> Config Class Initialized
INFO - 2018-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:16 --> URI Class Initialized
INFO - 2018-04-23 12:51:16 --> Router Class Initialized
INFO - 2018-04-23 12:51:16 --> Output Class Initialized
INFO - 2018-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:16 --> Input Class Initialized
INFO - 2018-04-23 12:51:16 --> Language Class Initialized
ERROR - 2018-04-23 12:51:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:16 --> Config Class Initialized
INFO - 2018-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:16 --> URI Class Initialized
INFO - 2018-04-23 12:51:16 --> Router Class Initialized
INFO - 2018-04-23 12:51:16 --> Output Class Initialized
INFO - 2018-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:16 --> Input Class Initialized
INFO - 2018-04-23 12:51:16 --> Language Class Initialized
ERROR - 2018-04-23 12:51:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:16 --> Config Class Initialized
INFO - 2018-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:16 --> URI Class Initialized
INFO - 2018-04-23 12:51:16 --> Router Class Initialized
INFO - 2018-04-23 12:51:16 --> Output Class Initialized
INFO - 2018-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:16 --> Input Class Initialized
INFO - 2018-04-23 12:51:16 --> Language Class Initialized
ERROR - 2018-04-23 12:51:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:16 --> Config Class Initialized
INFO - 2018-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:16 --> URI Class Initialized
INFO - 2018-04-23 12:51:16 --> Router Class Initialized
INFO - 2018-04-23 12:51:16 --> Output Class Initialized
INFO - 2018-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:16 --> Input Class Initialized
INFO - 2018-04-23 12:51:16 --> Language Class Initialized
ERROR - 2018-04-23 12:51:16 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:16 --> Config Class Initialized
INFO - 2018-04-23 12:51:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:16 --> URI Class Initialized
INFO - 2018-04-23 12:51:16 --> Router Class Initialized
INFO - 2018-04-23 12:51:16 --> Output Class Initialized
INFO - 2018-04-23 12:51:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:16 --> Input Class Initialized
INFO - 2018-04-23 12:51:16 --> Language Class Initialized
ERROR - 2018-04-23 12:51:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:17 --> Config Class Initialized
INFO - 2018-04-23 12:51:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:17 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:17 --> URI Class Initialized
INFO - 2018-04-23 12:51:17 --> Router Class Initialized
INFO - 2018-04-23 12:51:17 --> Output Class Initialized
INFO - 2018-04-23 12:51:17 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:17 --> Input Class Initialized
INFO - 2018-04-23 12:51:17 --> Language Class Initialized
INFO - 2018-04-23 12:51:17 --> Loader Class Initialized
INFO - 2018-04-23 12:51:17 --> Helper loaded: common_helper
INFO - 2018-04-23 12:51:17 --> Database Driver Class Initialized
INFO - 2018-04-23 12:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:51:17 --> Email Class Initialized
INFO - 2018-04-23 12:51:17 --> Controller Class Initialized
INFO - 2018-04-23 12:51:17 --> Helper loaded: form_helper
INFO - 2018-04-23 12:51:17 --> Form Validation Class Initialized
INFO - 2018-04-23 12:51:17 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:51:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:51:17 --> Helper loaded: url_helper
INFO - 2018-04-23 12:51:17 --> Model Class Initialized
INFO - 2018-04-23 12:51:17 --> Model Class Initialized
INFO - 2018-04-23 12:51:17 --> Model Class Initialized
INFO - 2018-04-23 18:21:17 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:21:17 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:21:17 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 18:21:17 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:21:17 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:21:17 --> Final output sent to browser
DEBUG - 2018-04-23 18:21:17 --> Total execution time: 0.0025
INFO - 2018-04-23 12:51:17 --> Config Class Initialized
INFO - 2018-04-23 12:51:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:17 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:17 --> URI Class Initialized
INFO - 2018-04-23 12:51:17 --> Router Class Initialized
INFO - 2018-04-23 12:51:17 --> Output Class Initialized
INFO - 2018-04-23 12:51:17 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:17 --> Input Class Initialized
INFO - 2018-04-23 12:51:17 --> Language Class Initialized
ERROR - 2018-04-23 12:51:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:17 --> Config Class Initialized
INFO - 2018-04-23 12:51:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:17 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:17 --> URI Class Initialized
INFO - 2018-04-23 12:51:17 --> Router Class Initialized
INFO - 2018-04-23 12:51:17 --> Output Class Initialized
INFO - 2018-04-23 12:51:17 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:17 --> Input Class Initialized
INFO - 2018-04-23 12:51:17 --> Language Class Initialized
ERROR - 2018-04-23 12:51:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:17 --> Config Class Initialized
INFO - 2018-04-23 12:51:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:17 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:17 --> URI Class Initialized
INFO - 2018-04-23 12:51:17 --> Router Class Initialized
INFO - 2018-04-23 12:51:17 --> Output Class Initialized
INFO - 2018-04-23 12:51:17 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:17 --> Input Class Initialized
INFO - 2018-04-23 12:51:17 --> Language Class Initialized
ERROR - 2018-04-23 12:51:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:18 --> Config Class Initialized
INFO - 2018-04-23 12:51:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:18 --> URI Class Initialized
INFO - 2018-04-23 12:51:18 --> Router Class Initialized
INFO - 2018-04-23 12:51:18 --> Config Class Initialized
INFO - 2018-04-23 12:51:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:18 --> URI Class Initialized
INFO - 2018-04-23 12:51:18 --> Router Class Initialized
INFO - 2018-04-23 12:51:18 --> Output Class Initialized
INFO - 2018-04-23 12:51:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:18 --> Input Class Initialized
INFO - 2018-04-23 12:51:18 --> Language Class Initialized
ERROR - 2018-04-23 12:51:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:18 --> Output Class Initialized
INFO - 2018-04-23 12:51:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:18 --> Input Class Initialized
INFO - 2018-04-23 12:51:18 --> Language Class Initialized
ERROR - 2018-04-23 12:51:18 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:18 --> Config Class Initialized
INFO - 2018-04-23 12:51:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:18 --> URI Class Initialized
INFO - 2018-04-23 12:51:18 --> Router Class Initialized
INFO - 2018-04-23 12:51:18 --> Output Class Initialized
INFO - 2018-04-23 12:51:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:18 --> Input Class Initialized
INFO - 2018-04-23 12:51:18 --> Language Class Initialized
ERROR - 2018-04-23 12:51:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
INFO - 2018-04-23 12:51:19 --> Loader Class Initialized
INFO - 2018-04-23 12:51:19 --> Helper loaded: common_helper
INFO - 2018-04-23 12:51:19 --> Database Driver Class Initialized
INFO - 2018-04-23 12:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:51:19 --> Email Class Initialized
INFO - 2018-04-23 12:51:19 --> Controller Class Initialized
INFO - 2018-04-23 12:51:19 --> Helper loaded: form_helper
INFO - 2018-04-23 12:51:19 --> Form Validation Class Initialized
INFO - 2018-04-23 12:51:19 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:51:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:51:19 --> Helper loaded: url_helper
INFO - 2018-04-23 12:51:19 --> Model Class Initialized
INFO - 2018-04-23 12:51:19 --> Model Class Initialized
INFO - 2018-04-23 12:51:19 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:51:19 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:51:19 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:51:19 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:51:19 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:51:19 --> Final output sent to browser
DEBUG - 2018-04-23 12:51:19 --> Total execution time: 0.0027
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:19 --> Config Class Initialized
INFO - 2018-04-23 12:51:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:19 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:19 --> URI Class Initialized
INFO - 2018-04-23 12:51:19 --> Router Class Initialized
INFO - 2018-04-23 12:51:19 --> Output Class Initialized
INFO - 2018-04-23 12:51:19 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:19 --> Input Class Initialized
INFO - 2018-04-23 12:51:19 --> Language Class Initialized
ERROR - 2018-04-23 12:51:19 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
INFO - 2018-04-23 12:51:29 --> Loader Class Initialized
INFO - 2018-04-23 12:51:29 --> Helper loaded: common_helper
INFO - 2018-04-23 12:51:29 --> Database Driver Class Initialized
INFO - 2018-04-23 12:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:51:29 --> Email Class Initialized
INFO - 2018-04-23 12:51:29 --> Controller Class Initialized
INFO - 2018-04-23 12:51:29 --> Helper loaded: form_helper
INFO - 2018-04-23 12:51:29 --> Form Validation Class Initialized
INFO - 2018-04-23 12:51:29 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:51:29 --> Helper loaded: url_helper
INFO - 2018-04-23 12:51:29 --> Model Class Initialized
INFO - 2018-04-23 12:51:29 --> Model Class Initialized
INFO - 2018-04-23 12:51:29 --> Model Class Initialized
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
INFO - 2018-04-23 12:51:29 --> Loader Class Initialized
INFO - 2018-04-23 12:51:29 --> Helper loaded: common_helper
INFO - 2018-04-23 12:51:29 --> Database Driver Class Initialized
INFO - 2018-04-23 12:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:51:29 --> Email Class Initialized
INFO - 2018-04-23 12:51:29 --> Controller Class Initialized
INFO - 2018-04-23 12:51:29 --> Helper loaded: form_helper
INFO - 2018-04-23 12:51:29 --> Form Validation Class Initialized
INFO - 2018-04-23 12:51:29 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:51:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:51:29 --> Helper loaded: url_helper
INFO - 2018-04-23 12:51:29 --> Model Class Initialized
INFO - 2018-04-23 12:51:29 --> Model Class Initialized
INFO - 2018-04-23 12:51:29 --> Model Class Initialized
INFO - 2018-04-23 12:51:29 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:51:29 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:51:29 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:51:29 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:51:29 --> Trying to get property of non-object
ERROR - 2018-04-23 12:51:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:51:29 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:51:29 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:51:29 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:51:29 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:51:29 --> Final output sent to browser
DEBUG - 2018-04-23 12:51:29 --> Total execution time: 0.0036
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/select2
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:51:29 --> Config Class Initialized
INFO - 2018-04-23 12:51:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:51:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:51:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:51:29 --> URI Class Initialized
INFO - 2018-04-23 12:51:29 --> Router Class Initialized
INFO - 2018-04-23 12:51:29 --> Output Class Initialized
INFO - 2018-04-23 12:51:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:51:29 --> Input Class Initialized
INFO - 2018-04-23 12:51:29 --> Language Class Initialized
ERROR - 2018-04-23 12:51:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
INFO - 2018-04-23 12:52:13 --> Loader Class Initialized
INFO - 2018-04-23 12:52:13 --> Helper loaded: common_helper
INFO - 2018-04-23 12:52:13 --> Database Driver Class Initialized
INFO - 2018-04-23 12:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:52:13 --> Email Class Initialized
INFO - 2018-04-23 12:52:13 --> Controller Class Initialized
INFO - 2018-04-23 12:52:13 --> Helper loaded: form_helper
INFO - 2018-04-23 12:52:13 --> Form Validation Class Initialized
INFO - 2018-04-23 12:52:13 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:52:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:52:13 --> Helper loaded: url_helper
INFO - 2018-04-23 12:52:13 --> Model Class Initialized
INFO - 2018-04-23 12:52:13 --> Model Class Initialized
INFO - 2018-04-23 12:52:13 --> Model Class Initialized
INFO - 2018-04-23 12:52:13 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:52:13 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:52:13 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:52:13 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:52:13 --> Trying to get property of non-object
ERROR - 2018-04-23 12:52:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:52:13 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:52:13 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:52:13 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:52:13 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:52:13 --> Final output sent to browser
DEBUG - 2018-04-23 12:52:13 --> Total execution time: 0.0033
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:52:13 --> Config Class Initialized
INFO - 2018-04-23 12:52:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:13 --> URI Class Initialized
INFO - 2018-04-23 12:52:13 --> Router Class Initialized
INFO - 2018-04-23 12:52:13 --> Output Class Initialized
INFO - 2018-04-23 12:52:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:13 --> Input Class Initialized
INFO - 2018-04-23 12:52:13 --> Language Class Initialized
ERROR - 2018-04-23 12:52:13 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
INFO - 2018-04-23 12:52:41 --> Loader Class Initialized
INFO - 2018-04-23 12:52:41 --> Helper loaded: common_helper
INFO - 2018-04-23 12:52:41 --> Database Driver Class Initialized
INFO - 2018-04-23 12:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:52:41 --> Email Class Initialized
INFO - 2018-04-23 12:52:41 --> Controller Class Initialized
INFO - 2018-04-23 12:52:41 --> Helper loaded: form_helper
INFO - 2018-04-23 12:52:41 --> Form Validation Class Initialized
INFO - 2018-04-23 12:52:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:52:41 --> Helper loaded: url_helper
INFO - 2018-04-23 12:52:41 --> Model Class Initialized
INFO - 2018-04-23 12:52:41 --> Model Class Initialized
INFO - 2018-04-23 12:52:41 --> Model Class Initialized
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
INFO - 2018-04-23 12:52:41 --> Loader Class Initialized
INFO - 2018-04-23 12:52:41 --> Helper loaded: common_helper
INFO - 2018-04-23 12:52:41 --> Database Driver Class Initialized
INFO - 2018-04-23 12:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:52:41 --> Email Class Initialized
INFO - 2018-04-23 12:52:41 --> Controller Class Initialized
INFO - 2018-04-23 12:52:41 --> Helper loaded: form_helper
INFO - 2018-04-23 12:52:41 --> Form Validation Class Initialized
INFO - 2018-04-23 12:52:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:52:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:52:41 --> Helper loaded: url_helper
INFO - 2018-04-23 12:52:41 --> Model Class Initialized
INFO - 2018-04-23 12:52:41 --> Model Class Initialized
INFO - 2018-04-23 12:52:41 --> Model Class Initialized
INFO - 2018-04-23 12:52:41 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:52:41 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:52:41 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:52:41 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:52:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:52:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:52:41 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:52:41 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:52:41 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:52:41 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:52:41 --> Final output sent to browser
DEBUG - 2018-04-23 12:52:41 --> Total execution time: 0.0030
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:52:41 --> Config Class Initialized
INFO - 2018-04-23 12:52:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:52:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:52:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:52:41 --> URI Class Initialized
INFO - 2018-04-23 12:52:41 --> Router Class Initialized
INFO - 2018-04-23 12:52:41 --> Output Class Initialized
INFO - 2018-04-23 12:52:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:52:41 --> Input Class Initialized
INFO - 2018-04-23 12:52:41 --> Language Class Initialized
ERROR - 2018-04-23 12:52:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:17 --> Config Class Initialized
INFO - 2018-04-23 12:53:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:17 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:17 --> URI Class Initialized
INFO - 2018-04-23 12:53:17 --> Router Class Initialized
INFO - 2018-04-23 12:53:17 --> Output Class Initialized
INFO - 2018-04-23 12:53:17 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:17 --> Input Class Initialized
INFO - 2018-04-23 12:53:17 --> Language Class Initialized
INFO - 2018-04-23 12:53:17 --> Loader Class Initialized
INFO - 2018-04-23 12:53:17 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:17 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:17 --> Email Class Initialized
INFO - 2018-04-23 12:53:17 --> Controller Class Initialized
INFO - 2018-04-23 12:53:17 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:17 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:17 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:17 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:17 --> Model Class Initialized
INFO - 2018-04-23 12:53:17 --> Model Class Initialized
INFO - 2018-04-23 12:53:17 --> Model Class Initialized
INFO - 2018-04-23 12:53:17 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:53:17 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:53:17 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:53:17 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:17 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:17 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:17 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:53:17 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:53:17 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:53:17 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:53:17 --> Final output sent to browser
DEBUG - 2018-04-23 12:53:17 --> Total execution time: 0.0034
INFO - 2018-04-23 12:53:20 --> Config Class Initialized
INFO - 2018-04-23 12:53:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:20 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:20 --> URI Class Initialized
INFO - 2018-04-23 12:53:20 --> Router Class Initialized
INFO - 2018-04-23 12:53:20 --> Output Class Initialized
INFO - 2018-04-23 12:53:20 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:20 --> Input Class Initialized
INFO - 2018-04-23 12:53:20 --> Language Class Initialized
INFO - 2018-04-23 12:53:20 --> Loader Class Initialized
INFO - 2018-04-23 12:53:20 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:20 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:20 --> Email Class Initialized
INFO - 2018-04-23 12:53:20 --> Controller Class Initialized
INFO - 2018-04-23 12:53:20 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:20 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:20 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:20 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:20 --> Model Class Initialized
INFO - 2018-04-23 12:53:20 --> Model Class Initialized
INFO - 2018-04-23 12:53:36 --> Config Class Initialized
INFO - 2018-04-23 12:53:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:36 --> URI Class Initialized
INFO - 2018-04-23 12:53:36 --> Router Class Initialized
INFO - 2018-04-23 12:53:36 --> Output Class Initialized
INFO - 2018-04-23 12:53:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:36 --> Input Class Initialized
INFO - 2018-04-23 12:53:36 --> Language Class Initialized
INFO - 2018-04-23 12:53:36 --> Loader Class Initialized
INFO - 2018-04-23 12:53:36 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:36 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:36 --> Email Class Initialized
INFO - 2018-04-23 12:53:36 --> Controller Class Initialized
INFO - 2018-04-23 12:53:36 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:36 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:36 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:36 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:36 --> Model Class Initialized
INFO - 2018-04-23 12:53:36 --> Model Class Initialized
INFO - 2018-04-23 12:53:37 --> Config Class Initialized
INFO - 2018-04-23 12:53:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:37 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:37 --> URI Class Initialized
INFO - 2018-04-23 12:53:37 --> Router Class Initialized
INFO - 2018-04-23 12:53:37 --> Output Class Initialized
INFO - 2018-04-23 12:53:37 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:37 --> Input Class Initialized
INFO - 2018-04-23 12:53:37 --> Language Class Initialized
INFO - 2018-04-23 12:53:37 --> Loader Class Initialized
INFO - 2018-04-23 12:53:37 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:37 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:37 --> Email Class Initialized
INFO - 2018-04-23 12:53:37 --> Controller Class Initialized
INFO - 2018-04-23 12:53:37 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:37 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:37 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:37 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:37 --> Model Class Initialized
INFO - 2018-04-23 12:53:37 --> Model Class Initialized
INFO - 2018-04-23 12:53:37 --> Model Class Initialized
INFO - 2018-04-23 12:53:37 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:53:37 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:53:37 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:53:37 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:37 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:37 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:37 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:53:37 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:53:37 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:53:37 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:53:37 --> Final output sent to browser
DEBUG - 2018-04-23 12:53:37 --> Total execution time: 0.0030
INFO - 2018-04-23 12:53:39 --> Config Class Initialized
INFO - 2018-04-23 12:53:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:39 --> URI Class Initialized
INFO - 2018-04-23 12:53:39 --> Router Class Initialized
INFO - 2018-04-23 12:53:39 --> Output Class Initialized
INFO - 2018-04-23 12:53:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:39 --> Input Class Initialized
INFO - 2018-04-23 12:53:39 --> Language Class Initialized
INFO - 2018-04-23 12:53:39 --> Loader Class Initialized
INFO - 2018-04-23 12:53:39 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:39 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:39 --> Email Class Initialized
INFO - 2018-04-23 12:53:39 --> Controller Class Initialized
INFO - 2018-04-23 12:53:39 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:39 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:39 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:39 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:39 --> Model Class Initialized
INFO - 2018-04-23 12:53:39 --> Model Class Initialized
INFO - 2018-04-23 12:53:39 --> Model Class Initialized
INFO - 2018-04-23 12:53:39 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:53:39 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:53:39 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:53:39 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:39 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:39 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:39 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:53:39 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:53:39 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:53:39 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:53:39 --> Final output sent to browser
DEBUG - 2018-04-23 12:53:39 --> Total execution time: 0.0031
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
INFO - 2018-04-23 12:53:41 --> Loader Class Initialized
INFO - 2018-04-23 12:53:41 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:41 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:41 --> Email Class Initialized
INFO - 2018-04-23 12:53:41 --> Controller Class Initialized
INFO - 2018-04-23 12:53:41 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:41 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:41 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:41 --> Model Class Initialized
INFO - 2018-04-23 12:53:41 --> Model Class Initialized
INFO - 2018-04-23 12:53:41 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:53:41 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:53:41 --> Undefined variable: categories
ERROR - 2018-04-23 12:53:41 --> Severity: Notice --> Undefined variable: categories /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 12:53:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 12:53:41 --> Undefined variable: articles
ERROR - 2018-04-23 12:53:41 --> Severity: Notice --> Undefined variable: articles /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 12:53:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 12:53:41 --> Undefined variable: subscriptions
ERROR - 2018-04-23 12:53:41 --> Severity: Notice --> Undefined variable: subscriptions /var/www/html/admin/application/views/dashboard.php 67
ERROR - 2018-04-23 12:53:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 67
INFO - 2018-04-23 12:53:41 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:53:41 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:53:41 --> Final output sent to browser
DEBUG - 2018-04-23 12:53:41 --> Total execution time: 0.0028
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:53:41 --> Config Class Initialized
INFO - 2018-04-23 12:53:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:41 --> URI Class Initialized
INFO - 2018-04-23 12:53:41 --> Router Class Initialized
INFO - 2018-04-23 12:53:41 --> Output Class Initialized
INFO - 2018-04-23 12:53:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:41 --> Input Class Initialized
INFO - 2018-04-23 12:53:41 --> Language Class Initialized
ERROR - 2018-04-23 12:53:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
INFO - 2018-04-23 12:53:48 --> Loader Class Initialized
INFO - 2018-04-23 12:53:48 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:48 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:48 --> Email Class Initialized
INFO - 2018-04-23 12:53:48 --> Controller Class Initialized
INFO - 2018-04-23 12:53:48 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:48 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:48 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:48 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:48 --> Model Class Initialized
INFO - 2018-04-23 12:53:48 --> Model Class Initialized
INFO - 2018-04-23 12:53:48 --> Model Class Initialized
INFO - 2018-04-23 18:23:48 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:23:48 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:23:48 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:23:48 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 18:23:48 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:23:48 --> Final output sent to browser
DEBUG - 2018-04-23 18:23:48 --> Total execution time: 0.0032
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:53:48 --> Config Class Initialized
INFO - 2018-04-23 12:53:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:48 --> URI Class Initialized
INFO - 2018-04-23 12:53:48 --> Router Class Initialized
INFO - 2018-04-23 12:53:48 --> Output Class Initialized
INFO - 2018-04-23 12:53:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:48 --> Input Class Initialized
INFO - 2018-04-23 12:53:48 --> Language Class Initialized
ERROR - 2018-04-23 12:53:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
INFO - 2018-04-23 12:53:53 --> Loader Class Initialized
INFO - 2018-04-23 12:53:53 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:53 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:53 --> Email Class Initialized
INFO - 2018-04-23 12:53:53 --> Controller Class Initialized
INFO - 2018-04-23 12:53:53 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:53 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:53 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:53 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:53 --> Model Class Initialized
INFO - 2018-04-23 12:53:53 --> Model Class Initialized
INFO - 2018-04-23 12:53:53 --> Model Class Initialized
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
INFO - 2018-04-23 12:53:53 --> Loader Class Initialized
INFO - 2018-04-23 12:53:53 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:53 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:53 --> Email Class Initialized
INFO - 2018-04-23 12:53:53 --> Controller Class Initialized
INFO - 2018-04-23 12:53:53 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:53 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:53 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:53 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:53 --> Model Class Initialized
INFO - 2018-04-23 12:53:53 --> Model Class Initialized
INFO - 2018-04-23 12:53:53 --> Model Class Initialized
INFO - 2018-04-23 12:53:53 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:53:53 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:53:53 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:53:53 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:53 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:53 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:53 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:53:53 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:53:53 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:53:53 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:53:53 --> Final output sent to browser
DEBUG - 2018-04-23 12:53:53 --> Total execution time: 0.0026
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
ERROR - 2018-04-23 12:53:53 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
ERROR - 2018-04-23 12:53:53 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
ERROR - 2018-04-23 12:53:53 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
ERROR - 2018-04-23 12:53:53 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
ERROR - 2018-04-23 12:53:53 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:53:53 --> Config Class Initialized
INFO - 2018-04-23 12:53:53 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:53 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:53 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:53 --> URI Class Initialized
INFO - 2018-04-23 12:53:53 --> Router Class Initialized
INFO - 2018-04-23 12:53:53 --> Output Class Initialized
INFO - 2018-04-23 12:53:53 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:53 --> Input Class Initialized
INFO - 2018-04-23 12:53:53 --> Language Class Initialized
ERROR - 2018-04-23 12:53:53 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:57 --> Config Class Initialized
INFO - 2018-04-23 12:53:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:57 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:57 --> URI Class Initialized
INFO - 2018-04-23 12:53:57 --> Router Class Initialized
INFO - 2018-04-23 12:53:57 --> Output Class Initialized
INFO - 2018-04-23 12:53:57 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:57 --> Input Class Initialized
INFO - 2018-04-23 12:53:57 --> Language Class Initialized
INFO - 2018-04-23 12:53:57 --> Loader Class Initialized
INFO - 2018-04-23 12:53:57 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:57 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:57 --> Email Class Initialized
INFO - 2018-04-23 12:53:57 --> Controller Class Initialized
INFO - 2018-04-23 12:53:57 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:57 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:57 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:57 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:57 --> Model Class Initialized
INFO - 2018-04-23 12:53:57 --> Model Class Initialized
INFO - 2018-04-23 12:53:57 --> Model Class Initialized
INFO - 2018-04-23 12:53:57 --> Config Class Initialized
INFO - 2018-04-23 12:53:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:57 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:57 --> URI Class Initialized
INFO - 2018-04-23 12:53:57 --> Router Class Initialized
INFO - 2018-04-23 12:53:57 --> Output Class Initialized
INFO - 2018-04-23 12:53:57 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:57 --> Input Class Initialized
INFO - 2018-04-23 12:53:57 --> Language Class Initialized
INFO - 2018-04-23 12:53:57 --> Loader Class Initialized
INFO - 2018-04-23 12:53:57 --> Helper loaded: common_helper
INFO - 2018-04-23 12:53:57 --> Database Driver Class Initialized
INFO - 2018-04-23 12:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:53:57 --> Email Class Initialized
INFO - 2018-04-23 12:53:57 --> Controller Class Initialized
INFO - 2018-04-23 12:53:57 --> Helper loaded: form_helper
INFO - 2018-04-23 12:53:57 --> Form Validation Class Initialized
INFO - 2018-04-23 12:53:57 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:53:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:53:57 --> Helper loaded: url_helper
INFO - 2018-04-23 12:53:57 --> Model Class Initialized
INFO - 2018-04-23 12:53:57 --> Model Class Initialized
INFO - 2018-04-23 12:53:57 --> Model Class Initialized
INFO - 2018-04-23 12:53:57 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:53:57 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:53:57 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:53:57 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:57 --> Trying to get property of non-object
ERROR - 2018-04-23 12:53:57 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:53:57 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:53:57 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:53:57 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:53:57 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:53:57 --> Final output sent to browser
DEBUG - 2018-04-23 12:53:57 --> Total execution time: 0.0031
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:53:58 --> Config Class Initialized
INFO - 2018-04-23 12:53:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:53:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:53:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:53:58 --> URI Class Initialized
INFO - 2018-04-23 12:53:58 --> Router Class Initialized
INFO - 2018-04-23 12:53:58 --> Output Class Initialized
INFO - 2018-04-23 12:53:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:53:58 --> Input Class Initialized
INFO - 2018-04-23 12:53:58 --> Language Class Initialized
ERROR - 2018-04-23 12:53:58 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:02 --> Config Class Initialized
INFO - 2018-04-23 12:54:02 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:02 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:02 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:02 --> URI Class Initialized
INFO - 2018-04-23 12:54:02 --> Router Class Initialized
INFO - 2018-04-23 12:54:02 --> Output Class Initialized
INFO - 2018-04-23 12:54:02 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:02 --> Input Class Initialized
INFO - 2018-04-23 12:54:02 --> Language Class Initialized
ERROR - 2018-04-23 12:54:02 --> 404 Page Not Found: Aadi%20pinisetty/index
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
INFO - 2018-04-23 12:54:18 --> Loader Class Initialized
INFO - 2018-04-23 12:54:18 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:18 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:18 --> Email Class Initialized
INFO - 2018-04-23 12:54:18 --> Controller Class Initialized
INFO - 2018-04-23 12:54:18 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:18 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:18 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:18 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:18 --> Model Class Initialized
INFO - 2018-04-23 12:54:18 --> Model Class Initialized
INFO - 2018-04-23 12:54:18 --> Model Class Initialized
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
INFO - 2018-04-23 12:54:18 --> Loader Class Initialized
INFO - 2018-04-23 12:54:18 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:18 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:18 --> Email Class Initialized
INFO - 2018-04-23 12:54:18 --> Controller Class Initialized
INFO - 2018-04-23 12:54:18 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:18 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:18 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:18 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:18 --> Model Class Initialized
INFO - 2018-04-23 12:54:18 --> Model Class Initialized
INFO - 2018-04-23 12:54:18 --> Model Class Initialized
INFO - 2018-04-23 12:54:18 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:54:18 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:54:18 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:54:18 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:54:18 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:54:18 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:54:18 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:54:18 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:54:18 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:18 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:18 --> Total execution time: 0.0030
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:18 --> Config Class Initialized
INFO - 2018-04-23 12:54:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:18 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:18 --> URI Class Initialized
INFO - 2018-04-23 12:54:18 --> Router Class Initialized
INFO - 2018-04-23 12:54:18 --> Output Class Initialized
INFO - 2018-04-23 12:54:18 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:18 --> Input Class Initialized
INFO - 2018-04-23 12:54:18 --> Language Class Initialized
ERROR - 2018-04-23 12:54:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:32 --> Config Class Initialized
INFO - 2018-04-23 12:54:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:32 --> URI Class Initialized
INFO - 2018-04-23 12:54:32 --> Router Class Initialized
INFO - 2018-04-23 12:54:32 --> Output Class Initialized
INFO - 2018-04-23 12:54:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:32 --> Input Class Initialized
INFO - 2018-04-23 12:54:32 --> Language Class Initialized
INFO - 2018-04-23 12:54:32 --> Loader Class Initialized
INFO - 2018-04-23 12:54:32 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:32 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:32 --> Email Class Initialized
INFO - 2018-04-23 12:54:32 --> Controller Class Initialized
INFO - 2018-04-23 12:54:32 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:32 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:32 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:32 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:32 --> Model Class Initialized
INFO - 2018-04-23 12:54:32 --> Model Class Initialized
INFO - 2018-04-23 12:54:32 --> Model Class Initialized
INFO - 2018-04-23 12:54:32 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:54:32 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:54:32 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:54:32 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:54:32 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:32 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:54:32 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:54:32 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:54:32 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:54:32 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:32 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:32 --> Total execution time: 0.0038
INFO - 2018-04-23 12:54:32 --> Config Class Initialized
INFO - 2018-04-23 12:54:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:32 --> URI Class Initialized
INFO - 2018-04-23 12:54:32 --> Router Class Initialized
INFO - 2018-04-23 12:54:32 --> Output Class Initialized
INFO - 2018-04-23 12:54:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:32 --> Input Class Initialized
INFO - 2018-04-23 12:54:32 --> Language Class Initialized
ERROR - 2018-04-23 12:54:32 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:32 --> Config Class Initialized
INFO - 2018-04-23 12:54:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:32 --> URI Class Initialized
INFO - 2018-04-23 12:54:32 --> Router Class Initialized
INFO - 2018-04-23 12:54:32 --> Output Class Initialized
INFO - 2018-04-23 12:54:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:32 --> Input Class Initialized
INFO - 2018-04-23 12:54:32 --> Language Class Initialized
ERROR - 2018-04-23 12:54:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:33 --> Config Class Initialized
INFO - 2018-04-23 12:54:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:33 --> URI Class Initialized
INFO - 2018-04-23 12:54:33 --> Router Class Initialized
INFO - 2018-04-23 12:54:33 --> Output Class Initialized
INFO - 2018-04-23 12:54:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:33 --> Input Class Initialized
INFO - 2018-04-23 12:54:33 --> Language Class Initialized
INFO - 2018-04-23 12:54:33 --> Loader Class Initialized
INFO - 2018-04-23 12:54:33 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:33 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:33 --> Email Class Initialized
INFO - 2018-04-23 12:54:33 --> Controller Class Initialized
INFO - 2018-04-23 12:54:33 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:33 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:33 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:33 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:33 --> Model Class Initialized
INFO - 2018-04-23 12:54:33 --> Model Class Initialized
INFO - 2018-04-23 12:54:33 --> Model Class Initialized
INFO - 2018-04-23 12:54:33 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:54:33 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:54:33 --> Undefined variable: noOfapps
ERROR - 2018-04-23 12:54:33 --> Severity: Notice --> Undefined variable: noOfapps /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:54:33 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:33 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 79
ERROR - 2018-04-23 12:54:33 --> Undefined variable: apptypes
ERROR - 2018-04-23 12:54:33 --> Severity: Notice --> Undefined variable: apptypes /var/www/html/admin/application/views/dashboard.php 87
INFO - 2018-04-23 12:54:33 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:54:33 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:33 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:33 --> Total execution time: 0.0030
INFO - 2018-04-23 12:54:34 --> Config Class Initialized
INFO - 2018-04-23 12:54:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:34 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:34 --> URI Class Initialized
INFO - 2018-04-23 12:54:34 --> Router Class Initialized
INFO - 2018-04-23 12:54:34 --> Output Class Initialized
INFO - 2018-04-23 12:54:34 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:34 --> Input Class Initialized
INFO - 2018-04-23 12:54:34 --> Language Class Initialized
INFO - 2018-04-23 12:54:34 --> Loader Class Initialized
INFO - 2018-04-23 12:54:34 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:34 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:34 --> Email Class Initialized
INFO - 2018-04-23 12:54:34 --> Controller Class Initialized
INFO - 2018-04-23 12:54:34 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:34 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:34 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:34 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:34 --> Model Class Initialized
INFO - 2018-04-23 12:54:34 --> Model Class Initialized
INFO - 2018-04-23 12:54:34 --> Model Class Initialized
INFO - 2018-04-23 18:24:34 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:24:34 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:24:34 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:24:34 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 18:24:34 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:24:34 --> Final output sent to browser
DEBUG - 2018-04-23 18:24:34 --> Total execution time: 0.0027
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
INFO - 2018-04-23 12:54:36 --> Loader Class Initialized
INFO - 2018-04-23 12:54:36 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:36 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:36 --> Email Class Initialized
INFO - 2018-04-23 12:54:36 --> Controller Class Initialized
INFO - 2018-04-23 12:54:36 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:36 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:36 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:36 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:36 --> Model Class Initialized
INFO - 2018-04-23 12:54:36 --> Model Class Initialized
INFO - 2018-04-23 12:54:36 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:54:36 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:54:36 --> Undefined variable: categories
ERROR - 2018-04-23 12:54:36 --> Severity: Notice --> Undefined variable: categories /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 12:54:36 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 12:54:36 --> Undefined variable: articles
ERROR - 2018-04-23 12:54:36 --> Severity: Notice --> Undefined variable: articles /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 12:54:36 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 12:54:36 --> Undefined variable: subscriptions
ERROR - 2018-04-23 12:54:36 --> Severity: Notice --> Undefined variable: subscriptions /var/www/html/admin/application/views/dashboard.php 67
ERROR - 2018-04-23 12:54:36 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 67
INFO - 2018-04-23 12:54:36 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:54:36 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:36 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:36 --> Total execution time: 0.0029
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
ERROR - 2018-04-23 12:54:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
ERROR - 2018-04-23 12:54:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
ERROR - 2018-04-23 12:54:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
ERROR - 2018-04-23 12:54:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
ERROR - 2018-04-23 12:54:36 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:36 --> Config Class Initialized
INFO - 2018-04-23 12:54:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:36 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:36 --> URI Class Initialized
INFO - 2018-04-23 12:54:36 --> Router Class Initialized
INFO - 2018-04-23 12:54:36 --> Output Class Initialized
INFO - 2018-04-23 12:54:36 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:36 --> Input Class Initialized
INFO - 2018-04-23 12:54:36 --> Language Class Initialized
ERROR - 2018-04-23 12:54:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
INFO - 2018-04-23 12:54:38 --> Loader Class Initialized
INFO - 2018-04-23 12:54:38 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:38 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:38 --> Email Class Initialized
INFO - 2018-04-23 12:54:38 --> Controller Class Initialized
INFO - 2018-04-23 12:54:38 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:38 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:38 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:38 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:38 --> Model Class Initialized
INFO - 2018-04-23 12:54:38 --> Model Class Initialized
INFO - 2018-04-23 12:54:38 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:54:38 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:54:38 --> File loaded: /var/www/html/admin/application/views/profile.php
INFO - 2018-04-23 12:54:38 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:54:38 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:38 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:38 --> Total execution time: 0.0030
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:38 --> Config Class Initialized
INFO - 2018-04-23 12:54:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:38 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:38 --> URI Class Initialized
INFO - 2018-04-23 12:54:38 --> Router Class Initialized
INFO - 2018-04-23 12:54:38 --> Output Class Initialized
INFO - 2018-04-23 12:54:38 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:38 --> Input Class Initialized
INFO - 2018-04-23 12:54:38 --> Language Class Initialized
ERROR - 2018-04-23 12:54:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
INFO - 2018-04-23 12:54:39 --> Loader Class Initialized
INFO - 2018-04-23 12:54:39 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:39 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:39 --> Email Class Initialized
INFO - 2018-04-23 12:54:39 --> Controller Class Initialized
INFO - 2018-04-23 12:54:39 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:39 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:39 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:39 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:39 --> Model Class Initialized
INFO - 2018-04-23 12:54:39 --> Model Class Initialized
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
DEBUG - 2018-04-23 12:54:39 --> No URI present. Default controller set.
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
INFO - 2018-04-23 12:54:39 --> Loader Class Initialized
INFO - 2018-04-23 12:54:39 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:39 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:39 --> Email Class Initialized
INFO - 2018-04-23 12:54:39 --> Controller Class Initialized
INFO - 2018-04-23 12:54:39 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:39 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:39 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:39 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:39 --> Model Class Initialized
INFO - 2018-04-23 12:54:39 --> Model Class Initialized
INFO - 2018-04-23 12:54:39 --> File loaded: /var/www/html/admin/application/views/index.php
INFO - 2018-04-23 12:54:39 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:39 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:39 --> Total execution time: 0.0029
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
ERROR - 2018-04-23 12:54:39 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
ERROR - 2018-04-23 12:54:39 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
ERROR - 2018-04-23 12:54:39 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
ERROR - 2018-04-23 12:54:39 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
ERROR - 2018-04-23 12:54:39 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:39 --> Config Class Initialized
INFO - 2018-04-23 12:54:39 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:39 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:39 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:39 --> URI Class Initialized
INFO - 2018-04-23 12:54:39 --> Router Class Initialized
INFO - 2018-04-23 12:54:39 --> Output Class Initialized
INFO - 2018-04-23 12:54:39 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:39 --> Input Class Initialized
INFO - 2018-04-23 12:54:39 --> Language Class Initialized
ERROR - 2018-04-23 12:54:39 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
DEBUG - 2018-04-23 12:54:41 --> No URI present. Default controller set.
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
INFO - 2018-04-23 12:54:41 --> Loader Class Initialized
INFO - 2018-04-23 12:54:41 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:41 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:41 --> Email Class Initialized
INFO - 2018-04-23 12:54:41 --> Controller Class Initialized
INFO - 2018-04-23 12:54:41 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:41 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:41 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:41 --> Model Class Initialized
INFO - 2018-04-23 12:54:41 --> Model Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
INFO - 2018-04-23 12:54:41 --> Loader Class Initialized
INFO - 2018-04-23 12:54:41 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:41 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:41 --> Email Class Initialized
INFO - 2018-04-23 12:54:41 --> Controller Class Initialized
INFO - 2018-04-23 12:54:41 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:41 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:41 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:41 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:41 --> Model Class Initialized
INFO - 2018-04-23 12:54:41 --> Model Class Initialized
INFO - 2018-04-23 12:54:41 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:54:41 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
ERROR - 2018-04-23 12:54:41 --> Undefined variable: categories
ERROR - 2018-04-23 12:54:41 --> Severity: Notice --> Undefined variable: categories /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 12:54:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 43
ERROR - 2018-04-23 12:54:41 --> Undefined variable: articles
ERROR - 2018-04-23 12:54:41 --> Severity: Notice --> Undefined variable: articles /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 12:54:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 55
ERROR - 2018-04-23 12:54:41 --> Undefined variable: subscriptions
ERROR - 2018-04-23 12:54:41 --> Severity: Notice --> Undefined variable: subscriptions /var/www/html/admin/application/views/dashboard.php 67
ERROR - 2018-04-23 12:54:41 --> Trying to get property of non-object
ERROR - 2018-04-23 12:54:41 --> Severity: Notice --> Trying to get property of non-object /var/www/html/admin/application/views/dashboard.php 67
INFO - 2018-04-23 12:54:41 --> File loaded: /var/www/html/admin/application/views/dashboard.php
INFO - 2018-04-23 12:54:41 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:54:41 --> Final output sent to browser
DEBUG - 2018-04-23 12:54:41 --> Total execution time: 0.0028
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
ERROR - 2018-04-23 12:54:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
ERROR - 2018-04-23 12:54:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
ERROR - 2018-04-23 12:54:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
ERROR - 2018-04-23 12:54:41 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
ERROR - 2018-04-23 12:54:41 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:41 --> Config Class Initialized
INFO - 2018-04-23 12:54:41 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:41 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:41 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:41 --> URI Class Initialized
INFO - 2018-04-23 12:54:41 --> Router Class Initialized
INFO - 2018-04-23 12:54:41 --> Output Class Initialized
INFO - 2018-04-23 12:54:41 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:41 --> Input Class Initialized
INFO - 2018-04-23 12:54:41 --> Language Class Initialized
ERROR - 2018-04-23 12:54:41 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
INFO - 2018-04-23 12:54:45 --> Loader Class Initialized
INFO - 2018-04-23 12:54:45 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:45 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:45 --> Email Class Initialized
INFO - 2018-04-23 12:54:45 --> Controller Class Initialized
INFO - 2018-04-23 12:54:45 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:45 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:45 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:45 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:45 --> Model Class Initialized
INFO - 2018-04-23 12:54:45 --> Model Class Initialized
INFO - 2018-04-23 12:54:45 --> Model Class Initialized
INFO - 2018-04-23 18:24:45 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:24:45 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:24:45 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:24:45 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 18:24:45 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:24:45 --> Final output sent to browser
DEBUG - 2018-04-23 18:24:45 --> Total execution time: 0.0027
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:54:45 --> Config Class Initialized
INFO - 2018-04-23 12:54:45 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:45 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:45 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:45 --> URI Class Initialized
INFO - 2018-04-23 12:54:45 --> Router Class Initialized
INFO - 2018-04-23 12:54:45 --> Output Class Initialized
INFO - 2018-04-23 12:54:45 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:45 --> Input Class Initialized
INFO - 2018-04-23 12:54:45 --> Language Class Initialized
ERROR - 2018-04-23 12:54:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:54:50 --> Config Class Initialized
INFO - 2018-04-23 12:54:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:54:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:54:50 --> Utf8 Class Initialized
INFO - 2018-04-23 12:54:50 --> URI Class Initialized
INFO - 2018-04-23 12:54:50 --> Router Class Initialized
INFO - 2018-04-23 12:54:50 --> Output Class Initialized
INFO - 2018-04-23 12:54:50 --> Security Class Initialized
DEBUG - 2018-04-23 12:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:54:50 --> Input Class Initialized
INFO - 2018-04-23 12:54:50 --> Language Class Initialized
INFO - 2018-04-23 12:54:50 --> Loader Class Initialized
INFO - 2018-04-23 12:54:50 --> Helper loaded: common_helper
INFO - 2018-04-23 12:54:50 --> Database Driver Class Initialized
INFO - 2018-04-23 12:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:54:50 --> Email Class Initialized
INFO - 2018-04-23 12:54:50 --> Controller Class Initialized
INFO - 2018-04-23 12:54:50 --> Helper loaded: form_helper
INFO - 2018-04-23 12:54:50 --> Form Validation Class Initialized
INFO - 2018-04-23 12:54:50 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:54:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:54:50 --> Helper loaded: url_helper
INFO - 2018-04-23 12:54:50 --> Model Class Initialized
INFO - 2018-04-23 12:54:50 --> Model Class Initialized
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
INFO - 2018-04-23 12:55:03 --> Loader Class Initialized
INFO - 2018-04-23 12:55:03 --> Helper loaded: common_helper
INFO - 2018-04-23 12:55:03 --> Database Driver Class Initialized
INFO - 2018-04-23 12:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:55:03 --> Email Class Initialized
INFO - 2018-04-23 12:55:03 --> Controller Class Initialized
INFO - 2018-04-23 12:55:03 --> Helper loaded: form_helper
INFO - 2018-04-23 12:55:03 --> Form Validation Class Initialized
INFO - 2018-04-23 12:55:03 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:55:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:55:03 --> Helper loaded: url_helper
INFO - 2018-04-23 12:55:03 --> Model Class Initialized
INFO - 2018-04-23 12:55:03 --> Model Class Initialized
INFO - 2018-04-23 12:55:03 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:55:03 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:55:03 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:55:03 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 12:55:03 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:55:03 --> Final output sent to browser
DEBUG - 2018-04-23 12:55:03 --> Total execution time: 0.0037
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:55:03 --> Config Class Initialized
INFO - 2018-04-23 12:55:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:03 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:03 --> URI Class Initialized
INFO - 2018-04-23 12:55:03 --> Router Class Initialized
INFO - 2018-04-23 12:55:03 --> Output Class Initialized
INFO - 2018-04-23 12:55:03 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:03 --> Input Class Initialized
INFO - 2018-04-23 12:55:03 --> Language Class Initialized
ERROR - 2018-04-23 12:55:03 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:55:08 --> Config Class Initialized
INFO - 2018-04-23 12:55:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:08 --> URI Class Initialized
INFO - 2018-04-23 12:55:08 --> Router Class Initialized
INFO - 2018-04-23 12:55:08 --> Output Class Initialized
INFO - 2018-04-23 12:55:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:08 --> Input Class Initialized
INFO - 2018-04-23 12:55:08 --> Language Class Initialized
ERROR - 2018-04-23 12:55:08 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:55:12 --> Config Class Initialized
INFO - 2018-04-23 12:55:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:12 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:12 --> URI Class Initialized
INFO - 2018-04-23 12:55:12 --> Router Class Initialized
INFO - 2018-04-23 12:55:12 --> Output Class Initialized
INFO - 2018-04-23 12:55:12 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:12 --> Input Class Initialized
INFO - 2018-04-23 12:55:12 --> Language Class Initialized
INFO - 2018-04-23 12:55:12 --> Loader Class Initialized
INFO - 2018-04-23 12:55:12 --> Helper loaded: common_helper
INFO - 2018-04-23 12:55:12 --> Database Driver Class Initialized
INFO - 2018-04-23 12:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:55:12 --> Email Class Initialized
INFO - 2018-04-23 12:55:12 --> Controller Class Initialized
INFO - 2018-04-23 12:55:12 --> Helper loaded: form_helper
INFO - 2018-04-23 12:55:12 --> Form Validation Class Initialized
INFO - 2018-04-23 12:55:12 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:55:12 --> Helper loaded: url_helper
INFO - 2018-04-23 12:55:12 --> Model Class Initialized
INFO - 2018-04-23 12:55:12 --> Model Class Initialized
INFO - 2018-04-23 12:55:12 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:55:12 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:55:12 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:55:12 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 12:55:12 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:55:12 --> Final output sent to browser
DEBUG - 2018-04-23 12:55:12 --> Total execution time: 0.0026
INFO - 2018-04-23 12:55:12 --> Config Class Initialized
INFO - 2018-04-23 12:55:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:12 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:12 --> Config Class Initialized
INFO - 2018-04-23 12:55:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:12 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:12 --> URI Class Initialized
INFO - 2018-04-23 12:55:12 --> Router Class Initialized
INFO - 2018-04-23 12:55:12 --> Output Class Initialized
INFO - 2018-04-23 12:55:12 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:12 --> Input Class Initialized
INFO - 2018-04-23 12:55:12 --> Language Class Initialized
ERROR - 2018-04-23 12:55:12 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:12 --> Config Class Initialized
INFO - 2018-04-23 12:55:12 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:12 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:12 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:12 --> URI Class Initialized
INFO - 2018-04-23 12:55:12 --> Router Class Initialized
INFO - 2018-04-23 12:55:12 --> Output Class Initialized
INFO - 2018-04-23 12:55:12 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:12 --> Input Class Initialized
INFO - 2018-04-23 12:55:12 --> Language Class Initialized
ERROR - 2018-04-23 12:55:12 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:55:13 --> URI Class Initialized
INFO - 2018-04-23 12:55:13 --> Router Class Initialized
INFO - 2018-04-23 12:55:13 --> Output Class Initialized
INFO - 2018-04-23 12:55:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:13 --> Input Class Initialized
INFO - 2018-04-23 12:55:13 --> Language Class Initialized
ERROR - 2018-04-23 12:55:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:13 --> Config Class Initialized
INFO - 2018-04-23 12:55:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:13 --> URI Class Initialized
INFO - 2018-04-23 12:55:13 --> Router Class Initialized
INFO - 2018-04-23 12:55:13 --> Output Class Initialized
INFO - 2018-04-23 12:55:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:13 --> Input Class Initialized
INFO - 2018-04-23 12:55:13 --> Language Class Initialized
ERROR - 2018-04-23 12:55:13 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:55:13 --> Config Class Initialized
INFO - 2018-04-23 12:55:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:13 --> URI Class Initialized
INFO - 2018-04-23 12:55:13 --> Router Class Initialized
INFO - 2018-04-23 12:55:13 --> Output Class Initialized
INFO - 2018-04-23 12:55:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:13 --> Input Class Initialized
INFO - 2018-04-23 12:55:13 --> Language Class Initialized
ERROR - 2018-04-23 12:55:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:55:13 --> Config Class Initialized
INFO - 2018-04-23 12:55:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:13 --> URI Class Initialized
INFO - 2018-04-23 12:55:13 --> Router Class Initialized
INFO - 2018-04-23 12:55:13 --> Output Class Initialized
INFO - 2018-04-23 12:55:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:13 --> Input Class Initialized
INFO - 2018-04-23 12:55:13 --> Language Class Initialized
ERROR - 2018-04-23 12:55:13 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:55:13 --> Config Class Initialized
INFO - 2018-04-23 12:55:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:13 --> URI Class Initialized
INFO - 2018-04-23 12:55:13 --> Router Class Initialized
INFO - 2018-04-23 12:55:13 --> Output Class Initialized
INFO - 2018-04-23 12:55:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:13 --> Input Class Initialized
INFO - 2018-04-23 12:55:13 --> Language Class Initialized
ERROR - 2018-04-23 12:55:13 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:55:35 --> Config Class Initialized
INFO - 2018-04-23 12:55:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:35 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:35 --> URI Class Initialized
INFO - 2018-04-23 12:55:35 --> Router Class Initialized
INFO - 2018-04-23 12:55:35 --> Output Class Initialized
INFO - 2018-04-23 12:55:35 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:35 --> Input Class Initialized
INFO - 2018-04-23 12:55:35 --> Language Class Initialized
INFO - 2018-04-23 12:55:35 --> Loader Class Initialized
INFO - 2018-04-23 12:55:35 --> Helper loaded: common_helper
INFO - 2018-04-23 12:55:35 --> Database Driver Class Initialized
INFO - 2018-04-23 12:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:55:35 --> Email Class Initialized
INFO - 2018-04-23 12:55:35 --> Controller Class Initialized
INFO - 2018-04-23 12:55:35 --> Helper loaded: form_helper
INFO - 2018-04-23 12:55:35 --> Form Validation Class Initialized
INFO - 2018-04-23 12:55:35 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:55:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:55:35 --> Helper loaded: url_helper
INFO - 2018-04-23 12:55:35 --> Model Class Initialized
INFO - 2018-04-23 12:55:35 --> Model Class Initialized
INFO - 2018-04-23 12:55:48 --> Config Class Initialized
INFO - 2018-04-23 12:55:48 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:48 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:48 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:48 --> URI Class Initialized
INFO - 2018-04-23 12:55:48 --> Router Class Initialized
INFO - 2018-04-23 12:55:48 --> Output Class Initialized
INFO - 2018-04-23 12:55:48 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:48 --> Input Class Initialized
INFO - 2018-04-23 12:55:48 --> Language Class Initialized
INFO - 2018-04-23 12:55:48 --> Loader Class Initialized
INFO - 2018-04-23 12:55:48 --> Helper loaded: common_helper
INFO - 2018-04-23 12:55:48 --> Database Driver Class Initialized
INFO - 2018-04-23 12:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:55:48 --> Email Class Initialized
INFO - 2018-04-23 12:55:48 --> Controller Class Initialized
INFO - 2018-04-23 12:55:48 --> Helper loaded: form_helper
INFO - 2018-04-23 12:55:48 --> Form Validation Class Initialized
INFO - 2018-04-23 12:55:48 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:55:48 --> Helper loaded: url_helper
INFO - 2018-04-23 12:55:48 --> Model Class Initialized
INFO - 2018-04-23 12:55:48 --> Model Class Initialized
INFO - 2018-04-23 12:55:57 --> Config Class Initialized
INFO - 2018-04-23 12:55:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:55:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:55:57 --> Utf8 Class Initialized
INFO - 2018-04-23 12:55:57 --> URI Class Initialized
INFO - 2018-04-23 12:55:57 --> Router Class Initialized
INFO - 2018-04-23 12:55:57 --> Output Class Initialized
INFO - 2018-04-23 12:55:57 --> Security Class Initialized
DEBUG - 2018-04-23 12:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:55:57 --> Input Class Initialized
INFO - 2018-04-23 12:55:57 --> Language Class Initialized
ERROR - 2018-04-23 12:55:57 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:29 --> Config Class Initialized
INFO - 2018-04-23 12:56:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:29 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:29 --> URI Class Initialized
INFO - 2018-04-23 12:56:29 --> Router Class Initialized
INFO - 2018-04-23 12:56:29 --> Output Class Initialized
INFO - 2018-04-23 12:56:29 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:29 --> Input Class Initialized
INFO - 2018-04-23 12:56:29 --> Language Class Initialized
ERROR - 2018-04-23 12:56:29 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:30 --> Config Class Initialized
INFO - 2018-04-23 12:56:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:30 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:30 --> URI Class Initialized
INFO - 2018-04-23 12:56:30 --> Router Class Initialized
INFO - 2018-04-23 12:56:30 --> Output Class Initialized
INFO - 2018-04-23 12:56:30 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:30 --> Input Class Initialized
INFO - 2018-04-23 12:56:30 --> Language Class Initialized
ERROR - 2018-04-23 12:56:30 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:30 --> Config Class Initialized
INFO - 2018-04-23 12:56:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:30 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:30 --> URI Class Initialized
INFO - 2018-04-23 12:56:30 --> Router Class Initialized
INFO - 2018-04-23 12:56:30 --> Output Class Initialized
INFO - 2018-04-23 12:56:30 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:30 --> Input Class Initialized
INFO - 2018-04-23 12:56:30 --> Language Class Initialized
ERROR - 2018-04-23 12:56:30 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:30 --> Config Class Initialized
INFO - 2018-04-23 12:56:30 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:30 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:30 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:30 --> URI Class Initialized
INFO - 2018-04-23 12:56:30 --> Router Class Initialized
INFO - 2018-04-23 12:56:30 --> Output Class Initialized
INFO - 2018-04-23 12:56:30 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:30 --> Input Class Initialized
INFO - 2018-04-23 12:56:30 --> Language Class Initialized
ERROR - 2018-04-23 12:56:30 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:31 --> Config Class Initialized
INFO - 2018-04-23 12:56:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:31 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:31 --> URI Class Initialized
INFO - 2018-04-23 12:56:31 --> Router Class Initialized
INFO - 2018-04-23 12:56:31 --> Output Class Initialized
INFO - 2018-04-23 12:56:31 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:31 --> Input Class Initialized
INFO - 2018-04-23 12:56:31 --> Language Class Initialized
ERROR - 2018-04-23 12:56:31 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:31 --> Config Class Initialized
INFO - 2018-04-23 12:56:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:31 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:31 --> URI Class Initialized
INFO - 2018-04-23 12:56:31 --> Router Class Initialized
INFO - 2018-04-23 12:56:31 --> Output Class Initialized
INFO - 2018-04-23 12:56:31 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:31 --> Input Class Initialized
INFO - 2018-04-23 12:56:31 --> Language Class Initialized
ERROR - 2018-04-23 12:56:31 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:31 --> Config Class Initialized
INFO - 2018-04-23 12:56:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:31 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:31 --> URI Class Initialized
INFO - 2018-04-23 12:56:31 --> Router Class Initialized
INFO - 2018-04-23 12:56:31 --> Output Class Initialized
INFO - 2018-04-23 12:56:31 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:31 --> Input Class Initialized
INFO - 2018-04-23 12:56:31 --> Language Class Initialized
ERROR - 2018-04-23 12:56:31 --> 404 Page Not Found: Adds/2
INFO - 2018-04-23 12:56:58 --> Config Class Initialized
INFO - 2018-04-23 12:56:58 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:56:58 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:56:58 --> Utf8 Class Initialized
INFO - 2018-04-23 12:56:58 --> URI Class Initialized
INFO - 2018-04-23 12:56:58 --> Router Class Initialized
INFO - 2018-04-23 12:56:58 --> Output Class Initialized
INFO - 2018-04-23 12:56:58 --> Security Class Initialized
DEBUG - 2018-04-23 12:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:56:58 --> Input Class Initialized
INFO - 2018-04-23 12:56:58 --> Language Class Initialized
INFO - 2018-04-23 12:56:58 --> Loader Class Initialized
INFO - 2018-04-23 12:56:58 --> Helper loaded: common_helper
INFO - 2018-04-23 12:56:58 --> Database Driver Class Initialized
INFO - 2018-04-23 12:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:56:58 --> Email Class Initialized
INFO - 2018-04-23 12:56:58 --> Controller Class Initialized
INFO - 2018-04-23 12:56:58 --> Helper loaded: form_helper
INFO - 2018-04-23 12:56:58 --> Form Validation Class Initialized
INFO - 2018-04-23 12:56:58 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:56:58 --> Helper loaded: url_helper
INFO - 2018-04-23 12:56:58 --> Model Class Initialized
INFO - 2018-04-23 12:56:58 --> Model Class Initialized
INFO - 2018-04-23 12:57:04 --> Config Class Initialized
INFO - 2018-04-23 12:57:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:04 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:04 --> URI Class Initialized
INFO - 2018-04-23 12:57:04 --> Router Class Initialized
INFO - 2018-04-23 12:57:04 --> Output Class Initialized
INFO - 2018-04-23 12:57:04 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:04 --> Input Class Initialized
INFO - 2018-04-23 12:57:04 --> Language Class Initialized
INFO - 2018-04-23 12:57:04 --> Loader Class Initialized
INFO - 2018-04-23 12:57:04 --> Helper loaded: common_helper
INFO - 2018-04-23 12:57:04 --> Database Driver Class Initialized
INFO - 2018-04-23 12:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:57:04 --> Email Class Initialized
INFO - 2018-04-23 12:57:04 --> Controller Class Initialized
INFO - 2018-04-23 12:57:04 --> Helper loaded: form_helper
INFO - 2018-04-23 12:57:04 --> Form Validation Class Initialized
INFO - 2018-04-23 12:57:04 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:57:04 --> Helper loaded: url_helper
INFO - 2018-04-23 12:57:04 --> Model Class Initialized
INFO - 2018-04-23 12:57:04 --> Model Class Initialized
INFO - 2018-04-23 12:57:05 --> Config Class Initialized
INFO - 2018-04-23 12:57:05 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:05 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:05 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:05 --> URI Class Initialized
INFO - 2018-04-23 12:57:05 --> Router Class Initialized
INFO - 2018-04-23 12:57:05 --> Output Class Initialized
INFO - 2018-04-23 12:57:05 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:05 --> Input Class Initialized
INFO - 2018-04-23 12:57:05 --> Language Class Initialized
INFO - 2018-04-23 12:57:05 --> Loader Class Initialized
INFO - 2018-04-23 12:57:05 --> Helper loaded: common_helper
INFO - 2018-04-23 12:57:05 --> Database Driver Class Initialized
INFO - 2018-04-23 12:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:57:05 --> Email Class Initialized
INFO - 2018-04-23 12:57:05 --> Controller Class Initialized
INFO - 2018-04-23 12:57:05 --> Helper loaded: form_helper
INFO - 2018-04-23 12:57:05 --> Form Validation Class Initialized
INFO - 2018-04-23 12:57:05 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:57:05 --> Helper loaded: url_helper
INFO - 2018-04-23 12:57:05 --> Model Class Initialized
INFO - 2018-04-23 12:57:05 --> Model Class Initialized
INFO - 2018-04-23 12:57:05 --> Model Class Initialized
INFO - 2018-04-23 18:27:05 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:27:05 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:27:05 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:27:05 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrity.php
INFO - 2018-04-23 18:27:05 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:27:05 --> Final output sent to browser
DEBUG - 2018-04-23 18:27:05 --> Total execution time: 0.0027
INFO - 2018-04-23 12:57:05 --> Config Class Initialized
INFO - 2018-04-23 12:57:05 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:05 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:05 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:05 --> URI Class Initialized
INFO - 2018-04-23 12:57:05 --> Router Class Initialized
INFO - 2018-04-23 12:57:05 --> Output Class Initialized
INFO - 2018-04-23 12:57:05 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:05 --> Input Class Initialized
INFO - 2018-04-23 12:57:05 --> Language Class Initialized
ERROR - 2018-04-23 12:57:05 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
INFO - 2018-04-23 12:57:07 --> Loader Class Initialized
INFO - 2018-04-23 12:57:07 --> Helper loaded: common_helper
INFO - 2018-04-23 12:57:07 --> Database Driver Class Initialized
INFO - 2018-04-23 12:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:57:07 --> Email Class Initialized
INFO - 2018-04-23 12:57:07 --> Controller Class Initialized
INFO - 2018-04-23 12:57:07 --> Helper loaded: form_helper
INFO - 2018-04-23 12:57:07 --> Form Validation Class Initialized
INFO - 2018-04-23 12:57:07 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:57:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:57:07 --> Helper loaded: url_helper
INFO - 2018-04-23 12:57:07 --> Model Class Initialized
INFO - 2018-04-23 12:57:07 --> Model Class Initialized
INFO - 2018-04-23 12:57:07 --> Model Class Initialized
INFO - 2018-04-23 18:27:07 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:27:07 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:27:07 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 18:27:07 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:27:07 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:27:07 --> Final output sent to browser
DEBUG - 2018-04-23 18:27:07 --> Total execution time: 0.0023
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
ERROR - 2018-04-23 12:57:07 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
ERROR - 2018-04-23 12:57:07 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
ERROR - 2018-04-23 12:57:07 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
ERROR - 2018-04-23 12:57:07 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
ERROR - 2018-04-23 12:57:07 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:07 --> Config Class Initialized
INFO - 2018-04-23 12:57:07 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:07 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:07 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:07 --> URI Class Initialized
INFO - 2018-04-23 12:57:07 --> Router Class Initialized
INFO - 2018-04-23 12:57:07 --> Output Class Initialized
INFO - 2018-04-23 12:57:07 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:07 --> Input Class Initialized
INFO - 2018-04-23 12:57:07 --> Language Class Initialized
ERROR - 2018-04-23 12:57:07 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
INFO - 2018-04-23 12:57:08 --> Loader Class Initialized
INFO - 2018-04-23 12:57:08 --> Helper loaded: common_helper
INFO - 2018-04-23 12:57:08 --> Database Driver Class Initialized
INFO - 2018-04-23 12:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:57:08 --> Email Class Initialized
INFO - 2018-04-23 12:57:08 --> Controller Class Initialized
INFO - 2018-04-23 12:57:08 --> Helper loaded: form_helper
INFO - 2018-04-23 12:57:08 --> Form Validation Class Initialized
INFO - 2018-04-23 12:57:08 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:57:08 --> Helper loaded: url_helper
INFO - 2018-04-23 12:57:08 --> Model Class Initialized
INFO - 2018-04-23 12:57:08 --> Model Class Initialized
INFO - 2018-04-23 12:57:08 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:57:08 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:57:08 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:57:08 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:57:08 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:57:08 --> Final output sent to browser
DEBUG - 2018-04-23 12:57:08 --> Total execution time: 0.0028
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:57:08 --> Config Class Initialized
INFO - 2018-04-23 12:57:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:08 --> URI Class Initialized
INFO - 2018-04-23 12:57:08 --> Router Class Initialized
INFO - 2018-04-23 12:57:08 --> Output Class Initialized
INFO - 2018-04-23 12:57:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:08 --> Input Class Initialized
INFO - 2018-04-23 12:57:08 --> Language Class Initialized
ERROR - 2018-04-23 12:57:08 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:13 --> Config Class Initialized
INFO - 2018-04-23 12:57:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:13 --> URI Class Initialized
INFO - 2018-04-23 12:57:13 --> Router Class Initialized
INFO - 2018-04-23 12:57:13 --> Output Class Initialized
INFO - 2018-04-23 12:57:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:13 --> Input Class Initialized
INFO - 2018-04-23 12:57:13 --> Language Class Initialized
INFO - 2018-04-23 12:57:13 --> Loader Class Initialized
INFO - 2018-04-23 12:57:13 --> Helper loaded: common_helper
INFO - 2018-04-23 12:57:13 --> Database Driver Class Initialized
INFO - 2018-04-23 12:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:57:13 --> Email Class Initialized
INFO - 2018-04-23 12:57:13 --> Controller Class Initialized
INFO - 2018-04-23 12:57:13 --> Helper loaded: form_helper
INFO - 2018-04-23 12:57:13 --> Form Validation Class Initialized
INFO - 2018-04-23 12:57:13 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:57:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:57:13 --> Helper loaded: url_helper
INFO - 2018-04-23 12:57:13 --> Model Class Initialized
INFO - 2018-04-23 12:57:13 --> Model Class Initialized
INFO - 2018-04-23 12:57:13 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:57:13 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:57:13 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:57:13 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:57:13 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:57:13 --> Final output sent to browser
DEBUG - 2018-04-23 12:57:13 --> Total execution time: 0.0027
INFO - 2018-04-23 12:57:13 --> Config Class Initialized
INFO - 2018-04-23 12:57:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:13 --> URI Class Initialized
INFO - 2018-04-23 12:57:13 --> Router Class Initialized
INFO - 2018-04-23 12:57:13 --> Output Class Initialized
INFO - 2018-04-23 12:57:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:13 --> Input Class Initialized
INFO - 2018-04-23 12:57:13 --> Language Class Initialized
ERROR - 2018-04-23 12:57:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:13 --> Config Class Initialized
INFO - 2018-04-23 12:57:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:13 --> URI Class Initialized
INFO - 2018-04-23 12:57:13 --> Router Class Initialized
INFO - 2018-04-23 12:57:13 --> Output Class Initialized
INFO - 2018-04-23 12:57:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:13 --> Input Class Initialized
INFO - 2018-04-23 12:57:13 --> Language Class Initialized
ERROR - 2018-04-23 12:57:13 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:13 --> Config Class Initialized
INFO - 2018-04-23 12:57:13 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:13 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:13 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:13 --> URI Class Initialized
INFO - 2018-04-23 12:57:13 --> Router Class Initialized
INFO - 2018-04-23 12:57:13 --> Output Class Initialized
INFO - 2018-04-23 12:57:13 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:13 --> Input Class Initialized
INFO - 2018-04-23 12:57:13 --> Language Class Initialized
ERROR - 2018-04-23 12:57:13 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:14 --> Config Class Initialized
INFO - 2018-04-23 12:57:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:14 --> URI Class Initialized
INFO - 2018-04-23 12:57:14 --> Router Class Initialized
INFO - 2018-04-23 12:57:14 --> Output Class Initialized
INFO - 2018-04-23 12:57:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:14 --> Input Class Initialized
INFO - 2018-04-23 12:57:14 --> Language Class Initialized
ERROR - 2018-04-23 12:57:14 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:14 --> Config Class Initialized
INFO - 2018-04-23 12:57:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:14 --> URI Class Initialized
INFO - 2018-04-23 12:57:14 --> Router Class Initialized
INFO - 2018-04-23 12:57:14 --> Output Class Initialized
INFO - 2018-04-23 12:57:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:14 --> Input Class Initialized
INFO - 2018-04-23 12:57:14 --> Language Class Initialized
ERROR - 2018-04-23 12:57:14 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:57:14 --> Config Class Initialized
INFO - 2018-04-23 12:57:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:14 --> URI Class Initialized
INFO - 2018-04-23 12:57:14 --> Router Class Initialized
INFO - 2018-04-23 12:57:14 --> Output Class Initialized
INFO - 2018-04-23 12:57:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:14 --> Input Class Initialized
INFO - 2018-04-23 12:57:14 --> Language Class Initialized
ERROR - 2018-04-23 12:57:14 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:14 --> Config Class Initialized
INFO - 2018-04-23 12:57:14 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:14 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:14 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:14 --> URI Class Initialized
INFO - 2018-04-23 12:57:14 --> Router Class Initialized
INFO - 2018-04-23 12:57:14 --> Output Class Initialized
INFO - 2018-04-23 12:57:14 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:14 --> Input Class Initialized
INFO - 2018-04-23 12:57:14 --> Language Class Initialized
ERROR - 2018-04-23 12:57:14 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
INFO - 2018-04-23 12:57:16 --> Loader Class Initialized
INFO - 2018-04-23 12:57:16 --> Helper loaded: common_helper
INFO - 2018-04-23 12:57:16 --> Database Driver Class Initialized
INFO - 2018-04-23 12:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:57:16 --> Email Class Initialized
INFO - 2018-04-23 12:57:16 --> Controller Class Initialized
INFO - 2018-04-23 12:57:16 --> Helper loaded: form_helper
INFO - 2018-04-23 12:57:16 --> Form Validation Class Initialized
INFO - 2018-04-23 12:57:16 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:57:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:57:16 --> Helper loaded: url_helper
INFO - 2018-04-23 12:57:16 --> Model Class Initialized
INFO - 2018-04-23 12:57:16 --> Model Class Initialized
INFO - 2018-04-23 12:57:16 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:57:16 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:57:16 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:57:16 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:57:16 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:57:16 --> Final output sent to browser
DEBUG - 2018-04-23 12:57:16 --> Total execution time: 0.0027
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:57:16 --> Config Class Initialized
INFO - 2018-04-23 12:57:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:16 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:16 --> URI Class Initialized
INFO - 2018-04-23 12:57:16 --> Router Class Initialized
INFO - 2018-04-23 12:57:16 --> Output Class Initialized
INFO - 2018-04-23 12:57:16 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:16 --> Input Class Initialized
INFO - 2018-04-23 12:57:16 --> Language Class Initialized
ERROR - 2018-04-23 12:57:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:57:50 --> Config Class Initialized
INFO - 2018-04-23 12:57:50 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:57:50 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:57:50 --> Utf8 Class Initialized
INFO - 2018-04-23 12:57:50 --> URI Class Initialized
INFO - 2018-04-23 12:57:50 --> Router Class Initialized
INFO - 2018-04-23 12:57:50 --> Output Class Initialized
INFO - 2018-04-23 12:57:50 --> Security Class Initialized
DEBUG - 2018-04-23 12:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:57:50 --> Input Class Initialized
INFO - 2018-04-23 12:57:50 --> Language Class Initialized
ERROR - 2018-04-23 12:57:50 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:08 --> Config Class Initialized
INFO - 2018-04-23 12:58:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:08 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:08 --> URI Class Initialized
INFO - 2018-04-23 12:58:08 --> Router Class Initialized
INFO - 2018-04-23 12:58:08 --> Output Class Initialized
INFO - 2018-04-23 12:58:08 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:08 --> Input Class Initialized
INFO - 2018-04-23 12:58:08 --> Language Class Initialized
ERROR - 2018-04-23 12:58:08 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:09 --> Config Class Initialized
INFO - 2018-04-23 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:09 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:09 --> URI Class Initialized
INFO - 2018-04-23 12:58:09 --> Router Class Initialized
INFO - 2018-04-23 12:58:09 --> Output Class Initialized
INFO - 2018-04-23 12:58:09 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:09 --> Input Class Initialized
INFO - 2018-04-23 12:58:09 --> Language Class Initialized
ERROR - 2018-04-23 12:58:09 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:09 --> Config Class Initialized
INFO - 2018-04-23 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:09 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:09 --> URI Class Initialized
INFO - 2018-04-23 12:58:09 --> Router Class Initialized
INFO - 2018-04-23 12:58:09 --> Output Class Initialized
INFO - 2018-04-23 12:58:09 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:09 --> Input Class Initialized
INFO - 2018-04-23 12:58:09 --> Language Class Initialized
ERROR - 2018-04-23 12:58:09 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:09 --> Config Class Initialized
INFO - 2018-04-23 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:09 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:09 --> URI Class Initialized
INFO - 2018-04-23 12:58:09 --> Router Class Initialized
INFO - 2018-04-23 12:58:09 --> Output Class Initialized
INFO - 2018-04-23 12:58:09 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:09 --> Input Class Initialized
INFO - 2018-04-23 12:58:09 --> Language Class Initialized
ERROR - 2018-04-23 12:58:09 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:09 --> Config Class Initialized
INFO - 2018-04-23 12:58:09 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:09 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:09 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:09 --> URI Class Initialized
INFO - 2018-04-23 12:58:09 --> Router Class Initialized
INFO - 2018-04-23 12:58:09 --> Output Class Initialized
INFO - 2018-04-23 12:58:09 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:09 --> Input Class Initialized
INFO - 2018-04-23 12:58:09 --> Language Class Initialized
ERROR - 2018-04-23 12:58:09 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:10 --> Config Class Initialized
INFO - 2018-04-23 12:58:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:10 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:10 --> URI Class Initialized
INFO - 2018-04-23 12:58:10 --> Router Class Initialized
INFO - 2018-04-23 12:58:10 --> Output Class Initialized
INFO - 2018-04-23 12:58:10 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:10 --> Input Class Initialized
INFO - 2018-04-23 12:58:10 --> Language Class Initialized
ERROR - 2018-04-23 12:58:10 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:10 --> Config Class Initialized
INFO - 2018-04-23 12:58:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:10 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:10 --> URI Class Initialized
INFO - 2018-04-23 12:58:10 --> Router Class Initialized
INFO - 2018-04-23 12:58:10 --> Output Class Initialized
INFO - 2018-04-23 12:58:10 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:10 --> Input Class Initialized
INFO - 2018-04-23 12:58:10 --> Language Class Initialized
ERROR - 2018-04-23 12:58:10 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:10 --> Config Class Initialized
INFO - 2018-04-23 12:58:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:10 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:10 --> URI Class Initialized
INFO - 2018-04-23 12:58:10 --> Router Class Initialized
INFO - 2018-04-23 12:58:10 --> Output Class Initialized
INFO - 2018-04-23 12:58:10 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:10 --> Input Class Initialized
INFO - 2018-04-23 12:58:10 --> Language Class Initialized
ERROR - 2018-04-23 12:58:10 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:10 --> Config Class Initialized
INFO - 2018-04-23 12:58:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:10 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:10 --> URI Class Initialized
INFO - 2018-04-23 12:58:10 --> Router Class Initialized
INFO - 2018-04-23 12:58:10 --> Output Class Initialized
INFO - 2018-04-23 12:58:10 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:10 --> Input Class Initialized
INFO - 2018-04-23 12:58:10 --> Language Class Initialized
ERROR - 2018-04-23 12:58:10 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:10 --> Config Class Initialized
INFO - 2018-04-23 12:58:10 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:10 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:10 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:10 --> URI Class Initialized
INFO - 2018-04-23 12:58:10 --> Router Class Initialized
INFO - 2018-04-23 12:58:10 --> Output Class Initialized
INFO - 2018-04-23 12:58:10 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:10 --> Input Class Initialized
INFO - 2018-04-23 12:58:10 --> Language Class Initialized
ERROR - 2018-04-23 12:58:10 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:31 --> Config Class Initialized
INFO - 2018-04-23 12:58:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:31 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:31 --> URI Class Initialized
INFO - 2018-04-23 12:58:31 --> Router Class Initialized
INFO - 2018-04-23 12:58:31 --> Output Class Initialized
INFO - 2018-04-23 12:58:31 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:31 --> Input Class Initialized
INFO - 2018-04-23 12:58:31 --> Language Class Initialized
ERROR - 2018-04-23 12:58:31 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:31 --> Config Class Initialized
INFO - 2018-04-23 12:58:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:31 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:31 --> URI Class Initialized
INFO - 2018-04-23 12:58:31 --> Router Class Initialized
INFO - 2018-04-23 12:58:31 --> Output Class Initialized
INFO - 2018-04-23 12:58:31 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:31 --> Input Class Initialized
INFO - 2018-04-23 12:58:31 --> Language Class Initialized
ERROR - 2018-04-23 12:58:31 --> 404 Page Not Found: Adds/index.php
INFO - 2018-04-23 12:58:32 --> Config Class Initialized
INFO - 2018-04-23 12:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:32 --> URI Class Initialized
INFO - 2018-04-23 12:58:32 --> Router Class Initialized
INFO - 2018-04-23 12:58:32 --> Output Class Initialized
INFO - 2018-04-23 12:58:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:32 --> Input Class Initialized
INFO - 2018-04-23 12:58:32 --> Language Class Initialized
INFO - 2018-04-23 12:58:32 --> Loader Class Initialized
INFO - 2018-04-23 12:58:32 --> Helper loaded: common_helper
INFO - 2018-04-23 12:58:32 --> Database Driver Class Initialized
INFO - 2018-04-23 12:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:58:32 --> Email Class Initialized
INFO - 2018-04-23 12:58:32 --> Controller Class Initialized
INFO - 2018-04-23 12:58:32 --> Helper loaded: form_helper
INFO - 2018-04-23 12:58:32 --> Form Validation Class Initialized
INFO - 2018-04-23 12:58:32 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:58:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:58:32 --> Helper loaded: url_helper
INFO - 2018-04-23 12:58:32 --> Model Class Initialized
INFO - 2018-04-23 12:58:32 --> Model Class Initialized
INFO - 2018-04-23 12:58:32 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:58:32 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:58:32 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:58:32 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:58:32 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:58:32 --> Final output sent to browser
DEBUG - 2018-04-23 12:58:32 --> Total execution time: 0.0038
INFO - 2018-04-23 12:58:32 --> Config Class Initialized
INFO - 2018-04-23 12:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:32 --> URI Class Initialized
INFO - 2018-04-23 12:58:32 --> Router Class Initialized
INFO - 2018-04-23 12:58:32 --> Output Class Initialized
INFO - 2018-04-23 12:58:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:32 --> Input Class Initialized
INFO - 2018-04-23 12:58:32 --> Language Class Initialized
ERROR - 2018-04-23 12:58:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:58:32 --> Config Class Initialized
INFO - 2018-04-23 12:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:32 --> URI Class Initialized
INFO - 2018-04-23 12:58:32 --> Router Class Initialized
INFO - 2018-04-23 12:58:32 --> Output Class Initialized
INFO - 2018-04-23 12:58:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:32 --> Input Class Initialized
INFO - 2018-04-23 12:58:32 --> Language Class Initialized
ERROR - 2018-04-23 12:58:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:58:32 --> Config Class Initialized
INFO - 2018-04-23 12:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:32 --> URI Class Initialized
INFO - 2018-04-23 12:58:32 --> Router Class Initialized
INFO - 2018-04-23 12:58:32 --> Output Class Initialized
INFO - 2018-04-23 12:58:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:32 --> Input Class Initialized
INFO - 2018-04-23 12:58:32 --> Language Class Initialized
ERROR - 2018-04-23 12:58:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:58:32 --> Config Class Initialized
INFO - 2018-04-23 12:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:32 --> URI Class Initialized
INFO - 2018-04-23 12:58:32 --> Config Class Initialized
INFO - 2018-04-23 12:58:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:32 --> URI Class Initialized
INFO - 2018-04-23 12:58:32 --> Router Class Initialized
INFO - 2018-04-23 12:58:32 --> Output Class Initialized
INFO - 2018-04-23 12:58:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:32 --> Input Class Initialized
INFO - 2018-04-23 12:58:32 --> Language Class Initialized
ERROR - 2018-04-23 12:58:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:58:32 --> Router Class Initialized
INFO - 2018-04-23 12:58:32 --> Output Class Initialized
INFO - 2018-04-23 12:58:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:32 --> Input Class Initialized
INFO - 2018-04-23 12:58:32 --> Language Class Initialized
ERROR - 2018-04-23 12:58:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
INFO - 2018-04-23 12:58:33 --> Loader Class Initialized
INFO - 2018-04-23 12:58:33 --> Helper loaded: common_helper
INFO - 2018-04-23 12:58:33 --> Database Driver Class Initialized
INFO - 2018-04-23 12:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:58:33 --> Email Class Initialized
INFO - 2018-04-23 12:58:33 --> Controller Class Initialized
INFO - 2018-04-23 12:58:33 --> Helper loaded: form_helper
INFO - 2018-04-23 12:58:33 --> Form Validation Class Initialized
INFO - 2018-04-23 12:58:33 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:58:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:58:33 --> Helper loaded: url_helper
INFO - 2018-04-23 12:58:33 --> Model Class Initialized
INFO - 2018-04-23 12:58:33 --> Model Class Initialized
INFO - 2018-04-23 12:58:33 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:58:33 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:58:33 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:58:33 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:58:33 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:58:33 --> Final output sent to browser
DEBUG - 2018-04-23 12:58:33 --> Total execution time: 0.0025
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:58:33 --> Config Class Initialized
INFO - 2018-04-23 12:58:33 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:58:33 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:58:33 --> Utf8 Class Initialized
INFO - 2018-04-23 12:58:33 --> URI Class Initialized
INFO - 2018-04-23 12:58:33 --> Router Class Initialized
INFO - 2018-04-23 12:58:33 --> Output Class Initialized
INFO - 2018-04-23 12:58:33 --> Security Class Initialized
DEBUG - 2018-04-23 12:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:58:33 --> Input Class Initialized
INFO - 2018-04-23 12:58:33 --> Language Class Initialized
ERROR - 2018-04-23 12:58:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
INFO - 2018-04-23 12:59:32 --> Loader Class Initialized
INFO - 2018-04-23 12:59:32 --> Helper loaded: common_helper
INFO - 2018-04-23 12:59:32 --> Database Driver Class Initialized
INFO - 2018-04-23 12:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:59:32 --> Email Class Initialized
INFO - 2018-04-23 12:59:32 --> Controller Class Initialized
INFO - 2018-04-23 12:59:32 --> Helper loaded: form_helper
INFO - 2018-04-23 12:59:32 --> Form Validation Class Initialized
INFO - 2018-04-23 12:59:32 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:59:32 --> Helper loaded: url_helper
INFO - 2018-04-23 12:59:32 --> Model Class Initialized
INFO - 2018-04-23 12:59:32 --> Model Class Initialized
INFO - 2018-04-23 12:59:32 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 12:59:32 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 12:59:32 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 12:59:32 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 12:59:32 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 12:59:32 --> Final output sent to browser
DEBUG - 2018-04-23 12:59:32 --> Total execution time: 0.0030
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/select2
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
ERROR - 2018-04-23 12:59:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 12:59:32 --> Config Class Initialized
INFO - 2018-04-23 12:59:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 12:59:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 12:59:32 --> Utf8 Class Initialized
INFO - 2018-04-23 12:59:32 --> URI Class Initialized
INFO - 2018-04-23 12:59:32 --> Router Class Initialized
INFO - 2018-04-23 12:59:32 --> Output Class Initialized
INFO - 2018-04-23 12:59:32 --> Security Class Initialized
DEBUG - 2018-04-23 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 12:59:32 --> Input Class Initialized
INFO - 2018-04-23 12:59:32 --> Language Class Initialized
INFO - 2018-04-23 12:59:32 --> Loader Class Initialized
INFO - 2018-04-23 12:59:32 --> Helper loaded: common_helper
INFO - 2018-04-23 12:59:32 --> Database Driver Class Initialized
INFO - 2018-04-23 12:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 12:59:32 --> Email Class Initialized
INFO - 2018-04-23 12:59:32 --> Controller Class Initialized
INFO - 2018-04-23 12:59:32 --> Helper loaded: form_helper
INFO - 2018-04-23 12:59:32 --> Form Validation Class Initialized
INFO - 2018-04-23 12:59:32 --> Helper loaded: email_helper
DEBUG - 2018-04-23 12:59:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 12:59:32 --> Helper loaded: url_helper
INFO - 2018-04-23 12:59:32 --> Model Class Initialized
INFO - 2018-04-23 12:59:32 --> Model Class Initialized
INFO - 2018-04-23 13:00:23 --> Config Class Initialized
INFO - 2018-04-23 13:00:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:00:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:00:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:00:23 --> URI Class Initialized
INFO - 2018-04-23 13:00:23 --> Router Class Initialized
INFO - 2018-04-23 13:00:23 --> Output Class Initialized
INFO - 2018-04-23 13:00:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:00:23 --> Input Class Initialized
INFO - 2018-04-23 13:00:23 --> Language Class Initialized
INFO - 2018-04-23 13:00:23 --> Loader Class Initialized
INFO - 2018-04-23 13:00:23 --> Helper loaded: common_helper
INFO - 2018-04-23 13:00:23 --> Database Driver Class Initialized
INFO - 2018-04-23 13:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:00:23 --> Email Class Initialized
INFO - 2018-04-23 13:00:23 --> Controller Class Initialized
INFO - 2018-04-23 13:00:23 --> Helper loaded: form_helper
INFO - 2018-04-23 13:00:23 --> Form Validation Class Initialized
INFO - 2018-04-23 13:00:23 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:00:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:00:23 --> Helper loaded: url_helper
INFO - 2018-04-23 13:00:23 --> Model Class Initialized
INFO - 2018-04-23 13:00:23 --> Model Class Initialized
INFO - 2018-04-23 13:00:34 --> Config Class Initialized
INFO - 2018-04-23 13:00:34 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:00:34 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:00:34 --> Utf8 Class Initialized
INFO - 2018-04-23 13:00:34 --> URI Class Initialized
INFO - 2018-04-23 13:00:34 --> Router Class Initialized
INFO - 2018-04-23 13:00:34 --> Output Class Initialized
INFO - 2018-04-23 13:00:34 --> Security Class Initialized
DEBUG - 2018-04-23 13:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:00:34 --> Input Class Initialized
INFO - 2018-04-23 13:00:34 --> Language Class Initialized
INFO - 2018-04-23 13:00:34 --> Loader Class Initialized
INFO - 2018-04-23 13:00:34 --> Helper loaded: common_helper
INFO - 2018-04-23 13:00:34 --> Database Driver Class Initialized
INFO - 2018-04-23 13:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:00:34 --> Email Class Initialized
INFO - 2018-04-23 13:00:34 --> Controller Class Initialized
INFO - 2018-04-23 13:00:34 --> Helper loaded: form_helper
INFO - 2018-04-23 13:00:34 --> Form Validation Class Initialized
INFO - 2018-04-23 13:00:34 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:00:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:00:34 --> Helper loaded: url_helper
INFO - 2018-04-23 13:00:34 --> Model Class Initialized
INFO - 2018-04-23 13:00:34 --> Model Class Initialized
INFO - 2018-04-23 13:00:51 --> Config Class Initialized
INFO - 2018-04-23 13:00:51 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:00:51 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:00:51 --> Utf8 Class Initialized
INFO - 2018-04-23 13:00:51 --> URI Class Initialized
INFO - 2018-04-23 13:00:51 --> Router Class Initialized
INFO - 2018-04-23 13:00:51 --> Output Class Initialized
INFO - 2018-04-23 13:00:51 --> Security Class Initialized
DEBUG - 2018-04-23 13:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:00:51 --> Input Class Initialized
INFO - 2018-04-23 13:00:51 --> Language Class Initialized
INFO - 2018-04-23 13:00:51 --> Loader Class Initialized
INFO - 2018-04-23 13:00:51 --> Helper loaded: common_helper
INFO - 2018-04-23 13:00:51 --> Database Driver Class Initialized
INFO - 2018-04-23 13:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:00:51 --> Email Class Initialized
INFO - 2018-04-23 13:00:51 --> Controller Class Initialized
INFO - 2018-04-23 13:00:51 --> Helper loaded: form_helper
INFO - 2018-04-23 13:00:51 --> Form Validation Class Initialized
INFO - 2018-04-23 13:00:51 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:00:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:00:51 --> Helper loaded: url_helper
INFO - 2018-04-23 13:00:51 --> Model Class Initialized
INFO - 2018-04-23 13:00:51 --> Model Class Initialized
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
INFO - 2018-04-23 13:01:06 --> Loader Class Initialized
INFO - 2018-04-23 13:01:06 --> Helper loaded: common_helper
INFO - 2018-04-23 13:01:06 --> Database Driver Class Initialized
INFO - 2018-04-23 13:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:01:06 --> Email Class Initialized
INFO - 2018-04-23 13:01:06 --> Controller Class Initialized
INFO - 2018-04-23 13:01:06 --> Helper loaded: form_helper
INFO - 2018-04-23 13:01:06 --> Form Validation Class Initialized
INFO - 2018-04-23 13:01:06 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:01:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:01:06 --> Helper loaded: url_helper
INFO - 2018-04-23 13:01:06 --> Model Class Initialized
INFO - 2018-04-23 13:01:06 --> Model Class Initialized
INFO - 2018-04-23 13:01:06 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:01:06 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:01:06 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:01:06 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:01:06 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:01:06 --> Final output sent to browser
DEBUG - 2018-04-23 13:01:06 --> Total execution time: 0.0037
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:01:06 --> Config Class Initialized
INFO - 2018-04-23 13:01:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:06 --> URI Class Initialized
INFO - 2018-04-23 13:01:06 --> Router Class Initialized
INFO - 2018-04-23 13:01:06 --> Output Class Initialized
INFO - 2018-04-23 13:01:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:06 --> Input Class Initialized
INFO - 2018-04-23 13:01:06 --> Language Class Initialized
ERROR - 2018-04-23 13:01:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:01:16 --> Config Class Initialized
INFO - 2018-04-23 13:01:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:16 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:16 --> URI Class Initialized
INFO - 2018-04-23 13:01:16 --> Router Class Initialized
INFO - 2018-04-23 13:01:16 --> Output Class Initialized
INFO - 2018-04-23 13:01:16 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:16 --> Input Class Initialized
INFO - 2018-04-23 13:01:16 --> Language Class Initialized
ERROR - 2018-04-23 13:01:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:01:16 --> Config Class Initialized
INFO - 2018-04-23 13:01:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:16 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:16 --> URI Class Initialized
INFO - 2018-04-23 13:01:16 --> Router Class Initialized
INFO - 2018-04-23 13:01:16 --> Output Class Initialized
INFO - 2018-04-23 13:01:16 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:16 --> Input Class Initialized
INFO - 2018-04-23 13:01:16 --> Language Class Initialized
ERROR - 2018-04-23 13:01:16 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:01:16 --> Config Class Initialized
INFO - 2018-04-23 13:01:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:01:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:01:16 --> Utf8 Class Initialized
INFO - 2018-04-23 13:01:16 --> URI Class Initialized
INFO - 2018-04-23 13:01:16 --> Router Class Initialized
INFO - 2018-04-23 13:01:16 --> Output Class Initialized
INFO - 2018-04-23 13:01:16 --> Security Class Initialized
DEBUG - 2018-04-23 13:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:01:16 --> Input Class Initialized
INFO - 2018-04-23 13:01:16 --> Language Class Initialized
ERROR - 2018-04-23 13:01:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:12:20 --> Config Class Initialized
INFO - 2018-04-23 13:12:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:20 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:20 --> URI Class Initialized
INFO - 2018-04-23 13:12:20 --> Router Class Initialized
INFO - 2018-04-23 13:12:20 --> Output Class Initialized
INFO - 2018-04-23 13:12:20 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:20 --> Input Class Initialized
INFO - 2018-04-23 13:12:20 --> Language Class Initialized
ERROR - 2018-04-23 13:12:20 --> Exception: syntax error, unexpected 'catch' (T_CATCH), expecting function (T_FUNCTION)
ERROR - 2018-04-23 13:12:20 --> Severity: error --> Exception: syntax error, unexpected 'catch' (T_CATCH), expecting function (T_FUNCTION) /var/www/html/admin/application/controllers/Adds.php 157
ERROR - 2018-04-23 13:12:20 --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in /var/www/html/admin/system/core/Common.php on line 658 and defined in /var/www/html/admin/system/core/Exceptions.php:191
Stack trace:
#0 /var/www/html/admin/system/core/Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown
ERROR - 2018-04-23 13:12:20 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in /var/www/html/admin/system/core/Common.php on line 658 and defined in /var/www/html/admin/system/core/Exceptions.php:191
Stack trace:
#0 /var/www/html/admin/system/core/Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown /var/www/html/admin/system/core/Exceptions.php 191
INFO - 2018-04-23 13:12:22 --> Config Class Initialized
INFO - 2018-04-23 13:12:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:22 --> URI Class Initialized
INFO - 2018-04-23 13:12:22 --> Router Class Initialized
INFO - 2018-04-23 13:12:22 --> Output Class Initialized
INFO - 2018-04-23 13:12:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:22 --> Input Class Initialized
INFO - 2018-04-23 13:12:22 --> Language Class Initialized
ERROR - 2018-04-23 13:12:22 --> Exception: syntax error, unexpected 'catch' (T_CATCH), expecting function (T_FUNCTION)
ERROR - 2018-04-23 13:12:22 --> Severity: error --> Exception: syntax error, unexpected 'catch' (T_CATCH), expecting function (T_FUNCTION) /var/www/html/admin/application/controllers/Adds.php 157
ERROR - 2018-04-23 13:12:22 --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in /var/www/html/admin/system/core/Common.php on line 658 and defined in /var/www/html/admin/system/core/Exceptions.php:191
Stack trace:
#0 /var/www/html/admin/system/core/Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown
ERROR - 2018-04-23 13:12:22 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in /var/www/html/admin/system/core/Common.php on line 658 and defined in /var/www/html/admin/system/core/Exceptions.php:191
Stack trace:
#0 /var/www/html/admin/system/core/Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown /var/www/html/admin/system/core/Exceptions.php 191
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
INFO - 2018-04-23 13:12:57 --> Loader Class Initialized
INFO - 2018-04-23 13:12:57 --> Helper loaded: common_helper
INFO - 2018-04-23 13:12:57 --> Database Driver Class Initialized
INFO - 2018-04-23 13:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:12:57 --> Email Class Initialized
INFO - 2018-04-23 13:12:57 --> Controller Class Initialized
INFO - 2018-04-23 13:12:57 --> Helper loaded: form_helper
INFO - 2018-04-23 13:12:57 --> Form Validation Class Initialized
INFO - 2018-04-23 13:12:57 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:12:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:12:57 --> Helper loaded: url_helper
INFO - 2018-04-23 13:12:57 --> Model Class Initialized
INFO - 2018-04-23 13:12:57 --> Model Class Initialized
INFO - 2018-04-23 13:12:57 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:12:57 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:12:57 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:12:57 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:12:57 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:12:57 --> Final output sent to browser
DEBUG - 2018-04-23 13:12:57 --> Total execution time: 0.0040
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:12:57 --> Config Class Initialized
INFO - 2018-04-23 13:12:57 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:57 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:57 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:57 --> URI Class Initialized
INFO - 2018-04-23 13:12:57 --> Router Class Initialized
INFO - 2018-04-23 13:12:57 --> Output Class Initialized
INFO - 2018-04-23 13:12:57 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:57 --> Input Class Initialized
INFO - 2018-04-23 13:12:57 --> Language Class Initialized
ERROR - 2018-04-23 13:12:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
INFO - 2018-04-23 13:12:59 --> Loader Class Initialized
INFO - 2018-04-23 13:12:59 --> Helper loaded: common_helper
INFO - 2018-04-23 13:12:59 --> Database Driver Class Initialized
INFO - 2018-04-23 13:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:12:59 --> Email Class Initialized
INFO - 2018-04-23 13:12:59 --> Controller Class Initialized
INFO - 2018-04-23 13:12:59 --> Helper loaded: form_helper
INFO - 2018-04-23 13:12:59 --> Form Validation Class Initialized
INFO - 2018-04-23 13:12:59 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:12:59 --> Helper loaded: url_helper
INFO - 2018-04-23 13:12:59 --> Model Class Initialized
INFO - 2018-04-23 13:12:59 --> Model Class Initialized
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
INFO - 2018-04-23 13:12:59 --> Loader Class Initialized
INFO - 2018-04-23 13:12:59 --> Helper loaded: common_helper
INFO - 2018-04-23 13:12:59 --> Database Driver Class Initialized
INFO - 2018-04-23 13:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:12:59 --> Email Class Initialized
INFO - 2018-04-23 13:12:59 --> Controller Class Initialized
INFO - 2018-04-23 13:12:59 --> Helper loaded: form_helper
INFO - 2018-04-23 13:12:59 --> Form Validation Class Initialized
INFO - 2018-04-23 13:12:59 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:12:59 --> Helper loaded: url_helper
INFO - 2018-04-23 13:12:59 --> Model Class Initialized
INFO - 2018-04-23 13:12:59 --> Model Class Initialized
INFO - 2018-04-23 13:12:59 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:12:59 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:12:59 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:12:59 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 13:12:59 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:12:59 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:12:59 --> Final output sent to browser
DEBUG - 2018-04-23 13:12:59 --> Total execution time: 0.0018
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:12:59 --> Config Class Initialized
INFO - 2018-04-23 13:12:59 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:12:59 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:12:59 --> Utf8 Class Initialized
INFO - 2018-04-23 13:12:59 --> URI Class Initialized
INFO - 2018-04-23 13:12:59 --> Router Class Initialized
INFO - 2018-04-23 13:12:59 --> Output Class Initialized
INFO - 2018-04-23 13:12:59 --> Security Class Initialized
DEBUG - 2018-04-23 13:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:12:59 --> Input Class Initialized
INFO - 2018-04-23 13:12:59 --> Language Class Initialized
ERROR - 2018-04-23 13:12:59 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:02 --> Config Class Initialized
INFO - 2018-04-23 13:13:02 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:02 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:02 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:02 --> URI Class Initialized
INFO - 2018-04-23 13:13:02 --> Router Class Initialized
INFO - 2018-04-23 13:13:02 --> Output Class Initialized
INFO - 2018-04-23 13:13:02 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:02 --> Input Class Initialized
INFO - 2018-04-23 13:13:02 --> Language Class Initialized
INFO - 2018-04-23 13:13:02 --> Loader Class Initialized
INFO - 2018-04-23 13:13:02 --> Helper loaded: common_helper
INFO - 2018-04-23 13:13:02 --> Database Driver Class Initialized
INFO - 2018-04-23 13:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:13:02 --> Email Class Initialized
INFO - 2018-04-23 13:13:02 --> Controller Class Initialized
INFO - 2018-04-23 13:13:02 --> Helper loaded: form_helper
INFO - 2018-04-23 13:13:02 --> Form Validation Class Initialized
INFO - 2018-04-23 13:13:02 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:13:02 --> Helper loaded: url_helper
INFO - 2018-04-23 13:13:02 --> Model Class Initialized
INFO - 2018-04-23 13:13:02 --> Model Class Initialized
INFO - 2018-04-23 13:13:02 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:13:02 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:13:02 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:13:02 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:13:02 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:13:02 --> Final output sent to browser
DEBUG - 2018-04-23 13:13:02 --> Total execution time: 0.0027
INFO - 2018-04-23 13:13:02 --> Config Class Initialized
INFO - 2018-04-23 13:13:02 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:02 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:02 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:02 --> URI Class Initialized
INFO - 2018-04-23 13:13:02 --> Router Class Initialized
INFO - 2018-04-23 13:13:02 --> Output Class Initialized
INFO - 2018-04-23 13:13:02 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:02 --> Input Class Initialized
INFO - 2018-04-23 13:13:02 --> Language Class Initialized
ERROR - 2018-04-23 13:13:02 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
INFO - 2018-04-23 13:13:25 --> Loader Class Initialized
INFO - 2018-04-23 13:13:25 --> Helper loaded: common_helper
INFO - 2018-04-23 13:13:25 --> Database Driver Class Initialized
INFO - 2018-04-23 13:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:13:25 --> Email Class Initialized
INFO - 2018-04-23 13:13:25 --> Controller Class Initialized
INFO - 2018-04-23 13:13:25 --> Helper loaded: form_helper
INFO - 2018-04-23 13:13:25 --> Form Validation Class Initialized
INFO - 2018-04-23 13:13:25 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:13:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:13:25 --> Helper loaded: url_helper
INFO - 2018-04-23 13:13:25 --> Model Class Initialized
INFO - 2018-04-23 13:13:25 --> Model Class Initialized
INFO - 2018-04-23 13:13:25 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:13:25 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:13:25 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:13:25 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:13:25 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:13:25 --> Final output sent to browser
DEBUG - 2018-04-23 13:13:25 --> Total execution time: 0.0038
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:13:25 --> Config Class Initialized
INFO - 2018-04-23 13:13:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:25 --> URI Class Initialized
INFO - 2018-04-23 13:13:25 --> Router Class Initialized
INFO - 2018-04-23 13:13:25 --> Output Class Initialized
INFO - 2018-04-23 13:13:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:25 --> Input Class Initialized
INFO - 2018-04-23 13:13:25 --> Language Class Initialized
ERROR - 2018-04-23 13:13:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
INFO - 2018-04-23 13:13:26 --> Loader Class Initialized
INFO - 2018-04-23 13:13:26 --> Helper loaded: common_helper
INFO - 2018-04-23 13:13:26 --> Database Driver Class Initialized
INFO - 2018-04-23 13:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:13:26 --> Email Class Initialized
INFO - 2018-04-23 13:13:26 --> Controller Class Initialized
INFO - 2018-04-23 13:13:26 --> Helper loaded: form_helper
INFO - 2018-04-23 13:13:26 --> Form Validation Class Initialized
INFO - 2018-04-23 13:13:26 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:13:26 --> Helper loaded: url_helper
INFO - 2018-04-23 13:13:26 --> Model Class Initialized
INFO - 2018-04-23 13:13:26 --> Model Class Initialized
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
INFO - 2018-04-23 13:13:26 --> Loader Class Initialized
INFO - 2018-04-23 13:13:26 --> Helper loaded: common_helper
INFO - 2018-04-23 13:13:26 --> Database Driver Class Initialized
INFO - 2018-04-23 13:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:13:26 --> Email Class Initialized
INFO - 2018-04-23 13:13:26 --> Controller Class Initialized
INFO - 2018-04-23 13:13:26 --> Helper loaded: form_helper
INFO - 2018-04-23 13:13:26 --> Form Validation Class Initialized
INFO - 2018-04-23 13:13:26 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:13:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:13:26 --> Helper loaded: url_helper
INFO - 2018-04-23 13:13:26 --> Model Class Initialized
INFO - 2018-04-23 13:13:26 --> Model Class Initialized
INFO - 2018-04-23 13:13:26 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:13:26 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:13:26 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:13:26 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 13:13:26 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:13:26 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:13:26 --> Final output sent to browser
DEBUG - 2018-04-23 13:13:26 --> Total execution time: 0.0016
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:13:26 --> Config Class Initialized
INFO - 2018-04-23 13:13:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:13:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:13:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:13:26 --> URI Class Initialized
INFO - 2018-04-23 13:13:26 --> Router Class Initialized
INFO - 2018-04-23 13:13:26 --> Output Class Initialized
INFO - 2018-04-23 13:13:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:13:26 --> Input Class Initialized
INFO - 2018-04-23 13:13:26 --> Language Class Initialized
ERROR - 2018-04-23 13:13:26 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
INFO - 2018-04-23 13:14:46 --> Loader Class Initialized
INFO - 2018-04-23 13:14:46 --> Helper loaded: common_helper
INFO - 2018-04-23 13:14:46 --> Database Driver Class Initialized
INFO - 2018-04-23 13:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:14:46 --> Email Class Initialized
INFO - 2018-04-23 13:14:46 --> Controller Class Initialized
INFO - 2018-04-23 13:14:46 --> Helper loaded: form_helper
INFO - 2018-04-23 13:14:46 --> Form Validation Class Initialized
INFO - 2018-04-23 13:14:46 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:14:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:14:46 --> Helper loaded: url_helper
INFO - 2018-04-23 13:14:46 --> Model Class Initialized
INFO - 2018-04-23 13:14:46 --> Model Class Initialized
INFO - 2018-04-23 13:14:46 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:14:46 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:14:46 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:14:46 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 13:14:46 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:14:46 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:14:46 --> Final output sent to browser
DEBUG - 2018-04-23 13:14:46 --> Total execution time: 0.0019
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
ERROR - 2018-04-23 13:14:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
ERROR - 2018-04-23 13:14:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
ERROR - 2018-04-23 13:14:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
ERROR - 2018-04-23 13:14:46 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
ERROR - 2018-04-23 13:14:46 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:14:46 --> Config Class Initialized
INFO - 2018-04-23 13:14:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:14:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:14:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:14:46 --> URI Class Initialized
INFO - 2018-04-23 13:14:46 --> Router Class Initialized
INFO - 2018-04-23 13:14:46 --> Output Class Initialized
INFO - 2018-04-23 13:14:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:14:46 --> Input Class Initialized
INFO - 2018-04-23 13:14:46 --> Language Class Initialized
ERROR - 2018-04-23 13:14:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:16 --> Config Class Initialized
INFO - 2018-04-23 13:15:16 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:16 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:16 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:16 --> URI Class Initialized
INFO - 2018-04-23 13:15:16 --> Router Class Initialized
INFO - 2018-04-23 13:15:16 --> Output Class Initialized
INFO - 2018-04-23 13:15:16 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:16 --> Input Class Initialized
INFO - 2018-04-23 13:15:16 --> Language Class Initialized
INFO - 2018-04-23 13:15:16 --> Loader Class Initialized
INFO - 2018-04-23 13:15:16 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:16 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:16 --> Email Class Initialized
INFO - 2018-04-23 13:15:16 --> Controller Class Initialized
INFO - 2018-04-23 13:15:16 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:16 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:16 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:16 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:16 --> Model Class Initialized
INFO - 2018-04-23 13:15:16 --> Model Class Initialized
INFO - 2018-04-23 13:15:16 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:15:16 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:15:16 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:16 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 13:15:16 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:15:16 --> Final output sent to browser
DEBUG - 2018-04-23 13:15:16 --> Total execution time: 0.0026
INFO - 2018-04-23 13:15:17 --> Config Class Initialized
INFO - 2018-04-23 13:15:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:17 --> URI Class Initialized
INFO - 2018-04-23 13:15:17 --> Router Class Initialized
INFO - 2018-04-23 13:15:17 --> Output Class Initialized
INFO - 2018-04-23 13:15:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:17 --> Input Class Initialized
INFO - 2018-04-23 13:15:17 --> Language Class Initialized
INFO - 2018-04-23 13:15:17 --> Loader Class Initialized
INFO - 2018-04-23 13:15:17 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:17 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:17 --> Email Class Initialized
INFO - 2018-04-23 13:15:17 --> Controller Class Initialized
INFO - 2018-04-23 13:15:17 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:17 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:17 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:17 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:17 --> Model Class Initialized
INFO - 2018-04-23 13:15:17 --> Model Class Initialized
INFO - 2018-04-23 13:15:17 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:15:17 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:15:17 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:17 --> File loaded: /var/www/html/admin/application/views/foundations/foundation.php
INFO - 2018-04-23 13:15:17 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:15:17 --> Final output sent to browser
DEBUG - 2018-04-23 13:15:17 --> Total execution time: 0.0025
INFO - 2018-04-23 13:15:17 --> Config Class Initialized
INFO - 2018-04-23 13:15:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:17 --> URI Class Initialized
INFO - 2018-04-23 13:15:17 --> Router Class Initialized
INFO - 2018-04-23 13:15:17 --> Output Class Initialized
INFO - 2018-04-23 13:15:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:17 --> Input Class Initialized
INFO - 2018-04-23 13:15:17 --> Language Class Initialized
ERROR - 2018-04-23 13:15:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:17 --> Config Class Initialized
INFO - 2018-04-23 13:15:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:17 --> URI Class Initialized
INFO - 2018-04-23 13:15:17 --> Router Class Initialized
INFO - 2018-04-23 13:15:17 --> Output Class Initialized
INFO - 2018-04-23 13:15:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:17 --> Input Class Initialized
INFO - 2018-04-23 13:15:17 --> Language Class Initialized
ERROR - 2018-04-23 13:15:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:17 --> Config Class Initialized
INFO - 2018-04-23 13:15:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:17 --> URI Class Initialized
INFO - 2018-04-23 13:15:17 --> Router Class Initialized
INFO - 2018-04-23 13:15:17 --> Output Class Initialized
INFO - 2018-04-23 13:15:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:17 --> Input Class Initialized
INFO - 2018-04-23 13:15:17 --> Language Class Initialized
ERROR - 2018-04-23 13:15:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:18 --> Config Class Initialized
INFO - 2018-04-23 13:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:18 --> URI Class Initialized
INFO - 2018-04-23 13:15:18 --> Router Class Initialized
INFO - 2018-04-23 13:15:18 --> Output Class Initialized
INFO - 2018-04-23 13:15:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:18 --> Input Class Initialized
INFO - 2018-04-23 13:15:18 --> Language Class Initialized
ERROR - 2018-04-23 13:15:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:18 --> Config Class Initialized
INFO - 2018-04-23 13:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:18 --> URI Class Initialized
INFO - 2018-04-23 13:15:18 --> Router Class Initialized
INFO - 2018-04-23 13:15:18 --> Output Class Initialized
INFO - 2018-04-23 13:15:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:18 --> Input Class Initialized
INFO - 2018-04-23 13:15:18 --> Language Class Initialized
ERROR - 2018-04-23 13:15:18 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:18 --> Config Class Initialized
INFO - 2018-04-23 13:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:18 --> URI Class Initialized
INFO - 2018-04-23 13:15:18 --> Router Class Initialized
INFO - 2018-04-23 13:15:18 --> Output Class Initialized
INFO - 2018-04-23 13:15:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:18 --> Input Class Initialized
INFO - 2018-04-23 13:15:18 --> Language Class Initialized
ERROR - 2018-04-23 13:15:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:18 --> Config Class Initialized
INFO - 2018-04-23 13:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:18 --> URI Class Initialized
INFO - 2018-04-23 13:15:18 --> Router Class Initialized
INFO - 2018-04-23 13:15:18 --> Output Class Initialized
INFO - 2018-04-23 13:15:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:18 --> Input Class Initialized
INFO - 2018-04-23 13:15:18 --> Language Class Initialized
ERROR - 2018-04-23 13:15:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:18 --> Config Class Initialized
INFO - 2018-04-23 13:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:18 --> URI Class Initialized
INFO - 2018-04-23 13:15:18 --> Router Class Initialized
INFO - 2018-04-23 13:15:18 --> Output Class Initialized
INFO - 2018-04-23 13:15:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:18 --> Input Class Initialized
INFO - 2018-04-23 13:15:18 --> Language Class Initialized
ERROR - 2018-04-23 13:15:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:18 --> Config Class Initialized
INFO - 2018-04-23 13:15:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:18 --> URI Class Initialized
INFO - 2018-04-23 13:15:18 --> Router Class Initialized
INFO - 2018-04-23 13:15:18 --> Output Class Initialized
INFO - 2018-04-23 13:15:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:18 --> Input Class Initialized
INFO - 2018-04-23 13:15:18 --> Language Class Initialized
ERROR - 2018-04-23 13:15:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:19 --> Config Class Initialized
INFO - 2018-04-23 13:15:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:19 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:19 --> URI Class Initialized
INFO - 2018-04-23 13:15:19 --> Router Class Initialized
INFO - 2018-04-23 13:15:19 --> Output Class Initialized
INFO - 2018-04-23 13:15:19 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:19 --> Input Class Initialized
INFO - 2018-04-23 13:15:19 --> Language Class Initialized
ERROR - 2018-04-23 13:15:19 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:19 --> Config Class Initialized
INFO - 2018-04-23 13:15:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:19 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:19 --> URI Class Initialized
INFO - 2018-04-23 13:15:19 --> Router Class Initialized
INFO - 2018-04-23 13:15:19 --> Output Class Initialized
INFO - 2018-04-23 13:15:19 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:19 --> Input Class Initialized
INFO - 2018-04-23 13:15:19 --> Language Class Initialized
ERROR - 2018-04-23 13:15:19 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:19 --> Config Class Initialized
INFO - 2018-04-23 13:15:19 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:19 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:19 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:19 --> URI Class Initialized
INFO - 2018-04-23 13:15:19 --> Router Class Initialized
INFO - 2018-04-23 13:15:19 --> Output Class Initialized
INFO - 2018-04-23 13:15:19 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:19 --> Input Class Initialized
INFO - 2018-04-23 13:15:19 --> Language Class Initialized
ERROR - 2018-04-23 13:15:19 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:20 --> Config Class Initialized
INFO - 2018-04-23 13:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:20 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:20 --> URI Class Initialized
INFO - 2018-04-23 13:15:20 --> Router Class Initialized
INFO - 2018-04-23 13:15:20 --> Output Class Initialized
INFO - 2018-04-23 13:15:20 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:20 --> Input Class Initialized
INFO - 2018-04-23 13:15:20 --> Language Class Initialized
INFO - 2018-04-23 13:15:20 --> Loader Class Initialized
INFO - 2018-04-23 13:15:20 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:20 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:20 --> Email Class Initialized
INFO - 2018-04-23 13:15:20 --> Controller Class Initialized
INFO - 2018-04-23 13:15:20 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:20 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:20 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:20 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:20 --> Model Class Initialized
INFO - 2018-04-23 13:15:20 --> Model Class Initialized
INFO - 2018-04-23 13:15:20 --> Model Class Initialized
INFO - 2018-04-23 18:45:20 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 18:45:20 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 18:45:20 --> File loaded: /var/www/html/admin/application/views/Celebrity/celebrityPage.php
INFO - 2018-04-23 18:45:20 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 18:45:20 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 18:45:20 --> Final output sent to browser
DEBUG - 2018-04-23 18:45:20 --> Total execution time: 0.0026
INFO - 2018-04-23 13:15:20 --> Config Class Initialized
INFO - 2018-04-23 13:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:20 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:20 --> URI Class Initialized
INFO - 2018-04-23 13:15:20 --> Router Class Initialized
INFO - 2018-04-23 13:15:20 --> Output Class Initialized
INFO - 2018-04-23 13:15:20 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:20 --> Input Class Initialized
INFO - 2018-04-23 13:15:20 --> Language Class Initialized
ERROR - 2018-04-23 13:15:20 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:20 --> Config Class Initialized
INFO - 2018-04-23 13:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:20 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:20 --> URI Class Initialized
INFO - 2018-04-23 13:15:20 --> Router Class Initialized
INFO - 2018-04-23 13:15:20 --> Output Class Initialized
INFO - 2018-04-23 13:15:20 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:20 --> Config Class Initialized
INFO - 2018-04-23 13:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:20 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:20 --> URI Class Initialized
INFO - 2018-04-23 13:15:20 --> Router Class Initialized
INFO - 2018-04-23 13:15:20 --> Output Class Initialized
INFO - 2018-04-23 13:15:20 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:20 --> Input Class Initialized
INFO - 2018-04-23 13:15:20 --> Language Class Initialized
ERROR - 2018-04-23 13:15:20 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:20 --> Input Class Initialized
INFO - 2018-04-23 13:15:20 --> Language Class Initialized
ERROR - 2018-04-23 13:15:20 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:20 --> Config Class Initialized
INFO - 2018-04-23 13:15:20 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:20 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:20 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:20 --> URI Class Initialized
INFO - 2018-04-23 13:15:20 --> Router Class Initialized
INFO - 2018-04-23 13:15:20 --> Output Class Initialized
INFO - 2018-04-23 13:15:20 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:20 --> Input Class Initialized
INFO - 2018-04-23 13:15:20 --> Language Class Initialized
ERROR - 2018-04-23 13:15:20 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
INFO - 2018-04-23 13:15:22 --> Loader Class Initialized
INFO - 2018-04-23 13:15:22 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:22 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:22 --> Email Class Initialized
INFO - 2018-04-23 13:15:22 --> Controller Class Initialized
INFO - 2018-04-23 13:15:22 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:22 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:22 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:22 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:22 --> Model Class Initialized
INFO - 2018-04-23 13:15:22 --> Model Class Initialized
INFO - 2018-04-23 13:15:22 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:15:22 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:15:22 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:22 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:15:22 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:15:22 --> Final output sent to browser
DEBUG - 2018-04-23 13:15:22 --> Total execution time: 0.0026
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/select2
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:22 --> Config Class Initialized
INFO - 2018-04-23 13:15:22 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:22 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:22 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:22 --> URI Class Initialized
INFO - 2018-04-23 13:15:22 --> Router Class Initialized
INFO - 2018-04-23 13:15:22 --> Output Class Initialized
INFO - 2018-04-23 13:15:22 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:22 --> Input Class Initialized
INFO - 2018-04-23 13:15:22 --> Language Class Initialized
ERROR - 2018-04-23 13:15:22 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
INFO - 2018-04-23 13:15:23 --> Loader Class Initialized
INFO - 2018-04-23 13:15:23 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:23 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:23 --> Email Class Initialized
INFO - 2018-04-23 13:15:23 --> Controller Class Initialized
INFO - 2018-04-23 13:15:23 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:23 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:23 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:23 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:23 --> Model Class Initialized
INFO - 2018-04-23 13:15:23 --> Model Class Initialized
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
INFO - 2018-04-23 13:15:23 --> Loader Class Initialized
INFO - 2018-04-23 13:15:23 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:23 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:23 --> Email Class Initialized
INFO - 2018-04-23 13:15:23 --> Controller Class Initialized
INFO - 2018-04-23 13:15:23 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:23 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:23 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:23 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:23 --> Model Class Initialized
INFO - 2018-04-23 13:15:23 --> Model Class Initialized
INFO - 2018-04-23 13:15:23 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:15:23 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:15:23 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:23 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 13:15:23 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:23 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:15:23 --> Final output sent to browser
DEBUG - 2018-04-23 13:15:23 --> Total execution time: 0.0016
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:23 --> Config Class Initialized
INFO - 2018-04-23 13:15:23 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:23 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:23 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:23 --> URI Class Initialized
INFO - 2018-04-23 13:15:23 --> Router Class Initialized
INFO - 2018-04-23 13:15:23 --> Output Class Initialized
INFO - 2018-04-23 13:15:23 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:23 --> Input Class Initialized
INFO - 2018-04-23 13:15:23 --> Language Class Initialized
ERROR - 2018-04-23 13:15:23 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:25 --> Config Class Initialized
INFO - 2018-04-23 13:15:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:25 --> URI Class Initialized
INFO - 2018-04-23 13:15:25 --> Router Class Initialized
INFO - 2018-04-23 13:15:25 --> Output Class Initialized
INFO - 2018-04-23 13:15:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:25 --> Input Class Initialized
INFO - 2018-04-23 13:15:25 --> Language Class Initialized
INFO - 2018-04-23 13:15:25 --> Loader Class Initialized
INFO - 2018-04-23 13:15:25 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:25 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:25 --> Email Class Initialized
INFO - 2018-04-23 13:15:25 --> Controller Class Initialized
INFO - 2018-04-23 13:15:25 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:25 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:25 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:25 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:25 --> Model Class Initialized
INFO - 2018-04-23 13:15:25 --> Model Class Initialized
INFO - 2018-04-23 13:15:25 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:15:25 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:15:25 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:25 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:15:25 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:15:25 --> Final output sent to browser
DEBUG - 2018-04-23 13:15:25 --> Total execution time: 0.0025
INFO - 2018-04-23 13:15:25 --> Config Class Initialized
INFO - 2018-04-23 13:15:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:25 --> URI Class Initialized
INFO - 2018-04-23 13:15:25 --> Router Class Initialized
INFO - 2018-04-23 13:15:25 --> Output Class Initialized
INFO - 2018-04-23 13:15:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:25 --> Input Class Initialized
INFO - 2018-04-23 13:15:25 --> Language Class Initialized
ERROR - 2018-04-23 13:15:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:29 --> Config Class Initialized
INFO - 2018-04-23 13:15:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:29 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:29 --> URI Class Initialized
INFO - 2018-04-23 13:15:29 --> Router Class Initialized
INFO - 2018-04-23 13:15:29 --> Output Class Initialized
INFO - 2018-04-23 13:15:29 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:29 --> Input Class Initialized
INFO - 2018-04-23 13:15:29 --> Language Class Initialized
ERROR - 2018-04-23 13:15:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:29 --> Config Class Initialized
INFO - 2018-04-23 13:15:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:29 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:29 --> URI Class Initialized
INFO - 2018-04-23 13:15:29 --> Router Class Initialized
INFO - 2018-04-23 13:15:29 --> Output Class Initialized
INFO - 2018-04-23 13:15:29 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:29 --> Input Class Initialized
INFO - 2018-04-23 13:15:29 --> Language Class Initialized
ERROR - 2018-04-23 13:15:29 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:29 --> Config Class Initialized
INFO - 2018-04-23 13:15:29 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:29 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:29 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:29 --> URI Class Initialized
INFO - 2018-04-23 13:15:29 --> Router Class Initialized
INFO - 2018-04-23 13:15:29 --> Output Class Initialized
INFO - 2018-04-23 13:15:29 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:29 --> Input Class Initialized
INFO - 2018-04-23 13:15:29 --> Language Class Initialized
ERROR - 2018-04-23 13:15:29 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
INFO - 2018-04-23 13:15:32 --> Loader Class Initialized
INFO - 2018-04-23 13:15:32 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:32 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:32 --> Email Class Initialized
INFO - 2018-04-23 13:15:32 --> Controller Class Initialized
INFO - 2018-04-23 13:15:32 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:32 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:32 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:32 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:32 --> Model Class Initialized
INFO - 2018-04-23 13:15:32 --> Model Class Initialized
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
INFO - 2018-04-23 13:15:32 --> Loader Class Initialized
INFO - 2018-04-23 13:15:32 --> Helper loaded: common_helper
INFO - 2018-04-23 13:15:32 --> Database Driver Class Initialized
INFO - 2018-04-23 13:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:15:32 --> Email Class Initialized
INFO - 2018-04-23 13:15:32 --> Controller Class Initialized
INFO - 2018-04-23 13:15:32 --> Helper loaded: form_helper
INFO - 2018-04-23 13:15:32 --> Form Validation Class Initialized
INFO - 2018-04-23 13:15:32 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:15:32 --> Helper loaded: url_helper
INFO - 2018-04-23 13:15:32 --> Model Class Initialized
INFO - 2018-04-23 13:15:32 --> Model Class Initialized
INFO - 2018-04-23 13:15:32 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:15:32 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:15:32 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:32 --> File loaded: /var/www/html/admin/application/views/foundations/addFoundation.php
INFO - 2018-04-23 13:15:32 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:15:32 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:15:32 --> Final output sent to browser
DEBUG - 2018-04-23 13:15:32 --> Total execution time: 0.0016
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:15:32 --> Config Class Initialized
INFO - 2018-04-23 13:15:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:15:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:15:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:15:32 --> URI Class Initialized
INFO - 2018-04-23 13:15:32 --> Router Class Initialized
INFO - 2018-04-23 13:15:32 --> Output Class Initialized
INFO - 2018-04-23 13:15:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:15:32 --> Input Class Initialized
INFO - 2018-04-23 13:15:32 --> Language Class Initialized
ERROR - 2018-04-23 13:15:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:16:08 --> Config Class Initialized
INFO - 2018-04-23 13:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:16:08 --> Utf8 Class Initialized
INFO - 2018-04-23 13:16:08 --> URI Class Initialized
INFO - 2018-04-23 13:16:08 --> Router Class Initialized
INFO - 2018-04-23 13:16:08 --> Output Class Initialized
INFO - 2018-04-23 13:16:08 --> Security Class Initialized
DEBUG - 2018-04-23 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:16:08 --> Input Class Initialized
INFO - 2018-04-23 13:16:08 --> Language Class Initialized
INFO - 2018-04-23 13:16:08 --> Loader Class Initialized
INFO - 2018-04-23 13:16:08 --> Helper loaded: common_helper
INFO - 2018-04-23 13:16:08 --> Database Driver Class Initialized
INFO - 2018-04-23 13:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:16:08 --> Email Class Initialized
INFO - 2018-04-23 13:16:08 --> Controller Class Initialized
INFO - 2018-04-23 13:16:08 --> Helper loaded: form_helper
INFO - 2018-04-23 13:16:08 --> Form Validation Class Initialized
INFO - 2018-04-23 13:16:08 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:16:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:16:08 --> Helper loaded: url_helper
INFO - 2018-04-23 13:16:08 --> Model Class Initialized
INFO - 2018-04-23 13:16:08 --> Model Class Initialized
INFO - 2018-04-23 13:16:08 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:16:08 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:16:08 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:16:08 --> File loaded: /var/www/html/admin/application/views/adds/adds.php
INFO - 2018-04-23 13:16:08 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:16:08 --> Final output sent to browser
DEBUG - 2018-04-23 13:16:08 --> Total execution time: 0.0032
INFO - 2018-04-23 13:16:08 --> Config Class Initialized
INFO - 2018-04-23 13:16:08 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:16:08 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:16:08 --> Utf8 Class Initialized
INFO - 2018-04-23 13:16:08 --> URI Class Initialized
INFO - 2018-04-23 13:16:08 --> Router Class Initialized
INFO - 2018-04-23 13:16:08 --> Output Class Initialized
INFO - 2018-04-23 13:16:08 --> Security Class Initialized
DEBUG - 2018-04-23 13:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:16:08 --> Input Class Initialized
INFO - 2018-04-23 13:16:08 --> Language Class Initialized
ERROR - 2018-04-23 13:16:08 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:16:09 --> Config Class Initialized
INFO - 2018-04-23 13:16:09 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:16:09 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:16:09 --> Utf8 Class Initialized
INFO - 2018-04-23 13:16:09 --> URI Class Initialized
INFO - 2018-04-23 13:16:09 --> Router Class Initialized
INFO - 2018-04-23 13:16:09 --> Output Class Initialized
INFO - 2018-04-23 13:16:09 --> Security Class Initialized
DEBUG - 2018-04-23 13:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:16:09 --> Input Class Initialized
INFO - 2018-04-23 13:16:09 --> Language Class Initialized
INFO - 2018-04-23 13:16:09 --> Loader Class Initialized
INFO - 2018-04-23 13:16:09 --> Helper loaded: common_helper
INFO - 2018-04-23 13:16:09 --> Database Driver Class Initialized
INFO - 2018-04-23 13:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:16:09 --> Email Class Initialized
INFO - 2018-04-23 13:16:09 --> Controller Class Initialized
INFO - 2018-04-23 13:16:09 --> Helper loaded: form_helper
INFO - 2018-04-23 13:16:09 --> Form Validation Class Initialized
INFO - 2018-04-23 13:16:09 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:16:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:16:09 --> Helper loaded: url_helper
INFO - 2018-04-23 13:16:09 --> Model Class Initialized
INFO - 2018-04-23 13:16:09 --> Model Class Initialized
INFO - 2018-04-23 13:17:24 --> Config Class Initialized
INFO - 2018-04-23 13:17:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:17:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:17:24 --> Utf8 Class Initialized
INFO - 2018-04-23 13:17:24 --> URI Class Initialized
INFO - 2018-04-23 13:17:24 --> Router Class Initialized
INFO - 2018-04-23 13:17:24 --> Output Class Initialized
INFO - 2018-04-23 13:17:24 --> Security Class Initialized
DEBUG - 2018-04-23 13:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:17:24 --> Input Class Initialized
INFO - 2018-04-23 13:17:24 --> Language Class Initialized
INFO - 2018-04-23 13:17:24 --> Loader Class Initialized
INFO - 2018-04-23 13:17:24 --> Helper loaded: common_helper
INFO - 2018-04-23 13:17:24 --> Database Driver Class Initialized
INFO - 2018-04-23 13:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:17:24 --> Email Class Initialized
INFO - 2018-04-23 13:17:24 --> Controller Class Initialized
INFO - 2018-04-23 13:17:24 --> Helper loaded: form_helper
INFO - 2018-04-23 13:17:24 --> Form Validation Class Initialized
INFO - 2018-04-23 13:17:24 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:17:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:17:24 --> Helper loaded: url_helper
INFO - 2018-04-23 13:17:24 --> Model Class Initialized
INFO - 2018-04-23 13:17:24 --> Model Class Initialized
INFO - 2018-04-23 13:17:26 --> Config Class Initialized
INFO - 2018-04-23 13:17:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:17:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:17:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:17:26 --> URI Class Initialized
INFO - 2018-04-23 13:17:26 --> Router Class Initialized
INFO - 2018-04-23 13:17:26 --> Output Class Initialized
INFO - 2018-04-23 13:17:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:17:26 --> Input Class Initialized
INFO - 2018-04-23 13:17:26 --> Language Class Initialized
INFO - 2018-04-23 13:17:26 --> Loader Class Initialized
INFO - 2018-04-23 13:17:26 --> Helper loaded: common_helper
INFO - 2018-04-23 13:17:26 --> Database Driver Class Initialized
INFO - 2018-04-23 13:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:17:26 --> Email Class Initialized
INFO - 2018-04-23 13:17:26 --> Controller Class Initialized
INFO - 2018-04-23 13:17:26 --> Helper loaded: form_helper
INFO - 2018-04-23 13:17:26 --> Form Validation Class Initialized
INFO - 2018-04-23 13:17:26 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:17:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:17:26 --> Helper loaded: url_helper
INFO - 2018-04-23 13:17:26 --> Model Class Initialized
INFO - 2018-04-23 13:17:26 --> Model Class Initialized
INFO - 2018-04-23 13:17:35 --> Config Class Initialized
INFO - 2018-04-23 13:17:35 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:17:35 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:17:35 --> Utf8 Class Initialized
INFO - 2018-04-23 13:17:35 --> URI Class Initialized
INFO - 2018-04-23 13:17:35 --> Router Class Initialized
INFO - 2018-04-23 13:17:35 --> Output Class Initialized
INFO - 2018-04-23 13:17:35 --> Security Class Initialized
DEBUG - 2018-04-23 13:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:17:35 --> Input Class Initialized
INFO - 2018-04-23 13:17:35 --> Language Class Initialized
INFO - 2018-04-23 13:17:35 --> Loader Class Initialized
INFO - 2018-04-23 13:17:35 --> Helper loaded: common_helper
INFO - 2018-04-23 13:17:35 --> Database Driver Class Initialized
INFO - 2018-04-23 13:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:17:35 --> Email Class Initialized
INFO - 2018-04-23 13:17:35 --> Controller Class Initialized
INFO - 2018-04-23 13:17:35 --> Helper loaded: form_helper
INFO - 2018-04-23 13:17:35 --> Form Validation Class Initialized
INFO - 2018-04-23 13:17:35 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:17:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:17:35 --> Helper loaded: url_helper
INFO - 2018-04-23 13:17:35 --> Model Class Initialized
INFO - 2018-04-23 13:17:35 --> Model Class Initialized
INFO - 2018-04-23 13:17:35 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
INFO - 2018-04-23 13:18:04 --> Loader Class Initialized
INFO - 2018-04-23 13:18:04 --> Helper loaded: common_helper
INFO - 2018-04-23 13:18:04 --> Database Driver Class Initialized
INFO - 2018-04-23 13:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:18:04 --> Email Class Initialized
INFO - 2018-04-23 13:18:04 --> Controller Class Initialized
INFO - 2018-04-23 13:18:04 --> Helper loaded: form_helper
INFO - 2018-04-23 13:18:04 --> Form Validation Class Initialized
INFO - 2018-04-23 13:18:04 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:18:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:18:04 --> Helper loaded: url_helper
INFO - 2018-04-23 13:18:04 --> Model Class Initialized
INFO - 2018-04-23 13:18:04 --> Model Class Initialized
INFO - 2018-04-23 13:18:04 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:18:04 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:18:04 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:18:04 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:18:04 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:18:04 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:18:04 --> Final output sent to browser
DEBUG - 2018-04-23 13:18:04 --> Total execution time: 0.0025
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:18:04 --> Config Class Initialized
INFO - 2018-04-23 13:18:04 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:04 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:04 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:04 --> URI Class Initialized
INFO - 2018-04-23 13:18:04 --> Router Class Initialized
INFO - 2018-04-23 13:18:04 --> Output Class Initialized
INFO - 2018-04-23 13:18:04 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:04 --> Input Class Initialized
INFO - 2018-04-23 13:18:04 --> Language Class Initialized
ERROR - 2018-04-23 13:18:04 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:18:05 --> Config Class Initialized
INFO - 2018-04-23 13:18:05 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:05 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:05 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:05 --> URI Class Initialized
INFO - 2018-04-23 13:18:05 --> Router Class Initialized
INFO - 2018-04-23 13:18:05 --> Output Class Initialized
INFO - 2018-04-23 13:18:05 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:05 --> Input Class Initialized
INFO - 2018-04-23 13:18:05 --> Language Class Initialized
ERROR - 2018-04-23 13:18:05 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:18:05 --> Config Class Initialized
INFO - 2018-04-23 13:18:05 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:18:05 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:18:05 --> Utf8 Class Initialized
INFO - 2018-04-23 13:18:05 --> URI Class Initialized
INFO - 2018-04-23 13:18:05 --> Router Class Initialized
INFO - 2018-04-23 13:18:05 --> Output Class Initialized
INFO - 2018-04-23 13:18:05 --> Security Class Initialized
DEBUG - 2018-04-23 13:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:18:05 --> Input Class Initialized
INFO - 2018-04-23 13:18:05 --> Language Class Initialized
ERROR - 2018-04-23 13:18:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
INFO - 2018-04-23 13:22:17 --> Loader Class Initialized
INFO - 2018-04-23 13:22:17 --> Helper loaded: common_helper
INFO - 2018-04-23 13:22:17 --> Database Driver Class Initialized
INFO - 2018-04-23 13:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:22:17 --> Email Class Initialized
INFO - 2018-04-23 13:22:17 --> Controller Class Initialized
INFO - 2018-04-23 13:22:17 --> Helper loaded: form_helper
INFO - 2018-04-23 13:22:17 --> Form Validation Class Initialized
INFO - 2018-04-23 13:22:17 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:22:17 --> Helper loaded: url_helper
INFO - 2018-04-23 13:22:17 --> Model Class Initialized
INFO - 2018-04-23 13:22:17 --> Model Class Initialized
INFO - 2018-04-23 13:22:17 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:22:17 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:22:17 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:22:17 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:22:17 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:22:17 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:22:17 --> Final output sent to browser
DEBUG - 2018-04-23 13:22:17 --> Total execution time: 0.0034
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
ERROR - 2018-04-23 13:22:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
ERROR - 2018-04-23 13:22:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
ERROR - 2018-04-23 13:22:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
ERROR - 2018-04-23 13:22:17 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
ERROR - 2018-04-23 13:22:17 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:22:17 --> Config Class Initialized
INFO - 2018-04-23 13:22:17 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:17 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:17 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:17 --> URI Class Initialized
INFO - 2018-04-23 13:22:17 --> Router Class Initialized
INFO - 2018-04-23 13:22:17 --> Output Class Initialized
INFO - 2018-04-23 13:22:17 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:17 --> Input Class Initialized
INFO - 2018-04-23 13:22:17 --> Language Class Initialized
ERROR - 2018-04-23 13:22:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:18 --> Config Class Initialized
INFO - 2018-04-23 13:22:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:18 --> URI Class Initialized
INFO - 2018-04-23 13:22:18 --> Router Class Initialized
INFO - 2018-04-23 13:22:18 --> Output Class Initialized
INFO - 2018-04-23 13:22:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:18 --> Input Class Initialized
INFO - 2018-04-23 13:22:18 --> Language Class Initialized
ERROR - 2018-04-23 13:22:18 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:18 --> Config Class Initialized
INFO - 2018-04-23 13:22:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:18 --> URI Class Initialized
INFO - 2018-04-23 13:22:18 --> Router Class Initialized
INFO - 2018-04-23 13:22:18 --> Output Class Initialized
INFO - 2018-04-23 13:22:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:18 --> Input Class Initialized
INFO - 2018-04-23 13:22:18 --> Language Class Initialized
ERROR - 2018-04-23 13:22:18 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:22:18 --> Config Class Initialized
INFO - 2018-04-23 13:22:18 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:18 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:18 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:18 --> URI Class Initialized
INFO - 2018-04-23 13:22:18 --> Router Class Initialized
INFO - 2018-04-23 13:22:18 --> Output Class Initialized
INFO - 2018-04-23 13:22:18 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:18 --> Input Class Initialized
INFO - 2018-04-23 13:22:18 --> Language Class Initialized
ERROR - 2018-04-23 13:22:18 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
INFO - 2018-04-23 13:22:40 --> Loader Class Initialized
INFO - 2018-04-23 13:22:40 --> Helper loaded: common_helper
INFO - 2018-04-23 13:22:40 --> Database Driver Class Initialized
INFO - 2018-04-23 13:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:22:40 --> Email Class Initialized
INFO - 2018-04-23 13:22:40 --> Controller Class Initialized
INFO - 2018-04-23 13:22:40 --> Helper loaded: form_helper
INFO - 2018-04-23 13:22:40 --> Form Validation Class Initialized
INFO - 2018-04-23 13:22:40 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:22:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:22:40 --> Helper loaded: url_helper
INFO - 2018-04-23 13:22:40 --> Model Class Initialized
INFO - 2018-04-23 13:22:40 --> Model Class Initialized
INFO - 2018-04-23 13:22:40 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:22:40 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:22:40 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:22:40 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:22:40 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:22:40 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:22:40 --> Final output sent to browser
DEBUG - 2018-04-23 13:22:40 --> Total execution time: 0.0021
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:22:40 --> Config Class Initialized
INFO - 2018-04-23 13:22:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:40 --> URI Class Initialized
INFO - 2018-04-23 13:22:40 --> Router Class Initialized
INFO - 2018-04-23 13:22:40 --> Output Class Initialized
INFO - 2018-04-23 13:22:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:40 --> Input Class Initialized
INFO - 2018-04-23 13:22:40 --> Language Class Initialized
ERROR - 2018-04-23 13:22:40 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:54 --> Config Class Initialized
INFO - 2018-04-23 13:22:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:54 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:54 --> URI Class Initialized
INFO - 2018-04-23 13:22:54 --> Router Class Initialized
INFO - 2018-04-23 13:22:54 --> Output Class Initialized
INFO - 2018-04-23 13:22:54 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:54 --> Input Class Initialized
INFO - 2018-04-23 13:22:54 --> Language Class Initialized
INFO - 2018-04-23 13:22:54 --> Loader Class Initialized
INFO - 2018-04-23 13:22:54 --> Helper loaded: common_helper
INFO - 2018-04-23 13:22:54 --> Database Driver Class Initialized
INFO - 2018-04-23 13:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:22:54 --> Email Class Initialized
INFO - 2018-04-23 13:22:54 --> Controller Class Initialized
INFO - 2018-04-23 13:22:54 --> Helper loaded: form_helper
INFO - 2018-04-23 13:22:54 --> Form Validation Class Initialized
INFO - 2018-04-23 13:22:54 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:22:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:22:54 --> Helper loaded: url_helper
INFO - 2018-04-23 13:22:54 --> Model Class Initialized
INFO - 2018-04-23 13:22:54 --> Model Class Initialized
INFO - 2018-04-23 13:22:54 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:22:54 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:22:54 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:22:54 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:22:54 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:22:54 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:22:54 --> Final output sent to browser
DEBUG - 2018-04-23 13:22:54 --> Total execution time: 0.0021
INFO - 2018-04-23 13:22:54 --> Config Class Initialized
INFO - 2018-04-23 13:22:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:54 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:54 --> URI Class Initialized
INFO - 2018-04-23 13:22:54 --> Router Class Initialized
INFO - 2018-04-23 13:22:54 --> Output Class Initialized
INFO - 2018-04-23 13:22:54 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:54 --> Input Class Initialized
INFO - 2018-04-23 13:22:54 --> Language Class Initialized
ERROR - 2018-04-23 13:22:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:54 --> Config Class Initialized
INFO - 2018-04-23 13:22:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:54 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:54 --> URI Class Initialized
INFO - 2018-04-23 13:22:54 --> Router Class Initialized
INFO - 2018-04-23 13:22:54 --> Output Class Initialized
INFO - 2018-04-23 13:22:54 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:54 --> Input Class Initialized
INFO - 2018-04-23 13:22:54 --> Language Class Initialized
ERROR - 2018-04-23 13:22:54 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:54 --> Config Class Initialized
INFO - 2018-04-23 13:22:54 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:54 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:54 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:54 --> URI Class Initialized
INFO - 2018-04-23 13:22:54 --> Router Class Initialized
INFO - 2018-04-23 13:22:54 --> Output Class Initialized
INFO - 2018-04-23 13:22:54 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:54 --> Input Class Initialized
INFO - 2018-04-23 13:22:54 --> Language Class Initialized
ERROR - 2018-04-23 13:22:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:22:55 --> Config Class Initialized
INFO - 2018-04-23 13:22:55 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:22:55 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:22:55 --> Utf8 Class Initialized
INFO - 2018-04-23 13:22:55 --> URI Class Initialized
INFO - 2018-04-23 13:22:55 --> Router Class Initialized
INFO - 2018-04-23 13:22:55 --> Output Class Initialized
INFO - 2018-04-23 13:22:55 --> Security Class Initialized
DEBUG - 2018-04-23 13:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:22:55 --> Input Class Initialized
INFO - 2018-04-23 13:22:55 --> Language Class Initialized
ERROR - 2018-04-23 13:22:55 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
INFO - 2018-04-23 13:23:15 --> Loader Class Initialized
INFO - 2018-04-23 13:23:15 --> Helper loaded: common_helper
INFO - 2018-04-23 13:23:15 --> Database Driver Class Initialized
INFO - 2018-04-23 13:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:23:15 --> Email Class Initialized
INFO - 2018-04-23 13:23:15 --> Controller Class Initialized
INFO - 2018-04-23 13:23:15 --> Helper loaded: form_helper
INFO - 2018-04-23 13:23:15 --> Form Validation Class Initialized
INFO - 2018-04-23 13:23:15 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:23:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:23:15 --> Helper loaded: url_helper
INFO - 2018-04-23 13:23:15 --> Model Class Initialized
INFO - 2018-04-23 13:23:15 --> Model Class Initialized
INFO - 2018-04-23 13:23:15 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:23:15 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:23:15 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:23:15 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:23:15 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:23:15 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:23:15 --> Final output sent to browser
DEBUG - 2018-04-23 13:23:15 --> Total execution time: 0.0023
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:23:15 --> Config Class Initialized
INFO - 2018-04-23 13:23:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:15 --> URI Class Initialized
INFO - 2018-04-23 13:23:15 --> Router Class Initialized
INFO - 2018-04-23 13:23:15 --> Output Class Initialized
INFO - 2018-04-23 13:23:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:15 --> Input Class Initialized
INFO - 2018-04-23 13:23:15 --> Language Class Initialized
ERROR - 2018-04-23 13:23:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:37 --> Config Class Initialized
INFO - 2018-04-23 13:23:37 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:37 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:37 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:37 --> URI Class Initialized
INFO - 2018-04-23 13:23:37 --> Router Class Initialized
INFO - 2018-04-23 13:23:37 --> Output Class Initialized
INFO - 2018-04-23 13:23:37 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:37 --> Input Class Initialized
INFO - 2018-04-23 13:23:37 --> Language Class Initialized
INFO - 2018-04-23 13:23:37 --> Loader Class Initialized
INFO - 2018-04-23 13:23:37 --> Helper loaded: common_helper
INFO - 2018-04-23 13:23:37 --> Database Driver Class Initialized
INFO - 2018-04-23 13:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:23:37 --> Email Class Initialized
INFO - 2018-04-23 13:23:37 --> Controller Class Initialized
INFO - 2018-04-23 13:23:37 --> Helper loaded: form_helper
INFO - 2018-04-23 13:23:37 --> Form Validation Class Initialized
INFO - 2018-04-23 13:23:37 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:23:37 --> Helper loaded: url_helper
INFO - 2018-04-23 13:23:37 --> Model Class Initialized
INFO - 2018-04-23 13:23:37 --> Model Class Initialized
INFO - 2018-04-23 13:23:37 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:23:37 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:23:37 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:23:37 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:23:37 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:23:37 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:23:37 --> Final output sent to browser
DEBUG - 2018-04-23 13:23:37 --> Total execution time: 0.0021
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:38 --> Config Class Initialized
INFO - 2018-04-23 13:23:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:38 --> URI Class Initialized
INFO - 2018-04-23 13:23:38 --> Router Class Initialized
INFO - 2018-04-23 13:23:38 --> Output Class Initialized
INFO - 2018-04-23 13:23:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:38 --> Input Class Initialized
INFO - 2018-04-23 13:23:38 --> Language Class Initialized
ERROR - 2018-04-23 13:23:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
INFO - 2018-04-23 13:23:47 --> Loader Class Initialized
INFO - 2018-04-23 13:23:47 --> Helper loaded: common_helper
INFO - 2018-04-23 13:23:47 --> Database Driver Class Initialized
INFO - 2018-04-23 13:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:23:47 --> Email Class Initialized
INFO - 2018-04-23 13:23:47 --> Controller Class Initialized
INFO - 2018-04-23 13:23:47 --> Helper loaded: form_helper
INFO - 2018-04-23 13:23:47 --> Form Validation Class Initialized
INFO - 2018-04-23 13:23:47 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:23:47 --> Helper loaded: url_helper
INFO - 2018-04-23 13:23:47 --> Model Class Initialized
INFO - 2018-04-23 13:23:47 --> Model Class Initialized
INFO - 2018-04-23 13:23:47 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:23:47 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:23:47 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:23:47 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:23:47 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:23:47 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:23:47 --> Final output sent to browser
DEBUG - 2018-04-23 13:23:47 --> Total execution time: 0.0022
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:23:47 --> Config Class Initialized
INFO - 2018-04-23 13:23:47 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:23:47 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:23:47 --> Utf8 Class Initialized
INFO - 2018-04-23 13:23:47 --> URI Class Initialized
INFO - 2018-04-23 13:23:47 --> Router Class Initialized
INFO - 2018-04-23 13:23:47 --> Output Class Initialized
INFO - 2018-04-23 13:23:47 --> Security Class Initialized
DEBUG - 2018-04-23 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:23:47 --> Input Class Initialized
INFO - 2018-04-23 13:23:47 --> Language Class Initialized
ERROR - 2018-04-23 13:23:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
INFO - 2018-04-23 13:24:25 --> Loader Class Initialized
INFO - 2018-04-23 13:24:25 --> Helper loaded: common_helper
INFO - 2018-04-23 13:24:25 --> Database Driver Class Initialized
INFO - 2018-04-23 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:24:25 --> Email Class Initialized
INFO - 2018-04-23 13:24:25 --> Controller Class Initialized
INFO - 2018-04-23 13:24:25 --> Helper loaded: form_helper
INFO - 2018-04-23 13:24:25 --> Form Validation Class Initialized
INFO - 2018-04-23 13:24:25 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:24:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:24:25 --> Helper loaded: url_helper
INFO - 2018-04-23 13:24:25 --> Model Class Initialized
INFO - 2018-04-23 13:24:25 --> Model Class Initialized
INFO - 2018-04-23 13:24:25 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:24:25 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:24:25 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:24:25 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:24:25 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:24:25 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:24:25 --> Final output sent to browser
DEBUG - 2018-04-23 13:24:25 --> Total execution time: 0.0029
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:24:25 --> Config Class Initialized
INFO - 2018-04-23 13:24:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:25 --> URI Class Initialized
INFO - 2018-04-23 13:24:25 --> Router Class Initialized
INFO - 2018-04-23 13:24:25 --> Output Class Initialized
INFO - 2018-04-23 13:24:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:25 --> Input Class Initialized
INFO - 2018-04-23 13:24:25 --> Language Class Initialized
ERROR - 2018-04-23 13:24:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
INFO - 2018-04-23 13:24:38 --> Loader Class Initialized
INFO - 2018-04-23 13:24:38 --> Helper loaded: common_helper
INFO - 2018-04-23 13:24:38 --> Database Driver Class Initialized
INFO - 2018-04-23 13:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:24:38 --> Email Class Initialized
INFO - 2018-04-23 13:24:38 --> Controller Class Initialized
INFO - 2018-04-23 13:24:38 --> Helper loaded: form_helper
INFO - 2018-04-23 13:24:38 --> Form Validation Class Initialized
INFO - 2018-04-23 13:24:38 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:24:38 --> Helper loaded: url_helper
INFO - 2018-04-23 13:24:38 --> Model Class Initialized
INFO - 2018-04-23 13:24:38 --> Model Class Initialized
INFO - 2018-04-23 13:24:38 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:24:38 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:24:38 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:24:38 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:24:38 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:24:38 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:24:38 --> Final output sent to browser
DEBUG - 2018-04-23 13:24:38 --> Total execution time: 0.0020
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:24:38 --> Config Class Initialized
INFO - 2018-04-23 13:24:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:38 --> URI Class Initialized
INFO - 2018-04-23 13:24:38 --> Router Class Initialized
INFO - 2018-04-23 13:24:38 --> Output Class Initialized
INFO - 2018-04-23 13:24:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:38 --> Input Class Initialized
INFO - 2018-04-23 13:24:38 --> Language Class Initialized
ERROR - 2018-04-23 13:24:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:40 --> Config Class Initialized
INFO - 2018-04-23 13:24:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:40 --> URI Class Initialized
INFO - 2018-04-23 13:24:40 --> Router Class Initialized
INFO - 2018-04-23 13:24:40 --> Output Class Initialized
INFO - 2018-04-23 13:24:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:40 --> Input Class Initialized
INFO - 2018-04-23 13:24:40 --> Language Class Initialized
ERROR - 2018-04-23 13:24:40 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:24:40 --> Config Class Initialized
INFO - 2018-04-23 13:24:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:40 --> URI Class Initialized
INFO - 2018-04-23 13:24:40 --> Router Class Initialized
INFO - 2018-04-23 13:24:40 --> Output Class Initialized
INFO - 2018-04-23 13:24:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:40 --> Input Class Initialized
INFO - 2018-04-23 13:24:40 --> Language Class Initialized
ERROR - 2018-04-23 13:24:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:24:40 --> Config Class Initialized
INFO - 2018-04-23 13:24:40 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:24:40 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:24:40 --> Utf8 Class Initialized
INFO - 2018-04-23 13:24:40 --> URI Class Initialized
INFO - 2018-04-23 13:24:40 --> Router Class Initialized
INFO - 2018-04-23 13:24:40 --> Output Class Initialized
INFO - 2018-04-23 13:24:40 --> Security Class Initialized
DEBUG - 2018-04-23 13:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:24:40 --> Input Class Initialized
INFO - 2018-04-23 13:24:40 --> Language Class Initialized
ERROR - 2018-04-23 13:24:40 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
INFO - 2018-04-23 13:31:36 --> Loader Class Initialized
INFO - 2018-04-23 13:31:36 --> Helper loaded: common_helper
INFO - 2018-04-23 13:31:36 --> Database Driver Class Initialized
INFO - 2018-04-23 13:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:31:36 --> Email Class Initialized
INFO - 2018-04-23 13:31:36 --> Controller Class Initialized
INFO - 2018-04-23 13:31:36 --> Helper loaded: form_helper
INFO - 2018-04-23 13:31:36 --> Form Validation Class Initialized
INFO - 2018-04-23 13:31:36 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:31:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:31:36 --> Helper loaded: url_helper
INFO - 2018-04-23 13:31:36 --> Model Class Initialized
INFO - 2018-04-23 13:31:36 --> Model Class Initialized
INFO - 2018-04-23 13:31:36 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:31:36 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:31:36 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:31:36 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:31:36 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:31:36 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:31:36 --> Final output sent to browser
DEBUG - 2018-04-23 13:31:36 --> Total execution time: 0.0024
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:31:36 --> Config Class Initialized
INFO - 2018-04-23 13:31:36 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:36 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:36 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:36 --> URI Class Initialized
INFO - 2018-04-23 13:31:36 --> Router Class Initialized
INFO - 2018-04-23 13:31:36 --> Output Class Initialized
INFO - 2018-04-23 13:31:36 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:36 --> Input Class Initialized
INFO - 2018-04-23 13:31:36 --> Language Class Initialized
ERROR - 2018-04-23 13:31:36 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:31:46 --> Config Class Initialized
INFO - 2018-04-23 13:31:46 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:31:46 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:31:46 --> Utf8 Class Initialized
INFO - 2018-04-23 13:31:46 --> URI Class Initialized
INFO - 2018-04-23 13:31:46 --> Router Class Initialized
INFO - 2018-04-23 13:31:46 --> Output Class Initialized
INFO - 2018-04-23 13:31:46 --> Security Class Initialized
DEBUG - 2018-04-23 13:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:31:46 --> Input Class Initialized
INFO - 2018-04-23 13:31:46 --> Language Class Initialized
INFO - 2018-04-23 13:31:46 --> Loader Class Initialized
INFO - 2018-04-23 13:31:46 --> Helper loaded: common_helper
INFO - 2018-04-23 13:31:46 --> Database Driver Class Initialized
INFO - 2018-04-23 13:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:31:46 --> Email Class Initialized
INFO - 2018-04-23 13:31:46 --> Controller Class Initialized
INFO - 2018-04-23 13:31:46 --> Helper loaded: form_helper
INFO - 2018-04-23 13:31:46 --> Form Validation Class Initialized
INFO - 2018-04-23 13:31:46 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:31:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:31:46 --> Helper loaded: url_helper
INFO - 2018-04-23 13:31:46 --> Model Class Initialized
INFO - 2018-04-23 13:31:46 --> Model Class Initialized
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
INFO - 2018-04-23 13:32:11 --> Loader Class Initialized
INFO - 2018-04-23 13:32:11 --> Helper loaded: common_helper
INFO - 2018-04-23 13:32:11 --> Database Driver Class Initialized
INFO - 2018-04-23 13:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:32:11 --> Email Class Initialized
INFO - 2018-04-23 13:32:11 --> Controller Class Initialized
INFO - 2018-04-23 13:32:11 --> Helper loaded: form_helper
INFO - 2018-04-23 13:32:11 --> Form Validation Class Initialized
INFO - 2018-04-23 13:32:11 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:32:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:32:11 --> Helper loaded: url_helper
INFO - 2018-04-23 13:32:11 --> Model Class Initialized
INFO - 2018-04-23 13:32:11 --> Model Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:32:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:32:11 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:32:11 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:32:11 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:32:11 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:32:11 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:32:11 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:32:11 --> Final output sent to browser
DEBUG - 2018-04-23 13:32:11 --> Total execution time: 0.0031
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:32:11 --> Config Class Initialized
INFO - 2018-04-23 13:32:11 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:11 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:11 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:11 --> URI Class Initialized
INFO - 2018-04-23 13:32:11 --> Router Class Initialized
INFO - 2018-04-23 13:32:11 --> Output Class Initialized
INFO - 2018-04-23 13:32:11 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:11 --> Input Class Initialized
INFO - 2018-04-23 13:32:11 --> Language Class Initialized
ERROR - 2018-04-23 13:32:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
INFO - 2018-04-23 13:32:31 --> Loader Class Initialized
INFO - 2018-04-23 13:32:31 --> Helper loaded: common_helper
INFO - 2018-04-23 13:32:31 --> Database Driver Class Initialized
INFO - 2018-04-23 13:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:32:31 --> Email Class Initialized
INFO - 2018-04-23 13:32:31 --> Controller Class Initialized
INFO - 2018-04-23 13:32:31 --> Helper loaded: form_helper
INFO - 2018-04-23 13:32:31 --> Form Validation Class Initialized
INFO - 2018-04-23 13:32:31 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:32:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:32:31 --> Helper loaded: url_helper
INFO - 2018-04-23 13:32:31 --> Model Class Initialized
INFO - 2018-04-23 13:32:31 --> Model Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:32:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:32:31 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:32:31 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:32:31 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:32:31 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:32:31 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:32:31 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:32:31 --> Final output sent to browser
DEBUG - 2018-04-23 13:32:31 --> Total execution time: 0.0047
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
ERROR - 2018-04-23 13:32:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
ERROR - 2018-04-23 13:32:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
ERROR - 2018-04-23 13:32:31 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
ERROR - 2018-04-23 13:32:31 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
ERROR - 2018-04-23 13:32:31 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:32:31 --> Config Class Initialized
INFO - 2018-04-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:31 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:31 --> URI Class Initialized
INFO - 2018-04-23 13:32:31 --> Router Class Initialized
INFO - 2018-04-23 13:32:31 --> Output Class Initialized
INFO - 2018-04-23 13:32:31 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:31 --> Input Class Initialized
INFO - 2018-04-23 13:32:31 --> Language Class Initialized
ERROR - 2018-04-23 13:32:31 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:32:32 --> Config Class Initialized
INFO - 2018-04-23 13:32:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:32 --> URI Class Initialized
INFO - 2018-04-23 13:32:32 --> Router Class Initialized
INFO - 2018-04-23 13:32:32 --> Output Class Initialized
INFO - 2018-04-23 13:32:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:32 --> Input Class Initialized
INFO - 2018-04-23 13:32:32 --> Language Class Initialized
ERROR - 2018-04-23 13:32:32 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:32:32 --> Config Class Initialized
INFO - 2018-04-23 13:32:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:32 --> URI Class Initialized
INFO - 2018-04-23 13:32:32 --> Router Class Initialized
INFO - 2018-04-23 13:32:32 --> Output Class Initialized
INFO - 2018-04-23 13:32:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:32 --> Input Class Initialized
INFO - 2018-04-23 13:32:32 --> Language Class Initialized
ERROR - 2018-04-23 13:32:32 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:32:32 --> Config Class Initialized
INFO - 2018-04-23 13:32:32 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:32:32 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:32:32 --> Utf8 Class Initialized
INFO - 2018-04-23 13:32:32 --> URI Class Initialized
INFO - 2018-04-23 13:32:32 --> Router Class Initialized
INFO - 2018-04-23 13:32:32 --> Output Class Initialized
INFO - 2018-04-23 13:32:32 --> Security Class Initialized
DEBUG - 2018-04-23 13:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:32:32 --> Input Class Initialized
INFO - 2018-04-23 13:32:32 --> Language Class Initialized
ERROR - 2018-04-23 13:32:32 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
INFO - 2018-04-23 13:33:26 --> Loader Class Initialized
INFO - 2018-04-23 13:33:26 --> Helper loaded: common_helper
INFO - 2018-04-23 13:33:26 --> Database Driver Class Initialized
INFO - 2018-04-23 13:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:33:26 --> Email Class Initialized
INFO - 2018-04-23 13:33:26 --> Controller Class Initialized
INFO - 2018-04-23 13:33:26 --> Helper loaded: form_helper
INFO - 2018-04-23 13:33:26 --> Form Validation Class Initialized
INFO - 2018-04-23 13:33:26 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:33:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:26 --> Helper loaded: url_helper
INFO - 2018-04-23 13:33:26 --> Model Class Initialized
INFO - 2018-04-23 13:33:26 --> Model Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:33:26 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:33:26 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:33:26 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:33:26 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:33:26 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:33:26 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:33:26 --> Final output sent to browser
DEBUG - 2018-04-23 13:33:26 --> Total execution time: 0.0027
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:26 --> Config Class Initialized
INFO - 2018-04-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:26 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:26 --> URI Class Initialized
INFO - 2018-04-23 13:33:26 --> Router Class Initialized
INFO - 2018-04-23 13:33:26 --> Output Class Initialized
INFO - 2018-04-23 13:33:26 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:26 --> Input Class Initialized
INFO - 2018-04-23 13:33:26 --> Language Class Initialized
ERROR - 2018-04-23 13:33:26 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:33:27 --> Config Class Initialized
INFO - 2018-04-23 13:33:27 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:27 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:27 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:27 --> URI Class Initialized
INFO - 2018-04-23 13:33:27 --> Router Class Initialized
INFO - 2018-04-23 13:33:27 --> Output Class Initialized
INFO - 2018-04-23 13:33:27 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:27 --> Input Class Initialized
INFO - 2018-04-23 13:33:27 --> Language Class Initialized
ERROR - 2018-04-23 13:33:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:42 --> Config Class Initialized
INFO - 2018-04-23 13:33:42 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:42 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:42 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:42 --> URI Class Initialized
INFO - 2018-04-23 13:33:42 --> Router Class Initialized
INFO - 2018-04-23 13:33:42 --> Output Class Initialized
INFO - 2018-04-23 13:33:42 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:42 --> Input Class Initialized
INFO - 2018-04-23 13:33:42 --> Language Class Initialized
INFO - 2018-04-23 13:33:42 --> Loader Class Initialized
INFO - 2018-04-23 13:33:42 --> Helper loaded: common_helper
INFO - 2018-04-23 13:33:42 --> Database Driver Class Initialized
INFO - 2018-04-23 13:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:33:42 --> Email Class Initialized
INFO - 2018-04-23 13:33:42 --> Controller Class Initialized
INFO - 2018-04-23 13:33:42 --> Helper loaded: form_helper
INFO - 2018-04-23 13:33:42 --> Form Validation Class Initialized
INFO - 2018-04-23 13:33:42 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:33:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:42 --> Helper loaded: url_helper
INFO - 2018-04-23 13:33:42 --> Model Class Initialized
INFO - 2018-04-23 13:33:42 --> Model Class Initialized
INFO - 2018-04-23 13:33:43 --> Config Class Initialized
INFO - 2018-04-23 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:43 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:43 --> URI Class Initialized
INFO - 2018-04-23 13:33:43 --> Router Class Initialized
INFO - 2018-04-23 13:33:43 --> Output Class Initialized
INFO - 2018-04-23 13:33:43 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:43 --> Input Class Initialized
INFO - 2018-04-23 13:33:43 --> Language Class Initialized
INFO - 2018-04-23 13:33:43 --> Loader Class Initialized
INFO - 2018-04-23 13:33:43 --> Helper loaded: common_helper
INFO - 2018-04-23 13:33:43 --> Database Driver Class Initialized
INFO - 2018-04-23 13:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:33:43 --> Email Class Initialized
INFO - 2018-04-23 13:33:43 --> Controller Class Initialized
INFO - 2018-04-23 13:33:43 --> Helper loaded: form_helper
INFO - 2018-04-23 13:33:43 --> Form Validation Class Initialized
INFO - 2018-04-23 13:33:43 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:43 --> Helper loaded: url_helper
INFO - 2018-04-23 13:33:43 --> Model Class Initialized
INFO - 2018-04-23 13:33:43 --> Model Class Initialized
INFO - 2018-04-23 13:33:43 --> Config Class Initialized
INFO - 2018-04-23 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:43 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:43 --> URI Class Initialized
DEBUG - 2018-04-23 13:33:43 --> No URI present. Default controller set.
INFO - 2018-04-23 13:33:43 --> Router Class Initialized
INFO - 2018-04-23 13:33:43 --> Output Class Initialized
INFO - 2018-04-23 13:33:43 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:43 --> Input Class Initialized
INFO - 2018-04-23 13:33:43 --> Language Class Initialized
INFO - 2018-04-23 13:33:43 --> Loader Class Initialized
INFO - 2018-04-23 13:33:43 --> Helper loaded: common_helper
INFO - 2018-04-23 13:33:43 --> Database Driver Class Initialized
INFO - 2018-04-23 13:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:33:43 --> Email Class Initialized
INFO - 2018-04-23 13:33:43 --> Controller Class Initialized
INFO - 2018-04-23 13:33:43 --> Helper loaded: form_helper
INFO - 2018-04-23 13:33:43 --> Form Validation Class Initialized
INFO - 2018-04-23 13:33:43 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:43 --> Helper loaded: url_helper
INFO - 2018-04-23 13:33:43 --> Model Class Initialized
INFO - 2018-04-23 13:33:43 --> Model Class Initialized
INFO - 2018-04-23 13:33:43 --> File loaded: /var/www/html/admin/application/views/index.php
INFO - 2018-04-23 13:33:43 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:33:43 --> Final output sent to browser
DEBUG - 2018-04-23 13:33:43 --> Total execution time: 0.0018
INFO - 2018-04-23 13:33:43 --> Config Class Initialized
INFO - 2018-04-23 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:43 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:43 --> URI Class Initialized
INFO - 2018-04-23 13:33:43 --> Router Class Initialized
INFO - 2018-04-23 13:33:43 --> Output Class Initialized
INFO - 2018-04-23 13:33:43 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:43 --> Input Class Initialized
INFO - 2018-04-23 13:33:43 --> Language Class Initialized
ERROR - 2018-04-23 13:33:43 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:43 --> Config Class Initialized
INFO - 2018-04-23 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:43 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:43 --> URI Class Initialized
INFO - 2018-04-23 13:33:43 --> Router Class Initialized
INFO - 2018-04-23 13:33:43 --> Output Class Initialized
INFO - 2018-04-23 13:33:43 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:43 --> Input Class Initialized
INFO - 2018-04-23 13:33:43 --> Language Class Initialized
ERROR - 2018-04-23 13:33:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:43 --> Config Class Initialized
INFO - 2018-04-23 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:43 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:43 --> URI Class Initialized
INFO - 2018-04-23 13:33:43 --> Router Class Initialized
INFO - 2018-04-23 13:33:43 --> Output Class Initialized
INFO - 2018-04-23 13:33:43 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:43 --> Input Class Initialized
INFO - 2018-04-23 13:33:43 --> Language Class Initialized
ERROR - 2018-04-23 13:33:43 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:33:43 --> Config Class Initialized
INFO - 2018-04-23 13:33:43 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:43 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:43 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:43 --> URI Class Initialized
INFO - 2018-04-23 13:33:43 --> Router Class Initialized
INFO - 2018-04-23 13:33:43 --> Output Class Initialized
INFO - 2018-04-23 13:33:43 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:43 --> Input Class Initialized
INFO - 2018-04-23 13:33:43 --> Language Class Initialized
ERROR - 2018-04-23 13:33:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
INFO - 2018-04-23 13:33:44 --> Loader Class Initialized
INFO - 2018-04-23 13:33:44 --> Helper loaded: common_helper
INFO - 2018-04-23 13:33:44 --> Database Driver Class Initialized
INFO - 2018-04-23 13:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:33:44 --> Email Class Initialized
INFO - 2018-04-23 13:33:44 --> Controller Class Initialized
INFO - 2018-04-23 13:33:44 --> Helper loaded: form_helper
INFO - 2018-04-23 13:33:44 --> Form Validation Class Initialized
INFO - 2018-04-23 13:33:44 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:33:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:44 --> Helper loaded: url_helper
INFO - 2018-04-23 13:33:44 --> Model Class Initialized
INFO - 2018-04-23 13:33:44 --> Model Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:33:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:33:44 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:33:44 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:33:44 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:33:44 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:33:44 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:33:44 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:33:44 --> Final output sent to browser
DEBUG - 2018-04-23 13:33:44 --> Total execution time: 0.0032
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:33:44 --> Config Class Initialized
INFO - 2018-04-23 13:33:44 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:33:44 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:33:44 --> Utf8 Class Initialized
INFO - 2018-04-23 13:33:44 --> URI Class Initialized
INFO - 2018-04-23 13:33:44 --> Router Class Initialized
INFO - 2018-04-23 13:33:44 --> Output Class Initialized
INFO - 2018-04-23 13:33:44 --> Security Class Initialized
DEBUG - 2018-04-23 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:33:44 --> Input Class Initialized
INFO - 2018-04-23 13:33:44 --> Language Class Initialized
ERROR - 2018-04-23 13:33:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:34:38 --> Config Class Initialized
INFO - 2018-04-23 13:34:38 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:34:38 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:34:38 --> Utf8 Class Initialized
INFO - 2018-04-23 13:34:38 --> URI Class Initialized
INFO - 2018-04-23 13:34:38 --> Router Class Initialized
INFO - 2018-04-23 13:34:38 --> Output Class Initialized
INFO - 2018-04-23 13:34:38 --> Security Class Initialized
DEBUG - 2018-04-23 13:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:34:38 --> Input Class Initialized
INFO - 2018-04-23 13:34:38 --> Language Class Initialized
INFO - 2018-04-23 13:34:38 --> Loader Class Initialized
INFO - 2018-04-23 13:34:38 --> Helper loaded: common_helper
INFO - 2018-04-23 13:34:38 --> Database Driver Class Initialized
INFO - 2018-04-23 13:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:34:38 --> Email Class Initialized
INFO - 2018-04-23 13:34:38 --> Controller Class Initialized
INFO - 2018-04-23 13:34:38 --> Helper loaded: form_helper
INFO - 2018-04-23 13:34:38 --> Form Validation Class Initialized
INFO - 2018-04-23 13:34:38 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:34:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:34:38 --> Helper loaded: url_helper
INFO - 2018-04-23 13:34:38 --> Model Class Initialized
INFO - 2018-04-23 13:34:38 --> Model Class Initialized
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
INFO - 2018-04-23 13:35:06 --> Loader Class Initialized
INFO - 2018-04-23 13:35:06 --> Helper loaded: common_helper
INFO - 2018-04-23 13:35:06 --> Database Driver Class Initialized
INFO - 2018-04-23 13:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:35:06 --> Email Class Initialized
INFO - 2018-04-23 13:35:06 --> Controller Class Initialized
INFO - 2018-04-23 13:35:06 --> Helper loaded: form_helper
INFO - 2018-04-23 13:35:06 --> Form Validation Class Initialized
INFO - 2018-04-23 13:35:06 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:35:06 --> Helper loaded: url_helper
INFO - 2018-04-23 13:35:06 --> Model Class Initialized
INFO - 2018-04-23 13:35:06 --> Model Class Initialized
INFO - 2018-04-23 13:35:06 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:35:06 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:35:06 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:35:06 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:35:06 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:35:06 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:35:06 --> Final output sent to browser
DEBUG - 2018-04-23 13:35:06 --> Total execution time: 0.0041
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/select2
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:35:06 --> Config Class Initialized
INFO - 2018-04-23 13:35:06 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:06 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:06 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:06 --> URI Class Initialized
INFO - 2018-04-23 13:35:06 --> Router Class Initialized
INFO - 2018-04-23 13:35:06 --> Output Class Initialized
INFO - 2018-04-23 13:35:06 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:06 --> Input Class Initialized
INFO - 2018-04-23 13:35:06 --> Language Class Initialized
ERROR - 2018-04-23 13:35:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
INFO - 2018-04-23 13:35:15 --> Loader Class Initialized
INFO - 2018-04-23 13:35:15 --> Helper loaded: common_helper
INFO - 2018-04-23 13:35:15 --> Database Driver Class Initialized
INFO - 2018-04-23 13:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:35:15 --> Email Class Initialized
INFO - 2018-04-23 13:35:15 --> Controller Class Initialized
INFO - 2018-04-23 13:35:15 --> Helper loaded: form_helper
INFO - 2018-04-23 13:35:15 --> Form Validation Class Initialized
INFO - 2018-04-23 13:35:15 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:35:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:35:15 --> Helper loaded: url_helper
INFO - 2018-04-23 13:35:15 --> Model Class Initialized
INFO - 2018-04-23 13:35:15 --> Model Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:35:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:35:15 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:35:15 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:35:15 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:35:15 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:35:15 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:35:15 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:35:15 --> Final output sent to browser
DEBUG - 2018-04-23 13:35:15 --> Total execution time: 0.0022
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:35:15 --> Config Class Initialized
INFO - 2018-04-23 13:35:15 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:15 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:15 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:15 --> URI Class Initialized
INFO - 2018-04-23 13:35:15 --> Router Class Initialized
INFO - 2018-04-23 13:35:15 --> Output Class Initialized
INFO - 2018-04-23 13:35:15 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:15 --> Input Class Initialized
INFO - 2018-04-23 13:35:15 --> Language Class Initialized
ERROR - 2018-04-23 13:35:15 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
INFO - 2018-04-23 13:35:52 --> Loader Class Initialized
INFO - 2018-04-23 13:35:52 --> Helper loaded: common_helper
INFO - 2018-04-23 13:35:52 --> Database Driver Class Initialized
INFO - 2018-04-23 13:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:35:52 --> Email Class Initialized
INFO - 2018-04-23 13:35:52 --> Controller Class Initialized
INFO - 2018-04-23 13:35:52 --> Helper loaded: form_helper
INFO - 2018-04-23 13:35:52 --> Form Validation Class Initialized
INFO - 2018-04-23 13:35:52 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:35:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:35:52 --> Helper loaded: url_helper
INFO - 2018-04-23 13:35:52 --> Model Class Initialized
INFO - 2018-04-23 13:35:52 --> Model Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:35:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:35:52 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:35:52 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:35:52 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:35:52 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:35:52 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:35:52 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:35:52 --> Final output sent to browser
DEBUG - 2018-04-23 13:35:52 --> Total execution time: 0.0021
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:35:52 --> Config Class Initialized
INFO - 2018-04-23 13:35:52 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:35:52 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:35:52 --> Utf8 Class Initialized
INFO - 2018-04-23 13:35:52 --> URI Class Initialized
INFO - 2018-04-23 13:35:52 --> Router Class Initialized
INFO - 2018-04-23 13:35:52 --> Output Class Initialized
INFO - 2018-04-23 13:35:52 --> Security Class Initialized
DEBUG - 2018-04-23 13:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:35:52 --> Input Class Initialized
INFO - 2018-04-23 13:35:52 --> Language Class Initialized
ERROR - 2018-04-23 13:35:52 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:36:03 --> Config Class Initialized
INFO - 2018-04-23 13:36:03 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:36:03 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:36:03 --> Utf8 Class Initialized
INFO - 2018-04-23 13:36:03 --> URI Class Initialized
INFO - 2018-04-23 13:36:03 --> Router Class Initialized
INFO - 2018-04-23 13:36:03 --> Output Class Initialized
INFO - 2018-04-23 13:36:03 --> Security Class Initialized
DEBUG - 2018-04-23 13:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:36:03 --> Input Class Initialized
INFO - 2018-04-23 13:36:03 --> Language Class Initialized
INFO - 2018-04-23 13:36:03 --> Loader Class Initialized
INFO - 2018-04-23 13:36:03 --> Helper loaded: common_helper
INFO - 2018-04-23 13:36:03 --> Database Driver Class Initialized
INFO - 2018-04-23 13:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:36:03 --> Email Class Initialized
INFO - 2018-04-23 13:36:03 --> Controller Class Initialized
INFO - 2018-04-23 13:36:03 --> Helper loaded: form_helper
INFO - 2018-04-23 13:36:03 --> Form Validation Class Initialized
INFO - 2018-04-23 13:36:03 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:36:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:36:03 --> Helper loaded: url_helper
INFO - 2018-04-23 13:36:03 --> Model Class Initialized
INFO - 2018-04-23 13:36:03 --> Model Class Initialized
INFO - 2018-04-23 13:37:24 --> Config Class Initialized
INFO - 2018-04-23 13:37:24 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:24 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:24 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:24 --> URI Class Initialized
INFO - 2018-04-23 13:37:24 --> Router Class Initialized
INFO - 2018-04-23 13:37:24 --> Output Class Initialized
INFO - 2018-04-23 13:37:24 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:24 --> Input Class Initialized
INFO - 2018-04-23 13:37:24 --> Language Class Initialized
INFO - 2018-04-23 13:37:24 --> Loader Class Initialized
INFO - 2018-04-23 13:37:24 --> Helper loaded: common_helper
INFO - 2018-04-23 13:37:24 --> Database Driver Class Initialized
INFO - 2018-04-23 13:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-04-23 13:37:24 --> Email Class Initialized
INFO - 2018-04-23 13:37:24 --> Controller Class Initialized
INFO - 2018-04-23 13:37:24 --> Helper loaded: form_helper
INFO - 2018-04-23 13:37:24 --> Form Validation Class Initialized
INFO - 2018-04-23 13:37:24 --> Helper loaded: email_helper
DEBUG - 2018-04-23 13:37:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:37:24 --> Helper loaded: url_helper
INFO - 2018-04-23 13:37:24 --> Model Class Initialized
INFO - 2018-04-23 13:37:24 --> Model Class Initialized
DEBUG - 2018-04-23 13:37:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-04-23 13:37:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-04-23 13:37:24 --> File loaded: /var/www/html/admin/application/views/header.php
INFO - 2018-04-23 13:37:24 --> File loaded: /var/www/html/admin/application/views/sideMenu.php
INFO - 2018-04-23 13:37:24 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:37:24 --> File loaded: /var/www/html/admin/application/views/adds/addAdd.php
INFO - 2018-04-23 13:37:24 --> File loaded: /var/www/html/admin/application/views/scripts.php
INFO - 2018-04-23 13:37:24 --> File loaded: /var/www/html/admin/application/views/footer.php
INFO - 2018-04-23 13:37:24 --> Final output sent to browser
DEBUG - 2018-04-23 13:37:24 --> Total execution time: 0.0053
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/select2
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/components-select2.min.js
INFO - 2018-04-23 13:37:25 --> Config Class Initialized
INFO - 2018-04-23 13:37:25 --> Hooks Class Initialized
DEBUG - 2018-04-23 13:37:25 --> UTF-8 Support Enabled
INFO - 2018-04-23 13:37:25 --> Utf8 Class Initialized
INFO - 2018-04-23 13:37:25 --> URI Class Initialized
INFO - 2018-04-23 13:37:25 --> Router Class Initialized
INFO - 2018-04-23 13:37:25 --> Output Class Initialized
INFO - 2018-04-23 13:37:25 --> Security Class Initialized
DEBUG - 2018-04-23 13:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-04-23 13:37:25 --> Input Class Initialized
INFO - 2018-04-23 13:37:25 --> Language Class Initialized
ERROR - 2018-04-23 13:37:25 --> 404 Page Not Found: Assets/bootstrap-datepicker
