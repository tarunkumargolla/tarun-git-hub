<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-05-01 07:50:58 --> Config Class Initialized
INFO - 2018-05-01 07:50:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 07:50:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 07:50:58 --> Utf8 Class Initialized
INFO - 2018-05-01 07:50:58 --> URI Class Initialized
INFO - 2018-05-01 07:50:58 --> Router Class Initialized
INFO - 2018-05-01 07:50:58 --> Output Class Initialized
INFO - 2018-05-01 07:50:58 --> Security Class Initialized
DEBUG - 2018-05-01 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 07:50:58 --> Input Class Initialized
INFO - 2018-05-01 07:50:58 --> Language Class Initialized
INFO - 2018-05-01 07:50:58 --> Loader Class Initialized
INFO - 2018-05-01 07:50:58 --> Helper loaded: common_helper
INFO - 2018-05-01 07:50:59 --> Database Driver Class Initialized
INFO - 2018-05-01 07:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 07:50:59 --> Email Class Initialized
INFO - 2018-05-01 07:50:59 --> Controller Class Initialized
INFO - 2018-05-01 07:50:59 --> Helper loaded: form_helper
INFO - 2018-05-01 07:50:59 --> Form Validation Class Initialized
INFO - 2018-05-01 07:50:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 07:50:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 07:50:59 --> Helper loaded: url_helper
INFO - 2018-05-01 07:50:59 --> Model Class Initialized
INFO - 2018-05-01 07:50:59 --> Model Class Initialized
INFO - 2018-05-01 07:50:59 --> Model Class Initialized
INFO - 2018-05-01 11:20:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:20:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:21:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:21:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-01 11:21:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:21:00 --> Final output sent to browser
DEBUG - 2018-05-01 11:21:00 --> Total execution time: 1.7891
INFO - 2018-05-01 08:08:10 --> Config Class Initialized
INFO - 2018-05-01 08:08:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:08:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:08:10 --> Utf8 Class Initialized
INFO - 2018-05-01 08:08:10 --> URI Class Initialized
INFO - 2018-05-01 08:08:10 --> Router Class Initialized
INFO - 2018-05-01 08:08:10 --> Output Class Initialized
INFO - 2018-05-01 08:08:10 --> Security Class Initialized
DEBUG - 2018-05-01 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:08:10 --> Input Class Initialized
INFO - 2018-05-01 08:08:10 --> Language Class Initialized
INFO - 2018-05-01 08:08:10 --> Loader Class Initialized
INFO - 2018-05-01 08:08:10 --> Helper loaded: common_helper
INFO - 2018-05-01 08:08:10 --> Database Driver Class Initialized
INFO - 2018-05-01 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:08:10 --> Email Class Initialized
INFO - 2018-05-01 08:08:10 --> Controller Class Initialized
INFO - 2018-05-01 08:08:10 --> Helper loaded: form_helper
INFO - 2018-05-01 08:08:10 --> Form Validation Class Initialized
INFO - 2018-05-01 08:08:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:10 --> Helper loaded: url_helper
INFO - 2018-05-01 08:08:10 --> Model Class Initialized
INFO - 2018-05-01 08:08:10 --> Model Class Initialized
INFO - 2018-05-01 08:08:10 --> Model Class Initialized
INFO - 2018-05-01 11:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-01 11:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:38:10 --> Final output sent to browser
DEBUG - 2018-05-01 11:38:10 --> Total execution time: 0.2150
INFO - 2018-05-01 08:08:12 --> Config Class Initialized
INFO - 2018-05-01 08:08:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:08:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:08:12 --> Utf8 Class Initialized
INFO - 2018-05-01 08:08:12 --> URI Class Initialized
INFO - 2018-05-01 08:08:12 --> Router Class Initialized
INFO - 2018-05-01 08:08:12 --> Output Class Initialized
INFO - 2018-05-01 08:08:12 --> Security Class Initialized
DEBUG - 2018-05-01 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:08:12 --> Input Class Initialized
INFO - 2018-05-01 08:08:12 --> Language Class Initialized
INFO - 2018-05-01 08:08:12 --> Loader Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: common_helper
INFO - 2018-05-01 08:08:12 --> Database Driver Class Initialized
INFO - 2018-05-01 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:08:12 --> Email Class Initialized
INFO - 2018-05-01 08:08:12 --> Controller Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: form_helper
INFO - 2018-05-01 08:08:12 --> Form Validation Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:12 --> Helper loaded: url_helper
INFO - 2018-05-01 08:08:12 --> Model Class Initialized
INFO - 2018-05-01 08:08:12 --> Model Class Initialized
INFO - 2018-05-01 08:08:12 --> Model Class Initialized
INFO - 2018-05-01 08:08:12 --> Config Class Initialized
INFO - 2018-05-01 08:08:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:08:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:08:12 --> Utf8 Class Initialized
INFO - 2018-05-01 08:08:12 --> URI Class Initialized
INFO - 2018-05-01 08:08:12 --> Router Class Initialized
INFO - 2018-05-01 08:08:12 --> Output Class Initialized
INFO - 2018-05-01 08:08:12 --> Security Class Initialized
DEBUG - 2018-05-01 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:08:12 --> Input Class Initialized
INFO - 2018-05-01 08:08:12 --> Language Class Initialized
INFO - 2018-05-01 08:08:12 --> Loader Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: common_helper
INFO - 2018-05-01 08:08:12 --> Database Driver Class Initialized
INFO - 2018-05-01 08:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:08:12 --> Email Class Initialized
INFO - 2018-05-01 08:08:12 --> Controller Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: form_helper
INFO - 2018-05-01 08:08:12 --> Form Validation Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:08:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:12 --> Helper loaded: url_helper
INFO - 2018-05-01 08:08:12 --> Model Class Initialized
INFO - 2018-05-01 08:08:12 --> Model Class Initialized
INFO - 2018-05-01 08:08:12 --> Config Class Initialized
INFO - 2018-05-01 08:08:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:08:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:08:12 --> Utf8 Class Initialized
INFO - 2018-05-01 08:08:12 --> URI Class Initialized
DEBUG - 2018-05-01 08:08:12 --> No URI present. Default controller set.
INFO - 2018-05-01 08:08:12 --> Router Class Initialized
INFO - 2018-05-01 08:08:12 --> Output Class Initialized
INFO - 2018-05-01 08:08:12 --> Security Class Initialized
DEBUG - 2018-05-01 08:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:08:12 --> Input Class Initialized
INFO - 2018-05-01 08:08:12 --> Language Class Initialized
INFO - 2018-05-01 08:08:12 --> Loader Class Initialized
INFO - 2018-05-01 08:08:12 --> Helper loaded: common_helper
INFO - 2018-05-01 08:08:12 --> Database Driver Class Initialized
INFO - 2018-05-01 08:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:08:13 --> Email Class Initialized
INFO - 2018-05-01 08:08:13 --> Controller Class Initialized
INFO - 2018-05-01 08:08:13 --> Helper loaded: form_helper
INFO - 2018-05-01 08:08:13 --> Form Validation Class Initialized
INFO - 2018-05-01 08:08:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:08:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:13 --> Helper loaded: url_helper
INFO - 2018-05-01 08:08:13 --> Model Class Initialized
INFO - 2018-05-01 08:08:13 --> Model Class Initialized
INFO - 2018-05-01 08:08:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\index.php
INFO - 2018-05-01 08:08:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:08:13 --> Final output sent to browser
DEBUG - 2018-05-01 08:08:13 --> Total execution time: 0.1690
INFO - 2018-05-01 08:08:15 --> Config Class Initialized
INFO - 2018-05-01 08:08:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:08:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:08:15 --> Utf8 Class Initialized
INFO - 2018-05-01 08:08:15 --> URI Class Initialized
DEBUG - 2018-05-01 08:08:15 --> No URI present. Default controller set.
INFO - 2018-05-01 08:08:15 --> Router Class Initialized
INFO - 2018-05-01 08:08:15 --> Output Class Initialized
INFO - 2018-05-01 08:08:15 --> Security Class Initialized
DEBUG - 2018-05-01 08:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:08:15 --> Input Class Initialized
INFO - 2018-05-01 08:08:15 --> Language Class Initialized
INFO - 2018-05-01 08:08:15 --> Loader Class Initialized
INFO - 2018-05-01 08:08:15 --> Helper loaded: common_helper
INFO - 2018-05-01 08:08:15 --> Database Driver Class Initialized
INFO - 2018-05-01 08:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:08:16 --> Email Class Initialized
INFO - 2018-05-01 08:08:16 --> Controller Class Initialized
INFO - 2018-05-01 08:08:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:08:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:08:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:08:16 --> Model Class Initialized
INFO - 2018-05-01 08:08:16 --> Model Class Initialized
DEBUG - 2018-05-01 08:08:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:08:16 --> Config Class Initialized
INFO - 2018-05-01 08:08:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:08:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:08:16 --> Utf8 Class Initialized
INFO - 2018-05-01 08:08:16 --> URI Class Initialized
INFO - 2018-05-01 08:08:16 --> Router Class Initialized
INFO - 2018-05-01 08:08:16 --> Output Class Initialized
INFO - 2018-05-01 08:08:16 --> Security Class Initialized
DEBUG - 2018-05-01 08:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:08:16 --> Input Class Initialized
INFO - 2018-05-01 08:08:16 --> Language Class Initialized
INFO - 2018-05-01 08:08:16 --> Loader Class Initialized
INFO - 2018-05-01 08:08:16 --> Helper loaded: common_helper
INFO - 2018-05-01 08:08:16 --> Database Driver Class Initialized
INFO - 2018-05-01 08:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:08:16 --> Email Class Initialized
INFO - 2018-05-01 08:08:16 --> Controller Class Initialized
INFO - 2018-05-01 08:08:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:08:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:08:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:08:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:08:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:08:16 --> Model Class Initialized
INFO - 2018-05-01 08:08:16 --> Model Class Initialized
INFO - 2018-05-01 08:08:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:08:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-01 08:08:16 --> Undefined variable: categories
ERROR - 2018-05-01 08:08:16 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-01 08:08:16 --> Trying to get property of non-object
ERROR - 2018-05-01 08:08:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-01 08:08:16 --> Undefined variable: articles
ERROR - 2018-05-01 08:08:16 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-01 08:08:16 --> Trying to get property of non-object
ERROR - 2018-05-01 08:08:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-01 08:08:16 --> Undefined variable: subscriptions
ERROR - 2018-05-01 08:08:16 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-01 08:08:16 --> Trying to get property of non-object
ERROR - 2018-05-01 08:08:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-01 08:08:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-01 08:08:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:08:16 --> Final output sent to browser
DEBUG - 2018-05-01 08:08:16 --> Total execution time: 0.3710
INFO - 2018-05-01 08:14:28 --> Config Class Initialized
INFO - 2018-05-01 08:14:28 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:14:28 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:14:28 --> Utf8 Class Initialized
INFO - 2018-05-01 08:14:28 --> URI Class Initialized
INFO - 2018-05-01 08:14:28 --> Router Class Initialized
INFO - 2018-05-01 08:14:28 --> Output Class Initialized
INFO - 2018-05-01 08:14:28 --> Security Class Initialized
DEBUG - 2018-05-01 08:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:14:28 --> Input Class Initialized
INFO - 2018-05-01 08:14:28 --> Language Class Initialized
INFO - 2018-05-01 08:14:28 --> Loader Class Initialized
INFO - 2018-05-01 08:14:28 --> Helper loaded: common_helper
INFO - 2018-05-01 08:14:28 --> Database Driver Class Initialized
INFO - 2018-05-01 08:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:14:28 --> Email Class Initialized
INFO - 2018-05-01 08:14:28 --> Controller Class Initialized
INFO - 2018-05-01 08:14:28 --> Helper loaded: form_helper
INFO - 2018-05-01 08:14:28 --> Form Validation Class Initialized
INFO - 2018-05-01 08:14:28 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:14:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:14:28 --> Helper loaded: url_helper
INFO - 2018-05-01 08:14:28 --> Model Class Initialized
INFO - 2018-05-01 08:14:28 --> Model Class Initialized
INFO - 2018-05-01 08:14:28 --> Model Class Initialized
INFO - 2018-05-01 11:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-01 11:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:44:28 --> Final output sent to browser
DEBUG - 2018-05-01 11:44:28 --> Total execution time: 0.2310
INFO - 2018-05-01 08:14:36 --> Config Class Initialized
INFO - 2018-05-01 08:14:36 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:14:36 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:14:36 --> Utf8 Class Initialized
INFO - 2018-05-01 08:14:36 --> URI Class Initialized
INFO - 2018-05-01 08:14:36 --> Router Class Initialized
INFO - 2018-05-01 08:14:36 --> Output Class Initialized
INFO - 2018-05-01 08:14:36 --> Security Class Initialized
DEBUG - 2018-05-01 08:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:14:36 --> Input Class Initialized
INFO - 2018-05-01 08:14:36 --> Language Class Initialized
INFO - 2018-05-01 08:14:36 --> Loader Class Initialized
INFO - 2018-05-01 08:14:36 --> Helper loaded: common_helper
INFO - 2018-05-01 08:14:36 --> Database Driver Class Initialized
INFO - 2018-05-01 08:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:14:36 --> Email Class Initialized
INFO - 2018-05-01 08:14:36 --> Controller Class Initialized
INFO - 2018-05-01 08:14:36 --> Helper loaded: form_helper
INFO - 2018-05-01 08:14:36 --> Form Validation Class Initialized
INFO - 2018-05-01 08:14:36 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:14:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:14:36 --> Helper loaded: url_helper
INFO - 2018-05-01 08:14:36 --> Model Class Initialized
INFO - 2018-05-01 08:14:36 --> Model Class Initialized
INFO - 2018-05-01 08:14:36 --> Model Class Initialized
INFO - 2018-05-01 11:44:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:44:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:44:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 11:44:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:44:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:44:36 --> Final output sent to browser
DEBUG - 2018-05-01 11:44:36 --> Total execution time: 0.1470
INFO - 2018-05-01 08:14:43 --> Config Class Initialized
INFO - 2018-05-01 08:14:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:14:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:14:43 --> Utf8 Class Initialized
INFO - 2018-05-01 08:14:43 --> URI Class Initialized
INFO - 2018-05-01 08:14:43 --> Router Class Initialized
INFO - 2018-05-01 08:14:43 --> Output Class Initialized
INFO - 2018-05-01 08:14:43 --> Security Class Initialized
DEBUG - 2018-05-01 08:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:14:43 --> Input Class Initialized
INFO - 2018-05-01 08:14:43 --> Language Class Initialized
INFO - 2018-05-01 08:14:43 --> Loader Class Initialized
INFO - 2018-05-01 08:14:43 --> Helper loaded: common_helper
INFO - 2018-05-01 08:14:43 --> Database Driver Class Initialized
INFO - 2018-05-01 08:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:14:43 --> Email Class Initialized
INFO - 2018-05-01 08:14:43 --> Controller Class Initialized
INFO - 2018-05-01 08:14:43 --> Helper loaded: form_helper
INFO - 2018-05-01 08:14:43 --> Form Validation Class Initialized
INFO - 2018-05-01 08:14:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:14:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:14:43 --> Helper loaded: url_helper
INFO - 2018-05-01 08:14:43 --> Model Class Initialized
INFO - 2018-05-01 08:14:43 --> Model Class Initialized
INFO - 2018-05-01 08:14:43 --> Model Class Initialized
INFO - 2018-05-01 11:44:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:44:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:44:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:44:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:44:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:44:43 --> Final output sent to browser
DEBUG - 2018-05-01 11:44:43 --> Total execution time: 0.1880
INFO - 2018-05-01 08:14:47 --> Config Class Initialized
INFO - 2018-05-01 08:14:47 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:14:47 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:14:47 --> Utf8 Class Initialized
INFO - 2018-05-01 08:14:47 --> URI Class Initialized
INFO - 2018-05-01 08:14:47 --> Router Class Initialized
INFO - 2018-05-01 08:14:47 --> Output Class Initialized
INFO - 2018-05-01 08:14:47 --> Security Class Initialized
DEBUG - 2018-05-01 08:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:14:47 --> Input Class Initialized
INFO - 2018-05-01 08:14:47 --> Language Class Initialized
INFO - 2018-05-01 08:14:47 --> Loader Class Initialized
INFO - 2018-05-01 08:14:47 --> Helper loaded: common_helper
INFO - 2018-05-01 08:14:47 --> Database Driver Class Initialized
INFO - 2018-05-01 08:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:14:47 --> Email Class Initialized
INFO - 2018-05-01 08:14:47 --> Controller Class Initialized
INFO - 2018-05-01 08:14:47 --> Helper loaded: form_helper
INFO - 2018-05-01 08:14:47 --> Form Validation Class Initialized
INFO - 2018-05-01 08:14:47 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:14:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:14:47 --> Helper loaded: url_helper
INFO - 2018-05-01 08:14:47 --> Model Class Initialized
INFO - 2018-05-01 08:14:47 --> Model Class Initialized
INFO - 2018-05-01 08:14:47 --> Model Class Initialized
INFO - 2018-05-01 11:44:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:44:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:44:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:44:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 11:44:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:44:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:44:47 --> Final output sent to browser
DEBUG - 2018-05-01 11:44:47 --> Total execution time: 0.1370
INFO - 2018-05-01 08:16:38 --> Config Class Initialized
INFO - 2018-05-01 08:16:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:16:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:16:38 --> Utf8 Class Initialized
INFO - 2018-05-01 08:16:38 --> URI Class Initialized
INFO - 2018-05-01 08:16:38 --> Router Class Initialized
INFO - 2018-05-01 08:16:38 --> Output Class Initialized
INFO - 2018-05-01 08:16:38 --> Security Class Initialized
DEBUG - 2018-05-01 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:16:38 --> Input Class Initialized
INFO - 2018-05-01 08:16:38 --> Language Class Initialized
INFO - 2018-05-01 08:16:38 --> Loader Class Initialized
INFO - 2018-05-01 08:16:38 --> Helper loaded: common_helper
INFO - 2018-05-01 08:16:38 --> Database Driver Class Initialized
INFO - 2018-05-01 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:16:38 --> Email Class Initialized
INFO - 2018-05-01 08:16:38 --> Controller Class Initialized
INFO - 2018-05-01 08:16:38 --> Helper loaded: form_helper
INFO - 2018-05-01 08:16:38 --> Form Validation Class Initialized
INFO - 2018-05-01 08:16:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:16:38 --> Helper loaded: url_helper
INFO - 2018-05-01 08:16:38 --> Model Class Initialized
INFO - 2018-05-01 08:16:38 --> Model Class Initialized
INFO - 2018-05-01 08:16:38 --> Model Class Initialized
DEBUG - 2018-05-01 11:46:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 11:46:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:16:38 --> Config Class Initialized
INFO - 2018-05-01 08:16:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:16:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:16:38 --> Utf8 Class Initialized
INFO - 2018-05-01 08:16:38 --> URI Class Initialized
INFO - 2018-05-01 08:16:38 --> Router Class Initialized
INFO - 2018-05-01 08:16:38 --> Output Class Initialized
INFO - 2018-05-01 08:16:38 --> Security Class Initialized
DEBUG - 2018-05-01 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:16:38 --> Input Class Initialized
INFO - 2018-05-01 08:16:38 --> Language Class Initialized
INFO - 2018-05-01 08:16:38 --> Loader Class Initialized
INFO - 2018-05-01 08:16:38 --> Helper loaded: common_helper
INFO - 2018-05-01 08:16:38 --> Database Driver Class Initialized
INFO - 2018-05-01 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:16:38 --> Email Class Initialized
INFO - 2018-05-01 08:16:38 --> Controller Class Initialized
INFO - 2018-05-01 08:16:38 --> Helper loaded: form_helper
INFO - 2018-05-01 08:16:38 --> Form Validation Class Initialized
INFO - 2018-05-01 08:16:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:16:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:16:38 --> Helper loaded: url_helper
INFO - 2018-05-01 08:16:38 --> Model Class Initialized
INFO - 2018-05-01 08:16:38 --> Model Class Initialized
INFO - 2018-05-01 08:16:38 --> Model Class Initialized
INFO - 2018-05-01 11:46:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:46:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:46:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:46:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:46:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:46:38 --> Final output sent to browser
DEBUG - 2018-05-01 11:46:38 --> Total execution time: 0.1510
INFO - 2018-05-01 08:22:03 --> Config Class Initialized
INFO - 2018-05-01 08:22:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:03 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:03 --> URI Class Initialized
INFO - 2018-05-01 08:22:03 --> Router Class Initialized
INFO - 2018-05-01 08:22:03 --> Output Class Initialized
INFO - 2018-05-01 08:22:03 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:03 --> Input Class Initialized
INFO - 2018-05-01 08:22:03 --> Language Class Initialized
INFO - 2018-05-01 08:22:03 --> Loader Class Initialized
INFO - 2018-05-01 08:22:03 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:03 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:03 --> Email Class Initialized
INFO - 2018-05-01 08:22:03 --> Controller Class Initialized
INFO - 2018-05-01 08:22:03 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:03 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:03 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:03 --> Model Class Initialized
INFO - 2018-05-01 08:22:03 --> Model Class Initialized
INFO - 2018-05-01 08:22:03 --> Model Class Initialized
INFO - 2018-05-01 11:52:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 11:52:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:03 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:03 --> Total execution time: 0.1720
INFO - 2018-05-01 08:22:30 --> Config Class Initialized
INFO - 2018-05-01 08:22:30 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:30 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:30 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:30 --> URI Class Initialized
INFO - 2018-05-01 08:22:30 --> Router Class Initialized
INFO - 2018-05-01 08:22:30 --> Output Class Initialized
INFO - 2018-05-01 08:22:30 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:30 --> Input Class Initialized
INFO - 2018-05-01 08:22:30 --> Language Class Initialized
INFO - 2018-05-01 08:22:30 --> Loader Class Initialized
INFO - 2018-05-01 08:22:30 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:30 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:31 --> Email Class Initialized
INFO - 2018-05-01 08:22:31 --> Controller Class Initialized
INFO - 2018-05-01 08:22:31 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:31 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:31 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:31 --> Model Class Initialized
INFO - 2018-05-01 08:22:31 --> Model Class Initialized
INFO - 2018-05-01 08:22:31 --> Model Class Initialized
DEBUG - 2018-05-01 11:52:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 11:52:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:22:31 --> Config Class Initialized
INFO - 2018-05-01 08:22:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:31 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:31 --> URI Class Initialized
INFO - 2018-05-01 08:22:31 --> Router Class Initialized
INFO - 2018-05-01 08:22:31 --> Output Class Initialized
INFO - 2018-05-01 08:22:31 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:31 --> Input Class Initialized
INFO - 2018-05-01 08:22:31 --> Language Class Initialized
INFO - 2018-05-01 08:22:31 --> Loader Class Initialized
INFO - 2018-05-01 08:22:31 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:31 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:31 --> Email Class Initialized
INFO - 2018-05-01 08:22:31 --> Controller Class Initialized
INFO - 2018-05-01 08:22:31 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:31 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:31 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:31 --> Model Class Initialized
INFO - 2018-05-01 08:22:31 --> Model Class Initialized
INFO - 2018-05-01 08:22:31 --> Model Class Initialized
INFO - 2018-05-01 11:52:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:52:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:31 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:31 --> Total execution time: 0.1310
INFO - 2018-05-01 08:22:37 --> Config Class Initialized
INFO - 2018-05-01 08:22:37 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:37 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:37 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:37 --> URI Class Initialized
INFO - 2018-05-01 08:22:37 --> Router Class Initialized
INFO - 2018-05-01 08:22:37 --> Output Class Initialized
INFO - 2018-05-01 08:22:37 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:37 --> Input Class Initialized
INFO - 2018-05-01 08:22:37 --> Language Class Initialized
INFO - 2018-05-01 08:22:37 --> Loader Class Initialized
INFO - 2018-05-01 08:22:37 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:37 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:37 --> Email Class Initialized
INFO - 2018-05-01 08:22:37 --> Controller Class Initialized
INFO - 2018-05-01 08:22:37 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:37 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:37 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:37 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:37 --> Model Class Initialized
INFO - 2018-05-01 08:22:37 --> Model Class Initialized
INFO - 2018-05-01 08:22:37 --> Model Class Initialized
INFO - 2018-05-01 11:52:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:52:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:37 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:37 --> Total execution time: 0.2090
INFO - 2018-05-01 08:22:43 --> Config Class Initialized
INFO - 2018-05-01 08:22:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:43 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:43 --> URI Class Initialized
INFO - 2018-05-01 08:22:43 --> Router Class Initialized
INFO - 2018-05-01 08:22:43 --> Output Class Initialized
INFO - 2018-05-01 08:22:43 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:43 --> Input Class Initialized
INFO - 2018-05-01 08:22:43 --> Language Class Initialized
INFO - 2018-05-01 08:22:43 --> Loader Class Initialized
INFO - 2018-05-01 08:22:43 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:43 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:43 --> Email Class Initialized
INFO - 2018-05-01 08:22:43 --> Controller Class Initialized
INFO - 2018-05-01 08:22:43 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:43 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:43 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:43 --> Model Class Initialized
INFO - 2018-05-01 08:22:43 --> Model Class Initialized
INFO - 2018-05-01 08:22:43 --> Model Class Initialized
INFO - 2018-05-01 08:22:43 --> Config Class Initialized
INFO - 2018-05-01 08:22:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:43 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:43 --> URI Class Initialized
INFO - 2018-05-01 08:22:43 --> Router Class Initialized
INFO - 2018-05-01 08:22:43 --> Output Class Initialized
INFO - 2018-05-01 08:22:43 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:43 --> Input Class Initialized
INFO - 2018-05-01 08:22:43 --> Language Class Initialized
INFO - 2018-05-01 08:22:43 --> Loader Class Initialized
INFO - 2018-05-01 08:22:43 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:43 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:43 --> Email Class Initialized
INFO - 2018-05-01 08:22:43 --> Controller Class Initialized
INFO - 2018-05-01 08:22:43 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:43 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:43 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:43 --> Model Class Initialized
INFO - 2018-05-01 08:22:43 --> Model Class Initialized
INFO - 2018-05-01 08:22:43 --> Model Class Initialized
INFO - 2018-05-01 11:52:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:52:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:43 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:43 --> Total execution time: 0.1370
INFO - 2018-05-01 08:22:47 --> Config Class Initialized
INFO - 2018-05-01 08:22:47 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:47 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:47 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:47 --> URI Class Initialized
INFO - 2018-05-01 08:22:47 --> Router Class Initialized
INFO - 2018-05-01 08:22:47 --> Output Class Initialized
INFO - 2018-05-01 08:22:47 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:47 --> Input Class Initialized
INFO - 2018-05-01 08:22:47 --> Language Class Initialized
INFO - 2018-05-01 08:22:47 --> Loader Class Initialized
INFO - 2018-05-01 08:22:47 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:47 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:47 --> Email Class Initialized
INFO - 2018-05-01 08:22:47 --> Controller Class Initialized
INFO - 2018-05-01 08:22:47 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:47 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:47 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:47 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:47 --> Model Class Initialized
INFO - 2018-05-01 08:22:47 --> Model Class Initialized
INFO - 2018-05-01 08:22:47 --> Model Class Initialized
INFO - 2018-05-01 11:52:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:52:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:47 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:47 --> Total execution time: 0.1360
INFO - 2018-05-01 08:22:55 --> Config Class Initialized
INFO - 2018-05-01 08:22:55 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:55 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:55 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:55 --> URI Class Initialized
INFO - 2018-05-01 08:22:55 --> Router Class Initialized
INFO - 2018-05-01 08:22:55 --> Output Class Initialized
INFO - 2018-05-01 08:22:55 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:55 --> Input Class Initialized
INFO - 2018-05-01 08:22:55 --> Language Class Initialized
INFO - 2018-05-01 08:22:55 --> Loader Class Initialized
INFO - 2018-05-01 08:22:55 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:55 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:55 --> Email Class Initialized
INFO - 2018-05-01 08:22:55 --> Controller Class Initialized
INFO - 2018-05-01 08:22:55 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:55 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:55 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:55 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:55 --> Model Class Initialized
INFO - 2018-05-01 08:22:55 --> Model Class Initialized
INFO - 2018-05-01 08:22:55 --> Model Class Initialized
INFO - 2018-05-01 08:22:55 --> Config Class Initialized
INFO - 2018-05-01 08:22:55 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:55 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:55 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:55 --> URI Class Initialized
INFO - 2018-05-01 08:22:55 --> Router Class Initialized
INFO - 2018-05-01 08:22:55 --> Output Class Initialized
INFO - 2018-05-01 08:22:55 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:55 --> Input Class Initialized
INFO - 2018-05-01 08:22:55 --> Language Class Initialized
INFO - 2018-05-01 08:22:55 --> Loader Class Initialized
INFO - 2018-05-01 08:22:55 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:55 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:55 --> Email Class Initialized
INFO - 2018-05-01 08:22:55 --> Controller Class Initialized
INFO - 2018-05-01 08:22:55 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:55 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:55 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:55 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:55 --> Model Class Initialized
INFO - 2018-05-01 08:22:55 --> Model Class Initialized
INFO - 2018-05-01 08:22:55 --> Model Class Initialized
INFO - 2018-05-01 11:52:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:52:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:55 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:55 --> Total execution time: 0.1350
INFO - 2018-05-01 08:22:59 --> Config Class Initialized
INFO - 2018-05-01 08:22:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:22:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:22:59 --> Utf8 Class Initialized
INFO - 2018-05-01 08:22:59 --> URI Class Initialized
INFO - 2018-05-01 08:22:59 --> Router Class Initialized
INFO - 2018-05-01 08:22:59 --> Output Class Initialized
INFO - 2018-05-01 08:22:59 --> Security Class Initialized
DEBUG - 2018-05-01 08:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:22:59 --> Input Class Initialized
INFO - 2018-05-01 08:22:59 --> Language Class Initialized
INFO - 2018-05-01 08:22:59 --> Loader Class Initialized
INFO - 2018-05-01 08:22:59 --> Helper loaded: common_helper
INFO - 2018-05-01 08:22:59 --> Database Driver Class Initialized
INFO - 2018-05-01 08:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:22:59 --> Email Class Initialized
INFO - 2018-05-01 08:22:59 --> Controller Class Initialized
INFO - 2018-05-01 08:22:59 --> Helper loaded: form_helper
INFO - 2018-05-01 08:22:59 --> Form Validation Class Initialized
INFO - 2018-05-01 08:22:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:22:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:22:59 --> Helper loaded: url_helper
INFO - 2018-05-01 08:22:59 --> Model Class Initialized
INFO - 2018-05-01 08:22:59 --> Model Class Initialized
INFO - 2018-05-01 08:22:59 --> Model Class Initialized
INFO - 2018-05-01 11:52:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:52:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:52:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:52:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:52:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:52:59 --> Final output sent to browser
DEBUG - 2018-05-01 11:52:59 --> Total execution time: 0.1350
INFO - 2018-05-01 08:27:14 --> Config Class Initialized
INFO - 2018-05-01 08:27:14 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:27:14 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:27:14 --> Utf8 Class Initialized
INFO - 2018-05-01 08:27:14 --> URI Class Initialized
INFO - 2018-05-01 08:27:14 --> Router Class Initialized
INFO - 2018-05-01 08:27:14 --> Output Class Initialized
INFO - 2018-05-01 08:27:14 --> Security Class Initialized
DEBUG - 2018-05-01 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:27:14 --> Input Class Initialized
INFO - 2018-05-01 08:27:14 --> Language Class Initialized
INFO - 2018-05-01 08:27:14 --> Loader Class Initialized
INFO - 2018-05-01 08:27:14 --> Helper loaded: common_helper
INFO - 2018-05-01 08:27:14 --> Database Driver Class Initialized
INFO - 2018-05-01 08:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:27:14 --> Email Class Initialized
INFO - 2018-05-01 08:27:14 --> Controller Class Initialized
INFO - 2018-05-01 08:27:14 --> Helper loaded: form_helper
INFO - 2018-05-01 08:27:14 --> Form Validation Class Initialized
INFO - 2018-05-01 08:27:14 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:27:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:27:14 --> Helper loaded: url_helper
INFO - 2018-05-01 08:27:14 --> Model Class Initialized
INFO - 2018-05-01 08:27:14 --> Model Class Initialized
INFO - 2018-05-01 08:27:14 --> Model Class Initialized
INFO - 2018-05-01 11:57:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:57:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:57:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:57:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:57:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:57:14 --> Final output sent to browser
DEBUG - 2018-05-01 11:57:14 --> Total execution time: 0.1480
INFO - 2018-05-01 08:27:16 --> Config Class Initialized
INFO - 2018-05-01 08:27:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:27:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:27:16 --> Utf8 Class Initialized
INFO - 2018-05-01 08:27:16 --> URI Class Initialized
INFO - 2018-05-01 08:27:16 --> Router Class Initialized
INFO - 2018-05-01 08:27:16 --> Output Class Initialized
INFO - 2018-05-01 08:27:16 --> Security Class Initialized
DEBUG - 2018-05-01 08:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:27:16 --> Input Class Initialized
INFO - 2018-05-01 08:27:16 --> Language Class Initialized
INFO - 2018-05-01 08:27:16 --> Loader Class Initialized
INFO - 2018-05-01 08:27:16 --> Helper loaded: common_helper
INFO - 2018-05-01 08:27:16 --> Database Driver Class Initialized
INFO - 2018-05-01 08:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:27:16 --> Email Class Initialized
INFO - 2018-05-01 08:27:16 --> Controller Class Initialized
INFO - 2018-05-01 08:27:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:27:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:27:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:27:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:27:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:27:16 --> Model Class Initialized
INFO - 2018-05-01 08:27:16 --> Model Class Initialized
INFO - 2018-05-01 08:27:16 --> Model Class Initialized
INFO - 2018-05-01 11:57:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:57:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:57:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:57:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 11:57:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:57:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:57:16 --> Final output sent to browser
DEBUG - 2018-05-01 11:57:16 --> Total execution time: 0.1270
INFO - 2018-05-01 08:27:58 --> Config Class Initialized
INFO - 2018-05-01 08:27:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:27:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:27:58 --> Utf8 Class Initialized
INFO - 2018-05-01 08:27:58 --> URI Class Initialized
INFO - 2018-05-01 08:27:58 --> Router Class Initialized
INFO - 2018-05-01 08:27:58 --> Output Class Initialized
INFO - 2018-05-01 08:27:58 --> Security Class Initialized
DEBUG - 2018-05-01 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:27:58 --> Input Class Initialized
INFO - 2018-05-01 08:27:58 --> Language Class Initialized
INFO - 2018-05-01 08:27:58 --> Loader Class Initialized
INFO - 2018-05-01 08:27:58 --> Helper loaded: common_helper
INFO - 2018-05-01 08:27:58 --> Database Driver Class Initialized
INFO - 2018-05-01 08:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:27:58 --> Email Class Initialized
INFO - 2018-05-01 08:27:58 --> Controller Class Initialized
INFO - 2018-05-01 08:27:58 --> Helper loaded: form_helper
INFO - 2018-05-01 08:27:58 --> Form Validation Class Initialized
INFO - 2018-05-01 08:27:58 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:27:58 --> Helper loaded: url_helper
INFO - 2018-05-01 08:27:58 --> Model Class Initialized
INFO - 2018-05-01 08:27:58 --> Model Class Initialized
INFO - 2018-05-01 08:27:58 --> Model Class Initialized
DEBUG - 2018-05-01 11:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 11:57:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:27:58 --> Config Class Initialized
INFO - 2018-05-01 08:27:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:27:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:27:58 --> Utf8 Class Initialized
INFO - 2018-05-01 08:27:58 --> URI Class Initialized
INFO - 2018-05-01 08:27:58 --> Router Class Initialized
INFO - 2018-05-01 08:27:58 --> Output Class Initialized
INFO - 2018-05-01 08:27:58 --> Security Class Initialized
DEBUG - 2018-05-01 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:27:58 --> Input Class Initialized
INFO - 2018-05-01 08:27:58 --> Language Class Initialized
INFO - 2018-05-01 08:27:58 --> Loader Class Initialized
INFO - 2018-05-01 08:27:58 --> Helper loaded: common_helper
INFO - 2018-05-01 08:27:58 --> Database Driver Class Initialized
INFO - 2018-05-01 08:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:27:58 --> Email Class Initialized
INFO - 2018-05-01 08:27:58 --> Controller Class Initialized
INFO - 2018-05-01 08:27:58 --> Helper loaded: form_helper
INFO - 2018-05-01 08:27:58 --> Form Validation Class Initialized
INFO - 2018-05-01 08:27:58 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:27:58 --> Helper loaded: url_helper
INFO - 2018-05-01 08:27:58 --> Model Class Initialized
INFO - 2018-05-01 08:27:58 --> Model Class Initialized
INFO - 2018-05-01 08:27:58 --> Model Class Initialized
INFO - 2018-05-01 11:57:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:57:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:57:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:57:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:57:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:57:58 --> Final output sent to browser
DEBUG - 2018-05-01 11:57:58 --> Total execution time: 0.1620
INFO - 2018-05-01 08:28:08 --> Config Class Initialized
INFO - 2018-05-01 08:28:08 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:08 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:08 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:08 --> URI Class Initialized
INFO - 2018-05-01 08:28:08 --> Router Class Initialized
INFO - 2018-05-01 08:28:08 --> Output Class Initialized
INFO - 2018-05-01 08:28:08 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:08 --> Input Class Initialized
INFO - 2018-05-01 08:28:08 --> Language Class Initialized
INFO - 2018-05-01 08:28:08 --> Loader Class Initialized
INFO - 2018-05-01 08:28:08 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:08 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:08 --> Email Class Initialized
INFO - 2018-05-01 08:28:08 --> Controller Class Initialized
INFO - 2018-05-01 08:28:08 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:08 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:08 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:09 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:09 --> Model Class Initialized
INFO - 2018-05-01 08:28:09 --> Model Class Initialized
INFO - 2018-05-01 08:28:09 --> Model Class Initialized
INFO - 2018-05-01 11:58:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:58:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:58:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:58:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:58:09 --> Final output sent to browser
DEBUG - 2018-05-01 11:58:09 --> Total execution time: 0.1500
INFO - 2018-05-01 08:28:15 --> Config Class Initialized
INFO - 2018-05-01 08:28:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:15 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:15 --> URI Class Initialized
INFO - 2018-05-01 08:28:15 --> Router Class Initialized
INFO - 2018-05-01 08:28:15 --> Output Class Initialized
INFO - 2018-05-01 08:28:15 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:15 --> Input Class Initialized
INFO - 2018-05-01 08:28:15 --> Language Class Initialized
ERROR - 2018-05-01 08:28:15 --> 404 Page Not Found: Assets/images
INFO - 2018-05-01 08:28:24 --> Config Class Initialized
INFO - 2018-05-01 08:28:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:24 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:24 --> URI Class Initialized
INFO - 2018-05-01 08:28:24 --> Router Class Initialized
INFO - 2018-05-01 08:28:24 --> Output Class Initialized
INFO - 2018-05-01 08:28:24 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:24 --> Input Class Initialized
INFO - 2018-05-01 08:28:24 --> Language Class Initialized
INFO - 2018-05-01 08:28:24 --> Loader Class Initialized
INFO - 2018-05-01 08:28:24 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:24 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:24 --> Email Class Initialized
INFO - 2018-05-01 08:28:24 --> Controller Class Initialized
INFO - 2018-05-01 08:28:24 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:24 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:24 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:24 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:24 --> Model Class Initialized
INFO - 2018-05-01 08:28:24 --> Model Class Initialized
INFO - 2018-05-01 08:28:24 --> Model Class Initialized
INFO - 2018-05-01 08:28:24 --> Config Class Initialized
INFO - 2018-05-01 08:28:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:24 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:24 --> URI Class Initialized
INFO - 2018-05-01 08:28:24 --> Router Class Initialized
INFO - 2018-05-01 08:28:24 --> Output Class Initialized
INFO - 2018-05-01 08:28:24 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:24 --> Input Class Initialized
INFO - 2018-05-01 08:28:24 --> Language Class Initialized
INFO - 2018-05-01 08:28:24 --> Loader Class Initialized
INFO - 2018-05-01 08:28:24 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:24 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:25 --> Email Class Initialized
INFO - 2018-05-01 08:28:25 --> Controller Class Initialized
INFO - 2018-05-01 08:28:25 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:25 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:25 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:25 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:25 --> Model Class Initialized
INFO - 2018-05-01 08:28:25 --> Model Class Initialized
INFO - 2018-05-01 08:28:25 --> Model Class Initialized
INFO - 2018-05-01 11:58:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:58:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:58:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:58:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:58:25 --> Final output sent to browser
DEBUG - 2018-05-01 11:58:25 --> Total execution time: 0.1350
INFO - 2018-05-01 08:28:32 --> Config Class Initialized
INFO - 2018-05-01 08:28:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:32 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:32 --> URI Class Initialized
INFO - 2018-05-01 08:28:32 --> Router Class Initialized
INFO - 2018-05-01 08:28:32 --> Output Class Initialized
INFO - 2018-05-01 08:28:32 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:32 --> Input Class Initialized
INFO - 2018-05-01 08:28:32 --> Language Class Initialized
INFO - 2018-05-01 08:28:32 --> Loader Class Initialized
INFO - 2018-05-01 08:28:32 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:32 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:32 --> Email Class Initialized
INFO - 2018-05-01 08:28:32 --> Controller Class Initialized
INFO - 2018-05-01 08:28:32 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:32 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:32 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:32 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:32 --> Model Class Initialized
INFO - 2018-05-01 08:28:32 --> Model Class Initialized
INFO - 2018-05-01 08:28:32 --> Model Class Initialized
INFO - 2018-05-01 11:58:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:58:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:58:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:58:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:58:32 --> Final output sent to browser
DEBUG - 2018-05-01 11:58:32 --> Total execution time: 0.1370
INFO - 2018-05-01 08:28:39 --> Config Class Initialized
INFO - 2018-05-01 08:28:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:39 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:39 --> URI Class Initialized
INFO - 2018-05-01 08:28:39 --> Router Class Initialized
INFO - 2018-05-01 08:28:39 --> Output Class Initialized
INFO - 2018-05-01 08:28:39 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:39 --> Input Class Initialized
INFO - 2018-05-01 08:28:39 --> Language Class Initialized
INFO - 2018-05-01 08:28:39 --> Loader Class Initialized
INFO - 2018-05-01 08:28:39 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:39 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:39 --> Email Class Initialized
INFO - 2018-05-01 08:28:39 --> Controller Class Initialized
INFO - 2018-05-01 08:28:39 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:39 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:39 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:39 --> Model Class Initialized
INFO - 2018-05-01 08:28:39 --> Model Class Initialized
INFO - 2018-05-01 08:28:39 --> Model Class Initialized
INFO - 2018-05-01 11:58:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:58:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:58:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:58:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:58:39 --> Final output sent to browser
DEBUG - 2018-05-01 11:58:39 --> Total execution time: 0.1500
INFO - 2018-05-01 08:28:41 --> Config Class Initialized
INFO - 2018-05-01 08:28:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:41 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:41 --> URI Class Initialized
INFO - 2018-05-01 08:28:41 --> Router Class Initialized
INFO - 2018-05-01 08:28:41 --> Output Class Initialized
INFO - 2018-05-01 08:28:41 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:41 --> Input Class Initialized
INFO - 2018-05-01 08:28:41 --> Language Class Initialized
INFO - 2018-05-01 08:28:41 --> Loader Class Initialized
INFO - 2018-05-01 08:28:41 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:41 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:41 --> Email Class Initialized
INFO - 2018-05-01 08:28:41 --> Controller Class Initialized
INFO - 2018-05-01 08:28:41 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:41 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:41 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:41 --> Model Class Initialized
INFO - 2018-05-01 08:28:41 --> Model Class Initialized
INFO - 2018-05-01 08:28:41 --> Model Class Initialized
INFO - 2018-05-01 11:58:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:58:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:58:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 11:58:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:58:41 --> Final output sent to browser
DEBUG - 2018-05-01 11:58:41 --> Total execution time: 0.1550
INFO - 2018-05-01 08:28:53 --> Config Class Initialized
INFO - 2018-05-01 08:28:53 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:53 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:53 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:53 --> URI Class Initialized
INFO - 2018-05-01 08:28:53 --> Router Class Initialized
INFO - 2018-05-01 08:28:53 --> Output Class Initialized
INFO - 2018-05-01 08:28:53 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:53 --> Input Class Initialized
INFO - 2018-05-01 08:28:53 --> Language Class Initialized
INFO - 2018-05-01 08:28:53 --> Loader Class Initialized
INFO - 2018-05-01 08:28:53 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:53 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:53 --> Email Class Initialized
INFO - 2018-05-01 08:28:53 --> Controller Class Initialized
INFO - 2018-05-01 08:28:53 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:53 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:53 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:53 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:53 --> Model Class Initialized
INFO - 2018-05-01 08:28:53 --> Model Class Initialized
INFO - 2018-05-01 08:28:53 --> Model Class Initialized
DEBUG - 2018-05-01 11:58:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 11:58:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 11:58:53 --> Missing argument 6 for News::saveImages(), called in C:\xampp\htdocs\Celebrity\admin\application\controllers\News.php on line 185 and defined
ERROR - 2018-05-01 11:58:53 --> Severity: Warning --> Missing argument 6 for News::saveImages(), called in C:\xampp\htdocs\Celebrity\admin\application\controllers\News.php on line 185 and defined C:\xampp\htdocs\Celebrity\admin\application\controllers\News.php 339
INFO - 2018-05-01 08:28:54 --> Config Class Initialized
INFO - 2018-05-01 08:28:54 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:28:54 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:28:54 --> Utf8 Class Initialized
INFO - 2018-05-01 08:28:54 --> URI Class Initialized
INFO - 2018-05-01 08:28:54 --> Router Class Initialized
INFO - 2018-05-01 08:28:54 --> Output Class Initialized
INFO - 2018-05-01 08:28:54 --> Security Class Initialized
DEBUG - 2018-05-01 08:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:28:54 --> Input Class Initialized
INFO - 2018-05-01 08:28:54 --> Language Class Initialized
INFO - 2018-05-01 08:28:54 --> Loader Class Initialized
INFO - 2018-05-01 08:28:54 --> Helper loaded: common_helper
INFO - 2018-05-01 08:28:54 --> Database Driver Class Initialized
INFO - 2018-05-01 08:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:28:54 --> Email Class Initialized
INFO - 2018-05-01 08:28:54 --> Controller Class Initialized
INFO - 2018-05-01 08:28:54 --> Helper loaded: form_helper
INFO - 2018-05-01 08:28:54 --> Form Validation Class Initialized
INFO - 2018-05-01 08:28:54 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:28:54 --> Helper loaded: url_helper
INFO - 2018-05-01 08:28:54 --> Model Class Initialized
INFO - 2018-05-01 08:28:54 --> Model Class Initialized
INFO - 2018-05-01 08:28:54 --> Model Class Initialized
INFO - 2018-05-01 11:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:58:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:58:54 --> Final output sent to browser
DEBUG - 2018-05-01 11:58:54 --> Total execution time: 0.1330
INFO - 2018-05-01 08:29:02 --> Config Class Initialized
INFO - 2018-05-01 08:29:02 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:29:02 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:29:02 --> Utf8 Class Initialized
INFO - 2018-05-01 08:29:02 --> URI Class Initialized
INFO - 2018-05-01 08:29:02 --> Router Class Initialized
INFO - 2018-05-01 08:29:02 --> Output Class Initialized
INFO - 2018-05-01 08:29:02 --> Security Class Initialized
DEBUG - 2018-05-01 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:29:02 --> Input Class Initialized
INFO - 2018-05-01 08:29:02 --> Language Class Initialized
INFO - 2018-05-01 08:29:02 --> Loader Class Initialized
INFO - 2018-05-01 08:29:02 --> Helper loaded: common_helper
INFO - 2018-05-01 08:29:02 --> Database Driver Class Initialized
INFO - 2018-05-01 08:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:29:02 --> Email Class Initialized
INFO - 2018-05-01 08:29:02 --> Controller Class Initialized
INFO - 2018-05-01 08:29:02 --> Helper loaded: form_helper
INFO - 2018-05-01 08:29:02 --> Form Validation Class Initialized
INFO - 2018-05-01 08:29:02 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:29:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:29:02 --> Helper loaded: url_helper
INFO - 2018-05-01 08:29:02 --> Model Class Initialized
INFO - 2018-05-01 08:29:02 --> Model Class Initialized
INFO - 2018-05-01 08:29:02 --> Model Class Initialized
INFO - 2018-05-01 11:59:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:59:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:59:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:59:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:59:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:59:02 --> Final output sent to browser
DEBUG - 2018-05-01 11:59:02 --> Total execution time: 0.1390
INFO - 2018-05-01 08:29:09 --> Config Class Initialized
INFO - 2018-05-01 08:29:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:29:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:29:09 --> Utf8 Class Initialized
INFO - 2018-05-01 08:29:09 --> URI Class Initialized
INFO - 2018-05-01 08:29:09 --> Router Class Initialized
INFO - 2018-05-01 08:29:09 --> Output Class Initialized
INFO - 2018-05-01 08:29:09 --> Security Class Initialized
DEBUG - 2018-05-01 08:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:29:09 --> Input Class Initialized
INFO - 2018-05-01 08:29:09 --> Language Class Initialized
INFO - 2018-05-01 08:29:09 --> Loader Class Initialized
INFO - 2018-05-01 08:29:09 --> Helper loaded: common_helper
INFO - 2018-05-01 08:29:09 --> Database Driver Class Initialized
INFO - 2018-05-01 08:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:29:09 --> Email Class Initialized
INFO - 2018-05-01 08:29:09 --> Controller Class Initialized
INFO - 2018-05-01 08:29:09 --> Helper loaded: form_helper
INFO - 2018-05-01 08:29:09 --> Form Validation Class Initialized
INFO - 2018-05-01 08:29:09 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:29:09 --> Helper loaded: url_helper
INFO - 2018-05-01 08:29:09 --> Model Class Initialized
INFO - 2018-05-01 08:29:09 --> Model Class Initialized
INFO - 2018-05-01 08:29:09 --> Model Class Initialized
INFO - 2018-05-01 08:29:09 --> Config Class Initialized
INFO - 2018-05-01 08:29:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:29:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:29:09 --> Utf8 Class Initialized
INFO - 2018-05-01 08:29:09 --> URI Class Initialized
INFO - 2018-05-01 08:29:09 --> Router Class Initialized
INFO - 2018-05-01 08:29:09 --> Output Class Initialized
INFO - 2018-05-01 08:29:09 --> Security Class Initialized
DEBUG - 2018-05-01 08:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:29:09 --> Input Class Initialized
INFO - 2018-05-01 08:29:09 --> Language Class Initialized
INFO - 2018-05-01 08:29:09 --> Loader Class Initialized
INFO - 2018-05-01 08:29:09 --> Helper loaded: common_helper
INFO - 2018-05-01 08:29:09 --> Database Driver Class Initialized
INFO - 2018-05-01 08:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:29:09 --> Email Class Initialized
INFO - 2018-05-01 08:29:09 --> Controller Class Initialized
INFO - 2018-05-01 08:29:09 --> Helper loaded: form_helper
INFO - 2018-05-01 08:29:09 --> Form Validation Class Initialized
INFO - 2018-05-01 08:29:09 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:29:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:29:09 --> Helper loaded: url_helper
INFO - 2018-05-01 08:29:09 --> Model Class Initialized
INFO - 2018-05-01 08:29:09 --> Model Class Initialized
INFO - 2018-05-01 08:29:09 --> Model Class Initialized
INFO - 2018-05-01 11:59:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:59:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:59:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:59:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:59:09 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:59:09 --> Final output sent to browser
DEBUG - 2018-05-01 11:59:09 --> Total execution time: 0.1330
INFO - 2018-05-01 08:29:13 --> Config Class Initialized
INFO - 2018-05-01 08:29:13 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:29:13 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:29:13 --> Utf8 Class Initialized
INFO - 2018-05-01 08:29:13 --> URI Class Initialized
INFO - 2018-05-01 08:29:13 --> Router Class Initialized
INFO - 2018-05-01 08:29:13 --> Output Class Initialized
INFO - 2018-05-01 08:29:13 --> Security Class Initialized
DEBUG - 2018-05-01 08:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:29:13 --> Input Class Initialized
INFO - 2018-05-01 08:29:13 --> Language Class Initialized
INFO - 2018-05-01 08:29:13 --> Loader Class Initialized
INFO - 2018-05-01 08:29:13 --> Helper loaded: common_helper
INFO - 2018-05-01 08:29:13 --> Database Driver Class Initialized
INFO - 2018-05-01 08:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:29:13 --> Email Class Initialized
INFO - 2018-05-01 08:29:13 --> Controller Class Initialized
INFO - 2018-05-01 08:29:13 --> Helper loaded: form_helper
INFO - 2018-05-01 08:29:13 --> Form Validation Class Initialized
INFO - 2018-05-01 08:29:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:29:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:29:13 --> Helper loaded: url_helper
INFO - 2018-05-01 08:29:13 --> Model Class Initialized
INFO - 2018-05-01 08:29:13 --> Model Class Initialized
INFO - 2018-05-01 08:29:13 --> Model Class Initialized
INFO - 2018-05-01 11:59:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:59:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:59:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 11:59:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:59:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:59:13 --> Final output sent to browser
DEBUG - 2018-05-01 11:59:13 --> Total execution time: 0.1320
INFO - 2018-05-01 08:29:16 --> Config Class Initialized
INFO - 2018-05-01 08:29:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:29:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:29:16 --> Utf8 Class Initialized
INFO - 2018-05-01 08:29:16 --> URI Class Initialized
INFO - 2018-05-01 08:29:16 --> Router Class Initialized
INFO - 2018-05-01 08:29:16 --> Output Class Initialized
INFO - 2018-05-01 08:29:16 --> Security Class Initialized
DEBUG - 2018-05-01 08:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:29:16 --> Input Class Initialized
INFO - 2018-05-01 08:29:16 --> Language Class Initialized
INFO - 2018-05-01 08:29:16 --> Loader Class Initialized
INFO - 2018-05-01 08:29:16 --> Helper loaded: common_helper
INFO - 2018-05-01 08:29:16 --> Database Driver Class Initialized
INFO - 2018-05-01 08:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:29:16 --> Email Class Initialized
INFO - 2018-05-01 08:29:16 --> Controller Class Initialized
INFO - 2018-05-01 08:29:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:29:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:29:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:29:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:29:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:29:16 --> Model Class Initialized
INFO - 2018-05-01 08:29:16 --> Model Class Initialized
INFO - 2018-05-01 08:29:16 --> Model Class Initialized
INFO - 2018-05-01 11:59:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 11:59:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 11:59:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 11:59:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 11:59:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 11:59:16 --> Final output sent to browser
DEBUG - 2018-05-01 11:59:16 --> Total execution time: 0.1500
INFO - 2018-05-01 08:30:01 --> Config Class Initialized
INFO - 2018-05-01 08:30:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:30:01 --> Utf8 Class Initialized
INFO - 2018-05-01 08:30:01 --> URI Class Initialized
INFO - 2018-05-01 08:30:01 --> Router Class Initialized
INFO - 2018-05-01 08:30:01 --> Output Class Initialized
INFO - 2018-05-01 08:30:01 --> Security Class Initialized
DEBUG - 2018-05-01 08:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:30:01 --> Input Class Initialized
INFO - 2018-05-01 08:30:01 --> Language Class Initialized
INFO - 2018-05-01 08:30:01 --> Loader Class Initialized
INFO - 2018-05-01 08:30:01 --> Helper loaded: common_helper
INFO - 2018-05-01 08:30:01 --> Database Driver Class Initialized
INFO - 2018-05-01 08:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:30:01 --> Email Class Initialized
INFO - 2018-05-01 08:30:01 --> Controller Class Initialized
INFO - 2018-05-01 08:30:01 --> Helper loaded: form_helper
INFO - 2018-05-01 08:30:01 --> Form Validation Class Initialized
INFO - 2018-05-01 08:30:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:30:01 --> Helper loaded: url_helper
INFO - 2018-05-01 08:30:01 --> Model Class Initialized
INFO - 2018-05-01 08:30:01 --> Model Class Initialized
INFO - 2018-05-01 08:30:01 --> Model Class Initialized
INFO - 2018-05-01 08:30:01 --> Config Class Initialized
INFO - 2018-05-01 08:30:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:30:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:30:01 --> Utf8 Class Initialized
INFO - 2018-05-01 08:30:01 --> URI Class Initialized
INFO - 2018-05-01 08:30:01 --> Router Class Initialized
INFO - 2018-05-01 08:30:01 --> Output Class Initialized
INFO - 2018-05-01 08:30:01 --> Security Class Initialized
DEBUG - 2018-05-01 08:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:30:01 --> Input Class Initialized
INFO - 2018-05-01 08:30:01 --> Language Class Initialized
INFO - 2018-05-01 08:30:01 --> Loader Class Initialized
INFO - 2018-05-01 08:30:01 --> Helper loaded: common_helper
INFO - 2018-05-01 08:30:01 --> Database Driver Class Initialized
INFO - 2018-05-01 08:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:30:01 --> Email Class Initialized
INFO - 2018-05-01 08:30:01 --> Controller Class Initialized
INFO - 2018-05-01 08:30:01 --> Helper loaded: form_helper
INFO - 2018-05-01 08:30:01 --> Form Validation Class Initialized
INFO - 2018-05-01 08:30:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:30:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:30:01 --> Helper loaded: url_helper
INFO - 2018-05-01 08:30:01 --> Model Class Initialized
INFO - 2018-05-01 08:30:01 --> Model Class Initialized
INFO - 2018-05-01 08:30:01 --> Model Class Initialized
INFO - 2018-05-01 12:00:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:00:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:00:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:00:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:00:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:00:01 --> Final output sent to browser
DEBUG - 2018-05-01 12:00:01 --> Total execution time: 0.1320
INFO - 2018-05-01 08:33:11 --> Config Class Initialized
INFO - 2018-05-01 08:33:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:11 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:11 --> URI Class Initialized
INFO - 2018-05-01 08:33:11 --> Router Class Initialized
INFO - 2018-05-01 08:33:11 --> Output Class Initialized
INFO - 2018-05-01 08:33:11 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:11 --> Input Class Initialized
INFO - 2018-05-01 08:33:11 --> Language Class Initialized
INFO - 2018-05-01 08:33:11 --> Loader Class Initialized
INFO - 2018-05-01 08:33:11 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:11 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:11 --> Email Class Initialized
INFO - 2018-05-01 08:33:11 --> Controller Class Initialized
INFO - 2018-05-01 08:33:11 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:11 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:11 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:11 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:11 --> Model Class Initialized
INFO - 2018-05-01 08:33:11 --> Model Class Initialized
INFO - 2018-05-01 08:33:11 --> Model Class Initialized
INFO - 2018-05-01 12:03:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 12:03:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:11 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:11 --> Total execution time: 0.2090
INFO - 2018-05-01 08:33:12 --> Config Class Initialized
INFO - 2018-05-01 08:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:12 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:12 --> URI Class Initialized
INFO - 2018-05-01 08:33:12 --> Router Class Initialized
INFO - 2018-05-01 08:33:12 --> Output Class Initialized
INFO - 2018-05-01 08:33:12 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:12 --> Input Class Initialized
INFO - 2018-05-01 08:33:12 --> Language Class Initialized
INFO - 2018-05-01 08:33:12 --> Loader Class Initialized
INFO - 2018-05-01 08:33:12 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:12 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:12 --> Config Class Initialized
INFO - 2018-05-01 08:33:12 --> Hooks Class Initialized
INFO - 2018-05-01 08:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:12 --> Email Class Initialized
INFO - 2018-05-01 08:33:12 --> Controller Class Initialized
DEBUG - 2018-05-01 08:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:12 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:12 --> URI Class Initialized
INFO - 2018-05-01 08:33:12 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:12 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:12 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:12 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:12 --> Model Class Initialized
INFO - 2018-05-01 08:33:12 --> Router Class Initialized
INFO - 2018-05-01 08:33:12 --> Model Class Initialized
INFO - 2018-05-01 08:33:12 --> Model Class Initialized
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:12 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:12 --> Total execution time: 0.2190
INFO - 2018-05-01 08:33:12 --> Output Class Initialized
INFO - 2018-05-01 08:33:12 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:12 --> Input Class Initialized
INFO - 2018-05-01 08:33:12 --> Language Class Initialized
INFO - 2018-05-01 08:33:12 --> Loader Class Initialized
INFO - 2018-05-01 08:33:12 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:12 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:12 --> Email Class Initialized
INFO - 2018-05-01 08:33:12 --> Controller Class Initialized
INFO - 2018-05-01 08:33:12 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:12 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:12 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:12 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:12 --> Model Class Initialized
INFO - 2018-05-01 08:33:12 --> Model Class Initialized
INFO - 2018-05-01 08:33:12 --> Model Class Initialized
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:12 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:12 --> Total execution time: 0.2240
INFO - 2018-05-01 08:33:12 --> Config Class Initialized
INFO - 2018-05-01 08:33:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:12 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:12 --> URI Class Initialized
INFO - 2018-05-01 08:33:12 --> Router Class Initialized
INFO - 2018-05-01 08:33:12 --> Output Class Initialized
INFO - 2018-05-01 08:33:12 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:12 --> Input Class Initialized
INFO - 2018-05-01 08:33:12 --> Language Class Initialized
INFO - 2018-05-01 08:33:13 --> Loader Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:13 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:13 --> Email Class Initialized
INFO - 2018-05-01 08:33:13 --> Controller Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:13 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:13 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 08:33:13 --> Config Class Initialized
INFO - 2018-05-01 08:33:13 --> Hooks Class Initialized
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
DEBUG - 2018-05-01 08:33:13 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:33:13 --> Utf8 Class Initialized
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:13 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:13 --> Total execution time: 0.1480
INFO - 2018-05-01 08:33:13 --> URI Class Initialized
INFO - 2018-05-01 08:33:13 --> Router Class Initialized
INFO - 2018-05-01 08:33:13 --> Output Class Initialized
INFO - 2018-05-01 08:33:13 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:13 --> Input Class Initialized
INFO - 2018-05-01 08:33:13 --> Language Class Initialized
INFO - 2018-05-01 08:33:13 --> Loader Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:13 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:13 --> Email Class Initialized
INFO - 2018-05-01 08:33:13 --> Controller Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:13 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:13 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:13 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:13 --> Total execution time: 0.1600
INFO - 2018-05-01 08:33:13 --> Config Class Initialized
INFO - 2018-05-01 08:33:13 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:13 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:13 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:13 --> URI Class Initialized
INFO - 2018-05-01 08:33:13 --> Router Class Initialized
INFO - 2018-05-01 08:33:13 --> Output Class Initialized
INFO - 2018-05-01 08:33:13 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:13 --> Input Class Initialized
INFO - 2018-05-01 08:33:13 --> Language Class Initialized
INFO - 2018-05-01 08:33:13 --> Loader Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:13 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:13 --> Email Class Initialized
INFO - 2018-05-01 08:33:13 --> Controller Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:13 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:13 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 08:33:13 --> Model Class Initialized
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:13 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:13 --> Total execution time: 0.1660
INFO - 2018-05-01 08:33:15 --> Config Class Initialized
INFO - 2018-05-01 08:33:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:15 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:15 --> URI Class Initialized
INFO - 2018-05-01 08:33:15 --> Router Class Initialized
INFO - 2018-05-01 08:33:15 --> Output Class Initialized
INFO - 2018-05-01 08:33:15 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:15 --> Input Class Initialized
INFO - 2018-05-01 08:33:15 --> Language Class Initialized
INFO - 2018-05-01 08:33:15 --> Loader Class Initialized
INFO - 2018-05-01 08:33:15 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:15 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:15 --> Email Class Initialized
INFO - 2018-05-01 08:33:15 --> Controller Class Initialized
INFO - 2018-05-01 08:33:15 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:15 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:15 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:15 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:15 --> Model Class Initialized
INFO - 2018-05-01 08:33:15 --> Model Class Initialized
INFO - 2018-05-01 08:33:15 --> Model Class Initialized
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:15 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:15 --> Total execution time: 0.1390
INFO - 2018-05-01 08:33:15 --> Config Class Initialized
INFO - 2018-05-01 08:33:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:15 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:15 --> URI Class Initialized
INFO - 2018-05-01 08:33:15 --> Router Class Initialized
INFO - 2018-05-01 08:33:15 --> Output Class Initialized
INFO - 2018-05-01 08:33:15 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:15 --> Input Class Initialized
INFO - 2018-05-01 08:33:15 --> Language Class Initialized
INFO - 2018-05-01 08:33:15 --> Loader Class Initialized
INFO - 2018-05-01 08:33:15 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:15 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:15 --> Email Class Initialized
INFO - 2018-05-01 08:33:15 --> Controller Class Initialized
INFO - 2018-05-01 08:33:15 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:15 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:15 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:15 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:15 --> Model Class Initialized
INFO - 2018-05-01 08:33:15 --> Model Class Initialized
INFO - 2018-05-01 08:33:15 --> Model Class Initialized
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:15 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:15 --> Total execution time: 0.1890
INFO - 2018-05-01 08:33:16 --> Config Class Initialized
INFO - 2018-05-01 08:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:16 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:16 --> URI Class Initialized
INFO - 2018-05-01 08:33:16 --> Router Class Initialized
INFO - 2018-05-01 08:33:16 --> Output Class Initialized
INFO - 2018-05-01 08:33:16 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:16 --> Input Class Initialized
INFO - 2018-05-01 08:33:16 --> Language Class Initialized
INFO - 2018-05-01 08:33:16 --> Loader Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:16 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:16 --> Config Class Initialized
INFO - 2018-05-01 08:33:16 --> Hooks Class Initialized
INFO - 2018-05-01 08:33:16 --> Email Class Initialized
INFO - 2018-05-01 08:33:16 --> Controller Class Initialized
DEBUG - 2018-05-01 08:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:16 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:16 --> URI Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:16 --> Router Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Output Class Initialized
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:16 --> Input Class Initialized
INFO - 2018-05-01 08:33:16 --> Language Class Initialized
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:16 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:16 --> Total execution time: 0.1820
INFO - 2018-05-01 08:33:16 --> Loader Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:16 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:16 --> Email Class Initialized
INFO - 2018-05-01 08:33:16 --> Controller Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:16 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:16 --> Total execution time: 0.1850
INFO - 2018-05-01 08:33:16 --> Config Class Initialized
INFO - 2018-05-01 08:33:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:16 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:16 --> URI Class Initialized
INFO - 2018-05-01 08:33:16 --> Router Class Initialized
INFO - 2018-05-01 08:33:16 --> Output Class Initialized
INFO - 2018-05-01 08:33:16 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:16 --> Input Class Initialized
INFO - 2018-05-01 08:33:16 --> Language Class Initialized
INFO - 2018-05-01 08:33:16 --> Loader Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:16 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:16 --> Email Class Initialized
INFO - 2018-05-01 08:33:16 --> Controller Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:16 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:16 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 08:33:16 --> Model Class Initialized
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/editNews.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:16 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:16 --> Total execution time: 0.1780
INFO - 2018-05-01 08:33:18 --> Config Class Initialized
INFO - 2018-05-01 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:18 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:18 --> URI Class Initialized
INFO - 2018-05-01 08:33:18 --> Router Class Initialized
INFO - 2018-05-01 08:33:18 --> Output Class Initialized
INFO - 2018-05-01 08:33:18 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:18 --> Input Class Initialized
INFO - 2018-05-01 08:33:18 --> Language Class Initialized
INFO - 2018-05-01 08:33:18 --> Loader Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:18 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:18 --> Email Class Initialized
INFO - 2018-05-01 08:33:18 --> Controller Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:18 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:18 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Config Class Initialized
INFO - 2018-05-01 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:18 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:18 --> URI Class Initialized
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:33:18 --> Router Class Initialized
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:33:18 --> Output Class Initialized
INFO - 2018-05-01 12:03:18 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:18 --> Total execution time: 0.1560
INFO - 2018-05-01 08:33:18 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:18 --> Input Class Initialized
INFO - 2018-05-01 08:33:18 --> Language Class Initialized
INFO - 2018-05-01 08:33:18 --> Loader Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:18 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:18 --> Email Class Initialized
INFO - 2018-05-01 08:33:18 --> Controller Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:18 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:18 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:18 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:18 --> Total execution time: 0.1450
INFO - 2018-05-01 08:33:18 --> Config Class Initialized
INFO - 2018-05-01 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:18 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:18 --> URI Class Initialized
INFO - 2018-05-01 08:33:18 --> Router Class Initialized
INFO - 2018-05-01 08:33:18 --> Output Class Initialized
INFO - 2018-05-01 08:33:18 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:18 --> Input Class Initialized
INFO - 2018-05-01 08:33:18 --> Language Class Initialized
INFO - 2018-05-01 08:33:18 --> Loader Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:18 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:18 --> Email Class Initialized
INFO - 2018-05-01 08:33:18 --> Controller Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:18 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:18 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:18 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:18 --> Total execution time: 0.1820
INFO - 2018-05-01 08:33:18 --> Config Class Initialized
INFO - 2018-05-01 08:33:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:18 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:18 --> URI Class Initialized
INFO - 2018-05-01 08:33:18 --> Router Class Initialized
INFO - 2018-05-01 08:33:18 --> Output Class Initialized
INFO - 2018-05-01 08:33:18 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:18 --> Input Class Initialized
INFO - 2018-05-01 08:33:18 --> Language Class Initialized
INFO - 2018-05-01 08:33:18 --> Loader Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:18 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:18 --> Email Class Initialized
INFO - 2018-05-01 08:33:18 --> Controller Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:18 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:18 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 08:33:18 --> Model Class Initialized
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/addNews.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:18 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:18 --> Total execution time: 0.1520
INFO - 2018-05-01 08:33:19 --> Config Class Initialized
INFO - 2018-05-01 08:33:19 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:19 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:19 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:19 --> URI Class Initialized
INFO - 2018-05-01 08:33:19 --> Router Class Initialized
INFO - 2018-05-01 08:33:19 --> Output Class Initialized
INFO - 2018-05-01 08:33:19 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:19 --> Input Class Initialized
INFO - 2018-05-01 08:33:19 --> Language Class Initialized
INFO - 2018-05-01 08:33:19 --> Loader Class Initialized
INFO - 2018-05-01 08:33:19 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:19 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:19 --> Email Class Initialized
INFO - 2018-05-01 08:33:19 --> Controller Class Initialized
INFO - 2018-05-01 08:33:19 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:19 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:19 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:19 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:19 --> Model Class Initialized
INFO - 2018-05-01 08:33:19 --> Model Class Initialized
INFO - 2018-05-01 08:33:19 --> Model Class Initialized
INFO - 2018-05-01 12:03:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\News/news.php
INFO - 2018-05-01 12:03:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:19 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:19 --> Total execution time: 0.1560
INFO - 2018-05-01 08:33:20 --> Config Class Initialized
INFO - 2018-05-01 08:33:20 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:20 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:20 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:20 --> URI Class Initialized
INFO - 2018-05-01 08:33:20 --> Router Class Initialized
INFO - 2018-05-01 08:33:20 --> Output Class Initialized
INFO - 2018-05-01 08:33:20 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:20 --> Input Class Initialized
INFO - 2018-05-01 08:33:20 --> Language Class Initialized
INFO - 2018-05-01 08:33:20 --> Loader Class Initialized
INFO - 2018-05-01 08:33:20 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:20 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:20 --> Email Class Initialized
INFO - 2018-05-01 08:33:20 --> Controller Class Initialized
INFO - 2018-05-01 08:33:20 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:20 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:20 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:20 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:20 --> Model Class Initialized
INFO - 2018-05-01 08:33:20 --> Model Class Initialized
INFO - 2018-05-01 08:33:20 --> Model Class Initialized
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:20 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:20 --> Total execution time: 0.1350
INFO - 2018-05-01 08:33:20 --> Config Class Initialized
INFO - 2018-05-01 08:33:20 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:20 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:20 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:20 --> URI Class Initialized
INFO - 2018-05-01 08:33:20 --> Router Class Initialized
INFO - 2018-05-01 08:33:20 --> Output Class Initialized
INFO - 2018-05-01 08:33:20 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:20 --> Input Class Initialized
INFO - 2018-05-01 08:33:20 --> Language Class Initialized
INFO - 2018-05-01 08:33:20 --> Loader Class Initialized
INFO - 2018-05-01 08:33:20 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:20 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:20 --> Email Class Initialized
INFO - 2018-05-01 08:33:20 --> Controller Class Initialized
INFO - 2018-05-01 08:33:20 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:20 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:20 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:20 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:20 --> Model Class Initialized
INFO - 2018-05-01 08:33:20 --> Model Class Initialized
INFO - 2018-05-01 08:33:20 --> Model Class Initialized
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-01 12:03:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:20 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:20 --> Total execution time: 0.1320
INFO - 2018-05-01 08:33:22 --> Config Class Initialized
INFO - 2018-05-01 08:33:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:22 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:22 --> URI Class Initialized
INFO - 2018-05-01 08:33:22 --> Router Class Initialized
INFO - 2018-05-01 08:33:22 --> Output Class Initialized
INFO - 2018-05-01 08:33:22 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:22 --> Input Class Initialized
INFO - 2018-05-01 08:33:22 --> Language Class Initialized
INFO - 2018-05-01 08:33:22 --> Loader Class Initialized
INFO - 2018-05-01 08:33:22 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:22 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:22 --> Email Class Initialized
INFO - 2018-05-01 08:33:22 --> Controller Class Initialized
INFO - 2018-05-01 08:33:22 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:22 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:22 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:22 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:22 --> Model Class Initialized
INFO - 2018-05-01 08:33:22 --> Model Class Initialized
INFO - 2018-05-01 08:33:22 --> Model Class Initialized
INFO - 2018-05-01 12:03:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:03:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:22 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:22 --> Total execution time: 0.1410
INFO - 2018-05-01 08:33:24 --> Config Class Initialized
INFO - 2018-05-01 08:33:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:24 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:24 --> URI Class Initialized
INFO - 2018-05-01 08:33:24 --> Router Class Initialized
INFO - 2018-05-01 08:33:24 --> Output Class Initialized
INFO - 2018-05-01 08:33:24 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:24 --> Input Class Initialized
INFO - 2018-05-01 08:33:24 --> Language Class Initialized
INFO - 2018-05-01 08:33:24 --> Loader Class Initialized
INFO - 2018-05-01 08:33:24 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:24 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:24 --> Email Class Initialized
INFO - 2018-05-01 08:33:24 --> Controller Class Initialized
INFO - 2018-05-01 08:33:24 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:24 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:24 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:25 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:25 --> Model Class Initialized
INFO - 2018-05-01 08:33:25 --> Model Class Initialized
INFO - 2018-05-01 08:33:25 --> Model Class Initialized
INFO - 2018-05-01 12:03:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-01 12:03:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:25 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:25 --> Total execution time: 0.1700
INFO - 2018-05-01 08:33:28 --> Config Class Initialized
INFO - 2018-05-01 08:33:28 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:28 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:28 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:28 --> URI Class Initialized
INFO - 2018-05-01 08:33:28 --> Router Class Initialized
INFO - 2018-05-01 08:33:28 --> Output Class Initialized
INFO - 2018-05-01 08:33:28 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:28 --> Input Class Initialized
INFO - 2018-05-01 08:33:28 --> Language Class Initialized
INFO - 2018-05-01 08:33:28 --> Loader Class Initialized
INFO - 2018-05-01 08:33:28 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:28 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:28 --> Email Class Initialized
INFO - 2018-05-01 08:33:28 --> Controller Class Initialized
INFO - 2018-05-01 08:33:28 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:28 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:28 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:28 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:28 --> Model Class Initialized
INFO - 2018-05-01 08:33:28 --> Model Class Initialized
INFO - 2018-05-01 08:33:28 --> Model Class Initialized
INFO - 2018-05-01 12:03:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/addWishes.php
INFO - 2018-05-01 12:03:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:28 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:28 --> Total execution time: 0.1300
INFO - 2018-05-01 08:33:37 --> Config Class Initialized
INFO - 2018-05-01 08:33:37 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:37 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:37 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:37 --> URI Class Initialized
INFO - 2018-05-01 08:33:37 --> Router Class Initialized
INFO - 2018-05-01 08:33:37 --> Output Class Initialized
INFO - 2018-05-01 08:33:37 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:37 --> Input Class Initialized
INFO - 2018-05-01 08:33:37 --> Language Class Initialized
INFO - 2018-05-01 08:33:37 --> Loader Class Initialized
INFO - 2018-05-01 08:33:37 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:37 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:37 --> Email Class Initialized
INFO - 2018-05-01 08:33:37 --> Controller Class Initialized
INFO - 2018-05-01 08:33:37 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:37 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:37 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:37 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:37 --> Model Class Initialized
INFO - 2018-05-01 08:33:37 --> Model Class Initialized
INFO - 2018-05-01 08:33:37 --> Model Class Initialized
DEBUG - 2018-05-01 12:03:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:33:38 --> Config Class Initialized
INFO - 2018-05-01 08:33:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:38 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:38 --> URI Class Initialized
INFO - 2018-05-01 08:33:38 --> Router Class Initialized
INFO - 2018-05-01 08:33:38 --> Output Class Initialized
INFO - 2018-05-01 08:33:38 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:38 --> Input Class Initialized
INFO - 2018-05-01 08:33:38 --> Language Class Initialized
INFO - 2018-05-01 08:33:38 --> Loader Class Initialized
INFO - 2018-05-01 08:33:38 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:38 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:38 --> Email Class Initialized
INFO - 2018-05-01 08:33:38 --> Controller Class Initialized
INFO - 2018-05-01 08:33:38 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:38 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:38 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:38 --> Model Class Initialized
INFO - 2018-05-01 08:33:38 --> Model Class Initialized
INFO - 2018-05-01 08:33:38 --> Model Class Initialized
INFO - 2018-05-01 12:03:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-01 12:03:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:38 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:38 --> Total execution time: 0.1350
INFO - 2018-05-01 08:33:42 --> Config Class Initialized
INFO - 2018-05-01 08:33:42 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:42 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:42 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:42 --> URI Class Initialized
INFO - 2018-05-01 08:33:42 --> Router Class Initialized
INFO - 2018-05-01 08:33:42 --> Output Class Initialized
INFO - 2018-05-01 08:33:42 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:42 --> Input Class Initialized
INFO - 2018-05-01 08:33:42 --> Language Class Initialized
INFO - 2018-05-01 08:33:42 --> Loader Class Initialized
INFO - 2018-05-01 08:33:42 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:42 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:43 --> Email Class Initialized
INFO - 2018-05-01 08:33:43 --> Controller Class Initialized
INFO - 2018-05-01 08:33:43 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:43 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:43 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:43 --> Model Class Initialized
INFO - 2018-05-01 08:33:43 --> Model Class Initialized
INFO - 2018-05-01 08:33:43 --> Model Class Initialized
INFO - 2018-05-01 12:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/editWishes.php
INFO - 2018-05-01 12:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:43 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:43 --> Total execution time: 0.1710
INFO - 2018-05-01 08:33:49 --> Config Class Initialized
INFO - 2018-05-01 08:33:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:49 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:49 --> URI Class Initialized
INFO - 2018-05-01 08:33:49 --> Router Class Initialized
INFO - 2018-05-01 08:33:49 --> Output Class Initialized
INFO - 2018-05-01 08:33:49 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:49 --> Input Class Initialized
INFO - 2018-05-01 08:33:49 --> Language Class Initialized
INFO - 2018-05-01 08:33:49 --> Loader Class Initialized
INFO - 2018-05-01 08:33:49 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:49 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:49 --> Email Class Initialized
INFO - 2018-05-01 08:33:49 --> Controller Class Initialized
INFO - 2018-05-01 08:33:49 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:49 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:49 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:49 --> Model Class Initialized
INFO - 2018-05-01 08:33:49 --> Model Class Initialized
INFO - 2018-05-01 08:33:49 --> Model Class Initialized
DEBUG - 2018-05-01 12:03:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:03:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:33:49 --> Config Class Initialized
INFO - 2018-05-01 08:33:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:49 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:49 --> URI Class Initialized
INFO - 2018-05-01 08:33:49 --> Router Class Initialized
INFO - 2018-05-01 08:33:49 --> Output Class Initialized
INFO - 2018-05-01 08:33:49 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:49 --> Input Class Initialized
INFO - 2018-05-01 08:33:49 --> Language Class Initialized
INFO - 2018-05-01 08:33:49 --> Loader Class Initialized
INFO - 2018-05-01 08:33:49 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:49 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:49 --> Email Class Initialized
INFO - 2018-05-01 08:33:49 --> Controller Class Initialized
INFO - 2018-05-01 08:33:49 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:49 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:49 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:49 --> Model Class Initialized
INFO - 2018-05-01 08:33:49 --> Model Class Initialized
INFO - 2018-05-01 08:33:49 --> Model Class Initialized
INFO - 2018-05-01 12:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-01 12:03:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:49 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:49 --> Total execution time: 0.1260
INFO - 2018-05-01 08:33:55 --> Config Class Initialized
INFO - 2018-05-01 08:33:55 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:55 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:55 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:55 --> URI Class Initialized
INFO - 2018-05-01 08:33:55 --> Router Class Initialized
INFO - 2018-05-01 08:33:55 --> Output Class Initialized
INFO - 2018-05-01 08:33:55 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:55 --> Input Class Initialized
INFO - 2018-05-01 08:33:55 --> Language Class Initialized
INFO - 2018-05-01 08:33:55 --> Loader Class Initialized
INFO - 2018-05-01 08:33:55 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:55 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:55 --> Email Class Initialized
INFO - 2018-05-01 08:33:55 --> Controller Class Initialized
INFO - 2018-05-01 08:33:55 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:55 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:55 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:55 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:55 --> Model Class Initialized
INFO - 2018-05-01 08:33:55 --> Model Class Initialized
INFO - 2018-05-01 08:33:55 --> Model Class Initialized
INFO - 2018-05-01 08:33:55 --> Config Class Initialized
INFO - 2018-05-01 08:33:55 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:33:55 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:33:55 --> Utf8 Class Initialized
INFO - 2018-05-01 08:33:55 --> URI Class Initialized
INFO - 2018-05-01 08:33:55 --> Router Class Initialized
INFO - 2018-05-01 08:33:55 --> Output Class Initialized
INFO - 2018-05-01 08:33:55 --> Security Class Initialized
DEBUG - 2018-05-01 08:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:33:55 --> Input Class Initialized
INFO - 2018-05-01 08:33:55 --> Language Class Initialized
INFO - 2018-05-01 08:33:55 --> Loader Class Initialized
INFO - 2018-05-01 08:33:55 --> Helper loaded: common_helper
INFO - 2018-05-01 08:33:55 --> Database Driver Class Initialized
INFO - 2018-05-01 08:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:33:55 --> Email Class Initialized
INFO - 2018-05-01 08:33:55 --> Controller Class Initialized
INFO - 2018-05-01 08:33:55 --> Helper loaded: form_helper
INFO - 2018-05-01 08:33:55 --> Form Validation Class Initialized
INFO - 2018-05-01 08:33:55 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:33:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:33:55 --> Helper loaded: url_helper
INFO - 2018-05-01 08:33:55 --> Model Class Initialized
INFO - 2018-05-01 08:33:55 --> Model Class Initialized
INFO - 2018-05-01 08:33:55 --> Model Class Initialized
INFO - 2018-05-01 12:03:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:03:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:03:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:03:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-01 12:03:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:03:55 --> Final output sent to browser
DEBUG - 2018-05-01 12:03:55 --> Total execution time: 0.1270
INFO - 2018-05-01 08:37:29 --> Config Class Initialized
INFO - 2018-05-01 08:37:29 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:29 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:29 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:29 --> URI Class Initialized
INFO - 2018-05-01 08:37:29 --> Router Class Initialized
INFO - 2018-05-01 08:37:29 --> Output Class Initialized
INFO - 2018-05-01 08:37:29 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:29 --> Input Class Initialized
INFO - 2018-05-01 08:37:29 --> Language Class Initialized
INFO - 2018-05-01 08:37:29 --> Loader Class Initialized
INFO - 2018-05-01 08:37:29 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:29 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:29 --> Email Class Initialized
INFO - 2018-05-01 08:37:29 --> Controller Class Initialized
INFO - 2018-05-01 08:37:29 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:29 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:29 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:29 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:29 --> Model Class Initialized
INFO - 2018-05-01 08:37:29 --> Model Class Initialized
INFO - 2018-05-01 08:37:29 --> Model Class Initialized
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/editWishes.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:07:29 --> Final output sent to browser
DEBUG - 2018-05-01 12:07:29 --> Total execution time: 0.2250
INFO - 2018-05-01 08:37:29 --> Config Class Initialized
INFO - 2018-05-01 08:37:29 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:29 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:29 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:29 --> URI Class Initialized
INFO - 2018-05-01 08:37:29 --> Router Class Initialized
INFO - 2018-05-01 08:37:29 --> Output Class Initialized
INFO - 2018-05-01 08:37:29 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:29 --> Input Class Initialized
INFO - 2018-05-01 08:37:29 --> Language Class Initialized
INFO - 2018-05-01 08:37:29 --> Loader Class Initialized
INFO - 2018-05-01 08:37:29 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:29 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:29 --> Email Class Initialized
INFO - 2018-05-01 08:37:29 --> Controller Class Initialized
INFO - 2018-05-01 08:37:29 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:29 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:29 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:29 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:29 --> Model Class Initialized
INFO - 2018-05-01 08:37:29 --> Model Class Initialized
INFO - 2018-05-01 08:37:29 --> Model Class Initialized
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-01 12:07:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:07:29 --> Final output sent to browser
DEBUG - 2018-05-01 12:07:29 --> Total execution time: 0.1630
INFO - 2018-05-01 08:37:31 --> Config Class Initialized
INFO - 2018-05-01 08:37:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:31 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:31 --> URI Class Initialized
INFO - 2018-05-01 08:37:31 --> Router Class Initialized
INFO - 2018-05-01 08:37:31 --> Output Class Initialized
INFO - 2018-05-01 08:37:31 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:31 --> Input Class Initialized
INFO - 2018-05-01 08:37:31 --> Language Class Initialized
INFO - 2018-05-01 08:37:31 --> Loader Class Initialized
INFO - 2018-05-01 08:37:31 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:31 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:31 --> Email Class Initialized
INFO - 2018-05-01 08:37:31 --> Controller Class Initialized
INFO - 2018-05-01 08:37:31 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:31 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:31 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:31 --> Model Class Initialized
INFO - 2018-05-01 08:37:31 --> Model Class Initialized
INFO - 2018-05-01 08:37:31 --> Model Class Initialized
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/addWishes.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:07:31 --> Final output sent to browser
DEBUG - 2018-05-01 12:07:31 --> Total execution time: 0.1450
INFO - 2018-05-01 08:37:31 --> Config Class Initialized
INFO - 2018-05-01 08:37:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:31 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:31 --> URI Class Initialized
INFO - 2018-05-01 08:37:31 --> Router Class Initialized
INFO - 2018-05-01 08:37:31 --> Output Class Initialized
INFO - 2018-05-01 08:37:31 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:31 --> Input Class Initialized
INFO - 2018-05-01 08:37:31 --> Language Class Initialized
INFO - 2018-05-01 08:37:31 --> Loader Class Initialized
INFO - 2018-05-01 08:37:31 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:31 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:31 --> Email Class Initialized
INFO - 2018-05-01 08:37:31 --> Controller Class Initialized
INFO - 2018-05-01 08:37:31 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:31 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:31 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:31 --> Model Class Initialized
INFO - 2018-05-01 08:37:31 --> Model Class Initialized
INFO - 2018-05-01 08:37:31 --> Model Class Initialized
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Wishes/wishes.php
INFO - 2018-05-01 12:07:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:07:31 --> Final output sent to browser
DEBUG - 2018-05-01 12:07:31 --> Total execution time: 0.1810
INFO - 2018-05-01 08:37:32 --> Config Class Initialized
INFO - 2018-05-01 08:37:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:32 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:32 --> URI Class Initialized
INFO - 2018-05-01 08:37:32 --> Router Class Initialized
INFO - 2018-05-01 08:37:32 --> Output Class Initialized
INFO - 2018-05-01 08:37:32 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:32 --> Input Class Initialized
INFO - 2018-05-01 08:37:32 --> Language Class Initialized
INFO - 2018-05-01 08:37:32 --> Loader Class Initialized
INFO - 2018-05-01 08:37:32 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:32 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:32 --> Email Class Initialized
INFO - 2018-05-01 08:37:32 --> Controller Class Initialized
INFO - 2018-05-01 08:37:32 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:32 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:32 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:32 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:32 --> Model Class Initialized
INFO - 2018-05-01 08:37:32 --> Model Class Initialized
INFO - 2018-05-01 08:37:32 --> Model Class Initialized
INFO - 2018-05-01 12:07:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:07:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:07:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:07:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:07:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:07:32 --> Final output sent to browser
DEBUG - 2018-05-01 12:07:32 --> Total execution time: 0.1400
INFO - 2018-05-01 08:37:35 --> Config Class Initialized
INFO - 2018-05-01 08:37:35 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:35 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:35 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:35 --> URI Class Initialized
INFO - 2018-05-01 08:37:35 --> Router Class Initialized
INFO - 2018-05-01 08:37:35 --> Output Class Initialized
INFO - 2018-05-01 08:37:35 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:35 --> Input Class Initialized
INFO - 2018-05-01 08:37:35 --> Language Class Initialized
INFO - 2018-05-01 08:37:35 --> Loader Class Initialized
INFO - 2018-05-01 08:37:35 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:35 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:35 --> Email Class Initialized
INFO - 2018-05-01 08:37:35 --> Controller Class Initialized
INFO - 2018-05-01 08:37:35 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:35 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:35 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:35 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:35 --> Model Class Initialized
INFO - 2018-05-01 08:37:35 --> Model Class Initialized
INFO - 2018-05-01 08:37:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:37:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:37:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:37:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:37:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:37:35 --> Final output sent to browser
DEBUG - 2018-05-01 08:37:35 --> Total execution time: 0.1550
INFO - 2018-05-01 08:37:38 --> Config Class Initialized
INFO - 2018-05-01 08:37:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:38 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:38 --> URI Class Initialized
INFO - 2018-05-01 08:37:38 --> Router Class Initialized
INFO - 2018-05-01 08:37:38 --> Output Class Initialized
INFO - 2018-05-01 08:37:38 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:38 --> Input Class Initialized
INFO - 2018-05-01 08:37:38 --> Language Class Initialized
INFO - 2018-05-01 08:37:38 --> Loader Class Initialized
INFO - 2018-05-01 08:37:38 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:38 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:38 --> Email Class Initialized
INFO - 2018-05-01 08:37:38 --> Controller Class Initialized
INFO - 2018-05-01 08:37:38 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:38 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:38 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:38 --> Model Class Initialized
INFO - 2018-05-01 08:37:38 --> Model Class Initialized
INFO - 2018-05-01 08:37:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:37:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:37:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:37:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/addAwards.php
INFO - 2018-05-01 08:37:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:37:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:37:38 --> Final output sent to browser
DEBUG - 2018-05-01 08:37:38 --> Total execution time: 0.1220
INFO - 2018-05-01 08:37:52 --> Config Class Initialized
INFO - 2018-05-01 08:37:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:52 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:52 --> URI Class Initialized
INFO - 2018-05-01 08:37:52 --> Router Class Initialized
INFO - 2018-05-01 08:37:52 --> Output Class Initialized
INFO - 2018-05-01 08:37:52 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:52 --> Input Class Initialized
INFO - 2018-05-01 08:37:52 --> Language Class Initialized
INFO - 2018-05-01 08:37:52 --> Loader Class Initialized
INFO - 2018-05-01 08:37:52 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:52 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:52 --> Email Class Initialized
INFO - 2018-05-01 08:37:52 --> Controller Class Initialized
INFO - 2018-05-01 08:37:52 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:52 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:52 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:52 --> Model Class Initialized
INFO - 2018-05-01 08:37:52 --> Model Class Initialized
DEBUG - 2018-05-01 08:37:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:37:52 --> Config Class Initialized
INFO - 2018-05-01 08:37:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:52 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:52 --> URI Class Initialized
INFO - 2018-05-01 08:37:52 --> Router Class Initialized
INFO - 2018-05-01 08:37:52 --> Output Class Initialized
INFO - 2018-05-01 08:37:52 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:52 --> Input Class Initialized
INFO - 2018-05-01 08:37:52 --> Language Class Initialized
INFO - 2018-05-01 08:37:52 --> Loader Class Initialized
INFO - 2018-05-01 08:37:52 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:52 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:52 --> Email Class Initialized
INFO - 2018-05-01 08:37:52 --> Controller Class Initialized
INFO - 2018-05-01 08:37:52 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:52 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:52 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:52 --> Model Class Initialized
INFO - 2018-05-01 08:37:52 --> Model Class Initialized
INFO - 2018-05-01 08:37:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:37:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:37:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:37:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:37:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:37:52 --> Final output sent to browser
DEBUG - 2018-05-01 08:37:52 --> Total execution time: 0.1250
INFO - 2018-05-01 08:37:56 --> Config Class Initialized
INFO - 2018-05-01 08:37:56 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:37:56 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:37:56 --> Utf8 Class Initialized
INFO - 2018-05-01 08:37:56 --> URI Class Initialized
INFO - 2018-05-01 08:37:56 --> Router Class Initialized
INFO - 2018-05-01 08:37:56 --> Output Class Initialized
INFO - 2018-05-01 08:37:56 --> Security Class Initialized
DEBUG - 2018-05-01 08:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:37:56 --> Input Class Initialized
INFO - 2018-05-01 08:37:56 --> Language Class Initialized
INFO - 2018-05-01 08:37:56 --> Loader Class Initialized
INFO - 2018-05-01 08:37:56 --> Helper loaded: common_helper
INFO - 2018-05-01 08:37:56 --> Database Driver Class Initialized
INFO - 2018-05-01 08:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:37:56 --> Email Class Initialized
INFO - 2018-05-01 08:37:56 --> Controller Class Initialized
INFO - 2018-05-01 08:37:56 --> Helper loaded: form_helper
INFO - 2018-05-01 08:37:56 --> Form Validation Class Initialized
INFO - 2018-05-01 08:37:56 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:37:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:37:56 --> Helper loaded: url_helper
INFO - 2018-05-01 08:37:56 --> Model Class Initialized
INFO - 2018-05-01 08:37:56 --> Model Class Initialized
INFO - 2018-05-01 08:37:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:37:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:37:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:37:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/editAwards.php
INFO - 2018-05-01 08:37:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:37:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:37:56 --> Final output sent to browser
DEBUG - 2018-05-01 08:37:56 --> Total execution time: 0.1270
INFO - 2018-05-01 08:38:10 --> Config Class Initialized
INFO - 2018-05-01 08:38:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:38:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:38:10 --> Utf8 Class Initialized
INFO - 2018-05-01 08:38:10 --> URI Class Initialized
INFO - 2018-05-01 08:38:10 --> Router Class Initialized
INFO - 2018-05-01 08:38:10 --> Output Class Initialized
INFO - 2018-05-01 08:38:10 --> Security Class Initialized
DEBUG - 2018-05-01 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:38:10 --> Input Class Initialized
INFO - 2018-05-01 08:38:10 --> Language Class Initialized
INFO - 2018-05-01 08:38:10 --> Loader Class Initialized
INFO - 2018-05-01 08:38:10 --> Helper loaded: common_helper
INFO - 2018-05-01 08:38:10 --> Database Driver Class Initialized
INFO - 2018-05-01 08:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:38:10 --> Email Class Initialized
INFO - 2018-05-01 08:38:10 --> Controller Class Initialized
INFO - 2018-05-01 08:38:10 --> Helper loaded: form_helper
INFO - 2018-05-01 08:38:10 --> Form Validation Class Initialized
INFO - 2018-05-01 08:38:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:10 --> Helper loaded: url_helper
INFO - 2018-05-01 08:38:10 --> Model Class Initialized
INFO - 2018-05-01 08:38:10 --> Model Class Initialized
DEBUG - 2018-05-01 08:38:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 08:38:10 --> Undefined offset: 2
ERROR - 2018-05-01 08:38:10 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\Celebrity\admin\application\controllers\Awards.php 252
INFO - 2018-05-01 08:38:10 --> Config Class Initialized
INFO - 2018-05-01 08:38:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:38:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:38:10 --> Utf8 Class Initialized
INFO - 2018-05-01 08:38:10 --> URI Class Initialized
INFO - 2018-05-01 08:38:10 --> Router Class Initialized
INFO - 2018-05-01 08:38:10 --> Output Class Initialized
INFO - 2018-05-01 08:38:10 --> Security Class Initialized
DEBUG - 2018-05-01 08:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:38:10 --> Input Class Initialized
INFO - 2018-05-01 08:38:10 --> Language Class Initialized
INFO - 2018-05-01 08:38:10 --> Loader Class Initialized
INFO - 2018-05-01 08:38:10 --> Helper loaded: common_helper
INFO - 2018-05-01 08:38:10 --> Database Driver Class Initialized
INFO - 2018-05-01 08:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:38:10 --> Email Class Initialized
INFO - 2018-05-01 08:38:10 --> Controller Class Initialized
INFO - 2018-05-01 08:38:10 --> Helper loaded: form_helper
INFO - 2018-05-01 08:38:10 --> Form Validation Class Initialized
INFO - 2018-05-01 08:38:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:38:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:10 --> Helper loaded: url_helper
INFO - 2018-05-01 08:38:10 --> Model Class Initialized
INFO - 2018-05-01 08:38:10 --> Model Class Initialized
INFO - 2018-05-01 08:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:38:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:38:10 --> Final output sent to browser
DEBUG - 2018-05-01 08:38:10 --> Total execution time: 0.1270
INFO - 2018-05-01 08:38:18 --> Config Class Initialized
INFO - 2018-05-01 08:38:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:38:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:38:18 --> Utf8 Class Initialized
INFO - 2018-05-01 08:38:18 --> URI Class Initialized
INFO - 2018-05-01 08:38:18 --> Router Class Initialized
INFO - 2018-05-01 08:38:18 --> Output Class Initialized
INFO - 2018-05-01 08:38:18 --> Security Class Initialized
DEBUG - 2018-05-01 08:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:38:18 --> Input Class Initialized
INFO - 2018-05-01 08:38:18 --> Language Class Initialized
INFO - 2018-05-01 08:38:18 --> Loader Class Initialized
INFO - 2018-05-01 08:38:18 --> Helper loaded: common_helper
INFO - 2018-05-01 08:38:18 --> Database Driver Class Initialized
INFO - 2018-05-01 08:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:38:18 --> Email Class Initialized
INFO - 2018-05-01 08:38:18 --> Controller Class Initialized
INFO - 2018-05-01 08:38:18 --> Helper loaded: form_helper
INFO - 2018-05-01 08:38:18 --> Form Validation Class Initialized
INFO - 2018-05-01 08:38:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:38:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:18 --> Helper loaded: url_helper
INFO - 2018-05-01 08:38:18 --> Model Class Initialized
INFO - 2018-05-01 08:38:18 --> Model Class Initialized
INFO - 2018-05-01 08:38:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:38:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:38:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:38:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/editAwards.php
INFO - 2018-05-01 08:38:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:38:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:38:18 --> Final output sent to browser
DEBUG - 2018-05-01 08:38:18 --> Total execution time: 0.1280
INFO - 2018-05-01 08:38:21 --> Config Class Initialized
INFO - 2018-05-01 08:38:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:38:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:38:21 --> Utf8 Class Initialized
INFO - 2018-05-01 08:38:21 --> URI Class Initialized
INFO - 2018-05-01 08:38:21 --> Router Class Initialized
INFO - 2018-05-01 08:38:21 --> Output Class Initialized
INFO - 2018-05-01 08:38:21 --> Security Class Initialized
DEBUG - 2018-05-01 08:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:38:21 --> Input Class Initialized
INFO - 2018-05-01 08:38:21 --> Language Class Initialized
INFO - 2018-05-01 08:38:21 --> Loader Class Initialized
INFO - 2018-05-01 08:38:21 --> Helper loaded: common_helper
INFO - 2018-05-01 08:38:21 --> Database Driver Class Initialized
INFO - 2018-05-01 08:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:38:21 --> Email Class Initialized
INFO - 2018-05-01 08:38:21 --> Controller Class Initialized
INFO - 2018-05-01 08:38:21 --> Helper loaded: form_helper
INFO - 2018-05-01 08:38:21 --> Form Validation Class Initialized
INFO - 2018-05-01 08:38:21 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:38:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:21 --> Helper loaded: url_helper
INFO - 2018-05-01 08:38:21 --> Model Class Initialized
INFO - 2018-05-01 08:38:21 --> Model Class Initialized
INFO - 2018-05-01 08:38:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:38:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:38:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:38:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:38:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:38:21 --> Final output sent to browser
DEBUG - 2018-05-01 08:38:21 --> Total execution time: 0.1920
INFO - 2018-05-01 08:38:26 --> Config Class Initialized
INFO - 2018-05-01 08:38:26 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:38:26 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:38:26 --> Utf8 Class Initialized
INFO - 2018-05-01 08:38:26 --> URI Class Initialized
INFO - 2018-05-01 08:38:26 --> Router Class Initialized
INFO - 2018-05-01 08:38:26 --> Output Class Initialized
INFO - 2018-05-01 08:38:26 --> Security Class Initialized
DEBUG - 2018-05-01 08:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:38:26 --> Input Class Initialized
INFO - 2018-05-01 08:38:26 --> Language Class Initialized
INFO - 2018-05-01 08:38:26 --> Loader Class Initialized
INFO - 2018-05-01 08:38:26 --> Helper loaded: common_helper
INFO - 2018-05-01 08:38:26 --> Database Driver Class Initialized
INFO - 2018-05-01 08:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:38:26 --> Email Class Initialized
INFO - 2018-05-01 08:38:26 --> Controller Class Initialized
INFO - 2018-05-01 08:38:26 --> Helper loaded: form_helper
INFO - 2018-05-01 08:38:26 --> Form Validation Class Initialized
INFO - 2018-05-01 08:38:26 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:26 --> Helper loaded: url_helper
INFO - 2018-05-01 08:38:26 --> Model Class Initialized
INFO - 2018-05-01 08:38:26 --> Model Class Initialized
INFO - 2018-05-01 08:38:26 --> Config Class Initialized
INFO - 2018-05-01 08:38:26 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:38:26 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:38:26 --> Utf8 Class Initialized
INFO - 2018-05-01 08:38:26 --> URI Class Initialized
INFO - 2018-05-01 08:38:26 --> Router Class Initialized
INFO - 2018-05-01 08:38:26 --> Output Class Initialized
INFO - 2018-05-01 08:38:26 --> Security Class Initialized
DEBUG - 2018-05-01 08:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:38:26 --> Input Class Initialized
INFO - 2018-05-01 08:38:26 --> Language Class Initialized
INFO - 2018-05-01 08:38:26 --> Loader Class Initialized
INFO - 2018-05-01 08:38:26 --> Helper loaded: common_helper
INFO - 2018-05-01 08:38:26 --> Database Driver Class Initialized
INFO - 2018-05-01 08:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:38:26 --> Email Class Initialized
INFO - 2018-05-01 08:38:26 --> Controller Class Initialized
INFO - 2018-05-01 08:38:26 --> Helper loaded: form_helper
INFO - 2018-05-01 08:38:26 --> Form Validation Class Initialized
INFO - 2018-05-01 08:38:26 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:38:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:38:26 --> Helper loaded: url_helper
INFO - 2018-05-01 08:38:26 --> Model Class Initialized
INFO - 2018-05-01 08:38:26 --> Model Class Initialized
INFO - 2018-05-01 08:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:38:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:38:26 --> Final output sent to browser
DEBUG - 2018-05-01 08:38:26 --> Total execution time: 0.1280
INFO - 2018-05-01 08:44:01 --> Config Class Initialized
INFO - 2018-05-01 08:44:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:01 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:01 --> URI Class Initialized
INFO - 2018-05-01 08:44:01 --> Router Class Initialized
INFO - 2018-05-01 08:44:01 --> Output Class Initialized
INFO - 2018-05-01 08:44:01 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:01 --> Input Class Initialized
INFO - 2018-05-01 08:44:01 --> Language Class Initialized
INFO - 2018-05-01 08:44:01 --> Loader Class Initialized
INFO - 2018-05-01 08:44:01 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:01 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:01 --> Email Class Initialized
INFO - 2018-05-01 08:44:01 --> Controller Class Initialized
INFO - 2018-05-01 08:44:01 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:01 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:01 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:01 --> Model Class Initialized
INFO - 2018-05-01 08:44:01 --> Model Class Initialized
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/editAwards.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:02 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:02 --> Total execution time: 0.1890
INFO - 2018-05-01 08:44:02 --> Config Class Initialized
INFO - 2018-05-01 08:44:02 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:02 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:02 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:02 --> URI Class Initialized
INFO - 2018-05-01 08:44:02 --> Router Class Initialized
INFO - 2018-05-01 08:44:02 --> Output Class Initialized
INFO - 2018-05-01 08:44:02 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:02 --> Input Class Initialized
INFO - 2018-05-01 08:44:02 --> Language Class Initialized
INFO - 2018-05-01 08:44:02 --> Loader Class Initialized
INFO - 2018-05-01 08:44:02 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:02 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:02 --> Email Class Initialized
INFO - 2018-05-01 08:44:02 --> Controller Class Initialized
INFO - 2018-05-01 08:44:02 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:02 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:02 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:02 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:02 --> Model Class Initialized
INFO - 2018-05-01 08:44:02 --> Model Class Initialized
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:44:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:02 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:02 --> Total execution time: 0.1670
INFO - 2018-05-01 08:44:03 --> Config Class Initialized
INFO - 2018-05-01 08:44:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:03 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:03 --> URI Class Initialized
INFO - 2018-05-01 08:44:03 --> Router Class Initialized
INFO - 2018-05-01 08:44:03 --> Output Class Initialized
INFO - 2018-05-01 08:44:03 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:03 --> Input Class Initialized
INFO - 2018-05-01 08:44:03 --> Language Class Initialized
INFO - 2018-05-01 08:44:03 --> Loader Class Initialized
INFO - 2018-05-01 08:44:03 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:03 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:03 --> Email Class Initialized
INFO - 2018-05-01 08:44:03 --> Controller Class Initialized
INFO - 2018-05-01 08:44:03 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:03 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:03 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:03 --> Model Class Initialized
INFO - 2018-05-01 08:44:03 --> Model Class Initialized
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/addAwards.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:03 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:03 --> Total execution time: 0.1370
INFO - 2018-05-01 08:44:03 --> Config Class Initialized
INFO - 2018-05-01 08:44:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:03 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:03 --> URI Class Initialized
INFO - 2018-05-01 08:44:03 --> Router Class Initialized
INFO - 2018-05-01 08:44:03 --> Output Class Initialized
INFO - 2018-05-01 08:44:03 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:03 --> Input Class Initialized
INFO - 2018-05-01 08:44:03 --> Language Class Initialized
INFO - 2018-05-01 08:44:03 --> Loader Class Initialized
INFO - 2018-05-01 08:44:03 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:03 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:03 --> Email Class Initialized
INFO - 2018-05-01 08:44:03 --> Controller Class Initialized
INFO - 2018-05-01 08:44:03 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:03 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:03 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:03 --> Model Class Initialized
INFO - 2018-05-01 08:44:03 --> Model Class Initialized
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\awards/awards.php
INFO - 2018-05-01 08:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:03 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:03 --> Total execution time: 0.1850
INFO - 2018-05-01 08:44:05 --> Config Class Initialized
INFO - 2018-05-01 08:44:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:05 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:05 --> URI Class Initialized
INFO - 2018-05-01 08:44:05 --> Router Class Initialized
INFO - 2018-05-01 08:44:05 --> Output Class Initialized
INFO - 2018-05-01 08:44:05 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:05 --> Input Class Initialized
INFO - 2018-05-01 08:44:05 --> Language Class Initialized
INFO - 2018-05-01 08:44:05 --> Loader Class Initialized
INFO - 2018-05-01 08:44:05 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:05 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:05 --> Email Class Initialized
INFO - 2018-05-01 08:44:05 --> Controller Class Initialized
INFO - 2018-05-01 08:44:05 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:05 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:05 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:05 --> Model Class Initialized
INFO - 2018-05-01 08:44:05 --> Model Class Initialized
INFO - 2018-05-01 08:44:05 --> Model Class Initialized
INFO - 2018-05-01 12:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:14:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:14:05 --> Final output sent to browser
DEBUG - 2018-05-01 12:14:05 --> Total execution time: 0.1360
INFO - 2018-05-01 08:44:07 --> Config Class Initialized
INFO - 2018-05-01 08:44:07 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:07 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:07 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:07 --> URI Class Initialized
INFO - 2018-05-01 08:44:07 --> Router Class Initialized
INFO - 2018-05-01 08:44:07 --> Output Class Initialized
INFO - 2018-05-01 08:44:07 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:07 --> Input Class Initialized
INFO - 2018-05-01 08:44:07 --> Language Class Initialized
INFO - 2018-05-01 08:44:07 --> Loader Class Initialized
INFO - 2018-05-01 08:44:07 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:07 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:07 --> Email Class Initialized
INFO - 2018-05-01 08:44:07 --> Controller Class Initialized
INFO - 2018-05-01 08:44:07 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:07 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:07 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:07 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:07 --> Model Class Initialized
INFO - 2018-05-01 08:44:07 --> Model Class Initialized
INFO - 2018-05-01 08:44:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:44:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:08 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:08 --> Total execution time: 0.2730
INFO - 2018-05-01 08:44:11 --> Config Class Initialized
INFO - 2018-05-01 08:44:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:11 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:11 --> URI Class Initialized
INFO - 2018-05-01 08:44:11 --> Router Class Initialized
INFO - 2018-05-01 08:44:11 --> Output Class Initialized
INFO - 2018-05-01 08:44:11 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:11 --> Input Class Initialized
INFO - 2018-05-01 08:44:11 --> Language Class Initialized
INFO - 2018-05-01 08:44:11 --> Loader Class Initialized
INFO - 2018-05-01 08:44:11 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:11 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:11 --> Email Class Initialized
INFO - 2018-05-01 08:44:11 --> Controller Class Initialized
INFO - 2018-05-01 08:44:11 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:11 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:11 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:11 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:11 --> Model Class Initialized
INFO - 2018-05-01 08:44:11 --> Model Class Initialized
INFO - 2018-05-01 08:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/addFoundation.php
INFO - 2018-05-01 08:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:11 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:11 --> Total execution time: 0.1260
INFO - 2018-05-01 08:44:27 --> Config Class Initialized
INFO - 2018-05-01 08:44:27 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:27 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:27 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:27 --> URI Class Initialized
INFO - 2018-05-01 08:44:27 --> Router Class Initialized
INFO - 2018-05-01 08:44:27 --> Output Class Initialized
INFO - 2018-05-01 08:44:27 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:27 --> Input Class Initialized
INFO - 2018-05-01 08:44:27 --> Language Class Initialized
INFO - 2018-05-01 08:44:27 --> Loader Class Initialized
INFO - 2018-05-01 08:44:27 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:27 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:27 --> Email Class Initialized
INFO - 2018-05-01 08:44:27 --> Controller Class Initialized
INFO - 2018-05-01 08:44:27 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:27 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:27 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:27 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:27 --> Model Class Initialized
INFO - 2018-05-01 08:44:27 --> Model Class Initialized
DEBUG - 2018-05-01 08:44:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:44:28 --> Config Class Initialized
INFO - 2018-05-01 08:44:28 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:28 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:28 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:28 --> URI Class Initialized
INFO - 2018-05-01 08:44:28 --> Router Class Initialized
INFO - 2018-05-01 08:44:28 --> Output Class Initialized
INFO - 2018-05-01 08:44:28 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:28 --> Input Class Initialized
INFO - 2018-05-01 08:44:28 --> Language Class Initialized
INFO - 2018-05-01 08:44:28 --> Loader Class Initialized
INFO - 2018-05-01 08:44:28 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:28 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:28 --> Email Class Initialized
INFO - 2018-05-01 08:44:28 --> Controller Class Initialized
INFO - 2018-05-01 08:44:28 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:28 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:28 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:28 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:28 --> Model Class Initialized
INFO - 2018-05-01 08:44:28 --> Model Class Initialized
INFO - 2018-05-01 08:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:44:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:28 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:28 --> Total execution time: 0.1280
INFO - 2018-05-01 08:44:32 --> Config Class Initialized
INFO - 2018-05-01 08:44:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:32 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:32 --> URI Class Initialized
INFO - 2018-05-01 08:44:32 --> Router Class Initialized
INFO - 2018-05-01 08:44:32 --> Output Class Initialized
INFO - 2018-05-01 08:44:32 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:32 --> Input Class Initialized
INFO - 2018-05-01 08:44:32 --> Language Class Initialized
INFO - 2018-05-01 08:44:32 --> Loader Class Initialized
INFO - 2018-05-01 08:44:32 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:32 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:32 --> Email Class Initialized
INFO - 2018-05-01 08:44:32 --> Controller Class Initialized
INFO - 2018-05-01 08:44:32 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:32 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:32 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:32 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:32 --> Model Class Initialized
INFO - 2018-05-01 08:44:32 --> Model Class Initialized
INFO - 2018-05-01 08:44:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/addFoundation.php
INFO - 2018-05-01 08:44:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:32 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:32 --> Total execution time: 0.1230
INFO - 2018-05-01 08:44:44 --> Config Class Initialized
INFO - 2018-05-01 08:44:44 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:44 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:44 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:44 --> URI Class Initialized
INFO - 2018-05-01 08:44:44 --> Router Class Initialized
INFO - 2018-05-01 08:44:44 --> Output Class Initialized
INFO - 2018-05-01 08:44:44 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:44 --> Input Class Initialized
INFO - 2018-05-01 08:44:44 --> Language Class Initialized
INFO - 2018-05-01 08:44:44 --> Loader Class Initialized
INFO - 2018-05-01 08:44:44 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:44 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:44 --> Email Class Initialized
INFO - 2018-05-01 08:44:44 --> Controller Class Initialized
INFO - 2018-05-01 08:44:44 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:44 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:44 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:44 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:44 --> Model Class Initialized
INFO - 2018-05-01 08:44:44 --> Model Class Initialized
DEBUG - 2018-05-01 08:44:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:44:44 --> Config Class Initialized
INFO - 2018-05-01 08:44:44 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:44:44 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:44:44 --> Utf8 Class Initialized
INFO - 2018-05-01 08:44:44 --> URI Class Initialized
INFO - 2018-05-01 08:44:44 --> Router Class Initialized
INFO - 2018-05-01 08:44:44 --> Output Class Initialized
INFO - 2018-05-01 08:44:44 --> Security Class Initialized
DEBUG - 2018-05-01 08:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:44:45 --> Input Class Initialized
INFO - 2018-05-01 08:44:45 --> Language Class Initialized
INFO - 2018-05-01 08:44:45 --> Loader Class Initialized
INFO - 2018-05-01 08:44:45 --> Helper loaded: common_helper
INFO - 2018-05-01 08:44:45 --> Database Driver Class Initialized
INFO - 2018-05-01 08:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:44:45 --> Email Class Initialized
INFO - 2018-05-01 08:44:45 --> Controller Class Initialized
INFO - 2018-05-01 08:44:45 --> Helper loaded: form_helper
INFO - 2018-05-01 08:44:45 --> Form Validation Class Initialized
INFO - 2018-05-01 08:44:45 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:44:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:44:45 --> Helper loaded: url_helper
INFO - 2018-05-01 08:44:45 --> Model Class Initialized
INFO - 2018-05-01 08:44:45 --> Model Class Initialized
INFO - 2018-05-01 08:44:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:44:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:44:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:44:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:44:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:44:45 --> Final output sent to browser
DEBUG - 2018-05-01 08:44:45 --> Total execution time: 0.1290
INFO - 2018-05-01 08:45:13 --> Config Class Initialized
INFO - 2018-05-01 08:45:13 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:13 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:13 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:13 --> URI Class Initialized
INFO - 2018-05-01 08:45:13 --> Router Class Initialized
INFO - 2018-05-01 08:45:13 --> Output Class Initialized
INFO - 2018-05-01 08:45:13 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:13 --> Input Class Initialized
INFO - 2018-05-01 08:45:13 --> Language Class Initialized
INFO - 2018-05-01 08:45:13 --> Loader Class Initialized
INFO - 2018-05-01 08:45:13 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:13 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:13 --> Email Class Initialized
INFO - 2018-05-01 08:45:13 --> Controller Class Initialized
INFO - 2018-05-01 08:45:13 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:13 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:13 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:13 --> Model Class Initialized
INFO - 2018-05-01 08:45:13 --> Model Class Initialized
INFO - 2018-05-01 08:45:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:45:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:13 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:13 --> Total execution time: 0.1360
INFO - 2018-05-01 08:45:26 --> Config Class Initialized
INFO - 2018-05-01 08:45:26 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:26 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:26 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:26 --> URI Class Initialized
INFO - 2018-05-01 08:45:26 --> Router Class Initialized
INFO - 2018-05-01 08:45:26 --> Output Class Initialized
INFO - 2018-05-01 08:45:26 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:26 --> Input Class Initialized
INFO - 2018-05-01 08:45:26 --> Language Class Initialized
INFO - 2018-05-01 08:45:26 --> Loader Class Initialized
INFO - 2018-05-01 08:45:26 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:26 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:26 --> Email Class Initialized
INFO - 2018-05-01 08:45:26 --> Controller Class Initialized
INFO - 2018-05-01 08:45:26 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:26 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:27 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:27 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:27 --> Model Class Initialized
INFO - 2018-05-01 08:45:27 --> Model Class Initialized
DEBUG - 2018-05-01 08:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:27 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 08:45:27 --> Undefined offset: 2
ERROR - 2018-05-01 08:45:27 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\Celebrity\admin\application\controllers\Foundations.php 258
INFO - 2018-05-01 08:45:27 --> Config Class Initialized
INFO - 2018-05-01 08:45:27 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:27 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:27 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:27 --> URI Class Initialized
INFO - 2018-05-01 08:45:27 --> Router Class Initialized
INFO - 2018-05-01 08:45:27 --> Output Class Initialized
INFO - 2018-05-01 08:45:27 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:27 --> Input Class Initialized
INFO - 2018-05-01 08:45:27 --> Language Class Initialized
INFO - 2018-05-01 08:45:27 --> Loader Class Initialized
INFO - 2018-05-01 08:45:27 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:27 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:27 --> Email Class Initialized
INFO - 2018-05-01 08:45:27 --> Controller Class Initialized
INFO - 2018-05-01 08:45:27 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:27 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:27 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:27 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:27 --> Model Class Initialized
INFO - 2018-05-01 08:45:27 --> Model Class Initialized
INFO - 2018-05-01 08:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:45:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:27 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:27 --> Total execution time: 0.1310
INFO - 2018-05-01 08:45:31 --> Config Class Initialized
INFO - 2018-05-01 08:45:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:31 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:31 --> URI Class Initialized
INFO - 2018-05-01 08:45:31 --> Router Class Initialized
INFO - 2018-05-01 08:45:31 --> Output Class Initialized
INFO - 2018-05-01 08:45:31 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:31 --> Input Class Initialized
INFO - 2018-05-01 08:45:31 --> Language Class Initialized
INFO - 2018-05-01 08:45:31 --> Loader Class Initialized
INFO - 2018-05-01 08:45:31 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:31 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:31 --> Email Class Initialized
INFO - 2018-05-01 08:45:31 --> Controller Class Initialized
INFO - 2018-05-01 08:45:31 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:31 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:31 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:31 --> Model Class Initialized
INFO - 2018-05-01 08:45:31 --> Model Class Initialized
INFO - 2018-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:31 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:31 --> Total execution time: 0.1690
INFO - 2018-05-01 08:45:39 --> Config Class Initialized
INFO - 2018-05-01 08:45:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:39 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:39 --> URI Class Initialized
INFO - 2018-05-01 08:45:39 --> Router Class Initialized
INFO - 2018-05-01 08:45:39 --> Output Class Initialized
INFO - 2018-05-01 08:45:39 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:39 --> Input Class Initialized
INFO - 2018-05-01 08:45:39 --> Language Class Initialized
INFO - 2018-05-01 08:45:39 --> Loader Class Initialized
INFO - 2018-05-01 08:45:39 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:39 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:39 --> Email Class Initialized
INFO - 2018-05-01 08:45:39 --> Controller Class Initialized
INFO - 2018-05-01 08:45:39 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:39 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:39 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:39 --> Model Class Initialized
INFO - 2018-05-01 08:45:39 --> Model Class Initialized
DEBUG - 2018-05-01 08:45:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 08:45:39 --> Invalid argument supplied for foreach()
ERROR - 2018-05-01 08:45:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Celebrity\admin\application\controllers\Foundations.php 243
INFO - 2018-05-01 08:45:39 --> Config Class Initialized
INFO - 2018-05-01 08:45:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:39 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:39 --> URI Class Initialized
INFO - 2018-05-01 08:45:39 --> Router Class Initialized
INFO - 2018-05-01 08:45:39 --> Output Class Initialized
INFO - 2018-05-01 08:45:39 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:39 --> Input Class Initialized
INFO - 2018-05-01 08:45:39 --> Language Class Initialized
INFO - 2018-05-01 08:45:39 --> Loader Class Initialized
INFO - 2018-05-01 08:45:39 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:39 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:39 --> Email Class Initialized
INFO - 2018-05-01 08:45:39 --> Controller Class Initialized
INFO - 2018-05-01 08:45:39 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:39 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:39 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:39 --> Model Class Initialized
INFO - 2018-05-01 08:45:39 --> Model Class Initialized
INFO - 2018-05-01 08:45:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:45:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:39 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:39 --> Total execution time: 0.1240
INFO - 2018-05-01 08:45:43 --> Config Class Initialized
INFO - 2018-05-01 08:45:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:43 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:43 --> URI Class Initialized
INFO - 2018-05-01 08:45:43 --> Router Class Initialized
INFO - 2018-05-01 08:45:43 --> Output Class Initialized
INFO - 2018-05-01 08:45:43 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:43 --> Input Class Initialized
INFO - 2018-05-01 08:45:43 --> Language Class Initialized
INFO - 2018-05-01 08:45:43 --> Loader Class Initialized
INFO - 2018-05-01 08:45:43 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:43 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:43 --> Email Class Initialized
INFO - 2018-05-01 08:45:43 --> Controller Class Initialized
INFO - 2018-05-01 08:45:43 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:43 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:43 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:43 --> Model Class Initialized
INFO - 2018-05-01 08:45:43 --> Model Class Initialized
INFO - 2018-05-01 08:45:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:45:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:43 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:43 --> Total execution time: 0.1300
INFO - 2018-05-01 08:45:45 --> Config Class Initialized
INFO - 2018-05-01 08:45:45 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:45 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:45 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:45 --> URI Class Initialized
INFO - 2018-05-01 08:45:45 --> Router Class Initialized
INFO - 2018-05-01 08:45:45 --> Output Class Initialized
INFO - 2018-05-01 08:45:45 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:45 --> Input Class Initialized
INFO - 2018-05-01 08:45:45 --> Language Class Initialized
INFO - 2018-05-01 08:45:45 --> Loader Class Initialized
INFO - 2018-05-01 08:45:45 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:45 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:45 --> Email Class Initialized
INFO - 2018-05-01 08:45:45 --> Controller Class Initialized
INFO - 2018-05-01 08:45:45 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:45 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:45 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:45 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:45 --> Model Class Initialized
INFO - 2018-05-01 08:45:45 --> Model Class Initialized
INFO - 2018-05-01 08:45:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:45:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:45 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:45 --> Total execution time: 0.1360
INFO - 2018-05-01 08:45:47 --> Config Class Initialized
INFO - 2018-05-01 08:45:47 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:47 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:47 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:47 --> URI Class Initialized
INFO - 2018-05-01 08:45:47 --> Router Class Initialized
INFO - 2018-05-01 08:45:47 --> Output Class Initialized
INFO - 2018-05-01 08:45:47 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:47 --> Input Class Initialized
INFO - 2018-05-01 08:45:47 --> Language Class Initialized
INFO - 2018-05-01 08:45:47 --> Loader Class Initialized
INFO - 2018-05-01 08:45:47 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:47 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:47 --> Email Class Initialized
INFO - 2018-05-01 08:45:47 --> Controller Class Initialized
INFO - 2018-05-01 08:45:47 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:47 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:47 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:47 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:47 --> Model Class Initialized
INFO - 2018-05-01 08:45:47 --> Model Class Initialized
INFO - 2018-05-01 08:45:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:45:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:47 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:47 --> Total execution time: 0.1370
INFO - 2018-05-01 08:45:51 --> Config Class Initialized
INFO - 2018-05-01 08:45:51 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:45:51 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:45:51 --> Utf8 Class Initialized
INFO - 2018-05-01 08:45:51 --> URI Class Initialized
INFO - 2018-05-01 08:45:51 --> Router Class Initialized
INFO - 2018-05-01 08:45:51 --> Output Class Initialized
INFO - 2018-05-01 08:45:51 --> Security Class Initialized
DEBUG - 2018-05-01 08:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:45:51 --> Input Class Initialized
INFO - 2018-05-01 08:45:51 --> Language Class Initialized
INFO - 2018-05-01 08:45:51 --> Loader Class Initialized
INFO - 2018-05-01 08:45:51 --> Helper loaded: common_helper
INFO - 2018-05-01 08:45:51 --> Database Driver Class Initialized
INFO - 2018-05-01 08:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:45:51 --> Email Class Initialized
INFO - 2018-05-01 08:45:51 --> Controller Class Initialized
INFO - 2018-05-01 08:45:51 --> Helper loaded: form_helper
INFO - 2018-05-01 08:45:51 --> Form Validation Class Initialized
INFO - 2018-05-01 08:45:51 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:45:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:45:51 --> Helper loaded: url_helper
INFO - 2018-05-01 08:45:51 --> Model Class Initialized
INFO - 2018-05-01 08:45:51 --> Model Class Initialized
INFO - 2018-05-01 08:45:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:45:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:45:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:45:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:45:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:45:51 --> Final output sent to browser
DEBUG - 2018-05-01 08:45:51 --> Total execution time: 0.1390
INFO - 2018-05-01 08:56:52 --> Config Class Initialized
INFO - 2018-05-01 08:56:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:56:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:56:52 --> Utf8 Class Initialized
INFO - 2018-05-01 08:56:52 --> URI Class Initialized
INFO - 2018-05-01 08:56:52 --> Router Class Initialized
INFO - 2018-05-01 08:56:52 --> Output Class Initialized
INFO - 2018-05-01 08:56:52 --> Security Class Initialized
DEBUG - 2018-05-01 08:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:56:52 --> Input Class Initialized
INFO - 2018-05-01 08:56:52 --> Language Class Initialized
INFO - 2018-05-01 08:56:52 --> Loader Class Initialized
INFO - 2018-05-01 08:56:52 --> Helper loaded: common_helper
INFO - 2018-05-01 08:56:52 --> Database Driver Class Initialized
INFO - 2018-05-01 08:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:56:52 --> Email Class Initialized
INFO - 2018-05-01 08:56:52 --> Controller Class Initialized
INFO - 2018-05-01 08:56:52 --> Helper loaded: form_helper
INFO - 2018-05-01 08:56:52 --> Form Validation Class Initialized
INFO - 2018-05-01 08:56:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:56:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:56:52 --> Helper loaded: url_helper
INFO - 2018-05-01 08:56:52 --> Model Class Initialized
INFO - 2018-05-01 08:56:52 --> Model Class Initialized
INFO - 2018-05-01 08:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:56:52 --> Final output sent to browser
DEBUG - 2018-05-01 08:56:52 --> Total execution time: 0.1320
INFO - 2018-05-01 08:56:56 --> Config Class Initialized
INFO - 2018-05-01 08:56:56 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:56:56 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:56:56 --> Utf8 Class Initialized
INFO - 2018-05-01 08:56:56 --> URI Class Initialized
INFO - 2018-05-01 08:56:56 --> Router Class Initialized
INFO - 2018-05-01 08:56:56 --> Output Class Initialized
INFO - 2018-05-01 08:56:56 --> Security Class Initialized
DEBUG - 2018-05-01 08:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:56:56 --> Input Class Initialized
INFO - 2018-05-01 08:56:56 --> Language Class Initialized
INFO - 2018-05-01 08:56:56 --> Loader Class Initialized
INFO - 2018-05-01 08:56:56 --> Helper loaded: common_helper
INFO - 2018-05-01 08:56:56 --> Database Driver Class Initialized
INFO - 2018-05-01 08:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:56:56 --> Email Class Initialized
INFO - 2018-05-01 08:56:56 --> Controller Class Initialized
INFO - 2018-05-01 08:56:56 --> Helper loaded: form_helper
INFO - 2018-05-01 08:56:56 --> Form Validation Class Initialized
INFO - 2018-05-01 08:56:56 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:56:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:56:56 --> Helper loaded: url_helper
INFO - 2018-05-01 08:56:56 --> Model Class Initialized
INFO - 2018-05-01 08:56:56 --> Model Class Initialized
INFO - 2018-05-01 08:56:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:56:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:56:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:56:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:56:56 --> Final output sent to browser
DEBUG - 2018-05-01 08:56:56 --> Total execution time: 0.1670
INFO - 2018-05-01 08:56:57 --> Config Class Initialized
INFO - 2018-05-01 08:56:57 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:56:57 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:56:57 --> Utf8 Class Initialized
INFO - 2018-05-01 08:56:57 --> URI Class Initialized
INFO - 2018-05-01 08:56:57 --> Router Class Initialized
INFO - 2018-05-01 08:56:57 --> Output Class Initialized
INFO - 2018-05-01 08:56:57 --> Security Class Initialized
DEBUG - 2018-05-01 08:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:56:57 --> Input Class Initialized
INFO - 2018-05-01 08:56:57 --> Language Class Initialized
INFO - 2018-05-01 08:56:57 --> Loader Class Initialized
INFO - 2018-05-01 08:56:57 --> Helper loaded: common_helper
INFO - 2018-05-01 08:56:57 --> Database Driver Class Initialized
INFO - 2018-05-01 08:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:56:57 --> Email Class Initialized
INFO - 2018-05-01 08:56:57 --> Controller Class Initialized
INFO - 2018-05-01 08:56:57 --> Helper loaded: form_helper
INFO - 2018-05-01 08:56:57 --> Form Validation Class Initialized
INFO - 2018-05-01 08:56:57 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:56:57 --> Helper loaded: url_helper
INFO - 2018-05-01 08:56:57 --> Model Class Initialized
INFO - 2018-05-01 08:56:57 --> Model Class Initialized
INFO - 2018-05-01 08:56:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:56:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:56:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:56:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:56:57 --> Final output sent to browser
DEBUG - 2018-05-01 08:56:57 --> Total execution time: 0.1410
INFO - 2018-05-01 08:56:58 --> Config Class Initialized
INFO - 2018-05-01 08:56:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:56:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:56:58 --> Utf8 Class Initialized
INFO - 2018-05-01 08:56:58 --> URI Class Initialized
INFO - 2018-05-01 08:56:58 --> Router Class Initialized
INFO - 2018-05-01 08:56:58 --> Output Class Initialized
INFO - 2018-05-01 08:56:58 --> Security Class Initialized
DEBUG - 2018-05-01 08:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:56:58 --> Input Class Initialized
INFO - 2018-05-01 08:56:58 --> Language Class Initialized
INFO - 2018-05-01 08:56:58 --> Loader Class Initialized
INFO - 2018-05-01 08:56:58 --> Helper loaded: common_helper
INFO - 2018-05-01 08:56:58 --> Database Driver Class Initialized
INFO - 2018-05-01 08:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:56:58 --> Email Class Initialized
INFO - 2018-05-01 08:56:58 --> Controller Class Initialized
INFO - 2018-05-01 08:56:58 --> Helper loaded: form_helper
INFO - 2018-05-01 08:56:58 --> Form Validation Class Initialized
INFO - 2018-05-01 08:56:58 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:56:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:56:58 --> Helper loaded: url_helper
INFO - 2018-05-01 08:56:58 --> Model Class Initialized
INFO - 2018-05-01 08:56:58 --> Model Class Initialized
INFO - 2018-05-01 08:56:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:56:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:56:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:56:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:56:58 --> Final output sent to browser
DEBUG - 2018-05-01 08:56:58 --> Total execution time: 0.1600
INFO - 2018-05-01 08:56:59 --> Config Class Initialized
INFO - 2018-05-01 08:56:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:56:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:56:59 --> Utf8 Class Initialized
INFO - 2018-05-01 08:56:59 --> URI Class Initialized
INFO - 2018-05-01 08:56:59 --> Router Class Initialized
INFO - 2018-05-01 08:56:59 --> Output Class Initialized
INFO - 2018-05-01 08:56:59 --> Security Class Initialized
DEBUG - 2018-05-01 08:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:56:59 --> Input Class Initialized
INFO - 2018-05-01 08:56:59 --> Language Class Initialized
INFO - 2018-05-01 08:56:59 --> Loader Class Initialized
INFO - 2018-05-01 08:56:59 --> Helper loaded: common_helper
INFO - 2018-05-01 08:56:59 --> Database Driver Class Initialized
INFO - 2018-05-01 08:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:56:59 --> Email Class Initialized
INFO - 2018-05-01 08:56:59 --> Controller Class Initialized
INFO - 2018-05-01 08:56:59 --> Helper loaded: form_helper
INFO - 2018-05-01 08:56:59 --> Form Validation Class Initialized
INFO - 2018-05-01 08:56:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:56:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:56:59 --> Helper loaded: url_helper
INFO - 2018-05-01 08:56:59 --> Model Class Initialized
INFO - 2018-05-01 08:56:59 --> Model Class Initialized
INFO - 2018-05-01 08:56:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:56:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:56:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/editFoundation.php
INFO - 2018-05-01 08:56:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:56:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:56:59 --> Final output sent to browser
DEBUG - 2018-05-01 08:56:59 --> Total execution time: 0.1510
INFO - 2018-05-01 08:57:00 --> Config Class Initialized
INFO - 2018-05-01 08:57:00 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:00 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:00 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:00 --> URI Class Initialized
INFO - 2018-05-01 08:57:00 --> Router Class Initialized
INFO - 2018-05-01 08:57:00 --> Output Class Initialized
INFO - 2018-05-01 08:57:00 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:00 --> Input Class Initialized
INFO - 2018-05-01 08:57:00 --> Language Class Initialized
INFO - 2018-05-01 08:57:00 --> Loader Class Initialized
INFO - 2018-05-01 08:57:00 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:00 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:00 --> Email Class Initialized
INFO - 2018-05-01 08:57:00 --> Controller Class Initialized
INFO - 2018-05-01 08:57:00 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:00 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:00 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:00 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:00 --> Model Class Initialized
INFO - 2018-05-01 08:57:00 --> Model Class Initialized
INFO - 2018-05-01 08:57:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:57:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:00 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:00 --> Total execution time: 0.2310
INFO - 2018-05-01 08:57:01 --> Config Class Initialized
INFO - 2018-05-01 08:57:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:01 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:01 --> URI Class Initialized
INFO - 2018-05-01 08:57:01 --> Router Class Initialized
INFO - 2018-05-01 08:57:01 --> Output Class Initialized
INFO - 2018-05-01 08:57:01 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:01 --> Input Class Initialized
INFO - 2018-05-01 08:57:01 --> Language Class Initialized
INFO - 2018-05-01 08:57:01 --> Loader Class Initialized
INFO - 2018-05-01 08:57:01 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:01 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:01 --> Email Class Initialized
INFO - 2018-05-01 08:57:01 --> Controller Class Initialized
INFO - 2018-05-01 08:57:01 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:01 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:01 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:01 --> Model Class Initialized
INFO - 2018-05-01 08:57:01 --> Model Class Initialized
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/addFoundation.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:01 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:01 --> Total execution time: 0.1420
INFO - 2018-05-01 08:57:01 --> Config Class Initialized
INFO - 2018-05-01 08:57:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:01 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:01 --> URI Class Initialized
INFO - 2018-05-01 08:57:01 --> Router Class Initialized
INFO - 2018-05-01 08:57:01 --> Output Class Initialized
INFO - 2018-05-01 08:57:01 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:01 --> Input Class Initialized
INFO - 2018-05-01 08:57:01 --> Language Class Initialized
INFO - 2018-05-01 08:57:01 --> Loader Class Initialized
INFO - 2018-05-01 08:57:01 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:01 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:01 --> Email Class Initialized
INFO - 2018-05-01 08:57:01 --> Controller Class Initialized
INFO - 2018-05-01 08:57:01 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:01 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:01 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:01 --> Model Class Initialized
INFO - 2018-05-01 08:57:01 --> Model Class Initialized
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:57:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:01 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:01 --> Total execution time: 0.1750
INFO - 2018-05-01 08:57:03 --> Config Class Initialized
INFO - 2018-05-01 08:57:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:03 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:03 --> URI Class Initialized
INFO - 2018-05-01 08:57:03 --> Router Class Initialized
INFO - 2018-05-01 08:57:03 --> Output Class Initialized
INFO - 2018-05-01 08:57:03 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:03 --> Input Class Initialized
INFO - 2018-05-01 08:57:03 --> Language Class Initialized
INFO - 2018-05-01 08:57:03 --> Loader Class Initialized
INFO - 2018-05-01 08:57:03 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:03 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:03 --> Email Class Initialized
INFO - 2018-05-01 08:57:03 --> Controller Class Initialized
INFO - 2018-05-01 08:57:03 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:03 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:03 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:03 --> Model Class Initialized
INFO - 2018-05-01 08:57:03 --> Model Class Initialized
INFO - 2018-05-01 08:57:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/addFoundation.php
INFO - 2018-05-01 08:57:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:03 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:03 --> Total execution time: 0.1300
INFO - 2018-05-01 08:57:04 --> Config Class Initialized
INFO - 2018-05-01 08:57:04 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:04 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:04 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:04 --> URI Class Initialized
INFO - 2018-05-01 08:57:04 --> Router Class Initialized
INFO - 2018-05-01 08:57:04 --> Output Class Initialized
INFO - 2018-05-01 08:57:04 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:04 --> Input Class Initialized
INFO - 2018-05-01 08:57:04 --> Language Class Initialized
INFO - 2018-05-01 08:57:04 --> Loader Class Initialized
INFO - 2018-05-01 08:57:04 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:04 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:04 --> Email Class Initialized
INFO - 2018-05-01 08:57:04 --> Controller Class Initialized
INFO - 2018-05-01 08:57:04 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:04 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:04 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:04 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:04 --> Model Class Initialized
INFO - 2018-05-01 08:57:04 --> Model Class Initialized
INFO - 2018-05-01 08:57:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\foundations/foundation.php
INFO - 2018-05-01 08:57:04 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:04 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:04 --> Total execution time: 0.1400
INFO - 2018-05-01 08:57:05 --> Config Class Initialized
INFO - 2018-05-01 08:57:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:05 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:05 --> URI Class Initialized
INFO - 2018-05-01 08:57:05 --> Router Class Initialized
INFO - 2018-05-01 08:57:05 --> Output Class Initialized
INFO - 2018-05-01 08:57:05 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:05 --> Input Class Initialized
INFO - 2018-05-01 08:57:05 --> Language Class Initialized
INFO - 2018-05-01 08:57:05 --> Loader Class Initialized
INFO - 2018-05-01 08:57:05 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:05 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:05 --> Email Class Initialized
INFO - 2018-05-01 08:57:05 --> Controller Class Initialized
INFO - 2018-05-01 08:57:05 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:05 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:05 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:05 --> Model Class Initialized
INFO - 2018-05-01 08:57:05 --> Model Class Initialized
INFO - 2018-05-01 08:57:05 --> Model Class Initialized
INFO - 2018-05-01 12:27:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:27:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:27:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:27:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:27:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:27:05 --> Final output sent to browser
DEBUG - 2018-05-01 12:27:05 --> Total execution time: 0.1350
INFO - 2018-05-01 08:57:08 --> Config Class Initialized
INFO - 2018-05-01 08:57:08 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:08 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:08 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:08 --> URI Class Initialized
INFO - 2018-05-01 08:57:08 --> Router Class Initialized
INFO - 2018-05-01 08:57:08 --> Output Class Initialized
INFO - 2018-05-01 08:57:08 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:08 --> Input Class Initialized
INFO - 2018-05-01 08:57:08 --> Language Class Initialized
INFO - 2018-05-01 08:57:08 --> Loader Class Initialized
INFO - 2018-05-01 08:57:08 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:08 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:08 --> Email Class Initialized
INFO - 2018-05-01 08:57:08 --> Controller Class Initialized
INFO - 2018-05-01 08:57:08 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:08 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:08 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:08 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:08 --> Model Class Initialized
INFO - 2018-05-01 08:57:08 --> Model Class Initialized
INFO - 2018-05-01 08:57:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 08:57:08 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:08 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:08 --> Total execution time: 0.1290
INFO - 2018-05-01 08:57:34 --> Config Class Initialized
INFO - 2018-05-01 08:57:34 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:57:34 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:57:34 --> Utf8 Class Initialized
INFO - 2018-05-01 08:57:34 --> URI Class Initialized
INFO - 2018-05-01 08:57:34 --> Router Class Initialized
INFO - 2018-05-01 08:57:34 --> Output Class Initialized
INFO - 2018-05-01 08:57:34 --> Security Class Initialized
DEBUG - 2018-05-01 08:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:57:34 --> Input Class Initialized
INFO - 2018-05-01 08:57:34 --> Language Class Initialized
INFO - 2018-05-01 08:57:34 --> Loader Class Initialized
INFO - 2018-05-01 08:57:34 --> Helper loaded: common_helper
INFO - 2018-05-01 08:57:34 --> Database Driver Class Initialized
INFO - 2018-05-01 08:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:57:34 --> Email Class Initialized
INFO - 2018-05-01 08:57:34 --> Controller Class Initialized
INFO - 2018-05-01 08:57:34 --> Helper loaded: form_helper
INFO - 2018-05-01 08:57:34 --> Form Validation Class Initialized
INFO - 2018-05-01 08:57:34 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:57:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:57:34 --> Helper loaded: url_helper
INFO - 2018-05-01 08:57:34 --> Model Class Initialized
INFO - 2018-05-01 08:57:34 --> Model Class Initialized
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:57:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:57:34 --> Final output sent to browser
DEBUG - 2018-05-01 08:57:34 --> Total execution time: 0.1650
INFO - 2018-05-01 08:58:04 --> Config Class Initialized
INFO - 2018-05-01 08:58:04 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:58:04 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:58:04 --> Utf8 Class Initialized
INFO - 2018-05-01 08:58:04 --> URI Class Initialized
INFO - 2018-05-01 08:58:04 --> Router Class Initialized
INFO - 2018-05-01 08:58:04 --> Output Class Initialized
INFO - 2018-05-01 08:58:04 --> Security Class Initialized
DEBUG - 2018-05-01 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:58:04 --> Input Class Initialized
INFO - 2018-05-01 08:58:04 --> Language Class Initialized
INFO - 2018-05-01 08:58:04 --> Loader Class Initialized
INFO - 2018-05-01 08:58:04 --> Helper loaded: common_helper
INFO - 2018-05-01 08:58:04 --> Database Driver Class Initialized
INFO - 2018-05-01 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:58:04 --> Email Class Initialized
INFO - 2018-05-01 08:58:04 --> Controller Class Initialized
INFO - 2018-05-01 08:58:04 --> Helper loaded: form_helper
INFO - 2018-05-01 08:58:04 --> Form Validation Class Initialized
INFO - 2018-05-01 08:58:04 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:58:04 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:04 --> Helper loaded: url_helper
INFO - 2018-05-01 08:58:04 --> Model Class Initialized
INFO - 2018-05-01 08:58:04 --> Model Class Initialized
DEBUG - 2018-05-01 08:58:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 08:58:05 --> Config Class Initialized
INFO - 2018-05-01 08:58:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:58:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:58:05 --> Utf8 Class Initialized
INFO - 2018-05-01 08:58:05 --> URI Class Initialized
INFO - 2018-05-01 08:58:05 --> Router Class Initialized
INFO - 2018-05-01 08:58:05 --> Output Class Initialized
INFO - 2018-05-01 08:58:05 --> Security Class Initialized
DEBUG - 2018-05-01 08:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:58:05 --> Input Class Initialized
INFO - 2018-05-01 08:58:05 --> Language Class Initialized
INFO - 2018-05-01 08:58:05 --> Loader Class Initialized
INFO - 2018-05-01 08:58:05 --> Helper loaded: common_helper
INFO - 2018-05-01 08:58:05 --> Database Driver Class Initialized
INFO - 2018-05-01 08:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:58:05 --> Email Class Initialized
INFO - 2018-05-01 08:58:05 --> Controller Class Initialized
INFO - 2018-05-01 08:58:05 --> Helper loaded: form_helper
INFO - 2018-05-01 08:58:05 --> Form Validation Class Initialized
INFO - 2018-05-01 08:58:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:58:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:05 --> Helper loaded: url_helper
INFO - 2018-05-01 08:58:05 --> Model Class Initialized
INFO - 2018-05-01 08:58:05 --> Model Class Initialized
INFO - 2018-05-01 08:58:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:58:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:58:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:58:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 08:58:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:58:05 --> Final output sent to browser
DEBUG - 2018-05-01 08:58:05 --> Total execution time: 0.1310
INFO - 2018-05-01 08:58:14 --> Config Class Initialized
INFO - 2018-05-01 08:58:14 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:58:14 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:58:14 --> Utf8 Class Initialized
INFO - 2018-05-01 08:58:14 --> URI Class Initialized
INFO - 2018-05-01 08:58:14 --> Router Class Initialized
INFO - 2018-05-01 08:58:14 --> Output Class Initialized
INFO - 2018-05-01 08:58:14 --> Security Class Initialized
DEBUG - 2018-05-01 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:58:14 --> Input Class Initialized
INFO - 2018-05-01 08:58:14 --> Language Class Initialized
INFO - 2018-05-01 08:58:14 --> Loader Class Initialized
INFO - 2018-05-01 08:58:14 --> Helper loaded: common_helper
INFO - 2018-05-01 08:58:14 --> Database Driver Class Initialized
INFO - 2018-05-01 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:58:14 --> Email Class Initialized
INFO - 2018-05-01 08:58:14 --> Controller Class Initialized
INFO - 2018-05-01 08:58:14 --> Helper loaded: form_helper
INFO - 2018-05-01 08:58:14 --> Form Validation Class Initialized
INFO - 2018-05-01 08:58:14 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:58:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:14 --> Helper loaded: url_helper
INFO - 2018-05-01 08:58:14 --> Model Class Initialized
INFO - 2018-05-01 08:58:14 --> Model Class Initialized
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:58:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:58:14 --> Final output sent to browser
DEBUG - 2018-05-01 08:58:14 --> Total execution time: 0.1720
INFO - 2018-05-01 08:58:38 --> Config Class Initialized
INFO - 2018-05-01 08:58:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:58:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:58:38 --> Utf8 Class Initialized
INFO - 2018-05-01 08:58:38 --> URI Class Initialized
INFO - 2018-05-01 08:58:38 --> Router Class Initialized
INFO - 2018-05-01 08:58:38 --> Output Class Initialized
INFO - 2018-05-01 08:58:38 --> Security Class Initialized
DEBUG - 2018-05-01 08:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:58:38 --> Input Class Initialized
INFO - 2018-05-01 08:58:38 --> Language Class Initialized
INFO - 2018-05-01 08:58:38 --> Loader Class Initialized
INFO - 2018-05-01 08:58:38 --> Helper loaded: common_helper
INFO - 2018-05-01 08:58:38 --> Database Driver Class Initialized
INFO - 2018-05-01 08:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:58:38 --> Email Class Initialized
INFO - 2018-05-01 08:58:38 --> Controller Class Initialized
INFO - 2018-05-01 08:58:38 --> Helper loaded: form_helper
INFO - 2018-05-01 08:58:38 --> Form Validation Class Initialized
INFO - 2018-05-01 08:58:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:38 --> Helper loaded: url_helper
INFO - 2018-05-01 08:58:38 --> Model Class Initialized
INFO - 2018-05-01 08:58:38 --> Model Class Initialized
DEBUG - 2018-05-01 08:58:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 08:58:38 --> Undefined variable: res
ERROR - 2018-05-01 08:58:38 --> Severity: Notice --> Undefined variable: res C:\xampp\htdocs\Celebrity\admin\application\controllers\SocialService.php 160
INFO - 2018-05-01 08:58:38 --> Config Class Initialized
INFO - 2018-05-01 08:58:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:58:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:58:38 --> Utf8 Class Initialized
INFO - 2018-05-01 08:58:38 --> URI Class Initialized
INFO - 2018-05-01 08:58:38 --> Router Class Initialized
INFO - 2018-05-01 08:58:38 --> Output Class Initialized
INFO - 2018-05-01 08:58:38 --> Security Class Initialized
DEBUG - 2018-05-01 08:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:58:38 --> Input Class Initialized
INFO - 2018-05-01 08:58:38 --> Language Class Initialized
INFO - 2018-05-01 08:58:38 --> Loader Class Initialized
INFO - 2018-05-01 08:58:38 --> Helper loaded: common_helper
INFO - 2018-05-01 08:58:38 --> Database Driver Class Initialized
INFO - 2018-05-01 08:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:58:38 --> Email Class Initialized
INFO - 2018-05-01 08:58:38 --> Controller Class Initialized
INFO - 2018-05-01 08:58:38 --> Helper loaded: form_helper
INFO - 2018-05-01 08:58:38 --> Form Validation Class Initialized
INFO - 2018-05-01 08:58:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:58:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:38 --> Helper loaded: url_helper
INFO - 2018-05-01 08:58:38 --> Model Class Initialized
INFO - 2018-05-01 08:58:38 --> Model Class Initialized
INFO - 2018-05-01 08:58:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:58:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:58:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:58:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 08:58:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:58:38 --> Final output sent to browser
DEBUG - 2018-05-01 08:58:38 --> Total execution time: 0.1280
INFO - 2018-05-01 08:58:52 --> Config Class Initialized
INFO - 2018-05-01 08:58:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:58:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:58:52 --> Utf8 Class Initialized
INFO - 2018-05-01 08:58:52 --> URI Class Initialized
INFO - 2018-05-01 08:58:52 --> Router Class Initialized
INFO - 2018-05-01 08:58:52 --> Output Class Initialized
INFO - 2018-05-01 08:58:52 --> Security Class Initialized
DEBUG - 2018-05-01 08:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:58:52 --> Input Class Initialized
INFO - 2018-05-01 08:58:52 --> Language Class Initialized
INFO - 2018-05-01 08:58:52 --> Loader Class Initialized
INFO - 2018-05-01 08:58:52 --> Helper loaded: common_helper
INFO - 2018-05-01 08:58:52 --> Database Driver Class Initialized
INFO - 2018-05-01 08:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:58:52 --> Email Class Initialized
INFO - 2018-05-01 08:58:52 --> Controller Class Initialized
INFO - 2018-05-01 08:58:52 --> Helper loaded: form_helper
INFO - 2018-05-01 08:58:52 --> Form Validation Class Initialized
INFO - 2018-05-01 08:58:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:58:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:58:52 --> Helper loaded: url_helper
INFO - 2018-05-01 08:58:52 --> Model Class Initialized
INFO - 2018-05-01 08:58:52 --> Model Class Initialized
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:58:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:58:52 --> Final output sent to browser
DEBUG - 2018-05-01 08:58:52 --> Total execution time: 0.1330
INFO - 2018-05-01 08:59:17 --> Config Class Initialized
INFO - 2018-05-01 08:59:17 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:59:17 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:59:17 --> Utf8 Class Initialized
INFO - 2018-05-01 08:59:17 --> URI Class Initialized
INFO - 2018-05-01 08:59:17 --> Router Class Initialized
INFO - 2018-05-01 08:59:17 --> Output Class Initialized
INFO - 2018-05-01 08:59:17 --> Security Class Initialized
DEBUG - 2018-05-01 08:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:59:17 --> Input Class Initialized
INFO - 2018-05-01 08:59:17 --> Language Class Initialized
INFO - 2018-05-01 08:59:17 --> Loader Class Initialized
INFO - 2018-05-01 08:59:17 --> Helper loaded: common_helper
INFO - 2018-05-01 08:59:17 --> Database Driver Class Initialized
INFO - 2018-05-01 08:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:59:17 --> Email Class Initialized
INFO - 2018-05-01 08:59:17 --> Controller Class Initialized
INFO - 2018-05-01 08:59:17 --> Helper loaded: form_helper
INFO - 2018-05-01 08:59:17 --> Form Validation Class Initialized
INFO - 2018-05-01 08:59:17 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:59:17 --> Helper loaded: url_helper
INFO - 2018-05-01 08:59:17 --> Model Class Initialized
INFO - 2018-05-01 08:59:17 --> Model Class Initialized
DEBUG - 2018-05-01 08:59:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:59:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 08:59:17 --> Invalid argument supplied for foreach()
ERROR - 2018-05-01 08:59:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Celebrity\admin\application\controllers\SocialService.php 268
INFO - 2018-05-01 08:59:17 --> Config Class Initialized
INFO - 2018-05-01 08:59:17 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:59:17 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:59:17 --> Utf8 Class Initialized
INFO - 2018-05-01 08:59:17 --> URI Class Initialized
INFO - 2018-05-01 08:59:17 --> Router Class Initialized
INFO - 2018-05-01 08:59:17 --> Output Class Initialized
INFO - 2018-05-01 08:59:17 --> Security Class Initialized
DEBUG - 2018-05-01 08:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:59:17 --> Input Class Initialized
INFO - 2018-05-01 08:59:17 --> Language Class Initialized
INFO - 2018-05-01 08:59:17 --> Loader Class Initialized
INFO - 2018-05-01 08:59:17 --> Helper loaded: common_helper
INFO - 2018-05-01 08:59:17 --> Database Driver Class Initialized
INFO - 2018-05-01 08:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:59:17 --> Email Class Initialized
INFO - 2018-05-01 08:59:17 --> Controller Class Initialized
INFO - 2018-05-01 08:59:17 --> Helper loaded: form_helper
INFO - 2018-05-01 08:59:17 --> Form Validation Class Initialized
INFO - 2018-05-01 08:59:17 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:59:17 --> Helper loaded: url_helper
INFO - 2018-05-01 08:59:17 --> Model Class Initialized
INFO - 2018-05-01 08:59:17 --> Model Class Initialized
INFO - 2018-05-01 08:59:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:59:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:59:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:59:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 08:59:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:59:17 --> Final output sent to browser
DEBUG - 2018-05-01 08:59:17 --> Total execution time: 0.1280
INFO - 2018-05-01 08:59:27 --> Config Class Initialized
INFO - 2018-05-01 08:59:27 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:59:27 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:59:27 --> Utf8 Class Initialized
INFO - 2018-05-01 08:59:27 --> URI Class Initialized
INFO - 2018-05-01 08:59:27 --> Router Class Initialized
INFO - 2018-05-01 08:59:27 --> Output Class Initialized
INFO - 2018-05-01 08:59:27 --> Security Class Initialized
DEBUG - 2018-05-01 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:59:27 --> Input Class Initialized
INFO - 2018-05-01 08:59:27 --> Language Class Initialized
INFO - 2018-05-01 08:59:27 --> Loader Class Initialized
INFO - 2018-05-01 08:59:27 --> Helper loaded: common_helper
INFO - 2018-05-01 08:59:27 --> Database Driver Class Initialized
INFO - 2018-05-01 08:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:59:27 --> Email Class Initialized
INFO - 2018-05-01 08:59:27 --> Controller Class Initialized
INFO - 2018-05-01 08:59:27 --> Helper loaded: form_helper
INFO - 2018-05-01 08:59:27 --> Form Validation Class Initialized
INFO - 2018-05-01 08:59:27 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:59:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:59:27 --> Helper loaded: url_helper
INFO - 2018-05-01 08:59:27 --> Model Class Initialized
INFO - 2018-05-01 08:59:27 --> Model Class Initialized
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:59:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:59:27 --> Final output sent to browser
DEBUG - 2018-05-01 08:59:27 --> Total execution time: 0.1350
INFO - 2018-05-01 08:59:37 --> Config Class Initialized
INFO - 2018-05-01 08:59:37 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:59:37 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:59:37 --> Utf8 Class Initialized
INFO - 2018-05-01 08:59:37 --> URI Class Initialized
INFO - 2018-05-01 08:59:37 --> Router Class Initialized
INFO - 2018-05-01 08:59:37 --> Output Class Initialized
INFO - 2018-05-01 08:59:37 --> Security Class Initialized
DEBUG - 2018-05-01 08:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:59:37 --> Input Class Initialized
INFO - 2018-05-01 08:59:37 --> Language Class Initialized
INFO - 2018-05-01 08:59:37 --> Loader Class Initialized
INFO - 2018-05-01 08:59:37 --> Helper loaded: common_helper
INFO - 2018-05-01 08:59:37 --> Database Driver Class Initialized
INFO - 2018-05-01 08:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:59:37 --> Email Class Initialized
INFO - 2018-05-01 08:59:37 --> Controller Class Initialized
INFO - 2018-05-01 08:59:37 --> Helper loaded: form_helper
INFO - 2018-05-01 08:59:37 --> Form Validation Class Initialized
INFO - 2018-05-01 08:59:37 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:59:37 --> Helper loaded: url_helper
INFO - 2018-05-01 08:59:37 --> Model Class Initialized
INFO - 2018-05-01 08:59:37 --> Model Class Initialized
INFO - 2018-05-01 08:59:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:59:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:59:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:59:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 08:59:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:59:37 --> Final output sent to browser
DEBUG - 2018-05-01 08:59:37 --> Total execution time: 0.1370
INFO - 2018-05-01 08:59:40 --> Config Class Initialized
INFO - 2018-05-01 08:59:40 --> Hooks Class Initialized
DEBUG - 2018-05-01 08:59:40 --> UTF-8 Support Enabled
INFO - 2018-05-01 08:59:40 --> Utf8 Class Initialized
INFO - 2018-05-01 08:59:40 --> URI Class Initialized
INFO - 2018-05-01 08:59:40 --> Router Class Initialized
INFO - 2018-05-01 08:59:40 --> Output Class Initialized
INFO - 2018-05-01 08:59:40 --> Security Class Initialized
DEBUG - 2018-05-01 08:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 08:59:40 --> Input Class Initialized
INFO - 2018-05-01 08:59:40 --> Language Class Initialized
INFO - 2018-05-01 08:59:40 --> Loader Class Initialized
INFO - 2018-05-01 08:59:40 --> Helper loaded: common_helper
INFO - 2018-05-01 08:59:40 --> Database Driver Class Initialized
INFO - 2018-05-01 08:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 08:59:40 --> Email Class Initialized
INFO - 2018-05-01 08:59:40 --> Controller Class Initialized
INFO - 2018-05-01 08:59:40 --> Helper loaded: form_helper
INFO - 2018-05-01 08:59:40 --> Form Validation Class Initialized
INFO - 2018-05-01 08:59:40 --> Helper loaded: email_helper
DEBUG - 2018-05-01 08:59:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 08:59:40 --> Helper loaded: url_helper
INFO - 2018-05-01 08:59:40 --> Model Class Initialized
INFO - 2018-05-01 08:59:40 --> Model Class Initialized
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 08:59:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 08:59:40 --> Final output sent to browser
DEBUG - 2018-05-01 08:59:40 --> Total execution time: 0.1330
INFO - 2018-05-01 09:00:11 --> Config Class Initialized
INFO - 2018-05-01 09:00:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:00:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:00:11 --> Utf8 Class Initialized
INFO - 2018-05-01 09:00:11 --> URI Class Initialized
INFO - 2018-05-01 09:00:11 --> Router Class Initialized
INFO - 2018-05-01 09:00:11 --> Output Class Initialized
INFO - 2018-05-01 09:00:11 --> Security Class Initialized
DEBUG - 2018-05-01 09:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:00:11 --> Input Class Initialized
INFO - 2018-05-01 09:00:11 --> Language Class Initialized
INFO - 2018-05-01 09:00:11 --> Loader Class Initialized
INFO - 2018-05-01 09:00:11 --> Helper loaded: common_helper
INFO - 2018-05-01 09:00:11 --> Database Driver Class Initialized
INFO - 2018-05-01 09:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:00:11 --> Email Class Initialized
INFO - 2018-05-01 09:00:11 --> Controller Class Initialized
INFO - 2018-05-01 09:00:11 --> Helper loaded: form_helper
INFO - 2018-05-01 09:00:11 --> Form Validation Class Initialized
INFO - 2018-05-01 09:00:11 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:00:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:00:11 --> Helper loaded: url_helper
INFO - 2018-05-01 09:00:11 --> Model Class Initialized
INFO - 2018-05-01 09:00:11 --> Model Class Initialized
DEBUG - 2018-05-01 09:00:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:00:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 09:00:11 --> Undefined offset: 2
ERROR - 2018-05-01 09:00:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\Celebrity\admin\application\controllers\SocialService.php 283
INFO - 2018-05-01 09:00:11 --> Config Class Initialized
INFO - 2018-05-01 09:00:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:00:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:00:11 --> Utf8 Class Initialized
INFO - 2018-05-01 09:00:11 --> URI Class Initialized
INFO - 2018-05-01 09:00:11 --> Router Class Initialized
INFO - 2018-05-01 09:00:11 --> Output Class Initialized
INFO - 2018-05-01 09:00:11 --> Security Class Initialized
DEBUG - 2018-05-01 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:00:12 --> Input Class Initialized
INFO - 2018-05-01 09:00:12 --> Language Class Initialized
INFO - 2018-05-01 09:00:12 --> Loader Class Initialized
INFO - 2018-05-01 09:00:12 --> Helper loaded: common_helper
INFO - 2018-05-01 09:00:12 --> Database Driver Class Initialized
INFO - 2018-05-01 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:00:12 --> Email Class Initialized
INFO - 2018-05-01 09:00:12 --> Controller Class Initialized
INFO - 2018-05-01 09:00:12 --> Helper loaded: form_helper
INFO - 2018-05-01 09:00:12 --> Form Validation Class Initialized
INFO - 2018-05-01 09:00:12 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:00:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:00:12 --> Helper loaded: url_helper
INFO - 2018-05-01 09:00:12 --> Model Class Initialized
INFO - 2018-05-01 09:00:12 --> Model Class Initialized
INFO - 2018-05-01 09:00:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:00:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:00:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:00:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:00:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:00:12 --> Final output sent to browser
DEBUG - 2018-05-01 09:00:12 --> Total execution time: 0.1280
INFO - 2018-05-01 09:00:18 --> Config Class Initialized
INFO - 2018-05-01 09:00:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:00:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:00:18 --> Utf8 Class Initialized
INFO - 2018-05-01 09:00:18 --> URI Class Initialized
INFO - 2018-05-01 09:00:18 --> Router Class Initialized
INFO - 2018-05-01 09:00:18 --> Output Class Initialized
INFO - 2018-05-01 09:00:18 --> Security Class Initialized
DEBUG - 2018-05-01 09:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:00:18 --> Input Class Initialized
INFO - 2018-05-01 09:00:18 --> Language Class Initialized
INFO - 2018-05-01 09:00:18 --> Loader Class Initialized
INFO - 2018-05-01 09:00:18 --> Helper loaded: common_helper
INFO - 2018-05-01 09:00:18 --> Database Driver Class Initialized
INFO - 2018-05-01 09:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:00:18 --> Email Class Initialized
INFO - 2018-05-01 09:00:18 --> Controller Class Initialized
INFO - 2018-05-01 09:00:18 --> Helper loaded: form_helper
INFO - 2018-05-01 09:00:18 --> Form Validation Class Initialized
INFO - 2018-05-01 09:00:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:00:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:00:18 --> Helper loaded: url_helper
INFO - 2018-05-01 09:00:18 --> Model Class Initialized
INFO - 2018-05-01 09:00:18 --> Model Class Initialized
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:00:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:00:18 --> Final output sent to browser
DEBUG - 2018-05-01 09:00:18 --> Total execution time: 0.1310
INFO - 2018-05-01 09:00:30 --> Config Class Initialized
INFO - 2018-05-01 09:00:30 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:00:30 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:00:30 --> Utf8 Class Initialized
INFO - 2018-05-01 09:00:30 --> URI Class Initialized
INFO - 2018-05-01 09:00:30 --> Router Class Initialized
INFO - 2018-05-01 09:00:30 --> Output Class Initialized
INFO - 2018-05-01 09:00:30 --> Security Class Initialized
DEBUG - 2018-05-01 09:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:00:30 --> Input Class Initialized
INFO - 2018-05-01 09:00:30 --> Language Class Initialized
INFO - 2018-05-01 09:00:30 --> Loader Class Initialized
INFO - 2018-05-01 09:00:30 --> Helper loaded: common_helper
INFO - 2018-05-01 09:00:30 --> Database Driver Class Initialized
INFO - 2018-05-01 09:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:00:30 --> Email Class Initialized
INFO - 2018-05-01 09:00:30 --> Controller Class Initialized
INFO - 2018-05-01 09:00:30 --> Helper loaded: form_helper
INFO - 2018-05-01 09:00:30 --> Form Validation Class Initialized
INFO - 2018-05-01 09:00:30 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:00:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:00:30 --> Helper loaded: url_helper
INFO - 2018-05-01 09:00:30 --> Model Class Initialized
INFO - 2018-05-01 09:00:30 --> Model Class Initialized
INFO - 2018-05-01 09:00:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:00:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:00:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:00:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:00:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:00:30 --> Final output sent to browser
DEBUG - 2018-05-01 09:00:30 --> Total execution time: 0.1400
INFO - 2018-05-01 09:00:39 --> Config Class Initialized
INFO - 2018-05-01 09:00:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:00:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:00:39 --> Utf8 Class Initialized
INFO - 2018-05-01 09:00:39 --> URI Class Initialized
INFO - 2018-05-01 09:00:39 --> Router Class Initialized
INFO - 2018-05-01 09:00:39 --> Output Class Initialized
INFO - 2018-05-01 09:00:39 --> Security Class Initialized
DEBUG - 2018-05-01 09:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:00:39 --> Input Class Initialized
INFO - 2018-05-01 09:00:39 --> Language Class Initialized
INFO - 2018-05-01 09:00:39 --> Loader Class Initialized
INFO - 2018-05-01 09:00:39 --> Helper loaded: common_helper
INFO - 2018-05-01 09:00:40 --> Database Driver Class Initialized
INFO - 2018-05-01 09:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:00:40 --> Email Class Initialized
INFO - 2018-05-01 09:00:40 --> Controller Class Initialized
INFO - 2018-05-01 09:00:40 --> Helper loaded: form_helper
INFO - 2018-05-01 09:00:40 --> Form Validation Class Initialized
INFO - 2018-05-01 09:00:40 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:00:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:00:40 --> Helper loaded: url_helper
INFO - 2018-05-01 09:00:40 --> Model Class Initialized
INFO - 2018-05-01 09:00:40 --> Model Class Initialized
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:00:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:00:40 --> Final output sent to browser
DEBUG - 2018-05-01 09:00:40 --> Total execution time: 0.1290
INFO - 2018-05-01 09:01:00 --> Config Class Initialized
INFO - 2018-05-01 09:01:00 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:01:00 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:01:00 --> Utf8 Class Initialized
INFO - 2018-05-01 09:01:00 --> URI Class Initialized
INFO - 2018-05-01 09:01:00 --> Router Class Initialized
INFO - 2018-05-01 09:01:00 --> Output Class Initialized
INFO - 2018-05-01 09:01:00 --> Security Class Initialized
DEBUG - 2018-05-01 09:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:01:00 --> Input Class Initialized
INFO - 2018-05-01 09:01:00 --> Language Class Initialized
INFO - 2018-05-01 09:01:00 --> Loader Class Initialized
INFO - 2018-05-01 09:01:00 --> Helper loaded: common_helper
INFO - 2018-05-01 09:01:00 --> Database Driver Class Initialized
INFO - 2018-05-01 09:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:01:00 --> Email Class Initialized
INFO - 2018-05-01 09:01:00 --> Controller Class Initialized
INFO - 2018-05-01 09:01:00 --> Helper loaded: form_helper
INFO - 2018-05-01 09:01:00 --> Form Validation Class Initialized
INFO - 2018-05-01 09:01:00 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:01:00 --> Helper loaded: url_helper
INFO - 2018-05-01 09:01:00 --> Model Class Initialized
INFO - 2018-05-01 09:01:00 --> Model Class Initialized
DEBUG - 2018-05-01 09:01:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:01:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 09:01:01 --> Config Class Initialized
INFO - 2018-05-01 09:01:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:01:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:01:01 --> Utf8 Class Initialized
INFO - 2018-05-01 09:01:01 --> URI Class Initialized
INFO - 2018-05-01 09:01:01 --> Router Class Initialized
INFO - 2018-05-01 09:01:01 --> Output Class Initialized
INFO - 2018-05-01 09:01:01 --> Security Class Initialized
DEBUG - 2018-05-01 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:01:01 --> Input Class Initialized
INFO - 2018-05-01 09:01:01 --> Language Class Initialized
INFO - 2018-05-01 09:01:01 --> Loader Class Initialized
INFO - 2018-05-01 09:01:01 --> Helper loaded: common_helper
INFO - 2018-05-01 09:01:01 --> Database Driver Class Initialized
INFO - 2018-05-01 09:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:01:01 --> Email Class Initialized
INFO - 2018-05-01 09:01:01 --> Controller Class Initialized
INFO - 2018-05-01 09:01:01 --> Helper loaded: form_helper
INFO - 2018-05-01 09:01:01 --> Form Validation Class Initialized
INFO - 2018-05-01 09:01:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:01:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:01:01 --> Helper loaded: url_helper
INFO - 2018-05-01 09:01:01 --> Model Class Initialized
INFO - 2018-05-01 09:01:01 --> Model Class Initialized
INFO - 2018-05-01 09:01:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:01:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:01:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:01:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:01:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:01:01 --> Final output sent to browser
DEBUG - 2018-05-01 09:01:01 --> Total execution time: 0.1250
INFO - 2018-05-01 09:02:07 --> Config Class Initialized
INFO - 2018-05-01 09:02:07 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:02:07 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:02:07 --> Utf8 Class Initialized
INFO - 2018-05-01 09:02:07 --> URI Class Initialized
INFO - 2018-05-01 09:02:07 --> Router Class Initialized
INFO - 2018-05-01 09:02:07 --> Output Class Initialized
INFO - 2018-05-01 09:02:07 --> Security Class Initialized
DEBUG - 2018-05-01 09:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:02:07 --> Input Class Initialized
INFO - 2018-05-01 09:02:07 --> Language Class Initialized
INFO - 2018-05-01 09:02:07 --> Loader Class Initialized
INFO - 2018-05-01 09:02:07 --> Helper loaded: common_helper
INFO - 2018-05-01 09:02:07 --> Database Driver Class Initialized
INFO - 2018-05-01 09:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:02:07 --> Email Class Initialized
INFO - 2018-05-01 09:02:07 --> Controller Class Initialized
INFO - 2018-05-01 09:02:07 --> Helper loaded: form_helper
INFO - 2018-05-01 09:02:07 --> Form Validation Class Initialized
INFO - 2018-05-01 09:02:07 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:02:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:02:07 --> Helper loaded: url_helper
INFO - 2018-05-01 09:02:07 --> Model Class Initialized
INFO - 2018-05-01 09:02:07 --> Model Class Initialized
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:02:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:02:07 --> Final output sent to browser
DEBUG - 2018-05-01 09:02:07 --> Total execution time: 0.1330
INFO - 2018-05-01 09:02:24 --> Config Class Initialized
INFO - 2018-05-01 09:02:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:02:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:02:24 --> Utf8 Class Initialized
INFO - 2018-05-01 09:02:24 --> URI Class Initialized
INFO - 2018-05-01 09:02:24 --> Router Class Initialized
INFO - 2018-05-01 09:02:24 --> Output Class Initialized
INFO - 2018-05-01 09:02:24 --> Security Class Initialized
DEBUG - 2018-05-01 09:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:02:24 --> Input Class Initialized
INFO - 2018-05-01 09:02:24 --> Language Class Initialized
INFO - 2018-05-01 09:02:24 --> Loader Class Initialized
INFO - 2018-05-01 09:02:24 --> Helper loaded: common_helper
INFO - 2018-05-01 09:02:24 --> Database Driver Class Initialized
INFO - 2018-05-01 09:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:02:24 --> Email Class Initialized
INFO - 2018-05-01 09:02:24 --> Controller Class Initialized
INFO - 2018-05-01 09:02:24 --> Helper loaded: form_helper
INFO - 2018-05-01 09:02:24 --> Form Validation Class Initialized
INFO - 2018-05-01 09:02:24 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:02:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:02:24 --> Helper loaded: url_helper
INFO - 2018-05-01 09:02:24 --> Model Class Initialized
INFO - 2018-05-01 09:02:24 --> Model Class Initialized
INFO - 2018-05-01 09:02:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:02:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:02:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:02:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:02:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:02:24 --> Final output sent to browser
DEBUG - 2018-05-01 09:02:24 --> Total execution time: 0.1570
INFO - 2018-05-01 09:04:43 --> Config Class Initialized
INFO - 2018-05-01 09:04:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:04:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:04:43 --> Utf8 Class Initialized
INFO - 2018-05-01 09:04:43 --> URI Class Initialized
INFO - 2018-05-01 09:04:43 --> Router Class Initialized
INFO - 2018-05-01 09:04:43 --> Output Class Initialized
INFO - 2018-05-01 09:04:43 --> Security Class Initialized
DEBUG - 2018-05-01 09:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:04:43 --> Input Class Initialized
INFO - 2018-05-01 09:04:43 --> Language Class Initialized
INFO - 2018-05-01 09:04:43 --> Loader Class Initialized
INFO - 2018-05-01 09:04:43 --> Helper loaded: common_helper
INFO - 2018-05-01 09:04:43 --> Database Driver Class Initialized
INFO - 2018-05-01 09:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:04:43 --> Email Class Initialized
INFO - 2018-05-01 09:04:43 --> Controller Class Initialized
INFO - 2018-05-01 09:04:43 --> Helper loaded: form_helper
INFO - 2018-05-01 09:04:43 --> Form Validation Class Initialized
INFO - 2018-05-01 09:04:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:04:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:04:43 --> Helper loaded: url_helper
INFO - 2018-05-01 09:04:43 --> Model Class Initialized
INFO - 2018-05-01 09:04:43 --> Model Class Initialized
INFO - 2018-05-01 09:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:04:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:04:43 --> Final output sent to browser
DEBUG - 2018-05-01 09:04:43 --> Total execution time: 0.1730
INFO - 2018-05-01 09:04:46 --> Config Class Initialized
INFO - 2018-05-01 09:04:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:04:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:04:46 --> Utf8 Class Initialized
INFO - 2018-05-01 09:04:46 --> URI Class Initialized
INFO - 2018-05-01 09:04:46 --> Router Class Initialized
INFO - 2018-05-01 09:04:46 --> Output Class Initialized
INFO - 2018-05-01 09:04:46 --> Security Class Initialized
DEBUG - 2018-05-01 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:04:46 --> Input Class Initialized
INFO - 2018-05-01 09:04:46 --> Language Class Initialized
INFO - 2018-05-01 09:04:46 --> Loader Class Initialized
INFO - 2018-05-01 09:04:46 --> Helper loaded: common_helper
INFO - 2018-05-01 09:04:46 --> Database Driver Class Initialized
INFO - 2018-05-01 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:04:46 --> Email Class Initialized
INFO - 2018-05-01 09:04:46 --> Controller Class Initialized
INFO - 2018-05-01 09:04:46 --> Helper loaded: form_helper
INFO - 2018-05-01 09:04:46 --> Form Validation Class Initialized
INFO - 2018-05-01 09:04:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:04:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:04:46 --> Helper loaded: url_helper
INFO - 2018-05-01 09:04:46 --> Model Class Initialized
INFO - 2018-05-01 09:04:46 --> Model Class Initialized
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:04:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:04:46 --> Final output sent to browser
DEBUG - 2018-05-01 09:04:46 --> Total execution time: 0.1310
INFO - 2018-05-01 09:04:58 --> Config Class Initialized
INFO - 2018-05-01 09:04:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:04:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:04:58 --> Utf8 Class Initialized
INFO - 2018-05-01 09:04:58 --> URI Class Initialized
INFO - 2018-05-01 09:04:58 --> Router Class Initialized
INFO - 2018-05-01 09:04:58 --> Output Class Initialized
INFO - 2018-05-01 09:04:58 --> Security Class Initialized
DEBUG - 2018-05-01 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:04:58 --> Input Class Initialized
INFO - 2018-05-01 09:04:58 --> Language Class Initialized
INFO - 2018-05-01 09:04:58 --> Loader Class Initialized
INFO - 2018-05-01 09:04:58 --> Helper loaded: common_helper
INFO - 2018-05-01 09:04:58 --> Database Driver Class Initialized
INFO - 2018-05-01 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:04:58 --> Email Class Initialized
INFO - 2018-05-01 09:04:58 --> Controller Class Initialized
INFO - 2018-05-01 09:04:58 --> Helper loaded: form_helper
INFO - 2018-05-01 09:04:58 --> Form Validation Class Initialized
INFO - 2018-05-01 09:04:58 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:04:58 --> Helper loaded: url_helper
INFO - 2018-05-01 09:04:58 --> Model Class Initialized
INFO - 2018-05-01 09:04:58 --> Model Class Initialized
DEBUG - 2018-05-01 09:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:04:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-05-01 09:04:58 --> Invalid argument supplied for foreach()
ERROR - 2018-05-01 09:04:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\Celebrity\admin\application\controllers\SocialService.php 269
INFO - 2018-05-01 09:04:58 --> Config Class Initialized
INFO - 2018-05-01 09:04:58 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:04:58 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:04:58 --> Utf8 Class Initialized
INFO - 2018-05-01 09:04:58 --> URI Class Initialized
INFO - 2018-05-01 09:04:58 --> Router Class Initialized
INFO - 2018-05-01 09:04:58 --> Output Class Initialized
INFO - 2018-05-01 09:04:58 --> Security Class Initialized
DEBUG - 2018-05-01 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:04:58 --> Input Class Initialized
INFO - 2018-05-01 09:04:58 --> Language Class Initialized
INFO - 2018-05-01 09:04:58 --> Loader Class Initialized
INFO - 2018-05-01 09:04:58 --> Helper loaded: common_helper
INFO - 2018-05-01 09:04:58 --> Database Driver Class Initialized
INFO - 2018-05-01 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:04:58 --> Email Class Initialized
INFO - 2018-05-01 09:04:58 --> Controller Class Initialized
INFO - 2018-05-01 09:04:58 --> Helper loaded: form_helper
INFO - 2018-05-01 09:04:58 --> Form Validation Class Initialized
INFO - 2018-05-01 09:04:58 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:04:58 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:04:58 --> Helper loaded: url_helper
INFO - 2018-05-01 09:04:58 --> Model Class Initialized
INFO - 2018-05-01 09:04:58 --> Model Class Initialized
INFO - 2018-05-01 09:04:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:04:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:04:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:04:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:04:58 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:04:58 --> Final output sent to browser
DEBUG - 2018-05-01 09:04:58 --> Total execution time: 0.1270
INFO - 2018-05-01 09:05:46 --> Config Class Initialized
INFO - 2018-05-01 09:05:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:05:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:05:46 --> Utf8 Class Initialized
INFO - 2018-05-01 09:05:46 --> URI Class Initialized
INFO - 2018-05-01 09:05:46 --> Router Class Initialized
INFO - 2018-05-01 09:05:46 --> Output Class Initialized
INFO - 2018-05-01 09:05:46 --> Security Class Initialized
DEBUG - 2018-05-01 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:05:46 --> Input Class Initialized
INFO - 2018-05-01 09:05:46 --> Language Class Initialized
INFO - 2018-05-01 09:05:46 --> Loader Class Initialized
INFO - 2018-05-01 09:05:46 --> Helper loaded: common_helper
INFO - 2018-05-01 09:05:46 --> Database Driver Class Initialized
INFO - 2018-05-01 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:05:46 --> Email Class Initialized
INFO - 2018-05-01 09:05:46 --> Controller Class Initialized
INFO - 2018-05-01 09:05:46 --> Helper loaded: form_helper
INFO - 2018-05-01 09:05:46 --> Form Validation Class Initialized
INFO - 2018-05-01 09:05:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:05:46 --> Helper loaded: url_helper
INFO - 2018-05-01 09:05:46 --> Model Class Initialized
INFO - 2018-05-01 09:05:46 --> Model Class Initialized
INFO - 2018-05-01 09:05:46 --> Config Class Initialized
INFO - 2018-05-01 09:05:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:05:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:05:46 --> Utf8 Class Initialized
INFO - 2018-05-01 09:05:46 --> URI Class Initialized
INFO - 2018-05-01 09:05:46 --> Router Class Initialized
INFO - 2018-05-01 09:05:46 --> Output Class Initialized
INFO - 2018-05-01 09:05:46 --> Security Class Initialized
DEBUG - 2018-05-01 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:05:46 --> Input Class Initialized
INFO - 2018-05-01 09:05:46 --> Language Class Initialized
INFO - 2018-05-01 09:05:46 --> Loader Class Initialized
INFO - 2018-05-01 09:05:46 --> Helper loaded: common_helper
INFO - 2018-05-01 09:05:46 --> Database Driver Class Initialized
INFO - 2018-05-01 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:05:46 --> Email Class Initialized
INFO - 2018-05-01 09:05:46 --> Controller Class Initialized
INFO - 2018-05-01 09:05:46 --> Helper loaded: form_helper
INFO - 2018-05-01 09:05:46 --> Form Validation Class Initialized
INFO - 2018-05-01 09:05:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:05:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:05:46 --> Helper loaded: url_helper
INFO - 2018-05-01 09:05:46 --> Model Class Initialized
INFO - 2018-05-01 09:05:46 --> Model Class Initialized
INFO - 2018-05-01 09:05:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:05:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:05:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:05:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:05:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:05:46 --> Final output sent to browser
DEBUG - 2018-05-01 09:05:46 --> Total execution time: 0.1300
INFO - 2018-05-01 09:08:41 --> Config Class Initialized
INFO - 2018-05-01 09:08:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:41 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:41 --> URI Class Initialized
INFO - 2018-05-01 09:08:41 --> Router Class Initialized
INFO - 2018-05-01 09:08:41 --> Output Class Initialized
INFO - 2018-05-01 09:08:41 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:41 --> Input Class Initialized
INFO - 2018-05-01 09:08:41 --> Language Class Initialized
INFO - 2018-05-01 09:08:41 --> Loader Class Initialized
INFO - 2018-05-01 09:08:41 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:41 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:41 --> Email Class Initialized
INFO - 2018-05-01 09:08:41 --> Controller Class Initialized
INFO - 2018-05-01 09:08:41 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:41 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:41 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:41 --> Model Class Initialized
INFO - 2018-05-01 09:08:41 --> Model Class Initialized
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:41 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:41 --> Total execution time: 0.1660
INFO - 2018-05-01 09:08:42 --> Config Class Initialized
INFO - 2018-05-01 09:08:42 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:42 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:42 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:42 --> URI Class Initialized
INFO - 2018-05-01 09:08:42 --> Router Class Initialized
INFO - 2018-05-01 09:08:42 --> Output Class Initialized
INFO - 2018-05-01 09:08:42 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:42 --> Input Class Initialized
INFO - 2018-05-01 09:08:42 --> Language Class Initialized
INFO - 2018-05-01 09:08:42 --> Loader Class Initialized
INFO - 2018-05-01 09:08:42 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:42 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:42 --> Email Class Initialized
INFO - 2018-05-01 09:08:42 --> Controller Class Initialized
INFO - 2018-05-01 09:08:42 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:42 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:42 --> Config Class Initialized
INFO - 2018-05-01 09:08:42 --> Hooks Class Initialized
INFO - 2018-05-01 09:08:42 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:42 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:42 --> Model Class Initialized
INFO - 2018-05-01 09:08:42 --> Model Class Initialized
DEBUG - 2018-05-01 09:08:42 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:42 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:42 --> URI Class Initialized
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:42 --> Router Class Initialized
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:42 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:42 --> Total execution time: 0.1790
INFO - 2018-05-01 09:08:42 --> Output Class Initialized
INFO - 2018-05-01 09:08:42 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:42 --> Input Class Initialized
INFO - 2018-05-01 09:08:42 --> Language Class Initialized
INFO - 2018-05-01 09:08:42 --> Loader Class Initialized
INFO - 2018-05-01 09:08:42 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:42 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:42 --> Email Class Initialized
INFO - 2018-05-01 09:08:42 --> Controller Class Initialized
INFO - 2018-05-01 09:08:42 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:42 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:42 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:42 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:42 --> Model Class Initialized
INFO - 2018-05-01 09:08:42 --> Model Class Initialized
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:42 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:42 --> Total execution time: 0.1740
INFO - 2018-05-01 09:08:43 --> Config Class Initialized
INFO - 2018-05-01 09:08:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:43 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:43 --> URI Class Initialized
INFO - 2018-05-01 09:08:43 --> Router Class Initialized
INFO - 2018-05-01 09:08:43 --> Output Class Initialized
INFO - 2018-05-01 09:08:43 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:43 --> Input Class Initialized
INFO - 2018-05-01 09:08:43 --> Language Class Initialized
INFO - 2018-05-01 09:08:43 --> Loader Class Initialized
INFO - 2018-05-01 09:08:43 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:43 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:43 --> Email Class Initialized
INFO - 2018-05-01 09:08:43 --> Controller Class Initialized
INFO - 2018-05-01 09:08:43 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:43 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:43 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:43 --> Model Class Initialized
INFO - 2018-05-01 09:08:43 --> Model Class Initialized
INFO - 2018-05-01 09:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:08:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:43 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:43 --> Total execution time: 0.1620
INFO - 2018-05-01 09:08:44 --> Config Class Initialized
INFO - 2018-05-01 09:08:44 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:44 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:44 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:44 --> URI Class Initialized
INFO - 2018-05-01 09:08:44 --> Router Class Initialized
INFO - 2018-05-01 09:08:44 --> Output Class Initialized
INFO - 2018-05-01 09:08:44 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:44 --> Input Class Initialized
INFO - 2018-05-01 09:08:44 --> Language Class Initialized
INFO - 2018-05-01 09:08:44 --> Loader Class Initialized
INFO - 2018-05-01 09:08:44 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:44 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:44 --> Email Class Initialized
INFO - 2018-05-01 09:08:44 --> Controller Class Initialized
INFO - 2018-05-01 09:08:44 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:44 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:44 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:44 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:44 --> Model Class Initialized
INFO - 2018-05-01 09:08:44 --> Model Class Initialized
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:44 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:44 --> Total execution time: 0.1400
INFO - 2018-05-01 09:08:44 --> Config Class Initialized
INFO - 2018-05-01 09:08:44 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:44 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:44 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:44 --> URI Class Initialized
INFO - 2018-05-01 09:08:44 --> Router Class Initialized
INFO - 2018-05-01 09:08:44 --> Output Class Initialized
INFO - 2018-05-01 09:08:44 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:44 --> Input Class Initialized
INFO - 2018-05-01 09:08:44 --> Language Class Initialized
INFO - 2018-05-01 09:08:44 --> Loader Class Initialized
INFO - 2018-05-01 09:08:44 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:44 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:44 --> Email Class Initialized
INFO - 2018-05-01 09:08:44 --> Controller Class Initialized
INFO - 2018-05-01 09:08:44 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:44 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:44 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:44 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:44 --> Model Class Initialized
INFO - 2018-05-01 09:08:44 --> Model Class Initialized
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:08:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:44 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:44 --> Total execution time: 0.1800
INFO - 2018-05-01 09:08:45 --> Config Class Initialized
INFO - 2018-05-01 09:08:45 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:45 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:45 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:45 --> URI Class Initialized
INFO - 2018-05-01 09:08:45 --> Router Class Initialized
INFO - 2018-05-01 09:08:45 --> Output Class Initialized
INFO - 2018-05-01 09:08:45 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:45 --> Input Class Initialized
INFO - 2018-05-01 09:08:45 --> Language Class Initialized
INFO - 2018-05-01 09:08:45 --> Loader Class Initialized
INFO - 2018-05-01 09:08:45 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:45 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:45 --> Email Class Initialized
INFO - 2018-05-01 09:08:45 --> Controller Class Initialized
INFO - 2018-05-01 09:08:45 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:45 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:45 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:45 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:45 --> Model Class Initialized
INFO - 2018-05-01 09:08:45 --> Model Class Initialized
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/editSocialService.php
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:45 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:45 --> Total execution time: 0.1470
INFO - 2018-05-01 09:08:46 --> Config Class Initialized
INFO - 2018-05-01 09:08:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:46 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:46 --> URI Class Initialized
INFO - 2018-05-01 09:08:46 --> Router Class Initialized
INFO - 2018-05-01 09:08:46 --> Output Class Initialized
INFO - 2018-05-01 09:08:46 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:46 --> Input Class Initialized
INFO - 2018-05-01 09:08:46 --> Language Class Initialized
INFO - 2018-05-01 09:08:46 --> Loader Class Initialized
INFO - 2018-05-01 09:08:46 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:46 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:46 --> Email Class Initialized
INFO - 2018-05-01 09:08:46 --> Controller Class Initialized
INFO - 2018-05-01 09:08:46 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:46 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:46 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:46 --> Model Class Initialized
INFO - 2018-05-01 09:08:46 --> Model Class Initialized
INFO - 2018-05-01 09:08:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:08:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:46 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:46 --> Total execution time: 0.1620
INFO - 2018-05-01 09:08:46 --> Config Class Initialized
INFO - 2018-05-01 09:08:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:46 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:46 --> URI Class Initialized
INFO - 2018-05-01 09:08:46 --> Router Class Initialized
INFO - 2018-05-01 09:08:46 --> Output Class Initialized
INFO - 2018-05-01 09:08:46 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:46 --> Input Class Initialized
INFO - 2018-05-01 09:08:46 --> Language Class Initialized
INFO - 2018-05-01 09:08:46 --> Loader Class Initialized
INFO - 2018-05-01 09:08:46 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:46 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:47 --> Email Class Initialized
INFO - 2018-05-01 09:08:47 --> Controller Class Initialized
INFO - 2018-05-01 09:08:47 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:47 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:47 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:47 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:47 --> Model Class Initialized
INFO - 2018-05-01 09:08:47 --> Model Class Initialized
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:47 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:47 --> Total execution time: 0.1460
INFO - 2018-05-01 09:08:47 --> Config Class Initialized
INFO - 2018-05-01 09:08:47 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:47 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:47 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:47 --> URI Class Initialized
INFO - 2018-05-01 09:08:47 --> Router Class Initialized
INFO - 2018-05-01 09:08:47 --> Output Class Initialized
INFO - 2018-05-01 09:08:47 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:47 --> Input Class Initialized
INFO - 2018-05-01 09:08:47 --> Language Class Initialized
INFO - 2018-05-01 09:08:47 --> Loader Class Initialized
INFO - 2018-05-01 09:08:47 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:47 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:47 --> Email Class Initialized
INFO - 2018-05-01 09:08:47 --> Controller Class Initialized
INFO - 2018-05-01 09:08:47 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:47 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:47 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:47 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:47 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:47 --> Model Class Initialized
INFO - 2018-05-01 09:08:47 --> Model Class Initialized
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:08:47 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:47 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:47 --> Total execution time: 0.1700
INFO - 2018-05-01 09:08:48 --> Config Class Initialized
INFO - 2018-05-01 09:08:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:48 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:48 --> URI Class Initialized
INFO - 2018-05-01 09:08:48 --> Router Class Initialized
INFO - 2018-05-01 09:08:48 --> Output Class Initialized
INFO - 2018-05-01 09:08:48 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:48 --> Input Class Initialized
INFO - 2018-05-01 09:08:48 --> Language Class Initialized
INFO - 2018-05-01 09:08:48 --> Loader Class Initialized
INFO - 2018-05-01 09:08:48 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:48 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:48 --> Email Class Initialized
INFO - 2018-05-01 09:08:48 --> Controller Class Initialized
INFO - 2018-05-01 09:08:48 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:48 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:48 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:48 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:48 --> Model Class Initialized
INFO - 2018-05-01 09:08:48 --> Model Class Initialized
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/addSocialService.php
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:48 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:48 --> Total execution time: 0.1380
INFO - 2018-05-01 09:08:49 --> Config Class Initialized
INFO - 2018-05-01 09:08:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:49 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:49 --> URI Class Initialized
INFO - 2018-05-01 09:08:49 --> Router Class Initialized
INFO - 2018-05-01 09:08:49 --> Output Class Initialized
INFO - 2018-05-01 09:08:49 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:49 --> Input Class Initialized
INFO - 2018-05-01 09:08:49 --> Language Class Initialized
INFO - 2018-05-01 09:08:49 --> Loader Class Initialized
INFO - 2018-05-01 09:08:49 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:49 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:49 --> Email Class Initialized
INFO - 2018-05-01 09:08:49 --> Controller Class Initialized
INFO - 2018-05-01 09:08:49 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:49 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:49 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:49 --> Model Class Initialized
INFO - 2018-05-01 09:08:49 --> Model Class Initialized
INFO - 2018-05-01 09:08:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\socialService/socialService.php
INFO - 2018-05-01 09:08:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:49 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:49 --> Total execution time: 0.1480
INFO - 2018-05-01 09:08:49 --> Config Class Initialized
INFO - 2018-05-01 09:08:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:49 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:49 --> URI Class Initialized
INFO - 2018-05-01 09:08:49 --> Router Class Initialized
INFO - 2018-05-01 09:08:49 --> Output Class Initialized
INFO - 2018-05-01 09:08:49 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:49 --> Input Class Initialized
INFO - 2018-05-01 09:08:49 --> Language Class Initialized
INFO - 2018-05-01 09:08:49 --> Loader Class Initialized
INFO - 2018-05-01 09:08:49 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:49 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:49 --> Email Class Initialized
INFO - 2018-05-01 09:08:49 --> Controller Class Initialized
INFO - 2018-05-01 09:08:49 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:49 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:49 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:49 --> Model Class Initialized
INFO - 2018-05-01 09:08:49 --> Model Class Initialized
INFO - 2018-05-01 09:08:49 --> Model Class Initialized
INFO - 2018-05-01 12:38:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:38:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:38:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:38:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:38:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:38:49 --> Final output sent to browser
DEBUG - 2018-05-01 12:38:49 --> Total execution time: 0.1750
INFO - 2018-05-01 09:08:51 --> Config Class Initialized
INFO - 2018-05-01 09:08:51 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:51 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:51 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:51 --> URI Class Initialized
INFO - 2018-05-01 09:08:51 --> Router Class Initialized
INFO - 2018-05-01 09:08:51 --> Output Class Initialized
INFO - 2018-05-01 09:08:51 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:51 --> Input Class Initialized
INFO - 2018-05-01 09:08:51 --> Language Class Initialized
INFO - 2018-05-01 09:08:51 --> Loader Class Initialized
INFO - 2018-05-01 09:08:51 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:51 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:51 --> Email Class Initialized
INFO - 2018-05-01 09:08:51 --> Controller Class Initialized
INFO - 2018-05-01 09:08:51 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:51 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:51 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:51 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:51 --> Model Class Initialized
INFO - 2018-05-01 09:08:51 --> Model Class Initialized
INFO - 2018-05-01 09:08:51 --> Model Class Initialized
INFO - 2018-05-01 12:38:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:38:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:38:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:38:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-01 12:38:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:38:51 --> Final output sent to browser
DEBUG - 2018-05-01 12:38:51 --> Total execution time: 0.1460
INFO - 2018-05-01 09:08:52 --> Config Class Initialized
INFO - 2018-05-01 09:08:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:52 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:52 --> URI Class Initialized
INFO - 2018-05-01 09:08:52 --> Router Class Initialized
INFO - 2018-05-01 09:08:52 --> Output Class Initialized
INFO - 2018-05-01 09:08:52 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:52 --> Input Class Initialized
INFO - 2018-05-01 09:08:52 --> Language Class Initialized
INFO - 2018-05-01 09:08:52 --> Loader Class Initialized
INFO - 2018-05-01 09:08:52 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:52 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:52 --> Email Class Initialized
INFO - 2018-05-01 09:08:52 --> Controller Class Initialized
INFO - 2018-05-01 09:08:52 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:52 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:52 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:52 --> Model Class Initialized
INFO - 2018-05-01 09:08:52 --> Model Class Initialized
INFO - 2018-05-01 09:08:52 --> Model Class Initialized
INFO - 2018-05-01 12:38:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:38:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:38:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:38:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:38:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:38:52 --> Final output sent to browser
DEBUG - 2018-05-01 12:38:52 --> Total execution time: 0.1430
INFO - 2018-05-01 09:08:55 --> Config Class Initialized
INFO - 2018-05-01 09:08:55 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:08:55 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:08:55 --> Utf8 Class Initialized
INFO - 2018-05-01 09:08:55 --> URI Class Initialized
INFO - 2018-05-01 09:08:55 --> Router Class Initialized
INFO - 2018-05-01 09:08:55 --> Output Class Initialized
INFO - 2018-05-01 09:08:55 --> Security Class Initialized
DEBUG - 2018-05-01 09:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:08:55 --> Input Class Initialized
INFO - 2018-05-01 09:08:55 --> Language Class Initialized
INFO - 2018-05-01 09:08:55 --> Loader Class Initialized
INFO - 2018-05-01 09:08:55 --> Helper loaded: common_helper
INFO - 2018-05-01 09:08:55 --> Database Driver Class Initialized
INFO - 2018-05-01 09:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:08:55 --> Email Class Initialized
INFO - 2018-05-01 09:08:55 --> Controller Class Initialized
INFO - 2018-05-01 09:08:55 --> Helper loaded: form_helper
INFO - 2018-05-01 09:08:55 --> Form Validation Class Initialized
INFO - 2018-05-01 09:08:55 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:08:55 --> Helper loaded: url_helper
INFO - 2018-05-01 09:08:55 --> Model Class Initialized
INFO - 2018-05-01 09:08:55 --> Model Class Initialized
INFO - 2018-05-01 09:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:08:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:08:55 --> Final output sent to browser
DEBUG - 2018-05-01 09:08:55 --> Total execution time: 0.1380
INFO - 2018-05-01 09:09:01 --> Config Class Initialized
INFO - 2018-05-01 09:09:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:01 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:01 --> URI Class Initialized
INFO - 2018-05-01 09:09:01 --> Router Class Initialized
INFO - 2018-05-01 09:09:01 --> Output Class Initialized
INFO - 2018-05-01 09:09:01 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:01 --> Input Class Initialized
INFO - 2018-05-01 09:09:01 --> Language Class Initialized
INFO - 2018-05-01 09:09:01 --> Loader Class Initialized
INFO - 2018-05-01 09:09:01 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:01 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:01 --> Email Class Initialized
INFO - 2018-05-01 09:09:01 --> Controller Class Initialized
INFO - 2018-05-01 09:09:01 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:01 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:01 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:01 --> Model Class Initialized
INFO - 2018-05-01 09:09:01 --> Model Class Initialized
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/addEvent.php
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:09:01 --> Final output sent to browser
DEBUG - 2018-05-01 09:09:01 --> Total execution time: 0.1430
INFO - 2018-05-01 09:09:22 --> Config Class Initialized
INFO - 2018-05-01 09:09:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:22 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:22 --> URI Class Initialized
INFO - 2018-05-01 09:09:22 --> Router Class Initialized
INFO - 2018-05-01 09:09:22 --> Output Class Initialized
INFO - 2018-05-01 09:09:22 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:22 --> Input Class Initialized
INFO - 2018-05-01 09:09:22 --> Language Class Initialized
INFO - 2018-05-01 09:09:22 --> Loader Class Initialized
INFO - 2018-05-01 09:09:22 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:22 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:22 --> Email Class Initialized
INFO - 2018-05-01 09:09:22 --> Controller Class Initialized
INFO - 2018-05-01 09:09:22 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:22 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:22 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:22 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:22 --> Model Class Initialized
INFO - 2018-05-01 09:09:22 --> Model Class Initialized
DEBUG - 2018-05-01 09:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 09:09:22 --> Config Class Initialized
INFO - 2018-05-01 09:09:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:22 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:22 --> URI Class Initialized
INFO - 2018-05-01 09:09:22 --> Router Class Initialized
INFO - 2018-05-01 09:09:22 --> Output Class Initialized
INFO - 2018-05-01 09:09:22 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:22 --> Input Class Initialized
INFO - 2018-05-01 09:09:22 --> Language Class Initialized
INFO - 2018-05-01 09:09:22 --> Loader Class Initialized
INFO - 2018-05-01 09:09:22 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:22 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:22 --> Email Class Initialized
INFO - 2018-05-01 09:09:22 --> Controller Class Initialized
INFO - 2018-05-01 09:09:22 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:22 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:22 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:22 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:22 --> Model Class Initialized
INFO - 2018-05-01 09:09:22 --> Model Class Initialized
INFO - 2018-05-01 09:09:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:09:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:09:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:09:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:09:22 --> Final output sent to browser
DEBUG - 2018-05-01 09:09:22 --> Total execution time: 0.1260
INFO - 2018-05-01 09:09:32 --> Config Class Initialized
INFO - 2018-05-01 09:09:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:32 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:32 --> URI Class Initialized
INFO - 2018-05-01 09:09:32 --> Router Class Initialized
INFO - 2018-05-01 09:09:32 --> Output Class Initialized
INFO - 2018-05-01 09:09:32 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:32 --> Input Class Initialized
INFO - 2018-05-01 09:09:32 --> Language Class Initialized
INFO - 2018-05-01 09:09:32 --> Loader Class Initialized
INFO - 2018-05-01 09:09:32 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:32 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:33 --> Email Class Initialized
INFO - 2018-05-01 09:09:33 --> Controller Class Initialized
INFO - 2018-05-01 09:09:33 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:33 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:33 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:33 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:33 --> Model Class Initialized
INFO - 2018-05-01 09:09:33 --> Model Class Initialized
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/editEvent.php
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:09:33 --> Final output sent to browser
DEBUG - 2018-05-01 09:09:33 --> Total execution time: 0.1270
INFO - 2018-05-01 09:09:41 --> Config Class Initialized
INFO - 2018-05-01 09:09:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:41 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:41 --> URI Class Initialized
INFO - 2018-05-01 09:09:41 --> Router Class Initialized
INFO - 2018-05-01 09:09:41 --> Output Class Initialized
INFO - 2018-05-01 09:09:41 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:41 --> Input Class Initialized
INFO - 2018-05-01 09:09:41 --> Language Class Initialized
INFO - 2018-05-01 09:09:41 --> Loader Class Initialized
INFO - 2018-05-01 09:09:41 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:41 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:41 --> Email Class Initialized
INFO - 2018-05-01 09:09:41 --> Controller Class Initialized
INFO - 2018-05-01 09:09:41 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:41 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:41 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:41 --> Model Class Initialized
INFO - 2018-05-01 09:09:41 --> Model Class Initialized
DEBUG - 2018-05-01 09:09:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 09:09:41 --> Config Class Initialized
INFO - 2018-05-01 09:09:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:41 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:41 --> URI Class Initialized
INFO - 2018-05-01 09:09:41 --> Router Class Initialized
INFO - 2018-05-01 09:09:41 --> Output Class Initialized
INFO - 2018-05-01 09:09:41 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:41 --> Input Class Initialized
INFO - 2018-05-01 09:09:41 --> Language Class Initialized
INFO - 2018-05-01 09:09:41 --> Loader Class Initialized
INFO - 2018-05-01 09:09:41 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:41 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:41 --> Email Class Initialized
INFO - 2018-05-01 09:09:41 --> Controller Class Initialized
INFO - 2018-05-01 09:09:41 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:41 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:41 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:41 --> Model Class Initialized
INFO - 2018-05-01 09:09:41 --> Model Class Initialized
INFO - 2018-05-01 09:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:09:41 --> Final output sent to browser
DEBUG - 2018-05-01 09:09:41 --> Total execution time: 0.1410
INFO - 2018-05-01 09:09:49 --> Config Class Initialized
INFO - 2018-05-01 09:09:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:09:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:09:49 --> Utf8 Class Initialized
INFO - 2018-05-01 09:09:49 --> URI Class Initialized
INFO - 2018-05-01 09:09:49 --> Router Class Initialized
INFO - 2018-05-01 09:09:49 --> Output Class Initialized
INFO - 2018-05-01 09:09:49 --> Security Class Initialized
DEBUG - 2018-05-01 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:09:49 --> Input Class Initialized
INFO - 2018-05-01 09:09:49 --> Language Class Initialized
INFO - 2018-05-01 09:09:49 --> Loader Class Initialized
INFO - 2018-05-01 09:09:49 --> Helper loaded: common_helper
INFO - 2018-05-01 09:09:49 --> Database Driver Class Initialized
INFO - 2018-05-01 09:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:09:49 --> Email Class Initialized
INFO - 2018-05-01 09:09:49 --> Controller Class Initialized
INFO - 2018-05-01 09:09:49 --> Helper loaded: form_helper
INFO - 2018-05-01 09:09:49 --> Form Validation Class Initialized
INFO - 2018-05-01 09:09:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:09:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:09:49 --> Helper loaded: url_helper
INFO - 2018-05-01 09:09:49 --> Model Class Initialized
INFO - 2018-05-01 09:09:49 --> Model Class Initialized
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/editEvent.php
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:09:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:09:49 --> Final output sent to browser
DEBUG - 2018-05-01 09:09:49 --> Total execution time: 0.1290
INFO - 2018-05-01 09:10:33 --> Config Class Initialized
INFO - 2018-05-01 09:10:33 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:10:33 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:10:33 --> Utf8 Class Initialized
INFO - 2018-05-01 09:10:33 --> URI Class Initialized
INFO - 2018-05-01 09:10:33 --> Router Class Initialized
INFO - 2018-05-01 09:10:33 --> Output Class Initialized
INFO - 2018-05-01 09:10:33 --> Security Class Initialized
DEBUG - 2018-05-01 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:10:33 --> Input Class Initialized
INFO - 2018-05-01 09:10:33 --> Language Class Initialized
INFO - 2018-05-01 09:10:33 --> Loader Class Initialized
INFO - 2018-05-01 09:10:33 --> Helper loaded: common_helper
INFO - 2018-05-01 09:10:33 --> Database Driver Class Initialized
INFO - 2018-05-01 09:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:10:33 --> Email Class Initialized
INFO - 2018-05-01 09:10:33 --> Controller Class Initialized
INFO - 2018-05-01 09:10:33 --> Helper loaded: form_helper
INFO - 2018-05-01 09:10:33 --> Form Validation Class Initialized
INFO - 2018-05-01 09:10:33 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:33 --> Helper loaded: url_helper
INFO - 2018-05-01 09:10:33 --> Model Class Initialized
INFO - 2018-05-01 09:10:33 --> Model Class Initialized
DEBUG - 2018-05-01 09:10:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 09:10:38 --> Config Class Initialized
INFO - 2018-05-01 09:10:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:10:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:10:38 --> Utf8 Class Initialized
INFO - 2018-05-01 09:10:38 --> URI Class Initialized
INFO - 2018-05-01 09:10:38 --> Router Class Initialized
INFO - 2018-05-01 09:10:38 --> Output Class Initialized
INFO - 2018-05-01 09:10:38 --> Security Class Initialized
DEBUG - 2018-05-01 09:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:10:38 --> Input Class Initialized
INFO - 2018-05-01 09:10:38 --> Language Class Initialized
INFO - 2018-05-01 09:10:38 --> Loader Class Initialized
INFO - 2018-05-01 09:10:38 --> Helper loaded: common_helper
INFO - 2018-05-01 09:10:38 --> Database Driver Class Initialized
INFO - 2018-05-01 09:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:10:38 --> Email Class Initialized
INFO - 2018-05-01 09:10:38 --> Controller Class Initialized
INFO - 2018-05-01 09:10:38 --> Helper loaded: form_helper
INFO - 2018-05-01 09:10:38 --> Form Validation Class Initialized
INFO - 2018-05-01 09:10:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:38 --> Helper loaded: url_helper
INFO - 2018-05-01 09:10:38 --> Model Class Initialized
INFO - 2018-05-01 09:10:38 --> Model Class Initialized
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/editEvent.php
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:10:38 --> Final output sent to browser
DEBUG - 2018-05-01 09:10:38 --> Total execution time: 0.1400
INFO - 2018-05-01 09:10:41 --> Config Class Initialized
INFO - 2018-05-01 09:10:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:10:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:10:41 --> Utf8 Class Initialized
INFO - 2018-05-01 09:10:41 --> URI Class Initialized
INFO - 2018-05-01 09:10:41 --> Router Class Initialized
INFO - 2018-05-01 09:10:41 --> Output Class Initialized
INFO - 2018-05-01 09:10:41 --> Security Class Initialized
DEBUG - 2018-05-01 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:10:41 --> Input Class Initialized
INFO - 2018-05-01 09:10:41 --> Language Class Initialized
INFO - 2018-05-01 09:10:41 --> Loader Class Initialized
INFO - 2018-05-01 09:10:41 --> Helper loaded: common_helper
INFO - 2018-05-01 09:10:41 --> Database Driver Class Initialized
INFO - 2018-05-01 09:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:10:41 --> Email Class Initialized
INFO - 2018-05-01 09:10:41 --> Controller Class Initialized
INFO - 2018-05-01 09:10:41 --> Helper loaded: form_helper
INFO - 2018-05-01 09:10:41 --> Form Validation Class Initialized
INFO - 2018-05-01 09:10:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:10:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:41 --> Helper loaded: url_helper
INFO - 2018-05-01 09:10:41 --> Model Class Initialized
INFO - 2018-05-01 09:10:41 --> Model Class Initialized
INFO - 2018-05-01 09:10:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:10:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:10:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:10:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:10:41 --> Final output sent to browser
DEBUG - 2018-05-01 09:10:41 --> Total execution time: 0.1340
INFO - 2018-05-01 09:10:48 --> Config Class Initialized
INFO - 2018-05-01 09:10:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:10:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:10:48 --> Utf8 Class Initialized
INFO - 2018-05-01 09:10:48 --> URI Class Initialized
INFO - 2018-05-01 09:10:48 --> Router Class Initialized
INFO - 2018-05-01 09:10:48 --> Output Class Initialized
INFO - 2018-05-01 09:10:48 --> Security Class Initialized
DEBUG - 2018-05-01 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:10:48 --> Input Class Initialized
INFO - 2018-05-01 09:10:48 --> Language Class Initialized
INFO - 2018-05-01 09:10:48 --> Loader Class Initialized
INFO - 2018-05-01 09:10:48 --> Helper loaded: common_helper
INFO - 2018-05-01 09:10:48 --> Database Driver Class Initialized
INFO - 2018-05-01 09:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:10:48 --> Email Class Initialized
INFO - 2018-05-01 09:10:48 --> Controller Class Initialized
INFO - 2018-05-01 09:10:48 --> Helper loaded: form_helper
INFO - 2018-05-01 09:10:48 --> Form Validation Class Initialized
INFO - 2018-05-01 09:10:48 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:10:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:48 --> Helper loaded: url_helper
INFO - 2018-05-01 09:10:48 --> Model Class Initialized
INFO - 2018-05-01 09:10:48 --> Model Class Initialized
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/editEvent.php
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:10:48 --> Final output sent to browser
DEBUG - 2018-05-01 09:10:48 --> Total execution time: 0.1270
INFO - 2018-05-01 09:10:57 --> Config Class Initialized
INFO - 2018-05-01 09:10:57 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:10:57 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:10:57 --> Utf8 Class Initialized
INFO - 2018-05-01 09:10:57 --> URI Class Initialized
INFO - 2018-05-01 09:10:57 --> Router Class Initialized
INFO - 2018-05-01 09:10:57 --> Output Class Initialized
INFO - 2018-05-01 09:10:57 --> Security Class Initialized
DEBUG - 2018-05-01 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:10:57 --> Input Class Initialized
INFO - 2018-05-01 09:10:57 --> Language Class Initialized
INFO - 2018-05-01 09:10:57 --> Loader Class Initialized
INFO - 2018-05-01 09:10:57 --> Helper loaded: common_helper
INFO - 2018-05-01 09:10:57 --> Database Driver Class Initialized
INFO - 2018-05-01 09:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:10:57 --> Email Class Initialized
INFO - 2018-05-01 09:10:57 --> Controller Class Initialized
INFO - 2018-05-01 09:10:57 --> Helper loaded: form_helper
INFO - 2018-05-01 09:10:57 --> Form Validation Class Initialized
INFO - 2018-05-01 09:10:57 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:10:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:57 --> Helper loaded: url_helper
INFO - 2018-05-01 09:10:57 --> Model Class Initialized
INFO - 2018-05-01 09:10:57 --> Model Class Initialized
INFO - 2018-05-01 09:10:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:10:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:10:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:10:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:10:57 --> Final output sent to browser
DEBUG - 2018-05-01 09:10:57 --> Total execution time: 0.1600
INFO - 2018-05-01 09:10:59 --> Config Class Initialized
INFO - 2018-05-01 09:10:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:10:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:10:59 --> Utf8 Class Initialized
INFO - 2018-05-01 09:10:59 --> URI Class Initialized
INFO - 2018-05-01 09:10:59 --> Router Class Initialized
INFO - 2018-05-01 09:10:59 --> Output Class Initialized
INFO - 2018-05-01 09:10:59 --> Security Class Initialized
DEBUG - 2018-05-01 09:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:10:59 --> Input Class Initialized
INFO - 2018-05-01 09:10:59 --> Language Class Initialized
INFO - 2018-05-01 09:10:59 --> Loader Class Initialized
INFO - 2018-05-01 09:10:59 --> Helper loaded: common_helper
INFO - 2018-05-01 09:10:59 --> Database Driver Class Initialized
INFO - 2018-05-01 09:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:10:59 --> Email Class Initialized
INFO - 2018-05-01 09:10:59 --> Controller Class Initialized
INFO - 2018-05-01 09:10:59 --> Helper loaded: form_helper
INFO - 2018-05-01 09:10:59 --> Form Validation Class Initialized
INFO - 2018-05-01 09:10:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:10:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:10:59 --> Helper loaded: url_helper
INFO - 2018-05-01 09:10:59 --> Model Class Initialized
INFO - 2018-05-01 09:10:59 --> Model Class Initialized
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/editEvent.php
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:10:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:10:59 --> Final output sent to browser
DEBUG - 2018-05-01 09:10:59 --> Total execution time: 0.1360
INFO - 2018-05-01 09:13:51 --> Config Class Initialized
INFO - 2018-05-01 09:13:51 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:51 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:51 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:51 --> URI Class Initialized
INFO - 2018-05-01 09:13:51 --> Router Class Initialized
INFO - 2018-05-01 09:13:51 --> Output Class Initialized
INFO - 2018-05-01 09:13:51 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:51 --> Input Class Initialized
INFO - 2018-05-01 09:13:51 --> Language Class Initialized
INFO - 2018-05-01 09:13:51 --> Loader Class Initialized
INFO - 2018-05-01 09:13:51 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:51 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:51 --> Email Class Initialized
INFO - 2018-05-01 09:13:51 --> Controller Class Initialized
INFO - 2018-05-01 09:13:51 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:51 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:51 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:51 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:51 --> Model Class Initialized
INFO - 2018-05-01 09:13:51 --> Model Class Initialized
INFO - 2018-05-01 09:13:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:13:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:13:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:13:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:13:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:13:51 --> Final output sent to browser
DEBUG - 2018-05-01 09:13:51 --> Total execution time: 0.1660
INFO - 2018-05-01 09:13:52 --> Config Class Initialized
INFO - 2018-05-01 09:13:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:52 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:52 --> URI Class Initialized
INFO - 2018-05-01 09:13:52 --> Router Class Initialized
INFO - 2018-05-01 09:13:52 --> Output Class Initialized
INFO - 2018-05-01 09:13:52 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:52 --> Input Class Initialized
INFO - 2018-05-01 09:13:52 --> Language Class Initialized
INFO - 2018-05-01 09:13:52 --> Loader Class Initialized
INFO - 2018-05-01 09:13:52 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:52 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:52 --> Email Class Initialized
INFO - 2018-05-01 09:13:52 --> Controller Class Initialized
INFO - 2018-05-01 09:13:52 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:52 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:52 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:52 --> Model Class Initialized
INFO - 2018-05-01 09:13:52 --> Model Class Initialized
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\datetime_calender.php
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/addEvent.php
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:13:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:13:52 --> Final output sent to browser
DEBUG - 2018-05-01 09:13:52 --> Total execution time: 0.1430
INFO - 2018-05-01 09:13:53 --> Config Class Initialized
INFO - 2018-05-01 09:13:53 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:53 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:53 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:53 --> URI Class Initialized
INFO - 2018-05-01 09:13:53 --> Router Class Initialized
INFO - 2018-05-01 09:13:53 --> Output Class Initialized
INFO - 2018-05-01 09:13:53 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:53 --> Input Class Initialized
INFO - 2018-05-01 09:13:53 --> Language Class Initialized
INFO - 2018-05-01 09:13:53 --> Loader Class Initialized
INFO - 2018-05-01 09:13:53 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:53 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:53 --> Email Class Initialized
INFO - 2018-05-01 09:13:53 --> Controller Class Initialized
INFO - 2018-05-01 09:13:53 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:53 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:53 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:53 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:53 --> Model Class Initialized
INFO - 2018-05-01 09:13:53 --> Model Class Initialized
INFO - 2018-05-01 09:13:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:13:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:13:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:13:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:13:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:13:53 --> Final output sent to browser
DEBUG - 2018-05-01 09:13:53 --> Total execution time: 0.1470
INFO - 2018-05-01 09:13:53 --> Config Class Initialized
INFO - 2018-05-01 09:13:53 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:53 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:53 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:53 --> URI Class Initialized
INFO - 2018-05-01 09:13:53 --> Router Class Initialized
INFO - 2018-05-01 09:13:53 --> Output Class Initialized
INFO - 2018-05-01 09:13:53 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:53 --> Input Class Initialized
INFO - 2018-05-01 09:13:53 --> Language Class Initialized
INFO - 2018-05-01 09:13:53 --> Loader Class Initialized
INFO - 2018-05-01 09:13:53 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:53 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:53 --> Email Class Initialized
INFO - 2018-05-01 09:13:53 --> Controller Class Initialized
INFO - 2018-05-01 09:13:54 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:54 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:54 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:54 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:54 --> Model Class Initialized
INFO - 2018-05-01 09:13:54 --> Model Class Initialized
INFO - 2018-05-01 09:13:54 --> Model Class Initialized
INFO - 2018-05-01 12:43:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:43:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:43:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:43:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:43:54 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:43:54 --> Final output sent to browser
DEBUG - 2018-05-01 12:43:54 --> Total execution time: 0.1670
INFO - 2018-05-01 09:13:55 --> Config Class Initialized
INFO - 2018-05-01 09:13:55 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:55 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:55 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:55 --> URI Class Initialized
INFO - 2018-05-01 09:13:55 --> Router Class Initialized
INFO - 2018-05-01 09:13:55 --> Output Class Initialized
INFO - 2018-05-01 09:13:55 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:55 --> Input Class Initialized
INFO - 2018-05-01 09:13:55 --> Language Class Initialized
INFO - 2018-05-01 09:13:55 --> Loader Class Initialized
INFO - 2018-05-01 09:13:55 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:55 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:55 --> Email Class Initialized
INFO - 2018-05-01 09:13:55 --> Controller Class Initialized
INFO - 2018-05-01 09:13:55 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:55 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:55 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:55 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:55 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:55 --> Model Class Initialized
INFO - 2018-05-01 09:13:55 --> Model Class Initialized
INFO - 2018-05-01 09:13:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:13:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:13:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:13:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:13:55 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:13:55 --> Final output sent to browser
DEBUG - 2018-05-01 09:13:55 --> Total execution time: 0.1400
INFO - 2018-05-01 09:13:59 --> Config Class Initialized
INFO - 2018-05-01 09:13:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:59 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:59 --> URI Class Initialized
INFO - 2018-05-01 09:13:59 --> Router Class Initialized
INFO - 2018-05-01 09:13:59 --> Output Class Initialized
INFO - 2018-05-01 09:13:59 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:59 --> Input Class Initialized
INFO - 2018-05-01 09:13:59 --> Language Class Initialized
INFO - 2018-05-01 09:13:59 --> Loader Class Initialized
INFO - 2018-05-01 09:13:59 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:59 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:59 --> Email Class Initialized
INFO - 2018-05-01 09:13:59 --> Controller Class Initialized
INFO - 2018-05-01 09:13:59 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:59 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:59 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:59 --> Model Class Initialized
INFO - 2018-05-01 09:13:59 --> Model Class Initialized
INFO - 2018-05-01 09:13:59 --> Config Class Initialized
INFO - 2018-05-01 09:13:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:13:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:13:59 --> Utf8 Class Initialized
INFO - 2018-05-01 09:13:59 --> URI Class Initialized
INFO - 2018-05-01 09:13:59 --> Router Class Initialized
INFO - 2018-05-01 09:13:59 --> Output Class Initialized
INFO - 2018-05-01 09:13:59 --> Security Class Initialized
DEBUG - 2018-05-01 09:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:13:59 --> Input Class Initialized
INFO - 2018-05-01 09:13:59 --> Language Class Initialized
INFO - 2018-05-01 09:13:59 --> Loader Class Initialized
INFO - 2018-05-01 09:13:59 --> Helper loaded: common_helper
INFO - 2018-05-01 09:13:59 --> Database Driver Class Initialized
INFO - 2018-05-01 09:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:13:59 --> Email Class Initialized
INFO - 2018-05-01 09:13:59 --> Controller Class Initialized
INFO - 2018-05-01 09:13:59 --> Helper loaded: form_helper
INFO - 2018-05-01 09:13:59 --> Form Validation Class Initialized
INFO - 2018-05-01 09:13:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:13:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:13:59 --> Helper loaded: url_helper
INFO - 2018-05-01 09:13:59 --> Model Class Initialized
INFO - 2018-05-01 09:13:59 --> Model Class Initialized
INFO - 2018-05-01 09:13:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 09:13:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 09:13:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 09:13:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\events/event.php
INFO - 2018-05-01 09:13:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 09:13:59 --> Final output sent to browser
DEBUG - 2018-05-01 09:13:59 --> Total execution time: 0.1450
INFO - 2018-05-01 09:14:03 --> Config Class Initialized
INFO - 2018-05-01 09:14:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 09:14:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 09:14:03 --> Utf8 Class Initialized
INFO - 2018-05-01 09:14:03 --> URI Class Initialized
INFO - 2018-05-01 09:14:03 --> Router Class Initialized
INFO - 2018-05-01 09:14:03 --> Output Class Initialized
INFO - 2018-05-01 09:14:03 --> Security Class Initialized
DEBUG - 2018-05-01 09:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 09:14:03 --> Input Class Initialized
INFO - 2018-05-01 09:14:03 --> Language Class Initialized
INFO - 2018-05-01 09:14:03 --> Loader Class Initialized
INFO - 2018-05-01 09:14:03 --> Helper loaded: common_helper
INFO - 2018-05-01 09:14:03 --> Database Driver Class Initialized
INFO - 2018-05-01 09:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 09:14:03 --> Email Class Initialized
INFO - 2018-05-01 09:14:03 --> Controller Class Initialized
INFO - 2018-05-01 09:14:03 --> Helper loaded: form_helper
INFO - 2018-05-01 09:14:03 --> Form Validation Class Initialized
INFO - 2018-05-01 09:14:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 09:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 09:14:03 --> Helper loaded: url_helper
INFO - 2018-05-01 09:14:03 --> Model Class Initialized
INFO - 2018-05-01 09:14:03 --> Model Class Initialized
INFO - 2018-05-01 09:14:03 --> Model Class Initialized
INFO - 2018-05-01 12:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 12:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 12:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 12:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:44:03 --> Final output sent to browser
DEBUG - 2018-05-01 12:44:03 --> Total execution time: 0.1360
INFO - 2018-05-01 12:39:02 --> Config Class Initialized
INFO - 2018-05-01 12:39:02 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:02 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:02 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:02 --> URI Class Initialized
INFO - 2018-05-01 12:39:02 --> Router Class Initialized
INFO - 2018-05-01 12:39:02 --> Output Class Initialized
INFO - 2018-05-01 12:39:02 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:02 --> Input Class Initialized
INFO - 2018-05-01 12:39:02 --> Language Class Initialized
INFO - 2018-05-01 12:39:02 --> Loader Class Initialized
INFO - 2018-05-01 12:39:02 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:02 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:02 --> Email Class Initialized
INFO - 2018-05-01 12:39:02 --> Controller Class Initialized
INFO - 2018-05-01 12:39:02 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:02 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:02 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:03 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> Config Class Initialized
INFO - 2018-05-01 12:39:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:03 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:03 --> URI Class Initialized
INFO - 2018-05-01 12:39:03 --> Router Class Initialized
INFO - 2018-05-01 12:39:03 --> Output Class Initialized
INFO - 2018-05-01 12:39:03 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:03 --> Input Class Initialized
INFO - 2018-05-01 12:39:03 --> Language Class Initialized
INFO - 2018-05-01 12:39:03 --> Loader Class Initialized
INFO - 2018-05-01 12:39:03 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:03 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:03 --> Email Class Initialized
INFO - 2018-05-01 12:39:03 --> Controller Class Initialized
INFO - 2018-05-01 12:39:03 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:03 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:03 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> Config Class Initialized
INFO - 2018-05-01 12:39:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:03 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:03 --> URI Class Initialized
DEBUG - 2018-05-01 12:39:03 --> No URI present. Default controller set.
INFO - 2018-05-01 12:39:03 --> Router Class Initialized
INFO - 2018-05-01 12:39:03 --> Output Class Initialized
INFO - 2018-05-01 12:39:03 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:03 --> Input Class Initialized
INFO - 2018-05-01 12:39:03 --> Language Class Initialized
INFO - 2018-05-01 12:39:03 --> Loader Class Initialized
INFO - 2018-05-01 12:39:03 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:03 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:03 --> Email Class Initialized
INFO - 2018-05-01 12:39:03 --> Controller Class Initialized
INFO - 2018-05-01 12:39:03 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:03 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:03 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> Model Class Initialized
INFO - 2018-05-01 12:39:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\index.php
INFO - 2018-05-01 12:39:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:39:03 --> Final output sent to browser
DEBUG - 2018-05-01 12:39:03 --> Total execution time: 0.1090
INFO - 2018-05-01 12:39:05 --> Config Class Initialized
INFO - 2018-05-01 12:39:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:05 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:05 --> URI Class Initialized
DEBUG - 2018-05-01 12:39:05 --> No URI present. Default controller set.
INFO - 2018-05-01 12:39:05 --> Router Class Initialized
INFO - 2018-05-01 12:39:05 --> Output Class Initialized
INFO - 2018-05-01 12:39:05 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:05 --> Input Class Initialized
INFO - 2018-05-01 12:39:05 --> Language Class Initialized
INFO - 2018-05-01 12:39:05 --> Loader Class Initialized
INFO - 2018-05-01 12:39:05 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:05 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:05 --> Email Class Initialized
INFO - 2018-05-01 12:39:05 --> Controller Class Initialized
INFO - 2018-05-01 12:39:05 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:05 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:05 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:05 --> Model Class Initialized
INFO - 2018-05-01 12:39:05 --> Model Class Initialized
DEBUG - 2018-05-01 12:39:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 12:39:05 --> Config Class Initialized
INFO - 2018-05-01 12:39:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:05 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:05 --> URI Class Initialized
INFO - 2018-05-01 12:39:05 --> Router Class Initialized
INFO - 2018-05-01 12:39:05 --> Output Class Initialized
INFO - 2018-05-01 12:39:05 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:05 --> Input Class Initialized
INFO - 2018-05-01 12:39:05 --> Language Class Initialized
INFO - 2018-05-01 12:39:05 --> Loader Class Initialized
INFO - 2018-05-01 12:39:05 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:05 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:05 --> Email Class Initialized
INFO - 2018-05-01 12:39:05 --> Controller Class Initialized
INFO - 2018-05-01 12:39:05 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:05 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:05 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:05 --> Model Class Initialized
INFO - 2018-05-01 12:39:05 --> Model Class Initialized
INFO - 2018-05-01 12:39:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 12:39:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
ERROR - 2018-05-01 12:39:05 --> Undefined variable: categories
ERROR - 2018-05-01 12:39:05 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-01 12:39:05 --> Trying to get property of non-object
ERROR - 2018-05-01 12:39:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 43
ERROR - 2018-05-01 12:39:05 --> Undefined variable: articles
ERROR - 2018-05-01 12:39:05 --> Severity: Notice --> Undefined variable: articles C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-01 12:39:05 --> Trying to get property of non-object
ERROR - 2018-05-01 12:39:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 55
ERROR - 2018-05-01 12:39:05 --> Undefined variable: subscriptions
ERROR - 2018-05-01 12:39:05 --> Severity: Notice --> Undefined variable: subscriptions C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
ERROR - 2018-05-01 12:39:05 --> Trying to get property of non-object
ERROR - 2018-05-01 12:39:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php 67
INFO - 2018-05-01 12:39:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\dashboard.php
INFO - 2018-05-01 12:39:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 12:39:05 --> Final output sent to browser
DEBUG - 2018-05-01 12:39:05 --> Total execution time: 0.1250
INFO - 2018-05-01 12:39:11 --> Config Class Initialized
INFO - 2018-05-01 12:39:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:11 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:11 --> URI Class Initialized
INFO - 2018-05-01 12:39:11 --> Router Class Initialized
INFO - 2018-05-01 12:39:11 --> Output Class Initialized
INFO - 2018-05-01 12:39:11 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:11 --> Input Class Initialized
INFO - 2018-05-01 12:39:11 --> Language Class Initialized
INFO - 2018-05-01 12:39:11 --> Loader Class Initialized
INFO - 2018-05-01 12:39:11 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:11 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:11 --> Email Class Initialized
INFO - 2018-05-01 12:39:11 --> Controller Class Initialized
INFO - 2018-05-01 12:39:11 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:11 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:11 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:11 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:11 --> Model Class Initialized
INFO - 2018-05-01 12:39:11 --> Model Class Initialized
INFO - 2018-05-01 12:39:11 --> Model Class Initialized
INFO - 2018-05-01 16:09:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 16:09:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-01 16:09:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:11 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:11 --> Total execution time: 0.1130
INFO - 2018-05-01 12:39:18 --> Config Class Initialized
INFO - 2018-05-01 12:39:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:18 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:18 --> URI Class Initialized
INFO - 2018-05-01 12:39:18 --> Router Class Initialized
INFO - 2018-05-01 12:39:18 --> Output Class Initialized
INFO - 2018-05-01 12:39:18 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:18 --> Input Class Initialized
INFO - 2018-05-01 12:39:18 --> Language Class Initialized
INFO - 2018-05-01 12:39:18 --> Loader Class Initialized
INFO - 2018-05-01 12:39:18 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:18 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:18 --> Email Class Initialized
INFO - 2018-05-01 12:39:18 --> Controller Class Initialized
INFO - 2018-05-01 12:39:18 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:18 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:18 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:18 --> Model Class Initialized
INFO - 2018-05-01 12:39:18 --> Model Class Initialized
INFO - 2018-05-01 12:39:18 --> Model Class Initialized
INFO - 2018-05-01 16:09:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 16:09:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 16:09:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:18 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:18 --> Total execution time: 0.1080
INFO - 2018-05-01 12:39:21 --> Config Class Initialized
INFO - 2018-05-01 12:39:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:21 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:21 --> URI Class Initialized
INFO - 2018-05-01 12:39:21 --> Router Class Initialized
INFO - 2018-05-01 12:39:21 --> Output Class Initialized
INFO - 2018-05-01 12:39:21 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:21 --> Input Class Initialized
INFO - 2018-05-01 12:39:21 --> Language Class Initialized
INFO - 2018-05-01 12:39:21 --> Loader Class Initialized
INFO - 2018-05-01 12:39:21 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:21 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:21 --> Email Class Initialized
INFO - 2018-05-01 12:39:21 --> Controller Class Initialized
INFO - 2018-05-01 12:39:21 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:21 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:21 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:21 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:21 --> Model Class Initialized
INFO - 2018-05-01 12:39:21 --> Model Class Initialized
INFO - 2018-05-01 12:39:21 --> Model Class Initialized
INFO - 2018-05-01 16:09:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 16:09:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 16:09:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:21 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:21 --> Total execution time: 0.1130
INFO - 2018-05-01 12:39:25 --> Config Class Initialized
INFO - 2018-05-01 12:39:25 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:25 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:25 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:25 --> URI Class Initialized
INFO - 2018-05-01 12:39:25 --> Router Class Initialized
INFO - 2018-05-01 12:39:25 --> Output Class Initialized
INFO - 2018-05-01 12:39:25 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:25 --> Input Class Initialized
INFO - 2018-05-01 12:39:25 --> Language Class Initialized
INFO - 2018-05-01 12:39:25 --> Loader Class Initialized
INFO - 2018-05-01 12:39:25 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:25 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:25 --> Email Class Initialized
INFO - 2018-05-01 12:39:25 --> Controller Class Initialized
INFO - 2018-05-01 12:39:25 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:25 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:25 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:25 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:25 --> Model Class Initialized
INFO - 2018-05-01 12:39:25 --> Model Class Initialized
INFO - 2018-05-01 12:39:25 --> Model Class Initialized
INFO - 2018-05-01 16:09:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 16:09:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 16:09:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:25 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:25 --> Total execution time: 0.1170
INFO - 2018-05-01 12:39:27 --> Config Class Initialized
INFO - 2018-05-01 12:39:27 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:27 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:27 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:27 --> URI Class Initialized
INFO - 2018-05-01 12:39:27 --> Router Class Initialized
INFO - 2018-05-01 12:39:27 --> Output Class Initialized
INFO - 2018-05-01 12:39:27 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:27 --> Input Class Initialized
INFO - 2018-05-01 12:39:27 --> Language Class Initialized
INFO - 2018-05-01 12:39:27 --> Loader Class Initialized
INFO - 2018-05-01 12:39:27 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:27 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:27 --> Email Class Initialized
INFO - 2018-05-01 12:39:27 --> Controller Class Initialized
INFO - 2018-05-01 12:39:27 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:27 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:27 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:27 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:28 --> Model Class Initialized
INFO - 2018-05-01 12:39:28 --> Model Class Initialized
INFO - 2018-05-01 12:39:28 --> Model Class Initialized
INFO - 2018-05-01 16:09:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 16:09:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 16:09:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:28 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:28 --> Total execution time: 0.1140
INFO - 2018-05-01 12:39:38 --> Config Class Initialized
INFO - 2018-05-01 12:39:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:38 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:38 --> URI Class Initialized
INFO - 2018-05-01 12:39:38 --> Router Class Initialized
INFO - 2018-05-01 12:39:38 --> Output Class Initialized
INFO - 2018-05-01 12:39:38 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:38 --> Input Class Initialized
INFO - 2018-05-01 12:39:38 --> Language Class Initialized
INFO - 2018-05-01 12:39:38 --> Loader Class Initialized
INFO - 2018-05-01 12:39:38 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:38 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:38 --> Email Class Initialized
INFO - 2018-05-01 12:39:38 --> Controller Class Initialized
INFO - 2018-05-01 12:39:38 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:38 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:38 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:38 --> Model Class Initialized
INFO - 2018-05-01 12:39:38 --> Model Class Initialized
INFO - 2018-05-01 12:39:38 --> Model Class Initialized
INFO - 2018-05-01 16:09:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 16:09:38 --> Trying to get property of non-object
ERROR - 2018-05-01 16:09:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 16:09:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 16:09:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:38 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:38 --> Total execution time: 0.1770
INFO - 2018-05-01 12:39:41 --> Config Class Initialized
INFO - 2018-05-01 12:39:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 12:39:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 12:39:41 --> Utf8 Class Initialized
INFO - 2018-05-01 12:39:41 --> URI Class Initialized
INFO - 2018-05-01 12:39:41 --> Router Class Initialized
INFO - 2018-05-01 12:39:41 --> Output Class Initialized
INFO - 2018-05-01 12:39:41 --> Security Class Initialized
DEBUG - 2018-05-01 12:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 12:39:41 --> Input Class Initialized
INFO - 2018-05-01 12:39:41 --> Language Class Initialized
INFO - 2018-05-01 12:39:41 --> Loader Class Initialized
INFO - 2018-05-01 12:39:41 --> Helper loaded: common_helper
INFO - 2018-05-01 12:39:41 --> Database Driver Class Initialized
INFO - 2018-05-01 12:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 12:39:41 --> Email Class Initialized
INFO - 2018-05-01 12:39:41 --> Controller Class Initialized
INFO - 2018-05-01 12:39:41 --> Helper loaded: form_helper
INFO - 2018-05-01 12:39:41 --> Form Validation Class Initialized
INFO - 2018-05-01 12:39:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 12:39:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 12:39:41 --> Helper loaded: url_helper
INFO - 2018-05-01 12:39:41 --> Model Class Initialized
INFO - 2018-05-01 12:39:41 --> Model Class Initialized
INFO - 2018-05-01 12:39:41 --> Model Class Initialized
INFO - 2018-05-01 16:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 16:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 16:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 16:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 16:09:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 16:09:41 --> Final output sent to browser
DEBUG - 2018-05-01 16:09:41 --> Total execution time: 0.1200
INFO - 2018-05-01 13:48:32 --> Config Class Initialized
INFO - 2018-05-01 13:48:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:32 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:32 --> URI Class Initialized
INFO - 2018-05-01 13:48:32 --> Router Class Initialized
INFO - 2018-05-01 13:48:32 --> Output Class Initialized
INFO - 2018-05-01 13:48:32 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:32 --> Input Class Initialized
INFO - 2018-05-01 13:48:32 --> Language Class Initialized
INFO - 2018-05-01 13:48:32 --> Loader Class Initialized
INFO - 2018-05-01 13:48:32 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:32 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:32 --> Email Class Initialized
INFO - 2018-05-01 13:48:32 --> Controller Class Initialized
INFO - 2018-05-01 13:48:32 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:32 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:32 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:32 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:32 --> Model Class Initialized
INFO - 2018-05-01 13:48:32 --> Model Class Initialized
INFO - 2018-05-01 13:48:32 --> Model Class Initialized
INFO - 2018-05-01 17:18:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:18:32 --> Trying to get property of non-object
ERROR - 2018-05-01 17:18:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:18:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:18:32 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:32 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:32 --> Total execution time: 0.8000
INFO - 2018-05-01 13:48:37 --> Config Class Initialized
INFO - 2018-05-01 13:48:37 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:37 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:37 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:37 --> URI Class Initialized
INFO - 2018-05-01 13:48:37 --> Router Class Initialized
INFO - 2018-05-01 13:48:37 --> Output Class Initialized
INFO - 2018-05-01 13:48:37 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:37 --> Input Class Initialized
INFO - 2018-05-01 13:48:37 --> Language Class Initialized
INFO - 2018-05-01 13:48:37 --> Loader Class Initialized
INFO - 2018-05-01 13:48:37 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:37 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:37 --> Email Class Initialized
INFO - 2018-05-01 13:48:37 --> Controller Class Initialized
INFO - 2018-05-01 13:48:37 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:37 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:37 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:37 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:37 --> Model Class Initialized
INFO - 2018-05-01 13:48:37 --> Model Class Initialized
INFO - 2018-05-01 13:48:37 --> Model Class Initialized
INFO - 2018-05-01 17:18:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:18:37 --> Trying to get property of non-object
ERROR - 2018-05-01 17:18:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:18:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:18:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:37 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:37 --> Total execution time: 0.1770
INFO - 2018-05-01 13:48:38 --> Config Class Initialized
INFO - 2018-05-01 13:48:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:38 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:38 --> URI Class Initialized
INFO - 2018-05-01 13:48:38 --> Router Class Initialized
INFO - 2018-05-01 13:48:38 --> Output Class Initialized
INFO - 2018-05-01 13:48:38 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:38 --> Input Class Initialized
INFO - 2018-05-01 13:48:38 --> Language Class Initialized
INFO - 2018-05-01 13:48:38 --> Loader Class Initialized
INFO - 2018-05-01 13:48:38 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:38 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:39 --> Email Class Initialized
INFO - 2018-05-01 13:48:39 --> Controller Class Initialized
INFO - 2018-05-01 13:48:39 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:39 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:39 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:39 --> Model Class Initialized
INFO - 2018-05-01 13:48:39 --> Model Class Initialized
INFO - 2018-05-01 13:48:39 --> Model Class Initialized
INFO - 2018-05-01 17:18:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 17:18:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:18:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:39 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:39 --> Total execution time: 0.2120
INFO - 2018-05-01 13:48:41 --> Config Class Initialized
INFO - 2018-05-01 13:48:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:41 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:41 --> URI Class Initialized
INFO - 2018-05-01 13:48:41 --> Router Class Initialized
INFO - 2018-05-01 13:48:41 --> Output Class Initialized
INFO - 2018-05-01 13:48:41 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:41 --> Input Class Initialized
INFO - 2018-05-01 13:48:41 --> Language Class Initialized
INFO - 2018-05-01 13:48:41 --> Loader Class Initialized
INFO - 2018-05-01 13:48:41 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:41 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:41 --> Email Class Initialized
INFO - 2018-05-01 13:48:41 --> Controller Class Initialized
INFO - 2018-05-01 13:48:41 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:41 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:41 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:41 --> Model Class Initialized
INFO - 2018-05-01 13:48:41 --> Model Class Initialized
INFO - 2018-05-01 13:48:41 --> Model Class Initialized
INFO - 2018-05-01 17:18:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 17:18:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:18:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:41 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:41 --> Total execution time: 0.1260
INFO - 2018-05-01 13:48:43 --> Config Class Initialized
INFO - 2018-05-01 13:48:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:43 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:43 --> URI Class Initialized
INFO - 2018-05-01 13:48:43 --> Router Class Initialized
INFO - 2018-05-01 13:48:43 --> Output Class Initialized
INFO - 2018-05-01 13:48:43 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:43 --> Input Class Initialized
INFO - 2018-05-01 13:48:43 --> Language Class Initialized
INFO - 2018-05-01 13:48:43 --> Loader Class Initialized
INFO - 2018-05-01 13:48:43 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:43 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:43 --> Email Class Initialized
INFO - 2018-05-01 13:48:43 --> Controller Class Initialized
INFO - 2018-05-01 13:48:43 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:43 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:43 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:43 --> Model Class Initialized
INFO - 2018-05-01 13:48:43 --> Model Class Initialized
INFO - 2018-05-01 13:48:43 --> Model Class Initialized
INFO - 2018-05-01 17:18:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:18:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:18:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:43 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:43 --> Total execution time: 0.1450
INFO - 2018-05-01 13:48:49 --> Config Class Initialized
INFO - 2018-05-01 13:48:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:49 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:49 --> URI Class Initialized
INFO - 2018-05-01 13:48:49 --> Router Class Initialized
INFO - 2018-05-01 13:48:49 --> Output Class Initialized
INFO - 2018-05-01 13:48:49 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:49 --> Input Class Initialized
INFO - 2018-05-01 13:48:49 --> Language Class Initialized
INFO - 2018-05-01 13:48:49 --> Loader Class Initialized
INFO - 2018-05-01 13:48:49 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:49 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:49 --> Email Class Initialized
INFO - 2018-05-01 13:48:49 --> Controller Class Initialized
INFO - 2018-05-01 13:48:49 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:49 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:49 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:49 --> Model Class Initialized
INFO - 2018-05-01 13:48:49 --> Model Class Initialized
INFO - 2018-05-01 13:48:49 --> Model Class Initialized
INFO - 2018-05-01 17:18:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:18:49 --> Trying to get property of non-object
ERROR - 2018-05-01 17:18:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:18:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:18:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:49 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:49 --> Total execution time: 0.1410
INFO - 2018-05-01 13:48:51 --> Config Class Initialized
INFO - 2018-05-01 13:48:51 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:51 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:51 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:51 --> URI Class Initialized
INFO - 2018-05-01 13:48:51 --> Router Class Initialized
INFO - 2018-05-01 13:48:51 --> Output Class Initialized
INFO - 2018-05-01 13:48:51 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:51 --> Input Class Initialized
INFO - 2018-05-01 13:48:51 --> Language Class Initialized
INFO - 2018-05-01 13:48:51 --> Loader Class Initialized
INFO - 2018-05-01 13:48:51 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:51 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:51 --> Email Class Initialized
INFO - 2018-05-01 13:48:51 --> Controller Class Initialized
INFO - 2018-05-01 13:48:51 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:51 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:51 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:51 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:51 --> Model Class Initialized
INFO - 2018-05-01 13:48:51 --> Model Class Initialized
INFO - 2018-05-01 13:48:51 --> Model Class Initialized
INFO - 2018-05-01 17:18:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:18:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:18:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:51 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:51 --> Total execution time: 0.1610
INFO - 2018-05-01 13:48:57 --> Config Class Initialized
INFO - 2018-05-01 13:48:57 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:48:57 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:48:57 --> Utf8 Class Initialized
INFO - 2018-05-01 13:48:57 --> URI Class Initialized
INFO - 2018-05-01 13:48:57 --> Router Class Initialized
INFO - 2018-05-01 13:48:57 --> Output Class Initialized
INFO - 2018-05-01 13:48:57 --> Security Class Initialized
DEBUG - 2018-05-01 13:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:48:57 --> Input Class Initialized
INFO - 2018-05-01 13:48:57 --> Language Class Initialized
INFO - 2018-05-01 13:48:57 --> Loader Class Initialized
INFO - 2018-05-01 13:48:57 --> Helper loaded: common_helper
INFO - 2018-05-01 13:48:57 --> Database Driver Class Initialized
INFO - 2018-05-01 13:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:48:57 --> Email Class Initialized
INFO - 2018-05-01 13:48:57 --> Controller Class Initialized
INFO - 2018-05-01 13:48:57 --> Helper loaded: form_helper
INFO - 2018-05-01 13:48:57 --> Form Validation Class Initialized
INFO - 2018-05-01 13:48:57 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:48:57 --> Helper loaded: url_helper
INFO - 2018-05-01 13:48:57 --> Model Class Initialized
INFO - 2018-05-01 13:48:57 --> Model Class Initialized
INFO - 2018-05-01 13:48:57 --> Model Class Initialized
INFO - 2018-05-01 17:18:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:18:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:18:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:18:57 --> Trying to get property of non-object
ERROR - 2018-05-01 17:18:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:18:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:18:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:18:57 --> Final output sent to browser
DEBUG - 2018-05-01 17:18:57 --> Total execution time: 0.1440
INFO - 2018-05-01 13:59:10 --> Config Class Initialized
INFO - 2018-05-01 13:59:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 13:59:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 13:59:10 --> Utf8 Class Initialized
INFO - 2018-05-01 13:59:10 --> URI Class Initialized
INFO - 2018-05-01 13:59:10 --> Router Class Initialized
INFO - 2018-05-01 13:59:10 --> Output Class Initialized
INFO - 2018-05-01 13:59:10 --> Security Class Initialized
DEBUG - 2018-05-01 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 13:59:10 --> Input Class Initialized
INFO - 2018-05-01 13:59:10 --> Language Class Initialized
INFO - 2018-05-01 13:59:10 --> Loader Class Initialized
INFO - 2018-05-01 13:59:10 --> Helper loaded: common_helper
INFO - 2018-05-01 13:59:10 --> Database Driver Class Initialized
INFO - 2018-05-01 13:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 13:59:10 --> Email Class Initialized
INFO - 2018-05-01 13:59:10 --> Controller Class Initialized
INFO - 2018-05-01 13:59:10 --> Helper loaded: form_helper
INFO - 2018-05-01 13:59:10 --> Form Validation Class Initialized
INFO - 2018-05-01 13:59:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 13:59:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 13:59:10 --> Helper loaded: url_helper
INFO - 2018-05-01 13:59:10 --> Model Class Initialized
INFO - 2018-05-01 13:59:10 --> Model Class Initialized
INFO - 2018-05-01 13:59:10 --> Model Class Initialized
INFO - 2018-05-01 17:29:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:29:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:29:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:29:10 --> Trying to get property of non-object
ERROR - 2018-05-01 17:29:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:29:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:29:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:29:10 --> Final output sent to browser
DEBUG - 2018-05-01 17:29:10 --> Total execution time: 0.2950
INFO - 2018-05-01 14:01:05 --> Config Class Initialized
INFO - 2018-05-01 14:01:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:05 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:05 --> URI Class Initialized
INFO - 2018-05-01 14:01:05 --> Router Class Initialized
INFO - 2018-05-01 14:01:05 --> Output Class Initialized
INFO - 2018-05-01 14:01:05 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:05 --> Input Class Initialized
INFO - 2018-05-01 14:01:05 --> Language Class Initialized
INFO - 2018-05-01 14:01:05 --> Loader Class Initialized
INFO - 2018-05-01 14:01:05 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:05 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:05 --> Email Class Initialized
INFO - 2018-05-01 14:01:05 --> Controller Class Initialized
INFO - 2018-05-01 14:01:05 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:05 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:05 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:05 --> Model Class Initialized
INFO - 2018-05-01 14:01:05 --> Model Class Initialized
INFO - 2018-05-01 14:01:05 --> Model Class Initialized
INFO - 2018-05-01 17:31:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:31:05 --> Trying to get property of non-object
ERROR - 2018-05-01 17:31:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:31:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:31:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:05 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:05 --> Total execution time: 0.2280
INFO - 2018-05-01 14:01:10 --> Config Class Initialized
INFO - 2018-05-01 14:01:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:10 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:10 --> URI Class Initialized
INFO - 2018-05-01 14:01:10 --> Router Class Initialized
INFO - 2018-05-01 14:01:10 --> Output Class Initialized
INFO - 2018-05-01 14:01:10 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:10 --> Input Class Initialized
INFO - 2018-05-01 14:01:10 --> Language Class Initialized
INFO - 2018-05-01 14:01:10 --> Loader Class Initialized
INFO - 2018-05-01 14:01:10 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:10 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:10 --> Email Class Initialized
INFO - 2018-05-01 14:01:10 --> Controller Class Initialized
INFO - 2018-05-01 14:01:10 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:10 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:10 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:10 --> Model Class Initialized
INFO - 2018-05-01 14:01:10 --> Model Class Initialized
INFO - 2018-05-01 14:01:10 --> Model Class Initialized
INFO - 2018-05-01 17:31:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:31:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-01 17:31:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:10 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:10 --> Total execution time: 0.2480
INFO - 2018-05-01 14:01:14 --> Config Class Initialized
INFO - 2018-05-01 14:01:14 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:14 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:14 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:14 --> URI Class Initialized
INFO - 2018-05-01 14:01:14 --> Router Class Initialized
INFO - 2018-05-01 14:01:14 --> Output Class Initialized
INFO - 2018-05-01 14:01:14 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:14 --> Input Class Initialized
INFO - 2018-05-01 14:01:14 --> Language Class Initialized
INFO - 2018-05-01 14:01:14 --> Loader Class Initialized
INFO - 2018-05-01 14:01:14 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:14 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:14 --> Email Class Initialized
INFO - 2018-05-01 14:01:14 --> Controller Class Initialized
INFO - 2018-05-01 14:01:14 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:14 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:14 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:14 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:14 --> Model Class Initialized
INFO - 2018-05-01 14:01:14 --> Model Class Initialized
INFO - 2018-05-01 14:01:14 --> Model Class Initialized
INFO - 2018-05-01 17:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-01 17:31:14 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:14 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:14 --> Total execution time: 0.2180
INFO - 2018-05-01 14:01:21 --> Config Class Initialized
INFO - 2018-05-01 14:01:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:21 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:21 --> URI Class Initialized
INFO - 2018-05-01 14:01:21 --> Router Class Initialized
INFO - 2018-05-01 14:01:21 --> Output Class Initialized
INFO - 2018-05-01 14:01:21 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:21 --> Input Class Initialized
INFO - 2018-05-01 14:01:21 --> Language Class Initialized
INFO - 2018-05-01 14:01:21 --> Loader Class Initialized
INFO - 2018-05-01 14:01:21 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:21 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:21 --> Email Class Initialized
INFO - 2018-05-01 14:01:21 --> Controller Class Initialized
INFO - 2018-05-01 14:01:21 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:21 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:21 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:21 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:21 --> Model Class Initialized
INFO - 2018-05-01 14:01:21 --> Model Class Initialized
INFO - 2018-05-01 14:01:21 --> Model Class Initialized
INFO - 2018-05-01 17:31:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:31:21 --> Trying to get property of non-object
ERROR - 2018-05-01 17:31:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:31:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:31:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:21 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:21 --> Total execution time: 0.2350
INFO - 2018-05-01 14:01:28 --> Config Class Initialized
INFO - 2018-05-01 14:01:28 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:28 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:28 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:28 --> URI Class Initialized
INFO - 2018-05-01 14:01:28 --> Router Class Initialized
INFO - 2018-05-01 14:01:28 --> Output Class Initialized
INFO - 2018-05-01 14:01:28 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:28 --> Input Class Initialized
INFO - 2018-05-01 14:01:28 --> Language Class Initialized
INFO - 2018-05-01 14:01:28 --> Loader Class Initialized
INFO - 2018-05-01 14:01:28 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:28 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:28 --> Email Class Initialized
INFO - 2018-05-01 14:01:28 --> Controller Class Initialized
INFO - 2018-05-01 14:01:28 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:28 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:28 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:28 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:28 --> Model Class Initialized
INFO - 2018-05-01 14:01:28 --> Model Class Initialized
INFO - 2018-05-01 14:01:28 --> Model Class Initialized
INFO - 2018-05-01 17:31:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:31:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movieImageDetails.php
INFO - 2018-05-01 17:31:28 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:28 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:28 --> Total execution time: 0.1460
INFO - 2018-05-01 14:01:31 --> Config Class Initialized
INFO - 2018-05-01 14:01:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:31 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:31 --> URI Class Initialized
INFO - 2018-05-01 14:01:31 --> Router Class Initialized
INFO - 2018-05-01 14:01:31 --> Output Class Initialized
INFO - 2018-05-01 14:01:31 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:31 --> Input Class Initialized
INFO - 2018-05-01 14:01:31 --> Language Class Initialized
INFO - 2018-05-01 14:01:31 --> Loader Class Initialized
INFO - 2018-05-01 14:01:31 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:31 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:31 --> Email Class Initialized
INFO - 2018-05-01 14:01:31 --> Controller Class Initialized
INFO - 2018-05-01 14:01:31 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:31 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:31 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:31 --> Model Class Initialized
INFO - 2018-05-01 14:01:31 --> Model Class Initialized
INFO - 2018-05-01 14:01:31 --> Model Class Initialized
INFO - 2018-05-01 17:31:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:31:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/aboutMovie.php
INFO - 2018-05-01 17:31:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:31 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:31 --> Total execution time: 0.1860
INFO - 2018-05-01 14:01:33 --> Config Class Initialized
INFO - 2018-05-01 14:01:33 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:33 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:33 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:33 --> URI Class Initialized
INFO - 2018-05-01 14:01:33 --> Router Class Initialized
INFO - 2018-05-01 14:01:33 --> Output Class Initialized
INFO - 2018-05-01 14:01:33 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:33 --> Input Class Initialized
INFO - 2018-05-01 14:01:33 --> Language Class Initialized
INFO - 2018-05-01 14:01:33 --> Loader Class Initialized
INFO - 2018-05-01 14:01:33 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:33 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:33 --> Email Class Initialized
INFO - 2018-05-01 14:01:33 --> Controller Class Initialized
INFO - 2018-05-01 14:01:33 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:33 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:33 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:33 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:33 --> Model Class Initialized
INFO - 2018-05-01 14:01:33 --> Model Class Initialized
INFO - 2018-05-01 14:01:33 --> Model Class Initialized
INFO - 2018-05-01 17:31:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:31:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:31:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:33 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:33 --> Total execution time: 0.1480
INFO - 2018-05-01 14:01:38 --> Config Class Initialized
INFO - 2018-05-01 14:01:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:01:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:01:38 --> Utf8 Class Initialized
INFO - 2018-05-01 14:01:38 --> URI Class Initialized
INFO - 2018-05-01 14:01:38 --> Router Class Initialized
INFO - 2018-05-01 14:01:38 --> Output Class Initialized
INFO - 2018-05-01 14:01:38 --> Security Class Initialized
DEBUG - 2018-05-01 14:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:01:38 --> Input Class Initialized
INFO - 2018-05-01 14:01:38 --> Language Class Initialized
INFO - 2018-05-01 14:01:38 --> Loader Class Initialized
INFO - 2018-05-01 14:01:38 --> Helper loaded: common_helper
INFO - 2018-05-01 14:01:38 --> Database Driver Class Initialized
INFO - 2018-05-01 14:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:01:38 --> Email Class Initialized
INFO - 2018-05-01 14:01:38 --> Controller Class Initialized
INFO - 2018-05-01 14:01:38 --> Helper loaded: form_helper
INFO - 2018-05-01 14:01:38 --> Form Validation Class Initialized
INFO - 2018-05-01 14:01:38 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:01:38 --> Helper loaded: url_helper
INFO - 2018-05-01 14:01:38 --> Model Class Initialized
INFO - 2018-05-01 14:01:38 --> Model Class Initialized
INFO - 2018-05-01 14:01:38 --> Model Class Initialized
INFO - 2018-05-01 17:31:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:31:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:31:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:31:38 --> Trying to get property of non-object
ERROR - 2018-05-01 17:31:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:31:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:31:38 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:31:38 --> Final output sent to browser
DEBUG - 2018-05-01 17:31:38 --> Total execution time: 0.1600
INFO - 2018-05-01 14:07:17 --> Config Class Initialized
INFO - 2018-05-01 14:07:17 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:07:17 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:07:17 --> Utf8 Class Initialized
INFO - 2018-05-01 14:07:17 --> URI Class Initialized
INFO - 2018-05-01 14:07:17 --> Router Class Initialized
INFO - 2018-05-01 14:07:17 --> Output Class Initialized
INFO - 2018-05-01 14:07:17 --> Security Class Initialized
DEBUG - 2018-05-01 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:07:17 --> Input Class Initialized
INFO - 2018-05-01 14:07:17 --> Language Class Initialized
INFO - 2018-05-01 14:07:17 --> Loader Class Initialized
INFO - 2018-05-01 14:07:17 --> Helper loaded: common_helper
INFO - 2018-05-01 14:07:17 --> Database Driver Class Initialized
INFO - 2018-05-01 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:07:17 --> Email Class Initialized
INFO - 2018-05-01 14:07:17 --> Controller Class Initialized
INFO - 2018-05-01 14:07:17 --> Helper loaded: form_helper
INFO - 2018-05-01 14:07:17 --> Form Validation Class Initialized
INFO - 2018-05-01 14:07:17 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:07:17 --> Helper loaded: url_helper
INFO - 2018-05-01 14:07:17 --> Model Class Initialized
INFO - 2018-05-01 14:07:17 --> Model Class Initialized
INFO - 2018-05-01 14:07:17 --> Model Class Initialized
INFO - 2018-05-01 17:37:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:37:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:37:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:37:17 --> Trying to get property of non-object
ERROR - 2018-05-01 17:37:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:37:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:37:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:37:17 --> Final output sent to browser
DEBUG - 2018-05-01 17:37:17 --> Total execution time: 0.1460
INFO - 2018-05-01 14:09:25 --> Config Class Initialized
INFO - 2018-05-01 14:09:25 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:09:25 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:09:25 --> Utf8 Class Initialized
INFO - 2018-05-01 14:09:25 --> URI Class Initialized
INFO - 2018-05-01 14:09:25 --> Router Class Initialized
INFO - 2018-05-01 14:09:25 --> Output Class Initialized
INFO - 2018-05-01 14:09:25 --> Security Class Initialized
DEBUG - 2018-05-01 14:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:09:25 --> Input Class Initialized
INFO - 2018-05-01 14:09:25 --> Language Class Initialized
INFO - 2018-05-01 14:09:25 --> Loader Class Initialized
INFO - 2018-05-01 14:09:25 --> Helper loaded: common_helper
INFO - 2018-05-01 14:09:25 --> Database Driver Class Initialized
INFO - 2018-05-01 14:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:09:25 --> Email Class Initialized
INFO - 2018-05-01 14:09:25 --> Controller Class Initialized
INFO - 2018-05-01 14:09:25 --> Helper loaded: form_helper
INFO - 2018-05-01 14:09:25 --> Form Validation Class Initialized
INFO - 2018-05-01 14:09:25 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:09:25 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:09:25 --> Helper loaded: url_helper
INFO - 2018-05-01 14:09:25 --> Model Class Initialized
INFO - 2018-05-01 14:09:25 --> Model Class Initialized
INFO - 2018-05-01 14:09:25 --> Model Class Initialized
INFO - 2018-05-01 17:39:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:39:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:39:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:39:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:39:25 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:39:25 --> Final output sent to browser
DEBUG - 2018-05-01 17:39:25 --> Total execution time: 0.1420
INFO - 2018-05-01 14:09:32 --> Config Class Initialized
INFO - 2018-05-01 14:09:32 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:09:32 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:09:32 --> Utf8 Class Initialized
INFO - 2018-05-01 14:09:32 --> URI Class Initialized
INFO - 2018-05-01 14:09:32 --> Router Class Initialized
INFO - 2018-05-01 14:09:32 --> Output Class Initialized
INFO - 2018-05-01 14:09:32 --> Security Class Initialized
DEBUG - 2018-05-01 14:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:09:32 --> Input Class Initialized
INFO - 2018-05-01 14:09:32 --> Language Class Initialized
INFO - 2018-05-01 14:09:32 --> Loader Class Initialized
INFO - 2018-05-01 14:09:32 --> Helper loaded: common_helper
INFO - 2018-05-01 14:09:32 --> Database Driver Class Initialized
INFO - 2018-05-01 14:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:09:33 --> Email Class Initialized
INFO - 2018-05-01 14:09:33 --> Controller Class Initialized
INFO - 2018-05-01 14:09:33 --> Helper loaded: form_helper
INFO - 2018-05-01 14:09:33 --> Form Validation Class Initialized
INFO - 2018-05-01 14:09:33 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:09:33 --> Helper loaded: url_helper
INFO - 2018-05-01 14:09:33 --> Model Class Initialized
INFO - 2018-05-01 14:09:33 --> Model Class Initialized
INFO - 2018-05-01 14:09:33 --> Model Class Initialized
INFO - 2018-05-01 17:39:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:39:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:39:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:39:33 --> Trying to get property of non-object
ERROR - 2018-05-01 17:39:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:39:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:39:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:39:33 --> Final output sent to browser
DEBUG - 2018-05-01 17:39:33 --> Total execution time: 0.1470
INFO - 2018-05-01 14:10:45 --> Config Class Initialized
INFO - 2018-05-01 14:10:45 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:10:45 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:10:45 --> Utf8 Class Initialized
INFO - 2018-05-01 14:10:45 --> URI Class Initialized
INFO - 2018-05-01 14:10:46 --> Router Class Initialized
INFO - 2018-05-01 14:10:46 --> Output Class Initialized
INFO - 2018-05-01 14:10:46 --> Security Class Initialized
DEBUG - 2018-05-01 14:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:10:46 --> Input Class Initialized
INFO - 2018-05-01 14:10:46 --> Language Class Initialized
INFO - 2018-05-01 14:10:46 --> Loader Class Initialized
INFO - 2018-05-01 14:10:46 --> Helper loaded: common_helper
INFO - 2018-05-01 14:10:46 --> Database Driver Class Initialized
INFO - 2018-05-01 14:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:10:46 --> Email Class Initialized
INFO - 2018-05-01 14:10:46 --> Controller Class Initialized
INFO - 2018-05-01 14:10:46 --> Helper loaded: form_helper
INFO - 2018-05-01 14:10:46 --> Form Validation Class Initialized
INFO - 2018-05-01 14:10:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:10:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:10:46 --> Helper loaded: url_helper
INFO - 2018-05-01 14:10:46 --> Model Class Initialized
INFO - 2018-05-01 14:10:46 --> Model Class Initialized
INFO - 2018-05-01 14:10:46 --> Model Class Initialized
INFO - 2018-05-01 17:40:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:40:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:40:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:40:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:40:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:40:46 --> Final output sent to browser
DEBUG - 2018-05-01 17:40:46 --> Total execution time: 0.1360
INFO - 2018-05-01 14:10:50 --> Config Class Initialized
INFO - 2018-05-01 14:10:50 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:10:50 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:10:50 --> Utf8 Class Initialized
INFO - 2018-05-01 14:10:50 --> URI Class Initialized
INFO - 2018-05-01 14:10:50 --> Router Class Initialized
INFO - 2018-05-01 14:10:50 --> Output Class Initialized
INFO - 2018-05-01 14:10:50 --> Security Class Initialized
DEBUG - 2018-05-01 14:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:10:50 --> Input Class Initialized
INFO - 2018-05-01 14:10:50 --> Language Class Initialized
INFO - 2018-05-01 14:10:50 --> Loader Class Initialized
INFO - 2018-05-01 14:10:50 --> Helper loaded: common_helper
INFO - 2018-05-01 14:10:50 --> Database Driver Class Initialized
INFO - 2018-05-01 14:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:10:50 --> Email Class Initialized
INFO - 2018-05-01 14:10:50 --> Controller Class Initialized
INFO - 2018-05-01 14:10:50 --> Helper loaded: form_helper
INFO - 2018-05-01 14:10:50 --> Form Validation Class Initialized
INFO - 2018-05-01 14:10:50 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:10:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:10:50 --> Helper loaded: url_helper
INFO - 2018-05-01 14:10:50 --> Model Class Initialized
INFO - 2018-05-01 14:10:50 --> Model Class Initialized
INFO - 2018-05-01 14:10:50 --> Model Class Initialized
INFO - 2018-05-01 17:40:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:40:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:40:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:40:50 --> Trying to get property of non-object
ERROR - 2018-05-01 17:40:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:40:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:40:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:40:50 --> Final output sent to browser
DEBUG - 2018-05-01 17:40:50 --> Total execution time: 0.1440
INFO - 2018-05-01 14:26:48 --> Config Class Initialized
INFO - 2018-05-01 14:26:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:26:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:26:48 --> Utf8 Class Initialized
INFO - 2018-05-01 14:26:48 --> URI Class Initialized
INFO - 2018-05-01 14:26:48 --> Router Class Initialized
INFO - 2018-05-01 14:26:48 --> Output Class Initialized
INFO - 2018-05-01 14:26:48 --> Security Class Initialized
DEBUG - 2018-05-01 14:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:26:48 --> Input Class Initialized
INFO - 2018-05-01 14:26:48 --> Language Class Initialized
INFO - 2018-05-01 14:26:48 --> Loader Class Initialized
INFO - 2018-05-01 14:26:48 --> Helper loaded: common_helper
INFO - 2018-05-01 14:26:48 --> Database Driver Class Initialized
INFO - 2018-05-01 14:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:26:48 --> Email Class Initialized
INFO - 2018-05-01 14:26:48 --> Controller Class Initialized
INFO - 2018-05-01 14:26:48 --> Helper loaded: form_helper
INFO - 2018-05-01 14:26:48 --> Form Validation Class Initialized
INFO - 2018-05-01 14:26:48 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:26:48 --> Helper loaded: url_helper
INFO - 2018-05-01 14:26:48 --> Model Class Initialized
INFO - 2018-05-01 14:26:48 --> Model Class Initialized
INFO - 2018-05-01 14:26:48 --> Model Class Initialized
INFO - 2018-05-01 17:56:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:56:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:56:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:56:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:56:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:56:48 --> Final output sent to browser
DEBUG - 2018-05-01 17:56:48 --> Total execution time: 0.1960
INFO - 2018-05-01 14:27:26 --> Config Class Initialized
INFO - 2018-05-01 14:27:26 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:27:26 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:27:26 --> Utf8 Class Initialized
INFO - 2018-05-01 14:27:26 --> URI Class Initialized
INFO - 2018-05-01 14:27:26 --> Router Class Initialized
INFO - 2018-05-01 14:27:26 --> Output Class Initialized
INFO - 2018-05-01 14:27:26 --> Security Class Initialized
DEBUG - 2018-05-01 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:27:26 --> Input Class Initialized
INFO - 2018-05-01 14:27:26 --> Language Class Initialized
INFO - 2018-05-01 14:27:26 --> Loader Class Initialized
INFO - 2018-05-01 14:27:26 --> Helper loaded: common_helper
INFO - 2018-05-01 14:27:26 --> Database Driver Class Initialized
INFO - 2018-05-01 14:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:27:26 --> Email Class Initialized
INFO - 2018-05-01 14:27:26 --> Controller Class Initialized
INFO - 2018-05-01 14:27:26 --> Helper loaded: form_helper
INFO - 2018-05-01 14:27:26 --> Form Validation Class Initialized
INFO - 2018-05-01 14:27:26 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:27:26 --> Helper loaded: url_helper
INFO - 2018-05-01 14:27:26 --> Model Class Initialized
INFO - 2018-05-01 14:27:26 --> Model Class Initialized
INFO - 2018-05-01 14:27:26 --> Model Class Initialized
INFO - 2018-05-01 17:57:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:57:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:57:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 17:57:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:57:26 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:57:26 --> Final output sent to browser
DEBUG - 2018-05-01 17:57:26 --> Total execution time: 0.1450
INFO - 2018-05-01 14:27:30 --> Config Class Initialized
INFO - 2018-05-01 14:27:30 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:27:30 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:27:30 --> Utf8 Class Initialized
INFO - 2018-05-01 14:27:30 --> URI Class Initialized
INFO - 2018-05-01 14:27:30 --> Router Class Initialized
INFO - 2018-05-01 14:27:30 --> Output Class Initialized
INFO - 2018-05-01 14:27:30 --> Security Class Initialized
DEBUG - 2018-05-01 14:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:27:30 --> Input Class Initialized
INFO - 2018-05-01 14:27:30 --> Language Class Initialized
INFO - 2018-05-01 14:27:30 --> Loader Class Initialized
INFO - 2018-05-01 14:27:30 --> Helper loaded: common_helper
INFO - 2018-05-01 14:27:30 --> Database Driver Class Initialized
INFO - 2018-05-01 14:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:27:30 --> Email Class Initialized
INFO - 2018-05-01 14:27:30 --> Controller Class Initialized
INFO - 2018-05-01 14:27:30 --> Helper loaded: form_helper
INFO - 2018-05-01 14:27:30 --> Form Validation Class Initialized
INFO - 2018-05-01 14:27:30 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:27:30 --> Helper loaded: url_helper
INFO - 2018-05-01 14:27:30 --> Model Class Initialized
INFO - 2018-05-01 14:27:30 --> Model Class Initialized
INFO - 2018-05-01 14:27:30 --> Model Class Initialized
INFO - 2018-05-01 17:57:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 17:57:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 17:57:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 17:57:30 --> Trying to get property of non-object
ERROR - 2018-05-01 17:57:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 17:57:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 17:57:30 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 17:57:30 --> Final output sent to browser
DEBUG - 2018-05-01 17:57:30 --> Total execution time: 0.1510
INFO - 2018-05-01 14:46:38 --> Config Class Initialized
INFO - 2018-05-01 14:46:38 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:46:38 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:46:38 --> Utf8 Class Initialized
INFO - 2018-05-01 14:46:38 --> URI Class Initialized
INFO - 2018-05-01 14:46:38 --> Router Class Initialized
INFO - 2018-05-01 14:46:38 --> Output Class Initialized
INFO - 2018-05-01 14:46:38 --> Security Class Initialized
DEBUG - 2018-05-01 14:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:46:38 --> Input Class Initialized
INFO - 2018-05-01 14:46:38 --> Language Class Initialized
INFO - 2018-05-01 14:46:38 --> Loader Class Initialized
INFO - 2018-05-01 14:46:39 --> Helper loaded: common_helper
INFO - 2018-05-01 14:46:39 --> Database Driver Class Initialized
INFO - 2018-05-01 14:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:46:39 --> Email Class Initialized
INFO - 2018-05-01 14:46:39 --> Controller Class Initialized
INFO - 2018-05-01 14:46:39 --> Helper loaded: form_helper
INFO - 2018-05-01 14:46:39 --> Form Validation Class Initialized
INFO - 2018-05-01 14:46:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:46:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:46:39 --> Helper loaded: url_helper
INFO - 2018-05-01 14:46:39 --> Model Class Initialized
INFO - 2018-05-01 14:46:39 --> Model Class Initialized
INFO - 2018-05-01 14:46:39 --> Model Class Initialized
INFO - 2018-05-01 18:16:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:16:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:16:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:16:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:16:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:16:39 --> Final output sent to browser
DEBUG - 2018-05-01 18:16:39 --> Total execution time: 0.1280
INFO - 2018-05-01 14:46:46 --> Config Class Initialized
INFO - 2018-05-01 14:46:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:46:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:46:46 --> Utf8 Class Initialized
INFO - 2018-05-01 14:46:46 --> URI Class Initialized
INFO - 2018-05-01 14:46:46 --> Router Class Initialized
INFO - 2018-05-01 14:46:46 --> Output Class Initialized
INFO - 2018-05-01 14:46:46 --> Security Class Initialized
DEBUG - 2018-05-01 14:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:46:46 --> Input Class Initialized
INFO - 2018-05-01 14:46:46 --> Language Class Initialized
INFO - 2018-05-01 14:46:46 --> Loader Class Initialized
INFO - 2018-05-01 14:46:46 --> Helper loaded: common_helper
INFO - 2018-05-01 14:46:46 --> Database Driver Class Initialized
INFO - 2018-05-01 14:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:46:46 --> Email Class Initialized
INFO - 2018-05-01 14:46:46 --> Controller Class Initialized
INFO - 2018-05-01 14:46:46 --> Helper loaded: form_helper
INFO - 2018-05-01 14:46:46 --> Form Validation Class Initialized
INFO - 2018-05-01 14:46:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:46:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:46:46 --> Helper loaded: url_helper
INFO - 2018-05-01 14:46:46 --> Model Class Initialized
INFO - 2018-05-01 14:46:46 --> Model Class Initialized
INFO - 2018-05-01 14:46:46 --> Model Class Initialized
INFO - 2018-05-01 18:16:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:16:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:16:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 18:16:46 --> Trying to get property of non-object
ERROR - 2018-05-01 18:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 18:16:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:16:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:16:46 --> Final output sent to browser
DEBUG - 2018-05-01 18:16:46 --> Total execution time: 0.1290
INFO - 2018-05-01 14:47:27 --> Config Class Initialized
INFO - 2018-05-01 14:47:27 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:47:27 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:47:27 --> Utf8 Class Initialized
INFO - 2018-05-01 14:47:27 --> URI Class Initialized
INFO - 2018-05-01 14:47:27 --> Router Class Initialized
INFO - 2018-05-01 14:47:27 --> Output Class Initialized
INFO - 2018-05-01 14:47:27 --> Security Class Initialized
DEBUG - 2018-05-01 14:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:47:27 --> Input Class Initialized
INFO - 2018-05-01 14:47:27 --> Language Class Initialized
INFO - 2018-05-01 14:47:27 --> Loader Class Initialized
INFO - 2018-05-01 14:47:27 --> Helper loaded: common_helper
INFO - 2018-05-01 14:47:27 --> Database Driver Class Initialized
INFO - 2018-05-01 14:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:47:27 --> Email Class Initialized
INFO - 2018-05-01 14:47:27 --> Controller Class Initialized
INFO - 2018-05-01 14:47:27 --> Helper loaded: form_helper
INFO - 2018-05-01 14:47:27 --> Form Validation Class Initialized
INFO - 2018-05-01 14:47:27 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:47:27 --> Helper loaded: url_helper
INFO - 2018-05-01 14:47:27 --> Model Class Initialized
INFO - 2018-05-01 14:47:27 --> Model Class Initialized
INFO - 2018-05-01 14:47:27 --> Model Class Initialized
INFO - 2018-05-01 18:17:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:17:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:17:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:17:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:17:27 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:17:27 --> Final output sent to browser
DEBUG - 2018-05-01 18:17:27 --> Total execution time: 0.1340
INFO - 2018-05-01 14:57:06 --> Config Class Initialized
INFO - 2018-05-01 14:57:06 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:57:06 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:57:06 --> Utf8 Class Initialized
INFO - 2018-05-01 14:57:06 --> URI Class Initialized
INFO - 2018-05-01 14:57:06 --> Router Class Initialized
INFO - 2018-05-01 14:57:06 --> Output Class Initialized
INFO - 2018-05-01 14:57:06 --> Security Class Initialized
DEBUG - 2018-05-01 14:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:57:06 --> Input Class Initialized
INFO - 2018-05-01 14:57:06 --> Language Class Initialized
INFO - 2018-05-01 14:57:06 --> Loader Class Initialized
INFO - 2018-05-01 14:57:06 --> Helper loaded: common_helper
INFO - 2018-05-01 14:57:06 --> Database Driver Class Initialized
INFO - 2018-05-01 14:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:57:06 --> Email Class Initialized
INFO - 2018-05-01 14:57:06 --> Controller Class Initialized
INFO - 2018-05-01 14:57:06 --> Helper loaded: form_helper
INFO - 2018-05-01 14:57:06 --> Form Validation Class Initialized
INFO - 2018-05-01 14:57:06 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:57:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:57:06 --> Helper loaded: url_helper
INFO - 2018-05-01 14:57:06 --> Model Class Initialized
INFO - 2018-05-01 14:57:06 --> Model Class Initialized
INFO - 2018-05-01 14:57:06 --> Model Class Initialized
INFO - 2018-05-01 18:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:27:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:27:06 --> Final output sent to browser
DEBUG - 2018-05-01 18:27:06 --> Total execution time: 0.1530
INFO - 2018-05-01 14:57:09 --> Config Class Initialized
INFO - 2018-05-01 14:57:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:57:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:57:09 --> Utf8 Class Initialized
INFO - 2018-05-01 14:57:09 --> URI Class Initialized
INFO - 2018-05-01 14:57:09 --> Router Class Initialized
INFO - 2018-05-01 14:57:09 --> Output Class Initialized
INFO - 2018-05-01 14:57:09 --> Security Class Initialized
DEBUG - 2018-05-01 14:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:57:09 --> Input Class Initialized
INFO - 2018-05-01 14:57:09 --> Language Class Initialized
INFO - 2018-05-01 14:57:09 --> Loader Class Initialized
INFO - 2018-05-01 14:57:09 --> Helper loaded: common_helper
INFO - 2018-05-01 14:57:09 --> Database Driver Class Initialized
INFO - 2018-05-01 14:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:57:09 --> Email Class Initialized
INFO - 2018-05-01 14:57:09 --> Controller Class Initialized
INFO - 2018-05-01 14:57:09 --> Helper loaded: form_helper
INFO - 2018-05-01 14:57:09 --> Form Validation Class Initialized
INFO - 2018-05-01 14:57:09 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:57:09 --> Helper loaded: url_helper
INFO - 2018-05-01 14:57:09 --> Model Class Initialized
INFO - 2018-05-01 14:57:09 --> Model Class Initialized
INFO - 2018-05-01 14:57:09 --> Model Class Initialized
INFO - 2018-05-01 14:57:12 --> Config Class Initialized
INFO - 2018-05-01 14:57:12 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:57:12 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:57:12 --> Utf8 Class Initialized
INFO - 2018-05-01 14:57:12 --> URI Class Initialized
INFO - 2018-05-01 14:57:12 --> Router Class Initialized
INFO - 2018-05-01 14:57:12 --> Output Class Initialized
INFO - 2018-05-01 14:57:12 --> Security Class Initialized
DEBUG - 2018-05-01 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:57:12 --> Input Class Initialized
INFO - 2018-05-01 14:57:12 --> Language Class Initialized
INFO - 2018-05-01 14:57:12 --> Loader Class Initialized
INFO - 2018-05-01 14:57:12 --> Helper loaded: common_helper
INFO - 2018-05-01 14:57:12 --> Database Driver Class Initialized
INFO - 2018-05-01 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:57:12 --> Email Class Initialized
INFO - 2018-05-01 14:57:12 --> Controller Class Initialized
INFO - 2018-05-01 14:57:12 --> Helper loaded: form_helper
INFO - 2018-05-01 14:57:12 --> Form Validation Class Initialized
INFO - 2018-05-01 14:57:12 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:57:12 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:57:12 --> Helper loaded: url_helper
INFO - 2018-05-01 14:57:12 --> Model Class Initialized
INFO - 2018-05-01 14:57:12 --> Model Class Initialized
INFO - 2018-05-01 14:57:12 --> Model Class Initialized
INFO - 2018-05-01 18:27:12 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:27:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:27:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:27:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:27:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:27:13 --> Final output sent to browser
DEBUG - 2018-05-01 18:27:13 --> Total execution time: 0.1370
INFO - 2018-05-01 14:57:22 --> Config Class Initialized
INFO - 2018-05-01 14:57:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 14:57:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 14:57:22 --> Utf8 Class Initialized
INFO - 2018-05-01 14:57:22 --> URI Class Initialized
INFO - 2018-05-01 14:57:22 --> Router Class Initialized
INFO - 2018-05-01 14:57:22 --> Output Class Initialized
INFO - 2018-05-01 14:57:22 --> Security Class Initialized
DEBUG - 2018-05-01 14:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 14:57:22 --> Input Class Initialized
INFO - 2018-05-01 14:57:22 --> Language Class Initialized
INFO - 2018-05-01 14:57:22 --> Loader Class Initialized
INFO - 2018-05-01 14:57:22 --> Helper loaded: common_helper
INFO - 2018-05-01 14:57:22 --> Database Driver Class Initialized
INFO - 2018-05-01 14:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 14:57:22 --> Email Class Initialized
INFO - 2018-05-01 14:57:22 --> Controller Class Initialized
INFO - 2018-05-01 14:57:22 --> Helper loaded: form_helper
INFO - 2018-05-01 14:57:22 --> Form Validation Class Initialized
INFO - 2018-05-01 14:57:22 --> Helper loaded: email_helper
DEBUG - 2018-05-01 14:57:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 14:57:22 --> Helper loaded: url_helper
INFO - 2018-05-01 14:57:22 --> Model Class Initialized
INFO - 2018-05-01 14:57:22 --> Model Class Initialized
INFO - 2018-05-01 14:57:22 --> Model Class Initialized
INFO - 2018-05-01 18:27:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:27:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:27:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:27:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:27:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:27:22 --> Final output sent to browser
DEBUG - 2018-05-01 18:27:22 --> Total execution time: 0.1370
INFO - 2018-05-01 15:00:00 --> Config Class Initialized
INFO - 2018-05-01 15:00:00 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:00:00 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:00:00 --> Utf8 Class Initialized
INFO - 2018-05-01 15:00:00 --> URI Class Initialized
INFO - 2018-05-01 15:00:00 --> Router Class Initialized
INFO - 2018-05-01 15:00:00 --> Output Class Initialized
INFO - 2018-05-01 15:00:00 --> Security Class Initialized
DEBUG - 2018-05-01 15:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:00:00 --> Input Class Initialized
INFO - 2018-05-01 15:00:00 --> Language Class Initialized
INFO - 2018-05-01 15:00:00 --> Loader Class Initialized
INFO - 2018-05-01 15:00:00 --> Helper loaded: common_helper
INFO - 2018-05-01 15:00:00 --> Database Driver Class Initialized
INFO - 2018-05-01 15:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:00:00 --> Email Class Initialized
INFO - 2018-05-01 15:00:00 --> Controller Class Initialized
INFO - 2018-05-01 15:00:00 --> Helper loaded: form_helper
INFO - 2018-05-01 15:00:00 --> Form Validation Class Initialized
INFO - 2018-05-01 15:00:00 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:00:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:00:00 --> Helper loaded: url_helper
INFO - 2018-05-01 15:00:00 --> Model Class Initialized
INFO - 2018-05-01 15:00:00 --> Model Class Initialized
INFO - 2018-05-01 15:00:00 --> Model Class Initialized
INFO - 2018-05-01 15:00:09 --> Config Class Initialized
INFO - 2018-05-01 15:00:09 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:00:09 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:00:09 --> Utf8 Class Initialized
INFO - 2018-05-01 15:00:09 --> URI Class Initialized
INFO - 2018-05-01 15:00:09 --> Router Class Initialized
INFO - 2018-05-01 15:00:09 --> Output Class Initialized
INFO - 2018-05-01 15:00:09 --> Security Class Initialized
DEBUG - 2018-05-01 15:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:00:09 --> Input Class Initialized
INFO - 2018-05-01 15:00:09 --> Language Class Initialized
INFO - 2018-05-01 15:00:09 --> Loader Class Initialized
INFO - 2018-05-01 15:00:09 --> Helper loaded: common_helper
INFO - 2018-05-01 15:00:09 --> Database Driver Class Initialized
INFO - 2018-05-01 15:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:00:10 --> Email Class Initialized
INFO - 2018-05-01 15:00:10 --> Controller Class Initialized
INFO - 2018-05-01 15:00:10 --> Helper loaded: form_helper
INFO - 2018-05-01 15:00:10 --> Form Validation Class Initialized
INFO - 2018-05-01 15:00:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:00:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:00:10 --> Helper loaded: url_helper
INFO - 2018-05-01 15:00:10 --> Model Class Initialized
INFO - 2018-05-01 15:00:10 --> Model Class Initialized
INFO - 2018-05-01 15:00:10 --> Model Class Initialized
INFO - 2018-05-01 18:30:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:30:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:30:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:30:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:30:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:30:10 --> Final output sent to browser
DEBUG - 2018-05-01 18:30:10 --> Total execution time: 0.5010
INFO - 2018-05-01 15:00:33 --> Config Class Initialized
INFO - 2018-05-01 15:00:33 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:00:33 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:00:33 --> Utf8 Class Initialized
INFO - 2018-05-01 15:00:33 --> URI Class Initialized
INFO - 2018-05-01 15:00:33 --> Router Class Initialized
INFO - 2018-05-01 15:00:33 --> Output Class Initialized
INFO - 2018-05-01 15:00:33 --> Security Class Initialized
DEBUG - 2018-05-01 15:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:00:33 --> Input Class Initialized
INFO - 2018-05-01 15:00:33 --> Language Class Initialized
INFO - 2018-05-01 15:00:33 --> Loader Class Initialized
INFO - 2018-05-01 15:00:33 --> Helper loaded: common_helper
INFO - 2018-05-01 15:00:33 --> Database Driver Class Initialized
INFO - 2018-05-01 15:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:00:33 --> Email Class Initialized
INFO - 2018-05-01 15:00:33 --> Controller Class Initialized
INFO - 2018-05-01 15:00:33 --> Helper loaded: form_helper
INFO - 2018-05-01 15:00:33 --> Form Validation Class Initialized
INFO - 2018-05-01 15:00:33 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:00:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:00:33 --> Helper loaded: url_helper
INFO - 2018-05-01 15:00:33 --> Model Class Initialized
INFO - 2018-05-01 15:00:33 --> Model Class Initialized
INFO - 2018-05-01 15:00:33 --> Model Class Initialized
INFO - 2018-05-01 18:30:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:30:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:30:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:30:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:30:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:30:33 --> Final output sent to browser
DEBUG - 2018-05-01 18:30:33 --> Total execution time: 0.1380
INFO - 2018-05-01 15:01:49 --> Config Class Initialized
INFO - 2018-05-01 15:01:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:01:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:01:49 --> Utf8 Class Initialized
INFO - 2018-05-01 15:01:49 --> URI Class Initialized
INFO - 2018-05-01 15:01:49 --> Router Class Initialized
INFO - 2018-05-01 15:01:49 --> Output Class Initialized
INFO - 2018-05-01 15:01:49 --> Security Class Initialized
DEBUG - 2018-05-01 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:01:49 --> Input Class Initialized
INFO - 2018-05-01 15:01:49 --> Language Class Initialized
INFO - 2018-05-01 15:01:49 --> Loader Class Initialized
INFO - 2018-05-01 15:01:49 --> Helper loaded: common_helper
INFO - 2018-05-01 15:01:49 --> Database Driver Class Initialized
INFO - 2018-05-01 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:01:49 --> Email Class Initialized
INFO - 2018-05-01 15:01:49 --> Controller Class Initialized
INFO - 2018-05-01 15:01:49 --> Helper loaded: form_helper
INFO - 2018-05-01 15:01:49 --> Form Validation Class Initialized
INFO - 2018-05-01 15:01:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:01:49 --> Helper loaded: url_helper
INFO - 2018-05-01 15:01:49 --> Model Class Initialized
INFO - 2018-05-01 15:01:49 --> Model Class Initialized
INFO - 2018-05-01 15:01:49 --> Model Class Initialized
INFO - 2018-05-01 18:31:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:31:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:31:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:31:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:31:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:31:49 --> Final output sent to browser
DEBUG - 2018-05-01 18:31:49 --> Total execution time: 0.1580
INFO - 2018-05-01 15:01:53 --> Config Class Initialized
INFO - 2018-05-01 15:01:53 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:01:53 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:01:53 --> Utf8 Class Initialized
INFO - 2018-05-01 15:01:53 --> URI Class Initialized
INFO - 2018-05-01 15:01:53 --> Router Class Initialized
INFO - 2018-05-01 15:01:53 --> Output Class Initialized
INFO - 2018-05-01 15:01:53 --> Security Class Initialized
DEBUG - 2018-05-01 15:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:01:53 --> Input Class Initialized
INFO - 2018-05-01 15:01:53 --> Language Class Initialized
INFO - 2018-05-01 15:01:53 --> Loader Class Initialized
INFO - 2018-05-01 15:01:53 --> Helper loaded: common_helper
INFO - 2018-05-01 15:01:53 --> Database Driver Class Initialized
INFO - 2018-05-01 15:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:01:53 --> Email Class Initialized
INFO - 2018-05-01 15:01:53 --> Controller Class Initialized
INFO - 2018-05-01 15:01:53 --> Helper loaded: form_helper
INFO - 2018-05-01 15:01:53 --> Form Validation Class Initialized
INFO - 2018-05-01 15:01:53 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:01:53 --> Helper loaded: url_helper
INFO - 2018-05-01 15:01:53 --> Model Class Initialized
INFO - 2018-05-01 15:01:53 --> Model Class Initialized
INFO - 2018-05-01 15:01:53 --> Model Class Initialized
ERROR - 2018-05-01 18:31:53 --> Query error: Unknown column 'movieId' in 'where clause' - Invalid query: UPDATE `movie_images` SET `isDeleted` = 1
WHERE `movieId` = '15'
INFO - 2018-05-01 15:01:53 --> Config Class Initialized
INFO - 2018-05-01 15:01:53 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:01:53 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:01:53 --> Utf8 Class Initialized
INFO - 2018-05-01 15:01:53 --> URI Class Initialized
INFO - 2018-05-01 15:01:53 --> Router Class Initialized
INFO - 2018-05-01 15:01:53 --> Output Class Initialized
INFO - 2018-05-01 15:01:53 --> Security Class Initialized
DEBUG - 2018-05-01 15:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:01:53 --> Input Class Initialized
INFO - 2018-05-01 15:01:53 --> Language Class Initialized
INFO - 2018-05-01 15:01:53 --> Loader Class Initialized
INFO - 2018-05-01 15:01:53 --> Helper loaded: common_helper
INFO - 2018-05-01 15:01:53 --> Database Driver Class Initialized
INFO - 2018-05-01 15:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:01:53 --> Email Class Initialized
INFO - 2018-05-01 15:01:53 --> Controller Class Initialized
INFO - 2018-05-01 15:01:53 --> Helper loaded: form_helper
INFO - 2018-05-01 15:01:53 --> Form Validation Class Initialized
INFO - 2018-05-01 15:01:53 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:01:53 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:01:53 --> Helper loaded: url_helper
INFO - 2018-05-01 15:01:53 --> Model Class Initialized
INFO - 2018-05-01 15:01:53 --> Model Class Initialized
INFO - 2018-05-01 15:01:53 --> Model Class Initialized
INFO - 2018-05-01 18:31:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:31:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:31:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 18:31:53 --> Trying to get property of non-object
ERROR - 2018-05-01 18:31:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 18:31:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:31:53 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:31:53 --> Final output sent to browser
DEBUG - 2018-05-01 18:31:53 --> Total execution time: 0.1420
INFO - 2018-05-01 15:02:01 --> Config Class Initialized
INFO - 2018-05-01 15:02:01 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:02:01 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:02:01 --> Utf8 Class Initialized
INFO - 2018-05-01 15:02:01 --> URI Class Initialized
INFO - 2018-05-01 15:02:01 --> Router Class Initialized
INFO - 2018-05-01 15:02:01 --> Output Class Initialized
INFO - 2018-05-01 15:02:01 --> Security Class Initialized
DEBUG - 2018-05-01 15:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:02:01 --> Input Class Initialized
INFO - 2018-05-01 15:02:01 --> Language Class Initialized
INFO - 2018-05-01 15:02:01 --> Loader Class Initialized
INFO - 2018-05-01 15:02:01 --> Helper loaded: common_helper
INFO - 2018-05-01 15:02:01 --> Database Driver Class Initialized
INFO - 2018-05-01 15:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:02:01 --> Email Class Initialized
INFO - 2018-05-01 15:02:01 --> Controller Class Initialized
INFO - 2018-05-01 15:02:01 --> Helper loaded: form_helper
INFO - 2018-05-01 15:02:01 --> Form Validation Class Initialized
INFO - 2018-05-01 15:02:01 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:02:01 --> Helper loaded: url_helper
INFO - 2018-05-01 15:02:01 --> Model Class Initialized
INFO - 2018-05-01 15:02:01 --> Model Class Initialized
INFO - 2018-05-01 15:02:01 --> Model Class Initialized
INFO - 2018-05-01 18:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:32:01 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:32:01 --> Final output sent to browser
DEBUG - 2018-05-01 18:32:01 --> Total execution time: 0.1450
INFO - 2018-05-01 15:04:18 --> Config Class Initialized
INFO - 2018-05-01 15:04:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:04:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:04:18 --> Utf8 Class Initialized
INFO - 2018-05-01 15:04:18 --> URI Class Initialized
INFO - 2018-05-01 15:04:18 --> Router Class Initialized
INFO - 2018-05-01 15:04:18 --> Output Class Initialized
INFO - 2018-05-01 15:04:18 --> Security Class Initialized
DEBUG - 2018-05-01 15:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:04:18 --> Input Class Initialized
INFO - 2018-05-01 15:04:18 --> Language Class Initialized
INFO - 2018-05-01 15:04:18 --> Loader Class Initialized
INFO - 2018-05-01 15:04:18 --> Helper loaded: common_helper
INFO - 2018-05-01 15:04:18 --> Database Driver Class Initialized
INFO - 2018-05-01 15:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:04:19 --> Email Class Initialized
INFO - 2018-05-01 15:04:19 --> Controller Class Initialized
INFO - 2018-05-01 15:04:19 --> Helper loaded: form_helper
INFO - 2018-05-01 15:04:19 --> Form Validation Class Initialized
INFO - 2018-05-01 15:04:19 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:04:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:04:19 --> Helper loaded: url_helper
INFO - 2018-05-01 15:04:19 --> Model Class Initialized
INFO - 2018-05-01 15:04:19 --> Model Class Initialized
INFO - 2018-05-01 15:04:19 --> Model Class Initialized
INFO - 2018-05-01 18:34:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:34:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:34:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:34:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:34:19 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:34:19 --> Final output sent to browser
DEBUG - 2018-05-01 18:34:19 --> Total execution time: 0.2360
INFO - 2018-05-01 15:04:22 --> Config Class Initialized
INFO - 2018-05-01 15:04:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:04:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:04:22 --> Utf8 Class Initialized
INFO - 2018-05-01 15:04:22 --> URI Class Initialized
INFO - 2018-05-01 15:04:22 --> Router Class Initialized
INFO - 2018-05-01 15:04:22 --> Output Class Initialized
INFO - 2018-05-01 15:04:22 --> Security Class Initialized
DEBUG - 2018-05-01 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:04:22 --> Input Class Initialized
INFO - 2018-05-01 15:04:22 --> Language Class Initialized
INFO - 2018-05-01 15:04:22 --> Loader Class Initialized
INFO - 2018-05-01 15:04:22 --> Helper loaded: common_helper
INFO - 2018-05-01 15:04:22 --> Database Driver Class Initialized
INFO - 2018-05-01 15:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:04:22 --> Email Class Initialized
INFO - 2018-05-01 15:04:22 --> Controller Class Initialized
INFO - 2018-05-01 15:04:22 --> Helper loaded: form_helper
INFO - 2018-05-01 15:04:22 --> Form Validation Class Initialized
INFO - 2018-05-01 15:04:22 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:04:22 --> Helper loaded: url_helper
INFO - 2018-05-01 15:04:22 --> Model Class Initialized
INFO - 2018-05-01 15:04:22 --> Model Class Initialized
INFO - 2018-05-01 15:04:22 --> Model Class Initialized
INFO - 2018-05-01 15:05:43 --> Config Class Initialized
INFO - 2018-05-01 15:05:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:05:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:05:43 --> Utf8 Class Initialized
INFO - 2018-05-01 15:05:43 --> URI Class Initialized
INFO - 2018-05-01 15:05:43 --> Router Class Initialized
INFO - 2018-05-01 15:05:43 --> Output Class Initialized
INFO - 2018-05-01 15:05:43 --> Security Class Initialized
DEBUG - 2018-05-01 15:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:05:43 --> Input Class Initialized
INFO - 2018-05-01 15:05:43 --> Language Class Initialized
INFO - 2018-05-01 15:05:43 --> Loader Class Initialized
INFO - 2018-05-01 15:05:43 --> Helper loaded: common_helper
INFO - 2018-05-01 15:05:43 --> Database Driver Class Initialized
INFO - 2018-05-01 15:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:05:43 --> Email Class Initialized
INFO - 2018-05-01 15:05:43 --> Controller Class Initialized
INFO - 2018-05-01 15:05:43 --> Helper loaded: form_helper
INFO - 2018-05-01 15:05:43 --> Form Validation Class Initialized
INFO - 2018-05-01 15:05:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:05:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:05:43 --> Helper loaded: url_helper
INFO - 2018-05-01 15:05:43 --> Model Class Initialized
INFO - 2018-05-01 15:05:43 --> Model Class Initialized
INFO - 2018-05-01 15:05:43 --> Model Class Initialized
INFO - 2018-05-01 18:35:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:35:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:35:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:35:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:35:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:35:43 --> Final output sent to browser
DEBUG - 2018-05-01 18:35:43 --> Total execution time: 0.1510
INFO - 2018-05-01 15:05:45 --> Config Class Initialized
INFO - 2018-05-01 15:05:45 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:05:45 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:05:45 --> Utf8 Class Initialized
INFO - 2018-05-01 15:05:45 --> URI Class Initialized
INFO - 2018-05-01 15:05:45 --> Router Class Initialized
INFO - 2018-05-01 15:05:45 --> Output Class Initialized
INFO - 2018-05-01 15:05:45 --> Security Class Initialized
DEBUG - 2018-05-01 15:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:05:45 --> Input Class Initialized
INFO - 2018-05-01 15:05:45 --> Language Class Initialized
INFO - 2018-05-01 15:05:45 --> Loader Class Initialized
INFO - 2018-05-01 15:05:45 --> Helper loaded: common_helper
INFO - 2018-05-01 15:05:45 --> Database Driver Class Initialized
INFO - 2018-05-01 15:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:05:45 --> Email Class Initialized
INFO - 2018-05-01 15:05:45 --> Controller Class Initialized
INFO - 2018-05-01 15:05:45 --> Helper loaded: form_helper
INFO - 2018-05-01 15:05:45 --> Form Validation Class Initialized
INFO - 2018-05-01 15:05:45 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:05:45 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:05:45 --> Helper loaded: url_helper
INFO - 2018-05-01 15:05:45 --> Model Class Initialized
INFO - 2018-05-01 15:05:45 --> Model Class Initialized
INFO - 2018-05-01 15:05:45 --> Model Class Initialized
INFO - 2018-05-01 18:35:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:35:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:35:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:35:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:35:45 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:35:45 --> Final output sent to browser
DEBUG - 2018-05-01 18:35:45 --> Total execution time: 0.1310
INFO - 2018-05-01 15:05:48 --> Config Class Initialized
INFO - 2018-05-01 15:05:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:05:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:05:48 --> Utf8 Class Initialized
INFO - 2018-05-01 15:05:48 --> URI Class Initialized
INFO - 2018-05-01 15:05:48 --> Router Class Initialized
INFO - 2018-05-01 15:05:48 --> Output Class Initialized
INFO - 2018-05-01 15:05:48 --> Security Class Initialized
DEBUG - 2018-05-01 15:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:05:48 --> Input Class Initialized
INFO - 2018-05-01 15:05:48 --> Language Class Initialized
INFO - 2018-05-01 15:05:48 --> Loader Class Initialized
INFO - 2018-05-01 15:05:48 --> Helper loaded: common_helper
INFO - 2018-05-01 15:05:48 --> Database Driver Class Initialized
INFO - 2018-05-01 15:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:05:48 --> Email Class Initialized
INFO - 2018-05-01 15:05:48 --> Controller Class Initialized
INFO - 2018-05-01 15:05:49 --> Helper loaded: form_helper
INFO - 2018-05-01 15:05:49 --> Form Validation Class Initialized
INFO - 2018-05-01 15:05:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:05:49 --> Helper loaded: url_helper
INFO - 2018-05-01 15:05:49 --> Model Class Initialized
INFO - 2018-05-01 15:05:49 --> Model Class Initialized
INFO - 2018-05-01 15:05:49 --> Model Class Initialized
ERROR - 2018-05-01 18:35:49 --> Query error: Unknown column 'movieId' in 'where clause' - Invalid query: UPDATE `movie_images` SET `isDeleted` = 1
WHERE `movieId` = '15'
INFO - 2018-05-01 15:05:49 --> Config Class Initialized
INFO - 2018-05-01 15:05:49 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:05:49 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:05:49 --> Utf8 Class Initialized
INFO - 2018-05-01 15:05:49 --> URI Class Initialized
INFO - 2018-05-01 15:05:49 --> Router Class Initialized
INFO - 2018-05-01 15:05:49 --> Output Class Initialized
INFO - 2018-05-01 15:05:49 --> Security Class Initialized
DEBUG - 2018-05-01 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:05:49 --> Input Class Initialized
INFO - 2018-05-01 15:05:49 --> Language Class Initialized
INFO - 2018-05-01 15:05:49 --> Loader Class Initialized
INFO - 2018-05-01 15:05:49 --> Helper loaded: common_helper
INFO - 2018-05-01 15:05:49 --> Database Driver Class Initialized
INFO - 2018-05-01 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:05:49 --> Email Class Initialized
INFO - 2018-05-01 15:05:49 --> Controller Class Initialized
INFO - 2018-05-01 15:05:49 --> Helper loaded: form_helper
INFO - 2018-05-01 15:05:49 --> Form Validation Class Initialized
INFO - 2018-05-01 15:05:49 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:05:49 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:05:49 --> Helper loaded: url_helper
INFO - 2018-05-01 15:05:49 --> Model Class Initialized
INFO - 2018-05-01 15:05:49 --> Model Class Initialized
INFO - 2018-05-01 15:05:49 --> Model Class Initialized
INFO - 2018-05-01 18:35:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:35:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:35:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:35:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:35:49 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:35:49 --> Final output sent to browser
DEBUG - 2018-05-01 18:35:49 --> Total execution time: 0.1270
INFO - 2018-05-01 15:10:06 --> Config Class Initialized
INFO - 2018-05-01 15:10:06 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:10:06 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:10:06 --> Utf8 Class Initialized
INFO - 2018-05-01 15:10:06 --> URI Class Initialized
INFO - 2018-05-01 15:10:06 --> Router Class Initialized
INFO - 2018-05-01 15:10:06 --> Output Class Initialized
INFO - 2018-05-01 15:10:06 --> Security Class Initialized
DEBUG - 2018-05-01 15:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:10:06 --> Input Class Initialized
INFO - 2018-05-01 15:10:06 --> Language Class Initialized
INFO - 2018-05-01 15:10:06 --> Loader Class Initialized
INFO - 2018-05-01 15:10:06 --> Helper loaded: common_helper
INFO - 2018-05-01 15:10:06 --> Database Driver Class Initialized
INFO - 2018-05-01 15:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:10:06 --> Email Class Initialized
INFO - 2018-05-01 15:10:06 --> Controller Class Initialized
INFO - 2018-05-01 15:10:06 --> Helper loaded: form_helper
INFO - 2018-05-01 15:10:06 --> Form Validation Class Initialized
INFO - 2018-05-01 15:10:06 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:10:06 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:10:06 --> Helper loaded: url_helper
INFO - 2018-05-01 15:10:06 --> Model Class Initialized
INFO - 2018-05-01 15:10:06 --> Model Class Initialized
INFO - 2018-05-01 15:10:06 --> Model Class Initialized
INFO - 2018-05-01 18:40:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:40:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:40:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:40:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:40:06 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:40:06 --> Final output sent to browser
DEBUG - 2018-05-01 18:40:06 --> Total execution time: 0.1430
INFO - 2018-05-01 15:14:11 --> Config Class Initialized
INFO - 2018-05-01 15:14:11 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:14:11 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:14:11 --> Utf8 Class Initialized
INFO - 2018-05-01 15:14:11 --> URI Class Initialized
INFO - 2018-05-01 15:14:11 --> Router Class Initialized
INFO - 2018-05-01 15:14:11 --> Output Class Initialized
INFO - 2018-05-01 15:14:11 --> Security Class Initialized
DEBUG - 2018-05-01 15:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:14:11 --> Input Class Initialized
INFO - 2018-05-01 15:14:11 --> Language Class Initialized
INFO - 2018-05-01 15:14:11 --> Loader Class Initialized
INFO - 2018-05-01 15:14:11 --> Helper loaded: common_helper
INFO - 2018-05-01 15:14:11 --> Database Driver Class Initialized
INFO - 2018-05-01 15:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:14:11 --> Email Class Initialized
INFO - 2018-05-01 15:14:11 --> Controller Class Initialized
INFO - 2018-05-01 15:14:11 --> Helper loaded: form_helper
INFO - 2018-05-01 15:14:11 --> Form Validation Class Initialized
INFO - 2018-05-01 15:14:11 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:14:11 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:14:11 --> Helper loaded: url_helper
INFO - 2018-05-01 15:14:11 --> Model Class Initialized
INFO - 2018-05-01 15:14:11 --> Model Class Initialized
INFO - 2018-05-01 15:14:11 --> Model Class Initialized
INFO - 2018-05-01 18:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:44:11 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:44:11 --> Final output sent to browser
DEBUG - 2018-05-01 18:44:11 --> Total execution time: 0.1480
INFO - 2018-05-01 15:14:36 --> Config Class Initialized
INFO - 2018-05-01 15:14:36 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:14:36 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:14:36 --> Utf8 Class Initialized
INFO - 2018-05-01 15:14:36 --> URI Class Initialized
INFO - 2018-05-01 15:14:36 --> Router Class Initialized
INFO - 2018-05-01 15:14:36 --> Output Class Initialized
INFO - 2018-05-01 15:14:36 --> Security Class Initialized
DEBUG - 2018-05-01 15:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:14:36 --> Input Class Initialized
INFO - 2018-05-01 15:14:36 --> Language Class Initialized
INFO - 2018-05-01 15:14:37 --> Loader Class Initialized
INFO - 2018-05-01 15:14:37 --> Helper loaded: common_helper
INFO - 2018-05-01 15:14:37 --> Database Driver Class Initialized
INFO - 2018-05-01 15:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:14:37 --> Email Class Initialized
INFO - 2018-05-01 15:14:37 --> Controller Class Initialized
INFO - 2018-05-01 15:14:37 --> Helper loaded: form_helper
INFO - 2018-05-01 15:14:37 --> Form Validation Class Initialized
INFO - 2018-05-01 15:14:37 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:14:37 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:14:37 --> Helper loaded: url_helper
INFO - 2018-05-01 15:14:37 --> Model Class Initialized
INFO - 2018-05-01 15:14:37 --> Model Class Initialized
INFO - 2018-05-01 15:14:37 --> Model Class Initialized
INFO - 2018-05-01 18:44:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:44:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:44:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:44:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:44:37 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:44:37 --> Final output sent to browser
DEBUG - 2018-05-01 18:44:37 --> Total execution time: 0.1400
INFO - 2018-05-01 15:14:41 --> Config Class Initialized
INFO - 2018-05-01 15:14:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:14:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:14:41 --> Utf8 Class Initialized
INFO - 2018-05-01 15:14:41 --> URI Class Initialized
INFO - 2018-05-01 15:14:41 --> Router Class Initialized
INFO - 2018-05-01 15:14:41 --> Output Class Initialized
INFO - 2018-05-01 15:14:41 --> Security Class Initialized
DEBUG - 2018-05-01 15:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:14:42 --> Input Class Initialized
INFO - 2018-05-01 15:14:42 --> Language Class Initialized
INFO - 2018-05-01 15:14:42 --> Loader Class Initialized
INFO - 2018-05-01 15:14:42 --> Helper loaded: common_helper
INFO - 2018-05-01 15:14:42 --> Database Driver Class Initialized
INFO - 2018-05-01 15:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:14:42 --> Email Class Initialized
INFO - 2018-05-01 15:14:42 --> Controller Class Initialized
INFO - 2018-05-01 15:14:42 --> Helper loaded: form_helper
INFO - 2018-05-01 15:14:42 --> Form Validation Class Initialized
INFO - 2018-05-01 15:14:42 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:14:42 --> Helper loaded: url_helper
INFO - 2018-05-01 15:14:42 --> Model Class Initialized
INFO - 2018-05-01 15:14:42 --> Model Class Initialized
INFO - 2018-05-01 15:14:42 --> Model Class Initialized
INFO - 2018-05-01 18:44:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:44:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:44:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 18:44:42 --> Trying to get property of non-object
ERROR - 2018-05-01 18:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 18:44:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:44:42 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:44:42 --> Final output sent to browser
DEBUG - 2018-05-01 18:44:42 --> Total execution time: 0.1520
INFO - 2018-05-01 15:14:44 --> Config Class Initialized
INFO - 2018-05-01 15:14:44 --> Hooks Class Initialized
DEBUG - 2018-05-01 15:14:44 --> UTF-8 Support Enabled
INFO - 2018-05-01 15:14:44 --> Utf8 Class Initialized
INFO - 2018-05-01 15:14:44 --> URI Class Initialized
INFO - 2018-05-01 15:14:44 --> Router Class Initialized
INFO - 2018-05-01 15:14:44 --> Output Class Initialized
INFO - 2018-05-01 15:14:44 --> Security Class Initialized
DEBUG - 2018-05-01 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 15:14:44 --> Input Class Initialized
INFO - 2018-05-01 15:14:44 --> Language Class Initialized
INFO - 2018-05-01 15:14:44 --> Loader Class Initialized
INFO - 2018-05-01 15:14:44 --> Helper loaded: common_helper
INFO - 2018-05-01 15:14:44 --> Database Driver Class Initialized
INFO - 2018-05-01 15:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 15:14:44 --> Email Class Initialized
INFO - 2018-05-01 15:14:44 --> Controller Class Initialized
INFO - 2018-05-01 15:14:44 --> Helper loaded: form_helper
INFO - 2018-05-01 15:14:44 --> Form Validation Class Initialized
INFO - 2018-05-01 15:14:44 --> Helper loaded: email_helper
DEBUG - 2018-05-01 15:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 15:14:44 --> Helper loaded: url_helper
INFO - 2018-05-01 15:14:44 --> Model Class Initialized
INFO - 2018-05-01 15:14:44 --> Model Class Initialized
INFO - 2018-05-01 15:14:44 --> Model Class Initialized
INFO - 2018-05-01 18:44:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 18:44:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 18:44:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 18:44:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 18:44:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 18:44:44 --> Final output sent to browser
DEBUG - 2018-05-01 18:44:44 --> Total execution time: 0.1320
INFO - 2018-05-01 16:07:34 --> Config Class Initialized
INFO - 2018-05-01 16:07:34 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:07:34 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:07:34 --> Utf8 Class Initialized
INFO - 2018-05-01 16:07:34 --> URI Class Initialized
INFO - 2018-05-01 16:07:34 --> Router Class Initialized
INFO - 2018-05-01 16:07:34 --> Output Class Initialized
INFO - 2018-05-01 16:07:34 --> Security Class Initialized
DEBUG - 2018-05-01 16:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:07:34 --> Input Class Initialized
INFO - 2018-05-01 16:07:34 --> Language Class Initialized
INFO - 2018-05-01 16:07:34 --> Loader Class Initialized
INFO - 2018-05-01 16:07:34 --> Helper loaded: common_helper
INFO - 2018-05-01 16:07:34 --> Database Driver Class Initialized
INFO - 2018-05-01 16:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:07:34 --> Email Class Initialized
INFO - 2018-05-01 16:07:34 --> Controller Class Initialized
INFO - 2018-05-01 16:07:34 --> Helper loaded: form_helper
INFO - 2018-05-01 16:07:34 --> Form Validation Class Initialized
INFO - 2018-05-01 16:07:34 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:07:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:07:34 --> Helper loaded: url_helper
INFO - 2018-05-01 16:07:34 --> Model Class Initialized
INFO - 2018-05-01 16:07:34 --> Model Class Initialized
INFO - 2018-05-01 16:07:34 --> Model Class Initialized
INFO - 2018-05-01 19:37:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:37:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:37:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:37:34 --> Trying to get property of non-object
ERROR - 2018-05-01 19:37:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:37:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:37:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:37:34 --> Final output sent to browser
DEBUG - 2018-05-01 19:37:34 --> Total execution time: 0.1520
INFO - 2018-05-01 16:12:07 --> Config Class Initialized
INFO - 2018-05-01 16:12:07 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:12:07 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:12:07 --> Utf8 Class Initialized
INFO - 2018-05-01 16:12:07 --> URI Class Initialized
INFO - 2018-05-01 16:12:07 --> Router Class Initialized
INFO - 2018-05-01 16:12:07 --> Output Class Initialized
INFO - 2018-05-01 16:12:07 --> Security Class Initialized
DEBUG - 2018-05-01 16:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:12:07 --> Input Class Initialized
INFO - 2018-05-01 16:12:07 --> Language Class Initialized
INFO - 2018-05-01 16:12:07 --> Loader Class Initialized
INFO - 2018-05-01 16:12:07 --> Helper loaded: common_helper
INFO - 2018-05-01 16:12:07 --> Database Driver Class Initialized
INFO - 2018-05-01 16:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:12:07 --> Email Class Initialized
INFO - 2018-05-01 16:12:07 --> Controller Class Initialized
INFO - 2018-05-01 16:12:07 --> Helper loaded: form_helper
INFO - 2018-05-01 16:12:07 --> Form Validation Class Initialized
INFO - 2018-05-01 16:12:07 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:12:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:12:07 --> Helper loaded: url_helper
INFO - 2018-05-01 16:12:07 --> Model Class Initialized
INFO - 2018-05-01 16:12:07 --> Model Class Initialized
INFO - 2018-05-01 16:12:07 --> Model Class Initialized
INFO - 2018-05-01 19:42:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:42:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:42:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:42:07 --> Trying to get property of non-object
ERROR - 2018-05-01 19:42:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:42:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:42:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:42:07 --> Final output sent to browser
DEBUG - 2018-05-01 19:42:07 --> Total execution time: 0.1510
INFO - 2018-05-01 16:14:22 --> Config Class Initialized
INFO - 2018-05-01 16:14:22 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:14:22 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:14:22 --> Utf8 Class Initialized
INFO - 2018-05-01 16:14:22 --> URI Class Initialized
INFO - 2018-05-01 16:14:22 --> Router Class Initialized
INFO - 2018-05-01 16:14:22 --> Output Class Initialized
INFO - 2018-05-01 16:14:22 --> Security Class Initialized
DEBUG - 2018-05-01 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:14:22 --> Input Class Initialized
INFO - 2018-05-01 16:14:22 --> Language Class Initialized
INFO - 2018-05-01 16:14:22 --> Loader Class Initialized
INFO - 2018-05-01 16:14:22 --> Helper loaded: common_helper
INFO - 2018-05-01 16:14:22 --> Database Driver Class Initialized
INFO - 2018-05-01 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:14:22 --> Email Class Initialized
INFO - 2018-05-01 16:14:22 --> Controller Class Initialized
INFO - 2018-05-01 16:14:22 --> Helper loaded: form_helper
INFO - 2018-05-01 16:14:22 --> Form Validation Class Initialized
INFO - 2018-05-01 16:14:22 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:14:22 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:14:22 --> Helper loaded: url_helper
INFO - 2018-05-01 16:14:22 --> Model Class Initialized
INFO - 2018-05-01 16:14:22 --> Model Class Initialized
INFO - 2018-05-01 16:14:22 --> Model Class Initialized
INFO - 2018-05-01 19:44:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:44:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:44:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:44:22 --> Trying to get property of non-object
ERROR - 2018-05-01 19:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:44:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:44:22 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:44:22 --> Final output sent to browser
DEBUG - 2018-05-01 19:44:22 --> Total execution time: 0.1470
INFO - 2018-05-01 16:14:29 --> Config Class Initialized
INFO - 2018-05-01 16:14:29 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:14:29 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:14:29 --> Utf8 Class Initialized
INFO - 2018-05-01 16:14:29 --> URI Class Initialized
INFO - 2018-05-01 16:14:29 --> Router Class Initialized
INFO - 2018-05-01 16:14:29 --> Output Class Initialized
INFO - 2018-05-01 16:14:29 --> Security Class Initialized
DEBUG - 2018-05-01 16:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:14:29 --> Input Class Initialized
INFO - 2018-05-01 16:14:29 --> Language Class Initialized
INFO - 2018-05-01 16:14:29 --> Loader Class Initialized
INFO - 2018-05-01 16:14:29 --> Helper loaded: common_helper
INFO - 2018-05-01 16:14:29 --> Database Driver Class Initialized
INFO - 2018-05-01 16:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:14:29 --> Email Class Initialized
INFO - 2018-05-01 16:14:29 --> Controller Class Initialized
INFO - 2018-05-01 16:14:29 --> Helper loaded: form_helper
INFO - 2018-05-01 16:14:29 --> Form Validation Class Initialized
INFO - 2018-05-01 16:14:29 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:14:29 --> Helper loaded: url_helper
INFO - 2018-05-01 16:14:29 --> Model Class Initialized
INFO - 2018-05-01 16:14:29 --> Model Class Initialized
INFO - 2018-05-01 16:14:29 --> Model Class Initialized
INFO - 2018-05-01 19:44:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:44:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:44:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:44:29 --> Trying to get property of non-object
ERROR - 2018-05-01 19:44:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:44:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:44:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:44:29 --> Final output sent to browser
DEBUG - 2018-05-01 19:44:29 --> Total execution time: 0.1440
INFO - 2018-05-01 16:14:31 --> Config Class Initialized
INFO - 2018-05-01 16:14:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:14:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:14:31 --> Utf8 Class Initialized
INFO - 2018-05-01 16:14:31 --> URI Class Initialized
INFO - 2018-05-01 16:14:31 --> Router Class Initialized
INFO - 2018-05-01 16:14:31 --> Output Class Initialized
INFO - 2018-05-01 16:14:31 --> Security Class Initialized
DEBUG - 2018-05-01 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:14:31 --> Input Class Initialized
INFO - 2018-05-01 16:14:31 --> Language Class Initialized
INFO - 2018-05-01 16:14:31 --> Loader Class Initialized
INFO - 2018-05-01 16:14:31 --> Helper loaded: common_helper
INFO - 2018-05-01 16:14:31 --> Database Driver Class Initialized
INFO - 2018-05-01 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:14:31 --> Email Class Initialized
INFO - 2018-05-01 16:14:31 --> Controller Class Initialized
INFO - 2018-05-01 16:14:31 --> Helper loaded: form_helper
INFO - 2018-05-01 16:14:31 --> Form Validation Class Initialized
INFO - 2018-05-01 16:14:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:14:31 --> Helper loaded: url_helper
INFO - 2018-05-01 16:14:31 --> Model Class Initialized
INFO - 2018-05-01 16:14:31 --> Model Class Initialized
INFO - 2018-05-01 16:14:31 --> Model Class Initialized
INFO - 2018-05-01 19:44:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:44:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:44:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:44:31 --> Trying to get property of non-object
ERROR - 2018-05-01 19:44:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:44:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:44:31 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:44:31 --> Final output sent to browser
DEBUG - 2018-05-01 19:44:31 --> Total execution time: 0.1460
INFO - 2018-05-01 16:14:33 --> Config Class Initialized
INFO - 2018-05-01 16:14:33 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:14:33 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:14:33 --> Utf8 Class Initialized
INFO - 2018-05-01 16:14:33 --> URI Class Initialized
INFO - 2018-05-01 16:14:33 --> Router Class Initialized
INFO - 2018-05-01 16:14:33 --> Output Class Initialized
INFO - 2018-05-01 16:14:33 --> Security Class Initialized
DEBUG - 2018-05-01 16:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:14:33 --> Input Class Initialized
INFO - 2018-05-01 16:14:33 --> Language Class Initialized
INFO - 2018-05-01 16:14:33 --> Loader Class Initialized
INFO - 2018-05-01 16:14:33 --> Helper loaded: common_helper
INFO - 2018-05-01 16:14:33 --> Database Driver Class Initialized
INFO - 2018-05-01 16:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:14:33 --> Email Class Initialized
INFO - 2018-05-01 16:14:33 --> Controller Class Initialized
INFO - 2018-05-01 16:14:33 --> Helper loaded: form_helper
INFO - 2018-05-01 16:14:33 --> Form Validation Class Initialized
INFO - 2018-05-01 16:14:33 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:14:33 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:14:33 --> Helper loaded: url_helper
INFO - 2018-05-01 16:14:33 --> Model Class Initialized
INFO - 2018-05-01 16:14:33 --> Model Class Initialized
INFO - 2018-05-01 16:14:33 --> Model Class Initialized
INFO - 2018-05-01 19:44:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:44:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:44:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:44:33 --> Trying to get property of non-object
ERROR - 2018-05-01 19:44:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:44:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:44:33 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:44:33 --> Final output sent to browser
DEBUG - 2018-05-01 19:44:33 --> Total execution time: 0.1980
INFO - 2018-05-01 16:14:39 --> Config Class Initialized
INFO - 2018-05-01 16:14:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:14:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:14:39 --> Utf8 Class Initialized
INFO - 2018-05-01 16:14:39 --> URI Class Initialized
INFO - 2018-05-01 16:14:39 --> Router Class Initialized
INFO - 2018-05-01 16:14:39 --> Output Class Initialized
INFO - 2018-05-01 16:14:39 --> Security Class Initialized
DEBUG - 2018-05-01 16:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:14:39 --> Input Class Initialized
INFO - 2018-05-01 16:14:39 --> Language Class Initialized
INFO - 2018-05-01 16:14:39 --> Loader Class Initialized
INFO - 2018-05-01 16:14:39 --> Helper loaded: common_helper
INFO - 2018-05-01 16:14:39 --> Database Driver Class Initialized
INFO - 2018-05-01 16:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:14:39 --> Email Class Initialized
INFO - 2018-05-01 16:14:39 --> Controller Class Initialized
INFO - 2018-05-01 16:14:39 --> Helper loaded: form_helper
INFO - 2018-05-01 16:14:39 --> Form Validation Class Initialized
INFO - 2018-05-01 16:14:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:14:39 --> Helper loaded: url_helper
INFO - 2018-05-01 16:14:39 --> Model Class Initialized
INFO - 2018-05-01 16:14:39 --> Model Class Initialized
INFO - 2018-05-01 16:14:39 --> Model Class Initialized
INFO - 2018-05-01 19:44:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:44:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:44:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 19:44:39 --> Trying to get property of non-object
ERROR - 2018-05-01 19:44:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 19:44:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:44:39 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:44:39 --> Final output sent to browser
DEBUG - 2018-05-01 19:44:39 --> Total execution time: 0.1480
INFO - 2018-05-01 16:15:19 --> Config Class Initialized
INFO - 2018-05-01 16:15:19 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:15:19 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:15:19 --> Utf8 Class Initialized
INFO - 2018-05-01 16:15:19 --> URI Class Initialized
INFO - 2018-05-01 16:15:19 --> Router Class Initialized
INFO - 2018-05-01 16:15:19 --> Output Class Initialized
INFO - 2018-05-01 16:15:19 --> Security Class Initialized
DEBUG - 2018-05-01 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:15:19 --> Input Class Initialized
INFO - 2018-05-01 16:15:19 --> Language Class Initialized
INFO - 2018-05-01 16:15:19 --> Loader Class Initialized
INFO - 2018-05-01 16:15:19 --> Helper loaded: common_helper
INFO - 2018-05-01 16:15:19 --> Database Driver Class Initialized
INFO - 2018-05-01 16:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:15:19 --> Email Class Initialized
INFO - 2018-05-01 16:15:19 --> Controller Class Initialized
INFO - 2018-05-01 16:15:19 --> Helper loaded: form_helper
INFO - 2018-05-01 16:15:19 --> Form Validation Class Initialized
INFO - 2018-05-01 16:15:19 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:15:19 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:15:19 --> Helper loaded: url_helper
INFO - 2018-05-01 16:15:19 --> Model Class Initialized
INFO - 2018-05-01 16:15:19 --> Model Class Initialized
INFO - 2018-05-01 16:15:19 --> Model Class Initialized
INFO - 2018-05-01 19:45:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:45:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\calender.php
INFO - 2018-05-01 19:45:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:45:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 19:45:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/editTrailer.php
INFO - 2018-05-01 19:45:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:45:20 --> Final output sent to browser
DEBUG - 2018-05-01 19:45:20 --> Total execution time: 0.5640
INFO - 2018-05-01 16:15:34 --> Config Class Initialized
INFO - 2018-05-01 16:15:34 --> Hooks Class Initialized
DEBUG - 2018-05-01 16:15:34 --> UTF-8 Support Enabled
INFO - 2018-05-01 16:15:34 --> Utf8 Class Initialized
INFO - 2018-05-01 16:15:34 --> URI Class Initialized
INFO - 2018-05-01 16:15:34 --> Router Class Initialized
INFO - 2018-05-01 16:15:34 --> Output Class Initialized
INFO - 2018-05-01 16:15:34 --> Security Class Initialized
DEBUG - 2018-05-01 16:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 16:15:34 --> Input Class Initialized
INFO - 2018-05-01 16:15:34 --> Language Class Initialized
INFO - 2018-05-01 16:15:34 --> Loader Class Initialized
INFO - 2018-05-01 16:15:34 --> Helper loaded: common_helper
INFO - 2018-05-01 16:15:35 --> Database Driver Class Initialized
INFO - 2018-05-01 16:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 16:15:35 --> Email Class Initialized
INFO - 2018-05-01 16:15:35 --> Controller Class Initialized
INFO - 2018-05-01 16:15:35 --> Helper loaded: form_helper
INFO - 2018-05-01 16:15:35 --> Form Validation Class Initialized
INFO - 2018-05-01 16:15:35 --> Helper loaded: email_helper
DEBUG - 2018-05-01 16:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 16:15:35 --> Helper loaded: url_helper
INFO - 2018-05-01 16:15:35 --> Model Class Initialized
INFO - 2018-05-01 16:15:35 --> Model Class Initialized
INFO - 2018-05-01 16:15:35 --> Model Class Initialized
INFO - 2018-05-01 19:45:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 19:45:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 19:45:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 19:45:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 19:45:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 19:45:35 --> Final output sent to browser
DEBUG - 2018-05-01 19:45:35 --> Total execution time: 0.1830
INFO - 2018-05-01 17:54:29 --> Config Class Initialized
INFO - 2018-05-01 17:54:29 --> Hooks Class Initialized
DEBUG - 2018-05-01 17:54:29 --> UTF-8 Support Enabled
INFO - 2018-05-01 17:54:29 --> Utf8 Class Initialized
INFO - 2018-05-01 17:54:29 --> URI Class Initialized
INFO - 2018-05-01 17:54:29 --> Router Class Initialized
INFO - 2018-05-01 17:54:29 --> Output Class Initialized
INFO - 2018-05-01 17:54:29 --> Security Class Initialized
DEBUG - 2018-05-01 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 17:54:29 --> Input Class Initialized
INFO - 2018-05-01 17:54:29 --> Language Class Initialized
INFO - 2018-05-01 17:54:29 --> Loader Class Initialized
INFO - 2018-05-01 17:54:29 --> Helper loaded: common_helper
INFO - 2018-05-01 17:54:29 --> Database Driver Class Initialized
INFO - 2018-05-01 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 17:54:29 --> Email Class Initialized
INFO - 2018-05-01 17:54:29 --> Controller Class Initialized
INFO - 2018-05-01 17:54:29 --> Helper loaded: form_helper
INFO - 2018-05-01 17:54:29 --> Form Validation Class Initialized
INFO - 2018-05-01 17:54:29 --> Helper loaded: email_helper
DEBUG - 2018-05-01 17:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 17:54:29 --> Helper loaded: url_helper
INFO - 2018-05-01 17:54:29 --> Model Class Initialized
INFO - 2018-05-01 17:54:29 --> Model Class Initialized
INFO - 2018-05-01 17:54:29 --> Model Class Initialized
INFO - 2018-05-01 21:24:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:24:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:24:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:24:29 --> Trying to get property of non-object
ERROR - 2018-05-01 21:24:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:24:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:24:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:24:29 --> Final output sent to browser
DEBUG - 2018-05-01 21:24:29 --> Total execution time: 0.0770
INFO - 2018-05-01 18:11:59 --> Config Class Initialized
INFO - 2018-05-01 18:11:59 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:11:59 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:11:59 --> Utf8 Class Initialized
INFO - 2018-05-01 18:11:59 --> URI Class Initialized
INFO - 2018-05-01 18:11:59 --> Router Class Initialized
INFO - 2018-05-01 18:11:59 --> Output Class Initialized
INFO - 2018-05-01 18:11:59 --> Security Class Initialized
DEBUG - 2018-05-01 18:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:11:59 --> Input Class Initialized
INFO - 2018-05-01 18:11:59 --> Language Class Initialized
INFO - 2018-05-01 18:11:59 --> Loader Class Initialized
INFO - 2018-05-01 18:11:59 --> Helper loaded: common_helper
INFO - 2018-05-01 18:11:59 --> Database Driver Class Initialized
INFO - 2018-05-01 18:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:11:59 --> Email Class Initialized
INFO - 2018-05-01 18:11:59 --> Controller Class Initialized
INFO - 2018-05-01 18:11:59 --> Helper loaded: form_helper
INFO - 2018-05-01 18:11:59 --> Form Validation Class Initialized
INFO - 2018-05-01 18:11:59 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:11:59 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:11:59 --> Helper loaded: url_helper
INFO - 2018-05-01 18:11:59 --> Model Class Initialized
INFO - 2018-05-01 18:11:59 --> Model Class Initialized
INFO - 2018-05-01 18:11:59 --> Model Class Initialized
INFO - 2018-05-01 21:41:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:41:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:41:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:41:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:41:59 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:41:59 --> Final output sent to browser
DEBUG - 2018-05-01 21:41:59 --> Total execution time: 0.1960
INFO - 2018-05-01 18:12:03 --> Config Class Initialized
INFO - 2018-05-01 18:12:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:03 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:03 --> URI Class Initialized
INFO - 2018-05-01 18:12:03 --> Router Class Initialized
INFO - 2018-05-01 18:12:03 --> Output Class Initialized
INFO - 2018-05-01 18:12:03 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:03 --> Input Class Initialized
INFO - 2018-05-01 18:12:03 --> Language Class Initialized
INFO - 2018-05-01 18:12:03 --> Loader Class Initialized
INFO - 2018-05-01 18:12:03 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:03 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:03 --> Email Class Initialized
INFO - 2018-05-01 18:12:03 --> Controller Class Initialized
INFO - 2018-05-01 18:12:03 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:03 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:03 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:03 --> Model Class Initialized
INFO - 2018-05-01 18:12:03 --> Model Class Initialized
INFO - 2018-05-01 18:12:03 --> Model Class Initialized
INFO - 2018-05-01 21:42:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:42:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:42:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 21:42:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:42:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:42:03 --> Final output sent to browser
DEBUG - 2018-05-01 21:42:03 --> Total execution time: 0.2630
INFO - 2018-05-01 18:12:05 --> Config Class Initialized
INFO - 2018-05-01 18:12:05 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:05 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:05 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:05 --> URI Class Initialized
INFO - 2018-05-01 18:12:05 --> Router Class Initialized
INFO - 2018-05-01 18:12:05 --> Output Class Initialized
INFO - 2018-05-01 18:12:05 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:05 --> Input Class Initialized
INFO - 2018-05-01 18:12:05 --> Language Class Initialized
INFO - 2018-05-01 18:12:05 --> Loader Class Initialized
INFO - 2018-05-01 18:12:05 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:05 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:05 --> Email Class Initialized
INFO - 2018-05-01 18:12:05 --> Controller Class Initialized
INFO - 2018-05-01 18:12:05 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:05 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:05 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:05 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:05 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:05 --> Model Class Initialized
INFO - 2018-05-01 18:12:05 --> Model Class Initialized
INFO - 2018-05-01 18:12:05 --> Model Class Initialized
INFO - 2018-05-01 21:42:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:42:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:42:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:42:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:42:05 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:42:05 --> Final output sent to browser
DEBUG - 2018-05-01 21:42:05 --> Total execution time: 0.1810
INFO - 2018-05-01 18:12:10 --> Config Class Initialized
INFO - 2018-05-01 18:12:10 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:10 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:10 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:10 --> URI Class Initialized
INFO - 2018-05-01 18:12:10 --> Router Class Initialized
INFO - 2018-05-01 18:12:10 --> Output Class Initialized
INFO - 2018-05-01 18:12:10 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:10 --> Input Class Initialized
INFO - 2018-05-01 18:12:10 --> Language Class Initialized
INFO - 2018-05-01 18:12:10 --> Loader Class Initialized
INFO - 2018-05-01 18:12:10 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:10 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:10 --> Email Class Initialized
INFO - 2018-05-01 18:12:10 --> Controller Class Initialized
INFO - 2018-05-01 18:12:10 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:10 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:10 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:10 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:10 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:10 --> Model Class Initialized
INFO - 2018-05-01 18:12:10 --> Model Class Initialized
INFO - 2018-05-01 18:12:10 --> Model Class Initialized
INFO - 2018-05-01 21:42:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:42:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:42:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:42:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/addGelery.php
INFO - 2018-05-01 21:42:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:42:10 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:42:10 --> Final output sent to browser
DEBUG - 2018-05-01 21:42:10 --> Total execution time: 0.1640
INFO - 2018-05-01 18:12:23 --> Config Class Initialized
INFO - 2018-05-01 18:12:23 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:23 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:23 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:23 --> URI Class Initialized
INFO - 2018-05-01 18:12:23 --> Router Class Initialized
INFO - 2018-05-01 18:12:23 --> Output Class Initialized
INFO - 2018-05-01 18:12:23 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:23 --> Input Class Initialized
INFO - 2018-05-01 18:12:23 --> Language Class Initialized
INFO - 2018-05-01 18:12:23 --> Loader Class Initialized
INFO - 2018-05-01 18:12:23 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:23 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:23 --> Email Class Initialized
INFO - 2018-05-01 18:12:23 --> Controller Class Initialized
INFO - 2018-05-01 18:12:23 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:23 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:23 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:23 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:23 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:23 --> Model Class Initialized
INFO - 2018-05-01 18:12:23 --> Model Class Initialized
INFO - 2018-05-01 18:12:23 --> Model Class Initialized
DEBUG - 2018-05-01 21:42:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2018-05-01 21:42:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2018-05-01 18:12:24 --> Config Class Initialized
INFO - 2018-05-01 18:12:24 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:24 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:24 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:24 --> URI Class Initialized
INFO - 2018-05-01 18:12:24 --> Router Class Initialized
INFO - 2018-05-01 18:12:24 --> Output Class Initialized
INFO - 2018-05-01 18:12:24 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:24 --> Input Class Initialized
INFO - 2018-05-01 18:12:24 --> Language Class Initialized
INFO - 2018-05-01 18:12:24 --> Loader Class Initialized
INFO - 2018-05-01 18:12:24 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:24 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:24 --> Email Class Initialized
INFO - 2018-05-01 18:12:24 --> Controller Class Initialized
INFO - 2018-05-01 18:12:24 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:24 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:24 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:24 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:24 --> Model Class Initialized
INFO - 2018-05-01 18:12:24 --> Model Class Initialized
INFO - 2018-05-01 18:12:24 --> Model Class Initialized
INFO - 2018-05-01 21:42:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:42:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:42:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:42:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:42:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:42:24 --> Final output sent to browser
DEBUG - 2018-05-01 21:42:24 --> Total execution time: 0.1270
INFO - 2018-05-01 18:12:46 --> Config Class Initialized
INFO - 2018-05-01 18:12:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:46 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:46 --> URI Class Initialized
INFO - 2018-05-01 18:12:46 --> Router Class Initialized
INFO - 2018-05-01 18:12:46 --> Output Class Initialized
INFO - 2018-05-01 18:12:46 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:46 --> Input Class Initialized
INFO - 2018-05-01 18:12:46 --> Language Class Initialized
INFO - 2018-05-01 18:12:46 --> Loader Class Initialized
INFO - 2018-05-01 18:12:46 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:46 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:46 --> Email Class Initialized
INFO - 2018-05-01 18:12:46 --> Controller Class Initialized
INFO - 2018-05-01 18:12:46 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:46 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:46 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:46 --> Model Class Initialized
INFO - 2018-05-01 18:12:46 --> Model Class Initialized
INFO - 2018-05-01 18:12:46 --> Model Class Initialized
INFO - 2018-05-01 18:12:46 --> Config Class Initialized
INFO - 2018-05-01 18:12:46 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:12:46 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:12:46 --> Utf8 Class Initialized
INFO - 2018-05-01 18:12:46 --> URI Class Initialized
INFO - 2018-05-01 18:12:46 --> Router Class Initialized
INFO - 2018-05-01 18:12:46 --> Output Class Initialized
INFO - 2018-05-01 18:12:46 --> Security Class Initialized
DEBUG - 2018-05-01 18:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:12:46 --> Input Class Initialized
INFO - 2018-05-01 18:12:46 --> Language Class Initialized
INFO - 2018-05-01 18:12:46 --> Loader Class Initialized
INFO - 2018-05-01 18:12:46 --> Helper loaded: common_helper
INFO - 2018-05-01 18:12:46 --> Database Driver Class Initialized
INFO - 2018-05-01 18:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:12:46 --> Email Class Initialized
INFO - 2018-05-01 18:12:46 --> Controller Class Initialized
INFO - 2018-05-01 18:12:46 --> Helper loaded: form_helper
INFO - 2018-05-01 18:12:46 --> Form Validation Class Initialized
INFO - 2018-05-01 18:12:46 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:12:46 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:12:46 --> Helper loaded: url_helper
INFO - 2018-05-01 18:12:46 --> Model Class Initialized
INFO - 2018-05-01 18:12:46 --> Model Class Initialized
INFO - 2018-05-01 18:12:46 --> Model Class Initialized
INFO - 2018-05-01 21:42:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:42:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:42:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:42:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:42:46 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:42:46 --> Final output sent to browser
DEBUG - 2018-05-01 21:42:46 --> Total execution time: 0.1460
INFO - 2018-05-01 18:13:02 --> Config Class Initialized
INFO - 2018-05-01 18:13:02 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:13:02 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:13:02 --> Utf8 Class Initialized
INFO - 2018-05-01 18:13:02 --> URI Class Initialized
INFO - 2018-05-01 18:13:02 --> Router Class Initialized
INFO - 2018-05-01 18:13:02 --> Output Class Initialized
INFO - 2018-05-01 18:13:02 --> Security Class Initialized
DEBUG - 2018-05-01 18:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:13:02 --> Input Class Initialized
INFO - 2018-05-01 18:13:02 --> Language Class Initialized
INFO - 2018-05-01 18:13:02 --> Loader Class Initialized
INFO - 2018-05-01 18:13:02 --> Helper loaded: common_helper
INFO - 2018-05-01 18:13:02 --> Database Driver Class Initialized
INFO - 2018-05-01 18:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:13:02 --> Email Class Initialized
INFO - 2018-05-01 18:13:02 --> Controller Class Initialized
INFO - 2018-05-01 18:13:02 --> Helper loaded: form_helper
INFO - 2018-05-01 18:13:02 --> Form Validation Class Initialized
INFO - 2018-05-01 18:13:02 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:13:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:13:02 --> Helper loaded: url_helper
INFO - 2018-05-01 18:13:02 --> Model Class Initialized
INFO - 2018-05-01 18:13:02 --> Model Class Initialized
INFO - 2018-05-01 18:13:02 --> Model Class Initialized
INFO - 2018-05-01 21:43:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:43:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:43:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:43:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:43:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:43:02 --> Final output sent to browser
DEBUG - 2018-05-01 21:43:02 --> Total execution time: 0.1320
INFO - 2018-05-01 18:13:29 --> Config Class Initialized
INFO - 2018-05-01 18:13:29 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:13:29 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:13:29 --> Utf8 Class Initialized
INFO - 2018-05-01 18:13:29 --> URI Class Initialized
INFO - 2018-05-01 18:13:29 --> Router Class Initialized
INFO - 2018-05-01 18:13:29 --> Output Class Initialized
INFO - 2018-05-01 18:13:29 --> Security Class Initialized
DEBUG - 2018-05-01 18:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:13:29 --> Input Class Initialized
INFO - 2018-05-01 18:13:29 --> Language Class Initialized
INFO - 2018-05-01 18:13:29 --> Loader Class Initialized
INFO - 2018-05-01 18:13:29 --> Helper loaded: common_helper
INFO - 2018-05-01 18:13:29 --> Database Driver Class Initialized
INFO - 2018-05-01 18:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:13:29 --> Email Class Initialized
INFO - 2018-05-01 18:13:29 --> Controller Class Initialized
INFO - 2018-05-01 18:13:29 --> Helper loaded: form_helper
INFO - 2018-05-01 18:13:29 --> Form Validation Class Initialized
INFO - 2018-05-01 18:13:29 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:13:29 --> Helper loaded: url_helper
INFO - 2018-05-01 18:13:29 --> Model Class Initialized
INFO - 2018-05-01 18:13:29 --> Model Class Initialized
INFO - 2018-05-01 18:13:29 --> Model Class Initialized
INFO - 2018-05-01 21:43:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:43:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:43:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:43:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:43:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:43:29 --> Final output sent to browser
DEBUG - 2018-05-01 21:43:29 --> Total execution time: 0.1410
INFO - 2018-05-01 18:13:35 --> Config Class Initialized
INFO - 2018-05-01 18:13:35 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:13:35 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:13:35 --> Utf8 Class Initialized
INFO - 2018-05-01 18:13:35 --> URI Class Initialized
INFO - 2018-05-01 18:13:35 --> Router Class Initialized
INFO - 2018-05-01 18:13:35 --> Output Class Initialized
INFO - 2018-05-01 18:13:35 --> Security Class Initialized
DEBUG - 2018-05-01 18:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:13:35 --> Input Class Initialized
INFO - 2018-05-01 18:13:35 --> Language Class Initialized
INFO - 2018-05-01 18:13:35 --> Loader Class Initialized
INFO - 2018-05-01 18:13:35 --> Helper loaded: common_helper
INFO - 2018-05-01 18:13:35 --> Database Driver Class Initialized
INFO - 2018-05-01 18:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:13:35 --> Email Class Initialized
INFO - 2018-05-01 18:13:35 --> Controller Class Initialized
INFO - 2018-05-01 18:13:35 --> Helper loaded: form_helper
INFO - 2018-05-01 18:13:35 --> Form Validation Class Initialized
INFO - 2018-05-01 18:13:35 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:13:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:13:35 --> Helper loaded: url_helper
INFO - 2018-05-01 18:13:35 --> Model Class Initialized
INFO - 2018-05-01 18:13:35 --> Model Class Initialized
INFO - 2018-05-01 18:13:35 --> Model Class Initialized
ERROR - 2018-05-01 21:43:35 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:43:35 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:13:39 --> Config Class Initialized
INFO - 2018-05-01 18:13:39 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:13:39 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:13:39 --> Utf8 Class Initialized
INFO - 2018-05-01 18:13:39 --> URI Class Initialized
INFO - 2018-05-01 18:13:39 --> Router Class Initialized
INFO - 2018-05-01 18:13:39 --> Output Class Initialized
INFO - 2018-05-01 18:13:39 --> Security Class Initialized
DEBUG - 2018-05-01 18:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:13:39 --> Input Class Initialized
INFO - 2018-05-01 18:13:39 --> Language Class Initialized
INFO - 2018-05-01 18:13:39 --> Loader Class Initialized
INFO - 2018-05-01 18:13:39 --> Helper loaded: common_helper
INFO - 2018-05-01 18:13:39 --> Database Driver Class Initialized
INFO - 2018-05-01 18:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:13:39 --> Email Class Initialized
INFO - 2018-05-01 18:13:39 --> Controller Class Initialized
INFO - 2018-05-01 18:13:39 --> Helper loaded: form_helper
INFO - 2018-05-01 18:13:39 --> Form Validation Class Initialized
INFO - 2018-05-01 18:13:39 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:13:39 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:13:39 --> Helper loaded: url_helper
INFO - 2018-05-01 18:13:39 --> Model Class Initialized
INFO - 2018-05-01 18:13:39 --> Model Class Initialized
INFO - 2018-05-01 18:13:39 --> Model Class Initialized
ERROR - 2018-05-01 21:43:39 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:43:39 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:13:43 --> Config Class Initialized
INFO - 2018-05-01 18:13:43 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:13:43 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:13:43 --> Utf8 Class Initialized
INFO - 2018-05-01 18:13:43 --> URI Class Initialized
INFO - 2018-05-01 18:13:43 --> Router Class Initialized
INFO - 2018-05-01 18:13:43 --> Output Class Initialized
INFO - 2018-05-01 18:13:43 --> Security Class Initialized
DEBUG - 2018-05-01 18:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:13:43 --> Input Class Initialized
INFO - 2018-05-01 18:13:43 --> Language Class Initialized
INFO - 2018-05-01 18:13:43 --> Loader Class Initialized
INFO - 2018-05-01 18:13:43 --> Helper loaded: common_helper
INFO - 2018-05-01 18:13:43 --> Database Driver Class Initialized
INFO - 2018-05-01 18:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:13:43 --> Email Class Initialized
INFO - 2018-05-01 18:13:43 --> Controller Class Initialized
INFO - 2018-05-01 18:13:43 --> Helper loaded: form_helper
INFO - 2018-05-01 18:13:43 --> Form Validation Class Initialized
INFO - 2018-05-01 18:13:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:13:43 --> Helper loaded: url_helper
INFO - 2018-05-01 18:13:43 --> Model Class Initialized
INFO - 2018-05-01 18:13:43 --> Model Class Initialized
INFO - 2018-05-01 18:13:43 --> Model Class Initialized
ERROR - 2018-05-01 21:43:43 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:43:43 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:13:57 --> Config Class Initialized
INFO - 2018-05-01 18:13:57 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:13:57 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:13:57 --> Utf8 Class Initialized
INFO - 2018-05-01 18:13:57 --> URI Class Initialized
INFO - 2018-05-01 18:13:57 --> Router Class Initialized
INFO - 2018-05-01 18:13:57 --> Output Class Initialized
INFO - 2018-05-01 18:13:57 --> Security Class Initialized
DEBUG - 2018-05-01 18:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:13:57 --> Input Class Initialized
INFO - 2018-05-01 18:13:57 --> Language Class Initialized
INFO - 2018-05-01 18:13:57 --> Loader Class Initialized
INFO - 2018-05-01 18:13:57 --> Helper loaded: common_helper
INFO - 2018-05-01 18:13:57 --> Database Driver Class Initialized
INFO - 2018-05-01 18:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:13:57 --> Email Class Initialized
INFO - 2018-05-01 18:13:57 --> Controller Class Initialized
INFO - 2018-05-01 18:13:57 --> Helper loaded: form_helper
INFO - 2018-05-01 18:13:57 --> Form Validation Class Initialized
INFO - 2018-05-01 18:13:57 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:13:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:13:57 --> Helper loaded: url_helper
INFO - 2018-05-01 18:13:57 --> Model Class Initialized
INFO - 2018-05-01 18:13:57 --> Model Class Initialized
INFO - 2018-05-01 18:13:57 --> Model Class Initialized
INFO - 2018-05-01 21:43:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:43:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:43:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:43:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:43:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:43:57 --> Final output sent to browser
DEBUG - 2018-05-01 21:43:57 --> Total execution time: 0.1380
INFO - 2018-05-01 18:14:03 --> Config Class Initialized
INFO - 2018-05-01 18:14:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:14:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:14:03 --> Utf8 Class Initialized
INFO - 2018-05-01 18:14:03 --> URI Class Initialized
INFO - 2018-05-01 18:14:03 --> Router Class Initialized
INFO - 2018-05-01 18:14:03 --> Output Class Initialized
INFO - 2018-05-01 18:14:03 --> Security Class Initialized
DEBUG - 2018-05-01 18:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:14:03 --> Input Class Initialized
INFO - 2018-05-01 18:14:03 --> Language Class Initialized
INFO - 2018-05-01 18:14:03 --> Loader Class Initialized
INFO - 2018-05-01 18:14:03 --> Helper loaded: common_helper
INFO - 2018-05-01 18:14:03 --> Database Driver Class Initialized
INFO - 2018-05-01 18:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:14:03 --> Email Class Initialized
INFO - 2018-05-01 18:14:03 --> Controller Class Initialized
INFO - 2018-05-01 18:14:03 --> Helper loaded: form_helper
INFO - 2018-05-01 18:14:03 --> Form Validation Class Initialized
INFO - 2018-05-01 18:14:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:14:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:14:03 --> Helper loaded: url_helper
INFO - 2018-05-01 18:14:03 --> Model Class Initialized
INFO - 2018-05-01 18:14:03 --> Model Class Initialized
INFO - 2018-05-01 18:14:03 --> Model Class Initialized
INFO - 2018-05-01 21:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:44:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:44:03 --> Final output sent to browser
DEBUG - 2018-05-01 21:44:03 --> Total execution time: 0.1440
INFO - 2018-05-01 18:14:23 --> Config Class Initialized
INFO - 2018-05-01 18:14:23 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:14:23 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:14:23 --> Utf8 Class Initialized
INFO - 2018-05-01 18:14:23 --> URI Class Initialized
INFO - 2018-05-01 18:14:23 --> Router Class Initialized
INFO - 2018-05-01 18:14:23 --> Output Class Initialized
INFO - 2018-05-01 18:14:23 --> Security Class Initialized
DEBUG - 2018-05-01 18:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:14:23 --> Input Class Initialized
INFO - 2018-05-01 18:14:23 --> Language Class Initialized
INFO - 2018-05-01 18:14:23 --> Loader Class Initialized
INFO - 2018-05-01 18:14:23 --> Helper loaded: common_helper
INFO - 2018-05-01 18:14:23 --> Database Driver Class Initialized
INFO - 2018-05-01 18:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:14:24 --> Email Class Initialized
INFO - 2018-05-01 18:14:24 --> Controller Class Initialized
INFO - 2018-05-01 18:14:24 --> Helper loaded: form_helper
INFO - 2018-05-01 18:14:24 --> Form Validation Class Initialized
INFO - 2018-05-01 18:14:24 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:14:24 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:14:24 --> Helper loaded: url_helper
INFO - 2018-05-01 18:14:24 --> Model Class Initialized
INFO - 2018-05-01 18:14:24 --> Model Class Initialized
INFO - 2018-05-01 18:14:24 --> Model Class Initialized
INFO - 2018-05-01 21:44:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:44:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:44:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:44:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:44:24 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:44:24 --> Final output sent to browser
DEBUG - 2018-05-01 21:44:24 --> Total execution time: 0.3390
INFO - 2018-05-01 18:14:31 --> Config Class Initialized
INFO - 2018-05-01 18:14:31 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:14:31 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:14:31 --> Utf8 Class Initialized
INFO - 2018-05-01 18:14:31 --> URI Class Initialized
INFO - 2018-05-01 18:14:31 --> Router Class Initialized
INFO - 2018-05-01 18:14:31 --> Output Class Initialized
INFO - 2018-05-01 18:14:31 --> Security Class Initialized
DEBUG - 2018-05-01 18:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:14:31 --> Input Class Initialized
INFO - 2018-05-01 18:14:31 --> Language Class Initialized
INFO - 2018-05-01 18:14:31 --> Loader Class Initialized
INFO - 2018-05-01 18:14:31 --> Helper loaded: common_helper
INFO - 2018-05-01 18:14:31 --> Database Driver Class Initialized
INFO - 2018-05-01 18:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:14:31 --> Email Class Initialized
INFO - 2018-05-01 18:14:31 --> Controller Class Initialized
INFO - 2018-05-01 18:14:31 --> Helper loaded: form_helper
INFO - 2018-05-01 18:14:31 --> Form Validation Class Initialized
INFO - 2018-05-01 18:14:31 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:14:31 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:14:31 --> Helper loaded: url_helper
INFO - 2018-05-01 18:14:31 --> Model Class Initialized
INFO - 2018-05-01 18:14:31 --> Model Class Initialized
INFO - 2018-05-01 18:14:31 --> Model Class Initialized
ERROR - 2018-05-01 21:44:31 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:44:31 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:14:33 --> Config Class Initialized
INFO - 2018-05-01 18:14:33 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:14:33 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:14:33 --> Utf8 Class Initialized
INFO - 2018-05-01 18:14:33 --> URI Class Initialized
INFO - 2018-05-01 18:14:33 --> Router Class Initialized
INFO - 2018-05-01 18:14:33 --> Output Class Initialized
INFO - 2018-05-01 18:14:33 --> Security Class Initialized
DEBUG - 2018-05-01 18:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:14:33 --> Input Class Initialized
INFO - 2018-05-01 18:14:33 --> Language Class Initialized
INFO - 2018-05-01 18:14:33 --> Loader Class Initialized
INFO - 2018-05-01 18:14:34 --> Helper loaded: common_helper
INFO - 2018-05-01 18:14:34 --> Database Driver Class Initialized
INFO - 2018-05-01 18:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:14:34 --> Email Class Initialized
INFO - 2018-05-01 18:14:34 --> Controller Class Initialized
INFO - 2018-05-01 18:14:34 --> Helper loaded: form_helper
INFO - 2018-05-01 18:14:34 --> Form Validation Class Initialized
INFO - 2018-05-01 18:14:34 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:14:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:14:34 --> Helper loaded: url_helper
INFO - 2018-05-01 18:14:34 --> Model Class Initialized
INFO - 2018-05-01 18:14:34 --> Model Class Initialized
INFO - 2018-05-01 18:14:34 --> Model Class Initialized
INFO - 2018-05-01 21:44:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:44:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:44:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:44:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:44:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:44:34 --> Final output sent to browser
DEBUG - 2018-05-01 21:44:34 --> Total execution time: 0.1310
INFO - 2018-05-01 18:14:52 --> Config Class Initialized
INFO - 2018-05-01 18:14:52 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:14:52 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:14:52 --> Utf8 Class Initialized
INFO - 2018-05-01 18:14:52 --> URI Class Initialized
INFO - 2018-05-01 18:14:52 --> Router Class Initialized
INFO - 2018-05-01 18:14:52 --> Output Class Initialized
INFO - 2018-05-01 18:14:52 --> Security Class Initialized
DEBUG - 2018-05-01 18:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:14:52 --> Input Class Initialized
INFO - 2018-05-01 18:14:52 --> Language Class Initialized
INFO - 2018-05-01 18:14:52 --> Loader Class Initialized
INFO - 2018-05-01 18:14:52 --> Helper loaded: common_helper
INFO - 2018-05-01 18:14:52 --> Database Driver Class Initialized
INFO - 2018-05-01 18:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:14:52 --> Email Class Initialized
INFO - 2018-05-01 18:14:52 --> Controller Class Initialized
INFO - 2018-05-01 18:14:52 --> Helper loaded: form_helper
INFO - 2018-05-01 18:14:52 --> Form Validation Class Initialized
INFO - 2018-05-01 18:14:52 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:14:52 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:14:52 --> Helper loaded: url_helper
INFO - 2018-05-01 18:14:52 --> Model Class Initialized
INFO - 2018-05-01 18:14:52 --> Model Class Initialized
INFO - 2018-05-01 18:14:52 --> Model Class Initialized
INFO - 2018-05-01 21:44:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:44:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:44:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:44:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:44:52 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:44:52 --> Final output sent to browser
DEBUG - 2018-05-01 21:44:52 --> Total execution time: 0.1320
INFO - 2018-05-01 18:15:02 --> Config Class Initialized
INFO - 2018-05-01 18:15:02 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:15:02 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:15:02 --> Utf8 Class Initialized
INFO - 2018-05-01 18:15:02 --> URI Class Initialized
INFO - 2018-05-01 18:15:02 --> Router Class Initialized
INFO - 2018-05-01 18:15:02 --> Output Class Initialized
INFO - 2018-05-01 18:15:02 --> Security Class Initialized
DEBUG - 2018-05-01 18:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:15:02 --> Input Class Initialized
INFO - 2018-05-01 18:15:02 --> Language Class Initialized
INFO - 2018-05-01 18:15:02 --> Loader Class Initialized
INFO - 2018-05-01 18:15:02 --> Helper loaded: common_helper
INFO - 2018-05-01 18:15:02 --> Database Driver Class Initialized
INFO - 2018-05-01 18:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:15:02 --> Email Class Initialized
INFO - 2018-05-01 18:15:02 --> Controller Class Initialized
INFO - 2018-05-01 18:15:02 --> Helper loaded: form_helper
INFO - 2018-05-01 18:15:02 --> Form Validation Class Initialized
INFO - 2018-05-01 18:15:02 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:15:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:15:02 --> Helper loaded: url_helper
INFO - 2018-05-01 18:15:02 --> Model Class Initialized
INFO - 2018-05-01 18:15:02 --> Model Class Initialized
INFO - 2018-05-01 18:15:02 --> Model Class Initialized
INFO - 2018-05-01 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:45:02 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:45:02 --> Final output sent to browser
DEBUG - 2018-05-01 21:45:02 --> Total execution time: 0.1570
INFO - 2018-05-01 18:15:08 --> Config Class Initialized
INFO - 2018-05-01 18:15:08 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:15:08 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:15:08 --> Utf8 Class Initialized
INFO - 2018-05-01 18:15:08 --> URI Class Initialized
INFO - 2018-05-01 18:15:08 --> Router Class Initialized
INFO - 2018-05-01 18:15:08 --> Output Class Initialized
INFO - 2018-05-01 18:15:08 --> Security Class Initialized
DEBUG - 2018-05-01 18:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:15:08 --> Input Class Initialized
INFO - 2018-05-01 18:15:08 --> Language Class Initialized
INFO - 2018-05-01 18:15:08 --> Loader Class Initialized
INFO - 2018-05-01 18:15:08 --> Helper loaded: common_helper
INFO - 2018-05-01 18:15:08 --> Database Driver Class Initialized
INFO - 2018-05-01 18:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:15:08 --> Email Class Initialized
INFO - 2018-05-01 18:15:08 --> Controller Class Initialized
INFO - 2018-05-01 18:15:08 --> Helper loaded: form_helper
INFO - 2018-05-01 18:15:08 --> Form Validation Class Initialized
INFO - 2018-05-01 18:15:08 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:15:08 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:15:08 --> Helper loaded: url_helper
INFO - 2018-05-01 18:15:08 --> Model Class Initialized
INFO - 2018-05-01 18:15:08 --> Model Class Initialized
INFO - 2018-05-01 18:15:08 --> Model Class Initialized
ERROR - 2018-05-01 21:45:08 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:45:08 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:15:14 --> Config Class Initialized
INFO - 2018-05-01 18:15:14 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:15:14 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:15:14 --> Utf8 Class Initialized
INFO - 2018-05-01 18:15:14 --> URI Class Initialized
INFO - 2018-05-01 18:15:14 --> Router Class Initialized
INFO - 2018-05-01 18:15:14 --> Output Class Initialized
INFO - 2018-05-01 18:15:14 --> Security Class Initialized
DEBUG - 2018-05-01 18:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:15:14 --> Input Class Initialized
INFO - 2018-05-01 18:15:14 --> Language Class Initialized
INFO - 2018-05-01 18:15:14 --> Loader Class Initialized
INFO - 2018-05-01 18:15:14 --> Helper loaded: common_helper
INFO - 2018-05-01 18:15:14 --> Database Driver Class Initialized
INFO - 2018-05-01 18:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:15:14 --> Email Class Initialized
INFO - 2018-05-01 18:15:14 --> Controller Class Initialized
INFO - 2018-05-01 18:15:14 --> Helper loaded: form_helper
INFO - 2018-05-01 18:15:14 --> Form Validation Class Initialized
INFO - 2018-05-01 18:15:14 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:15:14 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:15:14 --> Helper loaded: url_helper
INFO - 2018-05-01 18:15:14 --> Model Class Initialized
INFO - 2018-05-01 18:15:14 --> Model Class Initialized
INFO - 2018-05-01 18:15:14 --> Model Class Initialized
ERROR - 2018-05-01 21:45:14 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:45:14 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:15:16 --> Config Class Initialized
INFO - 2018-05-01 18:15:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:15:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:15:16 --> Utf8 Class Initialized
INFO - 2018-05-01 18:15:16 --> URI Class Initialized
INFO - 2018-05-01 18:15:16 --> Router Class Initialized
INFO - 2018-05-01 18:15:16 --> Output Class Initialized
INFO - 2018-05-01 18:15:16 --> Security Class Initialized
DEBUG - 2018-05-01 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:15:16 --> Input Class Initialized
INFO - 2018-05-01 18:15:16 --> Language Class Initialized
INFO - 2018-05-01 18:15:16 --> Loader Class Initialized
INFO - 2018-05-01 18:15:16 --> Helper loaded: common_helper
INFO - 2018-05-01 18:15:16 --> Database Driver Class Initialized
INFO - 2018-05-01 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:15:16 --> Email Class Initialized
INFO - 2018-05-01 18:15:16 --> Controller Class Initialized
INFO - 2018-05-01 18:15:16 --> Helper loaded: form_helper
INFO - 2018-05-01 18:15:16 --> Form Validation Class Initialized
INFO - 2018-05-01 18:15:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:15:16 --> Helper loaded: url_helper
INFO - 2018-05-01 18:15:16 --> Model Class Initialized
INFO - 2018-05-01 18:15:16 --> Model Class Initialized
INFO - 2018-05-01 18:15:16 --> Model Class Initialized
INFO - 2018-05-01 21:45:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:45:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:45:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:45:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:45:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:45:16 --> Final output sent to browser
DEBUG - 2018-05-01 21:45:16 --> Total execution time: 0.1350
INFO - 2018-05-01 18:15:34 --> Config Class Initialized
INFO - 2018-05-01 18:15:34 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:15:34 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:15:34 --> Utf8 Class Initialized
INFO - 2018-05-01 18:15:34 --> URI Class Initialized
INFO - 2018-05-01 18:15:34 --> Router Class Initialized
INFO - 2018-05-01 18:15:34 --> Output Class Initialized
INFO - 2018-05-01 18:15:34 --> Security Class Initialized
DEBUG - 2018-05-01 18:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:15:34 --> Input Class Initialized
INFO - 2018-05-01 18:15:34 --> Language Class Initialized
INFO - 2018-05-01 18:15:34 --> Loader Class Initialized
INFO - 2018-05-01 18:15:34 --> Helper loaded: common_helper
INFO - 2018-05-01 18:15:34 --> Database Driver Class Initialized
INFO - 2018-05-01 18:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:15:34 --> Email Class Initialized
INFO - 2018-05-01 18:15:34 --> Controller Class Initialized
INFO - 2018-05-01 18:15:34 --> Helper loaded: form_helper
INFO - 2018-05-01 18:15:34 --> Form Validation Class Initialized
INFO - 2018-05-01 18:15:34 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:15:34 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:15:34 --> Helper loaded: url_helper
INFO - 2018-05-01 18:15:34 --> Model Class Initialized
INFO - 2018-05-01 18:15:34 --> Model Class Initialized
INFO - 2018-05-01 18:15:34 --> Model Class Initialized
INFO - 2018-05-01 21:45:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:45:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:45:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:45:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:45:34 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:45:34 --> Final output sent to browser
DEBUG - 2018-05-01 21:45:34 --> Total execution time: 0.1380
INFO - 2018-05-01 18:15:56 --> Config Class Initialized
INFO - 2018-05-01 18:15:56 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:15:56 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:15:56 --> Utf8 Class Initialized
INFO - 2018-05-01 18:15:56 --> URI Class Initialized
INFO - 2018-05-01 18:15:56 --> Router Class Initialized
INFO - 2018-05-01 18:15:56 --> Output Class Initialized
INFO - 2018-05-01 18:15:56 --> Security Class Initialized
DEBUG - 2018-05-01 18:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:15:56 --> Input Class Initialized
INFO - 2018-05-01 18:15:56 --> Language Class Initialized
INFO - 2018-05-01 18:15:56 --> Loader Class Initialized
INFO - 2018-05-01 18:15:56 --> Helper loaded: common_helper
INFO - 2018-05-01 18:15:56 --> Database Driver Class Initialized
INFO - 2018-05-01 18:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:15:56 --> Email Class Initialized
INFO - 2018-05-01 18:15:56 --> Controller Class Initialized
INFO - 2018-05-01 18:15:56 --> Helper loaded: form_helper
INFO - 2018-05-01 18:15:56 --> Form Validation Class Initialized
INFO - 2018-05-01 18:15:56 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:15:56 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:15:56 --> Helper loaded: url_helper
INFO - 2018-05-01 18:15:56 --> Model Class Initialized
INFO - 2018-05-01 18:15:56 --> Model Class Initialized
INFO - 2018-05-01 18:15:56 --> Model Class Initialized
INFO - 2018-05-01 21:45:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:45:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:45:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:45:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:45:56 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:45:56 --> Final output sent to browser
DEBUG - 2018-05-01 21:45:56 --> Total execution time: 0.1470
INFO - 2018-05-01 18:16:02 --> Config Class Initialized
INFO - 2018-05-01 18:16:02 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:16:02 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:16:02 --> Utf8 Class Initialized
INFO - 2018-05-01 18:16:02 --> URI Class Initialized
INFO - 2018-05-01 18:16:02 --> Router Class Initialized
INFO - 2018-05-01 18:16:02 --> Output Class Initialized
INFO - 2018-05-01 18:16:02 --> Security Class Initialized
DEBUG - 2018-05-01 18:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:16:02 --> Input Class Initialized
INFO - 2018-05-01 18:16:02 --> Language Class Initialized
INFO - 2018-05-01 18:16:02 --> Loader Class Initialized
INFO - 2018-05-01 18:16:02 --> Helper loaded: common_helper
INFO - 2018-05-01 18:16:02 --> Database Driver Class Initialized
INFO - 2018-05-01 18:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:16:02 --> Email Class Initialized
INFO - 2018-05-01 18:16:02 --> Controller Class Initialized
INFO - 2018-05-01 18:16:02 --> Helper loaded: form_helper
INFO - 2018-05-01 18:16:02 --> Form Validation Class Initialized
INFO - 2018-05-01 18:16:02 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:16:02 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:16:02 --> Helper loaded: url_helper
INFO - 2018-05-01 18:16:02 --> Model Class Initialized
INFO - 2018-05-01 18:16:02 --> Model Class Initialized
INFO - 2018-05-01 18:16:02 --> Model Class Initialized
ERROR - 2018-05-01 21:46:02 --> rmdir(../uploads/gallery/qwertyui): No such file or directory
ERROR - 2018-05-01 21:46:02 --> Severity: Warning --> rmdir(../uploads/gallery/qwertyui): No such file or directory C:\xampp\htdocs\Celebrity\admin\application\controllers\Galery.php 251
INFO - 2018-05-01 18:16:50 --> Config Class Initialized
INFO - 2018-05-01 18:16:50 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:16:50 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:16:50 --> Utf8 Class Initialized
INFO - 2018-05-01 18:16:50 --> URI Class Initialized
INFO - 2018-05-01 18:16:50 --> Router Class Initialized
INFO - 2018-05-01 18:16:50 --> Output Class Initialized
INFO - 2018-05-01 18:16:50 --> Security Class Initialized
DEBUG - 2018-05-01 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:16:50 --> Input Class Initialized
INFO - 2018-05-01 18:16:50 --> Language Class Initialized
INFO - 2018-05-01 18:16:50 --> Loader Class Initialized
INFO - 2018-05-01 18:16:50 --> Helper loaded: common_helper
INFO - 2018-05-01 18:16:50 --> Database Driver Class Initialized
INFO - 2018-05-01 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:16:50 --> Email Class Initialized
INFO - 2018-05-01 18:16:50 --> Controller Class Initialized
INFO - 2018-05-01 18:16:50 --> Helper loaded: form_helper
INFO - 2018-05-01 18:16:50 --> Form Validation Class Initialized
INFO - 2018-05-01 18:16:50 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:16:50 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:16:50 --> Helper loaded: url_helper
INFO - 2018-05-01 18:16:50 --> Model Class Initialized
INFO - 2018-05-01 18:16:50 --> Model Class Initialized
INFO - 2018-05-01 18:16:50 --> Model Class Initialized
INFO - 2018-05-01 21:46:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:46:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:46:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:46:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:46:50 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:46:50 --> Final output sent to browser
DEBUG - 2018-05-01 21:46:50 --> Total execution time: 0.1310
INFO - 2018-05-01 18:19:13 --> Config Class Initialized
INFO - 2018-05-01 18:19:13 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:13 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:13 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:13 --> URI Class Initialized
INFO - 2018-05-01 18:19:13 --> Router Class Initialized
INFO - 2018-05-01 18:19:13 --> Output Class Initialized
INFO - 2018-05-01 18:19:13 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:13 --> Input Class Initialized
INFO - 2018-05-01 18:19:13 --> Language Class Initialized
INFO - 2018-05-01 18:19:13 --> Loader Class Initialized
INFO - 2018-05-01 18:19:13 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:13 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:13 --> Email Class Initialized
INFO - 2018-05-01 18:19:13 --> Controller Class Initialized
INFO - 2018-05-01 18:19:13 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:13 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:13 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:13 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:13 --> Model Class Initialized
INFO - 2018-05-01 18:19:13 --> Model Class Initialized
INFO - 2018-05-01 18:19:13 --> Model Class Initialized
INFO - 2018-05-01 21:49:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/addGelery.php
INFO - 2018-05-01 21:49:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:13 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:13 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:13 --> Total execution time: 0.1480
INFO - 2018-05-01 18:19:15 --> Config Class Initialized
INFO - 2018-05-01 18:19:15 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:15 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:15 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:15 --> URI Class Initialized
INFO - 2018-05-01 18:19:15 --> Router Class Initialized
INFO - 2018-05-01 18:19:15 --> Output Class Initialized
INFO - 2018-05-01 18:19:15 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:15 --> Input Class Initialized
INFO - 2018-05-01 18:19:15 --> Language Class Initialized
INFO - 2018-05-01 18:19:15 --> Loader Class Initialized
INFO - 2018-05-01 18:19:15 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:15 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:15 --> Email Class Initialized
INFO - 2018-05-01 18:19:15 --> Controller Class Initialized
INFO - 2018-05-01 18:19:15 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:15 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:15 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:15 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:15 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:15 --> Model Class Initialized
INFO - 2018-05-01 18:19:15 --> Model Class Initialized
INFO - 2018-05-01 18:19:15 --> Model Class Initialized
INFO - 2018-05-01 21:49:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\galery/image.php
INFO - 2018-05-01 21:49:15 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:15 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:15 --> Total execution time: 0.1460
INFO - 2018-05-01 18:19:16 --> Config Class Initialized
INFO - 2018-05-01 18:19:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:16 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:16 --> URI Class Initialized
INFO - 2018-05-01 18:19:16 --> Router Class Initialized
INFO - 2018-05-01 18:19:16 --> Output Class Initialized
INFO - 2018-05-01 18:19:16 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:16 --> Input Class Initialized
INFO - 2018-05-01 18:19:16 --> Language Class Initialized
INFO - 2018-05-01 18:19:16 --> Loader Class Initialized
INFO - 2018-05-01 18:19:16 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:16 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:16 --> Email Class Initialized
INFO - 2018-05-01 18:19:16 --> Controller Class Initialized
INFO - 2018-05-01 18:19:16 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:16 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:16 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:16 --> Model Class Initialized
INFO - 2018-05-01 18:19:16 --> Model Class Initialized
INFO - 2018-05-01 18:19:16 --> Model Class Initialized
INFO - 2018-05-01 21:49:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 21:49:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:16 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:16 --> Total execution time: 0.1770
INFO - 2018-05-01 18:19:17 --> Config Class Initialized
INFO - 2018-05-01 18:19:17 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:17 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:17 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:17 --> URI Class Initialized
INFO - 2018-05-01 18:19:17 --> Router Class Initialized
INFO - 2018-05-01 18:19:17 --> Output Class Initialized
INFO - 2018-05-01 18:19:17 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:17 --> Input Class Initialized
INFO - 2018-05-01 18:19:17 --> Language Class Initialized
INFO - 2018-05-01 18:19:17 --> Loader Class Initialized
INFO - 2018-05-01 18:19:17 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:17 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:17 --> Email Class Initialized
INFO - 2018-05-01 18:19:17 --> Controller Class Initialized
INFO - 2018-05-01 18:19:17 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:17 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:17 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:17 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:17 --> Model Class Initialized
INFO - 2018-05-01 18:19:17 --> Model Class Initialized
INFO - 2018-05-01 18:19:17 --> Model Class Initialized
INFO - 2018-05-01 21:49:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrity.php
INFO - 2018-05-01 21:49:17 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:17 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:17 --> Total execution time: 0.2360
INFO - 2018-05-01 18:19:18 --> Config Class Initialized
INFO - 2018-05-01 18:19:18 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:18 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:18 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:18 --> URI Class Initialized
INFO - 2018-05-01 18:19:18 --> Router Class Initialized
INFO - 2018-05-01 18:19:18 --> Output Class Initialized
INFO - 2018-05-01 18:19:18 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:18 --> Input Class Initialized
INFO - 2018-05-01 18:19:18 --> Language Class Initialized
INFO - 2018-05-01 18:19:18 --> Loader Class Initialized
INFO - 2018-05-01 18:19:18 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:18 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:18 --> Email Class Initialized
INFO - 2018-05-01 18:19:18 --> Controller Class Initialized
INFO - 2018-05-01 18:19:18 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:18 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:18 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:18 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:18 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:18 --> Model Class Initialized
INFO - 2018-05-01 18:19:18 --> Model Class Initialized
INFO - 2018-05-01 18:19:18 --> Model Class Initialized
INFO - 2018-05-01 21:49:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\Celebrity/celebrityPage.php
INFO - 2018-05-01 21:49:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:18 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:18 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:18 --> Total execution time: 0.1570
INFO - 2018-05-01 18:19:20 --> Config Class Initialized
INFO - 2018-05-01 18:19:20 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:20 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:20 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:20 --> URI Class Initialized
INFO - 2018-05-01 18:19:20 --> Router Class Initialized
INFO - 2018-05-01 18:19:20 --> Output Class Initialized
INFO - 2018-05-01 18:19:20 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:20 --> Input Class Initialized
INFO - 2018-05-01 18:19:20 --> Language Class Initialized
INFO - 2018-05-01 18:19:20 --> Loader Class Initialized
INFO - 2018-05-01 18:19:20 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:20 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:20 --> Email Class Initialized
INFO - 2018-05-01 18:19:20 --> Controller Class Initialized
INFO - 2018-05-01 18:19:20 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:20 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:20 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:20 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:20 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:20 --> Model Class Initialized
INFO - 2018-05-01 18:19:20 --> Model Class Initialized
INFO - 2018-05-01 18:19:20 --> Model Class Initialized
INFO - 2018-05-01 21:49:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:49:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:49:20 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:20 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:20 --> Total execution time: 0.1400
INFO - 2018-05-01 18:19:28 --> Config Class Initialized
INFO - 2018-05-01 18:19:28 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:19:28 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:19:28 --> Utf8 Class Initialized
INFO - 2018-05-01 18:19:28 --> URI Class Initialized
INFO - 2018-05-01 18:19:28 --> Router Class Initialized
INFO - 2018-05-01 18:19:28 --> Output Class Initialized
INFO - 2018-05-01 18:19:28 --> Security Class Initialized
DEBUG - 2018-05-01 18:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:19:28 --> Input Class Initialized
INFO - 2018-05-01 18:19:28 --> Language Class Initialized
INFO - 2018-05-01 18:19:28 --> Loader Class Initialized
INFO - 2018-05-01 18:19:29 --> Helper loaded: common_helper
INFO - 2018-05-01 18:19:29 --> Database Driver Class Initialized
INFO - 2018-05-01 18:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:19:29 --> Email Class Initialized
INFO - 2018-05-01 18:19:29 --> Controller Class Initialized
INFO - 2018-05-01 18:19:29 --> Helper loaded: form_helper
INFO - 2018-05-01 18:19:29 --> Form Validation Class Initialized
INFO - 2018-05-01 18:19:29 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:19:29 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:19:29 --> Helper loaded: url_helper
INFO - 2018-05-01 18:19:29 --> Model Class Initialized
INFO - 2018-05-01 18:19:29 --> Model Class Initialized
INFO - 2018-05-01 18:19:29 --> Model Class Initialized
INFO - 2018-05-01 21:49:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:49:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:49:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:49:29 --> Trying to get property of non-object
ERROR - 2018-05-01 21:49:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:49:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:49:29 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:49:29 --> Final output sent to browser
DEBUG - 2018-05-01 21:49:29 --> Total execution time: 0.1480
INFO - 2018-05-01 18:20:21 --> Config Class Initialized
INFO - 2018-05-01 18:20:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:20:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:20:21 --> Utf8 Class Initialized
INFO - 2018-05-01 18:20:21 --> URI Class Initialized
INFO - 2018-05-01 18:20:21 --> Router Class Initialized
INFO - 2018-05-01 18:20:21 --> Output Class Initialized
INFO - 2018-05-01 18:20:21 --> Security Class Initialized
DEBUG - 2018-05-01 18:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:20:21 --> Input Class Initialized
INFO - 2018-05-01 18:20:21 --> Language Class Initialized
INFO - 2018-05-01 18:20:21 --> Loader Class Initialized
INFO - 2018-05-01 18:20:21 --> Helper loaded: common_helper
INFO - 2018-05-01 18:20:21 --> Database Driver Class Initialized
INFO - 2018-05-01 18:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:20:21 --> Email Class Initialized
INFO - 2018-05-01 18:20:21 --> Controller Class Initialized
INFO - 2018-05-01 18:20:21 --> Helper loaded: form_helper
INFO - 2018-05-01 18:20:21 --> Form Validation Class Initialized
INFO - 2018-05-01 18:20:21 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:20:21 --> Helper loaded: url_helper
INFO - 2018-05-01 18:20:21 --> Model Class Initialized
INFO - 2018-05-01 18:20:21 --> Model Class Initialized
INFO - 2018-05-01 18:20:21 --> Model Class Initialized
INFO - 2018-05-01 21:50:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:50:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:50:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:50:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:50:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:50:21 --> Final output sent to browser
DEBUG - 2018-05-01 21:50:21 --> Total execution time: 0.1380
INFO - 2018-05-01 18:20:35 --> Config Class Initialized
INFO - 2018-05-01 18:20:35 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:20:35 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:20:35 --> Utf8 Class Initialized
INFO - 2018-05-01 18:20:35 --> URI Class Initialized
INFO - 2018-05-01 18:20:35 --> Router Class Initialized
INFO - 2018-05-01 18:20:35 --> Output Class Initialized
INFO - 2018-05-01 18:20:35 --> Security Class Initialized
DEBUG - 2018-05-01 18:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:20:35 --> Input Class Initialized
INFO - 2018-05-01 18:20:35 --> Language Class Initialized
INFO - 2018-05-01 18:20:35 --> Loader Class Initialized
INFO - 2018-05-01 18:20:35 --> Helper loaded: common_helper
INFO - 2018-05-01 18:20:35 --> Database Driver Class Initialized
INFO - 2018-05-01 18:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:20:35 --> Email Class Initialized
INFO - 2018-05-01 18:20:35 --> Controller Class Initialized
INFO - 2018-05-01 18:20:35 --> Helper loaded: form_helper
INFO - 2018-05-01 18:20:35 --> Form Validation Class Initialized
INFO - 2018-05-01 18:20:35 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:20:35 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:20:35 --> Helper loaded: url_helper
INFO - 2018-05-01 18:20:35 --> Model Class Initialized
INFO - 2018-05-01 18:20:35 --> Model Class Initialized
INFO - 2018-05-01 18:20:35 --> Model Class Initialized
INFO - 2018-05-01 21:50:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:50:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:50:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:50:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:50:35 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:50:35 --> Final output sent to browser
DEBUG - 2018-05-01 21:50:35 --> Total execution time: 0.1330
INFO - 2018-05-01 18:20:40 --> Config Class Initialized
INFO - 2018-05-01 18:20:40 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:20:40 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:20:40 --> Utf8 Class Initialized
INFO - 2018-05-01 18:20:40 --> URI Class Initialized
INFO - 2018-05-01 18:20:40 --> Router Class Initialized
INFO - 2018-05-01 18:20:40 --> Output Class Initialized
INFO - 2018-05-01 18:20:40 --> Security Class Initialized
DEBUG - 2018-05-01 18:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:20:40 --> Input Class Initialized
INFO - 2018-05-01 18:20:40 --> Language Class Initialized
INFO - 2018-05-01 18:20:40 --> Loader Class Initialized
INFO - 2018-05-01 18:20:40 --> Helper loaded: common_helper
INFO - 2018-05-01 18:20:40 --> Database Driver Class Initialized
INFO - 2018-05-01 18:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:20:40 --> Email Class Initialized
INFO - 2018-05-01 18:20:40 --> Controller Class Initialized
INFO - 2018-05-01 18:20:40 --> Helper loaded: form_helper
INFO - 2018-05-01 18:20:40 --> Form Validation Class Initialized
INFO - 2018-05-01 18:20:40 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:20:40 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:20:40 --> Helper loaded: url_helper
INFO - 2018-05-01 18:20:40 --> Model Class Initialized
INFO - 2018-05-01 18:20:40 --> Model Class Initialized
INFO - 2018-05-01 18:20:40 --> Model Class Initialized
INFO - 2018-05-01 21:50:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:50:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:50:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:50:40 --> Trying to get property of non-object
ERROR - 2018-05-01 21:50:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:50:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:50:40 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:50:40 --> Final output sent to browser
DEBUG - 2018-05-01 21:50:40 --> Total execution time: 0.1540
INFO - 2018-05-01 18:20:42 --> Config Class Initialized
INFO - 2018-05-01 18:20:42 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:20:42 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:20:42 --> Utf8 Class Initialized
INFO - 2018-05-01 18:20:42 --> URI Class Initialized
INFO - 2018-05-01 18:20:42 --> Router Class Initialized
INFO - 2018-05-01 18:20:42 --> Output Class Initialized
INFO - 2018-05-01 18:20:42 --> Security Class Initialized
DEBUG - 2018-05-01 18:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:20:42 --> Input Class Initialized
INFO - 2018-05-01 18:20:42 --> Language Class Initialized
INFO - 2018-05-01 18:20:42 --> Loader Class Initialized
INFO - 2018-05-01 18:20:42 --> Helper loaded: common_helper
INFO - 2018-05-01 18:20:42 --> Database Driver Class Initialized
INFO - 2018-05-01 18:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:20:43 --> Email Class Initialized
INFO - 2018-05-01 18:20:43 --> Controller Class Initialized
INFO - 2018-05-01 18:20:43 --> Helper loaded: form_helper
INFO - 2018-05-01 18:20:43 --> Form Validation Class Initialized
INFO - 2018-05-01 18:20:43 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:20:43 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:20:43 --> Helper loaded: url_helper
INFO - 2018-05-01 18:20:43 --> Model Class Initialized
INFO - 2018-05-01 18:20:43 --> Model Class Initialized
INFO - 2018-05-01 18:20:43 --> Model Class Initialized
INFO - 2018-05-01 21:50:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:50:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:50:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:50:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:50:43 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:50:43 --> Final output sent to browser
DEBUG - 2018-05-01 21:50:43 --> Total execution time: 0.1380
INFO - 2018-05-01 18:20:48 --> Config Class Initialized
INFO - 2018-05-01 18:20:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:20:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:20:48 --> Utf8 Class Initialized
INFO - 2018-05-01 18:20:48 --> URI Class Initialized
INFO - 2018-05-01 18:20:48 --> Router Class Initialized
INFO - 2018-05-01 18:20:48 --> Output Class Initialized
INFO - 2018-05-01 18:20:48 --> Security Class Initialized
DEBUG - 2018-05-01 18:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:20:48 --> Input Class Initialized
INFO - 2018-05-01 18:20:48 --> Language Class Initialized
INFO - 2018-05-01 18:20:48 --> Loader Class Initialized
INFO - 2018-05-01 18:20:48 --> Helper loaded: common_helper
INFO - 2018-05-01 18:20:48 --> Database Driver Class Initialized
INFO - 2018-05-01 18:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:20:48 --> Email Class Initialized
INFO - 2018-05-01 18:20:48 --> Controller Class Initialized
INFO - 2018-05-01 18:20:48 --> Helper loaded: form_helper
INFO - 2018-05-01 18:20:48 --> Form Validation Class Initialized
INFO - 2018-05-01 18:20:48 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:20:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:20:48 --> Helper loaded: url_helper
INFO - 2018-05-01 18:20:48 --> Model Class Initialized
INFO - 2018-05-01 18:20:48 --> Model Class Initialized
INFO - 2018-05-01 18:20:48 --> Model Class Initialized
INFO - 2018-05-01 21:50:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:50:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:50:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:50:48 --> Trying to get property of non-object
ERROR - 2018-05-01 21:50:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:50:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:50:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:50:48 --> Final output sent to browser
DEBUG - 2018-05-01 21:50:48 --> Total execution time: 0.1510
INFO - 2018-05-01 18:20:57 --> Config Class Initialized
INFO - 2018-05-01 18:20:57 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:20:57 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:20:57 --> Utf8 Class Initialized
INFO - 2018-05-01 18:20:57 --> URI Class Initialized
INFO - 2018-05-01 18:20:57 --> Router Class Initialized
INFO - 2018-05-01 18:20:57 --> Output Class Initialized
INFO - 2018-05-01 18:20:57 --> Security Class Initialized
DEBUG - 2018-05-01 18:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:20:57 --> Input Class Initialized
INFO - 2018-05-01 18:20:57 --> Language Class Initialized
INFO - 2018-05-01 18:20:57 --> Loader Class Initialized
INFO - 2018-05-01 18:20:57 --> Helper loaded: common_helper
INFO - 2018-05-01 18:20:57 --> Database Driver Class Initialized
INFO - 2018-05-01 18:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:20:57 --> Email Class Initialized
INFO - 2018-05-01 18:20:57 --> Controller Class Initialized
INFO - 2018-05-01 18:20:57 --> Helper loaded: form_helper
INFO - 2018-05-01 18:20:57 --> Form Validation Class Initialized
INFO - 2018-05-01 18:20:57 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:20:57 --> Helper loaded: url_helper
INFO - 2018-05-01 18:20:57 --> Model Class Initialized
INFO - 2018-05-01 18:20:57 --> Model Class Initialized
INFO - 2018-05-01 18:20:57 --> Model Class Initialized
INFO - 2018-05-01 21:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:50:57 --> Trying to get property of non-object
ERROR - 2018-05-01 21:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:50:57 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:50:57 --> Final output sent to browser
DEBUG - 2018-05-01 21:50:57 --> Total execution time: 0.1480
INFO - 2018-05-01 18:21:00 --> Config Class Initialized
INFO - 2018-05-01 18:21:00 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:21:00 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:21:00 --> Utf8 Class Initialized
INFO - 2018-05-01 18:21:00 --> URI Class Initialized
INFO - 2018-05-01 18:21:00 --> Router Class Initialized
INFO - 2018-05-01 18:21:00 --> Output Class Initialized
INFO - 2018-05-01 18:21:00 --> Security Class Initialized
DEBUG - 2018-05-01 18:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:21:00 --> Input Class Initialized
INFO - 2018-05-01 18:21:00 --> Language Class Initialized
INFO - 2018-05-01 18:21:00 --> Loader Class Initialized
INFO - 2018-05-01 18:21:00 --> Helper loaded: common_helper
INFO - 2018-05-01 18:21:00 --> Database Driver Class Initialized
INFO - 2018-05-01 18:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:21:00 --> Email Class Initialized
INFO - 2018-05-01 18:21:00 --> Controller Class Initialized
INFO - 2018-05-01 18:21:00 --> Helper loaded: form_helper
INFO - 2018-05-01 18:21:00 --> Form Validation Class Initialized
INFO - 2018-05-01 18:21:00 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:21:00 --> Helper loaded: url_helper
INFO - 2018-05-01 18:21:00 --> Model Class Initialized
INFO - 2018-05-01 18:21:00 --> Model Class Initialized
INFO - 2018-05-01 18:21:00 --> Model Class Initialized
INFO - 2018-05-01 21:51:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:51:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:51:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:51:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:51:00 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:51:00 --> Final output sent to browser
DEBUG - 2018-05-01 21:51:00 --> Total execution time: 0.1340
INFO - 2018-05-01 18:21:44 --> Config Class Initialized
INFO - 2018-05-01 18:21:44 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:21:44 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:21:44 --> Utf8 Class Initialized
INFO - 2018-05-01 18:21:44 --> URI Class Initialized
INFO - 2018-05-01 18:21:44 --> Router Class Initialized
INFO - 2018-05-01 18:21:44 --> Output Class Initialized
INFO - 2018-05-01 18:21:44 --> Security Class Initialized
DEBUG - 2018-05-01 18:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:21:44 --> Input Class Initialized
INFO - 2018-05-01 18:21:44 --> Language Class Initialized
INFO - 2018-05-01 18:21:44 --> Loader Class Initialized
INFO - 2018-05-01 18:21:44 --> Helper loaded: common_helper
INFO - 2018-05-01 18:21:44 --> Database Driver Class Initialized
INFO - 2018-05-01 18:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:21:44 --> Email Class Initialized
INFO - 2018-05-01 18:21:44 --> Controller Class Initialized
INFO - 2018-05-01 18:21:44 --> Helper loaded: form_helper
INFO - 2018-05-01 18:21:44 --> Form Validation Class Initialized
INFO - 2018-05-01 18:21:44 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:21:44 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:21:44 --> Helper loaded: url_helper
INFO - 2018-05-01 18:21:44 --> Model Class Initialized
INFO - 2018-05-01 18:21:44 --> Model Class Initialized
INFO - 2018-05-01 18:21:44 --> Model Class Initialized
INFO - 2018-05-01 21:51:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:51:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:51:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:51:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:51:44 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:51:44 --> Final output sent to browser
DEBUG - 2018-05-01 21:51:44 --> Total execution time: 0.1370
INFO - 2018-05-01 18:21:48 --> Config Class Initialized
INFO - 2018-05-01 18:21:48 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:21:48 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:21:48 --> Utf8 Class Initialized
INFO - 2018-05-01 18:21:48 --> URI Class Initialized
INFO - 2018-05-01 18:21:48 --> Router Class Initialized
INFO - 2018-05-01 18:21:48 --> Output Class Initialized
INFO - 2018-05-01 18:21:48 --> Security Class Initialized
DEBUG - 2018-05-01 18:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:21:48 --> Input Class Initialized
INFO - 2018-05-01 18:21:48 --> Language Class Initialized
INFO - 2018-05-01 18:21:48 --> Loader Class Initialized
INFO - 2018-05-01 18:21:48 --> Helper loaded: common_helper
INFO - 2018-05-01 18:21:48 --> Database Driver Class Initialized
INFO - 2018-05-01 18:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:21:48 --> Email Class Initialized
INFO - 2018-05-01 18:21:48 --> Controller Class Initialized
INFO - 2018-05-01 18:21:48 --> Helper loaded: form_helper
INFO - 2018-05-01 18:21:48 --> Form Validation Class Initialized
INFO - 2018-05-01 18:21:48 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:21:48 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:21:48 --> Helper loaded: url_helper
INFO - 2018-05-01 18:21:48 --> Model Class Initialized
INFO - 2018-05-01 18:21:48 --> Model Class Initialized
INFO - 2018-05-01 18:21:48 --> Model Class Initialized
INFO - 2018-05-01 21:51:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:51:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:51:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:51:48 --> Trying to get property of non-object
ERROR - 2018-05-01 21:51:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:51:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:51:48 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:51:48 --> Final output sent to browser
DEBUG - 2018-05-01 21:51:48 --> Total execution time: 0.1540
INFO - 2018-05-01 18:21:51 --> Config Class Initialized
INFO - 2018-05-01 18:21:51 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:21:51 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:21:51 --> Utf8 Class Initialized
INFO - 2018-05-01 18:21:51 --> URI Class Initialized
INFO - 2018-05-01 18:21:51 --> Router Class Initialized
INFO - 2018-05-01 18:21:51 --> Output Class Initialized
INFO - 2018-05-01 18:21:51 --> Security Class Initialized
DEBUG - 2018-05-01 18:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:21:51 --> Input Class Initialized
INFO - 2018-05-01 18:21:51 --> Language Class Initialized
INFO - 2018-05-01 18:21:51 --> Loader Class Initialized
INFO - 2018-05-01 18:21:51 --> Helper loaded: common_helper
INFO - 2018-05-01 18:21:51 --> Database Driver Class Initialized
INFO - 2018-05-01 18:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:21:51 --> Email Class Initialized
INFO - 2018-05-01 18:21:51 --> Controller Class Initialized
INFO - 2018-05-01 18:21:51 --> Helper loaded: form_helper
INFO - 2018-05-01 18:21:51 --> Form Validation Class Initialized
INFO - 2018-05-01 18:21:51 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:21:51 --> Helper loaded: url_helper
INFO - 2018-05-01 18:21:51 --> Model Class Initialized
INFO - 2018-05-01 18:21:51 --> Model Class Initialized
INFO - 2018-05-01 18:21:51 --> Model Class Initialized
INFO - 2018-05-01 21:51:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:51:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:51:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:51:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:51:51 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:51:51 --> Final output sent to browser
DEBUG - 2018-05-01 21:51:51 --> Total execution time: 0.1340
INFO - 2018-05-01 18:22:35 --> Config Class Initialized
INFO - 2018-05-01 18:22:35 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:22:35 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:22:35 --> Utf8 Class Initialized
INFO - 2018-05-01 18:22:35 --> URI Class Initialized
INFO - 2018-05-01 18:22:35 --> Router Class Initialized
INFO - 2018-05-01 18:22:35 --> Output Class Initialized
INFO - 2018-05-01 18:22:35 --> Security Class Initialized
DEBUG - 2018-05-01 18:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:22:35 --> Input Class Initialized
INFO - 2018-05-01 18:22:35 --> Language Class Initialized
INFO - 2018-05-01 18:22:35 --> Loader Class Initialized
INFO - 2018-05-01 18:22:35 --> Helper loaded: common_helper
INFO - 2018-05-01 18:22:35 --> Database Driver Class Initialized
INFO - 2018-05-01 18:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:22:35 --> Email Class Initialized
INFO - 2018-05-01 18:22:35 --> Controller Class Initialized
INFO - 2018-05-01 18:22:35 --> Helper loaded: form_helper
INFO - 2018-05-01 18:22:36 --> Form Validation Class Initialized
INFO - 2018-05-01 18:22:36 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:22:36 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:22:36 --> Helper loaded: url_helper
INFO - 2018-05-01 18:22:36 --> Model Class Initialized
INFO - 2018-05-01 18:22:36 --> Model Class Initialized
INFO - 2018-05-01 18:22:36 --> Model Class Initialized
INFO - 2018-05-01 21:52:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:52:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:52:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:52:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:52:36 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:52:36 --> Final output sent to browser
DEBUG - 2018-05-01 21:52:36 --> Total execution time: 0.1440
INFO - 2018-05-01 18:22:41 --> Config Class Initialized
INFO - 2018-05-01 18:22:41 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:22:41 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:22:41 --> Utf8 Class Initialized
INFO - 2018-05-01 18:22:41 --> URI Class Initialized
INFO - 2018-05-01 18:22:41 --> Router Class Initialized
INFO - 2018-05-01 18:22:41 --> Output Class Initialized
INFO - 2018-05-01 18:22:41 --> Security Class Initialized
DEBUG - 2018-05-01 18:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:22:41 --> Input Class Initialized
INFO - 2018-05-01 18:22:41 --> Language Class Initialized
INFO - 2018-05-01 18:22:41 --> Loader Class Initialized
INFO - 2018-05-01 18:22:41 --> Helper loaded: common_helper
INFO - 2018-05-01 18:22:41 --> Database Driver Class Initialized
INFO - 2018-05-01 18:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:22:41 --> Email Class Initialized
INFO - 2018-05-01 18:22:41 --> Controller Class Initialized
INFO - 2018-05-01 18:22:41 --> Helper loaded: form_helper
INFO - 2018-05-01 18:22:41 --> Form Validation Class Initialized
INFO - 2018-05-01 18:22:41 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:22:41 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:22:41 --> Helper loaded: url_helper
INFO - 2018-05-01 18:22:41 --> Model Class Initialized
INFO - 2018-05-01 18:22:41 --> Model Class Initialized
INFO - 2018-05-01 18:22:41 --> Model Class Initialized
INFO - 2018-05-01 21:52:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:52:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:52:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:52:41 --> Trying to get property of non-object
ERROR - 2018-05-01 21:52:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:52:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:52:41 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:52:41 --> Final output sent to browser
DEBUG - 2018-05-01 21:52:41 --> Total execution time: 0.1520
INFO - 2018-05-01 18:23:03 --> Config Class Initialized
INFO - 2018-05-01 18:23:03 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:23:03 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:23:03 --> Utf8 Class Initialized
INFO - 2018-05-01 18:23:03 --> URI Class Initialized
INFO - 2018-05-01 18:23:03 --> Router Class Initialized
INFO - 2018-05-01 18:23:03 --> Output Class Initialized
INFO - 2018-05-01 18:23:03 --> Security Class Initialized
DEBUG - 2018-05-01 18:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:23:03 --> Input Class Initialized
INFO - 2018-05-01 18:23:03 --> Language Class Initialized
INFO - 2018-05-01 18:23:03 --> Loader Class Initialized
INFO - 2018-05-01 18:23:03 --> Helper loaded: common_helper
INFO - 2018-05-01 18:23:03 --> Database Driver Class Initialized
INFO - 2018-05-01 18:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:23:03 --> Email Class Initialized
INFO - 2018-05-01 18:23:03 --> Controller Class Initialized
INFO - 2018-05-01 18:23:03 --> Helper loaded: form_helper
INFO - 2018-05-01 18:23:03 --> Form Validation Class Initialized
INFO - 2018-05-01 18:23:03 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:23:03 --> Helper loaded: url_helper
INFO - 2018-05-01 18:23:03 --> Model Class Initialized
INFO - 2018-05-01 18:23:03 --> Model Class Initialized
INFO - 2018-05-01 18:23:03 --> Model Class Initialized
INFO - 2018-05-01 21:53:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:53:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:53:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:53:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:53:03 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:53:03 --> Final output sent to browser
DEBUG - 2018-05-01 21:53:03 --> Total execution time: 0.1350
INFO - 2018-05-01 18:23:07 --> Config Class Initialized
INFO - 2018-05-01 18:23:07 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:23:07 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:23:07 --> Utf8 Class Initialized
INFO - 2018-05-01 18:23:07 --> URI Class Initialized
INFO - 2018-05-01 18:23:07 --> Router Class Initialized
INFO - 2018-05-01 18:23:07 --> Output Class Initialized
INFO - 2018-05-01 18:23:07 --> Security Class Initialized
DEBUG - 2018-05-01 18:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:23:07 --> Input Class Initialized
INFO - 2018-05-01 18:23:07 --> Language Class Initialized
INFO - 2018-05-01 18:23:07 --> Loader Class Initialized
INFO - 2018-05-01 18:23:07 --> Helper loaded: common_helper
INFO - 2018-05-01 18:23:07 --> Database Driver Class Initialized
INFO - 2018-05-01 18:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:23:07 --> Email Class Initialized
INFO - 2018-05-01 18:23:07 --> Controller Class Initialized
INFO - 2018-05-01 18:23:07 --> Helper loaded: form_helper
INFO - 2018-05-01 18:23:07 --> Form Validation Class Initialized
INFO - 2018-05-01 18:23:07 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:23:07 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:23:07 --> Helper loaded: url_helper
INFO - 2018-05-01 18:23:07 --> Model Class Initialized
INFO - 2018-05-01 18:23:07 --> Model Class Initialized
INFO - 2018-05-01 18:23:07 --> Model Class Initialized
INFO - 2018-05-01 21:53:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:53:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:53:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:53:07 --> Trying to get property of non-object
ERROR - 2018-05-01 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:53:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:53:07 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:53:07 --> Final output sent to browser
DEBUG - 2018-05-01 21:53:07 --> Total execution time: 0.1610
INFO - 2018-05-01 18:23:16 --> Config Class Initialized
INFO - 2018-05-01 18:23:16 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:23:16 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:23:16 --> Utf8 Class Initialized
INFO - 2018-05-01 18:23:16 --> URI Class Initialized
INFO - 2018-05-01 18:23:16 --> Router Class Initialized
INFO - 2018-05-01 18:23:16 --> Output Class Initialized
INFO - 2018-05-01 18:23:16 --> Security Class Initialized
DEBUG - 2018-05-01 18:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:23:16 --> Input Class Initialized
INFO - 2018-05-01 18:23:16 --> Language Class Initialized
INFO - 2018-05-01 18:23:16 --> Loader Class Initialized
INFO - 2018-05-01 18:23:16 --> Helper loaded: common_helper
INFO - 2018-05-01 18:23:16 --> Database Driver Class Initialized
INFO - 2018-05-01 18:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:23:16 --> Email Class Initialized
INFO - 2018-05-01 18:23:16 --> Controller Class Initialized
INFO - 2018-05-01 18:23:16 --> Helper loaded: form_helper
INFO - 2018-05-01 18:23:16 --> Form Validation Class Initialized
INFO - 2018-05-01 18:23:16 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:23:16 --> Helper loaded: url_helper
INFO - 2018-05-01 18:23:16 --> Model Class Initialized
INFO - 2018-05-01 18:23:16 --> Model Class Initialized
INFO - 2018-05-01 18:23:16 --> Model Class Initialized
INFO - 2018-05-01 21:53:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:53:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:53:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
INFO - 2018-05-01 21:53:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:53:16 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:53:16 --> Final output sent to browser
DEBUG - 2018-05-01 21:53:16 --> Total execution time: 0.1350
INFO - 2018-05-01 18:23:21 --> Config Class Initialized
INFO - 2018-05-01 18:23:21 --> Hooks Class Initialized
DEBUG - 2018-05-01 18:23:21 --> UTF-8 Support Enabled
INFO - 2018-05-01 18:23:21 --> Utf8 Class Initialized
INFO - 2018-05-01 18:23:21 --> URI Class Initialized
INFO - 2018-05-01 18:23:21 --> Router Class Initialized
INFO - 2018-05-01 18:23:21 --> Output Class Initialized
INFO - 2018-05-01 18:23:21 --> Security Class Initialized
DEBUG - 2018-05-01 18:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-05-01 18:23:21 --> Input Class Initialized
INFO - 2018-05-01 18:23:21 --> Language Class Initialized
INFO - 2018-05-01 18:23:21 --> Loader Class Initialized
INFO - 2018-05-01 18:23:21 --> Helper loaded: common_helper
INFO - 2018-05-01 18:23:21 --> Database Driver Class Initialized
INFO - 2018-05-01 18:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2018-05-01 18:23:21 --> Email Class Initialized
INFO - 2018-05-01 18:23:21 --> Controller Class Initialized
INFO - 2018-05-01 18:23:21 --> Helper loaded: form_helper
INFO - 2018-05-01 18:23:21 --> Form Validation Class Initialized
INFO - 2018-05-01 18:23:21 --> Helper loaded: email_helper
DEBUG - 2018-05-01 18:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2018-05-01 18:23:21 --> Helper loaded: url_helper
INFO - 2018-05-01 18:23:21 --> Model Class Initialized
INFO - 2018-05-01 18:23:21 --> Model Class Initialized
INFO - 2018-05-01 18:23:21 --> Model Class Initialized
INFO - 2018-05-01 21:53:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\header.php
INFO - 2018-05-01 21:53:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\sideMenu.php
INFO - 2018-05-01 21:53:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\scripts.php
ERROR - 2018-05-01 21:53:21 --> Trying to get property of non-object
ERROR - 2018-05-01 21:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\Celebrity\admin\application\views\movies\movies.php 23
INFO - 2018-05-01 21:53:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\movies/movies.php
INFO - 2018-05-01 21:53:21 --> File loaded: C:\xampp\htdocs\Celebrity\admin\application\views\footer.php
INFO - 2018-05-01 21:53:21 --> Final output sent to browser
DEBUG - 2018-05-01 21:53:21 --> Total execution time: 0.1540
